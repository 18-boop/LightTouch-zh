//! Settings: grouped cards like the Android app's settings screen.
use super::{App, Dialog, Page, icons, overlay, theme, widgets};
use eframe::egui::{self, RichText, Ui};
use lighttouch_model::session::Phase;
use lighttouch_model::settings::{Corner, OverlayGraph, OverlayLevel, Scaling, Theme};

pub fn show(app: &mut App, ui: &mut Ui) {
    let p = app.palette;
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        ui.add_space(18.0);
        let width = (ui.available_width() - 48.0).clamp(200.0, 640.0);
        let margin = ((ui.available_width() - width) / 2.0).max(24.0);
        egui::Frame::new().inner_margin(egui::Margin::symmetric(margin as i8, 0)).show(ui, |ui| {
            ui.set_max_width(width);
            ui.horizontal(|ui| {
                if widgets::icon_button(ui, &p, icons::BACK, "返回").clicked() {
                    app.page = Page::Device;
                }
                ui.label(RichText::new("设置").font(theme::headline()));
            });
            let before = app.model.settings.clone();
            let recording = app.model.recording_status();
            let running = app.model.session.as_ref().is_some_and(|s| matches!(s.phase, Phase::Running));
            let mut toggle_recording = false;
            let settings = &mut app.model.settings;

            widgets::section(ui, &p, "显示");
            widgets::card(ui, &p, |ui| {
                widgets::setting_row(ui, &p, icons::SUN, "主题", "", |ui| {
                    widgets::segmented(
                        ui,
                        &p,
                        &mut settings.theme,
                        &[(Theme::System, "跟随系统"), (Theme::Dark, "深色"), (Theme::Light, "浅色")],
                    );
                });
                widgets::setting_row(
                    ui,
                    &p,
                    icons::MONITOR,
                    "画面缩放",
                    "平滑会混合像素，锐利保持像素清晰",
                    |ui| {
                        widgets::segmented(
                            ui,
                            &p,
                            &mut settings.scaling,
                            &[(Scaling::Smooth, "平滑"), (Scaling::Sharp, "锐利")],
                        );
                    },
                );
                widgets::setting_row(
                    ui,
                    &p,
                    icons::PHONE,
                    "显示设备外观",
                    "在屏幕外绘制 iPod 或 iPhone 的外观",
                    |ui| {
                        widgets::switch(ui, &p, &mut settings.device_frame);
                    },
                );
                widgets::setting_row(
                    ui,
                    &p,
                    icons::PAUSE,
                    "最小化时暂停",
                    "窗口恢复后继续运行",
                    |ui| {
                        widgets::switch(ui, &p, &mut settings.pause_when_hidden);
                    },
                );
            });

            widgets::section(ui, &p, "操作说明");
            widgets::card(ui, &p, |ui| {
                #[cfg(target_os = "macos")]
                const MOUSE: &str = "单击即轻按；Option+拖动可缩放或旋转，Option+Shift+拖动可双指移动。H 主屏幕，P 睡眠/唤醒，+ 与 − 调节音量";
                #[cfg(not(target_os = "macos"))]
                const MOUSE: &str = "单击即轻按；Alt+拖动可缩放或旋转，Alt+Shift+拖动可双指移动。H 主屏幕，P 睡眠/唤醒，+ 与 − 调节音量";
                widgets::setting_row(ui, &p, icons::INFO, "鼠标与键盘", MOUSE, |_| {});
                widgets::setting_row(
                    ui,
                    &p,
                    icons::KEYBOARD,
                    "用方向键倾斜",
                    "让设备朝按键方向倾斜，适合靠倾斜操控的游戏",
                    |ui| {
                        widgets::switch(ui, &p, &mut settings.tilt);
                    },
                );
            });

            widgets::section(ui, &p, "音频");
            widgets::card(ui, &p, |ui| {
                widgets::setting_row(
                    ui,
                    &p,
                    icons::HEADPHONES,
                    "已插入耳机",
                    "通过耳机插孔输出立体声；关闭则用设备扬声器播放。下次启动设备时生效",
                    |ui| {
                        widgets::switch(ui, &p, &mut settings.headphones);
                        if widgets::icon_button(ui, &p, icons::INFO, "关于此设置").clicked() {
                            app.dialog = Some(Dialog::Headphones);
                        }
                    },
                );
                widgets::setting_row(ui, &p, icons::VOLUME_UP, "静音", "让设备静音但不暂停", |ui| {
                    widgets::switch(ui, &p, &mut settings.muted);
                });
            });

            widgets::section(ui, &p, "连接");
            widgets::card(ui, &p, |ui| {
                widgets::setting_row(ui, &p, icons::GLOBE, "网络", &settings.network.summary(), |ui| {
                    if widgets::tonal(ui, &p, "打开").clicked() {
                        app.page = Page::Network;
                    }
                });
            });

            widgets::section(ui, &p, "性能浮层");
            widgets::card(ui, &p, |ui| {
                widgets::setting_row(ui, &p, icons::CHART, "详细程度", "", |ui| {
                    widgets::segmented(
                        ui,
                        &p,
                        &mut settings.overlay,
                        &[
                            (OverlayLevel::Off, "已关闭"),
                            (OverlayLevel::Fps, "FPS"),
                            (OverlayLevel::Basic, "基础"),
                            (OverlayLevel::Full, "完整"),
                        ],
                    );
                });
                if settings.overlay != OverlayLevel::Off {
                    egui::Frame::new().inner_margin(egui::Margin { left: 30, right: 4, top: 4, bottom: 8 }).show(ui, |ui| {
                        overlay::preview(ui, settings, app.model.session.as_ref());
                    });
                    widgets::setting_row(ui, &p, icons::CHART, "图表", "", |ui| {
                        widgets::segmented(
                            ui,
                            &p,
                            &mut settings.overlay_graph,
                            &[(OverlayGraph::FrameTime, "帧耗时"), (OverlayGraph::FrameRate, "帧率")],
                        );
                    });
                    widgets::setting_row(ui, &p, icons::MONITOR, "位置", "", |ui| {
                        widgets::segmented(
                            ui,
                            &p,
                            &mut settings.overlay_corner,
                            &[
                                (Corner::TopLeft, "↖"),
                                (Corner::TopRight, "↗"),
                                (Corner::BottomLeft, "↙"),
                                (Corner::BottomRight, "↘"),
                            ],
                        );
                    });
                    widgets::setting_row(ui, &p, icons::SUN, "背景", "", |ui| {
                        ui.add(egui::Slider::new(&mut settings.overlay_opacity, 0.0..=0.9).show_value(false));
                    });
                    widgets::setting_row(
                        ui,
                        &p,
                        icons::PHONE,
                        "在设备视图中显示",
                        "否则仅在全屏显示",
                        |ui| {
                            widgets::switch(ui, &p, &mut settings.overlay_in_device_view);
                        },
                    );
                }
            });

            widgets::section(ui, &p, "诊断");
            widgets::card(ui, &p, |ui| {
                widgets::setting_row(
                    ui,
                    &p,
                    icons::CHART,
                    "检查按钮",
                    "在控制栏中加入帧检查器",
                    |ui| {
                        widgets::switch(ui, &p, &mut settings.inspect_button);
                    },
                );
                widgets::setting_row(
                    ui,
                    &p,
                    icons::CPU,
                    "详细帧计时",
                    "在帧检查器中显示每帧的时间去向，约损耗几个百分点的速度。",
                    |ui| {
                        widgets::switch(ui, &p, &mut settings.detailed_timing);
                    },
                );
                if !settings.detailed_timing {
                    let status = &recording;
                    let (title, detail) = match status {
                        Some(s) => ("停止性能记录", s.as_str()),
                        None => (
                            "记录性能数据",
                            "捕获当前应用引擎时序，供 tools/perf/profile.py 使用",
                        ),
                    };
                    widgets::setting_row(ui, &p, icons::CLOCK, title, detail, |ui| {
                        let label = if status.is_some() { "停止" } else { "记录" };
                        if widgets::tonal_enabled(ui, &p, label, running || status.is_some()).clicked() {
                            toggle_recording = true;
                        }
                    });
                    if status.is_some() {
                        ui.ctx().request_repaint_after(std::time::Duration::from_millis(500));
                    }
                }
                widgets::setting_row(ui, &p, icons::FILE, "会话日志", "每个设备会话的输出", |ui| {
                    if widgets::tonal(ui, &p, "打开文件夹").clicked() {
                        let dir = app.model.dirs.logs();
                        let _ = std::fs::create_dir_all(&dir);
                        open_path(&dir);
                    }
                });
            });

            let session_active = app.model.session_active();
            let selected = app.model.selected().cloned();
            widgets::section(ui, &p, "设备");
            widgets::card(ui, &p, |ui| {
                if let Some(device) = &selected {
                    widgets::setting_row(
                        ui,
                        &p,
                        icons::RECOVER,
                        "恢复保留的状态",
                        "以保留的数据冷启动所选设备",
                        |ui| {
                            if widgets::tonal_enabled(ui, &p, "恢复", !session_active).clicked() {
                                app.model.start(true);
                                app.page = Page::Device;
                            }
                        },
                    );
                    widgets::setting_row(
                        ui,
                        &p,
                        icons::PACKAGE,
                        "更新客户机工具",
                        &format!("将更新的 .itpack 安装到 {}，下次启动时生效", device.name),
                        |ui| {
                            if widgets::tonal_enabled(ui, &p, "选择", !session_active).clicked() {
                                if let Some(file) = rfd::FileDialog::new()
                                    .set_title("选择客户机工具")
                                    .add_filter("客户机工具", &["itpack"])
                                    .pick_file()
                                {
                                    app.model.update_guest_tools(&file);
                                }
                            }
                        },
                    );
                }
            });

            widgets::section(ui, &p, "关于");
            widgets::card(ui, &p, |ui| {
                widgets::setting_row(
                    ui,
                    &p,
                    icons::INFO,
                    &format!("LightTouch {}", env!("CARGO_PKG_VERSION")),
                    "自由软件，GNU GPL 第 2 版或更高版本",
                    |ui| {
                        if widgets::tonal(ui, &p, "源代码").clicked() {
                            open_path(std::path::Path::new("https://github.com/blake-lucas/LightTouch"));
                        }
                    },
                );
                widgets::setting_row(
                    ui,
                    &p,
                    icons::FILE,
                    "开源许可",
                    "LightTouch 包含的组件及其许可",
                    |ui| {
                        if widgets::tonal(ui, &p, "查看").clicked() {
                            app.page = Page::Licenses;
                        }
                    },
                );
            });
            ui.add_space(28.0);

            if toggle_recording {
                app.model.toggle_recording();
            }
            if app.model.settings != before {
                let muted_changed = app.model.settings.muted != before.muted;
                app.model.save_settings();
                if muted_changed {
                    let muted = app.model.settings.muted;
                    app.model.set_muted(muted);
                }
            }
        });
    });
}

/// Open a folder or link with the desktop's default handler.
pub fn open_path(path: &std::path::Path) {
    #[cfg(target_os = "linux")]
    let program = "xdg-open";
    #[cfg(target_os = "macos")]
    let program = "open";
    #[cfg(windows)]
    let program = "explorer";
    let _ = std::process::Command::new(program).arg(path).spawn();
}

//! Adding a device: a welcome on first run that leads into preparing one from an IPSW (prepare.rs), and "ready".
use super::{App, Page, icons, theme, widgets};
use eframe::egui::{self, RichText, Ui};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Step {
    Welcome,
    Done,
}

#[derive(Default)]
pub struct SetupState {
    pub added: Option<String>,
    /// (stage, seconds) of the preparation that made it, for "详情".
    pub timings: Vec<(String, f64)>,
}

fn centered(ui: &mut Ui, width: f32, add: impl FnOnce(&mut Ui)) {
    egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| {
        let w = (ui.available_width() - 48.0).clamp(200.0, width);
        let margin = ((ui.available_width() - w) / 2.0).max(24.0);
        egui::Frame::new()
            .inner_margin(egui::Margin { left: margin as i8, right: margin as i8, top: 36, bottom: 24 })
            .show(ui, |ui| {
                ui.set_max_width(w);
                add(ui);
            });
    });
}

pub fn show(app: &mut App, ui: &mut Ui, step: Step) {
    let p = app.palette;
    match step {
        Step::Welcome => centered(ui, 520.0, |ui| {
            ui.add_space(30.0);
            let (rect, _) = ui.allocate_exact_size(egui::vec2(64.0, 64.0), egui::Sense::hover());
            ui.painter().rect_filled(rect, egui::CornerRadius::same(18), p.primary);
            ui.painter().text(
                rect.center(),
                egui::Align2::CENTER_CENTER,
                icons::PHONE,
                egui::FontId::new(36.0, theme::icons_fill()),
                p.on_primary,
            );
            ui.add_space(16.0);
            ui.label(RichText::new("欢迎使用 LightTouch").font(theme::headline()));
            ui.add_space(6.0);
            ui.label(
                widgets::muted(&p, "在电脑上运行的经典 iPod touch 与 iPhone 软件。").size(15.0),
            );
            ui.add_space(22.0);
            ui.label(RichText::new("开始前需要一份 iOS 系统。LightTouch 会从 Apple 的存档下载并自动准备好，也可以使用你已有的 IPSW。"));
            ui.add_space(22.0);
            if widgets::primary(ui, &p, "开始使用").clicked() {
                super::prepare::open(app);
            }
        }),
        Step::Done => centered(ui, 520.0, |ui| {
            ui.add_space(40.0);
            ui.label(widgets::icon_text(icons::CHECK_CIRCLE, 54.0).color(p.primary));
            ui.add_space(10.0);
            let name = app.setup.added.clone().unwrap_or_else(|| "你的设备".into());
            ui.label(RichText::new(format!("{name} 已就绪")).font(theme::headline()));
            ui.add_space(6.0);
            ui.label(widgets::muted(&p, "首次启动时 iOS 需要自行初始化，会更久。"));
            if !app.setup.timings.is_empty() {
                ui.add_space(12.0);
                egui::CollapsingHeader::new(widgets::muted(&p, "详情")).id_salt("prepare-details").show(ui, |ui| {
                    ui.spacing_mut().interact_size.y = 20.0;
                    egui::Grid::new("timings").num_columns(2).spacing([28.0, 2.0]).show(ui, |ui| {
                        for (stage, secs) in &app.setup.timings {
                            ui.label(widgets::muted(&p, stage.as_str()));
                            ui.label(format!("{secs:.1} s"));
                            ui.end_row();
                        }
                    });
                });
            }
            ui.add_space(22.0);
            ui.horizontal(|ui| {
                let can_start = !app.model.session_active();
                if can_start && widgets::primary(ui, &p, "立即启动").clicked() {
                    app.model.start(false);
                    app.page = Page::Device;
                }
                if widgets::text_button(ui, &p, "稍后").clicked() {
                    app.page = Page::Device;
                }
            });
        }),
    }
}

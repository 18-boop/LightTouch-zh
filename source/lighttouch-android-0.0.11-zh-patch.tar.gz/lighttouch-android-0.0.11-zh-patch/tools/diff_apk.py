import zipfile, hashlib

OLD = r'E:\AI_Workspace\LightTouch-3e0484d-arm64-debug.apk'
NEW = r'E:\AI_Workspace\LightTouch_CN\out\LightTouch-zh-debug-aligned-debugSigned.apk'

zo, zn = zipfile.ZipFile(OLD), zipfile.ZipFile(NEW)
old = {i.filename: hashlib.sha256(zo.read(i.filename)).hexdigest() for i in zo.infolist()}
new = {i.filename: hashlib.sha256(zn.read(i.filename)).hexdigest() for i in zn.infolist()}

same = [n for n in old if n in new and old[n] == new[n]]
diff = [n for n in old if n in new and old[n] != new[n]]
only_old = [n for n in old if n not in new]
only_new = [n for n in new if n not in old]

print('identical entries:', len(same))
print('changed entries:', len(diff))
for n in diff:
    print('   CHANGED', n)
print('only in original:', only_old)
print('only in new:', only_new)

# native libs / assets specifically
for grp in ('lib/', 'assets/'):
    changed = [n for n in diff if n.startswith(grp)]
    print(f'{grp} changed: {len(changed)}')

import zipfile, struct, json, sys

NEW = r'E:\AI_Workspace\LightTouch_CN\out\LightTouch-zh-debug-aligned-debugSigned.apk'
OLD = r'E:\AI_Workspace\LightTouch-3e0484d-arm64-debug.apk'
TRANS = json.load(open(r'E:\AI_Workspace\LightTouch_CN\trans.json', encoding='utf-8'))

def uleb(data, i):
    r = 0; s = 0
    while True:
        x = data[i]; i += 1
        r |= (x & 0x7f) << s
        if not (x & 0x80): return r, i
        s += 7

def pool(data):
    n, off = struct.unpack_from('<II', data, 0x38)
    fsz = struct.unpack_from('<I', data, 0x20)[0]
    assert fsz == len(data), f'dex size mismatch {fsz} != {len(data)}'
    out = []
    for k in range(n):
        so = struct.unpack_from('<I', data, off + 4 * k)[0]
        _, p = uleb(data, so)
        e = data.index(b'\x00', p)
        out.append(data[p:e].decode('utf-8', 'surrogateescape'))
    return out

for label, path in (('OLD', OLD), ('NEW', NEW)):
    z = zipfile.ZipFile(path)
    print(label, 'entries', len(z.namelist()))
    for name in ('classes.dex', 'classes2.dex', 'classes3.dex', 'classes4.dex'):
        try:
            s = pool(z.read(name))
            print(f'  {name}: {len(s)} strings, header OK')
        except KeyError:
            print(f'  {name}: MISSING')
    if label == 'NEW':
        new_all = set()
        for name in ('classes.dex', 'classes2.dex', 'classes3.dex', 'classes4.dex'):
            new_all |= set(pool(z.read(name)))
        present = [k for k in TRANS if k in new_all]
        vals = [v for v in TRANS.values()]
        missing_vals = [v for v in vals if v not in new_all]
        print('  english keys still present:', len(present))
        for k in present[:20]:
            print('    LEFT:', repr(k))
        print('  translated values present:', len(vals) - len(missing_vals), '/', len(vals))
        for v in missing_vals[:20]:
            print('    MISSING:', repr(v))

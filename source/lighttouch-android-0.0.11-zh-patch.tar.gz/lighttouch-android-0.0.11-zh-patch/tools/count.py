import os, re, json

BASE = r'E:\AI_Workspace\LightTouch_CN\dec_full'
CS = re.compile(r'^\s*const-string(?:/jumbo)?\s+(?:v\d+|p\d+)\s*,\s*"(.*)"\s*$')
CJK = re.compile(r'\\u([4-9a-f][0-9a-f]{3})')

n = 0
files = 0
for root in ('smali_classes2', 'smali_classes3'):
    for dp, _, fns in os.walk(os.path.join(BASE, root)):
        for fn in fns:
            if not fn.endswith('.smali'):
                continue
            hit = False
            for line in open(os.path.join(dp, fn), encoding='utf-8', errors='replace'):
                m = CS.match(line)
                if m and CJK.search(m.group(1)):
                    n += 1
                    hit = True
            if hit:
                files += 1
print('CJK const-string occurrences:', n, 'in files:', files)
t = json.load(open(r'E:\AI_Workspace\LightTouch_CN\trans.json', encoding='utf-8'))
print('table entries:', len(t))
print('values with CJK:', sum(1 for v in t.values() if re.search(r'[\u4e00-\u9fff]', v)))

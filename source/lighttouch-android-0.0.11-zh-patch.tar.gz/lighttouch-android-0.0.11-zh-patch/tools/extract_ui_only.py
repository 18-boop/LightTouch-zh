import os, re, json, collections

BASE = r'E:\AI_Workspace\LightTouch_CN\dec_full'
ROOTS = [os.path.join(BASE, 'smali_classes2', 'org', 'lighttouch'),
         os.path.join(BASE, 'smali_classes3', 'org', 'lighttouch')]
OUT = r'E:\AI_Workspace\LightTouch_CN'

CS = re.compile(r'^\s*const-string(?:/jumbo)?\s+(?:v\d+|p\d+)\s*,\s*"(.*)"\s*$')
ESC = {'n': '\n', 't': '\t', 'r': '\r', '"': '"', "'": "'", '\\': '\\', 'b': '\b', 'f': '\f'}

def unescape(s):
    out = []; i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            n = s[i+1]
            if n in ESC: out.append(ESC[n]); i += 2; continue
            if n == 'u' and len(s) >= i+6: out.append(chr(int(s[i+2:i+6], 16))); i += 6; continue
            out.append(n); i += 2; continue
        out.append(c); i += 1
    return ''.join(out)

# UI-layer file names (Compose screens / components)
UI_FILE = re.compile(r'(ComposableSingletons\$|Kt\.smali$|Kt\$)')

SKIP_TEXT = [
    re.compile(r'^(C{1,2}P?\()'), re.compile(r'^\*?\d+@\d+'), re.compile(r'kt#'), re.compile(r'\.kt:\d'),
    re.compile(r'ComposableSingletons'), re.compile(r'lambda\$'),
    re.compile(r'^(iPhone|iPad|iPod|AppleTV)\d*,\d+$'),
    re.compile(r'^<set-\?>$'), re.compile(r'^\w+\(\.\.\.\)$'),
    re.compile(r'^, |=$'), re.compile(r'^[\w./$:;\[\]<>%#*+=|~^-]+$'),
    re.compile(r'^(L[\w/$]+;|\[)'), re.compile(r'^(android|androidx|java|kotlin|kotlinx)\.'),
    re.compile(r'https?://'), re.compile(r'^res/|^assets/|\.(png|jpg|xml|json|so|dylib|ttf|itpack)$'),
    re.compile(r'^org\.lighttouch'), re.compile(r'[\u4e00-\u9fff]'),
    re.compile(r'^(%[-+ 0-9.]*[dsfxeg])+$'),          # bare format strings
]

def looks_text(s):
    if not s or len(s) < 2 or len(s) > 400: return False
    if '\n' in s or '\t' in s: return False
    if not re.search(r'[A-Za-z]', s): return False
    for p in SKIP_TEXT:
        if p.search(s): return False
    return True

occ = collections.Counter()
files_of = collections.defaultdict(set)
allc = collections.Counter()
allf = collections.defaultdict(set)

for root in ROOTS:
    for dp, _, fns in os.walk(root):
        for fn in fns:
            if not fn.endswith('.smali'): continue
            p = os.path.join(dp, fn)
            isui = bool(UI_FILE.search(fn))
            seen = set()
            for line in open(p, encoding='utf-8', errors='replace'):
                m = CS.match(line)
                if not m: continue
                s = unescape(m.group(1))
                if not looks_text(s): continue
                allc[s] += 1; allf[s].add(fn)
                if isui:
                    occ[s] += 1; files_of[s].add(fn)
                break_flag = None

rows = sorted(occ.items(), key=lambda kv: (-kv[1], kv[0]))
json.dump({'occ': occ, 'files': {k: sorted(v) for k, v in files_of.items()}},
          open(os.path.join(OUT, 'ui_only.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
with open(os.path.join(OUT, 'ui_only.tsv'), 'w', encoding='utf-8') as fh:
    fh.write('string\tcount\tfiles\n')
    for s, c in rows:
        fh.write(f'{s}\t{c}\t{",".join(sorted(files_of[s])[:3])}\n')
print('UI-layer distinct:', len(rows), '| all distinct:', len(allc))

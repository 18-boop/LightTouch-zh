import os, re, json, sys

BASE = r'E:\AI_Workspace\LightTouch_CN\dec_full'
ROOTS = [os.path.join(BASE, 'smali_classes2', 'org', 'lighttouch'),
         os.path.join(BASE, 'smali_classes3', 'org', 'lighttouch')]
TRANS = json.load(open(r'E:\AI_Workspace\LightTouch_CN\trans.json', encoding='utf-8'))

CS = re.compile(r'^(\s*const-string(?:/jumbo)?\s+(?:v\d+|p\d+)\s*,\s*")(.*)("\s*)$')
ESC = {'n': '\n', 't': '\t', 'r': '\r', '"': '"', "'": "'", '\\': '\\', 'b': '\b', 'f': '\f'}

def unesc(s):
    out = []; i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            n = s[i+1]
            if n in ESC: out.append(ESC[n]); i += 2; continue
            if n == 'u' and len(s) >= i + 6: out.append(chr(int(s[i+2:i+6], 16))); i += 6; continue
            out.append(n); i += 2; continue
        out.append(c); i += 1
    return ''.join(out)

def esc(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif ch == '\n': out.append('\\n')
        elif ch == '\t': out.append('\\t')
        elif ch == '\r': out.append('\\r')
        elif 0x20 <= o < 0x7f: out.append(ch)
        elif o <= 0xffff: out.append('\\u%04x' % o)
        else:
            o -= 0x10000
            out.append('\\u%04x\\u%04x' % (0xd800 + (o >> 10), 0xdc00 + (o & 0x3ff)))
    return ''.join(out)

hits = {k: 0 for k in TRANS}
files_changed = 0
occ = 0

for root in ROOTS:
    for dp, _, fns in os.walk(root):
        for fn in fns:
            if not fn.endswith('.smali'): continue
            p = os.path.join(dp, fn)
            raw = open(p, encoding='utf-8', errors='surrogateescape').read()
            lines = raw.split('\n')
            changed = False
            for i, line in enumerate(lines):
                m = CS.match(line)
                if not m: continue
                s = unesc(m.group(2))
                zh = TRANS.get(s)
                if zh is None: continue
                lines[i] = m.group(1) + esc(zh) + m.group(3)
                changed = True
                hits[s] += 1
                occ += 1
            if changed:
                open(p, 'w', encoding='utf-8', errors='surrogateescape').write('\n'.join(lines))
                files_changed += 1

print(f'files changed: {files_changed}, occurrences: {occ}, table: {len(TRANS)}')
missing = [k for k, v in hits.items() if v == 0]
if missing:
    print(f'NOT FOUND in smali ({len(missing)}):')
    for k in missing:
        print('  ' + repr(k))

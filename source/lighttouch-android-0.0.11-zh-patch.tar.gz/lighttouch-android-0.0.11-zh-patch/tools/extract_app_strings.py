import os, re, json, collections

BASE = r'E:\AI_Workspace\LightTouch_CN\dec_full'
ROOTS = [os.path.join(BASE, 'smali_classes2', 'org', 'lighttouch'),
         os.path.join(BASE, 'smali_classes3', 'org', 'lighttouch')]

CS = re.compile(r'^\s*const-string(?:/jumbo)?\s+(?:v\d+|p\d+)\s*,\s*"(.*)"\s*$')

def unescape(s):
    # smali string literal escapes
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == '\\' and i + 1 < len(s):
            n = s[i+1]
            mp = {'n': '\n', 't': '\t', 'r': '\r', '"': '"', "'": "'", '\\': '\\', 'b': '\b', 'f': '\f'}
            if n in mp:
                out.append(mp[n]); i += 2; continue
            if n == 'u':
                out.append(chr(int(s[i+2:i+6], 16))); i += 6; continue
            if n == 'U':
                out.append(chr(int(s[i+2:i+10], 16))); i += 10; continue
            out.append(n); i += 2; continue
        out.append(c); i += 1
    return ''.join(out)

LATIN = re.compile(r'[A-Za-z]')
CJK = re.compile(r'[\u4e00-\u9fff]')

def is_text(s):
    if not s or len(s) < 2: return False
    if '\n' in s: return False
    if CJK.search(s): return False
    if not LATIN.search(s): return False
    if len(s) > 300: return False
    if s.startswith(('http://', 'https://', 'content://', 'file://', 'android.', 'java.', 'kotlin.', 'L', 'assets/', 'res/', '/data', '/sdcard')):
        return False
    if re.match(r'^[\w./$:;\[\]<>%#*+=|~^-]+$', s):   # no spaces, pure token
        return False
    return True

occ = collections.Counter()
files_of = collections.defaultdict(set)
raw_of = {}
total = 0
for root in ROOTS:
    for dp, _, fns in os.walk(root):
        for fn in fns:
            if not fn.endswith('.smali'): continue
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, BASE)
            try:
                txt = open(p, encoding='utf-8', errors='replace').read().splitlines()
            except Exception:
                continue
            for line in txt:
                m = CS.match(line)
                if not m: continue
                total += 1
                s = unescape(m.group(1))
                if not is_text(s): continue
                occ[s] += 1
                files_of[s].add(rel)
                raw_of.setdefault(s, m.group(1))

print('const-string occurrences:', total)
print('distinct text-like:', len(occ))
json.dump({'occ': occ, 'files': {k: sorted(v) for k, v in files_of.items()}, 'raw': raw_of},
          open(os.path.join(r'E:\AI_Workspace\LightTouch_CN', 'app_strings.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=0)

with open(os.path.join(r'E:\AI_Workspace\LightTouch_CN', 'app_strings.tsv'), 'w', encoding='utf-8') as fh:
    fh.write('count\tfiles\tstring\n')
    for s, c in occ.most_common():
        fh.write(f'{c}\t{len(files_of[s])}\t{s}\n')
print('wrote app_strings.tsv')

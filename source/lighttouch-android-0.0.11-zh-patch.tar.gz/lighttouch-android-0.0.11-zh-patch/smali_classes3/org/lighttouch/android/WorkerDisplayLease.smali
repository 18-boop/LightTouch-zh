.class public final Lorg/lighttouch/android/WorkerDisplayLease;
.super Ljava/lang/Object;
.source "DisplayOwnership.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0004\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0007\u0008\u0001\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J \u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00012\u0006\u0010\u000b\u001a\u00020\u00062\u0008\u0008\u0002\u0010\u000c\u001a\u00020\u0006J\u000e\u0010\r\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0001J\u0016\u0010\u000e\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u00012\u0006\u0010\u000c\u001a\u00020\u0006J\u0006\u0010\u000f\u001a\u00020\tR\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"
    }
    d2 = {
        "Lorg/lighttouch/android/WorkerDisplayLease;",
        "",
        "<init>",
        "()V",
        "worker",
        "token",
        "",
        "ownerTicket",
        "bind",
        "",
        "identity",
        "value",
        "ticket",
        "forWorker",
        "forOwner",
        "clear",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private ownerTicket:J

.field private token:J

.field private worker:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/WorkerDisplayLease;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 84
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic bind$default(Lorg/lighttouch/android/WorkerDisplayLease;Ljava/lang/Object;JJILjava/lang/Object;)V
    .locals 6

    .line 88
    and-int/lit8 p6, p6, 0x4

    if-eqz p6, :cond_0

    const-wide/16 p4, 0x1

    :cond_0
    move-wide v4, p4

    move-object v0, p0

    move-object v1, p1

    move-wide v2, p2

    invoke-virtual/range {v0 .. v5}, Lorg/lighttouch/android/WorkerDisplayLease;->bind(Ljava/lang/Object;JJ)V

    return-void
.end method


# virtual methods
.method public final bind(Ljava/lang/Object;JJ)V
    .locals 3
    .param p1, "identity"    # Ljava/lang/Object;
    .param p2, "value"    # J
    .param p4, "ticket"    # J

    const-string v0, "identity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-lez v2, :cond_0

    cmp-long v0, p4, v0

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    iput-object p1, p0, Lorg/lighttouch/android/WorkerDisplayLease;->worker:Ljava/lang/Object;

    iput-wide p2, p0, Lorg/lighttouch/android/WorkerDisplayLease;->token:J

    iput-wide p4, p0, Lorg/lighttouch/android/WorkerDisplayLease;->ownerTicket:J

    return-void

    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u65ad\u8a00\u5931\u8d25\u3002"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final clear()V
    .locals 2

    .line 91
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/WorkerDisplayLease;->worker:Ljava/lang/Object;

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lorg/lighttouch/android/WorkerDisplayLease;->token:J

    iput-wide v0, p0, Lorg/lighttouch/android/WorkerDisplayLease;->ownerTicket:J

    return-void
.end method

.method public final forOwner(Ljava/lang/Object;J)J
    .locals 2
    .param p1, "identity"    # Ljava/lang/Object;
    .param p2, "ticket"    # J

    const-string v0, "identity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    iget-wide v0, p0, Lorg/lighttouch/android/WorkerDisplayLease;->ownerTicket:J

    cmp-long v0, v0, p2

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Lorg/lighttouch/android/WorkerDisplayLease;->forWorker(Ljava/lang/Object;)J

    move-result-wide v0

    goto :goto_0

    :cond_0
    const-wide/16 v0, 0x0

    :goto_0
    return-wide v0
.end method

.method public final forWorker(Ljava/lang/Object;)J
    .locals 2
    .param p1, "identity"    # Ljava/lang/Object;

    const-string v0, "identity"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    iget-object v0, p0, Lorg/lighttouch/android/WorkerDisplayLease;->worker:Ljava/lang/Object;

    if-ne v0, p1, :cond_0

    iget-wide v0, p0, Lorg/lighttouch/android/WorkerDisplayLease;->token:J

    goto :goto_0

    :cond_0
    const-wide/16 v0, 0x0

    :goto_0
    return-wide v0
.end method

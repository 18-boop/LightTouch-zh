.class public final Lorg/lighttouch/android/HitchData$Companion;
.super Ljava/lang/Object;
.source "HitchData.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/lighttouch/android/HitchData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHitchData.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HitchData.kt\norg/lighttouch/android/HitchData$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,198:1\n774#2:199\n865#2,2:200\n1617#2,9:202\n1869#2:211\n1563#2:213\n1634#2,3:214\n1870#2:218\n1626#2:219\n774#2:220\n865#2,2:221\n1573#2:223\n1604#2,4:224\n1011#2,2:228\n1#3:212\n1#3:217\n*S KotlinDebug\n*F\n+ 1 HitchData.kt\norg/lighttouch/android/HitchData$Companion\n*L\n51#1:199\n51#1:200,2\n51#1:202,9\n51#1:211\n52#1:213\n52#1:214,3\n51#1:218\n51#1:219\n53#1:220\n53#1:221,2\n54#1:223\n54#1:224,4\n106#1:228,2\n51#1:217\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tJ4\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00052\u000c\u0010\u000f\u001a\u0008\u0012\u0004\u0012\u00020\u00110\u00102\u000c\u0010\u0012\u001a\u0008\u0012\u0004\u0012\u00020\u00130\u0010H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"
    }
    d2 = {
        "Lorg/lighttouch/android/HitchData$Companion;",
        "",
        "<init>",
        "()V",
        "WINDOW_NS",
        "",
        "load",
        "Lorg/lighttouch/android/HitchData;",
        "snapshot",
        "Landroid/os/Bundle;",
        "readEvents",
        "",
        "file",
        "Ljava/io/File;",
        "from",
        "breakdown",
        "",
        "Lorg/lighttouch/android/FrameBreakdown;",
        "events",
        "Lorg/lighttouch/android/SlowEvent;",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0}, Lorg/lighttouch/android/HitchData$Companion;-><init>()V

    return-void
.end method

.method private final readEvents(Ljava/io/File;JLjava/util/List;Ljava/util/List;)V
    .locals 37
    .param p1, "file"    # Ljava/io/File;
    .param p2, "from"    # J
    .param p4, "breakdown"    # Ljava/util/List;
    .param p5, "events"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "J",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/FrameBreakdown;",
            ">;",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/SlowEvent;",
            ">;)V"
        }
    .end annotation

    .line 67
    move-object/from16 v1, p5

    invoke-virtual/range {p1 .. p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 68
    :cond_0
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    move-object v2, v0

    .line 69
    .local v2, "names":Ljava/util/HashMap;
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v3, v0

    .line 70
    .local v3, "pendingGl":Ljava/util/ArrayList;
    const/4 v4, 0x0

    .line 71
    .local v4, "previous":Ljava/lang/Object;
    new-instance v0, Ljava/io/FileInputStream;

    move-object/from16 v5, p1

    invoke-direct {v0, v5}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    move-object v6, v0

    check-cast v6, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v6

    check-cast v0, Ljava/io/FileInputStream;

    .local v0, "stream\\1":Ljava/io/FileInputStream;
    const/4 v7, 0x0

    .line 72
    .local v7, "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    invoke-virtual {v5}, Ljava/io/File;->length()J

    move-result-wide v8

    const-wide/32 v10, 0x1800000

    sub-long/2addr v8, v10

    const-wide/16 v10, 0x0

    invoke-static {v10, v11, v8, v9}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v8

    .line 73
    .local v8, "start\\1":J
    invoke-virtual {v0}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v12

    invoke-virtual {v12, v8, v9}, Ljava/nio/channels/FileChannel;->position(J)Ljava/nio/channels/FileChannel;

    new-instance v12, Ljava/io/InputStreamReader;

    .line 74
    move-object v13, v0

    check-cast v13, Ljava/io/InputStream;

    sget-object v14, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v12, v13, v14}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v12, Ljava/io/Reader;

    instance-of v13, v12, Ljava/io/BufferedReader;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    if-eqz v13, :cond_1

    :try_start_1
    check-cast v12, Ljava/io/BufferedReader;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    .line 71
    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .end local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .end local v8    # "start\\1":J
    :catchall_0
    move-exception v0

    move-object/from16 v5, p4

    move-object v15, v4

    move-object/from16 v27, v6

    move-object v4, v0

    goto/16 :goto_19

    .line 74
    .restart local v0    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .restart local v8    # "start\\1":J
    :cond_1
    :try_start_2
    new-instance v13, Ljava/io/BufferedReader;

    const/high16 v14, 0x10000

    invoke-direct {v13, v12, v14}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_6

    move-object v12, v13

    .line 75
    .local v12, "input\\1":Ljava/io/BufferedReader;
    :goto_0
    cmp-long v10, v8, v10

    if-lez v10, :cond_2

    :try_start_3
    invoke-virtual {v12}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 76
    :cond_2
    :goto_1
    nop

    .line 77
    :try_start_4
    invoke-virtual {v12}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v10
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    const/4 v11, 0x0

    const/4 v13, 0x1

    if-nez v10, :cond_6

    .line 104
    nop

    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .end local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .end local v8    # "start\\1":J
    .end local v12    # "input\\1":Ljava/io/BufferedReader;
    :try_start_5
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 71
    invoke-static {v6, v11}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 105
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-string v6, "iterator(...)"

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const-string v7, "next(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Lkotlin/Triple;

    invoke-virtual {v6}, Lkotlin/Triple;->component1()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->longValue()J

    move-result-wide v15

    .local v15, "s":J
    invoke-virtual {v6}, Lkotlin/Triple;->component2()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->longValue()J

    move-result-wide v17

    .local v17, "e":J
    invoke-virtual {v6}, Lkotlin/Triple;->component3()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    .local v6, "slot":I
    new-instance v14, Lorg/lighttouch/android/SlowEvent;

    sget-object v19, Lorg/lighttouch/android/EventKind;->GL:Lorg/lighttouch/android/EventKind;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    if-nez v7, :cond_3

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "GL call "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :cond_3
    move-object/from16 v20, v7

    invoke-direct/range {v14 .. v20}, Lorg/lighttouch/android/SlowEvent;-><init>(JJLorg/lighttouch/android/EventKind;Ljava/lang/String;)V

    invoke-interface {v1, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 106
    .end local v6    # "slot":I
    .end local v15    # "s":J
    .end local v17    # "e":J
    :cond_4
    move-object/from16 v0, p5

    .local v0, "$this$sortBy\\11":Ljava/util/List;
    const/4 v6, 0x0

    .line 228
    .local v6, "$i$f$sortBy\\11\\106":I
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v7

    if-le v7, v13, :cond_5

    new-instance v7, Lorg/lighttouch/android/HitchData$Companion$readEvents$$inlined$sortBy$1;

    invoke-direct {v7}, Lorg/lighttouch/android/HitchData$Companion$readEvents$$inlined$sortBy$1;-><init>()V

    check-cast v7, Ljava/util/Comparator;

    invoke-static {v0, v7}, Lkotlin/collections/CollectionsKt;->sortWith(Ljava/util/List;Ljava/util/Comparator;)V

    .line 229
    :cond_5
    nop

    .line 107
    .end local v0    # "$this$sortBy\\11":Ljava/util/List;
    .end local v6    # "$i$f$sortBy\\11\\106":I
    return-void

    .line 78
    .local v0, "stream\\1":Ljava/io/FileInputStream;
    .restart local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .restart local v8    # "start\\1":J
    .local v10, "line\\1":Ljava/lang/String;
    .restart local v12    # "input\\1":Ljava/io/BufferedReader;
    :cond_6
    :try_start_6
    move-object v14, v10

    check-cast v14, Ljava/lang/CharSequence;

    invoke-static {v14}, Lkotlin/text/StringsKt;->firstOrNull(Ljava/lang/CharSequence;)Ljava/lang/Character;

    move-result-object v14

    .line 79
    if-nez v14, :cond_7

    move-object/from16 v5, p4

    move-object v15, v4

    move-object/from16 v27, v6

    goto/16 :goto_4

    :cond_7
    invoke-virtual {v14}, Ljava/lang/Character;->charValue()C

    move-result v15

    const/16 v11, 0x46

    if-ne v15, v11, :cond_a

    sget-object v11, Lorg/lighttouch/android/ProfileTail;->Companion:Lorg/lighttouch/android/ProfileTail$Companion;

    invoke-virtual {v11, v10}, Lorg/lighttouch/android/ProfileTail$Companion;->parse(Ljava/lang/String;)Lorg/lighttouch/android/ProfileTail$Frame;

    move-result-object v11

    if-eqz v11, :cond_9

    .local v11, "f\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    const/4 v13, 0x0

    .line 80
    .local v13, "$i$a$-let-HitchData$Companion$readEvents$1$1\\2\\79\\1":I
    move-object v14, v4

    .line 81
    .local v14, "p\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    if-eqz v14, :cond_8

    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getNs()J

    move-result-wide v15

    cmp-long v15, v15, p2

    if-ltz v15, :cond_8

    new-instance v16, Lorg/lighttouch/android/FrameBreakdown;

    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getNs()J

    move-result-wide v17

    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getNs()J

    move-result-wide v19

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getNs()J

    move-result-wide v21
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    move-object v15, v4

    .end local v4    # "previous":Ljava/lang/Object;
    .local v15, "previous":Ljava/lang/Object;
    sub-long v4, v19, v21

    long-to-float v4, v4

    const v5, 0x49742400    # 1000000.0f

    div-float v19, v4, v5

    .line 82
    :try_start_7
    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getRun()J

    move-result-wide v20

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getRun()J

    move-result-wide v22
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    move v4, v5

    move-object/from16 v27, v6

    sub-long v5, v20, v22

    long-to-float v5, v5

    div-float v20, v5, v4

    :try_start_8
    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getOutside()J

    move-result-wide v5

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getOutside()J

    move-result-wide v21

    sub-long v5, v5, v21

    long-to-float v5, v5

    div-float v21, v5, v4

    .line 83
    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getBqlInside()J

    move-result-wide v5

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getBqlInside()J

    move-result-wide v22

    sub-long v5, v5, v22

    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getBqlOutside()J

    move-result-wide v22

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getBqlOutside()J

    move-result-wide v24

    sub-long v22, v22, v24

    add-long v5, v5, v22

    long-to-float v5, v5

    div-float v22, v5, v4

    .line 84
    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getVcpuCpu()J

    move-result-wide v5

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getVcpuCpu()J

    move-result-wide v23

    sub-long v5, v5, v23

    long-to-float v5, v5

    div-float v23, v5, v4

    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getGl()J

    move-result-wide v5

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getGl()J

    move-result-wide v24

    sub-long v5, v5, v24

    long-to-float v5, v5

    div-float v24, v5, v4

    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getGlPresent()J

    move-result-wide v5

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getGlPresent()J

    move-result-wide v25

    sub-long v5, v5, v25

    long-to-float v5, v5

    div-float v25, v5, v4

    .line 85
    invoke-virtual {v11}, Lorg/lighttouch/android/ProfileTail$Frame;->getMainCpu()J

    move-result-wide v5

    invoke-virtual {v14}, Lorg/lighttouch/android/ProfileTail$Frame;->getMainCpu()J

    move-result-wide v28

    sub-long v5, v5, v28

    long-to-float v5, v5

    div-float v26, v5, v4

    .line 81
    invoke-direct/range {v16 .. v26}, Lorg/lighttouch/android/FrameBreakdown;-><init>(JFFFFFFFF)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    move-object/from16 v4, v16

    move-object/from16 v5, p4

    :try_start_9
    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3

    .line 71
    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .end local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .end local v8    # "start\\1":J
    .end local v10    # "line\\1":Ljava/lang/String;
    .end local v11    # "f\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    .end local v12    # "input\\1":Ljava/io/BufferedReader;
    .end local v13    # "$i$a$-let-HitchData$Companion$readEvents$1$1\\2\\79\\1":I
    .end local v14    # "p\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    :catchall_1
    move-exception v0

    move-object/from16 v5, p4

    move-object v4, v0

    goto/16 :goto_19

    :catchall_2
    move-exception v0

    move-object/from16 v5, p4

    move-object/from16 v27, v6

    move-object v4, v0

    goto/16 :goto_19

    .line 81
    .end local v15    # "previous":Ljava/lang/Object;
    .restart local v0    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v4    # "previous":Ljava/lang/Object;
    .restart local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .restart local v8    # "start\\1":J
    .restart local v10    # "line\\1":Ljava/lang/String;
    .restart local v11    # "f\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    .restart local v12    # "input\\1":Ljava/io/BufferedReader;
    .restart local v13    # "$i$a$-let-HitchData$Companion$readEvents$1$1\\2\\79\\1":I
    .restart local v14    # "p\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    :cond_8
    move-object/from16 v5, p4

    move-object v15, v4

    move-object/from16 v27, v6

    .line 86
    .end local v4    # "previous":Ljava/lang/Object;
    .restart local v15    # "previous":Ljava/lang/Object;
    :goto_3
    move-object v4, v11

    .line 87
    .end local v15    # "previous":Ljava/lang/Object;
    .restart local v4    # "previous":Ljava/lang/Object;
    nop

    .line 79
    .end local v11    # "f\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    .end local v13    # "$i$a$-let-HitchData$Companion$readEvents$1$1\\2\\79\\1":I
    .end local v14    # "p\\2":Lorg/lighttouch/android/ProfileTail$Frame;
    move-object/from16 v5, p1

    move-object/from16 v6, v27

    goto/16 :goto_1

    :cond_9
    move-object/from16 v5, p4

    move-object v15, v4

    move-object/from16 v27, v6

    .end local v4    # "previous":Ljava/lang/Object;
    .restart local v15    # "previous":Ljava/lang/Object;
    move-object/from16 v22, v0

    goto/16 :goto_18

    .end local v15    # "previous":Ljava/lang/Object;
    .restart local v4    # "previous":Ljava/lang/Object;
    :cond_a
    move-object/from16 v5, p4

    move-object v15, v4

    move-object/from16 v27, v6

    .line 88
    .end local v4    # "previous":Ljava/lang/Object;
    .restart local v15    # "previous":Ljava/lang/Object;
    :goto_4
    if-nez v14, :cond_b

    move-object/from16 v22, v0

    const/16 v18, 0x20

    const/16 v19, 0x0

    goto/16 :goto_8

    :cond_b
    const/16 v18, 0x20

    invoke-virtual {v14}, Ljava/lang/Character;->charValue()C

    move-result v11

    const/16 v19, 0x0

    const/16 v4, 0x47

    if-ne v11, v4, :cond_10

    move-object/from16 v20, v10

    check-cast v20, Ljava/lang/CharSequence;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    :try_start_a
    new-array v4, v13, [C

    aput-char v18, v4, v19
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    const/16 v24, 0x6

    const/16 v25, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v21, v4

    :try_start_b
    invoke-static/range {v20 .. v25}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v4

    move-object v11, v4

    .line 212
    .local v11, "it\\3":Ljava/util/List;
    const/4 v14, 0x0

    .line 88
    .local v14, "$i$a$-takeIf-HitchData$Companion$readEvents$1$2\\3\\88\\1":I
    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v13

    const/4 v6, 0x7

    if-lt v13, v6, :cond_c

    const/4 v13, 0x1

    goto :goto_5

    :cond_c
    move/from16 v13, v19

    .end local v11    # "it\\3":Ljava/util/List;
    .end local v14    # "$i$a$-takeIf-HitchData$Companion$readEvents$1$2\\3\\88\\1":I
    :goto_5
    if-eqz v13, :cond_d

    move-object v11, v4

    goto :goto_6

    :cond_d
    const/4 v11, 0x0

    :goto_6
    if-eqz v11, :cond_f

    .line 212
    .local v11, "it\\4":Ljava/util/List;
    const/4 v4, 0x0

    .line 88
    .local v4, "$i$a$-let-HitchData$Companion$readEvents$1$3\\4\\88\\1":I
    move-object v6, v2

    check-cast v6, Ljava/util/Map;

    const/4 v13, 0x2

    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v13

    if-eqz v13, :cond_e

    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    move-result v13

    goto :goto_7

    :cond_e
    const/4 v13, -0x1

    :goto_7
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    move-object v14, v11

    check-cast v14, Ljava/lang/Iterable;

    move-object/from16 v22, v0

    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .local v22, "stream\\1":Ljava/io/FileInputStream;
    const/4 v0, 0x6

    invoke-static {v14, v0}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    move-object/from16 v28, v0

    check-cast v28, Ljava/lang/Iterable;

    const-string v0, " "

    move-object/from16 v29, v0

    check-cast v29, Ljava/lang/CharSequence;

    const/16 v35, 0x3e

    const/16 v36, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    invoke-static/range {v28 .. v36}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v6, v13, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .end local v4    # "$i$a$-let-HitchData$Companion$readEvents$1$3\\4\\88\\1":I
    .end local v11    # "it\\4":Ljava/util/List;
    goto/16 :goto_18

    .end local v22    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v0    # "stream\\1":Ljava/io/FileInputStream;
    :cond_f
    move-object/from16 v22, v0

    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v22    # "stream\\1":Ljava/io/FileInputStream;
    goto/16 :goto_18

    .line 71
    .end local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .end local v8    # "start\\1":J
    .end local v10    # "line\\1":Ljava/lang/String;
    .end local v12    # "input\\1":Ljava/io/BufferedReader;
    .end local v22    # "stream\\1":Ljava/io/FileInputStream;
    :catchall_3
    move-exception v0

    move-object v4, v0

    goto/16 :goto_19

    .line 88
    .restart local v0    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .restart local v8    # "start\\1":J
    .restart local v10    # "line\\1":Ljava/lang/String;
    .restart local v12    # "input\\1":Ljava/io/BufferedReader;
    :cond_10
    move-object/from16 v22, v0

    .line 89
    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v22    # "stream\\1":Ljava/io/FileInputStream;
    :goto_8
    const/4 v0, 0x3

    const/4 v4, 0x4

    if-nez v14, :cond_12

    :cond_11
    goto/16 :goto_c

    :cond_12
    invoke-virtual {v14}, Ljava/lang/Character;->charValue()C

    move-result v6

    const/16 v11, 0x53

    if-ne v6, v11, :cond_11

    move-object/from16 v28, v10

    check-cast v28, Ljava/lang/CharSequence;
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    const/4 v6, 0x1

    :try_start_c
    new-array v11, v6, [C

    aput-char v18, v11, v19
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    const/16 v32, 0x6

    const/16 v33, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    move-object/from16 v29, v11

    :try_start_d
    invoke-static/range {v28 .. v33}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v6

    move-object v11, v6

    .line 212
    .local v11, "it\\5":Ljava/util/List;
    const/4 v13, 0x0

    .line 89
    .local v13, "$i$a$-takeIf-HitchData$Companion$readEvents$1$4\\5\\89\\1":I
    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v14

    if-lt v14, v4, :cond_13

    const/4 v4, 0x1

    goto :goto_9

    :cond_13
    move/from16 v4, v19

    .end local v11    # "it\\5":Ljava/util/List;
    .end local v13    # "$i$a$-takeIf-HitchData$Companion$readEvents$1$4\\5\\89\\1":I
    :goto_9
    if-eqz v4, :cond_14

    move-object v11, v6

    goto :goto_a

    :cond_14
    const/4 v11, 0x0

    :goto_a
    if-eqz v11, :cond_17

    .local v11, "v\\6":Ljava/util/List;
    const/4 v4, 0x0

    .line 90
    .local v4, "$i$a$-let-HitchData$Companion$readEvents$1$5\\6\\89\\1":I
    const/4 v6, 0x1

    invoke-interface {v11, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    const/4 v13, 0x2

    .local v6, "s\\6":Ljava/lang/Long;
    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v13

    .line 91
    .local v13, "e\\6":Ljava/lang/Long;
    if-eqz v6, :cond_16

    if-eqz v13, :cond_16

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v18

    cmp-long v14, v18, p2

    if-ltz v14, :cond_16

    new-instance v14, Lkotlin/Triple;

    invoke-interface {v11, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-static {v0}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_b

    :cond_15
    const/4 v0, -0x1

    :goto_b
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-direct {v14, v6, v13, v0}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v3, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 92
    :cond_16
    nop

    .line 89
    .end local v4    # "$i$a$-let-HitchData$Companion$readEvents$1$5\\6\\89\\1":I
    .end local v6    # "s\\6":Ljava/lang/Long;
    .end local v11    # "v\\6":Ljava/util/List;
    .end local v13    # "e\\6":Ljava/lang/Long;
    :cond_17
    goto/16 :goto_18

    .line 93
    :goto_c
    const/16 v6, 0x57

    if-nez v14, :cond_18

    :goto_d
    goto :goto_e

    :cond_18
    invoke-virtual {v14}, Ljava/lang/Character;->charValue()C

    move-result v11

    if-eq v11, v6, :cond_21

    goto :goto_d

    :goto_e
    if-nez v14, :cond_1a

    :cond_19
    goto :goto_f

    :cond_1a
    invoke-virtual {v14}, Ljava/lang/Character;->charValue()C

    move-result v11

    const/16 v13, 0x48

    if-ne v11, v13, :cond_19

    goto/16 :goto_13

    .line 98
    :goto_f
    if-nez v14, :cond_1c

    :cond_1b
    :goto_10
    goto/16 :goto_18

    :cond_1c
    invoke-virtual {v14}, Ljava/lang/Character;->charValue()C

    move-result v6

    const/16 v11, 0x43

    if-ne v6, v11, :cond_1b

    move-object/from16 v28, v10

    check-cast v28, Ljava/lang/CharSequence;
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    const/4 v6, 0x1

    :try_start_e
    new-array v11, v6, [C

    aput-char v18, v11, v19
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    const/16 v32, 0x6

    const/16 v33, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    move-object/from16 v29, v11

    :try_start_f
    invoke-static/range {v28 .. v33}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v6

    move-object v11, v6

    .line 212
    .local v11, "it\\9":Ljava/util/List;
    const/4 v13, 0x0

    .line 98
    .local v13, "$i$a$-takeIf-HitchData$Companion$readEvents$1$8\\9\\98\\1":I
    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v14

    if-lt v14, v4, :cond_1d

    const/4 v4, 0x1

    goto :goto_11

    :cond_1d
    move/from16 v4, v19

    .end local v11    # "it\\9":Ljava/util/List;
    .end local v13    # "$i$a$-takeIf-HitchData$Companion$readEvents$1$8\\9\\98\\1":I
    :goto_11
    if-eqz v4, :cond_1e

    move-object v11, v6

    goto :goto_12

    :cond_1e
    const/4 v11, 0x0

    :goto_12
    if-eqz v11, :cond_20

    .local v11, "v\\10":Ljava/util/List;
    const/4 v4, 0x0

    .line 99
    .local v4, "$i$a$-let-HitchData$Companion$readEvents$1$9\\10\\98\\1":I
    const/4 v6, 0x1

    invoke-interface {v11, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v6

    const/4 v13, 0x2

    .local v6, "s\\10":Ljava/lang/Long;
    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v13

    .line 100
    .local v13, "e\\10":Ljava/lang/Long;
    if-eqz v6, :cond_1f

    if-eqz v13, :cond_1f

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v16

    cmp-long v14, v16, p2

    if-ltz v14, :cond_1f

    new-instance v28, Lorg/lighttouch/android/SlowEvent;

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v29

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v31

    sget-object v33, Lorg/lighttouch/android/EventKind;->CALLBACK:Lorg/lighttouch/android/EventKind;

    invoke-interface {v11, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v34, v0

    check-cast v34, Ljava/lang/String;

    invoke-direct/range {v28 .. v34}, Lorg/lighttouch/android/SlowEvent;-><init>(JJLorg/lighttouch/android/EventKind;Ljava/lang/String;)V

    move-object/from16 v0, v28

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 101
    :cond_1f
    nop

    .end local v4    # "$i$a$-let-HitchData$Companion$readEvents$1$9\\10\\98\\1":I
    .end local v6    # "s\\10":Ljava/lang/Long;
    .end local v11    # "v\\10":Ljava/util/List;
    .end local v13    # "e\\10":Ljava/lang/Long;
    goto :goto_10

    .line 98
    .end local v10    # "line\\1":Ljava/lang/String;
    :cond_20
    goto/16 :goto_18

    .line 93
    .restart local v10    # "line\\1":Ljava/lang/String;
    :cond_21
    :goto_13
    move-object/from16 v28, v10

    check-cast v28, Ljava/lang/CharSequence;
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_4

    const/4 v11, 0x1

    :try_start_10
    new-array v13, v11, [C

    aput-char v18, v13, v19
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_3

    const/16 v32, 0x6

    const/16 v33, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    move-object/from16 v29, v13

    :try_start_11
    invoke-static/range {v28 .. v33}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v11

    move-object v13, v11

    .line 212
    .local v13, "it\\7":Ljava/util/List;
    const/4 v14, 0x0

    .line 93
    .local v14, "$i$a$-takeIf-HitchData$Companion$readEvents$1$6\\7\\93\\1":I
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v4

    const/4 v0, 0x5

    if-lt v4, v0, :cond_22

    const/4 v0, 0x1

    goto :goto_14

    :cond_22
    move/from16 v0, v19

    .end local v13    # "it\\7":Ljava/util/List;
    .end local v14    # "$i$a$-takeIf-HitchData$Companion$readEvents$1$6\\7\\93\\1":I
    :goto_14
    if-eqz v0, :cond_23

    goto :goto_15

    :cond_23
    const/4 v11, 0x0

    :goto_15
    if-eqz v11, :cond_26

    .local v11, "v\\8":Ljava/util/List;
    const/4 v0, 0x0

    .line 94
    .local v0, "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    const/4 v4, 0x1

    invoke-interface {v11, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v4

    const/4 v13, 0x2

    .local v4, "s\\8":Ljava/lang/Long;
    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v13

    .line 95
    .local v13, "e\\8":Ljava/lang/Long;
    if-eqz v4, :cond_25

    if-eqz v13, :cond_25

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v20

    cmp-long v14, v20, p2

    if-ltz v14, :cond_25

    .line 96
    new-instance v28, Lorg/lighttouch/android/SlowEvent;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v29

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v31

    move/from16 v14, v19

    invoke-virtual {v10, v14}, Ljava/lang/String;->charAt(I)C

    move-result v14

    if-ne v14, v6, :cond_24

    sget-object v6, Lorg/lighttouch/android/EventKind;->WAIT:Lorg/lighttouch/android/EventKind;

    goto :goto_16

    :cond_24
    sget-object v6, Lorg/lighttouch/android/EventKind;->HOLD:Lorg/lighttouch/android/EventKind;

    :goto_16
    move-object/from16 v33, v6

    new-instance v6, Ljava/io/File;

    const/4 v14, 0x3

    invoke-interface {v11, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-direct {v6, v14}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x4

    invoke-interface {v11, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    move/from16 v16, v0

    .end local v0    # "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    .local v16, "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v6, ":"

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v34

    invoke-direct/range {v28 .. v34}, Lorg/lighttouch/android/SlowEvent;-><init>(JJLorg/lighttouch/android/EventKind;Ljava/lang/String;)V

    move-object/from16 v0, v28

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_4

    goto :goto_17

    .line 95
    .end local v16    # "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    .restart local v0    # "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    :cond_25
    move/from16 v16, v0

    .line 97
    .end local v0    # "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    .restart local v16    # "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    :goto_17
    nop

    .line 93
    .end local v4    # "s\\8":Ljava/lang/Long;
    .end local v11    # "v\\8":Ljava/util/List;
    .end local v13    # "e\\8":Ljava/lang/Long;
    .end local v16    # "$i$a$-let-HitchData$Companion$readEvents$1$7\\8\\93\\1":I
    :cond_26
    nop

    .line 76
    .end local v10    # "line\\1":Ljava/lang/String;
    .end local v22    # "stream\\1":Ljava/io/FileInputStream;
    .local v0, "stream\\1":Ljava/io/FileInputStream;
    :goto_18
    move-object/from16 v5, p1

    move-object v4, v15

    move-object/from16 v0, v22

    move-object/from16 v6, v27

    .end local v0    # "stream\\1":Ljava/io/FileInputStream;
    .restart local v22    # "stream\\1":Ljava/io/FileInputStream;
    goto/16 :goto_1

    .line 71
    .end local v7    # "$i$a$-use-HitchData$Companion$readEvents$1\\1\\71\\0":I
    .end local v8    # "start\\1":J
    .end local v12    # "input\\1":Ljava/io/BufferedReader;
    .end local v22    # "stream\\1":Ljava/io/FileInputStream;
    :catchall_4
    move-exception v0

    move-object v4, v0

    goto :goto_19

    .end local v15    # "previous":Ljava/lang/Object;
    .local v4, "previous":Ljava/lang/Object;
    :catchall_5
    move-exception v0

    move-object/from16 v5, p4

    move-object v15, v4

    move-object/from16 v27, v6

    move-object v4, v0

    .end local v4    # "previous":Ljava/lang/Object;
    .restart local v15    # "previous":Ljava/lang/Object;
    goto :goto_19

    .end local v15    # "previous":Ljava/lang/Object;
    .restart local v4    # "previous":Ljava/lang/Object;
    :catchall_6
    move-exception v0

    move-object/from16 v5, p4

    move-object/from16 v27, v6

    move-object v15, v4

    move-object v4, v0

    .end local v2    # "names":Ljava/util/HashMap;
    .end local v3    # "pendingGl":Ljava/util/ArrayList;
    .end local v4    # "previous":Ljava/lang/Object;
    .end local p0    # "this":Lorg/lighttouch/android/HitchData$Companion;
    .end local p1    # "file":Ljava/io/File;
    .end local p2    # "from":J
    .end local p4    # "breakdown":Ljava/util/List;
    .end local p5    # "events":Ljava/util/List;
    :goto_19
    :try_start_12
    throw v4
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_7

    .restart local v2    # "names":Ljava/util/HashMap;
    .restart local v3    # "pendingGl":Ljava/util/ArrayList;
    .restart local v15    # "previous":Ljava/lang/Object;
    .restart local p0    # "this":Lorg/lighttouch/android/HitchData$Companion;
    .restart local p1    # "file":Ljava/io/File;
    .restart local p2    # "from":J
    .restart local p4    # "breakdown":Ljava/util/List;
    .restart local p5    # "events":Ljava/util/List;
    :catchall_7
    move-exception v0

    move-object/from16 v6, v27

    invoke-static {v6, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method


# virtual methods
.method public final load(Landroid/os/Bundle;)Lorg/lighttouch/android/HitchData;
    .locals 40
    .param p1, "snapshot"    # Landroid/os/Bundle;

    move-object/from16 v0, p1

    const-string v1, "snapshot"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    new-instance v1, Ljava/io/File;

    const-string v2, "directory"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_13

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v4, v1

    .line 50
    .local v4, "directory":Ljava/io/File;
    const-string v1, "snapshotNs"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v8

    .line 51
    .local v8, "snapshotNs":J
    new-instance v1, Ljava/io/File;

    const-string v2, "frames.tsv"

    invoke-direct {v1, v4, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1, v2, v3, v2}, Lkotlin/io/FilesKt;->readLines$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 199
    .local v5, "$i$f$filter\\2\\51":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\3":Ljava/util/Collection;
    move-object v7, v1

    .local v7, "$this$filterTo\\3":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 200
    .local v10, "$i$f$filterTo\\3\\199":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    const/4 v13, 0x2

    const/4 v14, 0x0

    if-eqz v12, :cond_2

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\3":Ljava/lang/Object;
    move-object v15, v12

    check-cast v15, Ljava/lang/String;

    .local v15, "it\\4":Ljava/lang/String;
    const/16 v16, 0x0

    .line 51
    .local v16, "$i$a$-filter-HitchData$Companion$load$raw$1\\4\\200\\0":I
    const-string v3, "#"

    invoke-static {v15, v3, v14, v13, v2}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    move-object v3, v15

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {v3}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_0

    const/4 v14, 0x1

    .line 200
    .end local v15    # "it\\4":Ljava/lang/String;
    .end local v16    # "$i$a$-filter-HitchData$Companion$load$raw$1\\4\\200\\0":I
    :cond_0
    if-eqz v14, :cond_1

    invoke-interface {v6, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v3, 0x1

    goto :goto_0

    .line 201
    .end local v12    # "element\\3":Ljava/lang/Object;
    :cond_2
    nop

    .end local v6    # "destination\\3":Ljava/util/Collection;
    .end local v7    # "$this$filterTo\\3":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\3\\199":I
    move-object v3, v6

    check-cast v3, Ljava/util/List;

    .line 199
    nop

    .end local v1    # "$this$filter\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\2\\51":I
    check-cast v3, Ljava/lang/Iterable;

    .line 51
    nop

    .local v3, "$this$mapNotNull\\5":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 202
    .local v1, "$i$f$mapNotNull\\5\\51":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\6":Ljava/util/Collection;
    move-object v6, v3

    .local v6, "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 210
    .local v7, "$i$f$mapNotNullTo\\6\\202":I
    move-object v10, v6

    .local v10, "$this$forEach\\7":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 211
    .local v11, "$i$f$forEach\\7\\210":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_1
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_8

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .local v15, "element\\7":Ljava/lang/Object;
    move-object/from16 v18, v15

    .local v18, "element\\8":Ljava/lang/Object;
    const/16 v19, 0x0

    .line 210
    .local v19, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\211\\6":I
    move-object/from16 v20, v18

    check-cast v20, Ljava/lang/String;

    .local v20, "line\\10":Ljava/lang/String;
    const/16 v21, 0x0

    .line 52
    .local v21, "$i$a$-mapNotNull-HitchData$Companion$load$raw$2\\10\\210\\0":I
    move-object/from16 v22, v20

    check-cast v22, Ljava/lang/CharSequence;

    move/from16 v28, v14

    const/4 v13, 0x1

    new-array v14, v13, [C

    const/16 v13, 0x20

    aput-char v13, v14, v28

    const/16 v26, 0x6

    const/16 v27, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    move-object/from16 v23, v14

    invoke-static/range {v22 .. v27}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v13

    move-object v14, v13

    .line 212
    .local v14, "it\\11":Ljava/util/List;
    const/16 v22, 0x0

    .line 52
    .local v22, "$i$a$-takeIf-HitchData$Companion$load$raw$2$1\\11\\52\\10":I
    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v2

    move/from16 v24, v1

    .end local v1    # "$i$f$mapNotNull\\5\\51":I
    .local v24, "$i$f$mapNotNull\\5\\51":I
    const/4 v1, 0x4

    if-lt v2, v1, :cond_3

    const/4 v1, 0x1

    goto :goto_2

    :cond_3
    move/from16 v1, v28

    .end local v14    # "it\\11":Ljava/util/List;
    .end local v22    # "$i$a$-takeIf-HitchData$Companion$load$raw$2$1\\11\\52\\10":I
    :goto_2
    if-eqz v1, :cond_4

    goto :goto_3

    :cond_4
    const/4 v13, 0x0

    :goto_3
    if-eqz v13, :cond_6

    move-object v1, v13

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\12":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 213
    .local v2, "$i$f$map\\12\\52":I
    new-instance v13, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v1, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v14

    invoke-direct {v13, v14}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v13, Ljava/util/Collection;

    .local v13, "destination\\13":Ljava/util/Collection;
    move-object v14, v1

    .local v14, "$this$mapTo\\13":Ljava/lang/Iterable;
    const/16 v22, 0x0

    .line 214
    .local v22, "$i$f$mapTo\\13\\213":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v23

    :goto_4
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v25

    if-eqz v25, :cond_5

    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v25

    .line 215
    .local v25, "item\\13":Ljava/lang/Object;
    move-object/from16 v26, v25

    check-cast v26, Ljava/lang/String;

    .local v26, "it\\14":Ljava/lang/String;
    const/16 v27, 0x0

    .line 52
    .local v27, "$i$a$-map-HitchData$Companion$load$raw$2$2\\14\\215\\10":I
    invoke-static/range {v26 .. v26}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v29

    move-object/from16 v26, v1

    .end local v1    # "$this$map\\12":Ljava/lang/Iterable;
    .end local v27    # "$i$a$-map-HitchData$Companion$load$raw$2$2\\14\\215\\10":I
    .local v26, "$this$map\\12":Ljava/lang/Iterable;
    invoke-static/range {v29 .. v30}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    .line 215
    invoke-interface {v13, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, v26

    goto :goto_4

    .line 216
    .end local v25    # "item\\13":Ljava/lang/Object;
    .end local v26    # "$this$map\\12":Ljava/lang/Iterable;
    .restart local v1    # "$this$map\\12":Ljava/lang/Iterable;
    :cond_5
    move-object/from16 v26, v1

    .end local v1    # "$this$map\\12":Ljava/lang/Iterable;
    .end local v13    # "destination\\13":Ljava/util/Collection;
    .end local v14    # "$this$mapTo\\13":Ljava/lang/Iterable;
    .end local v22    # "$i$f$mapTo\\13\\213":I
    .restart local v26    # "$this$map\\12":Ljava/lang/Iterable;
    move-object v1, v13

    check-cast v1, Ljava/util/List;

    .line 213
    nop

    .end local v2    # "$i$f$map\\12\\52":I
    .end local v26    # "$this$map\\12":Ljava/lang/Iterable;
    goto :goto_5

    .line 52
    :cond_6
    const/4 v1, 0x0

    .line 210
    .end local v20    # "line\\10":Ljava/lang/String;
    .end local v21    # "$i$a$-mapNotNull-HitchData$Companion$load$raw$2\\10\\210\\0":I
    :goto_5
    if-eqz v1, :cond_7

    .line 217
    .local v1, "it\\8":Ljava/lang/Object;
    const/4 v2, 0x0

    .line 210
    .local v2, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\9\\217\\8":I
    invoke-interface {v5, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 211
    .end local v1    # "it\\8":Ljava/lang/Object;
    .end local v2    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\9\\217\\8":I
    .end local v18    # "element\\8":Ljava/lang/Object;
    .end local v19    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\211\\6":I
    :cond_7
    move/from16 v1, v24

    move/from16 v14, v28

    const/4 v2, 0x0

    const/4 v13, 0x2

    .end local v15    # "element\\7":Ljava/lang/Object;
    goto/16 :goto_1

    .line 218
    .end local v24    # "$i$f$mapNotNull\\5\\51":I
    .local v1, "$i$f$mapNotNull\\5\\51":I
    :cond_8
    move/from16 v24, v1

    move/from16 v28, v14

    .line 219
    .end local v1    # "$i$f$mapNotNull\\5\\51":I
    .end local v10    # "$this$forEach\\7":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEach\\7\\210":I
    .restart local v24    # "$i$f$mapNotNull\\5\\51":I
    nop

    .end local v5    # "destination\\6":Ljava/util/Collection;
    .end local v6    # "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    .end local v7    # "$i$f$mapNotNullTo\\6\\202":I
    move-object v1, v5

    check-cast v1, Ljava/util/List;

    .line 202
    nop

    .end local v3    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v24    # "$i$f$mapNotNull\\5\\51":I
    check-cast v1, Ljava/lang/Iterable;

    .line 53
    nop

    .local v1, "$this$filter\\15":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 220
    .local v2, "$i$f$filter\\15\\53":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\16":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$filterTo\\16":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 221
    .local v6, "$i$f$filterTo\\16\\220":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_9
    :goto_6
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    const-wide v11, 0x1bf08eb000L

    if-eqz v10, :cond_b

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\16":Ljava/lang/Object;
    move-object v13, v10

    check-cast v13, Ljava/util/List;

    .local v13, "it\\17":Ljava/util/List;
    const/4 v14, 0x0

    .line 53
    .local v14, "$i$a$-filter-HitchData$Companion$load$raw$3\\17\\221\\0":I
    const/4 v15, 0x1

    invoke-interface {v13, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/Number;

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J

    move-result-wide v15

    sub-long v15, v8, v15

    cmp-long v11, v15, v11

    if-gtz v11, :cond_a

    const/4 v11, 0x1

    goto :goto_7

    :cond_a
    move/from16 v11, v28

    .line 221
    .end local v13    # "it\\17":Ljava/util/List;
    .end local v14    # "$i$a$-filter-HitchData$Companion$load$raw$3\\17\\221\\0":I
    :goto_7
    if-eqz v11, :cond_9

    invoke-interface {v3, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_6

    .line 222
    .end local v10    # "element\\16":Ljava/lang/Object;
    :cond_b
    nop

    .end local v3    # "destination\\16":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\16":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo\\16\\220":I
    check-cast v3, Ljava/util/List;

    .line 220
    nop

    .line 53
    .end local v1    # "$this$filter\\15":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\15\\53":I
    nop

    .line 51
    move-object v1, v3

    .line 54
    .local v1, "raw":Ljava/util/List;
    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$mapIndexed\\18":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 223
    .local v3, "$i$f$mapIndexed\\18\\54":I
    new-instance v5, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v2, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\19":Ljava/util/Collection;
    move-object v6, v2

    .local v6, "$this$mapIndexedTo\\19":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 224
    .local v7, "$i$f$mapIndexedTo\\19\\223":I
    const/4 v10, 0x0

    .line 225
    .local v10, "index\\19":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_8
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_e

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .line 226
    .local v14, "item\\19":Ljava/lang/Object;
    add-int/lit8 v15, v10, 0x1

    .end local v10    # "index\\19":I
    .local v15, "index\\19":I
    if-gez v10, :cond_c

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_c
    move-wide/from16 v18, v11

    move-object v11, v14

    check-cast v11, Ljava/util/List;

    .local v10, "i\\20":I
    .local v11, "v\\20":Ljava/util/List;
    const/4 v12, 0x0

    .line 55
    .local v12, "$i$a$-mapIndexed-HitchData$Companion$load$frames$1\\20\\226\\0":I
    new-instance v29, Lorg/lighttouch/android/HitchFrame;

    move-object/from16 v16, v2

    move/from16 v2, v28

    .end local v2    # "$this$mapIndexed\\18":Ljava/lang/Iterable;
    .local v16, "$this$mapIndexed\\18":Ljava/lang/Iterable;
    invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/Number;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Number;->longValue()J

    move-result-wide v30

    const/4 v2, 0x1

    invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/Number;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Number;->longValue()J

    move-result-wide v32

    const/4 v2, 0x2

    invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/Number;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Number;->longValue()J

    move-result-wide v34

    const/4 v2, 0x3

    invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v36

    if-nez v10, :cond_d

    const/4 v2, 0x0

    move-object/from16 v22, v1

    move/from16 v38, v2

    goto :goto_9

    :cond_d
    const/4 v2, 0x1

    invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/lang/Number;

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->longValue()J

    move-result-wide v20

    add-int/lit8 v2, v10, -0x1

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    move-object/from16 v22, v1

    const/4 v1, 0x1

    .end local v1    # "raw":Ljava/util/List;
    .local v22, "raw":Ljava/util/List;
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    sub-long v1, v20, v1

    long-to-float v1, v1

    const v2, 0x49742400    # 1000000.0f

    div-float v2, v1, v2

    move/from16 v38, v2

    :goto_9
    invoke-direct/range {v29 .. v38}, Lorg/lighttouch/android/HitchFrame;-><init>(JJJJF)V

    .line 226
    move-object/from16 v1, v29

    .end local v10    # "i\\20":I
    .end local v11    # "v\\20":Ljava/util/List;
    .end local v12    # "$i$a$-mapIndexed-HitchData$Companion$load$frames$1\\20\\226\\0":I
    invoke-interface {v5, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move v10, v15

    move-object/from16 v2, v16

    move-wide/from16 v11, v18

    move-object/from16 v1, v22

    const/16 v28, 0x0

    goto/16 :goto_8

    .line 227
    .end local v14    # "item\\19":Ljava/lang/Object;
    .end local v15    # "index\\19":I
    .end local v16    # "$this$mapIndexed\\18":Ljava/lang/Iterable;
    .end local v22    # "raw":Ljava/util/List;
    .restart local v1    # "raw":Ljava/util/List;
    .restart local v2    # "$this$mapIndexed\\18":Ljava/lang/Iterable;
    .local v10, "index\\19":I
    :cond_e
    move-object/from16 v22, v1

    move-object/from16 v16, v2

    move-wide/from16 v18, v11

    .end local v1    # "raw":Ljava/util/List;
    .end local v2    # "$this$mapIndexed\\18":Ljava/lang/Iterable;
    .end local v5    # "destination\\19":Ljava/util/Collection;
    .end local v6    # "$this$mapIndexedTo\\19":Ljava/lang/Iterable;
    .end local v7    # "$i$f$mapIndexedTo\\19\\223":I
    .end local v10    # "index\\19":I
    .restart local v16    # "$this$mapIndexed\\18":Ljava/lang/Iterable;
    .restart local v22    # "raw":Ljava/util/List;
    move-object v1, v5

    check-cast v1, Ljava/util/List;

    .line 223
    nop

    .end local v3    # "$i$f$mapIndexed\\18\\54":I
    .end local v16    # "$this$mapIndexed\\18":Ljava/lang/Iterable;
    check-cast v1, Ljava/lang/Iterable;

    .line 56
    const/4 v2, 0x1

    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v5

    .line 54
    nop

    .line 57
    .local v5, "frames":Ljava/util/List;
    const-string v1, "detailed"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v10

    .line 58
    .local v10, "detailed":Z
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 59
    .local v1, "breakdown":Ljava/util/ArrayList;
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 60
    .local v2, "events":Ljava/util/ArrayList;
    if-eqz v10, :cond_f

    new-instance v12, Ljava/io/File;

    const-string v3, "events.tsv"

    invoke-direct {v12, v4, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    sub-long v13, v8, v18

    move-object v15, v1

    check-cast v15, Ljava/util/List;

    move-object/from16 v16, v2

    check-cast v16, Ljava/util/List;

    move-object/from16 v11, p0

    invoke-direct/range {v11 .. v16}, Lorg/lighttouch/android/HitchData$Companion;->readEvents(Ljava/io/File;JLjava/util/List;Ljava/util/List;)V

    .line 61
    :cond_f
    new-instance v3, Lorg/lighttouch/android/HitchData;

    move-object v6, v1

    check-cast v6, Ljava/util/List;

    move-object v7, v2

    check-cast v7, Ljava/util/List;

    const-string v11, "engineLog"

    invoke-virtual {v0, v11}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, ""

    if-nez v11, :cond_10

    move-object v11, v12

    .line 62
    :cond_10
    const-string v13, "appName"

    invoke-virtual {v0, v13}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_11

    move-object v13, v12

    :cond_11
    const-string v14, "bundleId"

    invoke-virtual {v0, v14}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-nez v14, :cond_12

    goto :goto_a

    :cond_12
    move-object v12, v14

    .line 61
    :goto_a
    move-object/from16 v39, v13

    move-object v13, v12

    move-object/from16 v12, v39

    invoke-direct/range {v3 .. v13}, Lorg/lighttouch/android/HitchData;-><init>(Ljava/io/File;Ljava/util/List;Ljava/util/List;Ljava/util/List;JZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v3

    .line 49
    .end local v1    # "breakdown":Ljava/util/ArrayList;
    .end local v2    # "events":Ljava/util/ArrayList;
    .end local v4    # "directory":Ljava/io/File;
    .end local v5    # "frames":Ljava/util/List;
    .end local v8    # "snapshotNs":J
    .end local v10    # "detailed":Z
    .end local v22    # "raw":Ljava/util/List;
    :cond_13
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "\u5fc5\u9700\u7684\u503c\u4e3a\u7a7a\u3002"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

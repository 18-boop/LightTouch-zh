.class final Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;
.super Ljava/lang/Object;
.source "DeviceDetails.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeviceDetails.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeviceDetails.kt\norg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,189:1\n1#2:190\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $device:Lorg/lighttouch/android/DeviceSummary;

.field final synthetic $identity:Lorg/json/JSONObject;


# direct methods
.method constructor <init>(Lorg/lighttouch/android/DeviceSummary;Lorg/json/JSONObject;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    iput-object p2, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$identity:Lorg/json/JSONObject;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 127
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 16
    .param p1, "$this$Section"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$Section"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C127@7604L231,129@7860L81,130@7966L27,*133@8315L25:DeviceDetails.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 134
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_e

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.DeviceDetails.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DeviceDetails.kt:127)"

    const v6, 0x8c471fa

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 128
    :cond_2
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-virtual {v3}, Lorg/lighttouch/android/DeviceSummary;->getModel()Ljava/lang/String;

    move-result-object v3

    .line 129
    nop

    .line 128
    iget-object v5, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$identity:Lorg/json/JSONObject;

    const-string v6, ")"

    const-string v7, " ("

    const-string v8, ""

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v5, :cond_7

    const-string v12, "model-number"

    invoke-virtual {v5, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_7

    .line 190
    move-object v12, v5

    .local v12, "it\\1":Ljava/lang/String;
    const/4 v13, 0x0

    .line 128
    .local v13, "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$1\\1\\128\\0":I
    move-object v14, v12

    check-cast v14, Ljava/lang/CharSequence;

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-lez v14, :cond_3

    const/4 v14, 0x1

    goto :goto_1

    :cond_3
    move v14, v10

    .end local v12    # "it\\1":Ljava/lang/String;
    .end local v13    # "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$1\\1\\128\\0":I
    :goto_1
    if-eqz v14, :cond_4

    goto :goto_2

    :cond_4
    move-object v5, v11

    .line 129
    :goto_2
    if-eqz v5, :cond_7

    .line 128
    nop

    .line 129
    iget-object v12, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$identity:Lorg/json/JSONObject;

    .line 190
    nop

    .local v5, "it\\2":Ljava/lang/String;
    const/4 v13, 0x0

    .line 129
    .local v13, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$2\\2\\129\\0":I
    const-string v14, "region-info"

    invoke-virtual {v12, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 190
    nop

    .local v12, "r\\3":Ljava/lang/String;
    const/4 v14, 0x0

    .line 129
    .local v14, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$2$1\\3\\129\\2":I
    invoke-static {v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v15, v12

    check-cast v15, Ljava/lang/CharSequence;

    invoke-interface {v15}, Ljava/lang/CharSequence;->length()I

    move-result v15

    if-lez v15, :cond_5

    const/4 v15, 0x1

    goto :goto_3

    :cond_5
    move v15, v10

    :goto_3
    if-eqz v15, :cond_6

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, " "

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_4

    :cond_6
    move-object v9, v8

    .end local v12    # "r\\3":Ljava/lang/String;
    .end local v14    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$2$1\\3\\129\\2":I
    :goto_4
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    .line 128
    .end local v5    # "it\\2":Ljava/lang/String;
    .end local v13    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$2\\2\\129\\0":I
    if-eqz v9, :cond_7

    move-object v8, v9

    goto :goto_5

    .line 129
    :cond_7
    nop

    :goto_5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 128
    const-string v5, "\u673a\u578b"

    const/4 v8, 0x6

    invoke-static {v5, v3, v1, v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 130
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-virtual {v3}, Lorg/lighttouch/android/DeviceSummary;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v3

    if-eqz v3, :cond_8

    iget-object v5, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    .line 190
    nop

    .local v3, "it\\4":Lorg/lighttouch/android/StoreTarget;
    const/4 v9, 0x0

    .line 130
    .local v9, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$3\\4\\130\\0":I
    invoke-virtual {v3}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5}, Lorg/lighttouch/android/DeviceSummary;->getBuild()Ljava/lang/String;

    move-result-object v5

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .end local v3    # "it\\4":Lorg/lighttouch/android/StoreTarget;
    .end local v9    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$3\\4\\130\\0":I
    if-nez v3, :cond_9

    :cond_8
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-virtual {v3}, Lorg/lighttouch/android/DeviceSummary;->getBuild()Ljava/lang/String;

    move-result-object v3

    :cond_9
    const-string v5, "iOS"

    invoke-static {v5, v3, v1, v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 131
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-virtual {v3}, Lorg/lighttouch/android/DeviceSummary;->getBoard()Ljava/lang/String;

    move-result-object v3

    const-string v5, "\u4e3b\u677f"

    invoke-static {v5, v3, v1, v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 132
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$identity:Lorg/json/JSONObject;

    if-eqz v3, :cond_b

    const-string v5, "serial-number"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_b

    move-object v5, v3

    .line 190
    .local v5, "it\\5":Ljava/lang/String;
    const/4 v6, 0x0

    .line 132
    .local v6, "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$4\\5\\132\\0":I
    move-object v7, v5

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_a

    const/4 v7, 0x1

    goto :goto_6

    :cond_a
    move v7, v10

    .end local v5    # "it\\5":Ljava/lang/String;
    .end local v6    # "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$4\\5\\132\\0":I
    :goto_6
    if-eqz v7, :cond_b

    goto :goto_7

    :cond_b
    move-object v3, v11

    :goto_7
    const v5, -0x168fe525

    invoke-interface {v1, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "*131@8090L25"

    invoke-static {v1, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v3, :cond_c

    goto :goto_8

    .line 190
    .local v3, "it\\6":Ljava/lang/String;
    :cond_c
    const/4 v5, 0x0

    .line 132
    .local v5, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$5\\6\\132\\0":I
    const-string v6, "\u5e8f\u5217\u53f7"

    invoke-static {v6, v3, v1, v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .end local v3    # "it\\6":Ljava/lang/String;
    .end local v5    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$5\\6\\132\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_8
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 133
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$identity:Lorg/json/JSONObject;

    if-eqz v3, :cond_e

    const-string v5, "udid"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_e

    move-object v5, v3

    .line 190
    .local v5, "it\\7":Ljava/lang/String;
    const/4 v6, 0x0

    .line 133
    .local v6, "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$6\\7\\133\\0":I
    move-object v7, v5

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_d

    const/4 v7, 0x1

    goto :goto_9

    :cond_d
    move v7, v10

    .end local v5    # "it\\7":Ljava/lang/String;
    .end local v6    # "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$6\\7\\133\\0":I
    :goto_9
    if-eqz v7, :cond_e

    goto :goto_a

    :cond_e
    move-object v3, v11

    :goto_a
    const v5, -0x168fd6ce

    invoke-interface {v1, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "*132@8205L16"

    invoke-static {v1, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v3, :cond_f

    goto :goto_b

    .line 190
    .local v3, "it\\8":Ljava/lang/String;
    :cond_f
    const/4 v5, 0x0

    .line 133
    .local v5, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$7\\8\\133\\0":I
    const-string v6, "UDID"

    invoke-static {v6, v3, v1, v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .end local v3    # "it\\8":Ljava/lang/String;
    .end local v5    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$7\\8\\133\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_b
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 134
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;->$identity:Lorg/json/JSONObject;

    if-eqz v3, :cond_11

    const-string v5, "wifi-mac"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_11

    move-object v5, v3

    .line 190
    .local v5, "it\\9":Ljava/lang/String;
    const/4 v6, 0x0

    .line 134
    .local v6, "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$8\\9\\134\\0":I
    move-object v7, v5

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_10

    const/4 v9, 0x1

    goto :goto_c

    :cond_10
    move v9, v10

    .end local v5    # "it\\9":Ljava/lang/String;
    .end local v6    # "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$8\\9\\134\\0":I
    :goto_c
    if-eqz v9, :cond_11

    move-object v11, v3

    :cond_11
    if-nez v11, :cond_12

    goto :goto_d

    .line 190
    .local v11, "it\\10":Ljava/lang/String;
    :cond_12
    const/4 v3, 0x0

    .line 134
    .local v3, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$9\\10\\134\\0":I
    const-string v5, "Wi-Fi \u5730\u5740"

    invoke-static {v5, v11, v1, v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .end local v3    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$1$9\\10\\134\\0":I
    .end local v11    # "it\\10":Ljava/lang/String;
    :goto_d
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 135
    :cond_13
    :goto_e
    return-void
.end method

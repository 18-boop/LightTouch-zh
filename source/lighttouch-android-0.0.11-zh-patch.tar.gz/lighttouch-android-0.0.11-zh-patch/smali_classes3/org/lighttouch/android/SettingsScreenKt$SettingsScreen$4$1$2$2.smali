.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2\n*L\n57#1:197,6\n59#1:203,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $headphonesInfo$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method public static synthetic $r8$lambda$4HMz-XXfhSUrptPgT5DRkOw0-JY(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Pan8Eodzwhi7x4FXJdOOR4HlroU(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->invoke$lambda$5$lambda$4(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$b-2KFfwAVWpejpu98Db1QFWOZFo(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->invoke$lambda$1$lambda$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/AppSettings;",
            "Lorg/lighttouch/android/GuestHost;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$s:Lorg/lighttouch/android/AppSettings;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$host:Lorg/lighttouch/android/GuestHost;

    iput-object p3, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$headphonesInfo$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$headphonesInfo$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 57
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/SettingsScreenKt;->access$SettingsScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Z

    .line 57
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setHeadphones(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "it"    # Z

    .line 59
    invoke-interface {p0, p1}, Lorg/lighttouch/android/GuestHost;->useMicrophone(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 55
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 16
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v8, p2

    move/from16 v11, p3

    const-string v1, "$this$Group"

    move-object/from16 v12, p1

    invoke-static {v12, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C56@4011L25,56@4038L21,55@3762L297,58@4454L26,57@4080L400:SettingsScreen.kt#o13vsk"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v11, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 58
    :cond_0
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_6

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:55)"

    const v3, -0x102deebd

    invoke-static {v3, v11, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 56
    :cond_2
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getHeadphones()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    .line 57
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getHeadphones()Z

    move-result v4

    const v13, 0x4c5de2

    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v14, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\1":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$headphonesInfo$delegate:Landroidx/compose/runtime/MutableState;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 197
    .local v6, "$i$f$cache\\1\\57":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\1":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 198
    .local v9, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_3

    .line 199
    const/4 v10, 0x0

    .line 57
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$2$1\\3\\199\\0":I
    new-instance v15, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2$$ExternalSyntheticLambda0;

    invoke-direct {v15, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 199
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$2$1\\3\\199\\0":I
    nop

    .line 200
    .local v15, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .end local v15    # "value\\2":Ljava/lang/Object;
    goto :goto_1

    .line 202
    :cond_3
    move-object v15, v7

    .line 198
    :goto_1
    nop

    .line 197
    .end local v7    # "it\\1":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 57
    .end local v2    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\1\\57":I
    move-object v6, v15

    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\4":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 197
    .local v7, "$i$f$cache\\4\\57":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\4":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 198
    .local v10, "$i$a$-let-ComposerKt$cache$1\\5\\197\\4":I
    if-nez v2, :cond_5

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v9, v15, :cond_4

    goto :goto_2

    .line 202
    :cond_4
    move-object v13, v9

    goto :goto_3

    .line 199
    :cond_5
    :goto_2
    const/4 v15, 0x0

    .line 57
    .local v15, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$2$2\\6\\199\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2$$ExternalSyntheticLambda1;

    invoke-direct {v13, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 199
    .end local v15    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$2$2\\6\\199\\0":I
    nop

    .line 200
    .local v13, "value\\5":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .line 198
    .end local v13    # "value\\5":Ljava/lang/Object;
    :goto_3
    nop

    .line 197
    .end local v9    # "it\\4":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\5\\197\\4":I
    nop

    .line 57
    .end local v2    # "invalid\\4":Z
    .end local v5    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\4\\57":I
    move-object v7, v13

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 56
    const-string v2, "\u5df2\u63d2\u5165\u8033\u673a"

    const-string v3, "\u901a\u8fc7\u8033\u673a\u63d2\u5b54\u8f93\u51fa\u7acb\u4f53\u58f0\uff1b\u5173\u95ed\u5219\u7528\u8bbe\u5907\u626c\u58f0\u5668\u64ad\u653e\u3002\u4e0b\u6b21\u542f\u52a8\u8bbe\u5907\u65f6\u751f\u6548"

    const-string v5, "headphones_toggle"

    const v9, 0x361b0

    const/4 v10, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 58
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getMic()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    .line 59
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getMicrophone()Z

    move-result v4

    const v2, 0x4c5de2

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\7":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 203
    .local v6, "$i$f$cache\\7\\59":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\7":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 204
    .local v9, "$i$a$-let-ComposerKt$cache$1\\8\\203\\7":I
    if-nez v2, :cond_7

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_6

    goto :goto_4

    .line 208
    :cond_6
    move-object v13, v7

    goto :goto_5

    .line 205
    :cond_7
    :goto_4
    const/4 v10, 0x0

    .line 59
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$2$3\\9\\205\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2$$ExternalSyntheticLambda2;

    invoke-direct {v13, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 205
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$2$3\\9\\205\\0":I
    nop

    .line 206
    .local v13, "value\\8":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 204
    .end local v13    # "value\\8":Ljava/lang/Object;
    :goto_5
    nop

    .line 203
    .end local v7    # "it\\7":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\8\\203\\7":I
    nop

    .line 59
    .end local v2    # "invalid\\7":Z
    .end local v5    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\7\\59":I
    move-object v7, v13

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 58
    const-string v2, "\u9ea6\u514b\u98ce"

    const-string v3, "\u628a\u624b\u673a\u9ea6\u514b\u98ce\u4f5c\u4e3a\u8bbe\u5907\u7684\u8f93\u5165\uff0c\u53ef\u7528\u4e8e\u8bed\u97f3\u5907\u5fd8\u5f55\u3001Shazam \u7b49\u5f55\u97f3\u5e94\u7528\uff1b\u9996\u6b21\u5f55\u97f3\u65f6 iOS \u4f1a\u5728\u8bbe\u5907\u5185\u8be2\u95ee\u3002\u5f00\u542f\u65f6 Android \u4f1a\u8bf7\u6c42\u9ea6\u514b\u98ce\u6743\u9650\u3002\u4e0b\u6b21\u542f\u52a8\u8bbe\u5907\u65f6\u751f\u6548"

    const-string v5, "microphone_toggle"

    const/4 v6, 0x0

    const/16 v9, 0x61b0

    const/16 v10, 0x20

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 60
    :cond_8
    :goto_6
    return-void
.end method

.class public final Lorg/lighttouch/android/FirmwareService;
.super Landroid/app/Service;
.source "FirmwareService.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFirmwareService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FirmwareService.kt\norg/lighttouch/android/FirmwareService\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,181:1\n1#2:182\n1321#3,2:183\n1563#4:185\n1634#4,3:186\n*S KotlinDebug\n*F\n+ 1 FirmwareService.kt\norg/lighttouch/android/FirmwareService\n*L\n150#1:183,2\n127#1:185\n127#1:186,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010 \n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005*\u0001\u0015\u0008\u0007\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J(\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u001a\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u0007H\u0002J\u001e\u0010\u001e\u001a\u00020\u00182\u0006\u0010\u001f\u001a\u00020\u001c2\u000c\u0010 \u001a\u0008\u0012\u0004\u0012\u00020\u00070!H\u0002J\u0010\u0010\"\u001a\u00020\u00182\u0006\u0010#\u001a\u00020\u0007H\u0002J\u0010\u0010$\u001a\u00020\u00182\u0006\u0010%\u001a\u00020\u001cH\u0002J\u0010\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020)H\u0016J\"\u0010*\u001a\u00020+2\u0008\u0010(\u001a\u0004\u0018\u00010)2\u0006\u0010,\u001a\u00020+2\u0006\u0010-\u001a\u00020+H\u0016J\u0012\u0010.\u001a\u00020\u00182\u0008\u0008\u0002\u0010/\u001a\u00020\u0007H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0016\u00a8\u00060"
    }
    d2 = {
        "Lorg/lighttouch/android/FirmwareService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "consumed",
        "Ljava/util/concurrent/atomic/AtomicBoolean;",
        "destination",
        "",
        "failure",
        "currentFirmwareId",
        "cancelling",
        "",
        "state",
        "stage",
        "done",
        "",
        "total",
        "timings",
        "process",
        "Ljava/lang/Process;",
        "binder",
        "org/lighttouch/android/FirmwareService$binder$1",
        "Lorg/lighttouch/android/FirmwareService$binder$1;",
        "prepare",
        "",
        "firmwareId",
        "ipsw",
        "tools",
        "Ljava/io/File;",
        "bootrom",
        "run",
        "libs",
        "args",
        "",
        "note",
        "phase",
        "writable",
        "root",
        "onBind",
        "Landroid/os/IBinder;",
        "intent",
        "Landroid/content/Intent;",
        "onStartCommand",
        "",
        "flags",
        "startId",
        "foreground",
        "text",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final binder:Lorg/lighttouch/android/FirmwareService$binder$1;

.field private volatile cancelling:Z

.field private final consumed:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private volatile currentFirmwareId:Ljava/lang/String;

.field private volatile destination:Ljava/lang/String;

.field private volatile done:J

.field private volatile failure:Ljava/lang/String;

.field private volatile process:Ljava/lang/Process;

.field private volatile stage:Ljava/lang/String;

.field private volatile state:Ljava/lang/String;

.field private volatile timings:Ljava/lang/String;

.field private volatile total:J


# direct methods
.method public static synthetic $r8$lambda$K1FGJfl1iQrcZD0qwW8G0QCzDTo(Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$IntRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/FirmwareService;->run$lambda$11(Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$IntRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/FirmwareService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 17
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 18
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->consumed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    const-string v0, ""

    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->destination:Ljava/lang/String;

    .line 20
    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->failure:Ljava/lang/String;

    .line 21
    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->currentFirmwareId:Ljava/lang/String;

    .line 23
    const-string v1, "idle"

    iput-object v1, p0, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    .line 24
    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->stage:Ljava/lang/String;

    .line 28
    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->timings:Ljava/lang/String;

    .line 31
    new-instance v0, Lorg/lighttouch/android/FirmwareService$binder$1;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/FirmwareService$binder$1;-><init>(Lorg/lighttouch/android/FirmwareService;)V

    iput-object v0, p0, Lorg/lighttouch/android/FirmwareService;->binder:Lorg/lighttouch/android/FirmwareService$binder$1;

    .line 17
    return-void
.end method

.method public static final synthetic access$getCancelling$p(Lorg/lighttouch/android/FirmwareService;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-boolean v0, p0, Lorg/lighttouch/android/FirmwareService;->cancelling:Z

    return v0
.end method

.method public static final synthetic access$getConsumed$p(Lorg/lighttouch/android/FirmwareService;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->consumed:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method public static final synthetic access$getCurrentFirmwareId$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->currentFirmwareId:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getDestination$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->destination:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getDone$p(Lorg/lighttouch/android/FirmwareService;)J
    .locals 2
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-wide v0, p0, Lorg/lighttouch/android/FirmwareService;->done:J

    return-wide v0
.end method

.method public static final synthetic access$getFailure$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->failure:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getProcess$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/Process;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->process:Ljava/lang/Process;

    return-object v0
.end method

.method public static final synthetic access$getStage$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->stage:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getState$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getTimings$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->timings:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getTotal$p(Lorg/lighttouch/android/FirmwareService;)J
    .locals 2
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;

    .line 17
    iget-wide v0, p0, Lorg/lighttouch/android/FirmwareService;->total:J

    return-wide v0
.end method

.method public static final synthetic access$note(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "phase"    # Ljava/lang/String;

    .line 17
    invoke-direct {p0, p1}, Lorg/lighttouch/android/FirmwareService;->note(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$prepare(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "firmwareId"    # Ljava/lang/String;
    .param p2, "ipsw"    # Ljava/lang/String;
    .param p3, "tools"    # Ljava/io/File;
    .param p4, "bootrom"    # Ljava/lang/String;

    .line 17
    invoke-direct {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/FirmwareService;->prepare(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setCancelling$p(Lorg/lighttouch/android/FirmwareService;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "<set-?>"    # Z

    .line 17
    iput-boolean p1, p0, Lorg/lighttouch/android/FirmwareService;->cancelling:Z

    return-void
.end method

.method public static final synthetic access$setCurrentFirmwareId$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 17
    iput-object p1, p0, Lorg/lighttouch/android/FirmwareService;->currentFirmwareId:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setDestination$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 17
    iput-object p1, p0, Lorg/lighttouch/android/FirmwareService;->destination:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setStage$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 17
    iput-object p1, p0, Lorg/lighttouch/android/FirmwareService;->stage:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setState$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 17
    iput-object p1, p0, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    return-void
.end method

.method private final foreground(Ljava/lang/String;)V
    .locals 7
    .param p1, "text"    # Ljava/lang/String;

    .line 158
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/FirmwareService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 159
    .local v0, "manager":Landroid/app/NotificationManager;
    new-instance v1, Landroid/app/NotificationChannel;

    const-string v2, "\u56fa\u4ef6\u51c6\u5907"

    check-cast v2, Ljava/lang/CharSequence;

    const-string v3, "firmware"

    const/4 v4, 0x2

    invoke-direct {v1, v3, v2, v4}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 160
    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    new-instance v2, Landroid/content/Intent;

    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    const-class v6, Lorg/lighttouch/android/MainActivity;

    invoke-direct {v2, v5, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v5, 0x4000000

    const/4 v6, 0x1

    invoke-static {v1, v6, v2, v5}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    .line 161
    .local v1, "launch":Landroid/app/PendingIntent;
    new-instance v2, Landroid/app/Notification$Builder;

    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    invoke-direct {v2, v5, v3}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v3, 0x1080055

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 162
    const-string v3, "LightTouch preparation"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    move-object v3, p1

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 163
    invoke-virtual {v2, v1}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v6}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v2

    .line 161
    invoke-virtual {p0, v4, v2}, Lorg/lighttouch/android/FirmwareService;->startForeground(ILandroid/app/Notification;)V

    .line 164
    return-void
.end method

.method static synthetic foreground$default(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 0

    .line 157
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    const-string p1, "\u6b63\u5728\u51c6\u5907\u8bbe\u5907\uff1b\u8fd4\u56de\u5e94\u7528\u53ef\u67e5\u770b\u8fdb\u5ea6\u6216\u53d6\u6d88"

    :cond_0
    invoke-direct {p0, p1}, Lorg/lighttouch/android/FirmwareService;->foreground(Ljava/lang/String;)V

    return-void
.end method

.method private final note(Ljava/lang/String;)V
    .locals 5
    .param p1, "phase"    # Ljava/lang/String;

    .line 146
    sget-object v0, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "state"

    invoke-virtual {v2, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v4

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v2

    .line 147
    const-string v3, "firmwareId"

    iget-object v4, p0, Lorg/lighttouch/android/FirmwareService;->currentFirmwareId:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "destination"

    iget-object v4, p0, Lorg/lighttouch/android/FirmwareService;->destination:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "timings"

    iget-object v4, p0, Lorg/lighttouch/android/FirmwareService;->timings:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "error"

    iget-object v4, p0, Lorg/lighttouch/android/FirmwareService;->failure:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "put(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    invoke-virtual {v0, v1, v2}, Lorg/lighttouch/android/PreparationNote;->write(Landroid/content/Context;Lorg/json/JSONObject;)V

    .line 147
    return-void
.end method

.method private final prepare(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)V
    .locals 18
    .param p1, "firmwareId"    # Ljava/lang/String;
    .param p2, "ipsw"    # Ljava/lang/String;
    .param p3, "tools"    # Ljava/io/File;
    .param p4, "bootrom"    # Ljava/lang/String;

    .line 73
    move-object/from16 v1, p0

    const-string v0, "complete"

    const-string v2, "firmware-catalog.json"

    const-class v3, Landroid/os/PowerManager;

    invoke-virtual {v1, v3}, Lorg/lighttouch/android/FirmwareService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/PowerManager;

    const-string v4, "LightTouch:preparation"

    const/4 v5, 0x1

    invoke-virtual {v3, v5, v4}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v3

    .line 74
    .local v3, "awake":Landroid/os/PowerManager$WakeLock;
    const-wide/32 v6, 0x36ee80

    invoke-virtual {v3, v6, v7}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 75
    new-instance v4, Ljava/io/File;

    invoke-virtual {v1}, Lorg/lighttouch/android/FirmwareService;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v6

    iget-object v6, v6, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;

    invoke-direct {v4, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 76
    .local v4, "libs":Ljava/io/File;
    new-instance v6, Ljava/io/File;

    invoke-virtual {v1}, Lorg/lighttouch/android/FirmwareService;->getCacheDir()Ljava/io/File;

    move-result-object v7

    const-string v8, "firmwarekit"

    invoke-direct {v6, v7, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 77
    .local v6, "cache":Ljava/io/File;
    new-instance v7, Ljava/io/File;

    iget-object v8, v1, Lorg/lighttouch/android/FirmwareService;->destination:Ljava/lang/String;

    invoke-direct {v7, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 78
    .local v7, "out":Ljava/io/File;
    nop

    .line 79
    const/4 v8, 0x0

    :try_start_0
    new-instance v9, Ljava/io/File;

    invoke-virtual {v1}, Lorg/lighttouch/android/FirmwareService;->getFilesDir()Ljava/io/File;

    move-result-object v10

    invoke-direct {v9, v10, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 80
    .local v9, "catalog":Ljava/io/File;
    invoke-virtual {v1}, Lorg/lighttouch/android/FirmwareService;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v10

    invoke-virtual {v10, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v2

    check-cast v2, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    :try_start_1
    move-object v10, v2

    check-cast v10, Ljava/io/InputStream;

    .line 182
    .local v10, "input\\1":Ljava/io/InputStream;
    const/4 v11, 0x0

    .local v11, "$i$a$-use-FirmwareService$prepare$1\\1\\80\\0":I
    new-instance v12, Ljava/io/FileOutputStream;

    .line 80
    invoke-direct {v12, v9}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v12, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    :try_start_2
    move-object v13, v12

    check-cast v13, Ljava/io/FileOutputStream;

    .line 182
    .local v13, "it\\2":Ljava/io/FileOutputStream;
    const/4 v14, 0x0

    .line 80
    .local v14, "$i$a$-use-FirmwareService$prepare$1$1\\2\\80\\1":I
    invoke-static {v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v15, v13

    check-cast v15, Ljava/io/OutputStream;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move/from16 v16, v5

    const/4 v5, 0x2

    move-object/from16 v17, v3

    .end local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    .local v17, "awake":Landroid/os/PowerManager$WakeLock;
    const/4 v3, 0x0

    :try_start_3
    invoke-static {v10, v15, v3, v5, v8}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .end local v13    # "it\\2":Ljava/io/FileOutputStream;
    .end local v14    # "$i$a$-use-FirmwareService$prepare$1$1\\2\\80\\1":I
    :try_start_4
    invoke-static {v12, v8}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .end local v10    # "input\\1":Ljava/io/InputStream;
    .end local v11    # "$i$a$-use-FirmwareService$prepare$1\\1\\80\\0":I
    :try_start_5
    invoke-static {v2, v8}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 81
    const/16 v2, 0x12

    new-array v2, v2, [Ljava/lang/String;

    const-string v10, "create"

    aput-object v10, v2, v3

    const-string v10, "--catalog"

    aput-object v10, v2, v16

    invoke-virtual {v9}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v2, v5

    const-string v10, "--id"

    const/4 v11, 0x3

    aput-object v10, v2, v11

    const/4 v10, 0x4

    aput-object p1, v2, v10

    const-string v10, "--ipsw"

    const/4 v11, 0x5

    aput-object v10, v2, v11

    const/4 v10, 0x6

    aput-object p2, v2, v10

    const-string v10, "--out"

    const/4 v11, 0x7

    aput-object v10, v2, v11

    invoke-virtual {v7}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0x8

    aput-object v10, v2, v11

    .line 82
    const-string v10, "--helper"

    const/16 v11, 0x9

    aput-object v10, v2, v11

    .line 81
    nop

    .line 82
    new-instance v10, Ljava/io/File;

    const-string v11, "liblighttouch_oneshot.so"

    invoke-direct {v10, v4, v11}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v10}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0xa

    aput-object v10, v2, v11

    .line 81
    nop

    .line 82
    const-string v10, "--guest-tools"

    const/16 v11, 0xb

    aput-object v10, v2, v11

    .line 81
    nop

    .line 82
    invoke-virtual/range {p3 .. p3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0xc

    aput-object v10, v2, v11

    .line 81
    nop

    .line 82
    const-string v10, "--cache"

    const/16 v11, 0xd

    aput-object v10, v2, v11

    .line 81
    nop

    .line 82
    invoke-virtual {v6}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0xe

    aput-object v10, v2, v11

    .line 81
    nop

    .line 83
    const-string v10, "--language"

    const/16 v11, 0xf

    aput-object v10, v2, v11

    .line 81
    nop

    .line 83
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v10

    invoke-virtual {v10}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0x10

    aput-object v10, v2, v11

    .line 81
    nop

    .line 85
    const-string v10, "--skip-setup"

    const/16 v11, 0x11

    aput-object v10, v2, v11

    .line 81
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    .line 87
    move-object/from16 v10, p4

    check-cast v10, Ljava/lang/CharSequence;

    invoke-interface {v10}, Ljava/lang/CharSequence;->length()I

    move-result v10

    if-lez v10, :cond_0

    move/from16 v10, v16

    goto :goto_0

    :cond_0
    move v10, v3

    :goto_0
    if-eqz v10, :cond_1

    new-array v5, v5, [Ljava/lang/String;

    const-string v10, "--bootrom"

    aput-object v10, v5, v3

    aput-object p4, v5, v16

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    goto :goto_1

    :cond_1
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    :goto_1
    check-cast v3, Ljava/lang/Iterable;

    .line 81
    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v1, v4, v2}, Lorg/lighttouch/android/FirmwareService;->run(Ljava/io/File;Ljava/util/List;)V

    .line 89
    new-instance v2, Ljava/io/File;

    const-string v3, "work"

    invoke-direct {v2, v7, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 182
    .local v2, "it\\3":Ljava/io/File;
    const/4 v3, 0x0

    .line 89
    .local v3, "$i$a$-let-FirmwareService$prepare$2\\3\\89\\0":I
    invoke-direct {v1, v2}, Lorg/lighttouch/android/FirmwareService;->writable(Ljava/io/File;)V

    invoke-static {v2}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 90
    .end local v2    # "it\\3":Ljava/io/File;
    .end local v3    # "$i$a$-let-FirmwareService$prepare$2\\3\\89\\0":I
    iget-wide v2, v1, Lorg/lighttouch/android/FirmwareService;->total:J

    iput-wide v2, v1, Lorg/lighttouch/android/FirmwareService;->done:J

    .line 91
    iput-object v0, v1, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    .line 92
    invoke-direct {v1, v0}, Lorg/lighttouch/android/FirmwareService;->note(Ljava/lang/String;)V

    .line 93
    const-string v0, "\u8bbe\u5907\u5df2\u51c6\u5907\u5b8c\u6210\uff0c\u6253\u5f00 LightTouch \u5373\u53ef\u6dfb\u52a0\u3002"

    invoke-direct {v1, v0}, Lorg/lighttouch/android/FirmwareService;->foreground(Ljava/lang/String;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_7

    .line 99
    .end local v9    # "catalog":Ljava/io/File;
    iput-object v8, v1, Lorg/lighttouch/android/FirmwareService;->process:Ljava/lang/Process;

    .line 100
    invoke-virtual/range {v17 .. v17}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_5

    goto :goto_7

    .line 80
    .restart local v9    # "catalog":Ljava/io/File;
    .restart local v10    # "input\\1":Ljava/io/InputStream;
    .restart local v11    # "$i$a$-use-FirmwareService$prepare$1\\1\\80\\0":I
    :catchall_0
    move-exception v0

    move-object v3, v0

    goto :goto_2

    .end local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .local v3, "awake":Landroid/os/PowerManager$WakeLock;
    :catchall_1
    move-exception v0

    move-object/from16 v17, v3

    move-object v3, v0

    .end local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    .end local v4    # "libs":Ljava/io/File;
    .end local v6    # "cache":Ljava/io/File;
    .end local v7    # "out":Ljava/io/File;
    .end local v9    # "catalog":Ljava/io/File;
    .end local v10    # "input\\1":Ljava/io/InputStream;
    .end local v11    # "$i$a$-use-FirmwareService$prepare$1\\1\\80\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .end local p1    # "firmwareId":Ljava/lang/String;
    .end local p2    # "ipsw":Ljava/lang/String;
    .end local p3    # "tools":Ljava/io/File;
    .end local p4    # "bootrom":Ljava/lang/String;
    :goto_2
    :try_start_6
    throw v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .restart local v4    # "libs":Ljava/io/File;
    .restart local v6    # "cache":Ljava/io/File;
    .restart local v7    # "out":Ljava/io/File;
    .restart local v9    # "catalog":Ljava/io/File;
    .restart local v10    # "input\\1":Ljava/io/InputStream;
    .restart local v11    # "$i$a$-use-FirmwareService$prepare$1\\1\\80\\0":I
    .restart local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .restart local p1    # "firmwareId":Ljava/lang/String;
    .restart local p2    # "ipsw":Ljava/lang/String;
    .restart local p3    # "tools":Ljava/io/File;
    .restart local p4    # "bootrom":Ljava/lang/String;
    :catchall_2
    move-exception v0

    :try_start_7
    invoke-static {v12, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v4    # "libs":Ljava/io/File;
    .end local v6    # "cache":Ljava/io/File;
    .end local v7    # "out":Ljava/io/File;
    .end local v9    # "catalog":Ljava/io/File;
    .end local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .end local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .end local p1    # "firmwareId":Ljava/lang/String;
    .end local p2    # "ipsw":Ljava/lang/String;
    .end local p3    # "tools":Ljava/io/File;
    .end local p4    # "bootrom":Ljava/lang/String;
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .end local v10    # "input\\1":Ljava/io/InputStream;
    .end local v11    # "$i$a$-use-FirmwareService$prepare$1\\1\\80\\0":I
    .restart local v4    # "libs":Ljava/io/File;
    .restart local v6    # "cache":Ljava/io/File;
    .restart local v7    # "out":Ljava/io/File;
    .restart local v9    # "catalog":Ljava/io/File;
    .restart local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .restart local p1    # "firmwareId":Ljava/lang/String;
    .restart local p2    # "ipsw":Ljava/lang/String;
    .restart local p3    # "tools":Ljava/io/File;
    .restart local p4    # "bootrom":Ljava/lang/String;
    :catchall_3
    move-exception v0

    move-object v3, v0

    goto :goto_3

    .end local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    :catchall_4
    move-exception v0

    move-object/from16 v17, v3

    move-object v3, v0

    .end local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    .end local v4    # "libs":Ljava/io/File;
    .end local v6    # "cache":Ljava/io/File;
    .end local v7    # "out":Ljava/io/File;
    .end local v9    # "catalog":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .end local p1    # "firmwareId":Ljava/lang/String;
    .end local p2    # "ipsw":Ljava/lang/String;
    .end local p3    # "tools":Ljava/io/File;
    .end local p4    # "bootrom":Ljava/lang/String;
    :goto_3
    :try_start_8
    throw v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .restart local v4    # "libs":Ljava/io/File;
    .restart local v6    # "cache":Ljava/io/File;
    .restart local v7    # "out":Ljava/io/File;
    .restart local v9    # "catalog":Ljava/io/File;
    .restart local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .restart local p1    # "firmwareId":Ljava/lang/String;
    .restart local p2    # "ipsw":Ljava/lang/String;
    .restart local p3    # "tools":Ljava/io/File;
    .restart local p4    # "bootrom":Ljava/lang/String;
    :catchall_5
    move-exception v0

    :try_start_9
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v4    # "libs":Ljava/io/File;
    .end local v6    # "cache":Ljava/io/File;
    .end local v7    # "out":Ljava/io/File;
    .end local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .end local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .end local p1    # "firmwareId":Ljava/lang/String;
    .end local p2    # "ipsw":Ljava/lang/String;
    .end local p3    # "tools":Ljava/io/File;
    .end local p4    # "bootrom":Ljava/lang/String;
    throw v0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_7

    .line 94
    .end local v9    # "catalog":Ljava/io/File;
    .restart local v4    # "libs":Ljava/io/File;
    .restart local v6    # "cache":Ljava/io/File;
    .restart local v7    # "out":Ljava/io/File;
    .restart local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local p0    # "this":Lorg/lighttouch/android/FirmwareService;
    .restart local p1    # "firmwareId":Ljava/lang/String;
    .restart local p2    # "ipsw":Ljava/lang/String;
    .restart local p3    # "tools":Ljava/io/File;
    .restart local p4    # "bootrom":Ljava/lang/String;
    :catch_0
    move-exception v0

    goto :goto_4

    .line 99
    .end local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    :catchall_6
    move-exception v0

    move-object/from16 v17, v3

    .end local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    goto :goto_8

    .line 94
    .end local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    .restart local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    :catch_1
    move-exception v0

    move-object/from16 v17, v3

    .line 95
    .end local v3    # "awake":Landroid/os/PowerManager$WakeLock;
    .local v0, "e":Ljava/lang/Exception;
    .restart local v17    # "awake":Landroid/os/PowerManager$WakeLock;
    :goto_4
    :try_start_a
    iget-boolean v2, v1, Lorg/lighttouch/android/FirmwareService;->cancelling:Z
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    const-string v3, "failed"

    if-eqz v2, :cond_2

    :try_start_b
    const-string v2, "cancelled"

    iput-object v2, v1, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    goto :goto_5

    :cond_2
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    const-string v2, "\u56fa\u4ef6\u51c6\u5907\u5931\u8d25"

    :cond_3
    iput-object v2, v1, Lorg/lighttouch/android/FirmwareService;->failure:Ljava/lang/String;

    iput-object v3, v1, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    .line 96
    :goto_5
    invoke-direct {v1, v7}, Lorg/lighttouch/android/FirmwareService;->writable(Ljava/io/File;)V

    invoke-static {v7}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 97
    iget-boolean v2, v1, Lorg/lighttouch/android/FirmwareService;->cancelling:Z

    if-eqz v2, :cond_4

    sget-object v2, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v3, v1

    check-cast v3, Landroid/content/Context;

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/PreparationNote;->clear(Landroid/content/Context;)V

    goto :goto_6

    :cond_4
    invoke-direct {v1, v3}, Lorg/lighttouch/android/FirmwareService;->note(Ljava/lang/String;)V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_7

    .line 99
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_6
    iput-object v8, v1, Lorg/lighttouch/android/FirmwareService;->process:Ljava/lang/Process;

    .line 100
    invoke-virtual/range {v17 .. v17}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_5

    :goto_7
    invoke-virtual/range {v17 .. v17}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 102
    :cond_5
    invoke-static {v6}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 103
    nop

    .line 104
    return-void

    .line 99
    :catchall_7
    move-exception v0

    :goto_8
    iput-object v8, v1, Lorg/lighttouch/android/FirmwareService;->process:Ljava/lang/Process;

    .line 100
    invoke-virtual/range {v17 .. v17}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-virtual/range {v17 .. v17}, Landroid/os/PowerManager$WakeLock;->release()V

    .line 102
    :cond_6
    invoke-static {v6}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    throw v0
.end method

.method private final run(Ljava/io/File;Ljava/util/List;)V
    .locals 15
    .param p1, "libs"    # Ljava/io/File;
    .param p2, "args"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/File;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 111
    move-object/from16 v0, p1

    new-instance v1, Ljava/lang/ProcessBuilder;

    new-instance v2, Ljava/io/File;

    const-string v3, "libfirmwarekit.so"

    invoke-direct {v2, v0, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/Collection;

    move-object/from16 v3, p2

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/ProcessBuilder;-><init>(Ljava/util/List;)V

    .line 112
    new-instance v2, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/FirmwareService;->getCacheDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "firmwarekit.log"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 182
    move-object v3, v2

    .local v3, "$this$run_u24lambda_u243\\1":Ljava/io/File;
    const/4 v4, 0x0

    .line 112
    .local v4, "$i$a$-apply-FirmwareService$run$builder$1\\1\\112\\0":I
    invoke-virtual {v3}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v5

    if-eqz v5, :cond_0

    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    .end local v3    # "$this$run_u24lambda_u243\\1":Ljava/io/File;
    .end local v4    # "$i$a$-apply-FirmwareService$run$builder$1\\1\\112\\0":I
    :cond_0
    invoke-virtual {v1, v2}, Ljava/lang/ProcessBuilder;->redirectError(Ljava/io/File;)Ljava/lang/ProcessBuilder;

    move-result-object v1

    .line 111
    nop

    .line 113
    .local v1, "builder":Ljava/lang/ProcessBuilder;
    invoke-virtual {v1}, Ljava/lang/ProcessBuilder;->environment()Ljava/util/Map;

    move-result-object v2

    .local v2, "$this$run_u24lambda_u244\\2":Ljava/util/Map;
    const/4 v3, 0x0

    .line 114
    .local v3, "$i$a$-apply-FirmwareService$run$1\\2\\113\\0":I
    new-instance v4, Ljava/io/File;

    const-string v5, "libqemu-arm.so"

    invoke-direct {v4, v0, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, "LTM_QEMU_DYLIB"

    invoke-interface {v2, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    const-string v4, "LD_LIBRARY_PATH"

    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    invoke-virtual {p0}, Lorg/lighttouch/android/FirmwareService;->getFilesDir()Ljava/io/File;

    move-result-object v4

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, "HOME"

    invoke-interface {v2, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lorg/lighttouch/android/FirmwareService;->getCacheDir()Ljava/io/File;

    move-result-object v4

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    const-string v5, "TMPDIR"

    invoke-interface {v2, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    nop

    .line 113
    .end local v2    # "$this$run_u24lambda_u244\\2":Ljava/util/Map;
    .end local v3    # "$i$a$-apply-FirmwareService$run$1\\2\\113\\0":I
    nop

    .line 118
    iget-boolean v2, p0, Lorg/lighttouch/android/FirmwareService;->cancelling:Z

    const-string v3, "\u5df2\u53d6\u6d88"

    if-nez v2, :cond_7

    .line 119
    invoke-virtual {v1}, Ljava/lang/ProcessBuilder;->start()Ljava/lang/Process;

    move-result-object v2

    move-object v4, v2

    .line 182
    .local v4, "it\\4":Ljava/lang/Process;
    const/4 v5, 0x0

    .line 119
    .local v5, "$i$a$-also-FirmwareService$run$child$1\\4\\119\\0":I
    iput-object v4, p0, Lorg/lighttouch/android/FirmwareService;->process:Ljava/lang/Process;

    .line 120
    .end local v4    # "it\\4":Ljava/lang/Process;
    .end local v5    # "$i$a$-also-FirmwareService$run$child$1\\4\\119\\0":I
    .local v2, "child":Ljava/lang/Process;
    new-instance v4, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v4}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v10, v4

    .local v10, "weights":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v4

    iput-object v4, v10, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    new-instance v8, Lkotlin/jvm/internal/Ref$IntRef;

    invoke-direct {v8}, Lkotlin/jvm/internal/Ref$IntRef;-><init>()V

    .line 121
    .local v8, "step":Lkotlin/jvm/internal/Ref$IntRef;
    new-instance v11, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v11}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .local v11, "message":Lkotlin/jvm/internal/Ref$ObjectRef;
    const-string v4, ""

    iput-object v4, v11, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 122
    new-instance v6, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v6}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .local v6, "stepName":Lkotlin/jvm/internal/Ref$ObjectRef;
    iput-object v4, v6, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    new-instance v7, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v7}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    .line 124
    .local v7, "stepStarted":Lkotlin/jvm/internal/Ref$LongRef;
    invoke-virtual {v2}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    const-string v5, "getInputStream(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v5, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v9, Ljava/io/InputStreamReader;

    invoke-direct {v9, v4, v5}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v9, Ljava/io/Reader;

    instance-of v4, v9, Ljava/io/BufferedReader;

    if-eqz v4, :cond_1

    check-cast v9, Ljava/io/BufferedReader;

    goto :goto_0

    :cond_1
    new-instance v4, Ljava/io/BufferedReader;

    const/16 v5, 0x2000

    invoke-direct {v4, v9, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v9, v4

    :goto_0
    move-object v4, v9

    check-cast v4, Ljava/io/Reader;

    new-instance v5, Lorg/lighttouch/android/FirmwareService$$ExternalSyntheticLambda0;

    move-object v9, p0

    invoke-direct/range {v5 .. v11}, Lorg/lighttouch/android/FirmwareService$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$IntRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    invoke-static {v4, v5}, Lkotlin/io/TextStreamsKt;->forEachLine(Ljava/io/Reader;Lkotlin/jvm/functions/Function1;)V

    .line 140
    invoke-virtual {v2}, Ljava/lang/Process;->waitFor()I

    move-result v4

    .line 141
    .local v4, "exit":I
    invoke-static {v6, p0, v7}, Lorg/lighttouch/android/FirmwareService;->run$endStep(Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$LongRef;)V

    .line 142
    iget-boolean v5, p0, Lorg/lighttouch/android/FirmwareService;->cancelling:Z

    if-nez v5, :cond_6

    .line 143
    const/4 v3, 0x1

    const/4 v5, 0x0

    if-nez v4, :cond_2

    move v12, v3

    goto :goto_1

    :cond_2
    move v12, v5

    :goto_1
    if-nez v12, :cond_5

    .line 182
    const/4 v12, 0x0

    .line 143
    .local v12, "$i$a$-check-FirmwareService$run$5\\6\\143\\0":I
    iget-object v13, v11, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v13, Ljava/lang/CharSequence;

    invoke-interface {v13}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-nez v14, :cond_3

    goto :goto_2

    :cond_3
    move v3, v5

    :goto_2
    if-eqz v3, :cond_4

    .line 182
    const/4 v3, 0x0

    .line 143
    .local v3, "$i$a$-ifEmpty-FirmwareService$run$5$1\\7\\143\\6":I
    invoke-static/range {p2 .. p2}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v5

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "firmwarekit "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v13, " failed (exit "

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v13, ")"

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    .end local v3    # "$i$a$-ifEmpty-FirmwareService$run$5$1\\7\\143\\6":I
    .end local v12    # "$i$a$-check-FirmwareService$run$5\\6\\143\\0":I
    :cond_4
    new-instance v3, Ljava/lang/IllegalStateException;

    invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v3

    .line 144
    :cond_5
    return-void

    .line 182
    :cond_6
    const/4 v5, 0x0

    .line 142
    .local v5, "$i$a$-check-FirmwareService$run$4\\5\\142\\0":I
    nop

    .end local v5    # "$i$a$-check-FirmwareService$run$4\\5\\142\\0":I
    new-instance v5, Ljava/lang/IllegalStateException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v5, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 182
    .end local v2    # "child":Ljava/lang/Process;
    .end local v4    # "exit":I
    .end local v6    # "stepName":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v7    # "stepStarted":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v8    # "step":Lkotlin/jvm/internal/Ref$IntRef;
    .end local v10    # "weights":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local v11    # "message":Lkotlin/jvm/internal/Ref$ObjectRef;
    :cond_7
    const/4 v2, 0x0

    .line 118
    .local v2, "$i$a$-check-FirmwareService$run$2\\3\\118\\0":I
    nop

    .end local v2    # "$i$a$-check-FirmwareService$run$2\\3\\118\\0":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private static final run$endStep(Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$LongRef;)V
    .locals 6
    .param p0, "stepName"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p1, "this$0"    # Lorg/lighttouch/android/FirmwareService;
    .param p2, "stepStarted"    # Lkotlin/jvm/internal/Ref$LongRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/lang/String;",
            ">;",
            "Lorg/lighttouch/android/FirmwareService;",
            "Lkotlin/jvm/internal/Ref$LongRef;",
            ")V"
        }
    .end annotation

    .line 123
    iget-object v0, p0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    iget-object v0, p1, Lorg/lighttouch/android/FirmwareService;->timings:Ljava/lang/String;

    iget-object v1, p0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, p2, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    sub-long/2addr v2, v4

    const/16 v4, 0x64

    int-to-long v4, v4

    div-long/2addr v2, v4

    long-to-double v2, v2

    const-wide/high16 v4, 0x4024000000000000L    # 10.0

    div-double/2addr v2, v4

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\t"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p1, Lorg/lighttouch/android/FirmwareService;->timings:Ljava/lang/String;

    :cond_1
    return-void
.end method

.method private static final run$lambda$11(Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/internal/Ref$IntRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;)Lkotlin/Unit;
    .locals 21
    .param p0, "$stepName"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p1, "$stepStarted"    # Lkotlin/jvm/internal/Ref$LongRef;
    .param p2, "$step"    # Lkotlin/jvm/internal/Ref$IntRef;
    .param p3, "this$0"    # Lorg/lighttouch/android/FirmwareService;
    .param p4, "$weights"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p5, "$message"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p6, "line"    # Ljava/lang/String;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p6

    const-string v0, "line"

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 126
    .local v0, "event":Lorg/json/JSONObject;
    const-string v7, "event"

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_7

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v8

    const/4 v9, 0x0

    const-string v10, "optString(...)"

    const/4 v11, 0x1

    sparse-switch v8, :sswitch_data_0

    goto/16 :goto_2

    :sswitch_0
    const-string v8, "error"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_0

    goto/16 :goto_2

    .line 137
    :cond_0
    const-string v7, "message"

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v8, p5

    iput-object v7, v8, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    goto/16 :goto_2

    .line 126
    :sswitch_1
    move-object/from16 v8, p5

    const-string v10, "begin"

    invoke-virtual {v7, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_7

    .line 127
    const-string v7, "seconds"

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v7

    if-eqz v7, :cond_7

    .line 182
    .local v7, "a\\1":Lorg/json/JSONArray;
    const/4 v10, 0x0

    .line 127
    .local v10, "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v11

    invoke-static {v9, v11}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$map\\2":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 185
    .local v11, "$i$f$map\\2\\127":I
    new-instance v12, Ljava/util/ArrayList;

    const/16 v13, 0xa

    invoke-static {v9, v13}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v12, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\3":Ljava/util/Collection;
    move-object v13, v9

    .local v13, "$this$mapTo\\3":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 186
    .local v14, "$i$f$mapTo\\3\\185":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_0
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_1

    move-object/from16 v16, v15

    check-cast v16, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v16 .. v16}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v16

    .line 187
    .local v16, "item\\3":I
    move/from16 v17, v16

    .local v17, "it\\4":I
    const/16 v18, 0x0

    .line 127
    .local v18, "$i$a$-map-FirmwareService$run$3$1$1\\4\\187\\1":I
    move-object/from16 v19, v9

    .end local v9    # "$this$map\\2":Ljava/lang/Iterable;
    .local v19, "$this$map\\2":Ljava/lang/Iterable;
    const-wide/16 v8, 0x1

    move/from16 v20, v11

    move/from16 v6, v17

    move/from16 v17, v10

    .end local v10    # "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    .end local v11    # "$i$f$map\\2\\127":I
    .local v6, "it\\4":I
    .local v17, "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    .local v20, "$i$f$map\\2\\127":I
    invoke-virtual {v7, v6}, Lorg/json/JSONArray;->getLong(I)J

    move-result-wide v10

    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v8

    const/16 v10, 0x3e8

    int-to-long v10, v10

    mul-long/2addr v8, v10

    .end local v6    # "it\\4":I
    .end local v18    # "$i$a$-map-FirmwareService$run$3$1$1\\4\\187\\1":I
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    .line 187
    invoke-interface {v12, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v8, p5

    move-object/from16 v6, p6

    move/from16 v10, v17

    move-object/from16 v9, v19

    move/from16 v11, v20

    goto :goto_0

    .line 188
    .end local v16    # "item\\3":I
    .end local v17    # "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    .end local v19    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v20    # "$i$f$map\\2\\127":I
    .restart local v9    # "$this$map\\2":Ljava/lang/Iterable;
    .restart local v10    # "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    .restart local v11    # "$i$f$map\\2\\127":I
    :cond_1
    move-object/from16 v19, v9

    move/from16 v17, v10

    move/from16 v20, v11

    .end local v9    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v10    # "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    .end local v11    # "$i$f$map\\2\\127":I
    .end local v12    # "destination\\3":Ljava/util/Collection;
    .end local v13    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v14    # "$i$f$mapTo\\3\\185":I
    .restart local v17    # "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    .restart local v19    # "$this$map\\2":Ljava/lang/Iterable;
    .restart local v20    # "$i$f$map\\2\\127":I
    move-object v6, v12

    check-cast v6, Ljava/util/List;

    .line 185
    nop

    .line 127
    .end local v19    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v20    # "$i$f$map\\2\\127":I
    iput-object v6, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    iget-object v6, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->sumOfLong(Ljava/lang/Iterable;)J

    move-result-wide v8

    iput-wide v8, v4, Lorg/lighttouch/android/FirmwareService;->total:J

    .end local v7    # "a\\1":Lorg/json/JSONArray;
    .end local v17    # "$i$a$-let-FirmwareService$run$3$1\\1\\127\\0":I
    goto/16 :goto_2

    .line 126
    :sswitch_2
    const-string v6, "step"

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2

    goto/16 :goto_2

    .line 129
    :cond_2
    invoke-static {v1, v4, v2}, Lorg/lighttouch/android/FirmwareService;->run$endStep(Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/FirmwareService;Lkotlin/jvm/internal/Ref$LongRef;)V

    const-string v6, "name"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v6, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iput-wide v6, v2, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 130
    const-string v6, "index"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v6

    iput v6, v3, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    iget-object v6, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    iput-object v6, v4, Lorg/lighttouch/android/FirmwareService;->stage:Ljava/lang/String;

    iget-object v6, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Iterable;

    iget v7, v3, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    sub-int/2addr v7, v11

    invoke-static {v6, v7}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->sumOfLong(Ljava/lang/Iterable;)J

    move-result-wide v6

    iput-wide v6, v4, Lorg/lighttouch/android/FirmwareService;->done:J

    goto :goto_2

    .line 126
    :sswitch_3
    const-string v6, "progress"

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3

    goto :goto_2

    .line 133
    :cond_3
    iget v6, v3, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    if-lez v6, :cond_4

    iget v6, v3, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    iget-object v7, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v7, Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-gt v6, v7, :cond_4

    iget-object v6, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Iterable;

    iget v7, v3, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    sub-int/2addr v7, v11

    invoke-static {v6, v7}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->sumOfLong(Ljava/lang/Iterable;)J

    move-result-wide v6

    const-string v8, "fraction"

    const-wide/16 v12, 0x0

    invoke-virtual {v0, v8, v12, v13}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    move-result-wide v12

    iget-object v8, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v8, Ljava/util/List;

    iget v10, v3, Lkotlin/jvm/internal/Ref$IntRef;->element:I

    sub-int/2addr v10, v11

    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v14

    mul-double/2addr v12, v14

    double-to-long v12, v12

    add-long/2addr v6, v12

    iput-wide v6, v4, Lorg/lighttouch/android/FirmwareService;->done:J

    .line 135
    :cond_4
    const-string v6, "detail"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object v7, v6

    .line 182
    .local v7, "it\\5":Ljava/lang/String;
    const/4 v8, 0x0

    .line 135
    .local v8, "$i$a$-takeIf-FirmwareService$run$3$2\\5\\135\\0":I
    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v10, v7

    check-cast v10, Ljava/lang/CharSequence;

    invoke-interface {v10}, Ljava/lang/CharSequence;->length()I

    move-result v10

    if-lez v10, :cond_5

    move v9, v11

    .end local v7    # "it\\5":Ljava/lang/String;
    .end local v8    # "$i$a$-takeIf-FirmwareService$run$3$2\\5\\135\\0":I
    :cond_5
    if-eqz v9, :cond_6

    goto :goto_1

    :cond_6
    const/4 v6, 0x0

    :goto_1
    if-eqz v6, :cond_7

    .line 182
    .local v6, "it\\6":Ljava/lang/String;
    const/4 v7, 0x0

    .line 135
    .local v7, "$i$a$-let-FirmwareService$run$3$3\\6\\135\\0":I
    iput-object v6, v4, Lorg/lighttouch/android/FirmwareService;->stage:Ljava/lang/String;

    .line 139
    .end local v6    # "it\\6":Ljava/lang/String;
    .end local v7    # "$i$a$-let-FirmwareService$run$3$3\\6\\135\\0":I
    :cond_7
    :goto_2
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v6

    .line 125
    .end local v0    # "event":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v6

    :sswitch_data_0
    .sparse-switch
        -0x3bab3dd3 -> :sswitch_3
        0x3606cc -> :sswitch_2
        0x59478a9 -> :sswitch_1
        0x5c4d208 -> :sswitch_0
    .end sparse-switch
.end method

.method private final writable(Ljava/io/File;)V
    .locals 7
    .param p1, "root"    # Ljava/io/File;

    .line 150
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p1}, Lkotlin/io/FilesKt;->walkTopDown(Ljava/io/File;)Lkotlin/io/FileTreeWalk;

    move-result-object v0

    check-cast v0, Lkotlin/sequences/Sequence;

    .local v0, "$this$forEach\\1":Lkotlin/sequences/Sequence;
    const/4 v1, 0x0

    .line 183
    .local v1, "$i$f$forEach\\1\\150":I
    invoke-interface {v0}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Ljava/io/File;

    .local v4, "it\\2":Ljava/io/File;
    const/4 v5, 0x0

    .line 150
    .local v5, "$i$a$-forEach-FirmwareService$writable$1\\2\\183\\0":I
    const/4 v6, 0x1

    invoke-virtual {v4, v6, v6}, Ljava/io/File;->setWritable(ZZ)Z

    .line 183
    .end local v4    # "it\\2":Ljava/io/File;
    .end local v5    # "$i$a$-forEach-FirmwareService$writable$1\\2\\183\\0":I
    nop

    .end local v3    # "element\\1":Ljava/lang/Object;
    goto :goto_0

    .line 184
    :cond_0
    nop

    .line 150
    .end local v0    # "$this$forEach\\1":Lkotlin/sequences/Sequence;
    .end local v1    # "$i$f$forEach\\1\\150":I
    :cond_1
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    const-string v0, "intent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 152
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->binder:Lorg/lighttouch/android/FirmwareService$binder$1;

    check-cast v0, Landroid/os/IBinder;

    return-object v0
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 2
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 154
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService;->state:Ljava/lang/String;

    const-string v1, "complete"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "\u8bbe\u5907\u5df2\u51c6\u5907\u5b8c\u6210\uff0c\u6253\u5f00 LightTouch \u5373\u53ef\u6dfb\u52a0\u3002"

    goto :goto_0

    :cond_0
    const-string v0, "\u6b63\u5728\u51c6\u5907\u8bbe\u5907\uff1b\u8fd4\u56de\u5e94\u7528\u53ef\u67e5\u770b\u8fdb\u5ea6\u6216\u53d6\u6d88"

    :goto_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/FirmwareService;->foreground(Ljava/lang/String;)V

    .line 155
    const/4 v0, 0x2

    return v0
.end method

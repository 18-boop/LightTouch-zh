.class final Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;
.super Ljava/lang/Object;
.source "DeviceDetails.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeviceDetails.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeviceDetails.kt\norg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,189:1\n1#2:190\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $f:Lorg/lighttouch/android/DeviceFacts;

.field final synthetic $space$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceFacts$Space;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lorg/lighttouch/android/DeviceFacts;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/DeviceFacts;",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceFacts$Space;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;->$f:Lorg/lighttouch/android/DeviceFacts;

    iput-object p2, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;->$space$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 147
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 6
    .param p1, "$this$Section"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$Section"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C:DeviceDetails.kt#o13vsk"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    if-ne v0, v1, :cond_1

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 150
    :cond_0
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_5

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, -0x1

    const-string v1, "org.lighttouch.android.DeviceDetails.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DeviceDetails.kt:147)"

    const v2, 0x75c43ae3

    invoke-static {v2, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 148
    :cond_2
    iget-object v0, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;->$f:Lorg/lighttouch/android/DeviceFacts;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts;->getFlashBytes()Ljava/lang/Long;

    move-result-object v0

    goto :goto_1

    :cond_3
    const/4 v0, 0x0

    :goto_1
    const v1, 0x15a1137b

    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "*147@9288L48"

    invoke-static {p2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v1, 0x6

    if-nez v0, :cond_4

    goto :goto_2

    :cond_4
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .line 190
    .local v2, "it\\1":J
    const/4 v0, 0x0

    .line 148
    .local v0, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$3$1\\1\\148\\0":I
    invoke-static {v2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->formatBytes(J)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " \u95ea\u5b58"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "\u78c1\u76d8\u5bb9\u91cf"

    invoke-static {v5, v4, p2, v1}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .end local v0    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$3$1\\1\\148\\0":I
    .end local v2    # "it\\1":J
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_2
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 149
    iget-object v0, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;->$space$delegate:Landroidx/compose/runtime/MutableState;

    invoke-static {v0}, Lorg/lighttouch/android/DeviceDetailsKt;->access$DeviceDetails$lambda$4(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/DeviceFacts$Space;

    move-result-object v0

    .line 150
    .local v0, "u":Lorg/lighttouch/android/DeviceFacts$Space;
    const-string v2, "\u672c\u673a\u5360\u7528"

    if-nez v0, :cond_5

    const v1, 0x15a12426

    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "149@9416L35"

    invoke-static {p2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v1, "\u6b63\u5728\u7edf\u8ba1\u2026"

    const/16 v3, 0x36

    invoke-static {v2, v1, p2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    :goto_3
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_4

    :cond_5
    const v3, -0x617bd948

    invoke-interface {p2, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "150@9487L48,151@9564L49,152@9642L55,153@9746L44"

    invoke-static {p2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 151
    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts$Space;->getTotalBytes()J

    move-result-wide v3

    invoke-static {v3, v4}, Lorg/lighttouch/android/DeviceDetailsKt;->formatBytes(J)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3, p2, v1}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 152
    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts$Space;->getBaseBytes()J

    move-result-wide v2

    invoke-static {v2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->formatBytes(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u5df2\u51c6\u5907\u7cfb\u7edf"

    invoke-static {v3, v2, p2, v1}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 153
    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts$Space;->getChangesBytes()J

    move-result-wide v2

    invoke-static {v2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->formatBytes(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u6b64\u540e\u6539\u52a8"

    invoke-static {v3, v2, p2, v1}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 154
    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts$Space;->getLogBytes()J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-lez v2, :cond_6

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts$Space;->getLogBytes()J

    move-result-wide v2

    invoke-static {v2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->formatBytes(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u5f15\u64ce\u65e5\u5fd7"

    invoke-static {v3, v2, p2, v1}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 150
    :cond_6
    goto :goto_3

    :goto_4
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 156
    .end local v0    # "u":Lorg/lighttouch/android/DeviceFacts$Space;
    :cond_7
    :goto_5
    return-void
.end method

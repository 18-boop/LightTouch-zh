.class public final Lorg/lighttouch/android/StoreBrowser;
.super Ljava/lang/Object;
.source "StoreBrowse.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/StoreBrowser$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreBrowse.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreBrowse.kt\norg/lighttouch/android/StoreBrowser\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,355:1\n81#2:356\n107#2,2:357\n81#2:359\n107#2,2:360\n81#2:362\n107#2,2:363\n81#2:365\n107#2,2:366\n81#2:368\n107#2,2:369\n81#2:371\n107#2,2:372\n81#2:374\n107#2,2:375\n81#2:377\n107#2,2:378\n81#2:380\n107#2,2:381\n81#2:383\n107#2,2:384\n81#2:386\n107#2,2:387\n81#2:389\n107#2,2:390\n81#2:392\n107#2,2:393\n81#2:395\n107#2,2:396\n1#3:398\n*S KotlinDebug\n*F\n+ 1 StoreBrowse.kt\norg/lighttouch/android/StoreBrowser\n*L\n57#1:356\n57#1:357,2\n64#1:359\n64#1:360,2\n65#1:362\n65#1:363,2\n66#1:365\n66#1:366,2\n67#1:368\n67#1:369,2\n68#1:371\n68#1:372,2\n69#1:374\n69#1:375,2\n77#1:377\n77#1:378,2\n78#1:380\n78#1:381,2\n79#1:383\n79#1:384,2\n80#1:386\n80#1:387,2\n83#1:389\n83#1:390,2\n84#1:392\n84#1:393,2\n85#1:395\n85#1:396,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000|\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u000e\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u000c\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0010 \n\u0002\u0008\u0014\n\u0002\u0018\u0002\n\u0002\u0008\u0011\n\u0002\u0010\u0002\n\u0002\u0008\u000c\n\u0002\u0018\u0002\n\u0002\u0008\u0019\u0008\u0001\u0018\u00002\u00020\u0001B\u0017\u0012\u000e\u0010\u0002\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u001e\u0010o\u001a\u00020p2\u0006\u0010q\u001a\u00020\u001e2\u000c\u0010r\u001a\u0008\u0012\u0004\u0012\u00020p0\u0003H\u0002J\u0016\u0010s\u001a\u0002072\u000c\u0010r\u001a\u0008\u0012\u0004\u0012\u00020p0\u0003H\u0002J\u0006\u0010v\u001a\u00020pJ\u0006\u0010w\u001a\u00020pJ\u000e\u0010x\u001a\u00020p2\u0006\u0010y\u001a\u00020\nJ&\u0010z\u001a\u00020p2\u0006\u0010{\u001a\u00020\u00132\u0006\u0010w\u001a\u0002072\u000c\u0010|\u001a\u0008\u0012\u0004\u0012\u00020}0\u0003H\u0002J\u000e\u0010~\u001a\u00020p2\u0006\u0010{\u001a\u00020\u0013J\u0006\u0010\u007f\u001a\u00020pJ\u000b\u0010\u0080\u0001\u001a\u0004\u0018\u00010\u001eH\u0002J\u0014\u0010\u0081\u0001\u001a\u00020p2\u000b\u0008\u0002\u0010\u0082\u0001\u001a\u0004\u0018\u00010\u001eJ\u0010\u0010\u0083\u0001\u001a\u00020p2\u0007\u0010\u0084\u0001\u001a\u00020\u001eJ\u0010\u0010\u0085\u0001\u001a\u00020p2\u0007\u0010\u0086\u0001\u001a\u00020\u001eJ\u0012\u0010\u0087\u0001\u001a\u00020p2\t\u0010\u0088\u0001\u001a\u0004\u0018\u00010)J\u0010\u0010\u0089\u0001\u001a\u00020p2\u0007\u0010\u008a\u0001\u001a\u00020\u001eJ\u0010\u0010\u008b\u0001\u001a\u00020p2\u0007\u0010\u008c\u0001\u001a\u00020DJ\u0007\u0010\u008d\u0001\u001a\u00020pJ\u0010\u0010\u008e\u0001\u001a\u00020p2\u0007\u0010\u0088\u0001\u001a\u00020)J\u0010\u0010\u008f\u0001\u001a\u00020p2\u0007\u0010\u0090\u0001\u001a\u00020\u001eJ\t\u0010\u0091\u0001\u001a\u00020pH\u0002J\t\u0010\u0092\u0001\u001a\u00020pH\u0002J\u0010\u0010\u0093\u0001\u001a\u00020p2\u0007\u0010\u0094\u0001\u001a\u00020^J\u0007\u0010\u0095\u0001\u001a\u00020pR\u0016\u0010\u0002\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R+\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\n8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0010\u0010\u0011\u001a\u0004\u0008\u000c\u0010\r\"\u0004\u0008\u000e\u0010\u000fR\u0011\u0010\u0012\u001a\u00020\u0013\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0011\u0010\u0016\u001a\u00020\u0017\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0018\u0010\u0019R\u0011\u0010\u001a\u001a\u00020\u0017\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001b\u0010\u0019R\u0011\u0010\u001c\u001a\u00020\u0017\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u0019R+\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\t\u001a\u00020\u001e8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008$\u0010\u0011\u001a\u0004\u0008 \u0010!\"\u0004\u0008\"\u0010#R/\u0010%\u001a\u0004\u0018\u00010\u001e2\u0008\u0010\t\u001a\u0004\u0018\u00010\u001e8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008(\u0010\u0011\u001a\u0004\u0008&\u0010!\"\u0004\u0008\'\u0010#R/\u0010*\u001a\u0004\u0018\u00010)2\u0008\u0010\t\u001a\u0004\u0018\u00010)8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008/\u0010\u0011\u001a\u0004\u0008+\u0010,\"\u0004\u0008-\u0010.R/\u00101\u001a\u0004\u0018\u0001002\u0008\u0010\t\u001a\u0004\u0018\u0001008F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u00086\u0010\u0011\u001a\u0004\u00082\u00103\"\u0004\u00084\u00105R+\u00108\u001a\u0002072\u0006\u0010\t\u001a\u0002078F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008=\u0010\u0011\u001a\u0004\u00089\u0010:\"\u0004\u0008;\u0010<R/\u0010>\u001a\u0004\u0018\u00010\u001e2\u0008\u0010\t\u001a\u0004\u0018\u00010\u001e8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008A\u0010\u0011\u001a\u0004\u0008?\u0010!\"\u0004\u0008@\u0010#R\u0010\u0010B\u001a\u0004\u0018\u00010\u001eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020DX\u0082\u000e\u00a2\u0006\u0002\n\u0000R$\u0010F\u001a\u00020\u001e2\u0006\u0010E\u001a\u00020\u001e8F@FX\u0086\u000e\u00a2\u0006\u000c\u001a\u0004\u0008G\u0010!\"\u0004\u0008H\u0010#R;\u0010J\u001a\n\u0012\u0004\u0012\u00020)\u0018\u00010I2\u000e\u0010\t\u001a\n\u0012\u0004\u0012\u00020)\u0018\u00010I8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008O\u0010\u0011\u001a\u0004\u0008K\u0010L\"\u0004\u0008M\u0010NR/\u0010P\u001a\u0004\u0018\u00010\u001e2\u0008\u0010\t\u001a\u0004\u0018\u00010\u001e8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008S\u0010\u0011\u001a\u0004\u0008Q\u0010!\"\u0004\u0008R\u0010#R/\u0010T\u001a\u0004\u0018\u00010)2\u0008\u0010\t\u001a\u0004\u0018\u00010)8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008W\u0010\u0011\u001a\u0004\u0008U\u0010,\"\u0004\u0008V\u0010.R+\u0010X\u001a\u00020\u001e2\u0006\u0010\t\u001a\u00020\u001e8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008[\u0010\u0011\u001a\u0004\u0008Y\u0010!\"\u0004\u0008Z\u0010#R\u0011\u0010\\\u001a\u00020\u0013\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008]\u0010\u0015R;\u0010_\u001a\n\u0012\u0004\u0012\u00020^\u0018\u00010I2\u000e\u0010\t\u001a\n\u0012\u0004\u0012\u00020^\u0018\u00010I8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008b\u0010\u0011\u001a\u0004\u0008`\u0010L\"\u0004\u0008a\u0010NR/\u0010c\u001a\u0004\u0018\u00010\u001e2\u0008\u0010\t\u001a\u0004\u0018\u00010\u001e8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008f\u0010\u0011\u001a\u0004\u0008d\u0010!\"\u0004\u0008e\u0010#R/\u0010g\u001a\u0004\u0018\u00010^2\u0008\u0010\t\u001a\u0004\u0018\u00010^8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008l\u0010\u0011\u001a\u0004\u0008h\u0010i\"\u0004\u0008j\u0010kR\u0011\u0010m\u001a\u00020\u0013\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008n\u0010\u0015R\u0011\u0010t\u001a\u0002078F\u00a2\u0006\u0006\u001a\u0004\u0008u\u0010:\u00a8\u0006\u0096\u0001"
    }
    d2 = {
        "Lorg/lighttouch/android/StoreBrowser;",
        "",
        "target",
        "Lkotlin/Function0;",
        "Lorg/lighttouch/android/StoreTarget;",
        "<init>",
        "(Lkotlin/jvm/functions/Function0;)V",
        "handler",
        "Landroid/os/Handler;",
        "<set-?>",
        "Lorg/lighttouch/android/StoreTab;",
        "tab",
        "getTab",
        "()Lorg/lighttouch/android/StoreTab;",
        "setTab",
        "(Lorg/lighttouch/android/StoreTab;)V",
        "tab$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "featured",
        "Lorg/lighttouch/android/Listing;",
        "getFeatured",
        "()Lorg/lighttouch/android/Listing;",
        "chartList",
        "Landroidx/compose/foundation/lazy/LazyListState;",
        "getChartList",
        "()Landroidx/compose/foundation/lazy/LazyListState;",
        "genreList",
        "getGenreList",
        "collectionList",
        "getCollectionList",
        "",
        "chartType",
        "getChartType",
        "()Ljava/lang/String;",
        "setChartType",
        "(Ljava/lang/String;)V",
        "chartType$delegate",
        "chartDeviceChoice",
        "getChartDeviceChoice",
        "setChartDeviceChoice",
        "chartDeviceChoice$delegate",
        "Lorg/lighttouch/android/StoreGenre;",
        "chartGenre",
        "getChartGenre",
        "()Lorg/lighttouch/android/StoreGenre;",
        "setChartGenre",
        "(Lorg/lighttouch/android/StoreGenre;)V",
        "chartGenre$delegate",
        "Lorg/lighttouch/android/StoreChart;",
        "chart",
        "getChart",
        "()Lorg/lighttouch/android/StoreChart;",
        "setChart",
        "(Lorg/lighttouch/android/StoreChart;)V",
        "chart$delegate",
        "",
        "chartLoading",
        "getChartLoading",
        "()Z",
        "setChartLoading",
        "(Z)V",
        "chartLoading$delegate",
        "chartError",
        "getChartError",
        "setChartError",
        "chartError$delegate",
        "chartDate",
        "chartGeneration",
        "",
        "value",
        "chartDevice",
        "getChartDevice",
        "setChartDevice",
        "",
        "genres",
        "getGenres",
        "()Ljava/util/List;",
        "setGenres",
        "(Ljava/util/List;)V",
        "genres$delegate",
        "genresError",
        "getGenresError",
        "setGenresError",
        "genresError$delegate",
        "category",
        "getCategory",
        "setCategory",
        "category$delegate",
        "categorySort",
        "getCategorySort",
        "setCategorySort",
        "categorySort$delegate",
        "categoryApps",
        "getCategoryApps",
        "Lorg/lighttouch/android/StoreCollection;",
        "collections",
        "getCollections",
        "setCollections",
        "collections$delegate",
        "collectionsError",
        "getCollectionsError",
        "setCollectionsError",
        "collectionsError$delegate",
        "collection",
        "getCollection",
        "()Lorg/lighttouch/android/StoreCollection;",
        "setCollection",
        "(Lorg/lighttouch/android/StoreCollection;)V",
        "collection$delegate",
        "collectionApps",
        "getCollectionApps",
        "background",
        "",
        "name",
        "work",
        "post",
        "canGoBack",
        "getCanGoBack",
        "back",
        "reset",
        "show",
        "next",
        "load",
        "listing",
        "fetch",
        "Lorg/lighttouch/android/StorePage;",
        "more",
        "loadFeatured",
        "eraDate",
        "loadChart",
        "date",
        "pickChartType",
        "slug",
        "pickChartDevice",
        "device",
        "pickChartGenre",
        "genre",
        "pickChartYear",
        "year",
        "shiftChart",
        "delta",
        "loadGenres",
        "openCategory",
        "pickCategorySort",
        "sort",
        "loadCategory",
        "loadCollections",
        "openCollection",
        "item",
        "retryCollections",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final category$delegate:Landroidx/compose/runtime/MutableState;

.field private final categoryApps:Lorg/lighttouch/android/Listing;

.field private final categorySort$delegate:Landroidx/compose/runtime/MutableState;

.field private final chart$delegate:Landroidx/compose/runtime/MutableState;

.field private chartDate:Ljava/lang/String;

.field private final chartDeviceChoice$delegate:Landroidx/compose/runtime/MutableState;

.field private final chartError$delegate:Landroidx/compose/runtime/MutableState;

.field private chartGeneration:I

.field private final chartGenre$delegate:Landroidx/compose/runtime/MutableState;

.field private final chartList:Landroidx/compose/foundation/lazy/LazyListState;

.field private final chartLoading$delegate:Landroidx/compose/runtime/MutableState;

.field private final chartType$delegate:Landroidx/compose/runtime/MutableState;

.field private final collection$delegate:Landroidx/compose/runtime/MutableState;

.field private final collectionApps:Lorg/lighttouch/android/Listing;

.field private final collectionList:Landroidx/compose/foundation/lazy/LazyListState;

.field private final collections$delegate:Landroidx/compose/runtime/MutableState;

.field private final collectionsError$delegate:Landroidx/compose/runtime/MutableState;

.field private final featured:Lorg/lighttouch/android/Listing;

.field private final genreList:Landroidx/compose/foundation/lazy/LazyListState;

.field private final genres$delegate:Landroidx/compose/runtime/MutableState;

.field private final genresError$delegate:Landroidx/compose/runtime/MutableState;

.field private final handler:Landroid/os/Handler;

.field private final tab$delegate:Landroidx/compose/runtime/MutableState;

.field private final target:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lorg/lighttouch/android/StoreTarget;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$1usFqK4Ck5AnmC-SIMK5UqwvP74(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->loadGenres$lambda$20$lambda$19(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$3ZX5iMaajshCsfaH5xh1ZxmRXuA(ILorg/lighttouch/android/StoreBrowser;Ljava/lang/Object;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreBrowser;->loadChart$lambda$14$lambda$13(ILorg/lighttouch/android/StoreBrowser;Ljava/lang/Object;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4ZMk0YtxYBBU1FDZvBlRVlY26uA(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowser;->more$lambda$7$lambda$6(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4ftD0rwqIdVlI3fwcOOczK4Iccg(Lorg/lighttouch/android/StoreCollection;)Lorg/lighttouch/android/StorePage;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowser;->openCollection$lambda$27(Lorg/lighttouch/android/StoreCollection;)Lorg/lighttouch/android/StorePage;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$E7xDY7L_0WOhYntTRLaE7AefLnM(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowser;->loadCollections$lambda$26(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$H_p8iVZlYQL8WlDhRqOk9poZ9o4(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowser;->loadGenres$lambda$20(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JST8En9KAcFhwYe_bax6Hiksgi0(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->loadCollections$lambda$26$lambda$25(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KnzxjAcRHycZAYl_VF5UXWVj8G4(Lorg/lighttouch/android/StoreGenre;Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->loadCategory$lambda$21(Lorg/lighttouch/android/StoreGenre;Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$QFQoW6FirPDOMw7QO_aupQXjtEg(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/StoreBrowser;ILorg/lighttouch/android/Listing;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowser;->load$lambda$5(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/StoreBrowser;ILorg/lighttouch/android/Listing;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_2Ri-M4IeMA45mWuBK3c4hzi6EY()Lorg/lighttouch/android/StorePage;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/StoreBrowser;->loadFeatured$lambda$8()Lorg/lighttouch/android/StorePage;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$qV7by8AD96r3fTlSfyWBQ36djG8(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowser;->post$lambda$1(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$wWwXuVbCx-WHTSAVRobT2ZRYIYU(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/StoreBrowser;->loadChart$lambda$14(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$yj3tFFFQ0KC525R3n5PH6H24VEM(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowser;->background$lambda$0(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zRkgd93rPQ-8XS8WMtbCuS7IBR4(ILorg/lighttouch/android/Listing;Ljava/lang/Object;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreBrowser;->load$lambda$5$lambda$4(ILorg/lighttouch/android/Listing;Ljava/lang/Object;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/StoreBrowser;->$stable:I

    return-void
.end method

.method public constructor <init>(Lkotlin/jvm/functions/Function0;)V
    .locals 5
    .param p1, "target"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lorg/lighttouch/android/StoreTarget;",
            ">;)V"
        }
    .end annotation

    const-string v0, "target"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/StoreBrowser;->target:Lkotlin/jvm/functions/Function0;

    .line 56
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->handler:Landroid/os/Handler;

    .line 57
    sget-object v0, Lorg/lighttouch/android/StoreTab;->DEVICE:Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->tab$delegate:Landroidx/compose/runtime/MutableState;

    .line 59
    new-instance v0, Lorg/lighttouch/android/Listing;

    invoke-direct {v0}, Lorg/lighttouch/android/Listing;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->featured:Lorg/lighttouch/android/Listing;

    .line 60
    new-instance v0, Landroidx/compose/foundation/lazy/LazyListState;

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v0, v3, v3, v4, v1}, Landroidx/compose/foundation/lazy/LazyListState;-><init>(IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartList:Landroidx/compose/foundation/lazy/LazyListState;

    .line 61
    new-instance v0, Landroidx/compose/foundation/lazy/LazyListState;

    invoke-direct {v0, v3, v3, v4, v1}, Landroidx/compose/foundation/lazy/LazyListState;-><init>(IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genreList:Landroidx/compose/foundation/lazy/LazyListState;

    .line 62
    new-instance v0, Landroidx/compose/foundation/lazy/LazyListState;

    invoke-direct {v0, v3, v3, v4, v1}, Landroidx/compose/foundation/lazy/LazyListState;-><init>(IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionList:Landroidx/compose/foundation/lazy/LazyListState;

    .line 64
    const-string v0, "top-free"

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartType$delegate:Landroidx/compose/runtime/MutableState;

    .line 65
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartDeviceChoice$delegate:Landroidx/compose/runtime/MutableState;

    .line 66
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGenre$delegate:Landroidx/compose/runtime/MutableState;

    .line 67
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chart$delegate:Landroidx/compose/runtime/MutableState;

    .line 68
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartLoading$delegate:Landroidx/compose/runtime/MutableState;

    .line 69
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartError$delegate:Landroidx/compose/runtime/MutableState;

    .line 77
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genres$delegate:Landroidx/compose/runtime/MutableState;

    .line 78
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genresError$delegate:Landroidx/compose/runtime/MutableState;

    .line 79
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->category$delegate:Landroidx/compose/runtime/MutableState;

    .line 80
    const-string v0, "versions"

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->categorySort$delegate:Landroidx/compose/runtime/MutableState;

    .line 81
    new-instance v0, Lorg/lighttouch/android/Listing;

    invoke-direct {v0}, Lorg/lighttouch/android/Listing;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->categoryApps:Lorg/lighttouch/android/Listing;

    .line 83
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collections$delegate:Landroidx/compose/runtime/MutableState;

    .line 84
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionsError$delegate:Landroidx/compose/runtime/MutableState;

    .line 85
    invoke-static {v1, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collection$delegate:Landroidx/compose/runtime/MutableState;

    .line 86
    new-instance v0, Lorg/lighttouch/android/Listing;

    invoke-direct {v0}, Lorg/lighttouch/android/Listing;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionApps:Lorg/lighttouch/android/Listing;

    .line 55
    return-void
.end method

.method private final background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 2
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "work"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 88
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda10;

    invoke-direct {v1, p2}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda10;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-direct {v0, v1, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static final background$lambda$0(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 88
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private final eraDate()Ljava/lang/String;
    .locals 4

    .line 138
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->target:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/StoreTarget;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/16 v2, 0x2e

    const/4 v3, 0x2

    invoke-static {v0, v2, v1, v3, v1}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v0}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 398
    .local v0, "it\\1":I
    const/4 v1, 0x0

    .line 138
    .local v1, "$i$a$-let-StoreBrowser$eraDate$1\\1\\138\\0":I
    add-int/lit16 v2, v0, 0x7d7

    const/16 v3, 0x7e9

    invoke-static {v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "-07-01"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v0    # "it\\1":I
    .end local v1    # "$i$a$-let-StoreBrowser$eraDate$1\\1\\138\\0":I
    :cond_0
    return-object v1
.end method

.method private final getChartDeviceChoice()Ljava/lang/String;
    .locals 3

    .line 65
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartDeviceChoice$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 362
    .local v2, "$i$f$getValue\\1\\65":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\65":I
    check-cast v0, Ljava/lang/String;

    .line 65
    return-object v0
.end method

.method private final load(Lorg/lighttouch/android/Listing;ZLkotlin/jvm/functions/Function0;)V
    .locals 8
    .param p1, "listing"    # Lorg/lighttouch/android/Listing;
    .param p2, "reset"    # Z
    .param p3, "fetch"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/Listing;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lorg/lighttouch/android/StorePage;",
            ">;)V"
        }
    .end annotation

    .line 114
    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getLoading()Z

    move-result v0

    if-eqz v0, :cond_0

    if-nez p2, :cond_0

    return-void

    .line 115
    :cond_0
    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getGeneration()I

    move-result v0

    const/4 v1, 0x1

    add-int/2addr v0, v1

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/Listing;->setGeneration(I)V

    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getGeneration()I

    move-result v5

    .line 116
    .local v5, "generation":I
    const/4 v0, 0x0

    if-eqz p2, :cond_1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/Listing;->setRows(Ljava/util/List;)V

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/Listing;->setNext(Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/Listing;->setTotal(I)V

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/Listing;->setLoaded(Z)V

    .line 117
    :cond_1
    invoke-virtual {p1, v1}, Lorg/lighttouch/android/Listing;->setLoading(Z)V

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/Listing;->setError(Ljava/lang/String;)V

    .line 118
    new-instance v2, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda0;

    move-object v4, p0

    move-object v6, p1

    move v7, p2

    move-object v3, p3

    .end local p1    # "listing":Lorg/lighttouch/android/Listing;
    .end local p2    # "reset":Z
    .end local p3    # "fetch":Lkotlin/jvm/functions/Function0;
    .local v3, "fetch":Lkotlin/jvm/functions/Function0;
    .local v6, "listing":Lorg/lighttouch/android/Listing;
    .local v7, "reset":Z
    invoke-direct/range {v2 .. v7}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/StoreBrowser;ILorg/lighttouch/android/Listing;Z)V

    const-string p1, "store-browse"

    invoke-direct {p0, p1, v2}, Lorg/lighttouch/android/StoreBrowser;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 130
    return-void
.end method

.method private static final load$lambda$5(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/StoreBrowser;ILorg/lighttouch/android/Listing;Z)Lkotlin/Unit;
    .locals 2
    .param p0, "$fetch"    # Lkotlin/jvm/functions/Function0;
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreBrowser;
    .param p2, "$generation"    # I
    .param p3, "$listing"    # Lorg/lighttouch/android/Listing;
    .param p4, "$reset"    # Z

    .line 119
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 120
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda4;

    invoke-direct {v1, p2, p3, v0, p4}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda4;-><init>(ILorg/lighttouch/android/Listing;Ljava/lang/Object;Z)V

    invoke-direct {p1, v1}, Lorg/lighttouch/android/StoreBrowser;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 129
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final load$lambda$5$lambda$4(ILorg/lighttouch/android/Listing;Ljava/lang/Object;Z)Lkotlin/Unit;
    .locals 6
    .param p0, "$generation"    # I
    .param p1, "$listing"    # Lorg/lighttouch/android/Listing;
    .param p2, "$outcome"    # Ljava/lang/Object;
    .param p3, "$reset"    # Z

    .line 121
    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getGeneration()I

    move-result v0

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 122
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/Listing;->setLoading(Z)V

    .line 123
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    move-object v1, p2

    check-cast v1, Lorg/lighttouch/android/StorePage;

    .local v1, "it\\1":Lorg/lighttouch/android/StorePage;
    const/4 v2, 0x0

    .line 124
    .local v2, "$i$a$-onSuccess-StoreBrowser$load$1$1$1\\1\\123\\0":I
    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getRows()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/util/Collection;

    invoke-virtual {v1}, Lorg/lighttouch/android/StorePage;->getRows()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v3, v4}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v3

    invoke-virtual {p1, v3}, Lorg/lighttouch/android/Listing;->setRows(Ljava/util/List;)V

    invoke-virtual {v1}, Lorg/lighttouch/android/StorePage;->getNext()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Lorg/lighttouch/android/Listing;->setNext(Ljava/lang/String;)V

    invoke-virtual {v1}, Lorg/lighttouch/android/StorePage;->getTotal()I

    move-result v3

    invoke-virtual {p1, v3}, Lorg/lighttouch/android/Listing;->setTotal(I)V

    const/4 v3, 0x1

    invoke-virtual {p1, v3}, Lorg/lighttouch/android/Listing;->setLoaded(Z)V

    .line 125
    if-eqz p3, :cond_1

    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getListState()Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v3, v0, v0, v4, v5}, Landroidx/compose/foundation/lazy/LazyListState;->requestScrollToItem$default(Landroidx/compose/foundation/lazy/LazyListState;IIILjava/lang/Object;)V

    .line 126
    :cond_1
    nop

    .line 123
    .end local v1    # "it\\1":Lorg/lighttouch/android/StorePage;
    .end local v2    # "$i$a$-onSuccess-StoreBrowser$load$1$1$1\\1\\123\\0":I
    :cond_2
    nop

    .line 127
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 398
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 127
    .local v1, "$i$a$-onFailure-StoreBrowser$load$1$1$2\\3\\127\\0":I
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    const-string v2, "\u65e0\u6cd5\u52a0\u8f7d"

    :cond_3
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/Listing;->setError(Ljava/lang/String;)V

    .line 128
    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreBrowser$load$1$1$2\\3\\127\\0":I
    :cond_4
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final loadCategory()V
    .locals 5

    .line 177
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getCategory()Lorg/lighttouch/android/StoreGenre;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .local v0, "genre":Lorg/lighttouch/android/StoreGenre;
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getCategorySort()Ljava/lang/String;

    move-result-object v1

    .local v1, "sort":Ljava/lang/String;
    iget-object v2, p0, Lorg/lighttouch/android/StoreBrowser;->categoryApps:Lorg/lighttouch/android/Listing;

    new-instance v3, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda3;

    invoke-direct {v3, v0, v1}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/StoreGenre;Ljava/lang/String;)V

    const/4 v4, 0x1

    invoke-direct {p0, v2, v4, v3}, Lorg/lighttouch/android/StoreBrowser;->load(Lorg/lighttouch/android/Listing;ZLkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method private static final loadCategory$lambda$21(Lorg/lighttouch/android/StoreGenre;Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 2
    .param p0, "$genre"    # Lorg/lighttouch/android/StoreGenre;
    .param p1, "$sort"    # Ljava/lang/String;

    .line 177
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreGenre;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lorg/lighttouch/android/LegacyStore;->genreApps(Ljava/lang/String;Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic loadChart$default(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;ILjava/lang/Object;)V
    .locals 0

    .line 140
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    iget-object p1, p0, Lorg/lighttouch/android/StoreBrowser;->chartDate:Ljava/lang/String;

    :cond_0
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->loadChart(Ljava/lang/String;)V

    return-void
.end method

.method private static final loadChart$lambda$14(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreBrowser;
    .param p1, "$type"    # Ljava/lang/String;
    .param p2, "$device"    # Ljava/lang/String;
    .param p3, "$genre"    # Ljava/lang/String;
    .param p4, "$date"    # Ljava/lang/String;
    .param p5, "$generation"    # I

    .line 146
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 398
    .local v0, "$this$loadChart_u24lambda_u2414_u24lambda_u2410\\1":Lorg/lighttouch/android/StoreBrowser;
    const/4 v1, 0x0

    .line 146
    .local v1, "$i$a$-runCatching-StoreBrowser$loadChart$1$outcome$1\\1\\146\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2, p1, p2, p3, p4}, Lorg/lighttouch/android/LegacyStore;->chart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/lighttouch/android/StoreChart;

    move-result-object v2

    .end local v0    # "$this$loadChart_u24lambda_u2414_u24lambda_u2410\\1":Lorg/lighttouch/android/StoreBrowser;
    .end local v1    # "$i$a$-runCatching-StoreBrowser$loadChart$1$outcome$1\\1\\146\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 147
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda1;

    invoke-direct {v1, p5, p0, v0}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda1;-><init>(ILorg/lighttouch/android/StoreBrowser;Ljava/lang/Object;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreBrowser;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 152
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final loadChart$lambda$14$lambda$13(ILorg/lighttouch/android/StoreBrowser;Ljava/lang/Object;)Lkotlin/Unit;
    .locals 6
    .param p0, "$generation"    # I
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreBrowser;
    .param p2, "$outcome"    # Ljava/lang/Object;

    .line 148
    iget v0, p1, Lorg/lighttouch/android/StoreBrowser;->chartGeneration:I

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 149
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreBrowser;->setChartLoading(Z)V

    .line 150
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    move-object v1, p2

    check-cast v1, Lorg/lighttouch/android/StoreChart;

    .line 398
    .local v1, "it\\1":Lorg/lighttouch/android/StoreChart;
    const/4 v3, 0x0

    .line 150
    .local v3, "$i$a$-onSuccess-StoreBrowser$loadChart$1$1$1\\1\\150\\0":I
    invoke-virtual {p1, v1}, Lorg/lighttouch/android/StoreBrowser;->setChart(Lorg/lighttouch/android/StoreChart;)V

    iget-object v4, p1, Lorg/lighttouch/android/StoreBrowser;->chartList:Landroidx/compose/foundation/lazy/LazyListState;

    const/4 v5, 0x2

    invoke-static {v4, v0, v0, v5, v2}, Landroidx/compose/foundation/lazy/LazyListState;->requestScrollToItem$default(Landroidx/compose/foundation/lazy/LazyListState;IIILjava/lang/Object;)V

    .end local v1    # "it\\1":Lorg/lighttouch/android/StoreChart;
    .end local v3    # "$i$a$-onSuccess-StoreBrowser$loadChart$1$1$1\\1\\150\\0":I
    :cond_1
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_3

    .line 398
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 150
    .local v1, "$i$a$-onFailure-StoreBrowser$loadChart$1$1$2\\3\\150\\0":I
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreBrowser;->setChart(Lorg/lighttouch/android/StoreChart;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_2

    const-string v2, "\u6392\u884c\u699c\u52a0\u8f7d\u5931\u8d25"

    :cond_2
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreBrowser;->setChartError(Ljava/lang/String;)V

    .line 151
    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreBrowser$loadChart$1$1$2\\3\\150\\0":I
    :cond_3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final loadCollections()V
    .locals 2

    .line 180
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->setCollectionsError(Ljava/lang/String;)V

    .line 181
    new-instance v0, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    const-string v1, "store-collections"

    invoke-direct {p0, v1, v0}, Lorg/lighttouch/android/StoreBrowser;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 185
    return-void
.end method

.method private static final loadCollections$lambda$26(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreBrowser;

    .line 182
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 398
    .local v0, "$this$loadCollections_u24lambda_u2426_u24lambda_u2422\\1":Lorg/lighttouch/android/StoreBrowser;
    const/4 v1, 0x0

    .line 182
    .local v1, "$i$a$-runCatching-StoreBrowser$loadCollections$1$outcome$1\\1\\182\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2}, Lorg/lighttouch/android/LegacyStore;->collections()Ljava/util/List;

    move-result-object v2

    .end local v0    # "$this$loadCollections_u24lambda_u2426_u24lambda_u2422\\1":Lorg/lighttouch/android/StoreBrowser;
    .end local v1    # "$i$a$-runCatching-StoreBrowser$loadCollections$1$outcome$1\\1\\182\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 183
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda9;

    invoke-direct {v1, v0, p0}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda9;-><init>(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreBrowser;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 184
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final loadCollections$lambda$26$lambda$25(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 3
    .param p0, "$outcome"    # Ljava/lang/Object;
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreBrowser;

    .line 183
    invoke-static {p0}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Ljava/util/List;

    .line 398
    .local v0, "it\\1":Ljava/util/List;
    const/4 v1, 0x0

    .line 183
    .local v1, "$i$a$-onSuccess-StoreBrowser$loadCollections$1$1$1\\1\\183\\0":I
    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreBrowser;->setCollections(Ljava/util/List;)V

    .end local v0    # "it\\1":Ljava/util/List;
    .end local v1    # "$i$a$-onSuccess-StoreBrowser$loadCollections$1$1$1\\1\\183\\0":I
    :cond_0
    invoke-static {p0}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 398
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 183
    .local v1, "$i$a$-onFailure-StoreBrowser$loadCollections$1$1$2\\3\\183\\0":I
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    const-string v2, "\u5408\u96c6\u52a0\u8f7d\u5931\u8d25"

    :cond_1
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreBrowser;->setCollectionsError(Ljava/lang/String;)V

    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreBrowser$loadCollections$1$1$2\\3\\183\\0":I
    :cond_2
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final loadFeatured$lambda$8()Lorg/lighttouch/android/StorePage;
    .locals 2

    .line 135
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    const-string v1, "featured"

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/LegacyStore;->collection(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object v0

    return-object v0
.end method

.method private static final loadGenres$lambda$20(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreBrowser;

    .line 170
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 398
    .local v0, "$this$loadGenres_u24lambda_u2420_u24lambda_u2416\\1":Lorg/lighttouch/android/StoreBrowser;
    const/4 v1, 0x0

    .line 170
    .local v1, "$i$a$-runCatching-StoreBrowser$loadGenres$1$outcome$1\\1\\170\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2}, Lorg/lighttouch/android/LegacyStore;->genres()Ljava/util/List;

    move-result-object v2

    .end local v0    # "$this$loadGenres_u24lambda_u2420_u24lambda_u2416\\1":Lorg/lighttouch/android/StoreBrowser;
    .end local v1    # "$i$a$-runCatching-StoreBrowser$loadGenres$1$outcome$1\\1\\170\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 171
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda6;

    invoke-direct {v1, v0, p0}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda6;-><init>(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreBrowser;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 172
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final loadGenres$lambda$20$lambda$19(Ljava/lang/Object;Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 3
    .param p0, "$outcome"    # Ljava/lang/Object;
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreBrowser;

    .line 171
    invoke-static {p0}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Ljava/util/List;

    .line 398
    .local v0, "it\\1":Ljava/util/List;
    const/4 v1, 0x0

    .line 171
    .local v1, "$i$a$-onSuccess-StoreBrowser$loadGenres$1$1$1\\1\\171\\0":I
    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreBrowser;->setGenres(Ljava/util/List;)V

    .end local v0    # "it\\1":Ljava/util/List;
    .end local v1    # "$i$a$-onSuccess-StoreBrowser$loadGenres$1$1$1\\1\\171\\0":I
    :cond_0
    invoke-static {p0}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 398
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 171
    .local v1, "$i$a$-onFailure-StoreBrowser$loadGenres$1$1$2\\3\\171\\0":I
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    const-string v2, "\u5206\u7c7b\u52a0\u8f7d\u5931\u8d25"

    :cond_1
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreBrowser;->setGenresError(Ljava/lang/String;)V

    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreBrowser$loadGenres$1$1$2\\3\\171\\0":I
    :cond_2
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final more$lambda$7$lambda$6(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 1
    .param p0, "$address"    # Ljava/lang/String;

    .line 133
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v0, p0}, Lorg/lighttouch/android/LegacyStore;->page(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object v0

    return-object v0
.end method

.method private static final openCollection$lambda$27(Lorg/lighttouch/android/StoreCollection;)Lorg/lighttouch/android/StorePage;
    .locals 2
    .param p0, "$item"    # Lorg/lighttouch/android/StoreCollection;

    .line 186
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreCollection;->getSlug()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/LegacyStore;->collection(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object v0

    return-object v0
.end method

.method private final post(Lkotlin/jvm/functions/Function0;)Z
    .locals 2
    .param p1, "work"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 89
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda7;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda7;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v0

    return v0
.end method

.method private static final post$lambda$1(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 89
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private final setChartDeviceChoice(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 65
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartDeviceChoice$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 363
    .local v2, "$i$f$setValue\\1\\65":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 364
    nop

    .line 65
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\65":I
    return-void
.end method


# virtual methods
.method public final back()V
    .locals 3

    .line 92
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getTab()Lorg/lighttouch/android/StoreTab;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/StoreTab;->CATEGORIES:Lorg/lighttouch/android/StoreTab;

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreBrowser;->setCategory(Lorg/lighttouch/android/StoreGenre;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreBrowser;->setCollection(Lorg/lighttouch/android/StoreCollection;)V

    :goto_0
    return-void
.end method

.method public final getCanGoBack()Z
    .locals 2

    .line 91
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getTab()Lorg/lighttouch/android/StoreTab;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/StoreTab;->CATEGORIES:Lorg/lighttouch/android/StoreTab;

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getCategory()Lorg/lighttouch/android/StoreGenre;

    move-result-object v0

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getTab()Lorg/lighttouch/android/StoreTab;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/StoreTab;->COLLECTIONS:Lorg/lighttouch/android/StoreTab;

    if-ne v0, v1, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getCollection()Lorg/lighttouch/android/StoreCollection;

    move-result-object v0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final getCategory()Lorg/lighttouch/android/StoreGenre;
    .locals 3

    .line 79
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->category$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 383
    .local v2, "$i$f$getValue\\1\\79":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\79":I
    check-cast v0, Lorg/lighttouch/android/StoreGenre;

    .line 79
    return-object v0
.end method

.method public final getCategoryApps()Lorg/lighttouch/android/Listing;
    .locals 1

    .line 81
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->categoryApps:Lorg/lighttouch/android/Listing;

    return-object v0
.end method

.method public final getCategorySort()Ljava/lang/String;
    .locals 3

    .line 80
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->categorySort$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 386
    .local v2, "$i$f$getValue\\1\\80":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\80":I
    check-cast v0, Ljava/lang/String;

    .line 80
    return-object v0
.end method

.method public final getChart()Lorg/lighttouch/android/StoreChart;
    .locals 3

    .line 67
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chart$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 368
    .local v2, "$i$f$getValue\\1\\67":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\67":I
    check-cast v0, Lorg/lighttouch/android/StoreChart;

    .line 67
    return-object v0
.end method

.method public final getChartDevice()Ljava/lang/String;
    .locals 2

    .line 74
    invoke-direct {p0}, Lorg/lighttouch/android/StoreBrowser;->getChartDeviceChoice()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->target:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/StoreTarget;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreTarget;->getFamily()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "2"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "ipad"

    goto :goto_1

    :cond_1
    const-string v0, "iphone"

    :cond_2
    :goto_1
    return-object v0
.end method

.method public final getChartError()Ljava/lang/String;
    .locals 3

    .line 69
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartError$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 374
    .local v2, "$i$f$getValue\\1\\69":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\69":I
    check-cast v0, Ljava/lang/String;

    .line 69
    return-object v0
.end method

.method public final getChartGenre()Lorg/lighttouch/android/StoreGenre;
    .locals 3

    .line 66
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGenre$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 365
    .local v2, "$i$f$getValue\\1\\66":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\66":I
    check-cast v0, Lorg/lighttouch/android/StoreGenre;

    .line 66
    return-object v0
.end method

.method public final getChartList()Landroidx/compose/foundation/lazy/LazyListState;
    .locals 1

    .line 60
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartList:Landroidx/compose/foundation/lazy/LazyListState;

    return-object v0
.end method

.method public final getChartLoading()Z
    .locals 3

    .line 68
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartLoading$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 371
    .local v2, "$i$f$getValue\\1\\68":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\68":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 68
    return v0
.end method

.method public final getChartType()Ljava/lang/String;
    .locals 3

    .line 64
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartType$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 359
    .local v2, "$i$f$getValue\\1\\64":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\64":I
    check-cast v0, Ljava/lang/String;

    .line 64
    return-object v0
.end method

.method public final getCollection()Lorg/lighttouch/android/StoreCollection;
    .locals 3

    .line 85
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collection$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 395
    .local v2, "$i$f$getValue\\1\\85":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\85":I
    check-cast v0, Lorg/lighttouch/android/StoreCollection;

    .line 85
    return-object v0
.end method

.method public final getCollectionApps()Lorg/lighttouch/android/Listing;
    .locals 1

    .line 86
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionApps:Lorg/lighttouch/android/Listing;

    return-object v0
.end method

.method public final getCollectionList()Landroidx/compose/foundation/lazy/LazyListState;
    .locals 1

    .line 62
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionList:Landroidx/compose/foundation/lazy/LazyListState;

    return-object v0
.end method

.method public final getCollections()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCollection;",
            ">;"
        }
    .end annotation

    .line 83
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collections$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 389
    .local v2, "$i$f$getValue\\1\\83":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\83":I
    check-cast v0, Ljava/util/List;

    .line 83
    return-object v0
.end method

.method public final getCollectionsError()Ljava/lang/String;
    .locals 3

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionsError$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 392
    .local v2, "$i$f$getValue\\1\\84":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\84":I
    check-cast v0, Ljava/lang/String;

    .line 84
    return-object v0
.end method

.method public final getFeatured()Lorg/lighttouch/android/Listing;
    .locals 1

    .line 59
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->featured:Lorg/lighttouch/android/Listing;

    return-object v0
.end method

.method public final getGenreList()Landroidx/compose/foundation/lazy/LazyListState;
    .locals 1

    .line 61
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genreList:Landroidx/compose/foundation/lazy/LazyListState;

    return-object v0
.end method

.method public final getGenres()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreGenre;",
            ">;"
        }
    .end annotation

    .line 77
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genres$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 377
    .local v2, "$i$f$getValue\\1\\77":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\77":I
    check-cast v0, Ljava/util/List;

    .line 77
    return-object v0
.end method

.method public final getGenresError()Ljava/lang/String;
    .locals 3

    .line 78
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genresError$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 380
    .local v2, "$i$f$getValue\\1\\78":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\78":I
    check-cast v0, Ljava/lang/String;

    .line 78
    return-object v0
.end method

.method public final getTab()Lorg/lighttouch/android/StoreTab;
    .locals 3

    .line 57
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->tab$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 356
    .local v2, "$i$f$getValue\\1\\57":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\57":I
    check-cast v0, Lorg/lighttouch/android/StoreTab;

    .line 57
    return-object v0
.end method

.method public final loadChart(Ljava/lang/String;)V
    .locals 9
    .param p1, "date"    # Ljava/lang/String;

    .line 141
    iput-object p1, p0, Lorg/lighttouch/android/StoreBrowser;->chartDate:Ljava/lang/String;

    .line 142
    iget v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGeneration:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGeneration:I

    iget v8, p0, Lorg/lighttouch/android/StoreBrowser;->chartGeneration:I

    .line 143
    .local v8, "generation":I
    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreBrowser;->setChartLoading(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->setChartError(Ljava/lang/String;)V

    .line 144
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChartType()Ljava/lang/String;

    move-result-object v4

    .local v4, "type":Ljava/lang/String;
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChartDevice()Ljava/lang/String;

    move-result-object v5

    .local v5, "device":Ljava/lang/String;
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChartGenre()Lorg/lighttouch/android/StoreGenre;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lorg/lighttouch/android/StoreGenre;->getId()Ljava/lang/String;

    move-result-object v0

    :cond_0
    move-object v6, v0

    .line 145
    .local v6, "genre":Ljava/lang/String;
    new-instance v2, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda5;

    move-object v3, p0

    move-object v7, p1

    .end local p1    # "date":Ljava/lang/String;
    .local v7, "date":Ljava/lang/String;
    invoke-direct/range {v2 .. v8}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    const-string p1, "store-chart"

    invoke-direct {p0, p1, v2}, Lorg/lighttouch/android/StoreBrowser;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 153
    return-void
.end method

.method public final loadFeatured()V
    .locals 3

    .line 135
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->featured:Lorg/lighttouch/android/Listing;

    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda2;

    invoke-direct {v1}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda2;-><init>()V

    const/4 v2, 0x1

    invoke-direct {p0, v0, v2, v1}, Lorg/lighttouch/android/StoreBrowser;->load(Lorg/lighttouch/android/Listing;ZLkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public final loadGenres()V
    .locals 2

    .line 167
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getGenres()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_0

    return-void

    .line 168
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->setGenresError(Ljava/lang/String;)V

    .line 169
    new-instance v0, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda11;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    const-string v1, "store-genres"

    invoke-direct {p0, v1, v0}, Lorg/lighttouch/android/StoreBrowser;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 173
    return-void
.end method

.method public final more(Lorg/lighttouch/android/Listing;)V
    .locals 4
    .param p1, "listing"    # Lorg/lighttouch/android/Listing;

    const-string v0, "listing"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getNext()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 398
    .local v0, "address\\1":Ljava/lang/String;
    const/4 v1, 0x0

    .line 133
    .local v1, "$i$a$-let-StoreBrowser$more$1\\1\\133\\0":I
    invoke-virtual {p1}, Lorg/lighttouch/android/Listing;->getLoading()Z

    move-result v2

    if-nez v2, :cond_0

    new-instance v2, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda12;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda12;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-direct {p0, p1, v3, v2}, Lorg/lighttouch/android/StoreBrowser;->load(Lorg/lighttouch/android/Listing;ZLkotlin/jvm/functions/Function0;)V

    .end local v0    # "address\\1":Ljava/lang/String;
    .end local v1    # "$i$a$-let-StoreBrowser$more$1\\1\\133\\0":I
    :cond_0
    return-void
.end method

.method public final openCategory(Lorg/lighttouch/android/StoreGenre;)V
    .locals 1
    .param p1, "genre"    # Lorg/lighttouch/android/StoreGenre;

    const-string v0, "genre"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 175
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setCategory(Lorg/lighttouch/android/StoreGenre;)V

    invoke-direct {p0}, Lorg/lighttouch/android/StoreBrowser;->loadCategory()V

    return-void
.end method

.method public final openCollection(Lorg/lighttouch/android/StoreCollection;)V
    .locals 3
    .param p1, "item"    # Lorg/lighttouch/android/StoreCollection;

    const-string v0, "item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 186
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setCollection(Lorg/lighttouch/android/StoreCollection;)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionApps:Lorg/lighttouch/android/Listing;

    new-instance v1, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda13;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/StoreBrowser$$ExternalSyntheticLambda13;-><init>(Lorg/lighttouch/android/StoreCollection;)V

    const/4 v2, 0x1

    invoke-direct {p0, v0, v2, v1}, Lorg/lighttouch/android/StoreBrowser;->load(Lorg/lighttouch/android/Listing;ZLkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public final pickCategorySort(Ljava/lang/String;)V
    .locals 1
    .param p1, "sort"    # Ljava/lang/String;

    const-string v0, "sort"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 176
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setCategorySort(Ljava/lang/String;)V

    invoke-direct {p0}, Lorg/lighttouch/android/StoreBrowser;->loadCategory()V

    return-void
.end method

.method public final pickChartDevice(Ljava/lang/String;)V
    .locals 2
    .param p1, "device"    # Ljava/lang/String;

    const-string v0, "device"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 156
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setChartDevice(Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0, v0, v1, v0}, Lorg/lighttouch/android/StoreBrowser;->loadChart$default(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;ILjava/lang/Object;)V

    return-void
.end method

.method public final pickChartGenre(Lorg/lighttouch/android/StoreGenre;)V
    .locals 2
    .param p1, "genre"    # Lorg/lighttouch/android/StoreGenre;

    .line 157
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setChartGenre(Lorg/lighttouch/android/StoreGenre;)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0, v0, v1, v0}, Lorg/lighttouch/android/StoreBrowser;->loadChart$default(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;ILjava/lang/Object;)V

    return-void
.end method

.method public final pickChartType(Ljava/lang/String;)V
    .locals 2
    .param p1, "slug"    # Ljava/lang/String;

    const-string v0, "slug"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 155
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setChartType(Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0, v0, v1, v0}, Lorg/lighttouch/android/StoreBrowser;->loadChart$default(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;ILjava/lang/Object;)V

    return-void
.end method

.method public final pickChartYear(Ljava/lang/String;)V
    .locals 2
    .param p1, "year"    # Ljava/lang/String;

    const-string v0, "year"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 158
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "-07-01"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->loadChart(Ljava/lang/String;)V

    return-void
.end method

.method public final reset()V
    .locals 6

    .line 96
    const/4 v0, 0x3

    new-array v0, v0, [Lorg/lighttouch/android/Listing;

    iget-object v1, p0, Lorg/lighttouch/android/StoreBrowser;->featured:Lorg/lighttouch/android/Listing;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    iget-object v1, p0, Lorg/lighttouch/android/StoreBrowser;->categoryApps:Lorg/lighttouch/android/Listing;

    const/4 v3, 0x1

    aput-object v1, v0, v3

    const/4 v1, 0x2

    iget-object v4, p0, Lorg/lighttouch/android/StoreBrowser;->collectionApps:Lorg/lighttouch/android/Listing;

    aput-object v4, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/lighttouch/android/Listing;

    .local v1, "listing":Lorg/lighttouch/android/Listing;
    invoke-virtual {v1}, Lorg/lighttouch/android/Listing;->getGeneration()I

    move-result v5

    add-int/2addr v5, v3

    invoke-virtual {v1, v5}, Lorg/lighttouch/android/Listing;->setGeneration(I)V

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v5

    invoke-virtual {v1, v5}, Lorg/lighttouch/android/Listing;->setRows(Ljava/util/List;)V

    invoke-virtual {v1, v4}, Lorg/lighttouch/android/Listing;->setNext(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/Listing;->setLoaded(Z)V

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/Listing;->setLoading(Z)V

    invoke-virtual {v1, v4}, Lorg/lighttouch/android/Listing;->setError(Ljava/lang/String;)V

    .end local v1    # "listing":Lorg/lighttouch/android/Listing;
    goto :goto_0

    .line 97
    :cond_0
    iget v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGeneration:I

    add-int/2addr v0, v3

    iput v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGeneration:I

    invoke-virtual {p0, v4}, Lorg/lighttouch/android/StoreBrowser;->setChart(Lorg/lighttouch/android/StoreChart;)V

    iput-object v4, p0, Lorg/lighttouch/android/StoreBrowser;->chartDate:Ljava/lang/String;

    invoke-virtual {p0, v4}, Lorg/lighttouch/android/StoreBrowser;->setChartError(Ljava/lang/String;)V

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreBrowser;->setChartLoading(Z)V

    invoke-virtual {p0, v4}, Lorg/lighttouch/android/StoreBrowser;->setChartGenre(Lorg/lighttouch/android/StoreGenre;)V

    invoke-direct {p0, v4}, Lorg/lighttouch/android/StoreBrowser;->setChartDeviceChoice(Ljava/lang/String;)V

    .line 98
    invoke-virtual {p0, v4}, Lorg/lighttouch/android/StoreBrowser;->setCategory(Lorg/lighttouch/android/StoreGenre;)V

    invoke-virtual {p0, v4}, Lorg/lighttouch/android/StoreBrowser;->setCollection(Lorg/lighttouch/android/StoreCollection;)V

    .line 99
    return-void
.end method

.method public final retryCollections()V
    .locals 0

    .line 187
    invoke-direct {p0}, Lorg/lighttouch/android/StoreBrowser;->loadCollections()V

    return-void
.end method

.method public final setCategory(Lorg/lighttouch/android/StoreGenre;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/StoreGenre;

    .line 79
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->category$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 384
    .local v2, "$i$f$setValue\\1\\79":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 385
    nop

    .line 79
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\79":I
    return-void
.end method

.method public final setCategorySort(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->categorySort$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 387
    .local v2, "$i$f$setValue\\1\\80":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 388
    nop

    .line 80
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\80":I
    return-void
.end method

.method public final setChart(Lorg/lighttouch/android/StoreChart;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/StoreChart;

    .line 67
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chart$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 369
    .local v2, "$i$f$setValue\\1\\67":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 370
    nop

    .line 67
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\67":I
    return-void
.end method

.method public final setChartDevice(Ljava/lang/String;)V
    .locals 1
    .param p1, "value"    # Ljava/lang/String;

    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    invoke-direct {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setChartDeviceChoice(Ljava/lang/String;)V

    return-void
.end method

.method public final setChartError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 69
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartError$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 375
    .local v2, "$i$f$setValue\\1\\69":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 376
    nop

    .line 69
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\69":I
    return-void
.end method

.method public final setChartGenre(Lorg/lighttouch/android/StoreGenre;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/StoreGenre;

    .line 66
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartGenre$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 366
    .local v2, "$i$f$setValue\\1\\66":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 367
    nop

    .line 66
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\66":I
    return-void
.end method

.method public final setChartLoading(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 68
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartLoading$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 372
    .local v3, "$i$f$setValue\\1\\68":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 373
    nop

    .line 68
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\68":I
    return-void
.end method

.method public final setChartType(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartType$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 360
    .local v2, "$i$f$setValue\\1\\64":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 361
    nop

    .line 64
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\64":I
    return-void
.end method

.method public final setCollection(Lorg/lighttouch/android/StoreCollection;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/StoreCollection;

    .line 85
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collection$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 396
    .local v2, "$i$f$setValue\\1\\85":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 397
    nop

    .line 85
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\85":I
    return-void
.end method

.method public final setCollections(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCollection;",
            ">;)V"
        }
    .end annotation

    .line 83
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collections$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 390
    .local v2, "$i$f$setValue\\1\\83":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 391
    nop

    .line 83
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\83":I
    return-void
.end method

.method public final setCollectionsError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->collectionsError$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 393
    .local v2, "$i$f$setValue\\1\\84":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 394
    nop

    .line 84
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\84":I
    return-void
.end method

.method public final setGenres(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreGenre;",
            ">;)V"
        }
    .end annotation

    .line 77
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genres$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 378
    .local v2, "$i$f$setValue\\1\\77":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 379
    nop

    .line 77
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\77":I
    return-void
.end method

.method public final setGenresError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 78
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->genresError$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 381
    .local v2, "$i$f$setValue\\1\\78":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 382
    nop

    .line 78
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\78":I
    return-void
.end method

.method public final setTab(Lorg/lighttouch/android/StoreTab;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/StoreTab;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 57
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->tab$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 357
    .local v2, "$i$f$setValue\\1\\57":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 358
    nop

    .line 57
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\57":I
    return-void
.end method

.method public final shiftChart(I)V
    .locals 4
    .param p1, "delta"    # I

    .line 161
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChart()Lorg/lighttouch/android/StoreChart;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 162
    .local v0, "current":Lorg/lighttouch/android/StoreChart;
    :cond_0
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreChart;->getDates()Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreChart;->getDate()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v1

    .line 163
    .local v1, "index":I
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreChart;->getDates()Ljava/util/List;

    move-result-object v2

    add-int v3, v1, p1

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v2, :cond_1

    .line 398
    .local v2, "it\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 163
    .local v3, "$i$a$-let-StoreBrowser$shiftChart$1\\1\\163\\0":I
    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreBrowser;->loadChart(Ljava/lang/String;)V

    .line 164
    .end local v2    # "it\\1":Ljava/lang/String;
    .end local v3    # "$i$a$-let-StoreBrowser$shiftChart$1\\1\\163\\0":I
    :cond_1
    return-void
.end method

.method public final show(Lorg/lighttouch/android/StoreTab;)V
    .locals 2
    .param p1, "next"    # Lorg/lighttouch/android/StoreTab;

    const-string v0, "next"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->setTab(Lorg/lighttouch/android/StoreTab;)V

    .line 104
    sget-object v0, Lorg/lighttouch/android/StoreBrowser$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p1}, Lorg/lighttouch/android/StoreTab;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    .line 109
    :pswitch_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getCollections()Ljava/util/List;

    move-result-object v0

    if-nez v0, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/StoreBrowser;->loadCollections()V

    goto :goto_0

    .line 108
    :pswitch_1
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->loadGenres()V

    goto :goto_0

    .line 107
    :pswitch_2
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->loadGenres()V

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChart()Lorg/lighttouch/android/StoreChart;

    move-result-object v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChartLoading()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getChartError()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->chartDate:Ljava/lang/String;

    if-nez v0, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/StoreBrowser;->eraDate()Ljava/lang/String;

    move-result-object v0

    :cond_0
    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->loadChart(Ljava/lang/String;)V

    goto :goto_0

    .line 106
    :pswitch_3
    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->featured:Lorg/lighttouch/android/Listing;

    invoke-virtual {v0}, Lorg/lighttouch/android/Listing;->getLoaded()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lorg/lighttouch/android/StoreBrowser;->featured:Lorg/lighttouch/android/Listing;

    invoke-virtual {v0}, Lorg/lighttouch/android/Listing;->getLoading()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->loadFeatured()V

    .line 111
    :cond_1
    :goto_0
    :pswitch_4
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_4
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

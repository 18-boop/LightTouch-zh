.class public final Lorg/lighttouch/android/MainActivity$connection$1;
.super Ljava/lang/Object;
.source "MainActivity.kt"

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/MainActivity;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMainActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MainActivity.kt\norg/lighttouch/android/MainActivity$connection$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1266:1\n1#2:1267\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0010\u0010\u0008\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016\u00a8\u0006\t"
    }
    d2 = {
        "org/lighttouch/android/MainActivity$connection$1",
        "Landroid/content/ServiceConnection;",
        "onServiceConnected",
        "",
        "name",
        "Landroid/content/ComponentName;",
        "binder",
        "Landroid/os/IBinder;",
        "onServiceDisconnected",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lorg/lighttouch/android/MainActivity;


# direct methods
.method public static synthetic $r8$lambda$D9UKUS7nvJLu5jN4UarrNlPJkow(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity$connection$1;->onServiceConnected$lambda$1$lambda$0(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V

    return-void
.end method

.method public static synthetic $r8$lambda$E2abPNQ-nOa6ZejvOKoT1zbbeps(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity$connection$1;->onServiceConnected$lambda$1(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V

    return-void
.end method

.method public static synthetic $r8$lambda$HZ8jsAlGr_LPDy65Ovgil7slJf8(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Lorg/lighttouch/android/MainActivity$connection$1;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity$connection$1;->onServiceConnected$lambda$6(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Lorg/lighttouch/android/MainActivity$connection$1;)V

    return-void
.end method

.method public static synthetic $r8$lambda$v8Z-h0mcK416wzQdklEEUBsU_Vo(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Landroid/os/Bundle;Lorg/lighttouch/android/MainActivity$connection$1;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity$connection$1;->onServiceConnected$lambda$6$lambda$4(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Landroid/os/Bundle;Lorg/lighttouch/android/MainActivity$connection$1;)V

    return-void
.end method

.method public static synthetic $r8$lambda$wB25lTJv_7LLlxYws8MavJzua9c(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity$connection$1;->onServiceConnected$lambda$6$lambda$5(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method constructor <init>(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p1, "$receiver"    # Lorg/lighttouch/android/MainActivity;

    iput-object p1, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    .line 188
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final onServiceConnected$lambda$1(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$binder"    # Landroid/os/IBinder;

    .line 194
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getHandler$p(Lorg/lighttouch/android/MainActivity;)Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static final onServiceConnected$lambda$1$lambda$0(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$binder"    # Landroid/os/IBinder;

    .line 194
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$workerExited(Lorg/lighttouch/android/MainActivity;)V

    :cond_1
    return-void
.end method

.method private static final onServiceConnected$lambda$6(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Lorg/lighttouch/android/MainActivity$connection$1;)V
    .locals 3
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "$binder"    # Landroid/os/IBinder;
    .param p3, "this$1"    # Lorg/lighttouch/android/MainActivity$connection$1;

    .line 198
    :try_start_0
    invoke-interface {p0}, Lorg/lighttouch/android/IEngine;->status()Landroid/os/Bundle;

    move-result-object v0

    .local v0, "state":Landroid/os/Bundle;
    invoke-static {p1}, Lorg/lighttouch/android/MainActivity;->access$getHandler$p(Lorg/lighttouch/android/MainActivity;)Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda3;

    invoke-direct {v2, p1, p2, v0, p3}, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Landroid/os/Bundle;Lorg/lighttouch/android/MainActivity$connection$1;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "state":Landroid/os/Bundle;
    goto :goto_0

    .line 204
    :catch_0
    move-exception v0

    .local v0, "failure":Landroid/os/RemoteException;
    invoke-static {p1}, Lorg/lighttouch/android/MainActivity;->access$getHandler$p(Lorg/lighttouch/android/MainActivity;)Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda4;

    invoke-direct {v2, p1}, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 205
    .end local v0    # "failure":Landroid/os/RemoteException;
    :goto_0
    return-void
.end method

.method private static final onServiceConnected$lambda$6$lambda$4(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Landroid/os/Bundle;Lorg/lighttouch/android/MainActivity$connection$1;)V
    .locals 5
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$binder"    # Landroid/os/IBinder;
    .param p2, "$state"    # Landroid/os/Bundle;
    .param p3, "this$1"    # Lorg/lighttouch/android/MainActivity$connection$1;

    .line 199
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, v1

    :goto_0
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    return-void

    .line 200
    :cond_1
    const-string v0, "sessionStarted"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setSessionOwned(Lorg/lighttouch/android/MainActivity;Z)V

    const-string v0, "state"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_2

    const-string v0, "stopped"

    :cond_2
    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setStatus(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 201
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setPendingGuestStart$p(Lorg/lighttouch/android/MainActivity;Z)V

    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setEngineRestarting$p(Lorg/lighttouch/android/MainActivity;Z)V

    .line 202
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getPendingGuestRequest$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/MainActivity$GuestStartRequest;

    move-result-object v2

    if-eqz v2, :cond_3

    .line 1267
    .local v2, "it\\1":Lorg/lighttouch/android/MainActivity$GuestStartRequest;
    const/4 v3, 0x0

    .line 202
    .local v3, "$i$a$-let-MainActivity$connection$1$onServiceConnected$2$1$1\\1\\202\\0":I
    const/4 v4, 0x1

    invoke-static {p0, v0, v2, v4, v1}, Lorg/lighttouch/android/MainActivity;->startGuest$default(Lorg/lighttouch/android/MainActivity;ZLorg/lighttouch/android/MainActivity$GuestStartRequest;ILjava/lang/Object;)V

    .end local v2    # "it\\1":Lorg/lighttouch/android/MainActivity$GuestStartRequest;
    .end local v3    # "$i$a$-let-MainActivity$connection$1$onServiceConnected$2$1$1\\1\\202\\0":I
    goto :goto_1

    .line 203
    :cond_3
    move-object v0, p3

    .line 1267
    .local v0, "$this$onServiceConnected_u24lambda_u246_u24lambda_u244_u24lambda_u243\\2":Lorg/lighttouch/android/MainActivity$connection$1;
    const/4 v1, 0x0

    .line 203
    .local v1, "$i$a$-run-MainActivity$connection$1$onServiceConnected$2$1$2\\2\\203\\0":I
    const-string v2, "\u542f\u52a8\u8bf7\u6c42\u5df2\u4e22\u5931\uff0c\u8bf7\u91cd\u65b0\u9009\u62e9\u300c\u542f\u52a8\u300d\u6216\u300c\u6062\u590d\u4fdd\u7559\u7684\u72b6\u6001\u300d\u3002"

    invoke-static {p0, v2}, Lorg/lighttouch/android/MainActivity;->access$setError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    const-string v2, "failed"

    invoke-static {p0, v2}, Lorg/lighttouch/android/MainActivity;->access$setStatus(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 204
    .end local v0    # "$this$onServiceConnected_u24lambda_u246_u24lambda_u244_u24lambda_u243\\2":Lorg/lighttouch/android/MainActivity$connection$1;
    .end local v1    # "$i$a$-run-MainActivity$connection$1$onServiceConnected$2$1$2\\2\\203\\0":I
    :goto_1
    return-void
.end method

.method private static final onServiceConnected$lambda$6$lambda$5(Lorg/lighttouch/android/MainActivity;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 204
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setPendingGuestStart$p(Lorg/lighttouch/android/MainActivity;Z)V

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$workerExited(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 4
    .param p1, "name"    # Landroid/content/ComponentName;
    .param p2, "binder"    # Landroid/os/IBinder;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "binder"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getWorkerEvidenceDelivery$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/SessionDeliveryGate;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/SessionDeliveryGate;->advance()J

    .line 191
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {p2}, Lorg/lighttouch/android/IEngine$Stub;->asInterface(Landroid/os/IBinder;)Lorg/lighttouch/android/IEngine;

    move-result-object v1

    invoke-static {v0, v1}, Lorg/lighttouch/android/MainActivity;->access$setEngine(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;)V

    .line 192
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v3, v1, v2}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    .line 193
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->applySettings()V

    .line 194
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    new-instance v1, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda1;

    invoke-direct {v1, v0, p2}, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;)V

    invoke-interface {p2, v1, v3}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V

    .line 195
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getPendingGuestStart$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 196
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 197
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    new-instance v1, Ljava/lang/Thread;

    .line 205
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    new-instance v3, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda2;

    invoke-direct {v3, v0, v2, p2, p0}, Lorg/lighttouch/android/MainActivity$connection$1$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Landroid/os/IBinder;Lorg/lighttouch/android/MainActivity$connection$1;)V

    .line 197
    const-string v2, "guest-reconnect"

    invoke-direct {v1, v3, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 205
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    goto :goto_0

    .line 196
    .end local v0    # "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u5fc5\u9700\u7684\u503c\u4e3a\u7a7a\u3002"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 207
    :cond_1
    :goto_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getDisplayView$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/GuestDisplay;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestDisplay;->attachActiveSurface$app_debug()V

    .line 208
    :cond_2
    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 1
    .param p1, "name"    # Landroid/content/ComponentName;

    const-string v0, "name"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 209
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$connection$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$workerExited(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

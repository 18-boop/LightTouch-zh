.class final Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;
.super Ljava/lang/Object;
.source "PrepareScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/PrepareScreenKt;->FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPrepareScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt$FilesStep$2\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,416:1\n149#2:417\n149#2:418\n149#2:460\n99#3:419\n95#3,7:420\n102#3:455\n106#3:459\n79#4,6:427\n86#4,4:442\n90#4,2:452\n94#4:458\n368#5,9:433\n377#5:454\n378#5,2:456\n4034#6,6:446\n*S KotlinDebug\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt$FilesStep$2\n*L\n315#1:417\n316#1:418\n322#1:460\n316#1:419\n316#1:420,7\n316#1:455\n316#1:459\n316#1:427,6\n316#1:442,4\n316#1:452,2\n316#1:458\n316#1:433,9\n316#1:454\n316#1:456,2\n316#1:446,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $busy:Z

.field final synthetic $onChooseRom:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onDownloadRom:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $rom:Lorg/lighttouch/android/Bootrom;

.field final synthetic $state:Lorg/lighttouch/android/PrepareState;


# direct methods
.method constructor <init>(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ZLorg/lighttouch/android/Bootrom;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/PrepareState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lorg/lighttouch/android/Bootrom;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$state:Lorg/lighttouch/android/PrepareState;

    iput-object p2, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$onChooseRom:Lkotlin/jvm/functions/Function0;

    iput-boolean p3, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$busy:Z

    iput-object p4, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$rom:Lorg/lighttouch/android/Bootrom;

    iput-object p5, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$onDownloadRom:Lkotlin/jvm/functions/Function0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 310
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 39
    .param p1, "$this$Card"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v8, p2

    move/from16 v14, p3

    const-string v1, "$this$Card"

    move-object/from16 v15, p1

    invoke-static {v15, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C:PrepareScreen.kt#o13vsk"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v14, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 314
    :cond_0
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_7

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.FilesStep.<anonymous> (PrepareScreen.kt:310)"

    const v3, -0x6bfaceb3

    invoke-static {v3, v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 311
    :cond_2
    nop

    .line 312
    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_3

    const v1, -0x5881e7c0

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "311@19967L83"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$onChooseRom:Lkotlin/jvm/functions/Function0;

    iget-boolean v3, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$busy:Z

    xor-int/2addr v3, v2

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-1111696648$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const/high16 v12, 0x30000000

    const/16 v13, 0x1fa

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v11, p2

    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object v8, v11

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_6

    .line 313
    :cond_3
    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getRomChecking()Z

    move-result v1

    if-eqz v1, :cond_4

    const v1, -0x5881d943

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "312@20084L48"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v3, v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v9, 0x6

    const/16 v10, 0x1e

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v10}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_6

    .line 314
    :cond_4
    const v1, 0x48482c29

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "315@20359L496,322@21038L10,322@21082L11,321@20872L239"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v1, -0x5881cde8

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "314@20280L10,314@20324L11,314@20204L138"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 315
    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getRomError()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v3, 0x0

    if-lez v1, :cond_5

    move v1, v2

    goto :goto_1

    :cond_5
    move v1, v3

    :goto_1
    if-eqz v1, :cond_6

    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getRomError()Ljava/lang/String;

    move-result-object v1

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v16, v4

    check-cast v16, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 417
    .local v5, "$i$f$getDp\\1\\315":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v20

    .line 315
    .end local v4    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\315":I
    const/16 v21, 0x7

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v8, v6}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v8, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v5

    const/16 v24, 0x0

    const v25, 0xfff8

    move v9, v2

    move v7, v3

    move-object v2, v4

    move-wide v3, v5

    const-wide/16 v5, 0x0

    move v10, v7

    const/4 v7, 0x0

    const/4 v8, 0x0

    move v11, v9

    const/4 v9, 0x0

    move v12, v10

    move v13, v11

    const-wide/16 v10, 0x0

    move/from16 v16, v12

    const/4 v12, 0x0

    move/from16 v17, v13

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v22, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v26, v23

    const/16 v23, 0x30

    move/from16 v26, v22

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v8, v22

    goto :goto_2

    :cond_6
    move/from16 v26, v2

    :goto_2
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 316
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v2, 0x8

    .local v2, "$this$dp\\2":I
    const/4 v3, 0x0

    .line 418
    .local v3, "$i$f$getDp\\2\\316":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 316
    .end local v2    # "$this$dp\\2":I
    .end local v3    # "$i$f$getDp\\2\\316":I
    invoke-virtual {v1, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v1, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-boolean v2, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$busy:Z

    iget-object v9, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$onDownloadRom:Lkotlin/jvm/functions/Function0;

    iget-object v3, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$onChooseRom:Lkotlin/jvm/functions/Function0;

    const/16 v4, 0x30

    .local v4, "$changed\\3":I
    const/4 v5, 0x0

    .line 419
    .local v5, "$i$f$Row\\3\\316":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v8, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 420
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 422
    .local v6, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 425
    .local v7, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v1, v7, v8, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 426
    move/from16 v23, v11

    .local v23, "$changed\\4":I
    const/16 v24, 0x0

    .line 427
    .local v24, "$i$f$Layout\\4\\426":I
    const v11, -0x4ee9b9da

    const-string v12, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v8, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 428
    const/4 v12, 0x0

    invoke-static {v8, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v25

    .line 429
    .local v25, "compositeKeyHash\\4":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 430
    .local v11, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 432
    .local v12, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v23, 0x6

    and-int/lit16 v14, v14, 0x380

    or-int/lit8 v14, v14, 0x6

    .line 431
    move/from16 v27, v14

    .local v13, "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v27, "$changed\\5":I
    const/16 v28, 0x0

    .line 433
    .local v28, "$i$f$ReusableComposeNode\\5\\431":I
    const v14, -0x2942ffcf

    const-string v15, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v8, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 434
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 435
    :cond_7
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 436
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_8

    .line 437
    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 439
    :cond_8
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 441
    :goto_3
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 442
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\441\\4":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v29, v1

    .end local v1    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v29, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v14, v10, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 443
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v14, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 445
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 446
    .local v16, "$i$f$set-impl\\7\\445":I
    move-object/from16 v17, v14

    .local v17, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 447
    .local v18, "$i$a$-with-Updater$set$1\\8\\446\\7":I
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v19

    if-nez v19, :cond_a

    move/from16 v22, v2

    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v30, v3

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v3, v17

    goto :goto_5

    :cond_a
    move/from16 v22, v2

    move-object/from16 v30, v3

    .line 448
    :goto_4
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v17

    .end local v17    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 449
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v14, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 451
    :goto_5
    nop

    .line 446
    .end local v3    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-with-Updater$set$1\\8\\446\\7":I
    nop

    .line 451
    nop

    .line 452
    .end local v1    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\7\\445":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v14, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 453
    nop

    .line 441
    .end local v14    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\441\\4":I
    nop

    .line 454
    shr-int/lit8 v1, v27, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\9":I
    move-object/from16 v2, p2

    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 455
    .local v3, "$i$a$-Layout-RowKt$Row$1\\9\\454\\3":I
    const v14, -0x184f2606

    const-string v15, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v14, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v15, v4, 0x6

    and-int/lit8 v15, v15, 0x70

    or-int/lit8 v31, v15, 0x6

    .local v31, "$changed\\10":I
    check-cast v14, Landroidx/compose/foundation/layout/RowScope;

    .local v14, "$this$invoke_u24lambda_u240\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object v15, v2

    .local v15, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v32, v14

    .end local v14    # "$this$invoke_u24lambda_u240\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v32, "$this$invoke_u24lambda_u240\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v33, 0x0

    .line 317
    .local v33, "$i$a$-Row-PrepareScreenKt$FilesStep$2$1\\10\\455\\0":I
    const v14, 0x7e72f16b

    move/from16 v34, v1

    .end local v1    # "$changed\\9":I
    .local v34, "$changed\\9":I
    const-string v1, "C316@20437L248,319@20706L131:PrepareScreen.kt#o13vsk"

    invoke-static {v15, v14, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object v1, v11

    .end local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v1, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    xor-int/lit8 v11, v22, 0x1

    sget-object v14, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v14, Landroidx/compose/ui/Modifier;

    move-object/from16 v16, v1

    .end local v1    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v16, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const-string v1, "prepare_download_rom"

    invoke-static {v14, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v14, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v14}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-666154664$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v18

    const v20, 0x30000030

    const/16 v21, 0x1f8

    move-object v14, v12

    .end local v12    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v14, "materialized\\4":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v17, v13

    .end local v13    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v17, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/4 v13, 0x0

    move-object/from16 v19, v14

    .end local v14    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v19, "materialized\\4":Landroidx/compose/ui/Modifier;
    const/4 v14, 0x0

    move-object/from16 v35, v19

    move-object/from16 v19, v15

    .end local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v35, "materialized\\4":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    move-object/from16 v36, v16

    .end local v16    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v36, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v16, 0x0

    move-object/from16 v37, v17

    .end local v17    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v37, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    move-object/from16 v38, v10

    move-object v10, v1

    move-object/from16 v1, v38

    .end local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v1, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v9 .. v21}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 320
    xor-int/lit8 v12, v22, 0x1

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const-string v10, "prepare_choose_rom"

    invoke-static {v9, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    sget-object v9, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v9}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$1324395926$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const v21, 0x30000030

    const/16 v22, 0x1f8

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v20, v19

    move-object/from16 v10, v30

    move-object/from16 v19, v9

    .end local v19    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v22}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 317
    move-object/from16 v19, v20

    .end local v20    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v19    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v19 .. v19}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 321
    nop

    .line 455
    .end local v19    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v31    # "$changed\\10":I
    .end local v32    # "$this$invoke_u24lambda_u240\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v33    # "$i$a$-Row-PrepareScreenKt$FilesStep$2$1\\10\\455\\0":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 454
    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$a$-Layout-RowKt$Row$1\\9\\454\\3":I
    .end local v34    # "$changed\\9":I
    nop

    .line 456
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 433
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 457
    nop

    .line 427
    .end local v27    # "$changed\\5":I
    .end local v28    # "$i$f$ReusableComposeNode\\5\\431":I
    .end local v37    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 458
    nop

    .line 419
    .end local v23    # "$changed\\4":I
    .end local v24    # "$i$f$Layout\\4\\426":I
    .end local v25    # "compositeKeyHash\\4":I
    .end local v35    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v36    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 459
    nop

    .line 322
    .end local v1    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "$changed\\3":I
    .end local v5    # "$i$f$Row\\3\\316":I
    .end local v6    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v7    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v29    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$rom:Lorg/lighttouch/android/Bootrom;

    invoke-virtual {v1}, Lorg/lighttouch/android/Bootrom;->getSources()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;->$rom:Lorg/lighttouch/android/Bootrom;

    invoke-virtual {v2}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u4e0b\u8f7d\u6765\u6e90\uff1a"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, ", and must match the "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " boot ROM \u5b8c\u5168\u4e00\u81f4\u3002"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v9, v2

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\11":I
    const/4 v3, 0x0

    .line 460
    .local v3, "$i$f$getDp\\11\\322":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 322
    .end local v2    # "$this$dp\\11":I
    .end local v3    # "$i$f$getDp\\11\\322":I
    const/16 v14, 0xd

    const/4 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static/range {v9 .. v15}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 323
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v8, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v8, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    .line 322
    nop

    .line 323
    nop

    .line 322
    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x30

    const/16 v24, 0x0

    const v25, 0xfff8

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 314
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 326
    :cond_b
    :goto_7
    return-void
.end method

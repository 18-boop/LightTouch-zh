.class public final Lorg/lighttouch/android/IpswDownload;
.super Ljava/lang/Object;
.source "FirmwareCatalog.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFirmwareCatalog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FirmwareCatalog.kt\norg/lighttouch/android/IpswDownload\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 SnapshotFloatState.kt\nandroidx/compose/runtime/PrimitiveSnapshotStateKt__SnapshotFloatStateKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,239:1\n81#2:240\n107#2,2:241\n81#2:246\n107#2,2:247\n81#2:249\n107#2,2:250\n79#3:243\n112#3,2:244\n1#4:252\n1669#5,8:253\n*S KotlinDebug\n*F\n+ 1 FirmwareCatalog.kt\norg/lighttouch/android/IpswDownload\n*L\n136#1:240\n136#1:241,2\n140#1:246\n140#1:247,2\n142#1:249\n142#1:250,2\n138#1:243\n138#1:244,2\n184#1:253,8\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0007\n\u0002\u0010\u0007\n\u0002\u0008\u0007\n\u0002\u0010\u000b\n\u0002\u0008\u000c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0010\t\n\u0002\u0008\u0003\u0008\u00c1\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$J\u0006\u0010%\u001a\u00020&J2\u0010\'\u001a\u00020&2\u0006\u0010#\u001a\u00020$2\u0006\u0010(\u001a\u00020)2\u001a\u0010*\u001a\u0016\u0012\u0006\u0012\u0004\u0018\u00010\"\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020&0+J\u0012\u0010,\u001a\u0004\u0018\u00010\u00052\u0006\u0010(\u001a\u00020)H\u0002J\u0018\u0010-\u001a\u00020\"2\u0006\u0010#\u001a\u00020$2\u0006\u0010(\u001a\u00020)H\u0002J \u0010.\u001a\u00020&2\u0006\u0010/\u001a\u00020\u00052\u0006\u00100\u001a\u00020\"2\u0006\u00101\u001a\u000202H\u0002J\u000e\u00103\u001a\u00020\u00052\u0006\u00104\u001a\u00020\"R+\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00058F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u000b\u0010\u000c\u001a\u0004\u0008\u0007\u0010\u0008\"\u0004\u0008\t\u0010\nR+\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0004\u001a\u00020\r8F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0013\u0010\u0014\u001a\u0004\u0008\u000f\u0010\u0010\"\u0004\u0008\u0011\u0010\u0012R+\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0004\u001a\u00020\u00158F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u001b\u0010\u000c\u001a\u0004\u0008\u0017\u0010\u0018\"\u0004\u0008\u0019\u0010\u001aR+\u0010\u001c\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00058F@BX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u001f\u0010\u000c\u001a\u0004\u0008\u001d\u0010\u0008\"\u0004\u0008\u001e\u0010\nR\u000e\u0010 \u001a\u00020\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00065"
    }
    d2 = {
        "Lorg/lighttouch/android/IpswDownload;",
        "",
        "<init>",
        "()V",
        "<set-?>",
        "",
        "firmwareId",
        "getFirmwareId",
        "()Ljava/lang/String;",
        "setFirmwareId",
        "(Ljava/lang/String;)V",
        "firmwareId$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "",
        "progress",
        "getProgress",
        "()F",
        "setProgress",
        "(F)V",
        "progress$delegate",
        "Landroidx/compose/runtime/MutableFloatState;",
        "",
        "running",
        "getRunning",
        "()Z",
        "setRunning",
        "(Z)V",
        "running$delegate",
        "status",
        "getStatus",
        "setStatus",
        "status$delegate",
        "cancelled",
        "directory",
        "Ljava/io/File;",
        "context",
        "Landroid/content/Context;",
        "cancel",
        "",
        "start",
        "firmware",
        "Lorg/lighttouch/android/CatalogFirmware;",
        "onDone",
        "Lkotlin/Function2;",
        "ipswMe",
        "download",
        "fetch",
        "link",
        "partial",
        "expected",
        "",
        "sha1",
        "file",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lorg/lighttouch/android/IpswDownload;

.field private static volatile cancelled:Z

.field private static final firmwareId$delegate:Landroidx/compose/runtime/MutableState;

.field private static final progress$delegate:Landroidx/compose/runtime/MutableFloatState;

.field private static final running$delegate:Landroidx/compose/runtime/MutableState;

.field private static final status$delegate:Landroidx/compose/runtime/MutableState;


# direct methods
.method public static synthetic $r8$lambda$6kKlRx8H-WciMxVUXJ_0ZYlJ0MY(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;Lkotlin/jvm/functions/Function2;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/IpswDownload;->start$lambda$0(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;Lkotlin/jvm/functions/Function2;)V

    return-void
.end method

.method public static synthetic $r8$lambda$8gAVCBJVMSdrtFRfnVZbwyawrQE(B)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/IpswDownload;->sha1$lambda$15(B)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 4

    new-instance v0, Lorg/lighttouch/android/IpswDownload;

    invoke-direct {v0}, Lorg/lighttouch/android/IpswDownload;-><init>()V

    sput-object v0, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    .line 136
    const-string v0, ""

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    sput-object v3, Lorg/lighttouch/android/IpswDownload;->firmwareId$delegate:Landroidx/compose/runtime/MutableState;

    .line 138
    const/high16 v3, -0x40800000    # -1.0f

    invoke-static {v3}, Landroidx/compose/runtime/PrimitiveSnapshotStateKt;->mutableFloatStateOf(F)Landroidx/compose/runtime/MutableFloatState;

    move-result-object v3

    sput-object v3, Lorg/lighttouch/android/IpswDownload;->progress$delegate:Landroidx/compose/runtime/MutableFloatState;

    .line 140
    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v3, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    sput-object v3, Lorg/lighttouch/android/IpswDownload;->running$delegate:Landroidx/compose/runtime/MutableState;

    .line 142
    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/IpswDownload;->status$delegate:Landroidx/compose/runtime/MutableState;

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/IpswDownload;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 135
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final download(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;)Ljava/io/File;
    .locals 18
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "firmware"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 179
    move-object/from16 v1, p0

    invoke-virtual/range {p0 .. p1}, Lorg/lighttouch/android/IpswDownload;->directory(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    move-object v2, v0

    .line 252
    .local v2, "$this$download_u24lambda_u244\\1":Ljava/io/File;
    const/4 v3, 0x0

    .line 179
    .local v3, "$i$a$-apply-IpswDownload$download$target$1\\1\\179\\0":I
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .end local v2    # "$this$download_u24lambda_u244\\1":Ljava/io/File;
    .end local v3    # "$i$a$-apply-IpswDownload$download$target$1\\1\\179\\0":I
    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/CatalogFirmware;->getFileName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 180
    .local v3, "target":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {v3}, Ljava/io/File;->length()J

    move-result-wide v4

    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/CatalogFirmware;->getBytes()J

    move-result-wide v6

    cmp-long v0, v4, v6

    if-nez v0, :cond_0

    invoke-virtual {v1, v3}, Lorg/lighttouch/android/IpswDownload;->sha1(Ljava/io/File;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-object v3

    .line 181
    :cond_0
    new-instance v0, Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ".partial"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v2, v0

    .line 183
    .local v2, "partial":Ljava/io/File;
    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/CatalogFirmware;->getFileName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string v5, ","

    const-string v6, "%2C"

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "https://archive.org/download/iOS_Firmware_Exhibit_Collection/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 184
    .local v4, "archive":Ljava/lang/String;
    move-object/from16 v5, p2

    invoke-direct {v1, v5}, Lorg/lighttouch/android/IpswDownload;->ipswMe(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOfNotNull(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getUrls()Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v0, v6}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-static {v0, v4}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$distinctBy\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 253
    .local v6, "$i$f$distinctBy\\2\\184":I
    new-instance v7, Ljava/util/HashSet;

    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    .line 254
    .local v7, "set\\2":Ljava/util/HashSet;
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 255
    .local v8, "list\\2":Ljava/util/ArrayList;
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_1
    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 256
    .local v10, "e\\2":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Ljava/lang/String;

    .local v11, "it\\3":Ljava/lang/String;
    const/16 v17, 0x0

    .line 184
    .local v17, "$i$a$-distinctBy-IpswDownload$download$links$1\\3\\256\\0":I
    const/4 v15, 0x4

    const/16 v16, 0x0

    const-string v12, "%2C"

    const-string v13, ","

    const/4 v14, 0x0

    invoke-static/range {v11 .. v16}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    .line 256
    .end local v11    # "it\\3":Ljava/lang/String;
    .end local v17    # "$i$a$-distinctBy-IpswDownload$download$links$1\\3\\256\\0":I
    nop

    .line 257
    .local v11, "key\\2":Ljava/lang/Object;
    invoke-virtual {v7, v11}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1

    .line 258
    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 260
    .end local v10    # "e\\2":Ljava/lang/Object;
    .end local v11    # "key\\2":Ljava/lang/Object;
    :cond_2
    move-object v0, v8

    check-cast v0, Ljava/util/List;

    .line 184
    .end local v0    # "$this$distinctBy\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$distinctBy\\2\\184":I
    .end local v7    # "set\\2":Ljava/util/HashSet;
    .end local v8    # "list\\2":Ljava/util/ArrayList;
    move-object v6, v0

    .line 185
    .local v6, "links":Ljava/util/List;
    move-object v0, v6

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_9

    .line 186
    const-string v0, ""

    .line 187
    .local v0, "failure":Ljava/lang/String;
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move-object v8, v0

    .end local v0    # "failure":Ljava/lang/String;
    .local v8, "failure":Ljava/lang/String;
    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/lang/String;

    .line 188
    .local v9, "link":Ljava/lang/String;
    sget-boolean v0, Lorg/lighttouch/android/IpswDownload;->cancelled:Z

    const-string v10, "\u4e0b\u8f7d\u5df2\u53d6\u6d88"

    if-nez v0, :cond_7

    .line 189
    nop

    .line 190
    :try_start_0
    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getBytes()J

    move-result-wide v11

    invoke-direct {v1, v9, v2, v11, v12}, Lorg/lighttouch/android/IpswDownload;->fetch(Ljava/lang/String;Ljava/io/File;J)V

    .line 191
    const-string v0, "\u6b63\u5728\u6821\u9a8c\u4e0b\u8f7d\u5185\u5bb9"

    invoke-direct {v1, v0}, Lorg/lighttouch/android/IpswDownload;->setStatus(Ljava/lang/String;)V

    .line 192
    invoke-virtual {v1, v2}, Lorg/lighttouch/android/IpswDownload;->sha1(Ljava/io/File;)Ljava/lang/String;

    move-result-object v0

    .line 193
    .local v0, "digest":Ljava/lang/String;
    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-lez v11, :cond_3

    const/4 v11, 0x1

    goto :goto_2

    :cond_3
    const/4 v11, 0x0

    :goto_2
    if-eqz v11, :cond_4

    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v11

    invoke-static {v0, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_4

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    new-instance v11, Ljava/net/URL;

    invoke-direct {v11, v9}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "The download from "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, " did not match"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    move-object v8, v10

    goto :goto_1

    .line 194
    :cond_4
    invoke-virtual {v2, v3}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v11

    if-eqz v11, :cond_5

    .line 195
    return-object v3

    .line 252
    :cond_5
    const/4 v11, 0x0

    .line 194
    .local v11, "$i$a$-check-IpswDownload$download$3\\6\\194\\0":I
    const-string v12, "\u65e0\u6cd5\u4fdd\u5b58 IPSW"

    .end local v11    # "$i$a$-check-IpswDownload$download$3\\6\\194\\0":I
    new-instance v11, Ljava/lang/IllegalStateException;

    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v2    # "partial":Ljava/io/File;
    .end local v3    # "target":Ljava/io/File;
    .end local v4    # "archive":Ljava/lang/String;
    .end local v6    # "links":Ljava/util/List;
    .end local v8    # "failure":Ljava/lang/String;
    .end local v9    # "link":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "context":Landroid/content/Context;
    .end local p2    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    throw v11
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 196
    .end local v0    # "digest":Ljava/lang/String;
    .restart local v2    # "partial":Ljava/io/File;
    .restart local v3    # "target":Ljava/io/File;
    .restart local v4    # "archive":Ljava/lang/String;
    .restart local v6    # "links":Ljava/util/List;
    .restart local v8    # "failure":Ljava/lang/String;
    .restart local v9    # "link":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "context":Landroid/content/Context;
    .restart local p2    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    :catch_0
    move-exception v0

    .line 197
    .local v0, "e":Ljava/lang/Exception;
    sget-boolean v11, Lorg/lighttouch/android/IpswDownload;->cancelled:Z

    if-nez v11, :cond_6

    .line 198
    new-instance v10, Ljava/net/URL;

    invoke-direct {v10, v9}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v12, ": "

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .end local v0    # "e":Ljava/lang/Exception;
    .end local v9    # "link":Ljava/lang/String;
    goto/16 :goto_1

    .line 197
    .restart local v0    # "e":Ljava/lang/Exception;
    .restart local v9    # "link":Ljava/lang/String;
    :cond_6
    new-instance v7, Ljava/lang/IllegalStateException;

    invoke-direct {v7, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v7

    .line 252
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_7
    const/4 v0, 0x0

    .line 188
    .local v0, "$i$a$-check-IpswDownload$download$2\\5\\188\\0":I
    nop

    .end local v0    # "$i$a$-check-IpswDownload$download$2\\5\\188\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v0, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 198
    .end local v9    # "link":Ljava/lang/String;
    :cond_8
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 201
    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v7

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Could not download iOS "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v9, " ("

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v9, ")"

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v0, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 252
    .end local v8    # "failure":Ljava/lang/String;
    :cond_9
    const/4 v0, 0x0

    .line 185
    .local v0, "$i$a$-require-IpswDownload$download$1\\4\\185\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "No download is known for iOS "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "; choose an IPSW you have instead"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v0    # "$i$a$-require-IpswDownload$download$1\\4\\185\\0":I
    new-instance v7, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v7
.end method

.method private final fetch(Ljava/lang/String;Ljava/io/File;J)V
    .locals 25
    .param p1, "link"    # Ljava/lang/String;
    .param p2, "partial"    # Ljava/io/File;
    .param p3, "expected"    # J

    .line 205
    move-object/from16 v1, p1

    const-wide/16 v2, 0x0

    .local v2, "have":J
    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->isFile()Z

    move-result v0

    const-wide/16 v4, 0x0

    if-eqz v0, :cond_0

    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->length()J

    move-result-wide v6

    goto :goto_0

    :cond_0
    move-wide v6, v4

    .line 206
    .end local v2    # "have":J
    .local v6, "have":J
    :goto_0
    cmp-long v0, p3, v4

    if-lez v0, :cond_1

    cmp-long v0, v6, p3

    if-lez v0, :cond_1

    invoke-virtual/range {p2 .. p2}, Ljava/io/File;->delete()Z

    const-wide/16 v6, 0x0

    .line 207
    :cond_1
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    const-string v2, "null cannot be cast to non-null type java.net.HttpURLConnection"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v0

    check-cast v2, Ljava/net/HttpURLConnection;

    .line 208
    .local v2, "connection":Ljava/net/HttpURLConnection;
    const/16 v0, 0x3a98

    invoke-virtual {v2, v0}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v0, 0x7530

    invoke-virtual {v2, v0}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    const/4 v0, 0x1

    invoke-virtual {v2, v0}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 209
    cmp-long v3, v6, v4

    if-lez v3, :cond_2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "bytes="

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v8, "-"

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v8, "Range"

    invoke-virtual {v2, v8, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 210
    :cond_2
    nop

    .line 211
    :try_start_0
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_a

    .line 212
    .local v3, "code":I
    const/16 v8, 0x1a0

    if-ne v3, v8, :cond_3

    cmp-long v8, v6, p3

    if-nez v8, :cond_3

    .line 230
    .end local v3    # "code":I
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 212
    .restart local v3    # "code":I
    return-void

    .line 213
    :cond_3
    const/16 v8, 0xc8

    const/4 v9, 0x0

    if-eq v3, v8, :cond_5

    const/16 v10, 0xce

    if-ne v3, v10, :cond_4

    goto :goto_1

    :cond_4
    move v10, v9

    goto :goto_2

    :cond_5
    :goto_1
    move v10, v0

    :goto_2
    if-eqz v10, :cond_e

    .line 214
    if-ne v3, v8, :cond_6

    const-wide/16 v6, 0x0

    .line 215
    :cond_6
    cmp-long v8, p3, v4

    if-lez v8, :cond_7

    move-wide/from16 v10, p3

    goto :goto_3

    :cond_7
    :try_start_1
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getContentLengthLong()J

    move-result-wide v10

    add-long/2addr v10, v6

    .line 216
    .local v10, "total":J
    :goto_3
    new-instance v8, Ljava/net/URL;

    invoke-direct {v8, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v8

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Downloading from "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_a

    move-object/from16 v12, p0

    :try_start_2
    invoke-direct {v12, v8}, Lorg/lighttouch/android/IpswDownload;->setStatus(Ljava/lang/String;)V

    .line 217
    new-instance v8, Ljava/io/RandomAccessFile;

    const-string v13, "rw"
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_8

    move-object/from16 v14, p2

    :try_start_3
    invoke-direct {v8, v14, v13}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    check-cast v8, Ljava/io/Closeable;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_7

    :try_start_4
    move-object v13, v8

    check-cast v13, Ljava/io/RandomAccessFile;

    .local v13, "out\\2":Ljava/io/RandomAccessFile;
    const/4 v15, 0x0

    .line 218
    .local v15, "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    invoke-virtual {v13, v6, v7}, Ljava/io/RandomAccessFile;->setLength(J)V

    invoke-virtual {v13, v6, v7}, Ljava/io/RandomAccessFile;->seek(J)V

    .line 219
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v16

    move-wide/from16 v17, v4

    move-object/from16 v4, v16

    check-cast v4, Ljava/io/Closeable;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    :try_start_5
    move-object v5, v4

    check-cast v5, Ljava/io/InputStream;

    .local v5, "input\\3":Ljava/io/InputStream;
    const/16 v16, 0x0

    .line 220
    .local v16, "$i$a$-use-IpswDownload$fetch$2$1\\3\\219\\2":I
    const/high16 v0, 0x10000

    new-array v0, v0, [B

    .line 221
    .local v0, "buffer\\3":[B
    :goto_4
    nop

    .line 222
    sget-boolean v19, Lorg/lighttouch/android/IpswDownload;->cancelled:Z

    if-nez v19, :cond_d

    .line 223
    invoke-virtual {v5, v0}, Ljava/io/InputStream;->read([B)I

    move-result v19

    move/from16 v20, v19

    .local v20, "n\\3":I
    if-ltz v20, :cond_9

    .line 224
    move/from16 v1, v20

    .end local v20    # "n\\3":I
    .local v1, "n\\3":I
    invoke-virtual {v13, v0, v9, v1}, Ljava/io/RandomAccessFile;->write([BII)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    move-wide/from16 v20, v10

    .end local v10    # "total":J
    .local v20, "total":J
    int-to-long v9, v1

    add-long/2addr v6, v9

    .line 225
    cmp-long v9, v20, v17

    if-lez v9, :cond_8

    :try_start_6
    sget-object v9, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    long-to-float v10, v6

    move/from16 v22, v1

    move-object v11, v2

    move-wide/from16 v1, v20

    move-object/from16 v20, v0

    .end local v0    # "buffer\\3":[B
    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .local v1, "total":J
    .local v11, "connection":Ljava/net/HttpURLConnection;
    .local v20, "buffer\\3":[B
    .local v22, "n\\3":I
    long-to-float v0, v1

    div-float/2addr v10, v0

    const/4 v0, 0x0

    move-wide/from16 v23, v1

    .end local v1    # "total":J
    .local v23, "total":J
    const/high16 v1, 0x3f800000    # 1.0f

    :try_start_7
    invoke-static {v10, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    invoke-direct {v9, v0}, Lorg/lighttouch/android/IpswDownload;->setProgress(F)V

    .end local v22    # "n\\3":I
    goto :goto_5

    .line 219
    .end local v5    # "input\\3":Ljava/io/InputStream;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v16    # "$i$a$-use-IpswDownload$fetch$2$1\\3\\219\\2":I
    .end local v23    # "total":J
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .local v20, "total":J
    :catchall_0
    move-exception v0

    move-object v11, v2

    move-wide/from16 v23, v20

    move-object v1, v0

    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .end local v20    # "total":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v23    # "total":J
    goto/16 :goto_8

    .line 225
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v23    # "total":J
    .restart local v0    # "buffer\\3":[B
    .local v1, "n\\3":I
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v5    # "input\\3":Ljava/io/InputStream;
    .restart local v16    # "$i$a$-use-IpswDownload$fetch$2$1\\3\\219\\2":I
    .restart local v20    # "total":J
    :cond_8
    move/from16 v22, v1

    move-object v11, v2

    move-wide/from16 v23, v20

    move-object/from16 v20, v0

    .line 221
    .end local v0    # "buffer\\3":[B
    .end local v1    # "n\\3":I
    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .local v20, "buffer\\3":[B
    .restart local v23    # "total":J
    :goto_5
    move-object/from16 v1, p1

    move-object v2, v11

    move-object/from16 v0, v20

    move-wide/from16 v10, v23

    const/4 v9, 0x0

    goto :goto_4

    .line 223
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v23    # "total":J
    .restart local v0    # "buffer\\3":[B
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v10    # "total":J
    .local v20, "n\\3":I
    :cond_9
    move-wide/from16 v23, v10

    move/from16 v22, v20

    move-object/from16 v20, v0

    move-object v11, v2

    .line 227
    .end local v0    # "buffer\\3":[B
    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .end local v10    # "total":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .local v20, "buffer\\3":[B
    .restart local v23    # "total":J
    nop

    .end local v5    # "input\\3":Ljava/io/InputStream;
    .end local v16    # "$i$a$-use-IpswDownload$fetch$2$1\\3\\219\\2":I
    .end local v20    # "buffer\\3":[B
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 219
    const/4 v0, 0x0

    :try_start_8
    invoke-static {v4, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 228
    nop

    .end local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .end local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 217
    :try_start_9
    invoke-static {v8, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_9

    .line 229
    cmp-long v0, p3, v17

    if-lez v0, :cond_b

    cmp-long v0, v6, p3

    if-nez v0, :cond_a

    goto :goto_6

    :cond_a
    const/4 v0, 0x0

    goto :goto_7

    :cond_b
    :goto_6
    const/4 v0, 0x1

    :goto_7
    if-eqz v0, :cond_c

    .line 230
    .end local v3    # "code":I
    .end local v23    # "total":J
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 231
    return-void

    .line 252
    .restart local v3    # "code":I
    .restart local v23    # "total":J
    :cond_c
    const/4 v0, 0x0

    .line 229
    .local v0, "$i$a$-check-IpswDownload$fetch$3\\5\\229\\0":I
    :try_start_a
    const-string v1, "\u4e0b\u8f7d\u63d0\u524d\u4e2d\u65ad"

    .end local v0    # "$i$a$-check-IpswDownload$fetch$3\\5\\229\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v6    # "have":J
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_9

    .line 252
    .end local v23    # "total":J
    .local v0, "buffer\\3":[B
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v5    # "input\\3":Ljava/io/InputStream;
    .restart local v6    # "have":J
    .restart local v10    # "total":J
    .restart local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .restart local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    .restart local v16    # "$i$a$-use-IpswDownload$fetch$2$1\\3\\219\\2":I
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :cond_d
    move-object/from16 v20, v0

    move-wide/from16 v23, v10

    move-object v11, v2

    .end local v0    # "buffer\\3":[B
    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .end local v10    # "total":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v20    # "buffer\\3":[B
    .restart local v23    # "total":J
    const/4 v0, 0x0

    .line 222
    .local v0, "$i$a$-check-IpswDownload$fetch$2$1$1\\4\\222\\3":I
    :try_start_b
    const-string v1, "\u4e0b\u8f7d\u5df2\u53d6\u6d88"

    .end local v0    # "$i$a$-check-IpswDownload$fetch$2$1$1\\4\\222\\3":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v3    # "code":I
    .end local v6    # "have":J
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .end local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    .end local v23    # "total":J
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    .line 219
    .end local v5    # "input\\3":Ljava/io/InputStream;
    .end local v16    # "$i$a$-use-IpswDownload$fetch$2$1\\3\\219\\2":I
    .end local v20    # "buffer\\3":[B
    .restart local v3    # "code":I
    .restart local v6    # "have":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .restart local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    .restart local v23    # "total":J
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :catchall_1
    move-exception v0

    move-object v1, v0

    goto :goto_8

    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v23    # "total":J
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v10    # "total":J
    :catchall_2
    move-exception v0

    move-wide/from16 v23, v10

    move-object v11, v2

    move-object v1, v0

    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .end local v3    # "code":I
    .end local v6    # "have":J
    .end local v10    # "total":J
    .end local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .end local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    :goto_8
    :try_start_c
    throw v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    .restart local v3    # "code":I
    .restart local v6    # "have":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .restart local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    .restart local v23    # "total":J
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :catchall_3
    move-exception v0

    :try_start_d
    invoke-static {v4, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v3    # "code":I
    .end local v6    # "have":J
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v23    # "total":J
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    throw v0
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 217
    .end local v13    # "out\\2":Ljava/io/RandomAccessFile;
    .end local v15    # "$i$a$-use-IpswDownload$fetch$2\\2\\217\\0":I
    .restart local v3    # "code":I
    .restart local v6    # "have":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v23    # "total":J
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :catchall_4
    move-exception v0

    move-object v1, v0

    goto :goto_9

    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v23    # "total":J
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v10    # "total":J
    :catchall_5
    move-exception v0

    move-wide/from16 v23, v10

    move-object v11, v2

    move-object v1, v0

    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .end local v3    # "code":I
    .end local v6    # "have":J
    .end local v10    # "total":J
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    :goto_9
    :try_start_e
    throw v1
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_6

    .restart local v3    # "code":I
    .restart local v6    # "have":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v23    # "total":J
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :catchall_6
    move-exception v0

    :try_start_f
    invoke-static {v8, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v6    # "have":J
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    throw v0

    .line 230
    .end local v3    # "code":I
    .end local v23    # "total":J
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v6    # "have":J
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :catchall_7
    move-exception v0

    goto :goto_b

    :catchall_8
    move-exception v0

    goto :goto_a

    .line 252
    .restart local v3    # "code":I
    :cond_e
    move-object/from16 v12, p0

    move-object/from16 v14, p2

    move-object v11, v2

    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    const/4 v0, 0x0

    .line 213
    .local v0, "$i$a$-check-IpswDownload$fetch$1\\1\\213\\0":I
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "HTTP "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v0    # "$i$a$-check-IpswDownload$fetch$1\\1\\213\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v6    # "have":J
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "link":Ljava/lang/String;
    .end local p2    # "partial":Ljava/io/File;
    .end local p3    # "expected":J
    throw v0
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_9

    .line 230
    .end local v3    # "code":I
    .restart local v6    # "have":J
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "link":Ljava/lang/String;
    .restart local p2    # "partial":Ljava/io/File;
    .restart local p3    # "expected":J
    :catchall_9
    move-exception v0

    goto :goto_c

    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v2    # "connection":Ljava/net/HttpURLConnection;
    :catchall_a
    move-exception v0

    move-object/from16 v12, p0

    :goto_a
    move-object/from16 v14, p2

    :goto_b
    move-object v11, v2

    .end local v2    # "connection":Ljava/net/HttpURLConnection;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    :goto_c
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v0
.end method

.method private final ipswMe(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/String;
    .locals 11
    .param p1, "firmware"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 166
    nop

    .line 167
    const/4 v0, 0x0

    :try_start_0
    new-instance v1, Ljava/net/URL;

    invoke-virtual {p1}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Lorg/lighttouch/android/CatalogFirmware;->getBuild()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "https://api.ipsw.me/v4/ipsw/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "/"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    const-string v2, "null cannot be cast to non-null type java.net.HttpURLConnection"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/net/HttpURLConnection;

    .line 168
    .local v1, "connection":Ljava/net/HttpURLConnection;
    const/16 v2, 0x2710

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 169
    const-string v2, "Accept"

    const-string v3, "application/json"

    invoke-virtual {v1, v2, v3}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 170
    nop

    .line 171
    :try_start_1
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    const/16 v3, 0xc8

    if-eq v2, v3, :cond_0

    move-object v4, v0

    goto/16 :goto_2

    .line 172
    :cond_0
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v2

    const-string v3, "getInputStream(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v4, Ljava/io/InputStreamReader;

    invoke-direct {v4, v2, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v4, Ljava/io/Reader;

    instance-of v2, v4, Ljava/io/BufferedReader;

    if-eqz v2, :cond_1

    check-cast v4, Ljava/io/BufferedReader;

    goto :goto_0

    :cond_1
    new-instance v2, Ljava/io/BufferedReader;

    const/16 v3, 0x2000

    invoke-direct {v2, v4, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v4, v2

    :goto_0
    check-cast v4, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v2, v4

    check-cast v2, Ljava/io/BufferedReader;

    .line 252
    .local v2, "it\\1":Ljava/io/BufferedReader;
    const/4 v3, 0x0

    .line 172
    .local v3, "$i$a$-use-IpswDownload$ipswMe$1\\1\\172\\0":I
    move-object v5, v2

    check-cast v5, Ljava/io/Reader;

    invoke-static {v5}, Lkotlin/io/TextStreamsKt;->readText(Ljava/io/Reader;)Ljava/lang/String;

    move-result-object v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v2    # "it\\1":Ljava/io/BufferedReader;
    .end local v3    # "$i$a$-use-IpswDownload$ipswMe$1\\1\\172\\0":I
    :try_start_3
    invoke-static {v4, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .local v2, "info\\2":Lorg/json/JSONObject;
    const/4 v3, 0x0

    .line 173
    .local v3, "$i$a$-let-IpswDownload$ipswMe$2\\2\\172\\0":I
    const-string v4, "url"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v5, v4

    .line 252
    .local v5, "it\\3":Ljava/lang/String;
    const/4 v6, 0x0

    .line 173
    .local v6, "$i$a$-takeIf-IpswDownload$ipswMe$2$1\\3\\173\\2":I
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v7, "https://"

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v5, v7, v9, v8, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    invoke-virtual {p1}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    const/4 v8, 0x1

    if-nez v7, :cond_2

    move v7, v8

    goto :goto_1

    :cond_2
    move v7, v9

    :goto_1
    if-nez v7, :cond_3

    const-string v7, "sha1sum"

    invoke-virtual {v2, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v10

    invoke-static {v7, v10, v8}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-eqz v7, :cond_4

    :cond_3
    move v9, v8

    .end local v5    # "it\\3":Ljava/lang/String;
    .end local v6    # "$i$a$-takeIf-IpswDownload$ipswMe$2$1\\3\\173\\2":I
    :cond_4
    if-eqz v9, :cond_5

    goto :goto_2

    :cond_5
    move-object v4, v0

    .line 172
    .end local v2    # "info\\2":Lorg/json/JSONObject;
    .end local v3    # "$i$a$-let-IpswDownload$ipswMe$2\\2\\172\\0":I
    :goto_2
    nop

    .line 175
    :try_start_4
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    move-object v0, v4

    .end local v1    # "connection":Ljava/net/HttpURLConnection;
    goto :goto_3

    .line 172
    .restart local v1    # "connection":Ljava/net/HttpURLConnection;
    :catchall_0
    move-exception v2

    .end local v1    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    :try_start_5
    throw v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v1    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    :catchall_1
    move-exception v3

    :try_start_6
    invoke-static {v4, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v1    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    throw v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 175
    .restart local v1    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    :catchall_2
    move-exception v2

    :try_start_7
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    throw v2
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    .line 176
    .end local v1    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    :catch_0
    move-exception v1

    :goto_3
    return-object v0
.end method

.method private final setFirmwareId(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 136
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->firmwareId$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 241
    .local v2, "$i$f$setValue\\1\\136":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 242
    nop

    .line 136
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\136":I
    return-void
.end method

.method private final setProgress(F)V
    .locals 3
    .param p1, "<set-?>"    # F

    .line 138
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->progress$delegate:Landroidx/compose/runtime/MutableFloatState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableFloatState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 244
    .local v2, "$i$f$setValue\\1\\138":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableFloatState;->setFloatValue(F)V

    .line 245
    nop

    .line 138
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableFloatState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\138":I
    return-void
.end method

.method private final setRunning(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 140
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->running$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 247
    .local v3, "$i$f$setValue\\1\\140":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 248
    nop

    .line 140
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\140":I
    return-void
.end method

.method private final setStatus(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 142
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->status$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 250
    .local v2, "$i$f$setValue\\1\\142":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 251
    nop

    .line 142
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\142":I
    return-void
.end method

.method private static final sha1$lambda$15(B)Ljava/lang/CharSequence;
    .locals 2
    .param p0, "it"    # B

    .line 236
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02x"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private static final start$lambda$0(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;Lkotlin/jvm/functions/Function2;)V
    .locals 4
    .param p0, "$app"    # Landroid/content/Context;
    .param p1, "$firmware"    # Lorg/lighttouch/android/CatalogFirmware;
    .param p2, "$onDone"    # Lkotlin/jvm/functions/Function2;

    .line 157
    const-string v0, ""

    :try_start_0
    sget-object v1, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, p0, p1}, Lorg/lighttouch/android/IpswDownload;->download(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;)Ljava/io/File;

    move-result-object v1

    invoke-static {v1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    .local v1, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_0

    const-string v2, "\u4e0b\u8f7d\u5931\u8d25"

    :cond_0
    const/4 v3, 0x0

    invoke-static {v3, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    move-object v1, v2

    .line 158
    .local v1, "result":Lkotlin/Pair;
    :goto_0
    sget-object v2, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v2, p0}, Lorg/lighttouch/android/DownloadService$Companion;->release(Landroid/content/Context;)V

    .line 159
    sget-object v2, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lorg/lighttouch/android/IpswDownload;->setRunning(Z)V

    .line 160
    sget-object v2, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    :goto_1
    invoke-direct {v2, v0}, Lorg/lighttouch/android/IpswDownload;->setStatus(Ljava/lang/String;)V

    .line 161
    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {p2, v0, v2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    return-void
.end method


# virtual methods
.method public final cancel()V
    .locals 1

    .line 148
    const/4 v0, 0x1

    sput-boolean v0, Lorg/lighttouch/android/IpswDownload;->cancelled:Z

    return-void
.end method

.method public final directory(Landroid/content/Context;)Ljava/io/File;
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    new-instance v0, Ljava/io/File;

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "ipsw"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public final getFirmwareId()Ljava/lang/String;
    .locals 3

    .line 136
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->firmwareId$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 240
    .local v2, "$i$f$getValue\\1\\136":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\136":I
    check-cast v0, Ljava/lang/String;

    .line 136
    return-object v0
.end method

.method public final getProgress()F
    .locals 3

    .line 138
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->progress$delegate:Landroidx/compose/runtime/MutableFloatState;

    check-cast v0, Landroidx/compose/runtime/FloatState;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/FloatState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 243
    .local v2, "$i$f$getValue\\1\\138":I
    invoke-interface {v0}, Landroidx/compose/runtime/FloatState;->getFloatValue()F

    move-result v0

    .line 138
    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/FloatState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\138":I
    return v0
.end method

.method public final getRunning()Z
    .locals 3

    .line 140
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->running$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 246
    .local v2, "$i$f$getValue\\1\\140":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\140":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 140
    return v0
.end method

.method public final getStatus()Ljava/lang/String;
    .locals 3

    .line 142
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->status$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 249
    .local v2, "$i$f$getValue\\1\\142":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\142":I
    check-cast v0, Ljava/lang/String;

    .line 142
    return-object v0
.end method

.method public final sha1(Ljava/io/File;)Ljava/lang/String;
    .locals 12
    .param p1, "file"    # Ljava/io/File;

    const-string v0, "file"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    const-string v0, "SHA-1"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    .local v1, "digest":Ljava/security/MessageDigest;
    new-instance v0, Ljava/io/FileInputStream;

    .line 235
    invoke-direct {v0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v2

    check-cast v0, Ljava/io/FileInputStream;

    .line 252
    .local v0, "input\\1":Ljava/io/FileInputStream;
    const/4 v3, 0x0

    .line 235
    .local v3, "$i$a$-use-IpswDownload$sha1$1\\1\\235\\0":I
    const/high16 v4, 0x100000

    new-array v4, v4, [B

    .local v4, "buffer\\1":[B
    :goto_0
    invoke-virtual {v0, v4}, Ljava/io/FileInputStream;->read([B)I

    move-result v5

    .local v5, "n\\1":I
    if-ltz v5, :cond_0

    const/4 v6, 0x0

    invoke-virtual {v1, v4, v6, v5}, Ljava/security/MessageDigest;->update([BII)V

    .end local v5    # "n\\1":I
    goto :goto_0

    .end local v0    # "input\\1":Ljava/io/FileInputStream;
    .end local v3    # "$i$a$-use-IpswDownload$sha1$1\\1\\235\\0":I
    .end local v4    # "buffer\\1":[B
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x0

    invoke-static {v2, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 236
    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v3

    const-string v0, "digest(...)"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, ""

    move-object v4, v0

    check-cast v4, Ljava/lang/CharSequence;

    new-instance v9, Lorg/lighttouch/android/IpswDownload$$ExternalSyntheticLambda0;

    invoke-direct {v9}, Lorg/lighttouch/android/IpswDownload$$ExternalSyntheticLambda0;-><init>()V

    const/16 v10, 0x1e

    const/4 v11, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v3 .. v11}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 235
    :catchall_0
    move-exception v0

    move-object v3, v0

    .end local v1    # "digest":Ljava/security/MessageDigest;
    .end local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .end local p1    # "file":Ljava/io/File;
    :try_start_1
    throw v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local v1    # "digest":Ljava/security/MessageDigest;
    .restart local p0    # "this":Lorg/lighttouch/android/IpswDownload;
    .restart local p1    # "file":Ljava/io/File;
    :catchall_1
    move-exception v0

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final start(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;Lkotlin/jvm/functions/Function2;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "firmware"    # Lorg/lighttouch/android/CatalogFirmware;
    .param p3, "onDone"    # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lorg/lighttouch/android/CatalogFirmware;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/io/File;",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "firmware"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDone"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 152
    invoke-virtual {p0}, Lorg/lighttouch/android/IpswDownload;->getRunning()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 153
    :cond_0
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/IpswDownload;->setRunning(Z)V

    const/4 v0, 0x0

    sput-boolean v0, Lorg/lighttouch/android/IpswDownload;->cancelled:Z

    invoke-virtual {p2}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/IpswDownload;->setFirmwareId(Ljava/lang/String;)V

    const/high16 v0, -0x40800000    # -1.0f

    invoke-direct {p0, v0}, Lorg/lighttouch/android/IpswDownload;->setProgress(F)V

    invoke-virtual {p2}, Lorg/lighttouch/android/CatalogFirmware;->getFileName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Looking up "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/IpswDownload;->setStatus(Ljava/lang/String;)V

    .line 154
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 155
    .local v0, "app":Landroid/content/Context;
    sget-object v1, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {p2}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Downloading iOS "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v0, v2}, Lorg/lighttouch/android/DownloadService$Companion;->hold(Landroid/content/Context;Ljava/lang/String;)V

    .line 156
    new-instance v1, Ljava/lang/Thread;

    .line 162
    new-instance v2, Lorg/lighttouch/android/IpswDownload$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0, p2, p3}, Lorg/lighttouch/android/IpswDownload$$ExternalSyntheticLambda1;-><init>(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;Lkotlin/jvm/functions/Function2;)V

    .line 156
    const-string v3, "ipsw-download"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 162
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 163
    return-void
.end method

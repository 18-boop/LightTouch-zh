.class final Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;
.super Ljava/lang/Object;
.source "SetupWizard.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function4<",
        "Landroidx/compose/animation/AnimatedContentScope;",
        "Lorg/lighttouch/android/SetupStep;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSetupWizard.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SetupWizard.kt\norg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,247:1\n1225#2,6:248\n*S KotlinDebug\n*F\n+ 1 SetupWizard.kt\norg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2\n*L\n84#1:248,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $onCreate:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onFinish:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onPickFolder:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onPickRom:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onPickSystem:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onPrepare:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $state:Lorg/lighttouch/android/SetupState;


# direct methods
.method public static synthetic $r8$lambda$RmJhOmWm3GnSno249yw1vqxC5sg(Lorg/lighttouch/android/SetupState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->invoke$lambda$1$lambda$0(Lorg/lighttouch/android/SetupState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lorg/lighttouch/android/SetupState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPrepare:Lkotlin/jvm/functions/Function0;

    iput-object p2, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    iput-object p3, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPickFolder:Lkotlin/jvm/functions/Function0;

    iput-object p4, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPickSystem:Lkotlin/jvm/functions/Function0;

    iput-object p5, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPickRom:Lkotlin/jvm/functions/Function0;

    iput-object p6, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onCreate:Lkotlin/jvm/functions/Function0;

    iput-object p7, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onFinish:Lkotlin/jvm/functions/Function1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Lorg/lighttouch/android/SetupState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$state"    # Lorg/lighttouch/android/SetupState;

    .line 84
    sget-object v0, Lorg/lighttouch/android/SetupStep;->FILES:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;
    .param p4, "p4"    # Ljava/lang/Object;

    .line 82
    move-object v0, p1

    check-cast v0, Landroidx/compose/animation/AnimatedContentScope;

    move-object v1, p2

    check-cast v1, Lorg/lighttouch/android/SetupStep;

    move-object v2, p3

    check-cast v2, Landroidx/compose/runtime/Composer;

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->invoke(Landroidx/compose/animation/AnimatedContentScope;Lorg/lighttouch/android/SetupStep;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/animation/AnimatedContentScope;Lorg/lighttouch/android/SetupStep;Landroidx/compose/runtime/Composer;I)V
    .locals 10
    .param p1, "$this$AnimatedContent"    # Landroidx/compose/animation/AnimatedContentScope;
    .param p2, "step"    # Lorg/lighttouch/android/SetupStep;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$AnimatedContent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "step"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C:SetupWizard.kt#o13vsk"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const-string v1, "org.lighttouch.android.SetupWizard.<anonymous>.<anonymous>.<anonymous> (SetupWizard.kt:82)"

    const v2, 0x224dd45a

    invoke-static {v2, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 83
    :cond_0
    sget-object v0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p2}, Lorg/lighttouch/android/SetupStep;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_0

    move-object v7, p3

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const p3, -0x39d5d546

    invoke-interface {v7, p3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance p3, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {p3}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw p3

    .line 87
    .end local v7    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p3    # "$composer":Landroidx/compose/runtime/Composer;
    :pswitch_0
    const v0, -0x39d5ac89

    invoke-interface {p3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "86@4884L61"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0}, Lorg/lighttouch/android/SetupState;->getCreated()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "\u4f60\u7684\u8bbe\u5907"

    :cond_1
    iget-object v2, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v2}, Lorg/lighttouch/android/SetupState;->getTimings()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onFinish:Lkotlin/jvm/functions/Function1;

    invoke-static {v0, v2, v3, p3, v1}, Lorg/lighttouch/android/SetupWizardKt;->access$Done(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v7, p3

    goto/16 :goto_2

    .line 86
    :pswitch_1
    const v0, -0x39d5b621

    invoke-interface {p3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "85@4808L37"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0}, Lorg/lighttouch/android/SetupState;->getPhase()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v2}, Lorg/lighttouch/android/SetupState;->getProgress()F

    move-result v2

    invoke-static {v0, v2, p3, v1}, Lorg/lighttouch/android/SetupWizardKt;->access$Creating(Ljava/lang/String;FLandroidx/compose/runtime/Composer;I)V

    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v7, p3

    goto/16 :goto_2

    .line 85
    :pswitch_2
    const v0, -0x39d5c45e

    invoke-interface {p3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "84@4693L72"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    iget-object v2, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPickFolder:Lkotlin/jvm/functions/Function0;

    iget-object v3, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPickSystem:Lkotlin/jvm/functions/Function0;

    iget-object v4, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPickRom:Lkotlin/jvm/functions/Function0;

    iget-object v5, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onCreate:Lkotlin/jvm/functions/Function0;

    iget-object v6, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPrepare:Lkotlin/jvm/functions/Function0;

    const/4 v8, 0x0

    move-object v7, p3

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v1 .. v8}, Lorg/lighttouch/android/SetupWizardKt;->access$Files(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_2

    .line 84
    .end local v7    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p3    # "$composer":Landroidx/compose/runtime/Composer;
    :pswitch_3
    move-object v7, p3

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer":Landroidx/compose/runtime/Composer;
    const p3, -0x39d5cfd3

    invoke-interface {v7, p3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string p3, "83@4621L32,83@4602L51"

    invoke-static {v7, p3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object p3, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$onPrepare:Lkotlin/jvm/functions/Function0;

    const v0, 0x4c5de2

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\1":Z
    iget-object v2, p0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2;->$state:Lorg/lighttouch/android/SetupState;

    move-object v3, v7

    .local v3, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 248
    .local v4, "$i$f$cache\\1\\84":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\1":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 249
    .local v6, "$i$a$-let-ComposerKt$cache$1\\2\\248\\1":I
    if-nez v0, :cond_3

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v5, v8, :cond_2

    goto :goto_0

    .line 253
    :cond_2
    move-object v9, v5

    goto :goto_1

    .line 250
    :cond_3
    :goto_0
    const/4 v8, 0x0

    .line 84
    .local v8, "$i$a$-cache-SetupWizardKt$SetupWizard$3$1$2$1\\3\\250\\0":I
    new-instance v9, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2$$ExternalSyntheticLambda0;

    invoke-direct {v9, v2}, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3$1$2$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/SetupState;)V

    .line 250
    .end local v8    # "$i$a$-cache-SetupWizardKt$SetupWizard$3$1$2$1\\3\\250\\0":I
    nop

    .line 251
    .local v9, "value\\2":Ljava/lang/Object;
    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 252
    nop

    .line 249
    .end local v9    # "value\\2":Ljava/lang/Object;
    :goto_1
    nop

    .line 248
    .end local v5    # "it\\1":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\2\\248\\1":I
    nop

    .line 84
    .end local v0    # "invalid\\1":Z
    .end local v3    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\1\\84":I
    check-cast v9, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {p3, v9, v7, v1}, Lorg/lighttouch/android/SetupWizardKt;->access$Welcome(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 83
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p3

    if-eqz p3, :cond_4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 89
    :cond_4
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

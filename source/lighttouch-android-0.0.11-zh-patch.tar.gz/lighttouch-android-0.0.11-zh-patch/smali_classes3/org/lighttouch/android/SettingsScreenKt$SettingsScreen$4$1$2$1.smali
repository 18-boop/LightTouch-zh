.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n1225#2,6:209\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1\n*L\n51#1:197,6\n52#1:203,6\n53#1:209,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method public static synthetic $r8$lambda$Tk_wMfSpU3qS5366hlbY99TR6N0(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ejNhrYrKg7q93SQvmwo4QQJbZ_4(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->invoke$lambda$1$lambda$0(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pWEISagfzZvuECB5l23DRDYM5CA(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->invoke$lambda$5$lambda$4(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p2, "it"    # Z

    .line 51
    invoke-virtual {p0, p2}, Lorg/lighttouch/android/AppSettings;->setTilt(Z)V

    invoke-interface {p1}, Lorg/lighttouch/android/GuestHost;->applySettings()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Z

    .line 52
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setVolumeKeys(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Z

    .line 53
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setHaptics(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 50
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 16
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v8, p2

    move/from16 v11, p3

    const-string v1, "$this$Group"

    move-object/from16 v12, p1

    invoke-static {v12, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C50@3289L37,50@3162L164,51@3522L21,51@3347L196,52@3672L18,52@3564L126:SettingsScreen.kt#o13vsk"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v11, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 53
    :cond_0
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_7

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:50)"

    const v3, -0x444dcb26

    invoke-static {v3, v11, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 51
    :cond_2
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getTilt()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getTilt()Z

    move-result v4

    const v2, -0x615d173a

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v13, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\1":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v6, p2

    .local v6, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 197
    .local v7, "$i$f$cache\\1\\51":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\1":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 198
    .local v10, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    if-nez v2, :cond_4

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v9, v14, :cond_3

    goto :goto_1

    .line 202
    :cond_3
    move-object v15, v9

    goto :goto_2

    .line 199
    :cond_4
    :goto_1
    const/4 v14, 0x0

    .line 51
    .local v14, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$1$1\\3\\199\\0":I
    new-instance v15, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1$$ExternalSyntheticLambda0;

    invoke-direct {v15, v3, v5}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V

    .line 199
    .end local v14    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$1$1\\3\\199\\0":I
    nop

    .line 200
    .local v15, "value\\2":Ljava/lang/Object;
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .line 198
    .end local v15    # "value\\2":Ljava/lang/Object;
    :goto_2
    nop

    .line 197
    .end local v9    # "it\\1":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 51
    .end local v2    # "invalid\\1":Z
    .end local v6    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\1\\51":I
    move-object v7, v15

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x61b0

    const/16 v10, 0x20

    const-string v2, "\u503e\u659c\u63a7\u5236"

    const-string v3, "\u7528\u624b\u673a\u7684\u8fd0\u52a8\u4f20\u611f\u5668\u9a71\u52a8\u8bbe\u5907\u7684\u52a0\u901f\u5ea6\u8ba1"

    const-string v5, "tilt_toggle"

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 52
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getVolumeUp()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getVolumeKeys()Z

    move-result v4

    const v14, 0x4c5de2

    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\4":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 203
    .local v6, "$i$f$cache\\4\\52":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\4":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 204
    .local v9, "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    if-nez v2, :cond_6

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_5

    goto :goto_3

    .line 208
    :cond_5
    move-object v15, v7

    goto :goto_4

    .line 205
    :cond_6
    :goto_3
    const/4 v10, 0x0

    .line 52
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$1$2\\6\\205\\0":I
    new-instance v15, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1$$ExternalSyntheticLambda1;

    invoke-direct {v15, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 205
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$1$2\\6\\205\\0":I
    nop

    .line 206
    .local v15, "value\\5":Ljava/lang/Object;
    invoke-interface {v5, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 204
    .end local v15    # "value\\5":Ljava/lang/Object;
    :goto_4
    nop

    .line 203
    .end local v7    # "it\\4":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    nop

    .line 52
    .end local v2    # "invalid\\4":Z
    .end local v5    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\4\\52":I
    move-object v7, v15

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x1b0

    const/16 v10, 0x30

    const-string v2, "\u7528\u624b\u673a\u97f3\u91cf\u952e\u63a7\u5236\u8bbe\u5907"

    const-string v3, "\u5173\u95ed\u540e\u97f3\u91cf\u952e\u4ecd\u8c03\u624b\u673a\u97f3\u91cf\uff1b\u8bbe\u5907\u81ea\u5e26\u7684\u97f3\u91cf\u952e\u663e\u793a\u5728\u5c4f\u5e55\u4e0a"

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 53
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getVibrate()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getHaptics()Z

    move-result v4

    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\7":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 209
    .local v6, "$i$f$cache\\7\\53":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\7":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 210
    .local v9, "$i$a$-let-ComposerKt$cache$1\\8\\209\\7":I
    if-nez v2, :cond_8

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_7

    goto :goto_5

    .line 214
    :cond_7
    move-object v13, v7

    goto :goto_6

    .line 211
    :cond_8
    :goto_5
    const/4 v10, 0x0

    .line 53
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$1$3\\9\\211\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1$$ExternalSyntheticLambda2;

    invoke-direct {v13, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 211
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$1$3\\9\\211\\0":I
    nop

    .line 212
    .local v13, "value\\8":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    nop

    .line 210
    .end local v13    # "value\\8":Ljava/lang/Object;
    :goto_6
    nop

    .line 209
    .end local v7    # "it\\7":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\8\\209\\7":I
    nop

    .line 53
    .end local v2    # "invalid\\7":Z
    .end local v5    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\7\\53":I
    move-object v7, v13

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x1b0

    const/16 v10, 0x30

    const-string v2, "\u89e6\u611f\u53cd\u9988"

    const-string v3, "\u6309\u4e0b\u4e3b\u5c4f\u5e55\u3001\u7761\u7720/\u5524\u9192\u6216\u97f3\u91cf\u952e\u65f6\u8f7b\u5fae\u632f\u52a8"

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 54
    :cond_9
    :goto_7
    return-void
.end method

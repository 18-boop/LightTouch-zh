.class final Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;
.super Ljava/lang/Object;
.source "HitchInspector.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/HitchInspectorKt;->HitchInspector(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHitchInspector.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/HitchInspectorKt$HitchInspector$1\n+ 2 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 3 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 4 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 5 Composer.kt\nandroidx/compose/runtime/Updater\n+ 6 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 7 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 8 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 9 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n*L\n1#1,342:1\n86#2:343\n83#2,6:344\n89#2:378\n86#2:416\n83#2,6:417\n89#2:451\n93#2:456\n93#2:504\n79#3,6:350\n86#3,4:365\n90#3,2:375\n79#3,6:387\n86#3,4:402\n90#3,2:412\n79#3,6:423\n86#3,4:438\n90#3,2:448\n94#3:455\n94#3:460\n79#3,6:468\n86#3,4:483\n90#3,2:493\n94#3:499\n94#3:503\n368#4,9:356\n377#4:377\n368#4,9:393\n377#4:414\n368#4,9:429\n377#4:450\n378#4,2:453\n378#4,2:458\n368#4,9:474\n377#4:495\n378#4,2:497\n378#4,2:501\n4034#5,6:369\n4034#5,6:406\n4034#5,6:442\n4034#5,6:487\n149#6:379\n149#6:457\n99#7:380\n96#7,6:381\n102#7:415\n106#7:461\n1#8:452\n71#9:462\n69#9,5:463\n74#9:496\n78#9:500\n*S KotlinDebug\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/HitchInspectorKt$HitchInspector$1\n*L\n45#1:343\n45#1:344,6\n45#1:378\n48#1:416\n48#1:417,6\n48#1:451\n48#1:456\n45#1:504\n45#1:350,6\n45#1:365,4\n45#1:375,2\n46#1:387,6\n46#1:402,4\n46#1:412,2\n48#1:423,6\n48#1:438,4\n48#1:448,2\n48#1:455\n46#1:460\n59#1:468,6\n59#1:483,4\n59#1:493,2\n59#1:499\n45#1:503\n45#1:356,9\n45#1:377\n46#1:393,9\n46#1:414\n48#1:429,9\n48#1:450\n48#1:453,2\n46#1:458,2\n59#1:474,9\n59#1:495\n59#1:497,2\n45#1:501,2\n45#1:369,6\n46#1:406,6\n48#1:442,6\n59#1:487,6\n46#1:379\n53#1:457\n46#1:380\n46#1:381,6\n46#1:415\n46#1:461\n59#1:462\n59#1:463,5\n59#1:496\n59#1:500\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $data:Lorg/lighttouch/android/HitchData;

.field final synthetic $loadError:Ljava/lang/String;

.field final synthetic $onResume:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onSave:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onShare:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $savedNotice:Ljava/lang/String;

.field final synthetic $saving:Z


# direct methods
.method constructor <init>(Ljava/lang/String;Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/HitchData;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$loadError:Ljava/lang/String;

    iput-object p2, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$data:Lorg/lighttouch/android/HitchData;

    iput-object p3, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$onSave:Lkotlin/jvm/functions/Function2;

    iput-boolean p4, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$saving:Z

    iput-object p5, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$savedNotice:Ljava/lang/String;

    iput-object p6, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$onShare:Lkotlin/jvm/functions/Function0;

    iput-object p7, p0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$onResume:Lkotlin/jvm/functions/Function0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;

    .line 44
    move-object v0, p1

    check-cast v0, Landroidx/compose/runtime/Composer;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->invoke(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/runtime/Composer;I)V
    .locals 103
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    const-string v3, "C44@1989L11,44@1926L1521:HitchInspector.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 504
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_10

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.HitchInspector.<anonymous> (HitchInspector.kt:44)"

    const v6, -0x1f839f23

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 45
    :cond_2
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v3, v5, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v8, Landroidx/compose/foundation/layout/WindowInsets;->Companion:Landroidx/compose/foundation/layout/WindowInsets$Companion;

    const/4 v9, 0x6

    invoke-static {v8, v1, v9}, Landroidx/compose/foundation/layout/WindowInsets_androidKt;->getSafeDrawing(Landroidx/compose/foundation/layout/WindowInsets$Companion;Landroidx/compose/runtime/Composer;I)Landroidx/compose/foundation/layout/WindowInsets;

    move-result-object v8

    invoke-static {v3, v8}, Landroidx/compose/foundation/layout/WindowInsetsPaddingKt;->windowInsetsPadding(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/WindowInsets;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\1":Landroidx/compose/ui/Modifier;
    iget-object v8, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$loadError:Ljava/lang/String;

    iget-object v10, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$data:Lorg/lighttouch/android/HitchData;

    iget-object v11, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$onSave:Lkotlin/jvm/functions/Function2;

    iget-boolean v12, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$saving:Z

    iget-object v13, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$savedNotice:Ljava/lang/String;

    iget-object v14, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$onShare:Lkotlin/jvm/functions/Function0;

    iget-object v15, v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;->$onResume:Lkotlin/jvm/functions/Function0;

    const/16 v28, 0x0

    .local v28, "$changed\\1":I
    const/16 v29, 0x0

    .line 343
    .local v29, "$i$f$Column\\1\\45":I
    move/from16 v30, v9

    const v9, -0x1cd0f17e

    const-string v4, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v1, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 344
    sget-object v16, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 345
    .local v9, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v5

    .line 348
    .local v5, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v28, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v17, v28, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v6, v16, v17

    invoke-static {v9, v5, v1, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v28, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 349
    move/from16 v32, v16

    .local v32, "$changed\\2":I
    const/16 v33, 0x0

    .line 350
    .local v33, "$i$f$Layout\\2\\349":I
    const v7, -0x4ee9b9da

    const-string v0, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 351
    const/4 v7, 0x0

    invoke-static {v1, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v34

    .line 352
    .local v34, "compositeKeyHash\\2":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 353
    .local v7, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 355
    .local v2, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v36, v3

    .end local v3    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v36, "modifier\\1":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v32, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 354
    nop

    .local v3, "$changed\\3":I
    move-object/from16 v37, v16

    .local v37, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v38, 0x0

    .line 356
    .local v38, "$i$f$ReusableComposeNode\\3\\354":I
    move/from16 v39, v3

    .end local v3    # "$changed\\3":I
    .local v39, "$changed\\3":I
    const v3, -0x2942ffcf

    move-object/from16 v40, v5

    .end local v5    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v40, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 357
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 358
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 359
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_4

    .line 360
    move-object/from16 v3, v37

    .end local v37    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 362
    .end local v3    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v3, v37

    .end local v37    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 364
    :goto_1
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 365
    .local v16, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\364\\2":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v37, v3

    .end local v3    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 366
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 368
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 369
    .local v17, "$i$f$set-impl\\5\\368":I
    move-object/from16 v18, v1

    .local v18, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 370
    .local v19, "$i$a$-with-Updater$set$1\\6\\369\\5":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v20

    if-nez v20, :cond_6

    move-object/from16 v41, v6

    .end local v6    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v41, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v42, v7

    .end local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v42, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v7, v18

    goto :goto_3

    .end local v41    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v42    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_6
    move-object/from16 v41, v6

    move-object/from16 v42, v7

    .line 371
    .end local v6    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v41    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v42    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_2
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v7, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 372
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v1, v6, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 374
    :goto_3
    nop

    .line 369
    .end local v7    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-with-Updater$set$1\\6\\369\\5":I
    nop

    .line 374
    nop

    .line 375
    .end local v3    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\5\\368":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 376
    nop

    .line 364
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\364\\2":I
    nop

    .line 377
    shr-int/lit8 v1, v39, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\7":I
    move-object/from16 v3, p1

    .local v3, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 378
    .local v6, "$i$a$-Layout-ColumnKt$Column$1\\7\\377\\1":I
    const v7, -0x16ef5699

    move/from16 v43, v1

    .end local v1    # "$changed\\7":I
    .local v43, "$changed\\7":I
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v16, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v17, v28, 0x6

    and-int/lit8 v17, v17, 0x70

    or-int/lit8 v44, v17, 0x6

    .local v44, "$changed\\8":I
    check-cast v16, Landroidx/compose/foundation/layout/ColumnScope;

    .local v16, "$this$invoke_u24lambda_u244\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v45, v16

    .end local v16    # "$this$invoke_u24lambda_u244\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v45, "$this$invoke_u24lambda_u244\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v46, v3

    .local v46, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 46
    .local v47, "$i$a$-Column-HitchInspectorKt$HitchInspector$1$1\\8\\378\\0":I
    const v7, 0x25844a30

    move-object/from16 v48, v2

    .end local v2    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v48, "materialized\\2":Landroidx/compose/ui/Modifier;
    const-string v2, "C45@2017L920:HitchInspector.kt#o13vsk"

    move-object/from16 v49, v3

    .end local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\7":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move/from16 v46, v6

    move-object/from16 v50, v9

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x1

    .end local v6    # "$i$a$-Layout-ColumnKt$Column$1\\7\\377\\1":I
    .end local v9    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v46, "$i$a$-Layout-ColumnKt$Column$1\\7\\377\\1":I
    .local v50, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v2, v7, v9, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v6, 0x4

    .local v6, "$this$dp\\9":I
    const/4 v7, 0x0

    .line 379
    .local v7, "$i$f$getDp\\9\\46":I
    int-to-float v9, v6

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 46
    .end local v6    # "$this$dp\\9":I
    .end local v7    # "$i$f$getDp\\9\\46":I
    const/4 v7, 0x4

    .local v7, "$this$dp\\10":I
    const/4 v9, 0x0

    .line 379
    .local v9, "$i$f$getDp\\10\\46":I
    move/from16 v16, v9

    .end local v9    # "$i$f$getDp\\10\\46":I
    .local v16, "$i$f$getDp\\10\\46":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 46
    .end local v7    # "$this$dp\\10":I
    .end local v16    # "$i$f$getDp\\10\\46":I
    invoke-static {v2, v6, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    .local v6, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v7, 0x186

    .local v7, "$changed\\11":I
    const/4 v9, 0x0

    .line 380
    .local v9, "$i$f$Row\\11\\46":I
    move/from16 v51, v7

    .end local v7    # "$changed\\11":I
    .local v51, "$changed\\11":I
    const v7, 0x2952b718

    move/from16 v52, v9

    .end local v9    # "$i$f$Row\\11\\46":I
    .local v52, "$i$f$Row\\11\\46":I
    const-string v9, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v3, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 381
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    .line 385
    .local v7, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v9, v51, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v16, v51, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v9, v9, v16

    invoke-static {v7, v6, v3, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v51, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 386
    move/from16 v53, v16

    .local v53, "$changed\\12":I
    const/16 v54, 0x0

    .line 387
    .local v54, "$i$f$Layout\\12\\386":I
    move-object/from16 v55, v6

    const v6, -0x4ee9b9da

    .end local v6    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v55, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v3, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 388
    const/4 v6, 0x0

    invoke-static {v3, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v56

    .line 389
    .local v56, "compositeKeyHash\\12":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v6

    .line 390
    .local v6, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v57, v7

    .end local v7    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v57, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 392
    .local v7, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v58, v2

    .end local v2    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v58, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v53, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 391
    nop

    .local v2, "$changed\\13":I
    move-object/from16 v59, v16

    .local v59, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v60, 0x0

    .line 393
    .local v60, "$i$f$ReusableComposeNode\\13\\391":I
    move/from16 v61, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\13":I
    .local v61, "$changed\\13":I
    invoke-static {v3, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 394
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 395
    :cond_7
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 396
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_8

    .line 397
    move-object/from16 v2, v59

    .end local v59    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 399
    .end local v2    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v59    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v2, v59

    .end local v59    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 401
    :goto_4
    move-object/from16 v59, v2

    .end local v2    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v59    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 402
    .local v16, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\401\\12":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v62, v10

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v2, v9, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 403
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v2, v6, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 405
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 406
    .local v17, "$i$f$set-impl\\15\\405":I
    move-object/from16 v18, v2

    .local v18, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 407
    .local v19, "$i$a$-with-Updater$set$1\\16\\406\\15":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v20

    if-nez v20, :cond_a

    move-object/from16 v63, v6

    .end local v6    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v63, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v64, v9

    .end local v9    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v64, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v56 .. v56}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v6, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_9

    goto :goto_5

    :cond_9
    move-object/from16 v9, v18

    goto :goto_6

    .end local v63    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v64    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v6    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_a
    move-object/from16 v63, v6

    move-object/from16 v64, v9

    .line 408
    .end local v6    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v63    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v64    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_5
    invoke-static/range {v56 .. v56}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v9, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 409
    invoke-static/range {v56 .. v56}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v2, v6, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 411
    :goto_6
    nop

    .line 406
    .end local v9    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-with-Updater$set$1\\16\\406\\15":I
    nop

    .line 411
    nop

    .line 412
    .end local v10    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\15\\405":I
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v2, v7, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 413
    nop

    .line 401
    .end local v2    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\401\\12":I
    nop

    .line 414
    shr-int/lit8 v2, v61, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\17":I
    move-object v6, v3

    .local v6, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 415
    .local v9, "$i$a$-Layout-RowKt$Row$1\\17\\414\\11":I
    const v10, -0x184f2606

    move/from16 v65, v2

    .end local v2    # "$changed\\17":I
    .local v65, "$changed\\17":I
    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v6, v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v51, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\18":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$invoke_u24lambda_u244_u24lambda_u242\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v21, v6

    .local v21, "$composer\\18":Landroidx/compose/runtime/Composer;
    move-object/from16 v66, v2

    .end local v2    # "$this$invoke_u24lambda_u244_u24lambda_u242\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v66, "$this$invoke_u24lambda_u244_u24lambda_u242\\18":Landroidx/compose/foundation/layout/RowScope;
    const/4 v2, 0x0

    .line 47
    .local v2, "$i$a$-Row-HitchInspectorKt$HitchInspector$1$1$1\\18\\415\\8":I
    move/from16 v72, v2

    .end local v2    # "$i$a$-Row-HitchInspectorKt$HitchInspector$1$1$1\\18\\415\\8":I
    .local v72, "$i$a$-Row-HitchInspectorKt$HitchInspector$1$1$1\\18\\415\\8":I
    const v2, -0x3694abff

    move-object/from16 v73, v6

    .end local v6    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v73, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v6, "C46@2156L123,47@2296L375,52@2688L235:HitchInspector.kt#o13vsk"

    move-object/from16 v74, v7

    move-object/from16 v7, v21

    .end local v21    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v74, "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static {v7, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const-string v6, "hitch_close"

    invoke-static {v2, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->getLambda$-1964138234$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v20

    const v22, 0x30030

    const/16 v23, 0x1c

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    .end local v7    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v15 .. v23}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 48
    .end local v21    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\18":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v67, v2

    check-cast v67, Landroidx/compose/ui/Modifier;

    const/16 v70, 0x2

    const/16 v71, 0x0

    const/high16 v68, 0x3f800000    # 1.0f

    const/16 v69, 0x0

    invoke-static/range {v66 .. v71}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\19":Landroidx/compose/ui/Modifier;
    const/4 v6, 0x0

    .local v6, "$changed\\19":I
    const/16 v16, 0x0

    .line 416
    .local v16, "$i$f$Column\\19\\48":I
    move/from16 v17, v6

    const v6, -0x1cd0f17e

    .end local v6    # "$changed\\19":I
    .local v17, "$changed\\19":I
    invoke-static {v7, v6, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 417
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 418
    .local v4, "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .line 421
    .local v6, "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v18, v17, 0x3

    and-int/lit8 v18, v18, 0xe

    shr-int/lit8 v19, v17, 0x3

    and-int/lit8 v19, v19, 0x70

    move/from16 v67, v9

    .end local v9    # "$i$a$-Layout-RowKt$Row$1\\17\\414\\11":I
    .local v67, "$i$a$-Layout-RowKt$Row$1\\17\\414\\11":I
    or-int v9, v18, v19

    invoke-static {v4, v6, v7, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v18, v17, 0x3

    and-int/lit8 v18, v18, 0x70

    .line 422
    nop

    .local v18, "$changed\\20":I
    const/16 v19, 0x0

    .line 423
    .local v19, "$i$f$Layout\\20\\422":I
    move-object/from16 v20, v4

    const v4, -0x4ee9b9da

    .end local v4    # "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v20, "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v7, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 424
    const/4 v4, 0x0

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v21

    .line 425
    .local v21, "compositeKeyHash\\20":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 426
    .local v4, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v22, v6

    .end local v6    # "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    .local v22, "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v7, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 428
    .local v6, "materialized\\20":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v24, v2

    .end local v2    # "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\19":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v18, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 427
    move-object/from16 v26, v23

    .local v2, "$changed\\21":I
    .local v26, "factory\\21":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 429
    .local v23, "$i$f$ReusableComposeNode\\21\\427":I
    move/from16 v27, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\21":I
    .local v27, "$changed\\21":I
    invoke-static {v7, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 430
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 431
    :cond_b
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 432
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_c

    .line 433
    move-object/from16 v2, v26

    .end local v26    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_7

    .line 435
    .end local v2    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\21":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v2, v26

    .end local v26    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 437
    :goto_7
    move-object/from16 v26, v2

    .end local v2    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    const/16 v68, 0x0

    .line 438
    .local v68, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\437\\20":I
    sget-object v69, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v70, v7

    .end local v7    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v70, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v69 .. v69}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v9, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 439
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v4, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 441
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\23":Lkotlin/jvm/functions/Function2;
    const/16 v69, 0x0

    .line 442
    .local v69, "$i$f$set-impl\\23\\441":I
    move-object/from16 v71, v2

    .local v71, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v75, 0x0

    .line 443
    .local v75, "$i$a$-with-Updater$set$1\\24\\442\\23":I
    invoke-interface/range {v71 .. v71}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v76

    if-nez v76, :cond_e

    move-object/from16 v76, v4

    .end local v4    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .local v76, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v71 .. v71}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v77, v9

    .end local v9    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v77, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_d

    goto :goto_8

    :cond_d
    move-object/from16 v9, v71

    goto :goto_9

    .end local v76    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v77    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_e
    move-object/from16 v76, v4

    move-object/from16 v77, v9

    .line 444
    .end local v4    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v76    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v77    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_8
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v9, v71

    .end local v71    # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 445
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 447
    :goto_9
    nop

    .line 442
    .end local v9    # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v75    # "$i$a$-with-Updater$set$1\\24\\442\\23":I
    nop

    .line 447
    nop

    .line 448
    .end local v7    # "block\\23":Lkotlin/jvm/functions/Function2;
    .end local v69    # "$i$f$set-impl\\23\\441":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v6, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 449
    nop

    .line 437
    .end local v2    # "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .end local v68    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\437\\20":I
    nop

    .line 450
    shr-int/lit8 v2, v27, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\25":I
    move-object/from16 v4, v70

    .local v4, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 451
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\25\\450\\19":I
    const v9, -0x16ef5699

    invoke-static {v4, v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v17, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\26":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$invoke_u24lambda_u244_u24lambda_u242_u24lambda_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v99, v4

    .local v99, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 49
    .local v25, "$i$a$-Column-HitchInspectorKt$HitchInspector$1$1$1$1\\26\\451\\18":I
    move-object/from16 v68, v1

    .end local v1    # "$this$invoke_u24lambda_u244_u24lambda_u242_u24lambda_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    .local v68, "$this$invoke_u24lambda_u244_u24lambda_u242_u24lambda_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, -0x1e482fbd

    move/from16 v69, v2

    .end local v2    # "$changed\\25":I
    .local v69, "$changed\\25":I
    const-string v2, "C48@2392L10,48@2346L68,50@2580L10,50@2624L11,49@2435L218:HitchInspector.kt#o13vsk"

    move-object/from16 v71, v4

    .end local v99    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\25":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v98

    const/16 v101, 0x0

    const v102, 0xfffe

    const-string v78, "\u5e27\u68c0\u67e5\u5668"

    const/16 v79, 0x0

    const-wide/16 v80, 0x0

    const-wide/16 v82, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const-wide/16 v87, 0x0

    const/16 v89, 0x0

    const/16 v90, 0x0

    const-wide/16 v91, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const/16 v100, 0x6

    .end local v4    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v99    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v78 .. v102}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 50
    .end local v99    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x2

    new-array v2, v1, [Ljava/lang/String;

    if-eqz v62, :cond_10

    invoke-virtual/range {v62 .. v62}, Lorg/lighttouch/android/HitchData;->getAppName()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_10

    .line 452
    move-object/from16 v75, v1

    .local v75, "it\\27":Ljava/lang/String;
    const/16 v78, 0x0

    .line 50
    .local v78, "$i$a$-takeIf-HitchInspectorKt$HitchInspector$1$1$1$1$1\\27\\50\\26":I
    move-object/from16 v79, v75

    check-cast v79, Ljava/lang/CharSequence;

    invoke-interface/range {v79 .. v79}, Ljava/lang/CharSequence;->length()I

    move-result v79

    if-lez v79, :cond_f

    const/16 v79, 0x1

    goto :goto_a

    :cond_f
    const/16 v79, 0x0

    .end local v75    # "it\\27":Ljava/lang/String;
    .end local v78    # "$i$a$-takeIf-HitchInspectorKt$HitchInspector$1$1$1$1$1\\27\\50\\26":I
    :goto_a
    if-eqz v79, :cond_10

    goto :goto_b

    :cond_10
    const/4 v1, 0x0

    :goto_b
    const/16 v35, 0x0

    aput-object v1, v2, v35

    const-string v1, "\u5ba2\u6237\u673a\u5df2\u6682\u505c"

    const/16 v31, 0x1

    aput-object v1, v2, v31

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    move-object/from16 v78, v1

    check-cast v78, Ljava/lang/Iterable;

    const-string v1, " \u00b7 "

    move-object/from16 v79, v1

    check-cast v79, Ljava/lang/CharSequence;

    const/16 v85, 0x3e

    const/16 v86, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    invoke-static/range {v78 .. v86}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v78

    .line 51
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v98

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v80

    .line 50
    nop

    .line 51
    nop

    .line 50
    const/16 v79, 0x0

    const-wide/16 v82, 0x0

    const/16 v85, 0x0

    const-wide/16 v87, 0x0

    const/16 v89, 0x0

    const/16 v90, 0x0

    const-wide/16 v91, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const/16 v100, 0x0

    const/16 v101, 0x0

    const v102, 0xfffa

    move-object/from16 v99, v4

    .end local v4    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v99    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v78 .. v102}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 49
    .end local v99    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 52
    nop

    .line 451
    .end local v4    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v9    # "$changed\\26":I
    .end local v25    # "$i$a$-Column-HitchInspectorKt$HitchInspector$1$1$1$1\\26\\451\\18":I
    .end local v68    # "$this$invoke_u24lambda_u244_u24lambda_u242_u24lambda_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 450
    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\25\\450\\19":I
    .end local v69    # "$changed\\25":I
    .end local v71    # "$composer\\25":Landroidx/compose/runtime/Composer;
    nop

    .line 453
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 429
    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 454
    nop

    .line 423
    .end local v23    # "$i$f$ReusableComposeNode\\21\\427":I
    .end local v26    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .end local v27    # "$changed\\21":I
    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 455
    nop

    .line 416
    .end local v6    # "materialized\\20":Landroidx/compose/ui/Modifier;
    .end local v18    # "$changed\\20":I
    .end local v19    # "$i$f$Layout\\20\\422":I
    .end local v21    # "compositeKeyHash\\20":I
    .end local v76    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 456
    nop

    .line 53
    .end local v16    # "$i$f$Column\\19\\48":I
    .end local v17    # "$changed\\19":I
    .end local v20    # "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v22    # "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v24    # "modifier\\19":Landroidx/compose/ui/Modifier;
    .end local v77    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v16, v1

    check-cast v16, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\28":I
    const/4 v2, 0x0

    .line 457
    .local v2, "$i$f$getDp\\28\\53":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v19

    .line 53
    .end local v1    # "$this$dp\\28":I
    .end local v2    # "$i$f$getDp\\28\\53":I
    const/16 v21, 0xb

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v20, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "hitch_resume"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->getLambda$1516541617$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v24

    const v26, 0x30000030

    const/16 v27, 0x1fc

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v25, v70

    .end local v70    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v15 .. v27}, Landroidx/compose/material3/ButtonKt;->FilledTonalButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 47
    move-object/from16 v7, v25

    .end local v25    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 56
    nop

    .line 415
    .end local v7    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v10    # "$changed\\18":I
    .end local v66    # "$this$invoke_u24lambda_u244_u24lambda_u242\\18":Landroidx/compose/foundation/layout/RowScope;
    .end local v72    # "$i$a$-Row-HitchInspectorKt$HitchInspector$1$1$1\\18\\415\\8":I
    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 414
    .end local v65    # "$changed\\17":I
    .end local v67    # "$i$a$-Layout-RowKt$Row$1\\17\\414\\11":I
    .end local v73    # "$composer\\17":Landroidx/compose/runtime/Composer;
    nop

    .line 458
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 393
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 459
    nop

    .line 387
    .end local v59    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .end local v60    # "$i$f$ReusableComposeNode\\13\\391":I
    .end local v61    # "$changed\\13":I
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 460
    nop

    .line 380
    .end local v53    # "$changed\\12":I
    .end local v54    # "$i$f$Layout\\12\\386":I
    .end local v56    # "compositeKeyHash\\12":I
    .end local v63    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v74    # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 461
    nop

    .line 57
    .end local v51    # "$changed\\11":I
    .end local v52    # "$i$f$Row\\11\\46":I
    .end local v55    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v57    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v58    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v64    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    nop

    .line 58
    if-eqz v8, :cond_11

    const v0, -0x491c4f03

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "57@2994L54"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v0, "\u65e0\u6cd5\u8bfb\u53d6\u5e27\u5386\u53f2"

    move/from16 v1, v30

    invoke-static {v0, v8, v3, v1}, Lorg/lighttouch/android/HitchInspectorKt;->access$Message(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v73, v3

    goto/16 :goto_f

    .line 59
    :cond_11
    if-nez v62, :cond_16

    const v1, -0x491c43f9

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "58@3081L96"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x1

    invoke-static {v1, v7, v9, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\29":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v2

    .local v2, "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    const/16 v4, 0x36

    .local v4, "$changed\\29":I
    const/4 v6, 0x0

    .line 462
    .local v6, "$i$f$Box\\29\\59":I
    const v7, 0x2bb5b5d7

    const-string v8, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v3, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 463
    const/4 v7, 0x0

    .line 466
    .local v7, "propagateMinConstraints\\29":Z
    invoke-static {v2, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\29":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v4, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 467
    nop

    .local v9, "$changed\\30":I
    const/4 v10, 0x0

    .line 468
    .local v10, "$i$f$Layout\\30\\467":I
    const v11, -0x4ee9b9da

    invoke-static {v3, v11, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 469
    const/4 v0, 0x0

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v0

    .line 470
    .local v0, "compositeKeyHash\\30":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 471
    .local v11, "localMap\\30":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 473
    .local v12, "materialized\\30":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v9, 0x6

    and-int/lit16 v14, v14, 0x380

    const/16 v30, 0x6

    or-int/lit8 v14, v14, 0x6

    .line 472
    nop

    .local v13, "factory\\31":Lkotlin/jvm/functions/Function0;
    .local v14, "$changed\\31":I
    const/4 v15, 0x0

    .line 474
    .local v15, "$i$f$ReusableComposeNode\\31\\472":I
    move/from16 v16, v0

    const v0, -0x2942ffcf

    .end local v0    # "compositeKeyHash\\30":I
    .local v16, "compositeKeyHash\\30":I
    invoke-static {v3, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 475
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_12

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 476
    :cond_12
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 477
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_13

    .line 478
    invoke-interface {v3, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 480
    :cond_13
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 482
    :goto_c
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 483
    .local v5, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\32\\482\\30":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v18, v1

    .end local v1    # "modifier\\29":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\29":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v8, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 484
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 486
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\33":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 487
    .local v17, "$i$f$set-impl\\33\\486":I
    move-object/from16 v19, v0

    .local v19, "$this$set_impl_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 488
    .local v20, "$i$a$-with-Updater$set$1\\34\\487\\33":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v21

    if-nez v21, :cond_15

    move-object/from16 v21, v2

    .end local v2    # "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    .local v21, "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v22, v4

    .end local v4    # "$changed\\29":I
    .local v22, "$changed\\29":I
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_14

    goto :goto_d

    :cond_14
    move-object/from16 v4, v19

    goto :goto_e

    .end local v21    # "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    .end local v22    # "$changed\\29":I
    .restart local v2    # "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    .restart local v4    # "$changed\\29":I
    :cond_15
    move-object/from16 v21, v2

    move/from16 v22, v4

    .line 489
    .end local v2    # "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    .end local v4    # "$changed\\29":I
    .restart local v21    # "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    .restart local v22    # "$changed\\29":I
    :goto_d
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v19

    .end local v19    # "$this$set_impl_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 490
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 492
    :goto_e
    nop

    .line 487
    .end local v4    # "$this$set_impl_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-with-Updater$set$1\\34\\487\\33":I
    nop

    .line 492
    nop

    .line 493
    .end local v1    # "block\\33":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\33\\486":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 494
    nop

    .line 482
    .end local v0    # "$this$Layout_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\32\\482\\30":I
    nop

    .line 495
    shr-int/lit8 v0, v14, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\35":I
    move-object v1, v3

    .local v1, "$composer\\35":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 496
    .local v2, "$i$a$-Layout-BoxKt$Box$1\\35\\495\\29":I
    const v4, -0x7ff519f7    # -1.000876E-39f

    const-string v5, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v5, v22, 0x6

    and-int/lit8 v5, v5, 0x70

    const/16 v30, 0x6

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\36":I
    check-cast v4, Landroidx/compose/foundation/layout/BoxScope;

    .local v4, "$this$invoke_u24lambda_u244_u24lambda_u243\\36":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v58, v1

    .local v58, "$composer\\36":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 59
    .local v17, "$i$a$-Box-HitchInspectorKt$HitchInspector$1$1$2\\36\\496\\8":I
    move/from16 v19, v0

    .end local v0    # "$changed\\35":I
    .local v19, "$changed\\35":I
    const v0, -0x3eca64d8

    move-object/from16 v20, v1

    .end local v1    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\35":Landroidx/compose/runtime/Composer;
    const-string v1, "C58@3148L27:HitchInspector.kt#o13vsk"

    move/from16 v23, v2

    move-object/from16 v2, v58

    .end local v58    # "$composer\\36":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\36":Landroidx/compose/runtime/Composer;
    .local v23, "$i$a$-Layout-BoxKt$Box$1\\35\\495\\29":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v59, 0x0

    const/16 v60, 0x1f

    const/16 v51, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const-wide/16 v55, 0x0

    const/16 v57, 0x0

    .end local v2    # "$composer\\36":Landroidx/compose/runtime/Composer;
    .restart local v58    # "$composer\\36":Landroidx/compose/runtime/Composer;
    invoke-static/range {v51 .. v60}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-LxG7B9w(Landroidx/compose/ui/Modifier;JFJILandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 496
    .end local v4    # "$this$invoke_u24lambda_u244_u24lambda_u243\\36":Landroidx/compose/foundation/layout/BoxScope;
    .end local v5    # "$changed\\36":I
    .end local v17    # "$i$a$-Box-HitchInspectorKt$HitchInspector$1$1$2\\36\\496\\8":I
    .end local v58    # "$composer\\36":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 495
    .end local v19    # "$changed\\35":I
    .end local v20    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-Layout-BoxKt$Box$1\\35\\495\\29":I
    nop

    .line 497
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 474
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 498
    nop

    .line 468
    .end local v13    # "factory\\31":Lkotlin/jvm/functions/Function0;
    .end local v14    # "$changed\\31":I
    .end local v15    # "$i$f$ReusableComposeNode\\31\\472":I
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 499
    nop

    .line 462
    .end local v9    # "$changed\\30":I
    .end local v10    # "$i$f$Layout\\30\\467":I
    .end local v11    # "localMap\\30":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "materialized\\30":Landroidx/compose/ui/Modifier;
    .end local v16    # "compositeKeyHash\\30":I
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 500
    nop

    .line 59
    .end local v6    # "$i$f$Box\\29\\59":I
    .end local v7    # "propagateMinConstraints\\29":Z
    .end local v8    # "measurePolicy\\29":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "modifier\\29":Landroidx/compose/ui/Modifier;
    .end local v21    # "contentAlignment\\29":Landroidx/compose/ui/Alignment;
    .end local v22    # "$changed\\29":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v73, v3

    goto :goto_f

    .line 60
    :cond_16
    invoke-virtual/range {v62 .. v62}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x2

    if-ge v0, v1, :cond_17

    const v0, -0x491c32be

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "59@3218L123"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v0, "\u5ba2\u6237\u673a\u7ed8\u5236\u7684\u5e27\u8fd8\u4e0d\u591f\u591a\uff0c\u65e0\u6cd5\u68c0\u67e5\u3002\u8bf7\u7ee7\u7eed\u8fd0\u884c\u3001\u73a9\u51e0\u79d2\u949f\u540e\u518d\u8bd5\u3002"

    const/16 v1, 0x36

    const-string v2, "\u6682\u65e0\u5e27\u6570\u636e"

    invoke-static {v2, v0, v3, v1}, Lorg/lighttouch/android/HitchInspectorKt;->access$Message(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v73, v3

    goto :goto_f

    .line 61
    :cond_17
    const v0, -0x491c2080

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "60@3366L57"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/16 v16, 0x0

    move-object v15, v3

    move-object/from16 v10, v62

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v15, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v16}, Lorg/lighttouch/android/HitchInspectorKt;->access$InspectorBody(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    move-object/from16 v73, v15

    .end local v15    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v73, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v73 .. v73}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 46
    :goto_f
    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 63
    nop

    .line 378
    .end local v44    # "$changed\\8":I
    .end local v45    # "$this$invoke_u24lambda_u244\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v47    # "$i$a$-Column-HitchInspectorKt$HitchInspector$1$1\\8\\378\\0":I
    .end local v73    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 377
    .end local v43    # "$changed\\7":I
    .end local v46    # "$i$a$-Layout-ColumnKt$Column$1\\7\\377\\1":I
    .end local v49    # "$composer\\7":Landroidx/compose/runtime/Composer;
    nop

    .line 501
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 356
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 502
    nop

    .line 350
    .end local v37    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v38    # "$i$f$ReusableComposeNode\\3\\354":I
    .end local v39    # "$changed\\3":I
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 503
    nop

    .line 343
    .end local v32    # "$changed\\2":I
    .end local v33    # "$i$f$Layout\\2\\349":I
    .end local v34    # "compositeKeyHash\\2":I
    .end local v42    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v48    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 504
    nop

    .end local v28    # "$changed\\1":I
    .end local v29    # "$i$f$Column\\1\\45":I
    .end local v36    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v40    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v41    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v50    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 64
    :cond_18
    :goto_10
    return-void
.end method

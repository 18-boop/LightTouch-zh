.class final Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;
.super Ljava/lang/Object;
.source "FullscreenScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/BoxWithConstraintsScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFullscreenScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FullscreenScreen.kt\norg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/Dp\n+ 4 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 9 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 10 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n*L\n1#1,156:1\n149#2:157\n184#2:164\n149#2:203\n149#2:232\n149#2:274\n149#2:279\n149#2:286\n69#3:158\n57#3:159\n72#3:160\n84#3:161\n87#3:162\n57#3:163\n84#3:165\n57#3:166\n72#3:167\n71#4:168\n69#4,5:169\n74#4:202\n78#4:213\n71#4:239\n69#4,5:240\n74#4:273\n78#4:278\n79#5,6:174\n86#5,4:189\n90#5,2:199\n94#5:212\n79#5,6:245\n86#5,4:260\n90#5,2:270\n94#5:277\n368#6,9:180\n377#6:201\n378#6,2:210\n368#6,9:251\n377#6:272\n378#6,2:275\n4034#7,6:193\n4034#7,6:264\n1225#8,6:204\n1225#8,6:214\n1225#8,6:220\n1225#8,6:226\n1225#8,6:233\n1225#8,6:280\n81#9:287\n107#9,2:288\n78#10:290\n111#10,2:291\n*S KotlinDebug\n*F\n+ 1 FullscreenScreen.kt\norg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3\n*L\n52#1:157\n55#1:164\n60#1:203\n71#1:232\n73#1:274\n76#1:279\n77#1:286\n53#1:158\n54#1:159\n54#1:160\n54#1:161\n55#1:162\n55#1:163\n56#1:165\n59#1:166\n59#1:167\n59#1:168\n59#1:169,5\n59#1:202\n59#1:213\n71#1:239\n71#1:240,5\n71#1:273\n71#1:278\n59#1:174,6\n59#1:189,4\n59#1:199,2\n59#1:212\n71#1:245,6\n71#1:260,4\n71#1:270,2\n71#1:277\n59#1:180,9\n59#1:201\n59#1:210,2\n71#1:251,9\n71#1:272\n71#1:275,2\n59#1:193,6\n71#1:264,6\n60#1:204,6\n63#1:214,6\n64#1:220,6\n65#1:226,6\n72#1:233,6\n77#1:280,6\n63#1:287\n63#1:288,2\n64#1:290\n64#1:291,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $aspect:F

.field final synthetic $confirmStop$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $guestSurface:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/ui/Modifier;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $host:Lorg/lighttouch/android/GuestHost;


# direct methods
.method public static synthetic $r8$lambda$HQ5FtYnpeo02K9WLDhbNbLnEUws(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$11$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JqDMl3R-Rwk5dBD84T5YIOo1zM8(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$13$lambda$12(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$n9-YhXet31d3Px1hNPV8mQpGkAk(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$2$lambda$1$lambda$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(FLorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/ui/Modifier;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    iput p1, p0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$aspect:F

    iput-object p2, p0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    iput-object p3, p0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$guestSurface:Lkotlin/jvm/functions/Function3;

    iput-object p4, p0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$confirmStop$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final synthetic access$invoke$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 1
    .param p0, "$visible$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 48
    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$invoke$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$visible$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 48
    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$invoke$lambda$7(Landroidx/compose/runtime/MutableIntState;)I
    .locals 1
    .param p0, "$touched$delegate"    # Landroidx/compose/runtime/MutableIntState;

    .line 48
    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$7(Landroidx/compose/runtime/MutableIntState;)I

    move-result v0

    return v0
.end method

.method public static final synthetic access$invoke$lambda$8(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 0
    .param p0, "$touched$delegate"    # Landroidx/compose/runtime/MutableIntState;
    .param p1, "<set-?>"    # I

    .line 48
    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$8(Landroidx/compose/runtime/MutableIntState;I)V

    return-void
.end method

.method private static final invoke$lambda$11$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$visible$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 72
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$13$lambda$12(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    const-string v0, "\u663e\u793a\u63a7\u5236\u6761"

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$2$lambda$1$lambda$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$confirmStop$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 60
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1;->access$invoke$lambda$4(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$visible$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 63
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 287
    .local v3, "$i$f$getValue\\1\\63":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\63":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 63
    return v0
.end method

.method private static final invoke$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$visible$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 63
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 288
    .local v4, "$i$f$setValue\\1\\63":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 289
    nop

    .line 63
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\63":I
    return-void
.end method

.method private static final invoke$lambda$7(Landroidx/compose/runtime/MutableIntState;)I
    .locals 4
    .param p0, "$touched$delegate"    # Landroidx/compose/runtime/MutableIntState;

    .line 64
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/IntState;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/IntState;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 290
    .local v3, "$i$f$getValue\\1\\64":I
    invoke-interface {v0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result v0

    .line 64
    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/IntState;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\64":I
    return v0
.end method

.method private static final invoke$lambda$8(Landroidx/compose/runtime/MutableIntState;I)V
    .locals 4
    .param p0, "$touched$delegate"    # Landroidx/compose/runtime/MutableIntState;
    .param p1, "<set-?>"    # I

    .line 64
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableIntState;
    const/4 v3, 0x0

    .line 291
    .local v3, "$i$f$setValue\\1\\64":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    .line 292
    nop

    .line 64
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableIntState;
    .end local v3    # "$i$f$setValue\\1\\64":I
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 48
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke(Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)V
    .locals 49
    .param p1, "$this$BoxWithConstraints"    # Landroidx/compose/foundation/layout/BoxWithConstraintsScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v7, p2

    const-string v2, "$this$BoxWithConstraints"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C75@4530L91,76@4654L18,76@4630L115:FullscreenScreen.kt#o13vsk"

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v3, p3, 0x6

    const/4 v4, 0x2

    if-nez v3, :cond_1

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    move v3, v4

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    move v11, v2

    .end local v2    # "$dirty":I
    .local v11, "$dirty":I
    and-int/lit8 v2, v11, 0x13

    const/16 v3, 0x12

    if-ne v2, v3, :cond_3

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_1

    .line 77
    :cond_2
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v8, v1

    move/from16 v29, v11

    goto/16 :goto_13

    .line 0
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_4

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.FullscreenScreen.<anonymous>.<anonymous> (FullscreenScreen.kt:51)"

    const v5, 0x5a334d7c

    invoke-static {v5, v11, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 52
    :cond_4
    const/16 v2, 0x58

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 157
    .local v3, "$i$f$getDp\\1\\52":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 52
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\52":I
    move/from16 v27, v2

    .line 53
    .local v27, "bar":F
    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxWidth-D9Ej5fM()F

    move-result v2

    .local v2, "arg0\\2":F
    iget v3, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$aspect:F

    .local v3, "other\\2":F
    const/4 v5, 0x0

    .line 158
    .local v5, "$i$f$div-u2uoSUM\\2\\53":I
    div-float v6, v2, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 53
    .end local v2    # "arg0\\2":F
    .end local v3    # "other\\2":F
    .end local v5    # "$i$f$div-u2uoSUM\\2\\53":I
    move v12, v2

    .line 54
    .local v12, "fitHeight":F
    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxHeight-D9Ej5fM()F

    move-result v2

    .local v2, "arg0\\3":F
    const/4 v3, 0x0

    .line 159
    .local v3, "$i$f$minus-5rwHm24\\3\\54":I
    sub-float v5, v2, v12

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 54
    .end local v2    # "arg0\\3":F
    .end local v3    # "$i$f$minus-5rwHm24\\3\\54":I
    const/4 v3, 0x2

    .local v2, "arg0\\4":F
    .local v3, "other\\4":I
    const/4 v5, 0x0

    .line 160
    .local v5, "$i$f$div-u2uoSUM\\4\\54":I
    int-to-float v6, v3

    div-float v6, v2, v6

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 54
    .end local v2    # "arg0\\4":F
    .end local v3    # "other\\4":I
    .end local v5    # "$i$f$div-u2uoSUM\\4\\54":I
    const v3, 0x3f4ccccd    # 0.8f

    .local v3, "other\\5":F
    const/4 v5, 0x0

    .line 161
    .local v5, "$i$f$times-u2uoSUM\\5\\54":I
    mul-float v6, v27, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 54
    .end local v3    # "other\\5":F
    .end local v5    # "$i$f$times-u2uoSUM\\5\\54":I
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/Dp;->compareTo-0680j_4(FF)I

    move-result v2

    if-ltz v2, :cond_5

    const/4 v2, 0x1

    goto :goto_2

    :cond_5
    const/4 v2, 0x0

    :goto_2
    move/from16 v28, v2

    .line 55
    .local v28, "docked":Z
    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxHeight-D9Ej5fM()F

    move-result v2

    if-eqz v28, :cond_6

    const/4 v3, 0x2

    .local v3, "other\\6":I
    const/4 v5, 0x0

    .line 162
    .local v5, "$i$f$times-u2uoSUM\\6\\55":I
    int-to-float v6, v3

    mul-float v6, v6, v27

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 55
    .end local v3    # "other\\6":I
    .end local v5    # "$i$f$times-u2uoSUM\\6\\55":I
    nop

    .local v2, "arg0\\7":F
    .local v3, "other\\7":F
    const/4 v5, 0x0

    .line 163
    .local v5, "$i$f$minus-5rwHm24\\7\\55":I
    sub-float v6, v2, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 55
    .end local v2    # "arg0\\7":F
    .end local v3    # "other\\7":F
    .end local v5    # "$i$f$minus-5rwHm24\\7\\55":I
    nop

    .local v2, "b\\8":F
    const/4 v3, 0x0

    .line 164
    .local v3, "$i$f$min-YgX7TsA\\8\\55":I
    invoke-static {v12, v2}, Ljava/lang/Math;->min(FF)F

    move-result v5

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .end local v2    # "b\\8":F
    .end local v3    # "$i$f$min-YgX7TsA\\8\\55":I
    goto :goto_3

    .line 55
    .local v2, "b\\9":F
    :cond_6
    const/4 v3, 0x0

    .line 164
    .local v3, "$i$f$min-YgX7TsA\\9\\55":I
    invoke-static {v12, v2}, Ljava/lang/Math;->min(FF)F

    move-result v5

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    move v2, v5

    .line 55
    .end local v2    # "b\\9":F
    .end local v3    # "$i$f$min-YgX7TsA\\9\\55":I
    :goto_3
    move v15, v2

    .line 56
    .local v15, "screenHeight":F
    iget v2, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$aspect:F

    .local v2, "other\\10":F
    const/4 v3, 0x0

    .line 165
    .local v3, "$i$f$times-u2uoSUM\\10\\56":I
    mul-float v5, v15, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 56
    .end local v2    # "other\\10":F
    .end local v3    # "$i$f$times-u2uoSUM\\10\\56":I
    move v9, v2

    .line 57
    .local v9, "screenWidth":F
    const-string v10, "C73@3429L9:Box.kt#2w3rfo"

    const v2, -0x7ff519f7    # -1.000876E-39f

    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    const-string v6, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    const v8, -0x4ee9b9da

    const-string v14, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    move/from16 v18, v11

    .end local v11    # "$dirty":I
    .local v18, "$dirty":I
    const/4 v11, 0x0

    move/from16 v20, v12

    .end local v12    # "fitHeight":F
    .local v20, "fitHeight":F
    const-string v12, "CC(remember):FullscreenScreen.kt#9igjgp"

    const/4 v13, 0x0

    if-eqz v28, :cond_c

    const v4, -0x47d0ac1d

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "57@2909L138,58@3060L244"

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 58
    move v4, v2

    iget-object v2, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v22, v3

    iget-object v3, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$guestSurface:Lkotlin/jvm/functions/Function3;

    sget-object v23, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v4, v23

    check-cast v4, Landroidx/compose/ui/Modifier;

    invoke-static {v4, v9, v15}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v23, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v5

    invoke-interface {v1, v4, v5}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    move-object v5, v6

    const/4 v6, 0x0

    move/from16 v23, v8

    const/16 v8, 0x6c00

    move-object/from16 v26, v5

    const/high16 v5, 0x3f800000    # 1.0f

    move-object/from16 v30, v22

    move-object/from16 v32, v26

    invoke-static/range {v2 .. v8}, Lorg/lighttouch/android/HomeScreenKt;->GuestScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZLandroidx/compose/runtime/Composer;I)V

    .line 59
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getBottomCenter()Landroidx/compose/ui/Alignment;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v2, v11, v3, v13}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxHeight-D9Ej5fM()F

    move-result v3

    .local v3, "arg0\\11":F
    const/4 v4, 0x0

    .line 166
    .local v4, "$i$f$minus-5rwHm24\\11\\59":I
    sub-float v5, v3, v15

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 59
    .end local v3    # "arg0\\11":F
    .end local v4    # "$i$f$minus-5rwHm24\\11\\59":I
    const/4 v4, 0x2

    .local v3, "arg0\\12":F
    .local v4, "other\\12":I
    const/4 v5, 0x0

    .line 167
    .local v5, "$i$f$div-u2uoSUM\\12\\59":I
    int-to-float v6, v4

    div-float v6, v3, v6

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 59
    .end local v3    # "arg0\\12":F
    .end local v4    # "other\\12":I
    .end local v5    # "$i$f$div-u2uoSUM\\12\\59":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\13":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v3

    .local v3, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    iget-object v4, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    iget-object v5, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$confirmStop$delegate:Landroidx/compose/runtime/MutableState;

    const/16 v6, 0x30

    .local v6, "$changed\\13":I
    const/4 v8, 0x0

    .line 168
    .local v8, "$i$f$Box\\13\\59":I
    const v11, 0x2bb5b5d7

    invoke-static {v7, v11, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 169
    const/4 v11, 0x0

    .line 172
    .local v11, "propagateMinConstraints\\13":Z
    invoke-static {v3, v11}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v21, v6, 0x3

    and-int/lit8 v21, v21, 0x70

    .line 173
    nop

    .local v21, "$changed\\14":I
    const/16 v23, 0x0

    .line 174
    .local v23, "$i$f$Layout\\14\\173":I
    move/from16 v24, v6

    move/from16 v25, v8

    move-object/from16 v6, v32

    const v8, -0x4ee9b9da

    .end local v6    # "$changed\\13":I
    .end local v8    # "$i$f$Box\\13\\59":I
    .local v24, "$changed\\13":I
    .local v25, "$i$f$Box\\13\\59":I
    invoke-static {v7, v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 175
    const/4 v6, 0x0

    invoke-static {v7, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v6

    .line 176
    .local v6, "compositeKeyHash\\14":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 177
    .local v8, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 179
    .local v13, "materialized\\14":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v32, v2

    .end local v2    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v32, "modifier\\13":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v21, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 178
    nop

    .local v2, "$changed\\15":I
    move-object/from16 v33, v16

    .local v33, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 180
    .local v16, "$i$f$ReusableComposeNode\\15\\178":I
    move-object/from16 v34, v4

    move/from16 v41, v6

    move-object/from16 v6, v30

    const v4, -0x2942ffcf

    .end local v6    # "compositeKeyHash\\14":I
    .local v41, "compositeKeyHash\\14":I
    invoke-static {v7, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 181
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 182
    :cond_7
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 183
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_8

    .line 184
    move-object/from16 v4, v33

    .end local v33    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 186
    .end local v4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "factory\\15":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v4, v33

    .end local v33    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 188
    :goto_4
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .local v6, "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 189
    .local v30, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\188\\14":I
    sget-object v31, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v33, v2

    .end local v2    # "$changed\\15":I
    .local v33, "$changed\\15":I
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v6, v14, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 190
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v6, v8, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 192
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\17":Lkotlin/jvm/functions/Function2;
    const/16 v31, 0x0

    .line 193
    .local v31, "$i$f$set-impl\\17\\192":I
    move-object/from16 v35, v6

    .local v35, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 194
    .local v36, "$i$a$-with-Updater$set$1\\18\\193\\17":I
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v37

    if-nez v37, :cond_a

    move-object/from16 v42, v3

    .end local v3    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .local v42, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v43, v4

    .end local v4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v43, "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9

    goto :goto_5

    :cond_9
    move-object/from16 v4, v35

    goto :goto_6

    .end local v42    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .end local v43    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .restart local v4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    :cond_a
    move-object/from16 v42, v3

    move-object/from16 v43, v4

    .line 195
    .end local v3    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .end local v4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v42    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .restart local v43    # "factory\\15":Lkotlin/jvm/functions/Function0;
    :goto_5
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v35

    .end local v35    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 196
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v6, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 198
    :goto_6
    nop

    .line 193
    .end local v4    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-with-Updater$set$1\\18\\193\\17":I
    nop

    .line 198
    nop

    .line 199
    .end local v2    # "block\\17":Lkotlin/jvm/functions/Function2;
    .end local v31    # "$i$f$set-impl\\17\\192":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v6, v13, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 200
    nop

    .line 188
    .end local v6    # "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\188\\14":I
    nop

    .line 201
    shr-int/lit8 v2, v33, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\19":I
    move-object/from16 v3, p2

    .local v3, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 202
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\19\\201\\13":I
    const v6, -0x7ff519f7    # -1.000876E-39f

    invoke-static {v3, v6, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v10, v24, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\20":I
    check-cast v6, Landroidx/compose/foundation/layout/BoxScope;

    .local v6, "$this$invoke_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v38, v3

    .local v38, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 60
    .local v29, "$i$a$-Box-FullscreenScreenKt$FullscreenScreen$1$3$1\\20\\202\\0":I
    move/from16 v30, v2

    .end local v2    # "$changed\\19":I
    .local v30, "$changed\\19":I
    const v2, 0x2bfa3afb

    move-object/from16 v31, v3

    .end local v3    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v31, "$composer\\19":Landroidx/compose/runtime/Composer;
    const-string v3, "C59@3268L22,59@3213L77:FullscreenScreen.kt#o13vsk"

    move/from16 v44, v4

    move-object/from16 v4, v38

    .end local v38    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v44, "$i$a$-Layout-BoxKt$Box$1\\19\\201\\13":I
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v17, v6

    move-object/from16 v22, v8

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v8, 0x0

    .end local v6    # "$this$invoke_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    .end local v8    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v17, "$this$invoke_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    .local v22, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v3, v6, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v3, 0x40

    .local v3, "$this$dp\\21":I
    const/4 v6, 0x0

    .line 203
    .local v6, "$i$f$getDp\\21\\60":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 60
    .end local v3    # "$this$dp\\21":I
    .end local v6    # "$i$f$getDp\\21\\60":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v35

    const v2, 0x4c5de2

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\22":Z
    move-object v3, v4

    .local v3, "$this$cache\\22":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 204
    .local v6, "$i$f$cache\\22\\60":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\22":Ljava/lang/Object;
    const/16 v26, 0x0

    .line 205
    .local v26, "$i$a$-let-ComposerKt$cache$1\\23\\204\\22":I
    sget-object v36, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v37, v2

    .end local v2    # "invalid\\22":Z
    .local v37, "invalid\\22":Z
    invoke-virtual/range {v36 .. v36}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v8, v2, :cond_b

    .line 206
    const/4 v2, 0x0

    .line 60
    .local v2, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$1$1\\24\\206\\20":I
    move/from16 v36, v2

    .end local v2    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$1$1\\24\\206\\20":I
    .local v36, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$1$1\\24\\206\\20":I
    new-instance v2, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$$ExternalSyntheticLambda0;

    invoke-direct {v2, v5}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 206
    .end local v36    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$1$1\\24\\206\\20":I
    nop

    .line 207
    .local v2, "value\\23":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 208
    nop

    .end local v2    # "value\\23":Ljava/lang/Object;
    goto :goto_7

    .line 209
    :cond_b
    move-object v2, v8

    .line 205
    :goto_7
    nop

    .line 204
    .end local v8    # "it\\22":Ljava/lang/Object;
    .end local v26    # "$i$a$-let-ComposerKt$cache$1\\23\\204\\22":I
    nop

    .line 60
    .end local v3    # "$this$cache\\22":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\22\\60":I
    .end local v37    # "invalid\\22":Z
    move-object/from16 v37, v2

    check-cast v37, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v39, 0xc30

    const/16 v40, 0x4

    const/16 v36, 0x0

    move-object/from16 v38, v4

    .end local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v38    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v40}, Lorg/lighttouch/android/FullscreenScreenKt;->access$ButtonBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .end local v38    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 61
    nop

    .line 202
    .end local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v10    # "$changed\\20":I
    .end local v17    # "$this$invoke_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    .end local v29    # "$i$a$-Box-FullscreenScreenKt$FullscreenScreen$1$3$1\\20\\202\\0":I
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 201
    .end local v30    # "$changed\\19":I
    .end local v31    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v44    # "$i$a$-Layout-BoxKt$Box$1\\19\\201\\13":I
    nop

    .line 210
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 180
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 211
    nop

    .line 174
    .end local v16    # "$i$f$ReusableComposeNode\\15\\178":I
    .end local v33    # "$changed\\15":I
    .end local v43    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 212
    nop

    .line 168
    .end local v13    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .end local v21    # "$changed\\14":I
    .end local v22    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v23    # "$i$f$Layout\\14\\173":I
    .end local v41    # "compositeKeyHash\\14":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 213
    nop

    .line 57
    .end local v11    # "propagateMinConstraints\\13":Z
    .end local v14    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "$changed\\13":I
    .end local v25    # "$i$f$Box\\13\\59":I
    .end local v32    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v42    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v31, v9

    goto/16 :goto_10

    .line 62
    :cond_c
    move v11, v2

    move v2, v4

    move-object/from16 v32, v6

    const v4, -0x2942ffcf

    move-object v6, v3

    const v3, -0x47c9de8b

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "62@3349L33,63@3410L33,64@3489L50,64@3456L83,65@3552L138,66@3807L266,66@3703L370,71@4245L18,71@4299L40,70@4100L411"

    invoke-static {v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v13, 0x6e3c21fe

    invoke-interface {v7, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 63
    move-object/from16 v3, p2

    const/16 v16, 0x0

    .local v3, "$this$cache\\25":Landroidx/compose/runtime/Composer;
    move/from16 v5, v16

    .local v5, "invalid\\25":Z
    const/16 v23, 0x0

    .line 214
    .local v23, "$i$f$cache\\25\\63":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\25":Ljava/lang/Object;
    const/16 v24, 0x0

    .line 215
    .local v24, "$i$a$-let-ComposerKt$cache$1\\26\\214\\25":I
    sget-object v29, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v4, v8, :cond_d

    .line 216
    const/4 v8, 0x0

    .line 63
    .local v8, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$visible$2\\27\\216\\0":I
    const/16 v17, 0x1

    invoke-static/range {v17 .. v17}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    const/4 v13, 0x0

    invoke-static {v11, v13, v2, v13}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    .line 216
    .end local v8    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$visible$2\\27\\216\\0":I
    nop

    .line 217
    .local v2, "value\\26":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 218
    nop

    .end local v2    # "value\\26":Ljava/lang/Object;
    goto :goto_8

    .line 219
    :cond_d
    move-object v2, v4

    .line 215
    :goto_8
    nop

    .line 214
    .end local v4    # "it\\25":Ljava/lang/Object;
    .end local v24    # "$i$a$-let-ComposerKt$cache$1\\26\\214\\25":I
    nop

    .line 63
    .end local v3    # "$this$cache\\25":Landroidx/compose/runtime/Composer;
    .end local v5    # "invalid\\25":Z
    .end local v23    # "$i$f$cache\\25\\63":I
    move-object v11, v2

    check-cast v11, Landroidx/compose/runtime/MutableState;

    .local v11, "visible$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x6e3c21fe

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 64
    const/16 v16, 0x0

    move/from16 v2, v16

    .local v2, "invalid\\28":Z
    move-object/from16 v3, p2

    .local v3, "$this$cache\\28":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 220
    .local v4, "$i$f$cache\\28\\64":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\28":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 221
    .local v8, "$i$a$-let-ComposerKt$cache$1\\29\\220\\28":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v5, v13, :cond_e

    .line 222
    const/4 v13, 0x0

    .line 64
    .local v13, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$touched$2\\30\\222\\0":I
    const/16 v16, 0x0

    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v13

    .line 222
    .end local v13    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$touched$2\\30\\222\\0":I
    nop

    .line 223
    .local v13, "value\\29":Ljava/lang/Object;
    invoke-interface {v3, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 224
    nop

    .end local v13    # "value\\29":Ljava/lang/Object;
    goto :goto_9

    .line 225
    :cond_e
    move-object v13, v5

    .line 221
    :goto_9
    nop

    .line 220
    .end local v5    # "it\\28":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\29\\220\\28":I
    nop

    .line 64
    .end local v2    # "invalid\\28":Z
    .end local v3    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\28\\64":I
    check-cast v13, Landroidx/compose/runtime/MutableIntState;

    .local v13, "touched$delegate":Landroidx/compose/runtime/MutableIntState;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 65
    invoke-static {v11}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v13}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$7(Landroidx/compose/runtime/MutableIntState;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const v4, 0x4c5de2

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\31":Z
    move-object/from16 v5, p2

    .local v5, "$this$cache\\31":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 226
    .local v8, "$i$f$cache\\31\\65":I
    move/from16 v23, v4

    .end local v4    # "invalid\\31":Z
    .local v23, "invalid\\31":Z
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\31":Ljava/lang/Object;
    const/16 v24, 0x0

    .line 227
    .local v24, "$i$a$-let-ComposerKt$cache$1\\32\\226\\31":I
    sget-object v31, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v34, v6

    invoke-virtual/range {v31 .. v31}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_f

    .line 228
    const/4 v6, 0x0

    .line 65
    .local v6, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$2\\33\\228\\0":I
    move-object/from16 v31, v4

    .end local v4    # "it\\31":Ljava/lang/Object;
    .local v31, "it\\31":Ljava/lang/Object;
    new-instance v4, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$2$1;

    move/from16 v35, v6

    const/4 v6, 0x0

    .end local v6    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$2\\33\\228\\0":I
    .local v35, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$2\\33\\228\\0":I
    invoke-direct {v4, v11, v6}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$2$1;-><init>(Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v4, Lkotlin/jvm/functions/Function2;

    .line 228
    .end local v35    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$2\\33\\228\\0":I
    nop

    .line 229
    .local v4, "value\\32":Ljava/lang/Object;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 230
    nop

    .end local v4    # "value\\32":Ljava/lang/Object;
    goto :goto_a

    .line 231
    .end local v31    # "it\\31":Ljava/lang/Object;
    .local v4, "it\\31":Ljava/lang/Object;
    :cond_f
    move-object/from16 v31, v4

    .line 227
    .end local v4    # "it\\31":Ljava/lang/Object;
    .restart local v31    # "it\\31":Ljava/lang/Object;
    :goto_a
    nop

    .line 226
    .end local v24    # "$i$a$-let-ComposerKt$cache$1\\32\\226\\31":I
    .end local v31    # "it\\31":Ljava/lang/Object;
    nop

    .line 65
    .end local v5    # "$this$cache\\31":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\31\\65":I
    .end local v23    # "invalid\\31":Z
    check-cast v4, Lkotlin/jvm/functions/Function2;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v6, 0x0

    invoke-static {v2, v3, v4, v7, v6}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 66
    iget-object v2, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    iget-object v3, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$guestSurface:Lkotlin/jvm/functions/Function3;

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    invoke-static {v4, v9, v15}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v5

    invoke-interface {v1, v4, v5}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v6, 0x0

    const/16 v8, 0x6c00

    const/high16 v5, 0x3f800000    # 1.0f

    move-object/from16 v47, v32

    move-object/from16 v45, v34

    invoke-static/range {v2 .. v8}, Lorg/lighttouch/android/HomeScreenKt;->GuestScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZLandroidx/compose/runtime/Composer;I)V

    .line 67
    invoke-static {v11}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getBottomCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    invoke-interface {v1, v3, v4}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v6, v5, v4, v6}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeIn$default(Landroidx/compose/animation/core/FiniteAnimationSpec;FILjava/lang/Object;)Landroidx/compose/animation/EnterTransition;

    move-result-object v8

    invoke-static {v6, v5, v4, v6}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeOut$default(Landroidx/compose/animation/core/FiniteAnimationSpec;FILjava/lang/Object;)Landroidx/compose/animation/ExitTransition;

    move-result-object v5

    new-instance v4, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$3;

    iget-object v6, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    move/from16 v22, v2

    iget-object v2, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$confirmStop$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {v4, v6, v13, v2}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$3;-><init>(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/MutableIntState;Landroidx/compose/runtime/MutableState;)V

    const/16 v2, 0x36

    const v6, 0x6aa8a180    # 1.019311E26f

    move-object/from16 v23, v3

    const/4 v3, 0x1

    invoke-static {v6, v3, v4, v7, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    check-cast v2, Lkotlin/jvm/functions/Function3;

    move v3, v9

    .end local v9    # "screenWidth":F
    .local v3, "screenWidth":F
    const v9, 0x30d80

    move-object v4, v10

    const/16 v10, 0x10

    const/4 v6, 0x0

    move-object/from16 v31, v7

    move-object v7, v2

    move/from16 v2, v22

    move-object/from16 v22, v13

    move-object v13, v4

    move-object v4, v8

    move-object/from16 v8, v31

    move/from16 v31, v3

    move-object/from16 v3, v23

    .end local v3    # "screenWidth":F
    .end local v13    # "touched$delegate":Landroidx/compose/runtime/MutableIntState;
    .local v22, "touched$delegate":Landroidx/compose/runtime/MutableIntState;
    .local v31, "screenWidth":F
    invoke-static/range {v2 .. v10}, Landroidx/compose/animation/AnimatedVisibilityKt;->AnimatedVisibility(ZLandroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransition;Landroidx/compose/animation/ExitTransition;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 71
    move-object v7, v8

    invoke-static {v11}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->invoke$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    if-nez v2, :cond_16

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getBottomCenter()Landroidx/compose/ui/Alignment;

    move-result-object v3

    invoke-interface {v1, v2, v3}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v32

    const/16 v2, 0xa

    .local v2, "$this$dp\\34":I
    const/4 v3, 0x0

    .line 232
    .local v3, "$i$f$getDp\\34\\71":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v36

    .line 71
    .end local v2    # "$this$dp\\34":I
    .end local v3    # "$i$f$getDp\\34\\71":I
    const/16 v37, 0x7

    const/16 v38, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-static/range {v32 .. v38}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v3, 0x48

    .local v3, "$this$dp\\35":I
    const/4 v4, 0x0

    .line 232
    .local v4, "$i$f$getDp\\35\\71":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 71
    .end local v3    # "$this$dp\\35":I
    .end local v4    # "$i$f$getDp\\35\\71":I
    const/16 v4, 0x1c

    .local v4, "$this$dp\\36":I
    const/4 v5, 0x0

    .line 232
    .local v5, "$i$f$getDp\\36\\71":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 71
    .end local v4    # "$this$dp\\36":I
    .end local v5    # "$i$f$getDp\\36\\71":I
    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v3, 0xe

    .local v3, "$this$dp\\37":I
    const/4 v4, 0x0

    .line 232
    .local v4, "$i$f$getDp\\37\\71":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 71
    .end local v3    # "$this$dp\\37":I
    .end local v4    # "$i$f$getDp\\37\\71":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v3}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v32

    .line 72
    const v2, 0x4c5de2

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\38":Z
    move-object/from16 v4, p2

    .local v4, "$this$cache\\38":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 233
    .local v5, "$i$f$cache\\38\\72":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\38":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 234
    .local v8, "$i$a$-let-ComposerKt$cache$1\\39\\233\\38":I
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v6, v9, :cond_10

    .line 235
    const/4 v9, 0x0

    .line 72
    .local v9, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$4\\40\\235\\0":I
    new-instance v10, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$$ExternalSyntheticLambda1;

    invoke-direct {v10, v11}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 235
    .end local v9    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$4\\40\\235\\0":I
    nop

    .line 236
    .local v10, "value\\39":Ljava/lang/Object;
    invoke-interface {v4, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 237
    nop

    .end local v10    # "value\\39":Ljava/lang/Object;
    goto :goto_b

    .line 238
    :cond_10
    move-object v10, v6

    .line 234
    :goto_b
    nop

    .line 233
    .end local v6    # "it\\38":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\39\\233\\38":I
    nop

    .line 72
    .end local v3    # "invalid\\38":Z
    .end local v4    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\38\\72":I
    move-object/from16 v36, v10

    check-cast v36, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v37, 0x7

    const/16 v38, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-static/range {v32 .. v38}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const-string v4, "show_controls"

    invoke-static {v3, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const v4, 0x6e3c21fe

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\41":Z
    move-object/from16 v5, p2

    .local v5, "$this$cache\\41":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 233
    .local v6, "$i$f$cache\\41\\72":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\41":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 234
    .local v9, "$i$a$-let-ComposerKt$cache$1\\42\\233\\41":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v8, v10, :cond_11

    .line 235
    const/4 v10, 0x0

    .local v10, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$5\\43\\235\\0":I
    new-instance v19, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$$ExternalSyntheticLambda2;

    invoke-direct/range {v19 .. v19}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$$ExternalSyntheticLambda2;-><init>()V

    .end local v10    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$5\\43\\235\\0":I
    move-object/from16 v10, v19

    .line 236
    .local v10, "value\\42":Ljava/lang/Object;
    invoke-interface {v5, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 237
    nop

    .end local v10    # "value\\42":Ljava/lang/Object;
    goto :goto_c

    .line 238
    :cond_11
    move-object v10, v8

    .line 234
    :goto_c
    nop

    .line 233
    .end local v8    # "it\\41":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\42\\233\\41":I
    nop

    .line 72
    .end local v4    # "invalid\\41":Z
    .end local v5    # "$this$cache\\41":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\41\\72":I
    check-cast v10, Lkotlin/jvm/functions/Function1;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v8, 0x0

    invoke-static {v3, v4, v10, v6, v8}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 71
    const/16 v5, 0x30

    .local v3, "modifier\\44":Landroidx/compose/ui/Modifier;
    .local v4, "contentAlignment\\44":Landroidx/compose/ui/Alignment;
    .local v5, "$changed\\44":I
    const/4 v6, 0x0

    .line 239
    .local v6, "$i$f$Box\\44\\71":I
    const v8, 0x2bb5b5d7

    invoke-static {v7, v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 240
    const/4 v8, 0x0

    .line 243
    .local v8, "propagateMinConstraints\\44":Z
    invoke-static {v4, v8}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 244
    nop

    .local v10, "$changed\\45":I
    const/4 v14, 0x0

    .line 245
    .local v14, "$i$f$Layout\\45\\244":I
    move-object/from16 v17, v4

    move-object/from16 v2, v47

    const v4, -0x4ee9b9da

    .end local v4    # "contentAlignment\\44":Landroidx/compose/ui/Alignment;
    .local v17, "contentAlignment\\44":Landroidx/compose/ui/Alignment;
    invoke-static {v7, v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 246
    const/4 v4, 0x0

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v2

    .line 247
    .local v2, "compositeKeyHash\\45":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 248
    .local v4, "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v21, v2

    .end local v2    # "compositeKeyHash\\45":I
    .local v21, "compositeKeyHash\\45":I
    invoke-static {v7, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 250
    .local v2, "materialized\\45":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v24, v3

    .end local v3    # "modifier\\44":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\44":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v10, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 249
    nop

    .local v3, "$changed\\46":I
    move-object/from16 v25, v23

    .local v25, "factory\\46":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 251
    .local v23, "$i$f$ReusableComposeNode\\46\\249":I
    move/from16 v26, v3

    move/from16 v30, v5

    move-object/from16 v3, v45

    const v5, -0x2942ffcf

    .end local v3    # "$changed\\46":I
    .end local v5    # "$changed\\44":I
    .local v26, "$changed\\46":I
    .local v30, "$changed\\44":I
    invoke-static {v7, v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 252
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_12

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 253
    :cond_12
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 254
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_13

    .line 255
    move-object/from16 v3, v25

    .end local v25    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 257
    .end local v3    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\46":Lkotlin/jvm/functions/Function0;
    :cond_13
    move-object/from16 v3, v25

    .end local v25    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 259
    :goto_d
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 260
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\47\\259\\45":I
    sget-object v32, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v33, v3

    .end local v3    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .local v33, "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v32 .. v32}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 261
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v4, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 263
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\48":Lkotlin/jvm/functions/Function2;
    const/16 v32, 0x0

    .line 264
    .local v32, "$i$f$set-impl\\48\\263":I
    move-object/from16 v34, v5

    .local v34, "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 265
    .local v35, "$i$a$-with-Updater$set$1\\49\\264\\48":I
    invoke-interface/range {v34 .. v34}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v36

    if-nez v36, :cond_15

    move-object/from16 v36, v4

    .end local v4    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .local v36, "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v34 .. v34}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v37, v6

    .end local v6    # "$i$f$Box\\44\\71":I
    .local v37, "$i$f$Box\\44\\71":I
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_14

    goto :goto_e

    :cond_14
    move-object/from16 v6, v34

    goto :goto_f

    .end local v36    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v37    # "$i$f$Box\\44\\71":I
    .restart local v4    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "$i$f$Box\\44\\71":I
    :cond_15
    move-object/from16 v36, v4

    move/from16 v37, v6

    .line 266
    .end local v4    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "$i$f$Box\\44\\71":I
    .restart local v36    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v37    # "$i$f$Box\\44\\71":I
    :goto_e
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v6, v34

    .end local v34    # "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 267
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 269
    :goto_f
    nop

    .line 264
    .end local v6    # "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    .end local v35    # "$i$a$-with-Updater$set$1\\49\\264\\48":I
    nop

    .line 269
    nop

    .line 270
    .end local v3    # "block\\48":Lkotlin/jvm/functions/Function2;
    .end local v32    # "$i$f$set-impl\\48\\263":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 271
    nop

    .line 259
    .end local v5    # "$this$Layout_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\47\\259\\45":I
    nop

    .line 272
    shr-int/lit8 v3, v26, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\50":I
    move-object/from16 v4, p2

    .local v4, "$composer\\50":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 273
    .local v5, "$i$a$-Layout-BoxKt$Box$1\\50\\272\\44":I
    const v6, -0x7ff519f7    # -1.000876E-39f

    invoke-static {v4, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v13, v30, 0x6

    and-int/lit8 v13, v13, 0x70

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\51":I
    check-cast v6, Landroidx/compose/foundation/layout/BoxScope;

    .local v6, "$this$invoke_u24lambda_u2414\\51":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v25, v4

    .local v25, "$composer\\51":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 73
    .local v29, "$i$a$-Box-FullscreenScreenKt$FullscreenScreen$1$3$6\\51\\273\\0":I
    move-object/from16 v32, v2

    .end local v2    # "materialized\\45":Landroidx/compose/ui/Modifier;
    .local v32, "materialized\\45":Landroidx/compose/ui/Modifier;
    const v2, 0x1b994987

    move/from16 v34, v3

    .end local v3    # "$changed\\50":I
    .local v34, "$changed\\50":I
    const-string v3, "C72@4396L101:FullscreenScreen.kt#o13vsk"

    move-object/from16 v35, v4

    .end local v25    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\51":Landroidx/compose/runtime/Composer;
    .local v35, "$composer\\50":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x28

    .local v3, "$this$dp\\52":I
    const/16 v25, 0x0

    .line 274
    .local v25, "$i$f$getDp\\52\\73":I
    move/from16 v38, v5

    .end local v5    # "$i$a$-Layout-BoxKt$Box$1\\50\\272\\44":I
    .local v38, "$i$a$-Layout-BoxKt$Box$1\\50\\272\\44":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 73
    .end local v3    # "$this$dp\\52":I
    .end local v25    # "$i$f$getDp\\52\\73":I
    const/4 v5, 0x5

    .local v5, "$this$dp\\53":I
    const/16 v25, 0x0

    .line 274
    .local v25, "$i$f$getDp\\53\\73":I
    move-object/from16 v39, v6

    .end local v6    # "$this$invoke_u24lambda_u2414\\51":Landroidx/compose/foundation/layout/BoxScope;
    .local v39, "$this$invoke_u24lambda_u2414\\51":Landroidx/compose/foundation/layout/BoxScope;
    int-to-float v6, v5

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 73
    .end local v5    # "$this$dp\\53":I
    .end local v25    # "$i$f$getDp\\53\\73":I
    invoke-static {v2, v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v3, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v40

    const/16 v46, 0xe

    const/16 v47, 0x0

    const v42, 0x3ee66666    # 0.45f

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    invoke-static/range {v40 .. v47}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v5

    const/4 v3, 0x3

    .local v3, "$this$dp\\54":I
    const/16 v25, 0x0

    .line 274
    .local v25, "$i$f$getDp\\54\\73":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 73
    .end local v3    # "$this$dp\\54":I
    .end local v25    # "$i$f$getDp\\54\\73":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v5, v6, v3}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v6, 0x0

    invoke-static {v2, v4, v6}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 74
    nop

    .line 273
    .end local v4    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .end local v13    # "$changed\\51":I
    .end local v29    # "$i$a$-Box-FullscreenScreenKt$FullscreenScreen$1$3$6\\51\\273\\0":I
    .end local v39    # "$this$invoke_u24lambda_u2414\\51":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v35 .. v35}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 272
    .end local v34    # "$changed\\50":I
    .end local v35    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .end local v38    # "$i$a$-Layout-BoxKt$Box$1\\50\\272\\44":I
    nop

    .line 275
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 251
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 276
    nop

    .line 245
    .end local v23    # "$i$f$ReusableComposeNode\\46\\249":I
    .end local v26    # "$changed\\46":I
    .end local v33    # "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 277
    nop

    .line 239
    .end local v10    # "$changed\\45":I
    .end local v14    # "$i$f$Layout\\45\\244":I
    .end local v21    # "compositeKeyHash\\45":I
    .end local v32    # "materialized\\45":Landroidx/compose/ui/Modifier;
    .end local v36    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 278
    nop

    .line 62
    .end local v8    # "propagateMinConstraints\\44":Z
    .end local v9    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v11    # "visible$delegate":Landroidx/compose/runtime/MutableState;
    .end local v17    # "contentAlignment\\44":Landroidx/compose/ui/Alignment;
    .end local v22    # "touched$delegate":Landroidx/compose/runtime/MutableIntState;
    .end local v24    # "modifier\\44":Landroidx/compose/ui/Modifier;
    .end local v30    # "$changed\\44":I
    .end local v37    # "$i$f$Box\\44\\71":I
    :cond_16
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 76
    :goto_10
    iget-object v2, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x1

    .local v4, "$this$dp\\55":I
    const/4 v5, 0x0

    .line 279
    .local v5, "$i$f$getDp\\55\\76":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 76
    .end local v4    # "$this$dp\\55":I
    .end local v5    # "$i$f$getDp\\55\\76":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const-string v4, "session_status"

    invoke-static {v3, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v4, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v4

    const/16 v25, 0x0

    const v26, 0x1fff8

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v13, v12

    const-wide/16 v11, 0x0

    move-object v14, v13

    const/4 v13, 0x0

    move-object/from16 v16, v14

    const/4 v14, 0x0

    move/from16 v17, v15

    move-object/from16 v21, v16

    .end local v15    # "screenHeight":F
    .local v17, "screenHeight":F
    const-wide/16 v15, 0x0

    move/from16 v22, v17

    .end local v17    # "screenHeight":F
    .local v22, "screenHeight":F
    const/16 v17, 0x0

    move/from16 v23, v18

    .end local v18    # "$dirty":I
    .local v23, "$dirty":I
    const/16 v18, 0x0

    const v24, 0x4c5de2

    const/16 v19, 0x0

    move/from16 v29, v20

    .end local v20    # "fitHeight":F
    .local v29, "fitHeight":F
    const/16 v20, 0x0

    move-object/from16 v30, v21

    const/16 v21, 0x0

    move/from16 v32, v22

    .end local v22    # "screenHeight":F
    .local v32, "screenHeight":F
    const/16 v22, 0x0

    move/from16 v33, v24

    const/16 v24, 0x1b0

    move-object/from16 v48, v30

    move/from16 v1, v33

    move/from16 v30, v29

    move/from16 v29, v23

    move-object/from16 v23, p2

    .end local v23    # "$dirty":I
    .local v29, "$dirty":I
    .local v30, "fitHeight":F
    invoke-static/range {v2 .. v26}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 77
    move-object/from16 v7, v23

    iget-object v2, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getError()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    move-object/from16 v13, v48

    invoke-static {v7, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\56":Z
    move-object/from16 v4, p2

    .local v4, "$this$cache\\56":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 280
    .local v5, "$i$f$cache\\56\\77":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\56":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 281
    .local v8, "$i$a$-let-ComposerKt$cache$1\\57\\280\\56":I
    if-nez v1, :cond_18

    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v6, v9, :cond_17

    goto :goto_11

    .line 285
    :cond_17
    move-object v10, v6

    goto :goto_12

    .line 282
    :cond_18
    :goto_11
    const/4 v9, 0x0

    .line 77
    .local v9, "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$7\\58\\282\\0":I
    new-instance v10, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$7$1;

    invoke-direct {v10, v3}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1$3$7$1;-><init>(Ljava/lang/Object;)V

    check-cast v10, Lkotlin/reflect/KFunction;

    .line 282
    .end local v9    # "$i$a$-cache-FullscreenScreenKt$FullscreenScreen$1$3$7\\58\\282\\0":I
    nop

    .line 283
    .local v10, "value\\57":Ljava/lang/Object;
    invoke-interface {v4, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 284
    nop

    .line 281
    .end local v10    # "value\\57":Ljava/lang/Object;
    :goto_12
    nop

    .line 280
    .end local v6    # "it\\56":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\57\\280\\56":I
    nop

    .line 77
    .end local v1    # "invalid\\56":Z
    .end local v4    # "$this$cache\\56":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\56\\77":I
    check-cast v10, Lkotlin/reflect/KFunction;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v3, v10

    check-cast v3, Lkotlin/jvm/functions/Function0;

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getTopCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    move-object/from16 v8, p1

    invoke-interface {v8, v1, v4}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1}, Landroidx/compose/foundation/layout/WindowInsetsPadding_androidKt;->statusBarsPadding(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v4, 0xc

    .local v4, "$this$dp\\59":I
    const/4 v5, 0x0

    .line 286
    .local v5, "$i$f$getDp\\59\\77":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 77
    .end local v4    # "$this$dp\\59":I
    .end local v5    # "$i$f$getDp\\59\\77":I
    invoke-static {v1, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object/from16 v5, p2

    invoke-static/range {v2 .. v7}, Lorg/lighttouch/android/ShellKt;->ErrorBanner(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 78
    .end local v27    # "bar":F
    .end local v28    # "docked":Z
    .end local v30    # "fitHeight":F
    .end local v31    # "screenWidth":F
    .end local v32    # "screenHeight":F
    :cond_19
    :goto_13
    return-void
.end method

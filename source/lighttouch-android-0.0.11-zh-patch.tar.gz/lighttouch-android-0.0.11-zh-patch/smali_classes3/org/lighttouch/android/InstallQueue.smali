.class public final Lorg/lighttouch/android/InstallQueue;
.super Ljava/lang/Object;
.source "InstallQueue.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/InstallQueue$Entry;,
        Lorg/lighttouch/android/InstallQueue$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<P:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nInstallQueue.kt\nKotlin\n*S Kotlin\n*F\n+ 1 InstallQueue.kt\norg/lighttouch/android/InstallQueue\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,218:1\n1#2:219\n1563#3:220\n1634#3,3:221\n1761#3,3:224\n1761#3,3:227\n295#3,2:230\n360#3,7:232\n1761#3,3:239\n295#3,2:242\n2746#3,3:244\n295#3,2:247\n*S KotlinDebug\n*F\n+ 1 InstallQueue.kt\norg/lighttouch/android/InstallQueue\n*L\n75#1:220\n75#1:221,3\n76#1:224,3\n81#1:227,3\n94#1:230,2\n109#1:232,7\n136#1:239,3\n169#1:242,2\n174#1:244,3\n174#1:247,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000_\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0005\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\r\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0010\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0008\u0007*\u0001:\u0008\u0007\u0018\u0000*\u0004\u0008\u0000\u0010\u00012\u00020\u0002:\u0001?B7\u0012\u000c\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u0004\u0012 \u0008\u0002\u0010\u0005\u001a\u001a\u0012\u0004\u0012\u00020\u0007\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\t0\u0008\u0012\u0004\u0012\u00020\t0\u0006\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\u000c\u0010!\u001a\u0008\u0012\u0004\u0012\u00020#0\"J#\u0010\'\u001a\u00020\u00142\u0006\u0010(\u001a\u00020\u00072\u0006\u0010)\u001a\u00020\u00072\u0006\u0010*\u001a\u00028\u0000\u00a2\u0006\u0002\u0010+J\u000e\u0010,\u001a\u00020\t2\u0006\u0010-\u001a\u00020\u0012J\u000e\u0010.\u001a\u00020\t2\u0006\u0010-\u001a\u00020\u0012J\u000e\u0010/\u001a\u00020\t2\u0006\u0010-\u001a\u00020\u0012J\u0006\u00100\u001a\u00020\tJ\u0008\u00101\u001a\u00020\tH\u0002J\u0010\u00103\u001a\u0002042\u0006\u0010$\u001a\u00020\u0014H\u0002J*\u00105\u001a\u00020\t2\u000c\u00106\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u00102\u0012\u00107\u001a\u000e\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020#08H\u0002J\u001b\u00109\u001a\u00020:2\u000c\u00106\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u0010H\u0002\u00a2\u0006\u0002\u0010;J\u0008\u0010<\u001a\u00020\tH\u0002J\u0016\u0010=\u001a\u00020\t2\u000c\u00106\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u0010H\u0002J\u0016\u0010>\u001a\u00020\t2\u000c\u00106\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u0010H\u0002R\u0014\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00028\u00000\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R&\u0010\u0005\u001a\u001a\u0012\u0004\u0012\u00020\u0007\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\t0\u0008\u0012\u0004\u0012\u00020\t0\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0002X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0002X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00028\u00000\u00100\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R \u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0017\u0010\u0018\"\u0004\u0008\u0019\u0010\u001aR \u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001c\u0010\u0018\"\u0004\u0008\u001d\u0010\u001aR \u0010\u001e\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0008X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001f\u0010\u0018\"\u0004\u0008 \u0010\u001aR\u0011\u0010$\u001a\u00020\u00148F\u00a2\u0006\u0006\u001a\u0004\u0008%\u0010&R\u000e\u00102\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006@"
    }
    d2 = {
        "Lorg/lighttouch/android/InstallQueue;",
        "P",
        "",
        "work",
        "Lorg/lighttouch/android/QueueWork;",
        "spawn",
        "Lkotlin/Function2;",
        "",
        "Lkotlin/Function0;",
        "",
        "<init>",
        "(Lorg/lighttouch/android/QueueWork;Lkotlin/jvm/functions/Function2;)V",
        "lock",
        "announce",
        "entries",
        "",
        "Lorg/lighttouch/android/InstallQueue$Entry;",
        "nextId",
        "",
        "fetching",
        "",
        "installing",
        "onChange",
        "getOnChange",
        "()Lkotlin/jvm/functions/Function0;",
        "setOnChange",
        "(Lkotlin/jvm/functions/Function0;)V",
        "onBusy",
        "getOnBusy",
        "setOnBusy",
        "onIdle",
        "getOnIdle",
        "setOnIdle",
        "snapshot",
        "",
        "Lorg/lighttouch/android/QueueItem;",
        "active",
        "getActive",
        "()Z",
        "enqueue",
        "key",
        "name",
        "payload",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Z",
        "cancel",
        "id",
        "retry",
        "dismiss",
        "clearFinished",
        "changed",
        "announced",
        "transition",
        "",
        "update",
        "entry",
        "change",
        "Lkotlin/Function1;",
        "reporter",
        "org/lighttouch/android/InstallQueue$reporter$1",
        "(Lorg/lighttouch/android/InstallQueue$Entry;)Lorg/lighttouch/android/InstallQueue$reporter$1;",
        "pump",
        "runFetch",
        "runInstall",
        "Entry",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final announce:Ljava/lang/Object;

.field private announced:Z

.field private final entries:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstallQueue$Entry<",
            "TP;>;>;"
        }
    .end annotation
.end field

.field private fetching:Z

.field private installing:Z

.field private final lock:Ljava/lang/Object;

.field private nextId:J

.field private volatile onBusy:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private volatile onChange:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private volatile onIdle:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final spawn:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final work:Lorg/lighttouch/android/QueueWork;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lorg/lighttouch/android/QueueWork<",
            "TP;>;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$7g3G35UeDQeY0ENDQE-GaLSdT1I(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/InstallQueue;->pump$lambda$32$lambda$31(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$CoSLJXCQWUuDNOv52Jy-Pa0tr34(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/InstallQueue;->_init_$lambda$2(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$HslJ0eBlEHZ22n2PdLgclhaFt7M()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/InstallQueue;->onBusy$lambda$4()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$JFhK8bX5OMqGw43CTtRQN56hBhk()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/InstallQueue;->onIdle$lambda$5()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$XU9LWAsVqgRM6YweyV9_3cf3RbQ(Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/InstallQueue;->runInstall$lambda$40(Lorg/lighttouch/android/InstallQueue$Entry;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$_ZFASRUx3Y2kJY5NqRmMuLeKm3A(Ljava/lang/String;Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/InstallQueue;->enqueue$lambda$12$lambda$11(Ljava/lang/String;Lorg/lighttouch/android/InstallQueue$Entry;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$bEQ3tb65KgvTTjSeL_nS3O3vyO4(Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/InstallQueue;->runFetch$lambda$35(Lorg/lighttouch/android/InstallQueue$Entry;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$dHHHyH8UDrPvQ9X-sn3JAzhi2Fc(Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/InstallQueue;->clearFinished$lambda$20$lambda$19(Lorg/lighttouch/android/InstallQueue$Entry;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$i8-HC-ba-jo6ia61q0l21cyij28()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/InstallQueue;->onChange$lambda$3()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$jiXb8U3vxmBXr3QHvihpA1r8nos(JLorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/InstallQueue;->dismiss$lambda$18$lambda$17(JLorg/lighttouch/android/InstallQueue$Entry;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$sm5hyS-gReDr_tALrK_e9mGd3UE(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/InstallQueue;->_init_$lambda$2$lambda$0(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$xy1uqIvRjgwdXgupw4wBqc_gfag(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/InstallQueue;->pump$lambda$34$lambda$33(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/InstallQueue;->$stable:I

    return-void
.end method

.method public constructor <init>(Lorg/lighttouch/android/QueueWork;Lkotlin/jvm/functions/Function2;)V
    .locals 2
    .param p1, "work"    # Lorg/lighttouch/android/QueueWork;
    .param p2, "spawn"    # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/QueueWork<",
            "TP;>;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "work"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "spawn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/InstallQueue;->work:Lorg/lighttouch/android/QueueWork;

    .line 61
    iput-object p2, p0, Lorg/lighttouch/android/InstallQueue;->spawn:Lkotlin/jvm/functions/Function2;

    .line 64
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    .line 65
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/InstallQueue;->announce:Ljava/lang/Object;

    .line 66
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/List;

    iput-object v0, p0, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    .line 67
    const-wide/16 v0, 0x1

    iput-wide v0, p0, Lorg/lighttouch/android/InstallQueue;->nextId:J

    .line 71
    new-instance v0, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda9;

    invoke-direct {v0}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda9;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onChange:Lkotlin/jvm/functions/Function0;

    .line 72
    new-instance v0, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda10;

    invoke-direct {v0}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda10;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onBusy:Lkotlin/jvm/functions/Function0;

    .line 73
    new-instance v0, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda11;

    invoke-direct {v0}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda11;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onIdle:Lkotlin/jvm/functions/Function0;

    .line 60
    return-void
.end method

.method public synthetic constructor <init>(Lorg/lighttouch/android/QueueWork;Lkotlin/jvm/functions/Function2;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 60
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    .line 61
    new-instance p2, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda3;

    invoke-direct {p2}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda3;-><init>()V

    .line 60
    :cond_0
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/InstallQueue;-><init>(Lorg/lighttouch/android/QueueWork;Lkotlin/jvm/functions/Function2;)V

    .line 61
    return-void
.end method

.method private static final _init_$lambda$2(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .locals 4
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "body"    # Lkotlin/jvm/functions/Function0;

    const-string v0, "name"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "body"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda6;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda6;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-direct {v0, v1, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    move-object v1, v0

    .line 219
    .local v1, "$this$_init__u24lambda_u242_u24lambda_u241\\1":Ljava/lang/Thread;
    const/4 v2, 0x0

    .line 61
    .local v2, "$i$a$-apply-InstallQueue$1$1\\1\\61\\0":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/Thread;->setDaemon(Z)V

    .end local v1    # "$this$_init__u24lambda_u242_u24lambda_u241\\1":Ljava/lang/Thread;
    .end local v2    # "$i$a$-apply-InstallQueue$1$1\\1\\61\\0":I
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final _init_$lambda$2$lambda$0(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 61
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method public static final synthetic access$update(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;Lkotlin/jvm/functions/Function1;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/InstallQueue;
    .param p1, "entry"    # Lorg/lighttouch/android/InstallQueue$Entry;
    .param p2, "change"    # Lkotlin/jvm/functions/Function1;

    .line 60
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/InstallQueue;->update(Lorg/lighttouch/android/InstallQueue$Entry;Lkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method private final changed()V
    .locals 12

    .line 135
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->announce:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 136
    .local v1, "$i$a$-synchronized-InstallQueue$changed$1\\1\\135\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 219
    const/4 v3, 0x0

    .line 136
    .local v3, "$i$a$-synchronized-InstallQueue$changed$1$transition$1\\2\\136\\1":I
    :try_start_1
    iget-object v4, p0, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$any\\3":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 239
    .local v5, "$i$f$any\\3\\136":I
    instance-of v6, v4, Ljava/util/Collection;

    const/4 v7, 0x0

    if-eqz v6, :cond_0

    move-object v6, v4

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_0

    goto :goto_0

    .line 240
    :cond_0
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\3":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v9, "it\\4":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v10, 0x0

    .line 136
    .local v10, "$i$a$-any-InstallQueue$changed$1$transition$1$1\\4\\240\\2":I
    invoke-virtual {v9}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v11

    invoke-virtual {v11}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v11

    .line 240
    .end local v9    # "it\\4":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v10    # "$i$a$-any-InstallQueue$changed$1$transition$1$1\\4\\240\\2":I
    if-eqz v11, :cond_1

    const/4 v7, 0x1

    goto :goto_0

    .line 241
    .end local v8    # "element\\3":Ljava/lang/Object;
    :cond_2
    nop

    .line 136
    .end local v4    # "$this$any\\3":Ljava/lang/Iterable;
    .end local v5    # "$i$f$any\\3\\136":I
    :goto_0
    invoke-direct {p0, v7}, Lorg/lighttouch/android/InstallQueue;->transition(Z)I

    move-result v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v3    # "$i$a$-synchronized-InstallQueue$changed$1$transition$1\\2\\136\\1":I
    :try_start_2
    monitor-exit v2

    .line 137
    .local v4, "transition\\1":I
    if-lez v4, :cond_3

    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->onBusy:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 138
    :cond_3
    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->onChange:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 139
    if-gez v4, :cond_4

    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->onIdle:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 140
    :cond_4
    nop

    .end local v1    # "$i$a$-synchronized-InstallQueue$changed$1\\1\\135\\0":I
    .end local v4    # "transition\\1":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 135
    monitor-exit v0

    .line 141
    invoke-direct {p0}, Lorg/lighttouch/android/InstallQueue;->pump()V

    .line 142
    return-void

    .line 136
    .restart local v1    # "$i$a$-synchronized-InstallQueue$changed$1\\1\\135\\0":I
    :catchall_0
    move-exception v3

    :try_start_3
    monitor-exit v2

    .end local p0    # "this":Lorg/lighttouch/android/InstallQueue;
    throw v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 135
    .end local v1    # "$i$a$-synchronized-InstallQueue$changed$1\\1\\135\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/InstallQueue;
    :catchall_1
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private static final clearFinished$lambda$20$lambda$19(Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/InstallQueue$Entry;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 127
    invoke-virtual {p0}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    return v0
.end method

.method private static final dismiss$lambda$18$lambda$17(JLorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 2
    .param p0, "$id"    # J
    .param p2, "it"    # Lorg/lighttouch/android/InstallQueue$Entry;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 122
    invoke-virtual {p2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v0

    cmp-long v0, v0, p0

    if-nez v0, :cond_0

    invoke-virtual {p2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static final enqueue$lambda$12$lambda$11(Ljava/lang/String;Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 1
    .param p0, "$key"    # Ljava/lang/String;
    .param p1, "it"    # Lorg/lighttouch/android/InstallQueue$Entry;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    invoke-virtual {p1}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getKey()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method private static final onBusy$lambda$4()Lkotlin/Unit;
    .locals 1

    .line 72
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final onChange$lambda$3()Lkotlin/Unit;
    .locals 1

    .line 71
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final onIdle$lambda$5()Lkotlin/Unit;
    .locals 1

    .line 73
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final pump()V
    .locals 25

    .line 166
    move-object/from16 v1, p0

    const/4 v2, 0x0

    .line 167
    .local v2, "fetch":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 168
    .local v3, "install":Ljava/lang/Object;
    iget-object v4, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v4

    const/4 v0, 0x0

    .line 169
    .local v0, "$i$a$-synchronized-InstallQueue$pump$1\\1\\168\\0":I
    :try_start_0
    iget-boolean v5, v1, Lorg/lighttouch/android/InstallQueue;->installing:Z

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-nez v5, :cond_3

    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$firstOrNull\\2":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 242
    .local v9, "$i$f$firstOrNull\\2\\169":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_2

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\2":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v12, "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v13, 0x0

    .line 169
    .local v13, "$i$a$-firstOrNull-InstallQueue$pump$1$1\\3\\242\\1":I
    invoke-virtual {v12}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v14

    invoke-virtual {v14}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v14

    sget-object v15, Lorg/lighttouch/android/QueueState;->READY:Lorg/lighttouch/android/QueueState;

    if-ne v14, v15, :cond_1

    move v12, v8

    goto :goto_0

    :cond_1
    move v12, v7

    .line 242
    .end local v12    # "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v13    # "$i$a$-firstOrNull-InstallQueue$pump$1$1\\3\\242\\1":I
    :goto_0
    if-eqz v12, :cond_0

    goto :goto_1

    .line 243
    .end local v11    # "element\\2":Ljava/lang/Object;
    :cond_2
    move-object v11, v6

    .line 169
    .end local v5    # "$this$firstOrNull\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$firstOrNull\\2\\169":I
    :goto_1
    check-cast v11, Lorg/lighttouch/android/InstallQueue$Entry;

    if-eqz v11, :cond_3

    .local v11, "entry\\4":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v5, 0x0

    .line 170
    .local v5, "$i$a$-let-InstallQueue$pump$1$2\\4\\169\\1":I
    iput-boolean v8, v1, Lorg/lighttouch/android/InstallQueue;->installing:Z

    move-object v3, v11

    .line 171
    invoke-virtual {v11}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v12

    sget-object v17, Lorg/lighttouch/android/QueueState;->INSTALLING:Lorg/lighttouch/android/QueueState;

    const-string v18, "\u5b89\u88c5\u4e2d"

    const/16 v23, 0x1c7

    const/16 v24, 0x0

    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    invoke-static/range {v12 .. v24}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v9

    invoke-virtual {v11, v9}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    .line 172
    nop

    .line 169
    .end local v5    # "$i$a$-let-InstallQueue$pump$1$2\\4\\169\\1":I
    .end local v11    # "entry\\4":Lorg/lighttouch/android/InstallQueue$Entry;
    :cond_3
    nop

    .line 174
    iget-boolean v5, v1, Lorg/lighttouch/android/InstallQueue;->fetching:Z

    if-nez v5, :cond_b

    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$none\\5":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 244
    .local v9, "$i$f$none\\5\\174":I
    instance-of v10, v5, Ljava/util/Collection;

    if-eqz v10, :cond_4

    move-object v10, v5

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_4

    move v5, v8

    goto :goto_3

    .line 245
    :cond_4
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_5
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_7

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\5":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v12, "it\\6":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v13, 0x0

    .line 174
    .local v13, "$i$a$-none-InstallQueue$pump$1$3\\6\\245\\1":I
    invoke-virtual {v12}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v14

    invoke-virtual {v14}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v14

    sget-object v15, Lorg/lighttouch/android/QueueState;->READY:Lorg/lighttouch/android/QueueState;

    if-ne v14, v15, :cond_6

    move v12, v8

    goto :goto_2

    :cond_6
    move v12, v7

    .line 245
    .end local v12    # "it\\6":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v13    # "$i$a$-none-InstallQueue$pump$1$3\\6\\245\\1":I
    :goto_2
    if-eqz v12, :cond_5

    move v5, v7

    goto :goto_3

    .line 246
    .end local v11    # "element\\5":Ljava/lang/Object;
    :cond_7
    move v5, v8

    .line 174
    .end local v5    # "$this$none\\5":Ljava/lang/Iterable;
    .end local v9    # "$i$f$none\\5\\174":I
    :goto_3
    if-eqz v5, :cond_b

    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$firstOrNull\\7":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 247
    .local v9, "$i$f$firstOrNull\\7\\174":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_8
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_a

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\7":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v12, "it\\8":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v13, 0x0

    .line 174
    .local v13, "$i$a$-firstOrNull-InstallQueue$pump$1$4\\8\\247\\1":I
    invoke-virtual {v12}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v14

    invoke-virtual {v14}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v14

    sget-object v15, Lorg/lighttouch/android/QueueState;->PENDING:Lorg/lighttouch/android/QueueState;

    if-ne v14, v15, :cond_9

    move v12, v8

    goto :goto_4

    :cond_9
    move v12, v7

    .line 247
    .end local v12    # "it\\8":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v13    # "$i$a$-firstOrNull-InstallQueue$pump$1$4\\8\\247\\1":I
    :goto_4
    if-eqz v12, :cond_8

    move-object v6, v11

    goto :goto_5

    .line 248
    .end local v11    # "element\\7":Ljava/lang/Object;
    :cond_a
    nop

    .line 174
    .end local v5    # "$this$firstOrNull\\7":Ljava/lang/Iterable;
    .end local v9    # "$i$f$firstOrNull\\7\\174":I
    :goto_5
    check-cast v6, Lorg/lighttouch/android/InstallQueue$Entry;

    if-eqz v6, :cond_b

    .local v6, "entry\\9":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v5, 0x0

    .line 175
    .local v5, "$i$a$-let-InstallQueue$pump$1$5\\9\\174\\1":I
    iput-boolean v8, v1, Lorg/lighttouch/android/InstallQueue;->fetching:Z

    move-object v2, v6

    .line 176
    invoke-virtual {v6}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v7

    sget-object v12, Lorg/lighttouch/android/QueueState;->DOWNLOADING:Lorg/lighttouch/android/QueueState;

    const-string v13, "\u6b63\u5728\u4e0b\u8f7d"

    const/4 v8, 0x0

    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v14

    const/16 v18, 0x1c7

    const/16 v19, 0x0

    const-wide/16 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-static/range {v7 .. v19}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v7

    invoke-virtual {v6, v7}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    .line 177
    nop

    .line 174
    .end local v5    # "$i$a$-let-InstallQueue$pump$1$5\\9\\174\\1":I
    .end local v6    # "entry\\9":Lorg/lighttouch/android/InstallQueue$Entry;
    :cond_b
    nop

    .line 178
    nop

    .end local v0    # "$i$a$-synchronized-InstallQueue$pump$1\\1\\168\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 168
    monitor-exit v4

    .line 179
    if-nez v2, :cond_c

    if-eqz v3, :cond_d

    :cond_c
    iget-object v0, v1, Lorg/lighttouch/android/InstallQueue;->onChange:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 180
    :cond_d
    if-eqz v3, :cond_e

    move-object v0, v3

    .line 219
    .local v0, "entry\\10":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v4, 0x0

    .line 180
    .local v4, "$i$a$-let-InstallQueue$pump$2\\10\\180\\0":I
    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->spawn:Lkotlin/jvm/functions/Function2;

    const-string v6, "store-install"

    new-instance v7, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda1;

    invoke-direct {v7, v1, v0}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)V

    invoke-interface {v5, v6, v7}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 181
    .end local v0    # "entry\\10":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v4    # "$i$a$-let-InstallQueue$pump$2\\10\\180\\0":I
    :cond_e
    if-eqz v2, :cond_f

    move-object v0, v2

    .line 219
    .local v0, "entry\\11":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v4, 0x0

    .line 181
    .local v4, "$i$a$-let-InstallQueue$pump$3\\11\\181\\0":I
    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->spawn:Lkotlin/jvm/functions/Function2;

    const-string v6, "store-download"

    new-instance v7, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda2;

    invoke-direct {v7, v1, v0}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)V

    invoke-interface {v5, v6, v7}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 182
    .end local v0    # "entry\\11":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v4    # "$i$a$-let-InstallQueue$pump$3\\11\\181\\0":I
    :cond_f
    return-void

    .line 168
    :catchall_0
    move-exception v0

    monitor-exit v4

    throw v0
.end method

.method private static final pump$lambda$32$lambda$31(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/InstallQueue;
    .param p1, "$entry"    # Lorg/lighttouch/android/InstallQueue$Entry;

    .line 180
    invoke-direct {p0, p1}, Lorg/lighttouch/android/InstallQueue;->runInstall(Lorg/lighttouch/android/InstallQueue$Entry;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final pump$lambda$34$lambda$33(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/InstallQueue;
    .param p1, "$entry"    # Lorg/lighttouch/android/InstallQueue$Entry;

    .line 181
    invoke-direct {p0, p1}, Lorg/lighttouch/android/InstallQueue;->runFetch(Lorg/lighttouch/android/InstallQueue$Entry;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final reporter(Lorg/lighttouch/android/InstallQueue$Entry;)Lorg/lighttouch/android/InstallQueue$reporter$1;
    .locals 1
    .param p1, "entry"    # Lorg/lighttouch/android/InstallQueue$Entry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/InstallQueue$Entry<",
            "TP;>;)",
            "Lorg/lighttouch/android/InstallQueue$reporter$1;"
        }
    .end annotation

    .line 157
    new-instance v0, Lorg/lighttouch/android/InstallQueue$reporter$1;

    invoke-direct {v0, p0, p1}, Lorg/lighttouch/android/InstallQueue$reporter$1;-><init>(Lorg/lighttouch/android/InstallQueue;Lorg/lighttouch/android/InstallQueue$Entry;)V

    .line 162
    return-object v0
.end method

.method private final runFetch(Lorg/lighttouch/android/InstallQueue$Entry;)V
    .locals 31
    .param p1, "entry"    # Lorg/lighttouch/android/InstallQueue$Entry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/InstallQueue$Entry<",
            "TP;>;)V"
        }
    .end annotation

    .line 185
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const/4 v3, 0x0

    .line 186
    .local v3, "file":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 187
    .local v4, "failure":Ljava/lang/Object;
    :try_start_0
    iget-object v0, v1, Lorg/lighttouch/android/InstallQueue;->work:Lorg/lighttouch/android/QueueWork;

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getPayload()Ljava/lang/Object;

    move-result-object v5

    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/InstallQueue;->reporter(Lorg/lighttouch/android/InstallQueue$Entry;)Lorg/lighttouch/android/InstallQueue$reporter$1;

    move-result-object v6

    check-cast v6, Lorg/lighttouch/android/QueueReport;

    new-instance v7, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda8;

    invoke-direct {v7, v2}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/InstallQueue$Entry;)V

    invoke-interface {v0, v5, v6, v7}, Lorg/lighttouch/android/QueueWork;->fetch(Ljava/lang/Object;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)Ljava/io/File;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v3, v0

    move-object v12, v4

    goto :goto_0

    .line 188
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_0

    const-string v5, "\u4e0b\u8f7d\u5931\u8d25"

    :cond_0
    move-object v4, v5

    move-object v12, v4

    .line 189
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v4    # "failure":Ljava/lang/Object;
    .local v12, "failure":Ljava/lang/Object;
    :goto_0
    const/16 v17, 0x0

    .line 190
    .local v17, "discard":Ljava/lang/Object;
    iget-object v4, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v4

    const/4 v0, 0x0

    .line 191
    .local v0, "$i$a$-synchronized-InstallQueue$runFetch$2\\1\\190\\0":I
    const/4 v5, 0x0

    :try_start_1
    iput-boolean v5, v1, Lorg/lighttouch/android/InstallQueue;->fetching:Z

    .line 192
    nop

    .line 193
    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getCancelled()Z

    move-result v5

    if-eqz v5, :cond_1

    move-object/from16 v17, v3

    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    invoke-interface {v5, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-object/from16 v18, v4

    goto :goto_1

    .line 194
    :cond_1
    if-eqz v3, :cond_2

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/InstallQueue$Entry;->setFile(Ljava/io/File;)V

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v18

    sget-object v23, Lorg/lighttouch/android/QueueState;->READY:Lorg/lighttouch/android/QueueState;

    const-string v24, "\u7b49\u5f85\u5b89\u88c5"

    .line 195
    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/QueueItem;->getOverall()F

    move-result v5

    const v6, 0x3ecccccd    # 0.4f

    invoke-static {v5, v6}, Ljava/lang/Math;->max(FF)F

    move-result v28

    .line 194
    const/16 v29, 0xc7

    const/16 v30, 0x0

    const-wide/16 v19, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    invoke-static/range {v18 .. v30}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v5

    invoke-virtual {v2, v5}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    move-object/from16 v18, v4

    goto :goto_1

    .line 196
    :cond_2
    move-object v5, v4

    :try_start_2
    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    sget-object v9, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    const-string v10, ""
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/16 v15, 0x187

    const/16 v16, 0x0

    move-object v7, v5

    const-wide/16 v5, 0x0

    move-object v8, v7

    const/4 v7, 0x0

    move-object v11, v8

    const/4 v8, 0x0

    move-object v13, v11

    const/4 v11, 0x0

    move-object v14, v13

    const/4 v13, 0x0

    move-object/from16 v18, v14

    const/4 v14, 0x0

    :try_start_3
    invoke-static/range {v4 .. v16}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 197
    :goto_1
    nop

    .line 190
    .end local v0    # "$i$a$-synchronized-InstallQueue$runFetch$2\\1\\190\\0":I
    monitor-exit v18

    .line 199
    if-eqz v17, :cond_3

    iget-object v0, v1, Lorg/lighttouch/android/InstallQueue;->work:Lorg/lighttouch/android/QueueWork;

    move-object/from16 v4, v17

    .line 219
    .local v4, "p0\\2":Ljava/io/File;
    const/4 v5, 0x0

    .line 199
    .local v5, "$i$a$-let-InstallQueue$runFetch$3\\2\\199\\0":I
    invoke-interface {v0, v4}, Lorg/lighttouch/android/QueueWork;->discard(Ljava/io/File;)V

    .line 200
    .end local v4    # "p0\\2":Ljava/io/File;
    .end local v5    # "$i$a$-let-InstallQueue$runFetch$3\\2\\199\\0":I
    :cond_3
    invoke-direct {v1}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 201
    return-void

    .line 190
    :catchall_0
    move-exception v0

    goto :goto_2

    :catchall_1
    move-exception v0

    move-object/from16 v18, v5

    goto :goto_2

    :catchall_2
    move-exception v0

    move-object/from16 v18, v4

    :goto_2
    monitor-exit v18

    throw v0
.end method

.method private static final runFetch$lambda$35(Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 1
    .param p0, "$entry"    # Lorg/lighttouch/android/InstallQueue$Entry;

    .line 187
    invoke-virtual {p0}, Lorg/lighttouch/android/InstallQueue$Entry;->getCancelled()Z

    move-result v0

    return v0
.end method

.method private final runInstall(Lorg/lighttouch/android/InstallQueue$Entry;)V
    .locals 27
    .param p1, "entry"    # Lorg/lighttouch/android/InstallQueue$Entry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/InstallQueue$Entry<",
            "TP;>;)V"
        }
    .end annotation

    .line 204
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    iget-object v3, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v3

    .line 219
    const/4 v0, 0x0

    .line 204
    .local v0, "$i$a$-synchronized-InstallQueue$runInstall$file$1\\1\\204\\0":I
    :try_start_0
    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getFile()Ljava/io/File;

    move-result-object v4

    move-object v5, v4

    .line 219
    .local v5, "it\\2":Ljava/io/File;
    const/4 v6, 0x0

    .line 204
    .local v6, "$i$a$-also-InstallQueue$runInstall$file$1$1\\2\\204\\1":I
    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Lorg/lighttouch/android/InstallQueue$Entry;->setFile(Ljava/io/File;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .end local v0    # "$i$a$-synchronized-InstallQueue$runInstall$file$1\\1\\204\\0":I
    .end local v5    # "it\\2":Ljava/io/File;
    .end local v6    # "$i$a$-also-InstallQueue$runInstall$file$1$1\\2\\204\\1":I
    monitor-exit v3

    .line 205
    .local v4, "file":Ljava/io/File;
    const/4 v3, 0x0

    .line 206
    .local v3, "failure":Ljava/lang/Object;
    :try_start_1
    iget-object v0, v1, Lorg/lighttouch/android/InstallQueue;->work:Lorg/lighttouch/android/QueueWork;

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getPayload()Ljava/lang/Object;

    move-result-object v5

    if-eqz v4, :cond_0

    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/InstallQueue;->reporter(Lorg/lighttouch/android/InstallQueue$Entry;)Lorg/lighttouch/android/InstallQueue$reporter$1;

    move-result-object v6

    check-cast v6, Lorg/lighttouch/android/QueueReport;

    new-instance v7, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda4;

    invoke-direct {v7, v2}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/InstallQueue$Entry;)V

    invoke-interface {v0, v5, v4, v6, v7}, Lorg/lighttouch/android/QueueWork;->install(Ljava/lang/Object;Ljava/io/File;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)V

    move-object v13, v3

    goto :goto_0

    :cond_0
    const-string v0, "\u5fc5\u9700\u7684\u503c\u4e3a\u7a7a\u3002"

    new-instance v5, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v5, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v3    # "failure":Ljava/lang/Object;
    .end local v4    # "file":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/InstallQueue;
    .end local p1    # "entry":Lorg/lighttouch/android/InstallQueue$Entry;
    throw v5
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 207
    .restart local v3    # "failure":Ljava/lang/Object;
    .restart local v4    # "file":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/InstallQueue;
    .restart local p1    # "entry":Lorg/lighttouch/android/InstallQueue$Entry;
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_1

    const-string v5, "\u5b89\u88c5\u5931\u8d25"

    :cond_1
    move-object v3, v5

    move-object v13, v3

    .line 208
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v3    # "failure":Ljava/lang/Object;
    .local v13, "failure":Ljava/lang/Object;
    :goto_0
    if-eqz v4, :cond_2

    iget-object v0, v1, Lorg/lighttouch/android/InstallQueue;->work:Lorg/lighttouch/android/QueueWork;

    move-object v3, v4

    .line 219
    .local v3, "p0\\4":Ljava/io/File;
    const/4 v5, 0x0

    .line 208
    .local v5, "$i$a$-let-InstallQueue$runInstall$2\\4\\208\\0":I
    invoke-interface {v0, v3}, Lorg/lighttouch/android/QueueWork;->discard(Ljava/io/File;)V

    .line 209
    .end local v3    # "p0\\4":Ljava/io/File;
    .end local v5    # "$i$a$-let-InstallQueue$runInstall$2\\4\\208\\0":I
    :cond_2
    iget-object v3, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v3

    const/4 v0, 0x0

    .line 210
    .local v0, "$i$a$-synchronized-InstallQueue$runInstall$3\\5\\209\\0":I
    const/4 v5, 0x0

    :try_start_2
    iput-boolean v5, v1, Lorg/lighttouch/android/InstallQueue;->installing:Z

    .line 211
    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getCancelled()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/QueueItem;->getCommitted()Z

    move-result v5

    if-nez v5, :cond_3

    iget-object v5, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    invoke-interface {v5, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    goto :goto_2

    .line 212
    :cond_3
    if-nez v13, :cond_4

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v14

    sget-object v19, Lorg/lighttouch/android/QueueState;->DONE:Lorg/lighttouch/android/QueueState;

    const-string v20, "\u5df2\u5b89\u88c5\uff0c\u53ef\u5728\u4e3b\u5c4f\u5e55\u627e\u5230\u3002"

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v21

    const/16 v25, 0xc7

    const/16 v26, 0x0

    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/high16 v24, 0x3f800000    # 1.0f

    invoke-static/range {v14 .. v26}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v5

    goto :goto_1

    .line 213
    :cond_4
    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v5

    sget-object v10, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    const-string v11, ""

    const/16 v16, 0x187

    const/16 v17, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v5 .. v17}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v5

    .line 212
    :goto_1
    invoke-virtual {v2, v5}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 213
    :goto_2
    nop

    .line 209
    .end local v0    # "$i$a$-synchronized-InstallQueue$runInstall$3\\5\\209\\0":I
    monitor-exit v3

    .line 215
    invoke-direct {v1}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 216
    return-void

    .line 209
    :catchall_0
    move-exception v0

    monitor-exit v3

    throw v0

    .line 204
    .end local v4    # "file":Ljava/io/File;
    .end local v13    # "failure":Ljava/lang/Object;
    :catchall_1
    move-exception v0

    monitor-exit v3

    throw v0
.end method

.method private static final runInstall$lambda$40(Lorg/lighttouch/android/InstallQueue$Entry;)Z
    .locals 1
    .param p0, "$entry"    # Lorg/lighttouch/android/InstallQueue$Entry;

    .line 206
    invoke-virtual {p0}, Lorg/lighttouch/android/InstallQueue$Entry;->getCancelled()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getCommitted()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private final transition(Z)I
    .locals 2
    .param p1, "active"    # Z

    .line 146
    nop

    .line 147
    if-eqz p1, :cond_0

    iget-boolean v0, p0, Lorg/lighttouch/android/InstallQueue;->announced:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Lorg/lighttouch/android/InstallQueue;->announced:Z

    goto :goto_0

    .line 148
    :cond_0
    const/4 v0, 0x0

    if-nez p1, :cond_1

    iget-boolean v1, p0, Lorg/lighttouch/android/InstallQueue;->announced:Z

    if-eqz v1, :cond_1

    iput-boolean v0, p0, Lorg/lighttouch/android/InstallQueue;->announced:Z

    const/4 v0, -0x1

    goto :goto_0

    .line 149
    :cond_1
    nop

    .line 150
    :goto_0
    return v0
.end method

.method private final update(Lorg/lighttouch/android/InstallQueue$Entry;Lkotlin/jvm/functions/Function1;)V
    .locals 3
    .param p1, "entry"    # Lorg/lighttouch/android/InstallQueue$Entry;
    .param p2, "change"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/InstallQueue$Entry<",
            "TP;>;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/lighttouch/android/QueueItem;",
            "Lorg/lighttouch/android/QueueItem;",
            ">;)V"
        }
    .end annotation

    .line 153
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v0

    .line 219
    const/4 v1, 0x0

    .line 153
    .local v1, "$i$a$-synchronized-InstallQueue$update$1\\1\\153\\0":I
    :try_start_0
    invoke-virtual {p1}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v2

    invoke-interface {p2, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/QueueItem;

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    .end local v1    # "$i$a$-synchronized-InstallQueue$update$1\\1\\153\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    .line 154
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onChange:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 155
    return-void

    .line 153
    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method


# virtual methods
.method public final cancel(J)V
    .locals 23
    .param p1, "id"    # J

    .line 92
    move-object/from16 v1, p0

    const/4 v2, 0x0

    .line 93
    .local v2, "discard":Ljava/lang/Object;
    iget-object v3, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v3

    const/4 v0, 0x0

    .line 94
    .local v0, "$i$a$-synchronized-InstallQueue$cancel$1\\1\\93\\0":I
    :try_start_0
    iget-object v4, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$firstOrNull\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 230
    .local v5, "$i$f$firstOrNull\\2\\94":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\2":Ljava/lang/Object;
    move-object v10, v7

    check-cast v10, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v10, "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v11, 0x0

    .line 94
    .local v11, "$i$a$-firstOrNull-InstallQueue$cancel$1$entry$1\\3\\230\\1":I
    invoke-virtual {v10}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v12

    invoke-virtual {v12}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v12

    cmp-long v12, v12, p1

    if-nez v12, :cond_1

    move v12, v9

    goto :goto_0

    :cond_1
    const/4 v12, 0x0

    .line 230
    .end local v10    # "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v11    # "$i$a$-firstOrNull-InstallQueue$cancel$1$entry$1\\3\\230\\1":I
    :goto_0
    if-eqz v12, :cond_0

    goto :goto_1

    .line 231
    .end local v7    # "element\\2":Ljava/lang/Object;
    :cond_2
    move-object v7, v8

    .line 94
    .end local v4    # "$this$firstOrNull\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$firstOrNull\\2\\94":I
    :goto_1
    check-cast v7, Lorg/lighttouch/android/InstallQueue$Entry;

    if-nez v7, :cond_3

    goto/16 :goto_3

    .line 95
    .local v7, "entry\\1":Lorg/lighttouch/android/InstallQueue$Entry;
    :cond_3
    invoke-virtual {v7}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v4

    sget-object v5, Lorg/lighttouch/android/InstallQueue$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v4}, Lorg/lighttouch/android/QueueState;->ordinal()I

    move-result v4

    aget v4, v5, v4

    packed-switch v4, :pswitch_data_0

    goto :goto_2

    .line 99
    :pswitch_0
    invoke-virtual {v7}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/QueueItem;->getCommitted()Z

    move-result v4

    if-nez v4, :cond_4

    invoke-virtual {v7, v9}, Lorg/lighttouch/android/InstallQueue$Entry;->setCancelled(Z)V

    invoke-virtual {v7}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v10

    const-string v16, "\u6b63\u5728\u53d6\u6d88"

    const/16 v21, 0x1ef

    const/16 v22, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v10 .. v22}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    invoke-virtual {v7, v4}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    goto :goto_2

    .line 98
    :pswitch_1
    invoke-virtual {v7, v9}, Lorg/lighttouch/android/InstallQueue$Entry;->setCancelled(Z)V

    invoke-virtual {v7}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v8

    const-string v14, "\u6b63\u5728\u53d6\u6d88"

    const/16 v19, 0x1ef

    const/16 v20, 0x0

    const-wide/16 v9, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-static/range {v8 .. v20}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    invoke-virtual {v7, v4}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    goto :goto_2

    .line 97
    :pswitch_2
    invoke-virtual {v7}, Lorg/lighttouch/android/InstallQueue$Entry;->getFile()Ljava/io/File;

    move-result-object v4

    move-object v2, v4

    invoke-virtual {v7, v8}, Lorg/lighttouch/android/InstallQueue$Entry;->setFile(Ljava/io/File;)V

    iget-object v4, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    invoke-interface {v4, v7}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    goto :goto_2

    .line 96
    :pswitch_3
    iget-object v4, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    invoke-interface {v4, v7}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 102
    :cond_4
    :goto_2
    nop

    .end local v0    # "$i$a$-synchronized-InstallQueue$cancel$1\\1\\93\\0":I
    .end local v7    # "entry\\1":Lorg/lighttouch/android/InstallQueue$Entry;
    :goto_3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 93
    monitor-exit v3

    .line 103
    if-eqz v2, :cond_5

    iget-object v0, v1, Lorg/lighttouch/android/InstallQueue;->work:Lorg/lighttouch/android/QueueWork;

    move-object v3, v2

    .line 219
    .local v3, "p0\\4":Ljava/io/File;
    const/4 v4, 0x0

    .line 103
    .local v4, "$i$a$-let-InstallQueue$cancel$2\\4\\103\\0":I
    invoke-interface {v0, v3}, Lorg/lighttouch/android/QueueWork;->discard(Ljava/io/File;)V

    .line 104
    .end local v3    # "p0\\4":Ljava/io/File;
    .end local v4    # "$i$a$-let-InstallQueue$cancel$2\\4\\103\\0":I
    :cond_5
    invoke-direct {v1}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 105
    return-void

    .line 93
    :catchall_0
    move-exception v0

    monitor-exit v3

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final clearFinished()V
    .locals 4

    .line 127
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v0

    .line 219
    const/4 v1, 0x0

    .line 127
    .local v1, "$i$a$-synchronized-InstallQueue$clearFinished$1\\1\\127\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    new-instance v3, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda7;

    invoke-direct {v3}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda7;-><init>()V

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->removeAll(Ljava/util/List;Lkotlin/jvm/functions/Function1;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v1    # "$i$a$-synchronized-InstallQueue$clearFinished$1\\1\\127\\0":I
    monitor-exit v0

    .line 128
    invoke-direct {p0}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 129
    return-void

    .line 127
    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final dismiss(J)V
    .locals 4
    .param p1, "id"    # J

    .line 122
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v0

    .line 219
    const/4 v1, 0x0

    .line 122
    .local v1, "$i$a$-synchronized-InstallQueue$dismiss$1\\1\\122\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    new-instance v3, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda5;

    invoke-direct {v3, p1, p2}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda5;-><init>(J)V

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->removeAll(Ljava/util/List;Lkotlin/jvm/functions/Function1;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v1    # "$i$a$-synchronized-InstallQueue$dismiss$1\\1\\122\\0":I
    monitor-exit v0

    .line 123
    invoke-direct {p0}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 124
    return-void

    .line 122
    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final enqueue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Z
    .locals 20
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "payload"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "TP;)Z"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v5, p1

    const-string v0, "key"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    move-object/from16 v6, p2

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    iget-object v15, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v15

    const/4 v0, 0x0

    .line 81
    .local v0, "$i$a$-synchronized-InstallQueue$enqueue$accepted$1\\1\\80\\0":I
    :try_start_0
    iget-object v2, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$any\\2":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 227
    .local v3, "$i$f$any\\2\\81":I
    instance-of v4, v2, Ljava/util/Collection;

    const/16 v16, 0x1

    const/4 v7, 0x0

    if-eqz v4, :cond_0

    move-object v4, v2

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    move v2, v7

    goto :goto_1

    .line 228
    :cond_0
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\2":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v9, "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v10, 0x0

    .line 81
    .local v10, "$i$a$-any-InstallQueue$enqueue$accepted$1$1\\3\\228\\1":I
    invoke-virtual {v9}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v11

    invoke-virtual {v11}, Lorg/lighttouch/android/QueueItem;->getKey()Ljava/lang/String;

    move-result-object v11

    invoke-static {v11, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_2

    invoke-virtual {v9}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v11

    invoke-virtual {v11}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v11

    if-eqz v11, :cond_2

    move/from16 v9, v16

    goto :goto_0

    :cond_2
    move v9, v7

    .line 228
    .end local v9    # "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v10    # "$i$a$-any-InstallQueue$enqueue$accepted$1$1\\3\\228\\1":I
    :goto_0
    if-eqz v9, :cond_1

    move/from16 v2, v16

    goto :goto_1

    .line 229
    .end local v8    # "element\\2":Ljava/lang/Object;
    :cond_3
    move v2, v7

    .line 81
    .end local v2    # "$this$any\\2":Ljava/lang/Iterable;
    .end local v3    # "$i$f$any\\2\\81":I
    :goto_1
    if-eqz v2, :cond_4

    move-object/from16 v3, p3

    move/from16 v16, v7

    goto :goto_2

    .line 82
    :cond_4
    iget-object v2, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    new-instance v3, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda0;

    invoke-direct {v3, v5}, Lorg/lighttouch/android/InstallQueue$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->removeAll(Ljava/util/List;Lkotlin/jvm/functions/Function1;)Z

    .line 83
    iget-object v2, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v2, Ljava/util/Collection;

    new-instance v3, Lorg/lighttouch/android/InstallQueue$Entry;

    move-object v4, v2

    new-instance v2, Lorg/lighttouch/android/QueueItem;

    move-object v8, v3

    move-object v7, v4

    iget-wide v3, v1, Lorg/lighttouch/android/InstallQueue;->nextId:J

    const-wide/16 v9, 0x1

    add-long/2addr v9, v3

    iput-wide v9, v1, Lorg/lighttouch/android/InstallQueue;->nextId:J

    const/16 v13, 0x1f8

    const/4 v14, 0x0

    move-object v9, v7

    const/4 v7, 0x0

    move-object v10, v8

    const/4 v8, 0x0

    move-object v11, v9

    const/4 v9, 0x0

    move-object v12, v10

    const/4 v10, 0x0

    move-object/from16 v17, v11

    const/4 v11, 0x0

    move-object/from16 v18, v12

    const/4 v12, 0x0

    move/from16 v19, v0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    .end local v0    # "$i$a$-synchronized-InstallQueue$enqueue$accepted$1\\1\\80\\0":I
    .local v19, "$i$a$-synchronized-InstallQueue$enqueue$accepted$1\\1\\80\\0":I
    invoke-direct/range {v2 .. v14}, Lorg/lighttouch/android/QueueItem;-><init>(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v3, p3

    :try_start_1
    invoke-direct {v1, v2, v3}, Lorg/lighttouch/android/InstallQueue$Entry;-><init>(Lorg/lighttouch/android/QueueItem;Ljava/lang/Object;)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 84
    nop

    .line 80
    .end local v19    # "$i$a$-synchronized-InstallQueue$enqueue$accepted$1\\1\\80\\0":I
    :goto_2
    monitor-exit v15

    .line 86
    .local v16, "accepted":Z
    if-eqz v16, :cond_5

    invoke-direct/range {p0 .. p0}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 87
    :cond_5
    return v16

    .line 80
    .end local v16    # "accepted":Z
    :catchall_0
    move-exception v0

    goto :goto_3

    :catchall_1
    move-exception v0

    move-object/from16 v3, p3

    :goto_3
    monitor-exit v15

    throw v0
.end method

.method public final getActive()Z
    .locals 10

    .line 76
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v0

    .line 219
    const/4 v1, 0x0

    .line 76
    .local v1, "$i$a$-synchronized-InstallQueue$active$1\\1\\76\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$any\\2":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 224
    .local v3, "$i$f$any\\2\\76":I
    instance-of v4, v2, Ljava/util/Collection;

    const/4 v5, 0x0

    if-eqz v4, :cond_0

    move-object v4, v2

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_0

    .line 225
    :cond_0
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v7, "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v8, 0x0

    .line 76
    .local v8, "$i$a$-any-InstallQueue$active$1$1\\3\\225\\1":I
    invoke-virtual {v7}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v9

    invoke-virtual {v9}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 225
    .end local v7    # "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v8    # "$i$a$-any-InstallQueue$active$1$1\\3\\225\\1":I
    if-eqz v9, :cond_1

    const/4 v5, 0x1

    goto :goto_0

    .line 226
    .end local v6    # "element\\2":Ljava/lang/Object;
    :cond_2
    nop

    .line 76
    .end local v2    # "$this$any\\2":Ljava/lang/Iterable;
    .end local v3    # "$i$f$any\\2\\76":I
    :goto_0
    nop

    .end local v1    # "$i$a$-synchronized-InstallQueue$active$1\\1\\76\\0":I
    monitor-exit v0

    return v5

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final getOnBusy()Lkotlin/jvm/functions/Function0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 72
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onBusy:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnChange()Lkotlin/jvm/functions/Function0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 71
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onChange:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnIdle()Lkotlin/jvm/functions/Function0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 73
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->onIdle:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final retry(J)V
    .locals 23
    .param p1, "id"    # J

    .line 108
    move-object/from16 v1, p0

    iget-object v2, v1, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v2

    const/4 v0, 0x0

    .line 109
    .local v0, "$i$a$-synchronized-InstallQueue$retry$retried$1\\1\\108\\0":I
    :try_start_0
    iget-object v3, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    .local v3, "$this$indexOfFirst\\2":Ljava/util/List;
    const/4 v4, 0x0

    .line 232
    .local v4, "$i$f$indexOfFirst\\2\\109":I
    const/4 v5, 0x0

    .line 233
    .local v5, "index\\2":I
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 234
    .local v7, "item\\2":Ljava/lang/Object;
    move-object v10, v7

    check-cast v10, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v10, "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v11, 0x0

    .line 109
    .local v11, "$i$a$-indexOfFirst-InstallQueue$retry$retried$1$index$1\\3\\234\\1":I
    invoke-virtual {v10}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v12

    invoke-virtual {v12}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v12

    cmp-long v12, v12, p1

    if-nez v12, :cond_0

    invoke-virtual {v10}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v12

    invoke-virtual {v12}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v12

    sget-object v13, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    if-ne v12, v13, :cond_0

    move v10, v8

    goto :goto_1

    :cond_0
    move v10, v9

    .line 234
    .end local v10    # "it\\3":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v11    # "$i$a$-indexOfFirst-InstallQueue$retry$retried$1$index$1\\3\\234\\1":I
    :goto_1
    if-eqz v10, :cond_1

    .line 235
    goto :goto_2

    .line 236
    :cond_1
    nop

    .end local v7    # "item\\2":Ljava/lang/Object;
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 238
    :cond_2
    const/4 v6, -0x1

    move v5, v6

    .line 109
    .end local v3    # "$this$indexOfFirst\\2":Ljava/util/List;
    .end local v4    # "$i$f$indexOfFirst\\2\\109":I
    .end local v5    # "index\\2":I
    :goto_2
    nop

    .line 110
    .local v5, "index\\1":I
    if-gez v5, :cond_3

    move v8, v9

    goto :goto_3

    .line 112
    :cond_3
    iget-object v3, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    invoke-interface {v3, v5}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/lighttouch/android/InstallQueue$Entry;

    .line 113
    .local v3, "entry\\1":Lorg/lighttouch/android/InstallQueue$Entry;
    invoke-virtual {v3, v9}, Lorg/lighttouch/android/InstallQueue$Entry;->setCancelled(Z)V

    .line 114
    invoke-virtual {v3}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v10

    sget-object v15, Lorg/lighttouch/android/QueueState;->PENDING:Lorg/lighttouch/android/QueueState;

    const-string v16, "\u7b49\u5f85\u4e2d"

    const/16 v21, 0x7

    const/16 v22, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v10 .. v22}, Lorg/lighttouch/android/QueueItem;->copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;

    move-result-object v4

    invoke-virtual {v3, v4}, Lorg/lighttouch/android/InstallQueue$Entry;->setItem(Lorg/lighttouch/android/QueueItem;)V

    .line 115
    iget-object v4, v1, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 116
    nop

    .line 108
    .end local v0    # "$i$a$-synchronized-InstallQueue$retry$retried$1\\1\\108\\0":I
    .end local v3    # "entry\\1":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v5    # "index\\1":I
    :goto_3
    monitor-exit v2

    .line 118
    .local v8, "retried":Z
    if-eqz v8, :cond_4

    invoke-direct {v1}, Lorg/lighttouch/android/InstallQueue;->changed()V

    .line 119
    :cond_4
    return-void

    .line 108
    .end local v8    # "retried":Z
    :catchall_0
    move-exception v0

    monitor-exit v2

    throw v0
.end method

.method public final setOnBusy(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    iput-object p1, p0, Lorg/lighttouch/android/InstallQueue;->onBusy:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method public final setOnChange(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    iput-object p1, p0, Lorg/lighttouch/android/InstallQueue;->onChange:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method public final setOnIdle(Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 73
    iput-object p1, p0, Lorg/lighttouch/android/InstallQueue;->onIdle:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method public final snapshot()Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;"
        }
    .end annotation

    .line 75
    iget-object v0, p0, Lorg/lighttouch/android/InstallQueue;->lock:Ljava/lang/Object;

    monitor-enter v0

    .line 219
    const/4 v1, 0x0

    .line 75
    .local v1, "$i$a$-synchronized-InstallQueue$snapshot$1\\1\\75\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/InstallQueue;->entries:Ljava/util/List;

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\2":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 220
    .local v3, "$i$f$map\\2\\75":I
    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v2, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\3":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapTo\\3":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 221
    .local v6, "$i$f$mapTo\\3\\220":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_0

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 222
    .local v8, "item\\3":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/InstallQueue$Entry;

    .local v9, "it\\4":Lorg/lighttouch/android/InstallQueue$Entry;
    const/4 v10, 0x0

    .line 75
    .local v10, "$i$a$-map-InstallQueue$snapshot$1$1\\4\\222\\1":I
    invoke-virtual {v9}, Lorg/lighttouch/android/InstallQueue$Entry;->getItem()Lorg/lighttouch/android/QueueItem;

    move-result-object v11

    .line 222
    .end local v9    # "it\\4":Lorg/lighttouch/android/InstallQueue$Entry;
    .end local v10    # "$i$a$-map-InstallQueue$snapshot$1$1\\4\\222\\1":I
    invoke-interface {v4, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 223
    .end local v8    # "item\\3":Ljava/lang/Object;
    :cond_0
    nop

    .end local v4    # "destination\\3":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\3\\220":I
    check-cast v4, Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 220
    nop

    .line 75
    .end local v2    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v3    # "$i$f$map\\2\\75":I
    nop

    .end local v1    # "$i$a$-synchronized-InstallQueue$snapshot$1\\1\\75\\0":I
    monitor-exit v0

    return-object v4

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.class public final Lorg/lighttouch/android/LtIcons;
.super Ljava/lang/Object;
.source "Icons.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIcons.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Icons.kt\norg/lighttouch/android/LtIcons\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n*L\n1#1,46:1\n149#2:47\n*S KotlinDebug\n*F\n+ 1 Icons.kt\norg/lighttouch/android/LtIcons\n*L\n11#1:47\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0011\n\u0002\u0008[\u0008\u00c1\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J)\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0012\u0010\u0008\u001a\n\u0012\u0006\u0008\u0001\u0012\u00020\u00070\t\"\u00020\u0007H\u0002\u00a2\u0006\u0002\u0010\nR\u001b\u0010\u000b\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u000e\u0010\u000f\u001a\u0004\u0008\u000c\u0010\rR\u001b\u0010\u0010\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u0012\u0010\u000f\u001a\u0004\u0008\u0011\u0010\rR\u001b\u0010\u0013\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u0015\u0010\u000f\u001a\u0004\u0008\u0014\u0010\rR\u001b\u0010\u0016\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u0018\u0010\u000f\u001a\u0004\u0008\u0017\u0010\rR\u001b\u0010\u0019\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u001b\u0010\u000f\u001a\u0004\u0008\u001a\u0010\rR\u001b\u0010\u001c\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\u001e\u0010\u000f\u001a\u0004\u0008\u001d\u0010\rR\u001b\u0010\u001f\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008!\u0010\u000f\u001a\u0004\u0008 \u0010\rR\u001b\u0010\"\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008$\u0010\u000f\u001a\u0004\u0008#\u0010\rR\u001b\u0010%\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008\'\u0010\u000f\u001a\u0004\u0008&\u0010\rR\u001b\u0010(\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008*\u0010\u000f\u001a\u0004\u0008)\u0010\rR\u001b\u0010+\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008-\u0010\u000f\u001a\u0004\u0008,\u0010\rR\u001b\u0010.\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u00080\u0010\u000f\u001a\u0004\u0008/\u0010\rR\u001b\u00101\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u00083\u0010\u000f\u001a\u0004\u00082\u0010\rR\u001b\u00104\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u00086\u0010\u000f\u001a\u0004\u00085\u0010\rR\u001b\u00107\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u00089\u0010\u000f\u001a\u0004\u00088\u0010\rR\u001b\u0010:\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008<\u0010\u000f\u001a\u0004\u0008;\u0010\rR\u001b\u0010=\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008?\u0010\u000f\u001a\u0004\u0008>\u0010\rR\u001b\u0010@\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008B\u0010\u000f\u001a\u0004\u0008A\u0010\rR\u001b\u0010C\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008E\u0010\u000f\u001a\u0004\u0008D\u0010\rR\u001b\u0010F\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008H\u0010\u000f\u001a\u0004\u0008G\u0010\rR\u001b\u0010I\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008K\u0010\u000f\u001a\u0004\u0008J\u0010\rR\u001b\u0010L\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008N\u0010\u000f\u001a\u0004\u0008M\u0010\rR\u001b\u0010O\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008Q\u0010\u000f\u001a\u0004\u0008P\u0010\rR\u001b\u0010R\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008T\u0010\u000f\u001a\u0004\u0008S\u0010\rR\u001b\u0010U\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008W\u0010\u000f\u001a\u0004\u0008V\u0010\rR\u001b\u0010X\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008Z\u0010\u000f\u001a\u0004\u0008Y\u0010\rR\u001b\u0010[\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008]\u0010\u000f\u001a\u0004\u0008\\\u0010\rR\u001b\u0010^\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008`\u0010\u000f\u001a\u0004\u0008_\u0010\rR\u001b\u0010a\u001a\u00020\u00058FX\u0086\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008c\u0010\u000f\u001a\u0004\u0008b\u0010\r\u00a8\u0006d"
    }
    d2 = {
        "Lorg/lighttouch/android/LtIcons;",
        "",
        "<init>",
        "()V",
        "icon",
        "Landroidx/compose/ui/graphics/vector/ImageVector;",
        "name",
        "",
        "paths",
        "",
        "(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;",
        "Play",
        "getPlay",
        "()Landroidx/compose/ui/graphics/vector/ImageVector;",
        "Play$delegate",
        "Lkotlin/Lazy;",
        "Pause",
        "getPause",
        "Pause$delegate",
        "Stop",
        "getStop",
        "Stop$delegate",
        "Fullscreen",
        "getFullscreen",
        "Fullscreen$delegate",
        "FullscreenExit",
        "getFullscreenExit",
        "FullscreenExit$delegate",
        "Power",
        "getPower",
        "Power$delegate",
        "Mic",
        "getMic",
        "Mic$delegate",
        "Headphones",
        "getHeadphones",
        "Headphones$delegate",
        "VolumeUp",
        "getVolumeUp",
        "VolumeUp$delegate",
        "VolumeDown",
        "getVolumeDown",
        "VolumeDown$delegate",
        "Camera",
        "getCamera",
        "Camera$delegate",
        "Bag",
        "getBag",
        "Bag$delegate",
        "Timeline",
        "getTimeline",
        "Timeline$delegate",
        "Folder",
        "getFolder",
        "Folder$delegate",
        "File",
        "getFile",
        "File$delegate",
        "Chip",
        "getChip",
        "Chip$delegate",
        "Phone",
        "getPhone",
        "Phone$delegate",
        "Puzzle",
        "getPuzzle",
        "Puzzle$delegate",
        "History",
        "getHistory",
        "History$delegate",
        "Save",
        "getSave",
        "Save$delegate",
        "Speed",
        "getSpeed",
        "Speed$delegate",
        "Tilt",
        "getTilt",
        "Tilt$delegate",
        "Info",
        "getInfo",
        "Info$delegate",
        "Code",
        "getCode",
        "Code$delegate",
        "Layers",
        "getLayers",
        "Layers$delegate",
        "Vibrate",
        "getVibrate",
        "Vibrate$delegate",
        "Palette",
        "getPalette",
        "Palette$delegate",
        "Download",
        "getDownload",
        "Download$delegate",
        "Tablet",
        "getTablet",
        "Tablet$delegate",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final Bag$delegate:Lkotlin/Lazy;

.field private static final Camera$delegate:Lkotlin/Lazy;

.field private static final Chip$delegate:Lkotlin/Lazy;

.field private static final Code$delegate:Lkotlin/Lazy;

.field private static final Download$delegate:Lkotlin/Lazy;

.field private static final File$delegate:Lkotlin/Lazy;

.field private static final Folder$delegate:Lkotlin/Lazy;

.field private static final Fullscreen$delegate:Lkotlin/Lazy;

.field private static final FullscreenExit$delegate:Lkotlin/Lazy;

.field private static final Headphones$delegate:Lkotlin/Lazy;

.field private static final History$delegate:Lkotlin/Lazy;

.field public static final INSTANCE:Lorg/lighttouch/android/LtIcons;

.field private static final Info$delegate:Lkotlin/Lazy;

.field private static final Layers$delegate:Lkotlin/Lazy;

.field private static final Mic$delegate:Lkotlin/Lazy;

.field private static final Palette$delegate:Lkotlin/Lazy;

.field private static final Pause$delegate:Lkotlin/Lazy;

.field private static final Phone$delegate:Lkotlin/Lazy;

.field private static final Play$delegate:Lkotlin/Lazy;

.field private static final Power$delegate:Lkotlin/Lazy;

.field private static final Puzzle$delegate:Lkotlin/Lazy;

.field private static final Save$delegate:Lkotlin/Lazy;

.field private static final Speed$delegate:Lkotlin/Lazy;

.field private static final Stop$delegate:Lkotlin/Lazy;

.field private static final Tablet$delegate:Lkotlin/Lazy;

.field private static final Tilt$delegate:Lkotlin/Lazy;

.field private static final Timeline$delegate:Lkotlin/Lazy;

.field private static final Vibrate$delegate:Lkotlin/Lazy;

.field private static final VolumeDown$delegate:Lkotlin/Lazy;

.field private static final VolumeUp$delegate:Lkotlin/Lazy;


# direct methods
.method public static synthetic $r8$lambda$-hd9mIPw8S94GilMG4w4ckL1Eh4()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Tilt_delegate$lambda$22()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$5i3Inj1e_bIRHGqDPpLdkwZfL3w()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Headphones_delegate$lambda$8()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$8Z9aMmmCtssFkb4n5SRk6Ar_kKI()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Pause_delegate$lambda$2()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$8sGgAlWNcClw8t4xr-vCEKGdRDQ()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Save_delegate$lambda$20()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$BGjJ42rhqnZYMilCZn4A8rKUalU()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->FullscreenExit_delegate$lambda$5()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$Bzm-eZX9BNY-DFyTYaaldjz3Ejw()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Layers_delegate$lambda$25()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$CIJG8CJkOWOyYBJnmn_vgu4nvYA()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->History_delegate$lambda$19()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$E8h-axsN-pj6emu6xYkCsCuiARw()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Camera_delegate$lambda$11()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$ENVYMPsVHb_TJNOQkFKRiE-PBOI()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Stop_delegate$lambda$3()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$JIYYGNNmrFPu-J1CHOF6et0ZVSE()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Chip_delegate$lambda$16()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$MG0rEMH1UBEO8hU3eBFrhFK0FYA()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Power_delegate$lambda$6()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$ORomBV3NPoi_86OwMrKqu6CarTo()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Bag_delegate$lambda$12()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$OjsZEXCgu0-ImmeYP98JqUSYCQM()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Tablet_delegate$lambda$29()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$RYz5SCdMEi2uTc-Dy9gvkoCHDxo()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Code_delegate$lambda$24()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$SD6Ly6t7PQn47rh81tksNrDV4ks()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Fullscreen_delegate$lambda$4()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$W4THsKJefHrHPFREj4V_ltm_S_g()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Mic_delegate$lambda$7()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$XEycCfG1hoZvx0h2_HHCLwaFgaU()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->VolumeDown_delegate$lambda$10()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$XxsPkr2034Uz_FIgdc9kXXEAIpQ()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Puzzle_delegate$lambda$18()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$Yc-BBc-djTLMZ-PmpvlnEgAqU_k()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Play_delegate$lambda$1()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$cVNIm_lEpOaz49dTOjEyRyf9RPg()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Download_delegate$lambda$28()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$hWc7jsURCwiiHBiA70ElugWqEIk()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Folder_delegate$lambda$14()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$hYHD637Dj_yXMA-dH_nM84-VnU0()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Timeline_delegate$lambda$13()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$io5dBHeLaJliAJNPGgZNub93PI0()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Palette_delegate$lambda$27()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$og28Ivr_LbwfVBCr_8-MirokoJk()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->VolumeUp_delegate$lambda$9()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$qkBzmO6mNseSaLwtBIOpSH_kfI8()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Vibrate_delegate$lambda$26()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$quKeRFvfJMOpEsTfvzWSvmaIuxw()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Speed_delegate$lambda$21()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$t-jYCMU51UoDpjI9DqiCQHB7qzQ()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->File_delegate$lambda$15()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$y7GNT1uRu-lBtM8TSHrt7Rx7R9M()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Phone_delegate$lambda$17()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$z7q_d54RMN8FVrvrE2RfRLe73g0()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/LtIcons;->Info_delegate$lambda$23()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lorg/lighttouch/android/LtIcons;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons;-><init>()V

    sput-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    .line 15
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda0;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Play$delegate:Lkotlin/Lazy;

    .line 16
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda2;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda2;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Pause$delegate:Lkotlin/Lazy;

    .line 17
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda13;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda13;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Stop$delegate:Lkotlin/Lazy;

    .line 18
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda14;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda14;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Fullscreen$delegate:Lkotlin/Lazy;

    .line 19
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda15;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda15;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->FullscreenExit$delegate:Lkotlin/Lazy;

    .line 20
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda16;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda16;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Power$delegate:Lkotlin/Lazy;

    .line 21
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda17;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda17;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Mic$delegate:Lkotlin/Lazy;

    .line 23
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda18;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda18;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Headphones$delegate:Lkotlin/Lazy;

    .line 24
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda19;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda19;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->VolumeUp$delegate:Lkotlin/Lazy;

    .line 25
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda20;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda20;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->VolumeDown$delegate:Lkotlin/Lazy;

    .line 26
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda11;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda11;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Camera$delegate:Lkotlin/Lazy;

    .line 27
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda21;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda21;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Bag$delegate:Lkotlin/Lazy;

    .line 28
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda22;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda22;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Timeline$delegate:Lkotlin/Lazy;

    .line 29
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda23;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda23;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Folder$delegate:Lkotlin/Lazy;

    .line 30
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda24;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda24;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->File$delegate:Lkotlin/Lazy;

    .line 31
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda25;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda25;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Chip$delegate:Lkotlin/Lazy;

    .line 32
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda26;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda26;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Phone$delegate:Lkotlin/Lazy;

    .line 33
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda27;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda27;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Puzzle$delegate:Lkotlin/Lazy;

    .line 34
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda28;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda28;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->History$delegate:Lkotlin/Lazy;

    .line 35
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda1;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda1;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Save$delegate:Lkotlin/Lazy;

    .line 36
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda3;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda3;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Speed$delegate:Lkotlin/Lazy;

    .line 37
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda4;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda4;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Tilt$delegate:Lkotlin/Lazy;

    .line 38
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda5;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda5;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Info$delegate:Lkotlin/Lazy;

    .line 39
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda6;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda6;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Code$delegate:Lkotlin/Lazy;

    .line 40
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda7;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda7;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Layers$delegate:Lkotlin/Lazy;

    .line 41
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda8;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda8;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Vibrate$delegate:Lkotlin/Lazy;

    .line 42
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda9;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda9;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Palette$delegate:Lkotlin/Lazy;

    .line 43
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda10;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda10;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Download$delegate:Lkotlin/Lazy;

    .line 44
    new-instance v0, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda12;

    invoke-direct {v0}, Lorg/lighttouch/android/LtIcons$$ExternalSyntheticLambda12;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LtIcons;->Tablet$delegate:Lkotlin/Lazy;

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/LtIcons;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final Bag_delegate$lambda$12()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 27
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z"

    aput-object v3, v1, v2

    const-string v2, "Bag"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Camera_delegate$lambda$11()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 26
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4z"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"

    aput-object v3, v1, v2

    const-string v2, "Camera"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Chip_delegate$lambda$16()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 31
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M15 9H9v6h6V9zm-2 4h-2v-2h2v2zm8-2V9h-2V7c0-1.1-.9-2-2-2h-2V3h-2v2h-2V3H9v2H7c-1.1 0-2 .9-2 2v2H3v2h2v2H3v2h2v2c0 1.1.9 2 2 2h2v2h2v-2h2v2h2v-2h2c1.1 0 2-.9 2-2v-2h2v-2h-2v-2h2zm-4 6H7V7h10v10z"

    aput-object v3, v1, v2

    const-string v2, "\u82af\u7247"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Code_delegate$lambda$24()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 39
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"

    aput-object v3, v1, v2

    const-string v2, "Code"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Download_delegate$lambda$28()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 43
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"

    aput-object v3, v1, v2

    const-string v2, "\u4e0b\u8f7d"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final File_delegate$lambda$15()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 30
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M6 2c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6H6zm7 7V3.5L18.5 9H13z"

    aput-object v3, v1, v2

    const-string v2, "File"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Folder_delegate$lambda$14()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 29
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"

    aput-object v3, v1, v2

    const-string v2, "Folder"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final FullscreenExit_delegate$lambda$5()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 19
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"

    aput-object v3, v1, v2

    const-string v2, "FullscreenExit"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Fullscreen_delegate$lambda$4()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 18
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"

    aput-object v3, v1, v2

    const-string v2, "Fullscreen"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Headphones_delegate$lambda$8()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 23
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M12 1c-4.97 0-9 4.03-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7c0-4.97-4.03-9-9-9z"

    aput-object v3, v1, v2

    const-string v2, "Headphones"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final History_delegate$lambda$19()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 34
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"

    aput-object v3, v1, v2

    const-string v2, "History"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Info_delegate$lambda$23()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 38
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"

    aput-object v3, v1, v2

    const-string v2, "Info"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Layers_delegate$lambda$25()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 40
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M11.99 18.54l-7.37-5.73L3 14.07l9 7 9-7-1.63-1.27-7.38 5.74zM12 16l7.36-5.73L21 9l-9-7-9 7 1.63 1.27L12 16z"

    aput-object v3, v1, v2

    const-string v2, "Layers"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Mic_delegate$lambda$7()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 21
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"

    aput-object v3, v1, v2

    .line 22
    const-string v2, "M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"

    const/4 v3, 0x1

    aput-object v2, v1, v3

    .line 21
    const-string v2, "Mic"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    .line 22
    return-object v0
.end method

.method private static final Palette_delegate$lambda$27()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 42
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M12 3a9 9 0 0 0 0 18c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"

    aput-object v3, v1, v2

    const-string v2, "Palette"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Pause_delegate$lambda$2()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 16
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M6 19h4V5H6v14zm8-14v14h4V5h-4z"

    aput-object v3, v1, v2

    const-string v2, "\u6682\u505c"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Phone_delegate$lambda$17()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 32
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"

    aput-object v3, v1, v2

    const-string v2, "Phone"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Play_delegate$lambda$1()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 15
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M8 5v14l11-7z"

    aput-object v3, v1, v2

    const-string v2, "Play"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Power_delegate$lambda$6()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 20
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42C17.99 7.86 19 9.81 19 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.19 1.01-4.14 2.58-5.42L6.17 5.17C4.23 6.82 3 9.26 3 12c0 4.97 4.03 9 9 9s9-4.03 9-9c0-2.74-1.23-5.18-3.17-6.83z"

    aput-object v3, v1, v2

    const-string v2, "Power"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Puzzle_delegate$lambda$18()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 33
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"

    aput-object v3, v1, v2

    const-string v2, "Puzzle"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Save_delegate$lambda$20()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 35
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"

    aput-object v3, v1, v2

    const-string v2, "Save"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Speed_delegate$lambda$21()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 36
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44z"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "M10.59 15.41a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z"

    aput-object v3, v1, v2

    const-string v2, "Speed"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Stop_delegate$lambda$3()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 17
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M6 6h12v12H6z"

    aput-object v3, v1, v2

    const-string v2, "\u505c\u6b62"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Tablet_delegate$lambda$29()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 44
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M21 4H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h18c1.1 0 1.99-.9 1.99-2L23 6c0-1.1-.9-2-2-2zm-2 14H5V6h14v12z"

    aput-object v3, v1, v2

    const-string v2, "Tablet"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Tilt_delegate$lambda$22()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 37
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M16.48 2.52c3.27 1.55 5.61 4.72 5.97 8.48h1.5C23.44 4.84 18.29 0 12 0l-.66.03 3.81 3.81 1.33-1.32zm-6.25-.77c-.59-.59-1.54-.59-2.12 0L1.75 8.11c-.59.59-.59 1.54 0 2.12l12.02 12.02c.59.59 1.54.59 2.12 0l6.36-6.36c.59-.59.59-1.54 0-2.12L10.23 1.75zm4.6 19.44L2.81 9.17l6.36-6.36 12.02 12.02-6.36 6.36zm-7.31.29C4.25 19.94 1.91 16.76 1.55 13H.05C.56 19.16 5.71 24 12 24l.66-.03-3.81-3.81-1.33 1.32z"

    aput-object v3, v1, v2

    const-string v2, "Tilt"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Timeline_delegate$lambda$13()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 28
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M23 8c0 1.1-.9 2-2 2-.18 0-.35-.02-.51-.07l-3.56 3.55c.05.16.07.34.07.52 0 1.1-.9 2-2 2s-2-.9-2-2c0-.18.02-.36.07-.52l-2.55-2.55c-.16.05-.34.07-.52.07s-.36-.02-.52-.07l-4.55 4.56c.05.16.07.33.07.51 0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2c.18 0 .35.02.51.07l4.56-4.55C8.02 9.36 8 9.18 8 9c0-1.1.9-2 2-2s2 .9 2 2c0 .18-.02.36-.07.52l2.55 2.55c.16-.05.34-.07.52-.07s.36.02.52.07l3.55-3.56C19.02 8.35 19 8.18 19 8c0-1.1.9-2 2-2s2 .9 2 2z"

    aput-object v3, v1, v2

    const-string v2, "Timeline"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final Vibrate_delegate$lambda$26()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 41
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M0 15h2V9H0v6zm3 2h2V7H3v10zm19-8v6h2V9h-2zm-3 8h2V7h-2v10zM16.5 3h-9C6.67 3 6 3.67 6 4.5v15c0 .83.67 1.5 1.5 1.5h9c.83 0 1.5-.67 1.5-1.5v-15c0-.83-.67-1.5-1.5-1.5zM16 19H8V5h8v14z"

    aput-object v3, v1, v2

    const-string v2, "Vibrate"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final VolumeDown_delegate$lambda$10()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 25
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M18.5 12c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM5 9v6h4l5 5V4L9 9H5z"

    aput-object v3, v1, v2

    const-string v2, "VolumeDown"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private static final VolumeUp_delegate$lambda$9()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 4

    .line 24
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"

    aput-object v3, v1, v2

    const-string v2, "VolumeUp"

    invoke-direct {v0, v2, v1}, Lorg/lighttouch/android/LtIcons;->icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    return-object v0
.end method

.method private final varargs icon(Ljava/lang/String;[Ljava/lang/String;)Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 23
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "paths"    # [Ljava/lang/String;

    .line 11
    move-object/from16 v0, p2

    new-instance v1, Landroidx/compose/ui/graphics/vector/ImageVector$Builder;

    const/16 v2, 0x18

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 47
    .local v3, "$i$f$getDp\\1\\11":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 11
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\11":I
    const/16 v2, 0x18

    .local v2, "$this$dp\\2":I
    const/4 v4, 0x0

    .line 47
    .local v4, "$i$f$getDp\\2\\11":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 11
    .end local v2    # "$this$dp\\2":I
    .end local v4    # "$i$f$getDp\\2\\11":I
    const/16 v11, 0xe0

    const/4 v12, 0x0

    const/high16 v5, 0x41c00000    # 24.0f

    const/high16 v6, 0x41c00000    # 24.0f

    const-wide/16 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object/from16 v2, p1

    invoke-direct/range {v1 .. v12}, Landroidx/compose/ui/graphics/vector/ImageVector$Builder;-><init>(Ljava/lang/String;FFFFJIZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v2, v1

    .local v2, "$this$icon_u24lambda_u240\\3":Landroidx/compose/ui/graphics/vector/ImageVector$Builder;
    const/16 v19, 0x0

    .line 12
    .local v19, "$i$a$-apply-LtIcons$icon$1\\3\\11\\0":I
    array-length v3, v0

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_0

    aget-object v20, v0, v4

    move v5, v3

    .local v20, "path\\3":Ljava/lang/String;
    invoke-static/range {v20 .. v20}, Landroidx/compose/ui/graphics/vector/VectorKt;->addPathNodes(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    new-instance v6, Landroidx/compose/ui/graphics/SolidColor;

    sget-object v7, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v7

    const/4 v9, 0x0

    invoke-direct {v6, v7, v8, v9}, Landroidx/compose/ui/graphics/SolidColor;-><init>(JLkotlin/jvm/internal/DefaultConstructorMarker;)V

    check-cast v6, Landroidx/compose/ui/graphics/Brush;

    const/16 v17, 0x3ff6

    const/16 v18, 0x0

    move v7, v4

    const/4 v4, 0x0

    move v8, v5

    const/4 v5, 0x0

    move v9, v7

    const/4 v7, 0x0

    move v10, v8

    const/4 v8, 0x0

    move v11, v9

    const/4 v9, 0x0

    move v12, v10

    const/4 v10, 0x0

    move v13, v11

    const/4 v11, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    const/4 v14, 0x0

    move/from16 v21, v15

    const/4 v15, 0x0

    move/from16 v22, v16

    const/16 v16, 0x0

    invoke-static/range {v2 .. v18}, Landroidx/compose/ui/graphics/vector/ImageVector$Builder;->addPath-oIyEayM$default(Landroidx/compose/ui/graphics/vector/ImageVector$Builder;Ljava/util/List;ILjava/lang/String;Landroidx/compose/ui/graphics/Brush;FLandroidx/compose/ui/graphics/Brush;FFIIFFFFILjava/lang/Object;)Landroidx/compose/ui/graphics/vector/ImageVector$Builder;

    .end local v20    # "path\\3":Ljava/lang/String;
    add-int/lit8 v4, v21, 0x1

    move/from16 v3, v22

    goto :goto_0

    .line 13
    :cond_0
    nop

    .line 11
    .end local v2    # "$this$icon_u24lambda_u240\\3":Landroidx/compose/ui/graphics/vector/ImageVector$Builder;
    .end local v19    # "$i$a$-apply-LtIcons$icon$1\\3\\11\\0":I
    nop

    .line 13
    invoke-virtual {v1}, Landroidx/compose/ui/graphics/vector/ImageVector$Builder;->build()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    return-object v1
.end method


# virtual methods
.method public final getBag()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 27
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Bag$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getCamera()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 26
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Camera$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getChip()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 31
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Chip$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getCode()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 39
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Code$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getDownload()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 43
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Download$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getFile()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 30
    sget-object v0, Lorg/lighttouch/android/LtIcons;->File$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getFolder()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 29
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Folder$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getFullscreen()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 18
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Fullscreen$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getFullscreenExit()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 19
    sget-object v0, Lorg/lighttouch/android/LtIcons;->FullscreenExit$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getHeadphones()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 23
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Headphones$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getHistory()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 34
    sget-object v0, Lorg/lighttouch/android/LtIcons;->History$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getInfo()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 38
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Info$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getLayers()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 40
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Layers$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getMic()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 21
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Mic$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getPalette()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 42
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Palette$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getPause()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 16
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Pause$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getPhone()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 32
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Phone$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getPlay()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 15
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Play$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getPower()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 20
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Power$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getPuzzle()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 33
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Puzzle$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getSave()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 35
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Save$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getSpeed()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 36
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Speed$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getStop()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 17
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Stop$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getTablet()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 44
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Tablet$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getTilt()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 37
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Tilt$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getTimeline()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 28
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Timeline$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getVibrate()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 41
    sget-object v0, Lorg/lighttouch/android/LtIcons;->Vibrate$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getVolumeDown()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 25
    sget-object v0, Lorg/lighttouch/android/LtIcons;->VolumeDown$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.method public final getVolumeUp()Landroidx/compose/ui/graphics/vector/ImageVector;
    .locals 1

    .line 24
    sget-object v0, Lorg/lighttouch/android/LtIcons;->VolumeUp$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/vector/ImageVector;

    return-object v0
.end method

.class public final enum Lorg/lighttouch/android/Support;
.super Ljava/lang/Enum;
.source "FirmwareCatalog.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lorg/lighttouch/android/Support;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0008\u0080\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0019\u0008\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0005\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\u0008R\u0011\u0010\u000e\u001a\u00020\u000f8F\u00a2\u0006\u0006\u001a\u0004\u0008\u0010\u0010\u0011j\u0002\u0008\nj\u0002\u0008\u000bj\u0002\u0008\u000cj\u0002\u0008\r\u00a8\u0006\u0012"
    }
    d2 = {
        "Lorg/lighttouch/android/Support;",
        "",
        "label",
        "",
        "detail",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V",
        "getLabel",
        "()Ljava/lang/String;",
        "getDetail",
        "TESTED",
        "TESTED_SLOW",
        "EXPERIMENTAL",
        "UNTESTED",
        "tested",
        "",
        "getTested",
        "()Z",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lorg/lighttouch/android/Support;

.field public static final enum EXPERIMENTAL:Lorg/lighttouch/android/Support;

.field public static final enum TESTED:Lorg/lighttouch/android/Support;

.field public static final enum TESTED_SLOW:Lorg/lighttouch/android/Support;

.field public static final enum UNTESTED:Lorg/lighttouch/android/Support;


# instance fields
.field private final detail:Ljava/lang/String;

.field private final label:Ljava/lang/String;


# direct methods
.method private static final synthetic $values()[Lorg/lighttouch/android/Support;
    .locals 4

    sget-object v0, Lorg/lighttouch/android/Support;->TESTED:Lorg/lighttouch/android/Support;

    sget-object v1, Lorg/lighttouch/android/Support;->TESTED_SLOW:Lorg/lighttouch/android/Support;

    sget-object v2, Lorg/lighttouch/android/Support;->EXPERIMENTAL:Lorg/lighttouch/android/Support;

    sget-object v3, Lorg/lighttouch/android/Support;->UNTESTED:Lorg/lighttouch/android/Support;

    filled-new-array {v0, v1, v2, v3}, [Lorg/lighttouch/android/Support;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 5

    .line 35
    new-instance v0, Lorg/lighttouch/android/Support;

    const-string v1, "\u5df2\u6d4b\u8bd5"

    const-string v2, "\u5df2\u5728 LightTouch for Android \u4e0a\u9a8c\u8bc1\u3002"

    const-string v3, "TESTED"

    const/4 v4, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/Support;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/Support;->TESTED:Lorg/lighttouch/android/Support;

    .line 36
    new-instance v0, Lorg/lighttouch/android/Support;

    const-string v1, "\u5df2\u6d4b\u8bd5\uff0c\u8f83\u6162"

    const-string v2, "\u5df2\u5728 LightTouch for Android \u4e0a\u9a8c\u8bc1\uff0c\u4f46\u6bd4 iPod touch 2G + iOS 3.1.3 \u6162\u3002"

    const-string v3, "TESTED_SLOW"

    const/4 v4, 0x1

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/Support;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/Support;->TESTED_SLOW:Lorg/lighttouch/android/Support;

    .line 37
    new-instance v0, Lorg/lighttouch/android/Support;

    const-string v1, "\u5b9e\u9a8c\u6027"

    const-string v2, "\u5df2\u901a\u8fc7 Light Touch for Mac \u7684\u542f\u52a8\u68c0\u67e5\uff0c\u4f46\u5c1a\u672a\u5728 LightTouch for Android \u4e0a\u9a8c\u8bc1\u3002"

    const-string v3, "EXPERIMENTAL"

    const/4 v4, 0x2

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/Support;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/Support;->EXPERIMENTAL:Lorg/lighttouch/android/Support;

    .line 38
    new-instance v0, Lorg/lighttouch/android/Support;

    const-string v1, "\u672a\u6d4b\u8bd5"

    const-string v2, "\u5c1a\u65e0\u4eba\u5c1d\u8bd5\uff0c\u53ef\u80fd\u65e0\u6cd5\u542f\u52a8\u3002"

    const-string v3, "UNTESTED"

    const/4 v4, 0x3

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/Support;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/Support;->UNTESTED:Lorg/lighttouch/android/Support;

    invoke-static {}, Lorg/lighttouch/android/Support;->$values()[Lorg/lighttouch/android/Support;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/Support;->$VALUES:[Lorg/lighttouch/android/Support;

    sget-object v0, Lorg/lighttouch/android/Support;->$VALUES:[Lorg/lighttouch/android/Support;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/Support;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .param p3, "label"    # Ljava/lang/String;
    .param p4, "detail"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 34
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lorg/lighttouch/android/Support;->label:Ljava/lang/String;

    iput-object p4, p0, Lorg/lighttouch/android/Support;->detail:Ljava/lang/String;

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lorg/lighttouch/android/Support;",
            ">;"
        }
    .end annotation

    sget-object v0, Lorg/lighttouch/android/Support;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 41
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lorg/lighttouch/android/Support;
    .locals 1
    .param p0, "value"    # Ljava/lang/String;

    const-class v0, Lorg/lighttouch/android/Support;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    .line 41
    check-cast v0, Lorg/lighttouch/android/Support;

    return-object v0
.end method

.method public static values()[Lorg/lighttouch/android/Support;
    .locals 1

    sget-object v0, Lorg/lighttouch/android/Support;->$VALUES:[Lorg/lighttouch/android/Support;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    .line 41
    check-cast v0, [Lorg/lighttouch/android/Support;

    return-object v0
.end method


# virtual methods
.method public final getDetail()Ljava/lang/String;
    .locals 1

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/Support;->detail:Ljava/lang/String;

    return-object v0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 1

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/Support;->label:Ljava/lang/String;

    return-object v0
.end method

.method public final getTested()Z
    .locals 1

    .line 40
    sget-object v0, Lorg/lighttouch/android/Support;->TESTED:Lorg/lighttouch/android/Support;

    if-eq p0, v0, :cond_1

    sget-object v0, Lorg/lighttouch/android/Support;->TESTED_SLOW:Lorg/lighttouch/android/Support;

    if-ne p0, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

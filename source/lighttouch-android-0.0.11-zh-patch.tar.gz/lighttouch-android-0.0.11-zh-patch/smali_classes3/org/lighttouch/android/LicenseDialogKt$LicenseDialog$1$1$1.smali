.class final Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "LicenseDialog.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Ljava/util/List<",
        "+",
        "Lorg/lighttouch/android/NoticeGroup;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLicenseDialog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LicenseDialog.kt\norg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,85:1\n11228#2:86\n11563#2,2:87\n11565#2:94\n1#3:89\n1563#4:90\n1634#4,3:91\n*S KotlinDebug\n*F\n+ 1 LicenseDialog.kt\norg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1\n*L\n34#1:86\n34#1:87,2\n34#1:94\n39#1:90\n39#1:91,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0008\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0003H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lorg/lighttouch/android/NoticeGroup;",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "org.lighttouch.android.LicenseDialogKt$LicenseDialog$1$1$1"
    f = "LicenseDialog.kt"
    i = {}
    l = {}
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $context:Landroid/content/Context;

.field label:I


# direct methods
.method constructor <init>(Landroid/content/Context;Lkotlin/coroutines/Continuation;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->$context:Landroid/content/Context;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;

    iget-object v1, p0, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->$context:Landroid/content/Context;

    invoke-direct {v0, v1, p2}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;-><init>(Landroid/content/Context;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/NoticeGroup;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    move-object/from16 v1, p0

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 33
    iget v0, v1, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->label:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_0
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object/from16 v2, p1

    .line 34
    .local v2, "$result":Ljava/lang/Object;
    iget-object v0, v1, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->$context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v3, "licenses"

    invoke-virtual {v0, v3}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    new-array v0, v3, [Ljava/lang/String;

    :cond_0
    iget-object v4, v1, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;->$context:Landroid/content/Context;

    .local v0, "$this$map\\1":[Ljava/lang/Object;
    const/4 v5, 0x0

    .line 86
    .local v5, "$i$f$map\\1\\34":I
    new-instance v6, Ljava/util/ArrayList;

    array-length v7, v0

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v6, Ljava/util/Collection;

    .local v0, "$this$mapTo\\2":[Ljava/lang/Object;
    .local v6, "destination\\2":Ljava/util/Collection;
    const/4 v7, 0x0

    .line 87
    .local v7, "$i$f$mapTo\\2\\86":I
    array-length v8, v0

    move v9, v3

    :goto_0
    if-ge v9, v8, :cond_9

    aget-object v10, v0, v9

    .line 88
    .local v10, "item\\2":Ljava/lang/Object;
    nop

    .local v10, "folder\\3":Ljava/lang/String;
    const/4 v11, 0x0

    .line 35
    .local v11, "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1\\3\\88\\0":I
    invoke-static {v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v10}, Lorg/lighttouch/android/LicenseDialogKt;->checkedNoticePath(Ljava/lang/String;)Z

    move-result v12

    const/4 v13, 0x0

    if-eqz v12, :cond_1

    move-object v12, v10

    check-cast v12, Ljava/lang/CharSequence;

    const/16 v15, 0x2f

    const/4 v14, 0x2

    invoke-static {v12, v15, v3, v14, v13}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_1

    const/4 v12, 0x1

    goto :goto_1

    :cond_1
    move v12, v3

    :goto_1
    const-string v14, "\u65ad\u8a00\u5931\u8d25\u3002"

    if-eqz v12, :cond_8

    .line 36
    invoke-virtual {v4}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v12

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "licenses/"

    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v15, "/manifest.json"

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v12, v3}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v3

    const-string v12, "open(...)"

    invoke-static {v3, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v12, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v15, Ljava/io/InputStreamReader;

    invoke-direct {v15, v3, v12}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v15, Ljava/io/Reader;

    instance-of v3, v15, Ljava/io/BufferedReader;

    if-eqz v3, :cond_2

    check-cast v15, Ljava/io/BufferedReader;

    goto :goto_2

    :cond_2
    new-instance v3, Ljava/io/BufferedReader;

    const/16 v12, 0x2000

    invoke-direct {v3, v15, v12}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v15, v3

    :goto_2
    check-cast v15, Ljava/io/Closeable;

    :try_start_0
    move-object v3, v15

    check-cast v3, Ljava/io/BufferedReader;

    .line 89
    .local v3, "it\\4":Ljava/io/BufferedReader;
    const/4 v12, 0x0

    .line 36
    .local v12, "$i$a$-use-LicenseDialogKt$LicenseDialog$1$1$1$1$manifest$1\\4\\36\\3":I
    move-object/from16 v17, v3

    check-cast v17, Ljava/io/Reader;

    invoke-static/range {v17 .. v17}, Lkotlin/io/TextStreamsKt;->readText(Ljava/io/Reader;)Ljava/lang/String;

    move-result-object v13
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    .end local v3    # "it\\4":Ljava/io/BufferedReader;
    .end local v12    # "$i$a$-use-LicenseDialogKt$LicenseDialog$1$1$1$1$manifest$1\\4\\36\\3":I
    invoke-static {v15, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v13}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 37
    .local v3, "manifest\\3":Lorg/json/JSONObject;
    const-string v12, "schema"

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v12

    const/4 v13, 0x1

    if-ne v12, v13, :cond_3

    goto :goto_3

    :cond_3
    const/4 v13, 0x0

    :goto_3
    if-eqz v13, :cond_7

    .line 38
    const-string v12, "files"

    invoke-virtual {v3, v12}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v12

    .line 39
    .local v12, "files\\3":Lorg/json/JSONArray;
    invoke-virtual {v12}, Lorg/json/JSONArray;->length()I

    move-result v13

    const/4 v15, 0x0

    invoke-static {v15, v13}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v13

    check-cast v13, Ljava/lang/Iterable;

    .end local v10    # "folder\\3":Ljava/lang/String;
    .local v13, "$this$map\\5":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 90
    .local v16, "$i$f$map\\5\\39":I
    new-instance v15, Ljava/util/ArrayList;

    move-object/from16 p1, v0

    .end local v0    # "$this$mapTo\\2":[Ljava/lang/Object;
    .local p1, "$this$mapTo\\2":[Ljava/lang/Object;
    const/16 v0, 0xa

    invoke-static {v13, v0}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v0

    invoke-direct {v15, v0}, Ljava/util/ArrayList;-><init>(I)V

    move-object v0, v15

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination\\6":Ljava/util/Collection;
    .local v13, "$this$mapTo\\6":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 91
    .local v15, "$i$f$mapTo\\6\\90":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    .end local v13    # "$this$mapTo\\6":Ljava/lang/Iterable;
    :goto_4
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_6

    move-object/from16 v13, v18

    check-cast v13, Lkotlin/collections/IntIterator;

    invoke-virtual {v13}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v13

    .line 92
    .local v13, "item\\6":I
    move/from16 v19, v13

    .local v19, "index\\7":I
    const/16 v20, 0x0

    .line 40
    .local v20, "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1$1\\7\\92\\3":I
    move/from16 v1, v19

    move-object/from16 v19, v2

    .end local v2    # "$result":Ljava/lang/Object;
    .local v1, "index\\7":I
    .local v19, "$result":Ljava/lang/Object;
    invoke-virtual {v12, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    .line 41
    .local v2, "entry\\7":Lorg/json/JSONObject;
    move/from16 v21, v1

    .end local v1    # "index\\7":I
    .local v21, "index\\7":I
    const-string v1, "path"

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v22, v4

    .local v1, "path\\7":Ljava/lang/String;
    const-string v4, "sha256"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 42
    .local v4, "hash\\7":Ljava/lang/String;
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v1}, Lorg/lighttouch/android/LicenseDialogKt;->checkedNoticePath(Ljava/lang/String;)Z

    move-result v23

    if-eqz v23, :cond_5

    .line 43
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v23, v2

    .end local v2    # "entry\\7":Lorg/json/JSONObject;
    .local v23, "entry\\7":Lorg/json/JSONObject;
    move-object v2, v4

    check-cast v2, Ljava/lang/CharSequence;

    move/from16 v24, v5

    .end local v5    # "$i$f$map\\1\\34":I
    .local v24, "$i$f$map\\1\\34":I
    new-instance v5, Lkotlin/text/Regex;

    move/from16 v25, v7

    .end local v7    # "$i$f$mapTo\\2\\86":I
    .local v25, "$i$f$mapTo\\2\\86":I
    const-string v7, "[0-9a-f]{64}"

    invoke-direct {v5, v7}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v2}, Lkotlin/text/Regex;->matches(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 44
    invoke-static {v1, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    .line 92
    .end local v1    # "path\\7":Ljava/lang/String;
    .end local v4    # "hash\\7":Ljava/lang/String;
    .end local v20    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1$1\\7\\92\\3":I
    .end local v21    # "index\\7":I
    .end local v23    # "entry\\7":Lorg/json/JSONObject;
    invoke-interface {v0, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p0

    move-object/from16 v2, v19

    move-object/from16 v4, v22

    move/from16 v5, v24

    move/from16 v7, v25

    goto :goto_4

    .line 43
    .restart local v1    # "path\\7":Ljava/lang/String;
    .restart local v4    # "hash\\7":Ljava/lang/String;
    .restart local v20    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1$1\\7\\92\\3":I
    .restart local v21    # "index\\7":I
    .restart local v23    # "entry\\7":Lorg/json/JSONObject;
    :cond_4
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 42
    .end local v23    # "entry\\7":Lorg/json/JSONObject;
    .end local v24    # "$i$f$map\\1\\34":I
    .end local v25    # "$i$f$mapTo\\2\\86":I
    .restart local v2    # "entry\\7":Lorg/json/JSONObject;
    .restart local v5    # "$i$f$map\\1\\34":I
    .restart local v7    # "$i$f$mapTo\\2\\86":I
    :cond_5
    move-object/from16 v23, v2

    move/from16 v24, v5

    .end local v2    # "entry\\7":Lorg/json/JSONObject;
    .end local v5    # "$i$f$map\\1\\34":I
    .restart local v23    # "entry\\7":Lorg/json/JSONObject;
    .restart local v24    # "$i$f$map\\1\\34":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 93
    .end local v1    # "path\\7":Ljava/lang/String;
    .end local v4    # "hash\\7":Ljava/lang/String;
    .end local v13    # "item\\6":I
    .end local v19    # "$result":Ljava/lang/Object;
    .end local v20    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1$1\\7\\92\\3":I
    .end local v21    # "index\\7":I
    .end local v23    # "entry\\7":Lorg/json/JSONObject;
    .end local v24    # "$i$f$map\\1\\34":I
    .local v2, "$result":Ljava/lang/Object;
    .restart local v5    # "$i$f$map\\1\\34":I
    :cond_6
    move-object/from16 v19, v2

    move-object/from16 v22, v4

    move/from16 v24, v5

    move/from16 v25, v7

    .end local v0    # "destination\\6":Ljava/util/Collection;
    .end local v2    # "$result":Ljava/lang/Object;
    .end local v5    # "$i$f$map\\1\\34":I
    .end local v7    # "$i$f$mapTo\\2\\86":I
    .end local v15    # "$i$f$mapTo\\6\\90":I
    .restart local v19    # "$result":Ljava/lang/Object;
    .restart local v24    # "$i$f$map\\1\\34":I
    .restart local v25    # "$i$f$mapTo\\2\\86":I
    check-cast v0, Ljava/util/List;

    .line 90
    nop

    .line 45
    .end local v16    # "$i$f$map\\5\\39":I
    const-string v1, "source_reference"

    invoke-virtual {v3, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "getString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    new-instance v2, Lorg/lighttouch/android/NoticeGroup;

    invoke-direct {v2, v10, v0, v1}, Lorg/lighttouch/android/NoticeGroup;-><init>(Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 45
    nop

    .line 88
    .end local v3    # "manifest\\3":Lorg/json/JSONObject;
    .end local v11    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1\\3\\88\\0":I
    .end local v12    # "files\\3":Lorg/json/JSONArray;
    invoke-interface {v6, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 87
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, v19

    const/4 v3, 0x0

    goto/16 :goto_0

    .line 37
    .end local v19    # "$result":Ljava/lang/Object;
    .end local v24    # "$i$f$map\\1\\34":I
    .end local v25    # "$i$f$mapTo\\2\\86":I
    .end local p1    # "$this$mapTo\\2":[Ljava/lang/Object;
    .local v0, "$this$mapTo\\2":[Ljava/lang/Object;
    .restart local v2    # "$result":Ljava/lang/Object;
    .restart local v3    # "manifest\\3":Lorg/json/JSONObject;
    .restart local v5    # "$i$f$map\\1\\34":I
    .restart local v7    # "$i$f$mapTo\\2\\86":I
    .restart local v10    # "folder\\3":Ljava/lang/String;
    .restart local v11    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1\\3\\88\\0":I
    :cond_7
    move-object/from16 p1, v0

    .end local v0    # "$this$mapTo\\2":[Ljava/lang/Object;
    .restart local p1    # "$this$mapTo\\2":[Ljava/lang/Object;
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 36
    .end local v3    # "manifest\\3":Lorg/json/JSONObject;
    .end local v6    # "destination\\2":Ljava/util/Collection;
    .end local v10    # "folder\\3":Ljava/lang/String;
    .end local p1    # "$this$mapTo\\2":[Ljava/lang/Object;
    :catchall_0
    move-exception v0

    move-object/from16 v19, v2

    move/from16 v24, v5

    move/from16 v25, v7

    move-object v1, v0

    .end local v2    # "$result":Ljava/lang/Object;
    .end local v5    # "$i$f$map\\1\\34":I
    .end local v7    # "$i$f$mapTo\\2\\86":I
    .end local v11    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1\\3\\88\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local v11    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1\\3\\88\\0":I
    .restart local v19    # "$result":Ljava/lang/Object;
    .restart local v24    # "$i$f$map\\1\\34":I
    .restart local v25    # "$i$f$mapTo\\2\\86":I
    .restart local p0    # "this":Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1$1;
    :catchall_1
    move-exception v0

    invoke-static {v15, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 35
    .end local v19    # "$result":Ljava/lang/Object;
    .end local v24    # "$i$f$map\\1\\34":I
    .end local v25    # "$i$f$mapTo\\2\\86":I
    .restart local v0    # "$this$mapTo\\2":[Ljava/lang/Object;
    .restart local v2    # "$result":Ljava/lang/Object;
    .restart local v5    # "$i$f$map\\1\\34":I
    .restart local v6    # "destination\\2":Ljava/util/Collection;
    .restart local v7    # "$i$f$mapTo\\2\\86":I
    .restart local v10    # "folder\\3":Ljava/lang/String;
    :cond_8
    move-object/from16 p1, v0

    .end local v0    # "$this$mapTo\\2":[Ljava/lang/Object;
    .restart local p1    # "$this$mapTo\\2":[Ljava/lang/Object;
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v14}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 94
    .end local v10    # "folder\\3":Ljava/lang/String;
    .end local v11    # "$i$a$-map-LicenseDialogKt$LicenseDialog$1$1$1$1\\3\\88\\0":I
    .end local p1    # "$this$mapTo\\2":[Ljava/lang/Object;
    .restart local v0    # "$this$mapTo\\2":[Ljava/lang/Object;
    :cond_9
    move-object/from16 p1, v0

    .end local v0    # "$this$mapTo\\2":[Ljava/lang/Object;
    .end local v6    # "destination\\2":Ljava/util/Collection;
    .end local v7    # "$i$f$mapTo\\2\\86":I
    move-object v0, v6

    check-cast v0, Ljava/util/List;

    .line 86
    nop

    .line 46
    .end local v5    # "$i$f$map\\1\\34":I
    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

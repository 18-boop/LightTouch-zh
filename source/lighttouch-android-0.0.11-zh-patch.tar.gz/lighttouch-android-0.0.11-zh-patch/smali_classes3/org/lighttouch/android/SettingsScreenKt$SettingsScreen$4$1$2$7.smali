.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n1225#2,6:209\n1225#2,6:215\n1225#2,6:222\n1225#2,6:228\n1#3:221\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7\n*L\n88#1:197,6\n89#1:203,6\n90#1:209,6\n91#1:215,6\n94#1:222,6\n96#1:228,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $onBack:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method public static synthetic $r8$lambda$CUIyYBFX2lqHlDvTYX-a-6rG4R8(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke$lambda$12$lambda$11(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KDqhWLrduYlK9I-fs98VOQyP5pw(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke$lambda$5$lambda$4(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$OTE_hm-fZ_fctLfxtt0FbiZwpZ8(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$depO6EzMZvmhA3-emBSZfaayj1U(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke$lambda$7$lambda$6(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pBRzroZ6xlZ0COrGD_SUjBhBvP8(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke$lambda$1$lambda$0(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vLUXWwelVzipPIWcKR9vLE74w1Y(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke$lambda$10$lambda$9(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/AppSettings;",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    iput-object p3, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$onBack:Lkotlin/jvm/functions/Function0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Z

    .line 88
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setHitchButton(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$10$lambda$9(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 94
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->toggleProfile()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$12$lambda$11(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "$onBack"    # Lkotlin/jvm/functions/Function0;

    .line 96
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->recover()V

    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p2, "it"    # Z

    .line 89
    invoke-virtual {p0, p2}, Lorg/lighttouch/android/AppSettings;->setDetailedTiming(Z)V

    invoke-interface {p1}, Lorg/lighttouch/android/GuestHost;->applySettings()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "it"    # Z

    .line 90
    invoke-interface {p0, p1}, Lorg/lighttouch/android/GuestHost;->usePresentAsync(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$7$lambda$6(Lorg/lighttouch/android/GuestHost;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "it"    # Z

    .line 91
    invoke-interface {p0, p1}, Lorg/lighttouch/android/GuestHost;->useFaithfulScaler(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 87
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 18
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v8, p2

    move/from16 v11, p3

    const-string v1, "$this$Group"

    move-object/from16 v12, p1

    invoke-static {v12, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C87@7391L22,87@7220L193,88@7657L47,88@7434L270,89@8018L28,89@7725L321,90@8440L30,90@8067L403,95@9219L28,94@8998L249:SettingsScreen.kt#o13vsk"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v11, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 95
    :cond_0
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_12

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:87)"

    const v3, 0x70ef8bf

    invoke-static {v3, v11, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 88
    :cond_2
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getTimeline()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getHitchButton()Z

    move-result v4

    const v13, 0x4c5de2

    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v14, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\1":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 197
    .local v6, "$i$f$cache\\1\\88":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\1":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 198
    .local v9, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    if-nez v2, :cond_4

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_3

    goto :goto_1

    .line 202
    :cond_3
    move-object v15, v7

    goto :goto_2

    .line 199
    :cond_4
    :goto_1
    const/4 v10, 0x0

    .line 88
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$1\\3\\199\\0":I
    new-instance v15, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda0;

    invoke-direct {v15, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 199
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$1\\3\\199\\0":I
    nop

    .line 200
    .local v15, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .line 198
    .end local v15    # "value\\2":Ljava/lang/Object;
    :goto_2
    nop

    .line 197
    .end local v7    # "it\\1":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 88
    .end local v2    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\1\\88":I
    move-object v7, v15

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x61b0

    const/16 v10, 0x20

    const-string v2, "\u68c0\u67e5\u6309\u94ae"

    const-string v3, "\u8be5\u6309\u94ae\u4f1a\u6682\u505c iOS \u5e76\u6253\u5f00\u5e27\u68c0\u67e5\u5668\uff0c\u7528\u4e8e\u5256\u6790\u521a\u51fa\u73b0\u7684\u5361\u987f"

    const-string v5, "hitch_toggle"

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 89
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getChip()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getDetailedTiming()Z

    move-result v4

    const v15, -0x615d173a

    invoke-interface {v8, v15}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\4":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v6, p2

    .local v6, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 203
    .local v7, "$i$f$cache\\4\\89":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\4":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 204
    .local v10, "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    if-nez v2, :cond_6

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v9, v15, :cond_5

    goto :goto_3

    .line 208
    :cond_5
    move-object v13, v9

    goto :goto_4

    .line 205
    :cond_6
    :goto_3
    const/4 v15, 0x0

    .line 89
    .local v15, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$2\\6\\205\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda1;

    invoke-direct {v13, v3, v5}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V

    .line 205
    .end local v15    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$2\\6\\205\\0":I
    nop

    .line 206
    .local v13, "value\\5":Ljava/lang/Object;
    invoke-interface {v6, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 204
    .end local v13    # "value\\5":Ljava/lang/Object;
    :goto_4
    nop

    .line 203
    .end local v9    # "it\\4":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    nop

    .line 89
    .end local v2    # "invalid\\4":Z
    .end local v6    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\4\\89":I
    move-object v7, v13

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x61b0

    const/16 v10, 0x20

    const-string v2, "\u8be6\u7ec6\u5e27\u8ba1\u65f6"

    const-string v3, "\u8bb0\u5f55\u6bcf\u5e27\u7684\u5ba2\u6237\u673a CPU\u3001GL \u4e0e\u9501\u7b49\u5f85\u65f6\u95f4\uff0c\u4fbf\u4e8e\u6d6e\u5c42\u548c\u68c0\u67e5\u5668\u89e3\u91ca\u6162\u5e27\u6210\u56e0\u3002\u5f00\u542f\u65f6\u7ea6\u635f\u5931 6% \u7684\u901f\u5ea6\u3002"

    const-string v5, "detailed_timing"

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 90
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getSpeed()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getPresentAsync()Z

    move-result v4

    const v2, 0x4c5de2

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\7":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 209
    .local v6, "$i$f$cache\\7\\90":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\7":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 210
    .local v9, "$i$a$-let-ComposerKt$cache$1\\8\\209\\7":I
    if-nez v2, :cond_8

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_7

    goto :goto_5

    .line 214
    :cond_7
    move-object v13, v7

    goto :goto_6

    .line 211
    :cond_8
    :goto_5
    const/4 v10, 0x0

    .line 90
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$3\\9\\211\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda2;

    invoke-direct {v13, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 211
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$3\\9\\211\\0":I
    nop

    .line 212
    .local v13, "value\\8":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    nop

    .line 210
    .end local v13    # "value\\8":Ljava/lang/Object;
    :goto_6
    nop

    .line 209
    .end local v7    # "it\\7":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\8\\209\\7":I
    nop

    .line 90
    .end local v2    # "invalid\\7":Z
    .end local v5    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\7\\90":I
    move-object v7, v13

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x61b0

    const/16 v10, 0x20

    const-string v2, "\u5728\u5de5\u4f5c\u7ebf\u7a0b\u5448\u73b0"

    const-string v3, "\u628a\u5e27\u590d\u5236\u5230\u5ba2\u6237\u673a\u8868\u9762\u653e\u5230\u5de5\u4f5c\u7ebf\u7a0b\u6267\u884c\u3002\u5173\u95ed\u5219\u6539\u4e3a\u5728 CPU \u4e0a\u590d\u5236\uff0c\u5f53\u5ba2\u6237\u673a\u672c\u6765\u5c31\u6709\u5927\u534a\u5e27\u5728\u7b49\u5f85\u65f6\u66f4\u7a33\u5b9a\u3002\u4e0b\u6b21\u542f\u52a8\u5ba2\u6237\u673a\u65f6\u751f\u6548\u3002"

    const-string v5, "present_async"

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 91
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getTimeline()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getFaithfulScaler()Z

    move-result v4

    const v2, 0x4c5de2

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\10":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 215
    .local v6, "$i$f$cache\\10\\91":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\10":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 216
    .local v9, "$i$a$-let-ComposerKt$cache$1\\11\\215\\10":I
    if-nez v2, :cond_a

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_9

    goto :goto_7

    .line 220
    :cond_9
    move-object v13, v7

    goto :goto_8

    .line 217
    :cond_a
    :goto_7
    const/4 v10, 0x0

    .line 91
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$4\\12\\217\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda3;

    invoke-direct {v13, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 217
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$4\\12\\217\\0":I
    nop

    .line 218
    .local v13, "value\\11":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 219
    nop

    .line 216
    .end local v13    # "value\\11":Ljava/lang/Object;
    :goto_8
    nop

    .line 215
    .end local v7    # "it\\10":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\11\\215\\10":I
    nop

    .line 91
    .end local v2    # "invalid\\10":Z
    .end local v5    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\10\\91":I
    move-object v7, v13

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x61b0

    const/16 v10, 0x20

    const-string v2, "\u7cbe\u786e\u7f29\u653e\u65f6\u5e8f"

    const-string v3, "\u5e27\u5757\u6309\u4f20\u8f93\u7684\u5b8c\u6574\u786c\u4ef6\u8017\u65f6\u5efa\u6a21\uff08\u6574\u5c4f\u7ea6 3 \u6beb\u79d2\uff09\uff0c\u5ba2\u6237\u673a\u4f1a\u6309\u6a21\u62df\u65f6\u95f4\u7b49\u5f85\u3002\u5173\u95ed\u5219\u50cf\u7d20\u5199\u5b8c\u5373\u7ed3\u675f\u4f20\u8f93\uff0c\u76f8\u5f53\u4e8e\u4ece\u663e\u793a\u7ba1\u7ebf\u5c55\u793a\u7684\u6bcf\u4e00\u5e27\u4e2d\u53bb\u6389\u8fd9\u6bb5\u8017\u65f6\u3002\u4e0b\u6b21\u542f\u52a8\u5ba2\u6237\u673a\u65f6\u751f\u6548\u3002"

    const-string v5, "faithful_scaler"

    const/4 v6, 0x0

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    const v1, 0x7f34685a

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "93@8910L24,91@8514L420"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 92
    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getDetailedTiming()Z

    move-result v1

    if-nez v1, :cond_13

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getSave()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getProfileRecording()Z

    move-result v2

    if-eqz v2, :cond_b

    const-string v2, "\u505c\u6b62\u6027\u80fd\u8bb0\u5f55"

    goto :goto_9

    :cond_b
    const-string v2, "\u8bb0\u5f55\u6027\u80fd\u6570\u636e"

    .line 93
    :goto_9
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v3}, Lorg/lighttouch/android/GuestHost;->getProfileRecording()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_e

    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v3}, Lorg/lighttouch/android/GuestHost;->getProfileNotice()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-nez v5, :cond_c

    const/4 v5, 0x1

    goto :goto_a

    :cond_c
    move v5, v4

    :goto_a
    if-eqz v5, :cond_d

    .line 221
    const/4 v3, 0x0

    .line 93
    .local v3, "$i$a$-ifEmpty-SettingsScreenKt$SettingsScreen$4$1$2$7$5\\13\\93\\0":I
    nop

    .end local v3    # "$i$a$-ifEmpty-SettingsScreenKt$SettingsScreen$4$1$2$7$5\\13\\93\\0":I
    const-string v3, "\u8bb0\u5f55\u4e2d\u2026"

    :cond_d
    check-cast v3, Ljava/lang/String;

    goto :goto_b

    :cond_e
    const-string v3, "\u6355\u83b7\u5c4f\u5e55\u4e0a\u5e94\u7528\u7684\u5f15\u64ce\u65f6\u5e8f\uff0c\u4f9b tools/perf/profile.py \u4f7f\u7528"

    .line 94
    :goto_b
    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v5}, Lorg/lighttouch/android/GuestHost;->getProfileBusy()Z

    move-result v5

    if-nez v5, :cond_10

    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-static {v5}, Lorg/lighttouch/android/ShellKt;->getRunning(Lorg/lighttouch/android/GuestHost;)Z

    move-result v5

    if-nez v5, :cond_f

    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v5}, Lorg/lighttouch/android/GuestHost;->getProfileRecording()Z

    move-result v5

    if-eqz v5, :cond_10

    :cond_f
    const/4 v4, 0x1

    :cond_10
    const v5, 0x4c5de2

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    .local v5, "invalid\\14":Z
    iget-object v6, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v7, p2

    .local v7, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 222
    .local v9, "$i$f$cache\\14\\94":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\14":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 223
    .local v15, "$i$a$-let-ComposerKt$cache$1\\15\\222\\14":I
    if-nez v5, :cond_12

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    const/16 v17, 0x1

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v13, v10, :cond_11

    goto :goto_c

    .line 227
    :cond_11
    move-object/from16 v16, v1

    move-object v1, v13

    goto :goto_d

    .line 223
    :cond_12
    const/16 v17, 0x1

    .line 224
    :goto_c
    const/4 v10, 0x0

    .line 94
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$6\\16\\224\\0":I
    move-object/from16 v16, v1

    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda4;

    invoke-direct {v1, v6}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 224
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$6\\16\\224\\0":I
    nop

    .line 225
    .local v1, "value\\15":Ljava/lang/Object;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 226
    nop

    .line 223
    .end local v1    # "value\\15":Ljava/lang/Object;
    :goto_d
    nop

    .line 222
    .end local v13    # "it\\14":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\15\\222\\14":I
    nop

    .line 94
    .end local v5    # "invalid\\14":Z
    .end local v7    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\14\\94":I
    move-object v6, v1

    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 92
    const-string v5, "profile_capture"

    const/16 v8, 0x6000

    const/4 v9, 0x0

    move-object/from16 v7, p2

    move-object/from16 v1, v16

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    move-object v8, v7

    goto :goto_e

    :cond_13
    const/16 v17, 0x1

    :goto_e
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 95
    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v1

    if-eqz v1, :cond_17

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-static {v1}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v1

    if-nez v1, :cond_17

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getHistory()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    .line 96
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v2

    if-eqz v2, :cond_14

    invoke-virtual {v2}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v2

    goto :goto_f

    :cond_14
    const/4 v2, 0x0

    :goto_f
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u542f\u52a8 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " from its saved data after an unclean shutdown, keeping diagnostics"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getBusy()Z

    move-result v2

    xor-int/lit8 v4, v2, 0x1

    const v2, -0x615d173a

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$onBack:Lkotlin/jvm/functions/Function0;

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v2, v5

    .local v2, "invalid\\17":Z
    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$host:Lorg/lighttouch/android/GuestHost;

    iget-object v6, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;->$onBack:Lkotlin/jvm/functions/Function0;

    move-object/from16 v7, p2

    .local v7, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 228
    .local v9, "$i$f$cache\\17\\96":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\17":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 229
    .local v13, "$i$a$-let-ComposerKt$cache$1\\18\\228\\17":I
    if-nez v2, :cond_16

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v10, v14, :cond_15

    goto :goto_10

    .line 233
    :cond_15
    move-object v15, v10

    goto :goto_11

    .line 230
    :cond_16
    :goto_10
    const/4 v14, 0x0

    .line 96
    .local v14, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$7\\19\\230\\0":I
    new-instance v15, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda5;

    invoke-direct {v15, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V

    .line 230
    .end local v14    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$7$7\\19\\230\\0":I
    nop

    .line 231
    .local v15, "value\\18":Ljava/lang/Object;
    invoke-interface {v7, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 232
    nop

    .line 229
    .end local v15    # "value\\18":Ljava/lang/Object;
    :goto_11
    nop

    .line 228
    .end local v10    # "it\\17":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\18\\228\\17":I
    nop

    .line 96
    .end local v2    # "invalid\\17":Z
    .end local v7    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\17\\96":I
    move-object v6, v15

    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 95
    const-string v2, "\u6062\u590d\u4fdd\u7559\u7684\u72b6\u6001"

    const-string v5, "recover_guest"

    const/16 v8, 0x6030

    const/4 v9, 0x0

    move-object/from16 v7, p2

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    :cond_17
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 97
    :cond_18
    :goto_12
    return-void
.end method

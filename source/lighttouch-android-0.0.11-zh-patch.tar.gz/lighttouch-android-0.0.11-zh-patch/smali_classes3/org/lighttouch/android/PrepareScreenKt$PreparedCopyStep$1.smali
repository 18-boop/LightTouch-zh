.class final Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;
.super Ljava/lang/Object;
.source "PrepareScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/PrepareScreenKt;->PreparedCopyStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPrepareScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,416:1\n149#2:417\n149#2:418\n99#3:419\n95#3,7:420\n102#3:455\n106#3:465\n79#4,6:427\n86#4,4:442\n90#4,2:452\n94#4:464\n368#5,9:433\n377#5:454\n378#5,2:462\n4034#6,6:446\n1225#7,6:456\n*S KotlinDebug\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1\n*L\n245#1:417\n247#1:418\n247#1:419\n247#1:420,7\n247#1:455\n247#1:465\n247#1:427,6\n247#1:442,4\n247#1:452,2\n247#1:464\n247#1:433,9\n247#1:454\n247#1:462,2\n247#1:446,6\n249#1:456,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $busy:Z

.field final synthetic $context:Landroid/content/Context;

.field final synthetic $firmware:Lorg/lighttouch/android/CatalogFirmware;

.field final synthetic $onChoosePrepared:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$2g6Vl38ClI59_wULfk1jlxXO0Rs(Landroid/content/Context;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->invoke$lambda$2$lambda$1$lambda$0(Landroid/content/Context;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/CatalogFirmware;ZLkotlin/jvm/functions/Function0;Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/CatalogFirmware;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$firmware:Lorg/lighttouch/android/CatalogFirmware;

    iput-boolean p2, p0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$busy:Z

    iput-object p3, p0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$onChoosePrepared:Lkotlin/jvm/functions/Function0;

    iput-object p4, p0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$context:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$2$lambda$1$lambda$0(Landroid/content/Context;)Lkotlin/Unit;
    .locals 3
    .param p0, "$context"    # Landroid/content/Context;

    .line 249
    new-instance v0, Landroid/content/Intent;

    .line 250
    const-string v1, "https://github.com/blake-lucas/LightTouch/blob/main/docs/ASSETS.md#5-prepare-a-system-from-an-ipsw-instead"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 249
    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 250
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 242
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 47
    .param p1, "$this$Card"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$Card"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C243@14702L10,243@14746L11,242@14509L266,245@14927L10,244@14784L234,246@15027L502:PrepareScreen.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 465
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_6

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.PreparedCopyStep.<anonymous> (PrepareScreen.kt:242)"

    const v6, 0x17351a8c

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 244
    :cond_2
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v1, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v1, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v5

    .line 243
    nop

    .line 244
    nop

    .line 243
    const/4 v2, 0x0

    move-wide v3, v5

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x6

    const/16 v24, 0x0

    const v25, 0xfffa

    const-string v1, "\u5728 Mac \u4e0a\uff0c\u7528 Light Touch for Mac \u7684 firmwarekit \u5de5\u5177\u51c6\u5907\u597d\u5e76\u6253\u5305\u6210 .itbase \u6587\u4ef6\u5939\u3002\u628a\u8be5\u6587\u4ef6\u5939\u590d\u5236\u5230\u624b\u673a\uff0c\u7136\u540e\u5728\u6b64\u9009\u62e9\uff1a"

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 245
    move-object/from16 v1, v22

    iget-object v2, v0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$firmware:Lorg/lighttouch/android/CatalogFirmware;

    invoke-virtual {v2}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "firmwarekit create --id "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u2026\nfirmwarekit pack-base \u2026"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 417
    .local v5, "$i$f$getDp\\1\\245":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 245
    .end local v4    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\245":I
    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v3, v7, v4, v6, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 246
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v1, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v5

    sget-object v4, Landroidx/compose/ui/text/font/FontFamily;->Companion:Landroidx/compose/ui/text/font/FontFamily$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/text/font/FontFamily$Companion;->getMonospace()Landroidx/compose/ui/text/font/GenericFontFamily;

    move-result-object v4

    move-object v13, v4

    check-cast v13, Landroidx/compose/ui/text/font/FontFamily;

    const v35, 0xffffdf

    const/16 v36, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v14, 0x0

    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const-wide/16 v20, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    invoke-static/range {v5 .. v36}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/graphics/drawscope/DrawStyle;IIJLandroidx/compose/ui/text/style/TextIndent;Landroidx/compose/ui/text/PlatformTextStyle;Landroidx/compose/ui/text/style/LineHeightStyle;IILandroidx/compose/ui/text/style/TextMotion;ILjava/lang/Object;)Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    .line 245
    move-object v1, v2

    move-object v2, v3

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x30

    const/16 v24, 0x0

    const v25, 0xfffc

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 247
    move-object/from16 v1, v22

    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v3, 0x8

    .local v3, "$this$dp\\2":I
    const/4 v4, 0x0

    .line 418
    .local v4, "$i$f$getDp\\2\\247":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 247
    .end local v3    # "$this$dp\\2":I
    .end local v4    # "$i$f$getDp\\2\\247":I
    invoke-virtual {v2, v3}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v2, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-boolean v3, v0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$busy:Z

    iget-object v4, v0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$onChoosePrepared:Lkotlin/jvm/functions/Function0;

    iget-object v5, v0, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;->$context:Landroid/content/Context;

    const/16 v17, 0x30

    .local v17, "$changed\\3":I
    const/16 v18, 0x0

    .line 419
    .local v18, "$i$f$Row\\3\\247":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v1, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 420
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 422
    .local v6, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 425
    .local v7, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v8, v17, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v9, v17, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v8, v9

    invoke-static {v2, v7, v1, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v17, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 426
    move/from16 v19, v9

    .local v19, "$changed\\4":I
    const/16 v20, 0x0

    .line 427
    .local v20, "$i$f$Layout\\4\\426":I
    const v9, -0x4ee9b9da

    const-string v10, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 428
    const/4 v9, 0x0

    invoke-static {v1, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v21

    .line 429
    .local v21, "compositeKeyHash\\4":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 430
    .local v9, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 432
    .local v10, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v11

    shl-int/lit8 v12, v19, 0x6

    and-int/lit16 v12, v12, 0x380

    or-int/lit8 v12, v12, 0x6

    .line 431
    move/from16 v22, v12

    .local v11, "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v22, "$changed\\5":I
    const/16 v23, 0x0

    .line 433
    .local v23, "$i$f$ReusableComposeNode\\5\\431":I
    const v12, -0x2942ffcf

    const-string v13, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 434
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v12

    instance-of v12, v12, Landroidx/compose/runtime/Applier;

    if-nez v12, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 435
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 436
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-eqz v12, :cond_4

    .line 437
    invoke-interface {v1, v11}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 439
    :cond_4
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 441
    :goto_1
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .local v12, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 442
    .local v13, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\441\\4":I
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v12, v8, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 443
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v12, v9, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 445
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    .local v14, "block\\7":Lkotlin/jvm/functions/Function2;
    const/4 v15, 0x0

    .line 446
    .local v15, "$i$f$set-impl\\7\\445":I
    move-object/from16 v16, v12

    .local v16, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 447
    .local v24, "$i$a$-with-Updater$set$1\\8\\446\\7":I
    invoke-interface/range {v16 .. v16}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_6

    invoke-interface/range {v16 .. v16}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v1, v16

    goto :goto_3

    .line 448
    :cond_6
    :goto_2
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, v16

    .end local v16    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v1, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 449
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v12, v0, v14}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 451
    :goto_3
    nop

    .line 446
    .end local v1    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\8\\446\\7":I
    nop

    .line 451
    nop

    .line 452
    .end local v14    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v15    # "$i$f$set-impl\\7\\445":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v12, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 453
    nop

    .line 441
    .end local v12    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\441\\4":I
    nop

    .line 454
    shr-int/lit8 v0, v22, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object/from16 v1, p2

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 455
    .local v24, "$i$a$-Layout-RowKt$Row$1\\9\\454\\3":I
    const v12, -0x184f2606

    const-string v13, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v12, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v13, v17, 0x6

    and-int/lit8 v13, v13, 0x70

    or-int/lit8 v25, v13, 0x6

    .local v25, "$changed\\10":I
    check-cast v12, Landroidx/compose/foundation/layout/RowScope;

    .local v12, "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object v14, v1

    .local v14, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v39, v12

    .end local v12    # "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v39, "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v40, 0x0

    .line 248
    .local v40, "$i$a$-Row-PrepareScreenKt$PreparedCopyStep$1$1\\10\\455\\0":I
    const v12, 0x25411f6d

    const-string v13, "C247@15097L137,248@15268L234,248@15247L272:PrepareScreen.kt#o13vsk"

    invoke-static {v14, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    xor-int/lit8 v3, v3, 0x1

    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    const-string v13, "prepare_choose_prepared"

    invoke-static {v12, v13}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    sget-object v13, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v13}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$827884512$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v13

    const v15, 0x30000030

    const/16 v16, 0x1f8

    move-object/from16 v26, v7

    .end local v7    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v26, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const/4 v7, 0x0

    move-object/from16 v27, v8

    .end local v8    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v27, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v8, 0x0

    move-object/from16 v28, v9

    .end local v9    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v28, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v9, 0x0

    move-object/from16 v29, v10

    .end local v10    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v29, "materialized\\4":Landroidx/compose/ui/Modifier;
    const/4 v10, 0x0

    move-object/from16 v30, v11

    .end local v11    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v30, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/4 v11, 0x0

    move-object/from16 v31, v5

    move-object v5, v12

    const/4 v12, 0x0

    move-object/from16 v41, v6

    move-object/from16 v42, v26

    move-object/from16 v43, v27

    move-object/from16 v44, v28

    move-object/from16 v45, v29

    move-object/from16 v46, v30

    move v6, v3

    move-object/from16 v3, v31

    .end local v6    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v26    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v27    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v28    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v29    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v30    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v41, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v42, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v43, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v44, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v45, "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v46, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v4 .. v16}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    const v4, 0x4c5de2

    invoke-interface {v14, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "CC(remember):PrepareScreen.kt#9igjgp"

    invoke-static {v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v14, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    .line 249
    move-object v5, v14

    .local v4, "invalid\\11":Z
    .local v5, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 456
    .local v6, "$i$f$cache\\11\\249":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\11":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 457
    .local v8, "$i$a$-let-ComposerKt$cache$1\\12\\456\\11":I
    if-nez v4, :cond_8

    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v7, v9, :cond_7

    goto :goto_4

    .line 461
    :cond_7
    move-object v10, v7

    goto :goto_5

    .line 458
    :cond_8
    :goto_4
    const/4 v9, 0x0

    .line 249
    .local v9, "$i$a$-cache-PrepareScreenKt$PreparedCopyStep$1$1$1\\13\\458\\10":I
    new-instance v10, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1$$ExternalSyntheticLambda0;

    invoke-direct {v10, v3}, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1$$ExternalSyntheticLambda0;-><init>(Landroid/content/Context;)V

    .line 458
    .end local v9    # "$i$a$-cache-PrepareScreenKt$PreparedCopyStep$1$1$1\\13\\458\\10":I
    nop

    .line 459
    .local v10, "value\\12":Ljava/lang/Object;
    invoke-interface {v5, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 460
    nop

    .line 457
    .end local v10    # "value\\12":Ljava/lang/Object;
    :goto_5
    nop

    .line 456
    .end local v7    # "it\\11":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\12\\456\\11":I
    nop

    .line 249
    .end local v4    # "invalid\\11":Z
    .end local v5    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\11\\249":I
    move-object/from16 v26, v10

    check-cast v26, Lkotlin/jvm/functions/Function0;

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v3}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-322404051$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v35

    const/high16 v37, 0x30000000

    const/16 v38, 0x1fe

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    move-object/from16 v36, v14

    .end local v14    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v36, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v26 .. v38}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 248
    .end local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v14    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 251
    nop

    .line 455
    .end local v14    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v25    # "$changed\\10":I
    .end local v39    # "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v40    # "$i$a$-Row-PrepareScreenKt$PreparedCopyStep$1$1\\10\\455\\0":I
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 454
    .end local v0    # "$changed\\9":I
    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Layout-RowKt$Row$1\\9\\454\\3":I
    nop

    .line 462
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 433
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 463
    nop

    .line 427
    .end local v22    # "$changed\\5":I
    .end local v23    # "$i$f$ReusableComposeNode\\5\\431":I
    .end local v46    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 464
    nop

    .line 419
    .end local v19    # "$changed\\4":I
    .end local v20    # "$i$f$Layout\\4\\426":I
    .end local v21    # "compositeKeyHash\\4":I
    .end local v44    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v45    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 465
    nop

    .end local v2    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v17    # "$changed\\3":I
    .end local v18    # "$i$f$Row\\3\\247":I
    .end local v41    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v42    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v43    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 252
    :cond_9
    :goto_6
    return-void
.end method

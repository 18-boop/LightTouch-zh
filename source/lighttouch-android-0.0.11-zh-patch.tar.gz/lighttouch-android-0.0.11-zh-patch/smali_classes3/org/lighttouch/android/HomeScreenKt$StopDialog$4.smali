.class final Lorg/lighttouch/android/HomeScreenKt$StopDialog$4;
.super Ljava/lang/Object;
.source "HomeScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/HomeScreenKt;->StopDialog(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHomeScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt$StopDialog$4\n+ 2 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 3 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 4 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 5 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,192:1\n86#2:193\n82#2,7:194\n89#2:229\n93#2:233\n79#3,6:201\n86#3,4:216\n90#3,2:226\n94#3:232\n368#4,9:207\n377#4:228\n378#4,2:230\n4034#5,6:220\n*S KotlinDebug\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt$StopDialog$4\n*L\n172#1:193\n172#1:194,7\n172#1:229\n172#1:233\n172#1:201,6\n172#1:216,4\n172#1:226,2\n172#1:232\n172#1:207,9\n172#1:228\n172#1:230,2\n172#1:220,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;


# direct methods
.method constructor <init>(Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/HomeScreenKt$StopDialog$4;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;

    .line 171
    move-object v0, p1

    check-cast v0, Landroidx/compose/runtime/Composer;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$StopDialog$4;->invoke(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/runtime/Composer;I)V
    .locals 49
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C171@10772L367:HomeScreen.kt#o13vsk"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-ne v2, v3, :cond_1

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    .line 233
    :cond_0
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_5

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.StopDialog.<anonymous> (HomeScreen.kt:171)"

    const v4, -0x7eef5d6

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 172
    :cond_2
    move-object/from16 v2, p0

    iget-object v3, v2, Lorg/lighttouch/android/HomeScreenKt$StopDialog$4;->$host:Lorg/lighttouch/android/GuestHost;

    const/4 v4, 0x0

    .local v4, "$changed\\1":I
    const/4 v5, 0x0

    .line 193
    .local v5, "$i$f$Column\\1\\172":I
    const v6, -0x1cd0f17e

    const-string v7, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v0, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 194
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 195
    .local v6, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 196
    .local v7, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 199
    .local v8, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v9, v4, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v7, v8, v0, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 200
    nop

    .local v10, "$changed\\2":I
    const/4 v11, 0x0

    .line 201
    .local v11, "$i$f$Layout\\2\\200":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v0, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 202
    const/4 v12, 0x0

    invoke-static {v0, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v12

    .line 203
    .local v12, "compositeKeyHash\\2":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 204
    .local v13, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v0, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 206
    .local v14, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v1, v10, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 205
    nop

    .local v1, "$changed\\3":I
    .local v15, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 207
    .local v16, "$i$f$ReusableComposeNode\\3\\205":I
    move/from16 v17, v1

    .end local v1    # "$changed\\3":I
    .local v17, "$changed\\3":I
    const v1, -0x2942ffcf

    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 208
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 209
    :cond_3
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 210
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_4

    .line 211
    invoke-interface {v0, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 213
    :cond_4
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 215
    :goto_1
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 216
    .local v2, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 217
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 219
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 220
    .local v18, "$i$f$set-impl\\5\\219":I
    move-object/from16 v19, v1

    .local v19, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 221
    .local v20, "$i$a$-with-Updater$set$1\\6\\220\\5":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v21

    if-nez v21, :cond_6

    move/from16 v21, v2

    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v22, v3

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v3, v19

    goto :goto_3

    .end local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    .restart local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    :cond_6
    move/from16 v21, v2

    move-object/from16 v22, v3

    .line 222
    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    .restart local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    :goto_2
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v19

    .end local v19    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 223
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 225
    :goto_3
    nop

    .line 220
    .end local v3    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-with-Updater$set$1\\6\\220\\5":I
    nop

    .line 225
    nop

    .line 226
    .end local v0    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\5\\219":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 227
    nop

    .line 215
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\215\\2":I
    nop

    .line 228
    shr-int/lit8 v0, v17, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object/from16 v1, p1

    .local v1, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 229
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\7\\228\\1":I
    const v3, -0x16ef5699

    move/from16 v18, v0

    .end local v0    # "$changed\\7":I
    .local v18, "$changed\\7":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v4, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\8":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$invoke_u24lambda_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v44, v1

    .local v44, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 173
    .local v19, "$i$a$-Column-HomeScreenKt$StopDialog$4$1\\8\\229\\0":I
    move-object/from16 v20, v0

    .end local v0    # "$this$invoke_u24lambda_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v20, "$this$invoke_u24lambda_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x6c8beb87

    move-object/from16 v21, v1

    .end local v1    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v1, "C174@11103L10,172@10797L328:HomeScreen.kt#o13vsk"

    move/from16 v48, v2

    move-object/from16 v2, v44

    .end local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v48, "$i$a$-Layout-ColumnKt$Column$1\\7\\228\\1":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface/range {v22 .. v22}, Lorg/lighttouch/android/GuestHost;->getCanSaveState()Z

    move-result v0

    if-eqz v0, :cond_7

    const-string v0, "\u300c\u4fdd\u5b58\u5e76\u505c\u6b62\u300d\u4f1a\u4fdd\u7559\u5f53\u524d\u6240\u6709\u72b6\u6001\uff08\u5305\u62ec\u5df2\u6253\u5f00\u7684\u5e94\u7528\uff09\uff0c\u4e0b\u6b21\u4ece\u65ad\u70b9\u7ee7\u7eed\u3002"

    move-object/from16 v23, v0

    goto :goto_4

    .line 174
    :cond_7
    const-string v0, "\u7b49\u540c\u4e8e\u957f\u6309\u7535\u6e90\u952e\u5173\u673a\uff1a\u5e94\u7528\u5173\u95ed\u3001\u8bbe\u5907\u65ad\u7535\u5173\u95ed\uff0c\u5e94\u7528\u548c\u6570\u636e\u90fd\u4f1a\u4fdd\u7559\u3002"

    move-object/from16 v23, v0

    :goto_4
    nop

    .line 175
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v43

    .line 173
    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const-wide/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const v47, 0xfffe

    move-object/from16 v44, v2

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v47}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 176
    nop

    .line 229
    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v3    # "$changed\\8":I
    .end local v19    # "$i$a$-Column-HomeScreenKt$StopDialog$4$1\\8\\229\\0":I
    .end local v20    # "$this$invoke_u24lambda_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 228
    .end local v18    # "$changed\\7":I
    .end local v21    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v48    # "$i$a$-Layout-ColumnKt$Column$1\\7\\228\\1":I
    nop

    .line 230
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 207
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 231
    nop

    .line 201
    .end local v15    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v16    # "$i$f$ReusableComposeNode\\3\\205":I
    .end local v17    # "$changed\\3":I
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 232
    nop

    .line 193
    .end local v10    # "$changed\\2":I
    .end local v11    # "$i$f$Layout\\2\\200":I
    .end local v12    # "compositeKeyHash\\2":I
    .end local v13    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 233
    nop

    .end local v4    # "$changed\\1":I
    .end local v5    # "$i$f$Column\\1\\172":I
    .end local v6    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v7    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v8    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v9    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 177
    :cond_8
    :goto_5
    return-void
.end method

.class final Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;
.super Ljava/lang/Object;
.source "DevicesSheet.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDevicesSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DevicesSheet.kt\norg/lighttouch/android/DevicesSheetKt$DevicesSheet$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 8 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 9 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 10 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt\n*L\n1#1,141:1\n149#2:142\n149#2:179\n149#2:180\n149#2:181\n149#2:188\n149#2:195\n149#2:232\n149#2:272\n86#3:143\n83#3,6:144\n89#3:178\n86#3:273\n82#3,7:274\n89#3:309\n93#3:313\n93#3:321\n79#4,6:150\n86#4,4:165\n90#4,2:175\n79#4,6:203\n86#4,4:218\n90#4,2:228\n79#4,6:239\n86#4,4:254\n90#4,2:264\n94#4:270\n79#4,6:281\n86#4,4:296\n90#4,2:306\n94#4:312\n94#4:316\n94#4:320\n368#5,9:156\n377#5:177\n368#5,9:209\n377#5:230\n368#5,9:245\n377#5:266\n378#5,2:268\n368#5,9:287\n377#5:308\n378#5,2:310\n378#5,2:314\n378#5,2:318\n4034#6,6:169\n4034#6,6:222\n4034#6,6:258\n4034#6,6:300\n1225#7,6:182\n1225#7,6:189\n99#8:196\n96#8,6:197\n102#8:231\n106#8:317\n71#9:233\n69#9,5:234\n74#9:267\n78#9:271\n143#10,12:322\n*S KotlinDebug\n*F\n+ 1 DevicesSheet.kt\norg/lighttouch/android/DevicesSheetKt$DevicesSheet$1\n*L\n46#1:142\n47#1:179\n50#1:180\n51#1:181\n60#1:188\n61#1:195\n63#1:232\n66#1:272\n46#1:143\n46#1:144,6\n46#1:178\n67#1:273\n67#1:274,7\n67#1:309\n67#1:313\n46#1:321\n46#1:150,6\n46#1:165,4\n46#1:175,2\n60#1:203,6\n60#1:218,4\n60#1:228,2\n63#1:239,6\n63#1:254,4\n63#1:264,2\n63#1:270\n67#1:281,6\n67#1:296,4\n67#1:306,2\n67#1:312\n60#1:316\n46#1:320\n46#1:156,9\n46#1:177\n60#1:209,9\n60#1:230\n63#1:245,9\n63#1:266\n63#1:268,2\n67#1:287,9\n67#1:308\n67#1:310,2\n60#1:314,2\n46#1:318,2\n46#1:169,6\n60#1:222,6\n63#1:258,6\n67#1:300,6\n51#1:182,6\n61#1:189,6\n60#1:196\n60#1:197,6\n60#1:231\n60#1:317\n63#1:233\n63#1:234,5\n63#1:267\n63#1:271\n52#1:322,12\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $deleting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $onDismiss:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $renaming$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$2BoOdeLjDNffySgy-9V6dvSGLNU(Lorg/lighttouch/android/DeviceSummary;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->invoke$lambda$13$lambda$7$lambda$6$lambda$0(Lorg/lighttouch/android/DeviceSummary;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$gpGdjyzfLu7o1QgN-UskH7x44ro(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->invoke$lambda$13$lambda$9$lambda$8(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$il3822w36keZHQ_0nDvw12kI9X0(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->invoke$lambda$13$lambda$7$lambda$6(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$host:Lorg/lighttouch/android/GuestHost;

    iput-object p2, p0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$renaming$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$13$lambda$7$lambda$6(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 14
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "$onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$renaming$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    move-object/from16 v1, p4

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getDevices()Ljava/util/List;

    move-result-object v3

    .local v3, "items\\1":Ljava/util/List;
    new-instance v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$$ExternalSyntheticLambda0;-><init>()V

    .local v0, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object/from16 v8, p4

    .line 322
    .local v8, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 325
    sget-object v2, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$1;

    move-object v9, v2

    check-cast v9, Lkotlin/jvm/functions/Function1;

    .line 322
    .local v9, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v10, 0x0

    .line 327
    .local v10, "$i$f$items\\1\\52":I
    nop

    .line 328
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v11

    .line 329
    nop

    .line 327
    new-instance v2, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$2;

    invoke-direct {v2, v0, v3}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    move-object v12, v2

    check-cast v12, Lkotlin/jvm/functions/Function1;

    new-instance v2, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$3;

    invoke-direct {v2, v9, v3}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    move-object v13, v2

    check-cast v13, Lkotlin/jvm/functions/Function1;

    .line 331
    new-instance v2, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$4;

    move-object v4, p0

    move-object v5, p1

    move-object/from16 v6, p2

    move-object/from16 v7, p3

    invoke-direct/range {v2 .. v7}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$invoke$lambda$13$lambda$7$lambda$6$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v4, -0x25b7f321

    const/4 v5, 0x1

    invoke-static {v4, v5, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    check-cast v2, Lkotlin/jvm/functions/Function4;

    .line 327
    invoke-interface {v8, v11, v12, v13, v2}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 333
    nop

    .line 59
    .end local v0    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v3    # "items\\1":Ljava/util/List;
    .end local v8    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v9    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v10    # "$i$f$items\\1\\52":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$13$lambda$7$lambda$6$lambda$0(Lorg/lighttouch/android/DeviceSummary;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/DeviceSummary;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    invoke-virtual {p0}, Lorg/lighttouch/android/DeviceSummary;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final invoke$lambda$13$lambda$9$lambda$8(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 61
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    invoke-interface {p1}, Lorg/lighttouch/android/GuestHost;->addDevice()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 44
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 92
    .param p1, "$this$ModalBottomSheet"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$ModalBottomSheet"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C44@2134L17,45@2160L2217:DevicesSheet.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 321
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_13

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.DevicesSheet.<anonymous> (DevicesSheet.kt:44)"

    const v6, -0x2cca751b

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 45
    :cond_2
    const/4 v3, 0x0

    invoke-static {v1, v3}, Lorg/lighttouch/android/DevicesSheetKt;->access$SheetSystemBars(Landroidx/compose/runtime/Composer;I)V

    .line 46
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    invoke-static {v5}, Landroidx/compose/foundation/layout/WindowInsetsPadding_androidKt;->navigationBarsPadding(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v5, 0x10

    .local v5, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 142
    .local v7, "$i$f$getDp\\1\\46":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 46
    .end local v5    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\46":I
    const/4 v11, 0x7

    const/4 v12, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v6 .. v12}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\2":Landroidx/compose/ui/Modifier;
    iget-object v6, v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$host:Lorg/lighttouch/android/GuestHost;

    iget-object v7, v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$onDismiss:Lkotlin/jvm/functions/Function0;

    iget-object v8, v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$renaming$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v9, v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v10, 0x0

    .local v10, "$changed\\2":I
    const/4 v11, 0x0

    .line 143
    .local v11, "$i$f$Column\\2\\46":I
    const v12, -0x1cd0f17e

    const-string v13, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 144
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v14

    .line 145
    .local v14, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v15, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v15

    .line 148
    .local v15, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v10, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v17, v10, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v12, v16, v17

    invoke-static {v14, v15, v1, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v10, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 149
    nop

    .local v16, "$changed\\3":I
    const/16 v17, 0x0

    .line 150
    .local v17, "$i$f$Layout\\3\\149":I
    const v3, -0x4ee9b9da

    const-string v0, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 151
    const/4 v3, 0x0

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v21

    .line 152
    .local v21, "compositeKeyHash\\3":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 153
    .local v3, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 155
    .local v2, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v22

    shl-int/lit8 v4, v16, 0x6

    and-int/lit16 v4, v4, 0x380

    move/from16 v23, v4

    const/4 v4, 0x6

    or-int/lit8 v23, v23, 0x6

    .line 154
    move-object/from16 v24, v22

    .local v23, "$changed\\4":I
    .local v24, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v22, 0x0

    .line 156
    .local v22, "$i$f$ReusableComposeNode\\4\\154":I
    move/from16 v25, v4

    const v4, -0x2942ffcf

    move-object/from16 v26, v5

    .end local v5    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v26, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 157
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 158
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 159
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_4

    .line 160
    move-object/from16 v4, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 162
    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v4, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 164
    :goto_1
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 165
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\164\\3":I
    sget-object v28, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v29, v4

    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v29, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v28 .. v28}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v1, v12, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 166
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v1, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 168
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v28, 0x0

    .line 169
    .local v28, "$i$f$set-impl\\6\\168":I
    move-object/from16 v30, v1

    .local v30, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 170
    .local v31, "$i$a$-with-Updater$set$1\\7\\169\\6":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v32

    if-nez v32, :cond_6

    move-object/from16 v32, v3

    .end local v3    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v32, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v33, v10

    .end local v10    # "$changed\\2":I
    .local v33, "$changed\\2":I
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v3, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v10, v30

    goto :goto_3

    .end local v32    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v33    # "$changed\\2":I
    .restart local v3    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10    # "$changed\\2":I
    :cond_6
    move-object/from16 v32, v3

    move/from16 v33, v10

    .line 171
    .end local v3    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "$changed\\2":I
    .restart local v32    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v33    # "$changed\\2":I
    :goto_2
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v10, v30

    .end local v30    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 172
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 174
    :goto_3
    nop

    .line 169
    .end local v10    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-with-Updater$set$1\\7\\169\\6":I
    nop

    .line 174
    nop

    .line 175
    .end local v4    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v28    # "$i$f$set-impl\\6\\168":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 176
    nop

    .line 164
    .end local v1    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\164\\3":I
    nop

    .line 177
    shr-int/lit8 v1, v23, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object/from16 v3, p2

    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 178
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\8\\177\\2":I
    const v10, -0x16ef5699

    move/from16 v24, v1

    .end local v1    # "$changed\\8":I
    .local v24, "$changed\\8":I
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v28, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v30, v33, 0x6

    and-int/lit8 v30, v30, 0x70

    or-int/lit8 v30, v30, 0x6

    .local v30, "$changed\\9":I
    move-object/from16 v10, v28

    check-cast v10, Landroidx/compose/foundation/layout/ColumnScope;

    .local v10, "$this$invoke_u24lambda_u2413\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v55, v3

    .local v55, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 47
    .local v28, "$i$a$-Column-DevicesSheetKt$DevicesSheet$1$1\\9\\178\\0":I
    move-object/from16 v59, v2

    .end local v2    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v59, "materialized\\3":Landroidx/compose/ui/Modifier;
    const v2, -0x2e1a251c

    move-object/from16 v60, v3

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v60, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v3, "C46@2277L10,46@2239L126,50@2756L635,50@2690L701,60@3557L33,59@3404L963:DevicesSheet.kt#o13vsk"

    move/from16 v61, v4

    move-object/from16 v4, v55

    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v61, "$i$a$-Layout-ColumnKt$Column$1\\8\\177\\2":I
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v54

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x18

    .local v3, "$this$dp\\10":I
    const/16 v34, 0x0

    .line 179
    .local v34, "$i$f$getDp\\10\\47":I
    nop

    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    int-to-float v4, v3

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 47
    .end local v3    # "$this$dp\\10":I
    .end local v34    # "$i$f$getDp\\10\\47":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\11":I
    const/16 v34, 0x0

    .line 179
    .local v34, "$i$f$getDp\\11\\47":I
    move/from16 v62, v11

    .end local v11    # "$i$f$Column\\2\\46":I
    .local v62, "$i$f$Column\\2\\46":I
    int-to-float v11, v4

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 47
    .end local v4    # "$this$dp\\11":I
    .end local v34    # "$i$f$getDp\\11\\47":I
    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v35

    const/16 v57, 0x0

    const v58, 0xfffc

    const-string v34, "\u8bbe\u5907"

    const-wide/16 v36, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const-wide/16 v47, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v56, 0x36

    invoke-static/range {v34 .. v58}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v4, v55

    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    const v2, -0x438d30c6

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "48@2522L10,48@2566L11,47@2395L282"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 48
    invoke-static {v6}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v2

    if-eqz v2, :cond_9

    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v2

    if-eqz v2, :cond_7

    invoke-virtual {v2}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_8

    :cond_7
    const-string v2, "\u6b63\u5728\u8fd0\u884c\u7684\u8bbe\u5907"

    :cond_8
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "Stop "

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5207\u6362\u8bbe\u5907\u6216\u6dfb\u52a0\u65b0\u8bbe\u5907\u3002"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v34

    .line 49
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v54

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v36

    .line 50
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x18

    .local v3, "$this$dp\\12":I
    const/4 v11, 0x0

    .line 180
    .local v11, "$i$f$getDp\\12\\50":I
    move-object/from16 v55, v4

    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    int-to-float v4, v3

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 50
    .end local v3    # "$this$dp\\12":I
    .end local v11    # "$i$f$getDp\\12\\50":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\13":I
    const/4 v11, 0x0

    .line 180
    .local v11, "$i$f$getDp\\13\\50":I
    move/from16 v35, v11

    .end local v11    # "$i$f$getDp\\13\\50":I
    .local v35, "$i$f$getDp\\13\\50":I
    int-to-float v11, v4

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 50
    .end local v4    # "$this$dp\\13":I
    .end local v35    # "$i$f$getDp\\13\\50":I
    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v35

    .line 48
    nop

    .line 50
    nop

    .line 49
    nop

    .line 48
    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const-wide/16 v47, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v56, 0x30

    const/16 v57, 0x0

    const v58, 0xfff8

    invoke-static/range {v34 .. v58}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v4, v55

    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    :cond_9
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 51
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v34, v2

    check-cast v34, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\14":I
    const/4 v3, 0x0

    .line 181
    .local v3, "$i$f$getDp\\14\\51":I
    int-to-float v11, v2

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v36

    .line 51
    .end local v2    # "$this$dp\\14":I
    .end local v3    # "$i$f$getDp\\14\\51":I
    const/16 v39, 0xd

    const/16 v40, 0x0

    const/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    invoke-static/range {v34 .. v40}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v11, 0x0

    invoke-interface {v10, v2, v3, v11}, Landroidx/compose/foundation/layout/ColumnScope;->weight(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;

    move-result-object v34

    const v2, -0x48fade91

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):DevicesSheet.kt#9igjgp"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    invoke-interface {v4, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v35

    or-int v11, v11, v35

    .local v11, "invalid\\15":Z
    move-object/from16 v35, v4

    .local v35, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 182
    .local v36, "$i$f$cache\\15\\51":I
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\15":Ljava/lang/Object;
    const/16 v37, 0x0

    .line 183
    .local v37, "$i$a$-let-ComposerKt$cache$1\\16\\182\\15":I
    if-nez v11, :cond_b

    sget-object v38, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v55, v4

    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v38 .. v38}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_a

    goto :goto_4

    .line 187
    :cond_a
    move-object/from16 v38, v3

    move-object/from16 v4, v35

    goto :goto_5

    .line 183
    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :cond_b
    move-object/from16 v55, v4

    .line 184
    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :goto_4
    const/4 v4, 0x0

    .line 51
    .local v4, "$i$a$-cache-DevicesSheetKt$DevicesSheet$1$1$1\\17\\184\\9":I
    move-object/from16 v38, v3

    .end local v3    # "it\\15":Ljava/lang/Object;
    .local v38, "it\\15":Ljava/lang/Object;
    new-instance v3, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$$ExternalSyntheticLambda1;

    invoke-direct {v3, v6, v7, v8, v9}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 184
    .end local v4    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$1$1$1\\17\\184\\9":I
    nop

    .line 185
    .local v3, "value\\16":Ljava/lang/Object;
    move-object/from16 v4, v35

    .end local v35    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .local v4, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 186
    nop

    .line 183
    .end local v3    # "value\\16":Ljava/lang/Object;
    :goto_5
    nop

    .line 182
    .end local v37    # "$i$a$-let-ComposerKt$cache$1\\16\\182\\15":I
    .end local v38    # "it\\15":Ljava/lang/Object;
    nop

    .line 51
    .end local v4    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v11    # "invalid\\15":Z
    .end local v36    # "$i$f$cache\\15\\51":I
    move-object/from16 v42, v3

    check-cast v42, Lkotlin/jvm/functions/Function1;

    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v44, 0x0

    const/16 v45, 0xfe

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    move-object/from16 v43, v55

    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v45}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 60
    move-object/from16 v4, v43

    .end local v43    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v11, 0x0

    invoke-static {v3, v8, v9, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v9, 0xc

    .local v9, "$this$dp\\18":I
    const/16 v35, 0x0

    .line 188
    .local v35, "$i$f$getDp\\18\\60":I
    int-to-float v8, v9

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 60
    .end local v9    # "$this$dp\\18":I
    .end local v35    # "$i$f$getDp\\18\\60":I
    const/4 v9, 0x2

    move-object/from16 v35, v10

    const/4 v10, 0x0

    .end local v10    # "$this$invoke_u24lambda_u2413\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v35, "$this$invoke_u24lambda_u2413\\9":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static {v3, v8, v10, v9, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v8, 0xe

    .local v8, "$this$dp\\19":I
    const/4 v9, 0x0

    .line 188
    .local v9, "$i$f$getDp\\19\\60":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 60
    .end local v8    # "$this$dp\\19":I
    .end local v9    # "$i$f$getDp\\19\\60":I
    invoke-static {v8}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v8

    check-cast v8, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v8}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v36

    .line 61
    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getBusy()Z

    move-result v3

    if-nez v3, :cond_c

    invoke-static {v6}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v3

    if-nez v3, :cond_c

    const/16 v37, 0x1

    goto :goto_6

    :cond_c
    const/16 v37, 0x0

    :goto_6
    const v3, -0x615d173a

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\20":Z
    move-object v3, v4

    .local v3, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 189
    .local v8, "$i$f$cache\\20\\61":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\20":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 190
    .local v10, "$i$a$-let-ComposerKt$cache$1\\21\\189\\20":I
    if-nez v2, :cond_e

    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v9, v11, :cond_d

    goto :goto_7

    .line 194
    :cond_d
    move/from16 v34, v2

    move-object v2, v9

    goto :goto_8

    .line 191
    :cond_e
    :goto_7
    const/4 v11, 0x0

    .line 61
    .local v11, "$i$a$-cache-DevicesSheetKt$DevicesSheet$1$1$2\\22\\191\\9":I
    move/from16 v34, v2

    .end local v2    # "invalid\\20":Z
    .local v34, "invalid\\20":Z
    new-instance v2, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$$ExternalSyntheticLambda2;

    invoke-direct {v2, v7, v6}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)V

    .line 191
    .end local v11    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$1$1$2\\22\\191\\9":I
    nop

    .line 192
    .local v2, "value\\21":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 193
    nop

    .line 190
    .end local v2    # "value\\21":Ljava/lang/Object;
    :goto_8
    nop

    .line 189
    .end local v9    # "it\\20":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\21\\189\\20":I
    nop

    .line 61
    .end local v3    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\20\\61":I
    .end local v34    # "invalid\\20":Z
    move-object/from16 v40, v2

    check-cast v40, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v41, 0x6

    const/16 v42, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    invoke-static/range {v36 .. v42}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v3, 0xc

    .local v3, "$this$dp\\23":I
    const/4 v7, 0x0

    .line 195
    .local v7, "$i$f$getDp\\23\\61":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 61
    .end local v3    # "$this$dp\\23":I
    .end local v7    # "$i$f$getDp\\23\\61":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const-string v3, "add_device"

    invoke-static {v2, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    invoke-static {v6}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v3

    if-eqz v3, :cond_f

    const v3, 0x3ec28f5c    # 0.38f

    goto :goto_9

    :cond_f
    const/high16 v3, 0x3f800000    # 1.0f

    :goto_9
    invoke-static {v2, v3}, Landroidx/compose/ui/draw/AlphaKt;->alpha(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 62
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .line 60
    const/16 v6, 0x180

    .local v2, "modifier\\24":Landroidx/compose/ui/Modifier;
    .local v3, "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    .local v6, "$changed\\24":I
    const/4 v7, 0x0

    .line 196
    .local v7, "$i$f$Row\\24\\60":I
    const v8, 0x2952b718

    const-string v9, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v4, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 197
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v8

    .line 201
    .local v8, "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v9, v6, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v8, v3, v4, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 202
    nop

    .local v10, "$changed\\25":I
    const/4 v11, 0x0

    .line 203
    .local v11, "$i$f$Layout\\25\\202":I
    move-object/from16 v34, v3

    const v3, -0x4ee9b9da

    .end local v3    # "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    .local v34, "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v4, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 204
    const/4 v3, 0x0

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v36

    .line 205
    .local v36, "compositeKeyHash\\25":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 206
    .local v3, "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v37, v6

    .end local v6    # "$changed\\24":I
    .local v37, "$changed\\24":I
    invoke-static {v4, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 208
    .local v6, "materialized\\25":Landroidx/compose/ui/Modifier;
    sget-object v38, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v38 .. v38}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v38

    move-object/from16 v39, v2

    .end local v2    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .local v39, "modifier\\24":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v10, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 207
    nop

    .local v2, "$changed\\26":I
    move-object/from16 v40, v38

    .local v40, "factory\\26":Lkotlin/jvm/functions/Function0;
    const/16 v38, 0x0

    .line 209
    .local v38, "$i$f$ReusableComposeNode\\26\\207":I
    move/from16 v41, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\26":I
    .local v41, "$changed\\26":I
    invoke-static {v4, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 210
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 211
    :cond_10
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 212
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_11

    .line 213
    move-object/from16 v2, v40

    .end local v40    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\26":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 215
    .end local v2    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .restart local v40    # "factory\\26":Lkotlin/jvm/functions/Function0;
    :cond_11
    move-object/from16 v2, v40

    .end local v40    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\26":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 217
    :goto_a
    move-object/from16 v40, v2

    .end local v2    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .restart local v40    # "factory\\26":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    const/16 v42, 0x0

    .line 218
    .local v42, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\27\\217\\25":I
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v55, v4

    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v9, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 219
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 221
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\28":Lkotlin/jvm/functions/Function2;
    const/16 v43, 0x0

    .line 222
    .local v43, "$i$f$set-impl\\28\\221":I
    move-object/from16 v44, v2

    .local v44, "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    const/16 v45, 0x0

    .line 223
    .local v45, "$i$a$-with-Updater$set$1\\29\\222\\28":I
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v46

    if-nez v46, :cond_13

    move-object/from16 v46, v3

    .end local v3    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .local v46, "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v47, v7

    .end local v7    # "$i$f$Row\\24\\60":I
    .local v47, "$i$f$Row\\24\\60":I
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_12

    goto :goto_b

    :cond_12
    move-object/from16 v7, v44

    goto :goto_c

    .end local v46    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v47    # "$i$f$Row\\24\\60":I
    .restart local v3    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v7    # "$i$f$Row\\24\\60":I
    :cond_13
    move-object/from16 v46, v3

    move/from16 v47, v7

    .line 224
    .end local v3    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v7    # "$i$f$Row\\24\\60":I
    .restart local v46    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v47    # "$i$f$Row\\24\\60":I
    :goto_b
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v7, v44

    .end local v44    # "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 225
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 227
    :goto_c
    nop

    .line 222
    .end local v7    # "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .end local v45    # "$i$a$-with-Updater$set$1\\29\\222\\28":I
    nop

    .line 227
    nop

    .line 228
    .end local v4    # "block\\28":Lkotlin/jvm/functions/Function2;
    .end local v43    # "$i$f$set-impl\\28\\221":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 229
    nop

    .line 217
    .end local v2    # "$this$Layout_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .end local v42    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\27\\217\\25":I
    nop

    .line 230
    shr-int/lit8 v2, v41, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\30":I
    move-object/from16 v3, v55

    .local v3, "$composer\\30":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 231
    .local v4, "$i$a$-Layout-RowKt$Row$1\\30\\230\\24":I
    const v7, -0x184f2606

    move/from16 v42, v2

    .end local v2    # "$changed\\30":I
    .local v42, "$changed\\30":I
    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v3, v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v7, v37, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\31":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$invoke_u24lambda_u2413_u24lambda_u2412\\31":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v43, v3

    .local v43, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/16 v44, 0x0

    .line 63
    .local v44, "$i$a$-Row-DevicesSheetKt$DevicesSheet$1$1$3\\31\\231\\9":I
    move-object/from16 v45, v2

    .end local v2    # "$this$invoke_u24lambda_u2413_u24lambda_u2412\\31":Landroidx/compose/foundation/layout/RowScope;
    .local v45, "$this$invoke_u24lambda_u2413_u24lambda_u2412\\31":Landroidx/compose/foundation/layout/RowScope;
    const v2, -0x650298c4

    move-object/from16 v48, v3

    .end local v3    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\30":Landroidx/compose/runtime/Composer;
    const-string v3, "C62@3799L11,62@3749L266,65@4032L29,66@4078L275:DevicesSheet.kt#o13vsk"

    move/from16 v49, v4

    move-object/from16 v4, v43

    .end local v43    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v49, "$i$a$-Layout-RowKt$Row$1\\30\\230\\24":I
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x2c

    .local v3, "$this$dp\\32":I
    const/16 v43, 0x0

    .line 232
    .local v43, "$i$f$getDp\\32\\63":I
    move-object/from16 v50, v6

    .end local v6    # "materialized\\25":Landroidx/compose/ui/Modifier;
    .local v50, "materialized\\25":Landroidx/compose/ui/Modifier;
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 63
    .end local v3    # "$this$dp\\32":I
    .end local v43    # "$i$f$getDp\\32\\63":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    move/from16 v43, v7

    .end local v7    # "$changed\\31":I
    .local v43, "$changed\\31":I
    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v6

    const/16 v3, 0xc

    .local v3, "$this$dp\\33":I
    const/16 v51, 0x0

    .line 232
    .local v51, "$i$f$getDp\\33\\63":I
    move-object/from16 v52, v8

    .end local v8    # "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v52, "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 63
    .end local v3    # "$this$dp\\33":I
    .end local v51    # "$i$f$getDp\\33\\63":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v6, v7, v3}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\34":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v3

    .local v3, "contentAlignment\\34":Landroidx/compose/ui/Alignment;
    const/16 v6, 0x30

    .local v6, "$changed\\34":I
    const/4 v7, 0x0

    .line 233
    .local v7, "$i$f$Box\\34\\63":I
    const v8, 0x2bb5b5d7

    move/from16 v51, v6

    .end local v6    # "$changed\\34":I
    .local v51, "$changed\\34":I
    const-string v6, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v4, v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 234
    const/4 v6, 0x0

    .line 237
    .local v6, "propagateMinConstraints\\34":Z
    invoke-static {v3, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v53, v51, 0x3

    and-int/lit8 v53, v53, 0x70

    .line 238
    nop

    .local v53, "$changed\\35":I
    const/16 v54, 0x0

    .line 239
    .local v54, "$i$f$Layout\\35\\238":I
    move-object/from16 v56, v3

    const v3, -0x4ee9b9da

    .end local v3    # "contentAlignment\\34":Landroidx/compose/ui/Alignment;
    .local v56, "contentAlignment\\34":Landroidx/compose/ui/Alignment;
    invoke-static {v4, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 240
    const/4 v3, 0x0

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v57

    .line 241
    .local v57, "compositeKeyHash\\35":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 242
    .local v3, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v58, v6

    .end local v6    # "propagateMinConstraints\\34":Z
    .local v58, "propagateMinConstraints\\34":Z
    invoke-static {v4, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 244
    .local v6, "materialized\\35":Landroidx/compose/ui/Modifier;
    sget-object v63, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v63 .. v63}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v63

    move-object/from16 v64, v2

    .end local v2    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .local v64, "modifier\\34":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v53, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 243
    move-object/from16 v65, v63

    .local v2, "$changed\\36":I
    .local v65, "factory\\36":Lkotlin/jvm/functions/Function0;
    const/16 v63, 0x0

    .line 245
    .local v63, "$i$f$ReusableComposeNode\\36\\243":I
    move/from16 v66, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\36":I
    .local v66, "$changed\\36":I
    invoke-static {v4, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 246
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 247
    :cond_14
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 248
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_15

    .line 249
    move-object/from16 v2, v65

    .end local v65    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 251
    .end local v2    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v65    # "factory\\36":Lkotlin/jvm/functions/Function0;
    :cond_15
    move-object/from16 v2, v65

    .end local v65    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 253
    :goto_d
    move-object/from16 v65, v2

    .end local v2    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v65    # "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    const/16 v67, 0x0

    .line 254
    .local v67, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\37\\253\\35":I
    sget-object v68, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v69, v7

    .end local v7    # "$i$f$Box\\34\\63":I
    .local v69, "$i$f$Box\\34\\63":I
    invoke-virtual/range {v68 .. v68}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v8, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 255
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v3, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 257
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\38":Lkotlin/jvm/functions/Function2;
    const/16 v68, 0x0

    .line 258
    .local v68, "$i$f$set-impl\\38\\257":I
    move-object/from16 v70, v2

    .local v70, "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    const/16 v71, 0x0

    .line 259
    .local v71, "$i$a$-with-Updater$set$1\\39\\258\\38":I
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v72

    if-nez v72, :cond_17

    move-object/from16 v72, v3

    .end local v3    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .local v72, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v73, v8

    .end local v8    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v73, "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v57 .. v57}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v3, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_16

    goto :goto_e

    :cond_16
    move-object/from16 v8, v70

    goto :goto_f

    .end local v72    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v73    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_17
    move-object/from16 v72, v3

    move-object/from16 v73, v8

    .line 260
    .end local v3    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v72    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v73    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_e
    invoke-static/range {v57 .. v57}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v8, v70

    .end local v70    # "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 261
    invoke-static/range {v57 .. v57}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 263
    :goto_f
    nop

    .line 258
    .end local v8    # "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .end local v71    # "$i$a$-with-Updater$set$1\\39\\258\\38":I
    nop

    .line 263
    nop

    .line 264
    .end local v7    # "block\\38":Lkotlin/jvm/functions/Function2;
    .end local v68    # "$i$f$set-impl\\38\\257":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 265
    nop

    .line 253
    .end local v2    # "$this$Layout_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    .end local v67    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\37\\253\\35":I
    nop

    .line 266
    shr-int/lit8 v2, v66, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\40":I
    move-object v3, v4

    .local v3, "$composer\\40":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 267
    .local v7, "$i$a$-Layout-BoxKt$Box$1\\40\\266\\34":I
    const v8, -0x7ff519f7    # -1.000876E-39f

    move/from16 v67, v2

    .end local v2    # "$changed\\40":I
    .local v67, "$changed\\40":I
    const-string v2, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v3, v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v8, v51, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\41":I
    check-cast v2, Landroidx/compose/foundation/layout/BoxScope;

    .local v2, "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2410\\41":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v79, v3

    .local v79, "$composer\\41":Landroidx/compose/runtime/Composer;
    const/16 v68, 0x0

    .line 64
    .local v68, "$i$a$-Box-DevicesSheetKt$DevicesSheet$1$1$3$1\\41\\267\\31":I
    move-object/from16 v70, v2

    .end local v2    # "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2410\\41":Landroidx/compose/foundation/layout/BoxScope;
    .local v70, "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2410\\41":Landroidx/compose/foundation/layout/BoxScope;
    const v2, 0x33e9c96d

    move-object/from16 v71, v3

    .end local v3    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\40":Landroidx/compose/runtime/Composer;
    const-string v3, "C63@3966L11,63@3916L81:DevicesSheet.kt#o13vsk"

    move-object/from16 v82, v6

    move-object/from16 v6, v79

    .end local v79    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v82, "materialized\\35":Landroidx/compose/ui/Modifier;
    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v2}, Landroidx/compose/material/icons/filled/AddKt;->getAdd(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v74

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v6, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnPrimaryContainer-0d7_KjU()J

    move-result-wide v77

    const/16 v80, 0x30

    const/16 v81, 0x4

    const/16 v75, 0x0

    const/16 v76, 0x0

    .end local v6    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v79    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v74 .. v81}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v79 .. v79}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 65
    nop

    .line 267
    .end local v8    # "$changed\\41":I
    .end local v68    # "$i$a$-Box-DevicesSheetKt$DevicesSheet$1$1$3$1\\41\\267\\31":I
    .end local v70    # "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2410\\41":Landroidx/compose/foundation/layout/BoxScope;
    .end local v79    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 266
    .end local v7    # "$i$a$-Layout-BoxKt$Box$1\\40\\266\\34":I
    .end local v67    # "$changed\\40":I
    .end local v71    # "$composer\\40":Landroidx/compose/runtime/Composer;
    nop

    .line 268
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 245
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 269
    nop

    .line 239
    .end local v63    # "$i$f$ReusableComposeNode\\36\\243":I
    .end local v65    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .end local v66    # "$changed\\36":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 270
    nop

    .line 233
    .end local v53    # "$changed\\35":I
    .end local v54    # "$i$f$Layout\\35\\238":I
    .end local v57    # "compositeKeyHash\\35":I
    .end local v72    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v82    # "materialized\\35":Landroidx/compose/ui/Modifier;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 271
    nop

    .line 66
    .end local v51    # "$changed\\34":I
    .end local v56    # "contentAlignment\\34":Landroidx/compose/ui/Alignment;
    .end local v58    # "propagateMinConstraints\\34":Z
    .end local v64    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .end local v69    # "$i$f$Box\\34\\63":I
    .end local v73    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x10

    .local v3, "$this$dp\\42":I
    const/4 v6, 0x0

    .line 272
    .local v6, "$i$f$getDp\\42\\66":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 66
    .end local v3    # "$this$dp\\42":I
    .end local v6    # "$i$f$getDp\\42\\66":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    move/from16 v3, v25

    invoke-static {v2, v4, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 67
    const/16 v19, 0x0

    move/from16 v2, v19

    .local v2, "$changed\\43":I
    const/4 v3, 0x0

    .line 273
    .local v3, "$i$f$Column\\43\\67":I
    const v6, -0x1cd0f17e

    invoke-static {v4, v6, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 274
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 275
    .local v6, "modifier\\43":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 276
    .local v7, "verticalArrangement\\43":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 279
    .local v8, "horizontalAlignment\\43":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v13, v2, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v18, v2, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v13, v13, v18

    invoke-static {v7, v8, v4, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\43":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v18, v2, 0x3

    and-int/lit8 v18, v18, 0x70

    .line 280
    nop

    .local v18, "$changed\\44":I
    const/16 v51, 0x0

    .line 281
    .local v51, "$i$f$Layout\\44\\280":I
    move/from16 v53, v2

    const v2, -0x4ee9b9da

    .end local v2    # "$changed\\43":I
    .local v53, "$changed\\43":I
    invoke-static {v4, v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 282
    const/4 v0, 0x0

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v0

    .line 283
    .local v0, "compositeKeyHash\\44":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 284
    .local v2, "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v19, v0

    .end local v0    # "compositeKeyHash\\44":I
    .local v19, "compositeKeyHash\\44":I
    invoke-static {v4, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 286
    .local v0, "materialized\\44":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move/from16 v54, v3

    .end local v3    # "$i$f$Column\\43\\67":I
    .local v54, "$i$f$Column\\43\\67":I
    shl-int/lit8 v3, v18, 0x6

    and-int/lit16 v3, v3, 0x380

    const/16 v25, 0x6

    or-int/lit8 v3, v3, 0x6

    .line 285
    move-object/from16 v56, v20

    .local v3, "$changed\\45":I
    .local v56, "factory\\45":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 287
    .local v20, "$i$f$ReusableComposeNode\\45\\285":I
    move/from16 v57, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\45":I
    .local v57, "$changed\\45":I
    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 288
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 289
    :cond_18
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 290
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_19

    .line 291
    move-object/from16 v3, v56

    .end local v56    # "factory\\45":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\45":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 293
    .end local v3    # "factory\\45":Lkotlin/jvm/functions/Function0;
    .restart local v56    # "factory\\45":Lkotlin/jvm/functions/Function0;
    :cond_19
    move-object/from16 v3, v56

    .end local v56    # "factory\\45":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\45":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 295
    :goto_10
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\46":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 296
    .local v27, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\46\\295\\44":I
    sget-object v56, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v58, v3

    .end local v3    # "factory\\45":Lkotlin/jvm/functions/Function0;
    .local v58, "factory\\45":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v13, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 297
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 299
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\47":Lkotlin/jvm/functions/Function2;
    const/16 v56, 0x0

    .line 300
    .local v56, "$i$f$set-impl\\47\\299":I
    move-object/from16 v63, v5

    .local v63, "$this$set_impl_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    const/16 v64, 0x0

    .line 301
    .local v64, "$i$a$-with-Updater$set$1\\48\\300\\47":I
    invoke-interface/range {v63 .. v63}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v65

    if-nez v65, :cond_1b

    move-object/from16 v65, v2

    .end local v2    # "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    .local v65, "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v63 .. v63}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v66, v4

    .end local v4    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\31":Landroidx/compose/runtime/Composer;
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1a

    goto :goto_11

    :cond_1a
    move-object/from16 v4, v63

    goto :goto_12

    .end local v65    # "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v66    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local v2    # "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "$composer\\31":Landroidx/compose/runtime/Composer;
    :cond_1b
    move-object/from16 v65, v2

    move-object/from16 v66, v4

    .line 302
    .end local v2    # "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local v65    # "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v66    # "$composer\\31":Landroidx/compose/runtime/Composer;
    :goto_11
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v63

    .end local v63    # "$this$set_impl_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 303
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v5, v2, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 305
    :goto_12
    nop

    .line 300
    .end local v4    # "$this$set_impl_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    .end local v64    # "$i$a$-with-Updater$set$1\\48\\300\\47":I
    nop

    .line 305
    nop

    .line 306
    .end local v3    # "block\\47":Lkotlin/jvm/functions/Function2;
    .end local v56    # "$i$f$set-impl\\47\\299":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 307
    nop

    .line 295
    .end local v5    # "$this$Layout_u24lambda_u240\\46":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\46\\295\\44":I
    nop

    .line 308
    shr-int/lit8 v2, v57, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\49":I
    move-object/from16 v3, v66

    .local v3, "$composer\\49":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 309
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\49\\308\\43":I
    const v5, -0x16ef5699

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v53, 0x6

    and-int/lit8 v5, v5, 0x70

    const/16 v25, 0x6

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\50":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2411\\50":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v88, v3

    .local v88, "$composer\\50":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 68
    .local v25, "$i$a$-Column-DevicesSheetKt$DevicesSheet$1$1$3$2\\50\\309\\31":I
    move-object/from16 v27, v0

    .end local v0    # "materialized\\44":Landroidx/compose/ui/Modifier;
    .local v27, "materialized\\44":Landroidx/compose/ui/Modifier;
    const v0, -0x5679056

    move-object/from16 v31, v1

    .end local v1    # "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2411\\50":Landroidx/compose/foundation/layout/ColumnScope;
    .local v31, "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2411\\50":Landroidx/compose/foundation/layout/ColumnScope;
    const-string v1, "C67@4148L10,67@4107L63,68@4262L10,68@4306L11,68@4191L144:DevicesSheet.kt#o13vsk"

    move/from16 v56, v2

    move-object/from16 v2, v88

    .end local v88    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\50":Landroidx/compose/runtime/Composer;
    .local v56, "$changed\\49":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v87

    const/16 v90, 0x0

    const v91, 0xfffe

    const-string v67, "\u6dfb\u52a0\u8bbe\u5907"

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const-wide/16 v71, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const-wide/16 v80, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v89, 0x6

    .end local v2    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .restart local v88    # "$composer\\50":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v91}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 69
    .end local v88    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\50":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v87

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v69

    const v91, 0xfffa

    const-string v67, "\u4ece IPSW \u6216\u5df2\u5907\u597d\u7684\u8bbe\u5907\u955c\u50cf"

    .end local v2    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .restart local v88    # "$composer\\50":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v91}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 68
    .end local v88    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\50":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 70
    nop

    .line 309
    .end local v2    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .end local v5    # "$changed\\50":I
    .end local v25    # "$i$a$-Column-DevicesSheetKt$DevicesSheet$1$1$3$2\\50\\309\\31":I
    .end local v31    # "$this$invoke_u24lambda_u2413_u24lambda_u2412_u24lambda_u2411\\50":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 308
    .end local v3    # "$composer\\49":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\49\\308\\43":I
    .end local v56    # "$changed\\49":I
    nop

    .line 310
    invoke-interface/range {v66 .. v66}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 287
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 311
    nop

    .line 281
    .end local v20    # "$i$f$ReusableComposeNode\\45\\285":I
    .end local v57    # "$changed\\45":I
    .end local v58    # "factory\\45":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 312
    nop

    .line 273
    .end local v18    # "$changed\\44":I
    .end local v19    # "compositeKeyHash\\44":I
    .end local v27    # "materialized\\44":Landroidx/compose/ui/Modifier;
    .end local v51    # "$i$f$Layout\\44\\280":I
    .end local v65    # "localMap\\44":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 313
    nop

    .line 63
    .end local v6    # "modifier\\43":Landroidx/compose/ui/Modifier;
    .end local v7    # "verticalArrangement\\43":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v8    # "horizontalAlignment\\43":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v13    # "measurePolicy\\43":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v53    # "$changed\\43":I
    .end local v54    # "$i$f$Column\\43\\67":I
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 71
    nop

    .line 231
    .end local v43    # "$changed\\31":I
    .end local v44    # "$i$a$-Row-DevicesSheetKt$DevicesSheet$1$1$3\\31\\231\\9":I
    .end local v45    # "$this$invoke_u24lambda_u2413_u24lambda_u2412\\31":Landroidx/compose/foundation/layout/RowScope;
    .end local v66    # "$composer\\31":Landroidx/compose/runtime/Composer;
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 230
    .end local v42    # "$changed\\30":I
    .end local v48    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .end local v49    # "$i$a$-Layout-RowKt$Row$1\\30\\230\\24":I
    nop

    .line 314
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 209
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 315
    nop

    .line 203
    .end local v38    # "$i$f$ReusableComposeNode\\26\\207":I
    .end local v40    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .end local v41    # "$changed\\26":I
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 316
    nop

    .line 196
    .end local v10    # "$changed\\25":I
    .end local v11    # "$i$f$Layout\\25\\202":I
    .end local v36    # "compositeKeyHash\\25":I
    .end local v46    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "materialized\\25":Landroidx/compose/ui/Modifier;
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 317
    nop

    .line 47
    .end local v9    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v34    # "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    .end local v37    # "$changed\\24":I
    .end local v39    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .end local v47    # "$i$f$Row\\24\\60":I
    .end local v52    # "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 72
    nop

    .line 178
    .end local v28    # "$i$a$-Column-DevicesSheetKt$DevicesSheet$1$1\\9\\178\\0":I
    .end local v30    # "$changed\\9":I
    .end local v35    # "$this$invoke_u24lambda_u2413\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 177
    .end local v24    # "$changed\\8":I
    .end local v60    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v61    # "$i$a$-Layout-ColumnKt$Column$1\\8\\177\\2":I
    nop

    .line 318
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 156
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 319
    nop

    .line 150
    .end local v22    # "$i$f$ReusableComposeNode\\4\\154":I
    .end local v23    # "$changed\\4":I
    .end local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 320
    nop

    .line 143
    .end local v16    # "$changed\\3":I
    .end local v17    # "$i$f$Layout\\3\\149":I
    .end local v21    # "compositeKeyHash\\3":I
    .end local v32    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v59    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 321
    nop

    .end local v12    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v14    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v15    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v26    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v33    # "$changed\\2":I
    .end local v62    # "$i$f$Column\\2\\46":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 73
    :cond_1c
    :goto_13
    return-void
.end method

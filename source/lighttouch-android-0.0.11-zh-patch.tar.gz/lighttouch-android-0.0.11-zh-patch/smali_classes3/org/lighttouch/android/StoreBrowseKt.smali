.class public final Lorg/lighttouch/android/StoreBrowseKt;
.super Ljava/lang/Object;
.source "StoreBrowse.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreBrowse.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreBrowse.kt\norg/lighttouch/android/StoreBrowseKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n+ 9 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 10 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 11 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 12 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt\n+ 13 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,355:1\n149#2:356\n149#2:369\n149#2:371\n149#2:372\n149#2:379\n149#2:420\n149#2:427\n149#2:473\n149#2:567\n149#2:576\n149#2:583\n149#2:596\n149#2:686\n149#2:701\n149#2:738\n149#2:739\n149#2:785\n149#2:792\n149#2:799\n149#2:851\n149#2:858\n149#2:871\n1225#3,6:357\n1225#3,6:363\n1225#3,6:373\n1225#3,6:421\n1225#3,6:463\n1225#3,6:506\n1225#3,6:512\n1225#3,6:555\n1225#3,6:561\n1225#3,6:577\n1225#3,6:584\n1225#3,6:590\n1225#3,6:633\n1225#3,6:674\n1225#3,6:680\n1225#3,6:691\n1225#3,6:786\n1225#3,6:793\n1225#3,6:835\n1225#3,6:845\n1225#3,6:852\n1225#3,6:859\n1225#3,6:865\n1#4:370\n99#5:380\n96#5,6:381\n102#5:415\n106#5:419\n99#5:428\n97#5,5:429\n102#5:462\n106#5:472\n99#5,3:474\n102#5:505\n106#5:575\n99#5:597\n96#5,6:598\n102#5:632\n106#5:700\n99#5:702\n96#5,6:703\n102#5:737\n106#5:784\n99#5:800\n97#5,5:801\n102#5:834\n106#5:844\n99#5:872\n96#5,6:873\n102#5:907\n106#5:952\n79#6,6:387\n86#6,4:402\n90#6,2:412\n94#6:418\n79#6,6:434\n86#6,4:449\n90#6,2:459\n94#6:471\n79#6,6:477\n86#6,4:492\n90#6,2:502\n79#6,6:526\n86#6,4:541\n90#6,2:551\n94#6:570\n94#6:574\n79#6,6:604\n86#6,4:619\n90#6,2:629\n79#6,6:645\n86#6,4:660\n90#6,2:670\n94#6:689\n94#6:699\n79#6,6:709\n86#6,4:724\n90#6,2:734\n79#6,6:748\n86#6,4:763\n90#6,2:773\n94#6:779\n94#6:783\n79#6,6:806\n86#6,4:821\n90#6,2:831\n94#6:843\n79#6,6:879\n86#6,4:894\n90#6,2:904\n79#6,6:916\n86#6,4:931\n90#6,2:941\n94#6:947\n94#6:951\n368#7,9:393\n377#7:414\n378#7,2:416\n368#7,9:440\n377#7:461\n378#7,2:469\n368#7,9:483\n377#7:504\n368#7,9:532\n377#7:553\n378#7,2:568\n378#7,2:572\n368#7,9:610\n377#7:631\n368#7,9:651\n377#7:672\n378#7,2:687\n378#7,2:697\n368#7,9:715\n377#7:736\n368#7,9:754\n377#7:775\n378#7,2:777\n378#7,2:781\n368#7,9:812\n377#7:833\n378#7,2:841\n368#7,9:885\n377#7:906\n368#7,9:922\n377#7:943\n378#7,2:945\n378#7,2:949\n4034#8,6:406\n4034#8,6:453\n4034#8,6:496\n4034#8,6:545\n4034#8,6:623\n4034#8,6:664\n4034#8,6:728\n4034#8,6:767\n4034#8,6:825\n4034#8,6:898\n4034#8,6:935\n71#9:518\n67#9,7:519\n74#9:554\n78#9:571\n71#9:639\n69#9,5:640\n74#9:673\n78#9:690\n86#10:740\n82#10,7:741\n89#10:776\n93#10:780\n86#10:908\n82#10,7:909\n89#10:944\n93#10:948\n81#11:953\n81#11:966\n107#11,2:967\n81#11:984\n107#11,2:985\n143#12,12:954\n143#12,12:969\n143#12,12:987\n143#12,12:999\n1761#13,3:981\n*S KotlinDebug\n*F\n+ 1 StoreBrowse.kt\norg/lighttouch/android/StoreBrowseKt\n*L\n192#1:356\n203#1:369\n205#1:371\n206#1:372\n214#1:379\n223#1:420\n231#1:427\n234#1:473\n239#1:567\n247#1:576\n249#1:583\n264#1:596\n270#1:686\n283#1:701\n284#1:738\n285#1:739\n299#1:785\n301#1:792\n312#1:799\n325#1:851\n327#1:858\n348#1:871\n201#1:357,6\n202#1:363,6\n206#1:373,6\n225#1:421,6\n232#1:463,6\n235#1:506,6\n236#1:512,6\n238#1:555,6\n239#1:561,6\n248#1:577,6\n249#1:584,6\n263#1:590,6\n265#1:633,6\n267#1:674,6\n270#1:680,6\n274#1:691,6\n300#1:786,6\n301#1:793,6\n313#1:835,6\n315#1:845,6\n326#1:852,6\n327#1:859,6\n341#1:865,6\n214#1:380\n214#1:381,6\n214#1:415\n214#1:419\n231#1:428\n231#1:429,5\n231#1:462\n231#1:472\n234#1:474,3\n234#1:505\n234#1:575\n264#1:597\n264#1:598,6\n264#1:632\n264#1:700\n283#1:702\n283#1:703,6\n283#1:737\n283#1:784\n312#1:800\n312#1:801,5\n312#1:834\n312#1:844\n348#1:872\n348#1:873,6\n348#1:907\n348#1:952\n214#1:387,6\n214#1:402,4\n214#1:412,2\n214#1:418\n231#1:434,6\n231#1:449,4\n231#1:459,2\n231#1:471\n234#1:477,6\n234#1:492,4\n234#1:502,2\n237#1:526,6\n237#1:541,4\n237#1:551,2\n237#1:570\n234#1:574\n264#1:604,6\n264#1:619,4\n264#1:629,2\n266#1:645,6\n266#1:660,4\n266#1:670,2\n266#1:689\n264#1:699\n283#1:709,6\n283#1:724,4\n283#1:734,2\n286#1:748,6\n286#1:763,4\n286#1:773,2\n286#1:779\n283#1:783\n312#1:806,6\n312#1:821,4\n312#1:831,2\n312#1:843\n348#1:879,6\n348#1:894,4\n348#1:904,2\n349#1:916,6\n349#1:931,4\n349#1:941,2\n349#1:947\n348#1:951\n214#1:393,9\n214#1:414\n214#1:416,2\n231#1:440,9\n231#1:461\n231#1:469,2\n234#1:483,9\n234#1:504\n237#1:532,9\n237#1:553\n237#1:568,2\n234#1:572,2\n264#1:610,9\n264#1:631\n266#1:651,9\n266#1:672\n266#1:687,2\n264#1:697,2\n283#1:715,9\n283#1:736\n286#1:754,9\n286#1:775\n286#1:777,2\n283#1:781,2\n312#1:812,9\n312#1:833\n312#1:841,2\n348#1:885,9\n348#1:906\n349#1:922,9\n349#1:943\n349#1:945,2\n348#1:949,2\n214#1:406,6\n231#1:453,6\n234#1:496,6\n237#1:545,6\n264#1:623,6\n266#1:664,6\n283#1:728,6\n286#1:767,6\n312#1:825,6\n348#1:898,6\n349#1:935,6\n237#1:518\n237#1:519,7\n237#1:554\n237#1:571\n266#1:639\n266#1:640,5\n266#1:673\n266#1:690\n286#1:740\n286#1:741,7\n286#1:776\n286#1:780\n349#1:908\n349#1:909,7\n349#1:944\n349#1:948\n201#1:953\n236#1:966\n236#1:967,2\n263#1:984\n263#1:985,2\n207#1:954,12\n250#1:969,12\n302#1:987,12\n328#1:999,12\n253#1:981,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000F\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0010\u000b\n\u0000\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0001\u00a2\u0006\u0002\u0010\u0004\u001aA\u0010\u0005\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\n2\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000c2\u0008\u0008\u0002\u0010\r\u001a\u00020\u000eH\u0001\u00a2\u0006\u0002\u0010\u000f\u001a#\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u000e2\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000cH\u0003\u00a2\u0006\u0002\u0010\u0012\u001a\u0019\u0010\u0013\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\t\u001a\u00020\nH\u0001\u00a2\u0006\u0002\u0010\u0014\u001a\u0019\u0010\u0015\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\t\u001a\u00020\nH\u0001\u00a2\u0006\u0002\u0010\u0014\u001a\u001d\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0002\u001a\u00020\u0003H\u0003\u00a2\u0006\u0002\u0010\u0019\u001a\u0010\u0010\u001a\u001a\u00020\u000e2\u0006\u0010\u001b\u001a\u00020\u000eH\u0002\u001a\u0015\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u001eH\u0003\u00a2\u0006\u0002\u0010\u001f\u001a\u0019\u0010 \u001a\u00020\u0001*\u00020\u00062\u0006\u0010\t\u001a\u00020\nH\u0001\u00a2\u0006\u0002\u0010\u0014\u001a\u0019\u0010!\u001a\u00020\u0001*\u00020\u00062\u0006\u0010\t\u001a\u00020\nH\u0001\u00a2\u0006\u0002\u0010\u0014\u001a\u001f\u0010\"\u001a\u00020\u00012\u0006\u0010#\u001a\u00020\u000e2\u0008\u0010$\u001a\u0004\u0018\u00010\u000eH\u0003\u00a2\u0006\u0002\u0010%\u00a8\u0006&\u00b2\u0006\n\u0010\'\u001a\u00020(X\u008a\u0084\u0002\u00b2\u0006\n\u0010)\u001a\u00020(X\u008a\u008e\u0002\u00b2\u0006\n\u0010)\u001a\u00020(X\u008a\u008e\u0002"
    }
    d2 = {
        "BrowseTabs",
        "",
        "browser",
        "Lorg/lighttouch/android/StoreBrowser;",
        "(Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V",
        "AppListing",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "listing",
        "Lorg/lighttouch/android/Listing;",
        "model",
        "Lorg/lighttouch/android/StoreModel;",
        "onRetry",
        "Lkotlin/Function0;",
        "empty",
        "",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V",
        "ErrorLine",
        "message",
        "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "FeaturedTab",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V",
        "ChartsTab",
        "SnapshotBar",
        "chart",
        "Lorg/lighttouch/android/StoreChart;",
        "(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V",
        "snapshotDate",
        "date",
        "GhostRow",
        "row",
        "Lorg/lighttouch/android/ChartRow;",
        "(Lorg/lighttouch/android/ChartRow;Landroidx/compose/runtime/Composer;I)V",
        "CategoriesTab",
        "CollectionsTab",
        "SectionHeader",
        "title",
        "subtitle",
        "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "atEnd",
        "",
        "menu"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$-g7Eo9OfBfdHb4W-oOohzIv7n0Y(Landroidx/compose/foundation/lazy/LazyListState;)Z
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing$lambda$3$lambda$2(Landroidx/compose/foundation/lazy/LazyListState;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$2SVklOvz_LebJJ4IIHfw_nde2O8(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$36$lambda$35(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$92vFs7Y4kIpS9HmQYm1TnenLUjA(Lorg/lighttouch/android/StoreCollection;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->CollectionsTab$lambda$82$lambda$81$lambda$75(Lorg/lighttouch/android/StoreCollection;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9IJzHyuy-3C44cXVR3i3wiCCAoI(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->SectionHeader$lambda$89(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9ekRIhiDHfm1hkB0Y4L0bbsdkuY(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$19$lambda$18(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$BX5o1jVNRnjU-vaE3OUcs36vpDQ(Lorg/lighttouch/android/StoreGenre;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab$lambda$64$lambda$63$lambda$59(Lorg/lighttouch/android/StoreGenre;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$EF2egkCeVICg3GA8uzkJbVG90ZU(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$27$lambda$26$lambda$25(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$EdoIbfjENWWvIu1UuEiloqcLxxY(Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing$lambda$9$lambda$8(Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Gt4J0siQQKylthe7jHjooQBuxFI(Ljava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->ErrorLine$lambda$12(Ljava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JHihBgAY6-DFq7UwAUWUBZF4wqQ(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab$lambda$58$lambda$57$lambda$56(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JlQbTDbTB4JVA9DYaGEcbtB9e7I(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$17$lambda$16$lambda$15(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$LK0UX2ZpGHaZyiNxn16ZaZclzSc(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p9}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing$lambda$10(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NP5OlwE4BRZDwJfu8HqeB3hsfng(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$31$lambda$30$lambda$29(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$PozL23RljMQ1egIwJbTk71sPZRY(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$37(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$QPz1H16F8ZzqJhH7oYiGZmdzgEk(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$27$lambda$24$lambda$23(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$SZENy7Pzvoa5MDNVbt5iZJ7Nu5k(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab$lambda$71$lambda$70(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TykWySeKY3IjFZ1iSPl0RitCklE(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->FeaturedTab$lambda$14(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$YaxHXccjNV7pgPyB7-LFQZE4cDM(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$51(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZTtWm2otbSHzswrSjoGKA_83NJA(Lorg/lighttouch/android/ChartRow;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$36$lambda$35$lambda$32(Lorg/lighttouch/android/ChartRow;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ajOhVNS45oNqx87Ejxt3w3JFqNg(Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreCollection;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowseKt;->CollectionsTab$lambda$84$lambda$83(Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreCollection;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$arVw7SJw1teMJ3goZ4PvQFFvAww(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab$lambda$72(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g3akbuSgMSyeB8k3OjwIt3CGb5E(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$50$lambda$42$lambda$41(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$gBd3pl9WoxU68GDq_JgKRHRD4N0(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab$lambda$69$lambda$68$lambda$67(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$l_QnZGYLBGN60EOVEyL8g51njqE(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$50$lambda$49$lambda$48(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$nxckIlncaOXsdHooG3fZSwrIJsg(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab$lambda$64$lambda$63(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$oIFMHLXb4QpIcKeDJghxF1zRvk8(Lorg/lighttouch/android/StoreBrowser;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreBrowseKt;->BrowseTabs$lambda$0(Lorg/lighttouch/android/StoreBrowser;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$oW9laTzjn5bdzLyaHI5xx3mgBeY(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreBrowseKt;->CollectionsTab$lambda$85(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rwBZAA5ys2hvs5gP_lNd1nIl0PY(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreBrowseKt;->CollectionsTab$lambda$82$lambda$81(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$syEMM_bWaorJlPGYJ_iqwsifXEU(Lorg/lighttouch/android/ChartRow;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreBrowseKt;->GhostRow$lambda$55(Lorg/lighttouch/android/ChartRow;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wijYQunn-v7hvqkFaTM36y3ERgc(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$50$lambda$47$lambda$46$lambda$45(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$yQAkoi2aPLtZ_bT3NMNDYyAqI0E(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$50$lambda$47$lambda$44$lambda$43(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final AppListing(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V
    .locals 36
    .param p0, "$this$AppListing"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "listing"    # Lorg/lighttouch/android/Listing;
    .param p2, "browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p3, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p4, "onRetry"    # Lkotlin/jvm/functions/Function0;
    .param p5, "empty"    # Ljava/lang/String;
    .param p6, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p7, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Lorg/lighttouch/android/Listing;",
            "Lorg/lighttouch/android/StoreBrowser;",
            "Lorg/lighttouch/android/StoreModel;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move-object/from16 v7, p2

    move-object/from16 v8, p3

    move-object/from16 v9, p4

    move/from16 v10, p7

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "listing"

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "browser"

    invoke-static {v7, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v8, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "onRetry"

    invoke-static {v9, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 199
    const v1, -0x250c9388

    move-object/from16 v2, p6

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(AppListing)P(2!1,3,4)200@9934L144,201@10138L60,201@10083L115,205@10754L199,205@10607L346:StoreBrowse.kt#o13vsk"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p7

    .local v2, "$dirty":I
    const/high16 v3, -0x80000000

    and-int v3, p8, v3

    if-eqz v3, :cond_0

    or-int/lit8 v2, v2, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v3, v10, 0x6

    if-nez v3, :cond_2

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_2
    :goto_1
    and-int/lit8 v3, p8, 0x1

    if-eqz v3, :cond_3

    or-int/lit8 v2, v2, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v3, v10, 0x30

    if-nez v3, :cond_5

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x20

    goto :goto_2

    :cond_4
    const/16 v3, 0x10

    :goto_2
    or-int/2addr v2, v3

    :cond_5
    :goto_3
    and-int/lit8 v3, p8, 0x2

    if-eqz v3, :cond_6

    or-int/lit16 v2, v2, 0x180

    goto :goto_5

    :cond_6
    and-int/lit16 v3, v10, 0x180

    if-nez v3, :cond_8

    invoke-interface {v15, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    const/16 v3, 0x100

    goto :goto_4

    :cond_7
    const/16 v3, 0x80

    :goto_4
    or-int/2addr v2, v3

    :cond_8
    :goto_5
    and-int/lit8 v3, p8, 0x4

    if-eqz v3, :cond_9

    or-int/lit16 v2, v2, 0xc00

    goto :goto_7

    :cond_9
    and-int/lit16 v3, v10, 0xc00

    if-nez v3, :cond_b

    invoke-interface {v15, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    const/16 v3, 0x800

    goto :goto_6

    :cond_a
    const/16 v3, 0x400

    :goto_6
    or-int/2addr v2, v3

    :cond_b
    :goto_7
    and-int/lit8 v3, p8, 0x8

    if-eqz v3, :cond_c

    or-int/lit16 v2, v2, 0x6000

    goto :goto_9

    :cond_c
    and-int/lit16 v3, v10, 0x6000

    if-nez v3, :cond_e

    invoke-interface {v15, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_d

    const/16 v3, 0x4000

    goto :goto_8

    :cond_d
    const/16 v3, 0x2000

    :goto_8
    or-int/2addr v2, v3

    :cond_e
    :goto_9
    and-int/lit8 v3, p8, 0x10

    const/high16 v4, 0x30000

    if-eqz v3, :cond_f

    or-int/2addr v2, v4

    move-object/from16 v4, p5

    goto :goto_b

    :cond_f
    and-int/2addr v4, v10

    if-nez v4, :cond_11

    move-object/from16 v4, p5

    invoke-interface {v15, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_10

    const/high16 v5, 0x20000

    goto :goto_a

    :cond_10
    const/high16 v5, 0x10000

    :goto_a
    or-int/2addr v2, v5

    goto :goto_b

    :cond_11
    move-object/from16 v4, p5

    :goto_b
    const v5, 0x12493

    and-int/2addr v5, v2

    const v11, 0x12492

    if-ne v5, v11, :cond_13

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_12

    goto :goto_c

    .line 206
    :cond_12
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v24, v2

    move-object/from16 v23, v4

    goto/16 :goto_15

    .line 199
    :cond_13
    :goto_c
    if-eqz v3, :cond_14

    const-string v3, "\u672a\u627e\u5230\u5e94\u7528\u3002"

    .end local p5    # "empty":Ljava/lang/String;
    .local v3, "empty":Ljava/lang/String;
    goto :goto_d

    .end local v3    # "empty":Ljava/lang/String;
    .restart local p5    # "empty":Ljava/lang/String;
    :cond_14
    move-object v3, v4

    .end local p5    # "empty":Ljava/lang/String;
    .restart local v3    # "empty":Ljava/lang/String;
    :goto_d
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_15

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.AppListing (StoreBrowse.kt:198)"

    invoke-static {v1, v2, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 200
    :cond_15
    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getListState()Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v1

    .local v1, "state":Landroidx/compose/foundation/lazy/LazyListState;
    const v4, 0x6e3c21fe

    invoke-interface {v15, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "CC(remember):StoreBrowse.kt#9igjgp"

    invoke-static {v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 201
    const/4 v5, 0x0

    .local v5, "invalid\\1":Z
    move-object v11, v15

    .local v11, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 357
    .local v12, "$i$f$cache\\1\\201":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\1":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 358
    .local v14, "$i$a$-let-ComposerKt$cache$1\\2\\357\\1":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v13, v0, :cond_16

    .line 359
    const/4 v0, 0x0

    .line 201
    .local v0, "$i$a$-cache-StoreBrowseKt$AppListing$atEnd$2\\3\\359\\0":I
    move/from16 p5, v0

    .end local v0    # "$i$a$-cache-StoreBrowseKt$AppListing$atEnd$2\\3\\359\\0":I
    .local p5, "$i$a$-cache-StoreBrowseKt$AppListing$atEnd$2\\3\\359\\0":I
    new-instance v0, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda18;

    invoke-direct {v0, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda18;-><init>(Landroidx/compose/foundation/lazy/LazyListState;)V

    invoke-static {v0}, Landroidx/compose/runtime/SnapshotStateKt;->derivedStateOf(Lkotlin/jvm/functions/Function0;)Landroidx/compose/runtime/State;

    move-result-object v0

    .line 359
    .end local p5    # "$i$a$-cache-StoreBrowseKt$AppListing$atEnd$2\\3\\359\\0":I
    nop

    .line 360
    .local v0, "value\\2":Ljava/lang/Object;
    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 361
    nop

    .end local v0    # "value\\2":Ljava/lang/Object;
    goto :goto_e

    .line 362
    :cond_16
    move-object v0, v13

    .line 358
    :goto_e
    nop

    .line 357
    .end local v13    # "it\\1":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\2\\357\\1":I
    nop

    .line 201
    .end local v5    # "invalid\\1":Z
    .end local v11    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\1\\201":I
    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "atEnd$delegate":Landroidx/compose/runtime/State;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 202
    invoke-static {v0}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing$lambda$4(Landroidx/compose/runtime/State;)Z

    move-result v5

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getRows()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getNext()Ljava/lang/String;

    move-result-object v13

    const v5, -0x6815fd56

    invoke-interface {v15, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    invoke-interface {v15, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    or-int/2addr v5, v14

    .local v5, "invalid\\4":Z
    move-object v14, v15

    .local v14, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 363
    .local v16, "$i$f$cache\\4\\202":I
    move-object/from16 p5, v1

    .end local v1    # "state":Landroidx/compose/foundation/lazy/LazyListState;
    .local p5, "state":Landroidx/compose/foundation/lazy/LazyListState;
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\4":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 364
    .local v17, "$i$a$-let-ComposerKt$cache$1\\5\\363\\4":I
    move/from16 p6, v2

    .end local v2    # "$dirty":I
    .local p6, "$dirty":I
    if-nez v5, :cond_18

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_17

    goto :goto_f

    .line 368
    :cond_17
    move-object/from16 v18, v1

    goto :goto_10

    .line 365
    :cond_18
    :goto_f
    const/4 v2, 0x0

    .line 202
    .local v2, "$i$a$-cache-StoreBrowseKt$AppListing$1\\6\\365\\0":I
    move-object/from16 v18, v1

    .end local v1    # "it\\4":Ljava/lang/Object;
    .local v18, "it\\4":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/StoreBrowseKt$AppListing$1$1;

    move/from16 v20, v2

    const/4 v2, 0x0

    .end local v2    # "$i$a$-cache-StoreBrowseKt$AppListing$1\\6\\365\\0":I
    .local v20, "$i$a$-cache-StoreBrowseKt$AppListing$1\\6\\365\\0":I
    invoke-direct {v1, v6, v7, v0, v2}, Lorg/lighttouch/android/StoreBrowseKt$AppListing$1$1;-><init>(Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/State;Lkotlin/coroutines/Continuation;)V

    check-cast v1, Lkotlin/jvm/functions/Function2;

    .line 365
    .end local v20    # "$i$a$-cache-StoreBrowseKt$AppListing$1\\6\\365\\0":I
    nop

    .line 366
    .local v1, "value\\5":Ljava/lang/Object;
    invoke-interface {v14, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 367
    nop

    .line 364
    .end local v1    # "value\\5":Ljava/lang/Object;
    :goto_10
    nop

    .line 363
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\5\\363\\4":I
    .end local v18    # "it\\4":Ljava/lang/Object;
    nop

    .line 202
    .end local v5    # "invalid\\4":Z
    .end local v14    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$f$cache\\4\\202":I
    move-object v14, v1

    check-cast v14, Lkotlin/jvm/functions/Function2;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v16, 0x0

    invoke-static/range {v11 .. v16}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    const v1, -0x1435945c

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "202@10250L93"

    invoke-static {v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 203
    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getLoading()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getRows()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_19

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v11, 0x0

    invoke-static {v1, v2, v5, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x10

    .local v2, "$this$dp\\7":I
    const/4 v5, 0x0

    .line 369
    .local v5, "$i$f$getDp\\7\\203":I
    int-to-float v11, v2

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 203
    .end local v2    # "$this$dp\\7":I
    .end local v5    # "$i$f$getDp\\7\\203":I
    const/16 v5, 0x8

    .local v5, "$this$dp\\8":I
    const/4 v11, 0x0

    .line 369
    .local v11, "$i$f$getDp\\8\\203":I
    int-to-float v12, v5

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 203
    .end local v5    # "$this$dp\\8":I
    .end local v11    # "$i$f$getDp\\8\\203":I
    invoke-static {v1, v2, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/16 v19, 0x6

    const/16 v20, 0x1e

    const-wide/16 v12, 0x0

    move-object/from16 v32, v15

    .end local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .local v32, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v18, v32

    .end local v32    # "$composer":Landroidx/compose/runtime/Composer;
    .local v18, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v20}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v15, v18

    .end local v18    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v15    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_19
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 204
    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getError()Ljava/lang/String;

    move-result-object v1

    const v2, -0x143580ca

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*203@10369L22"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v1, :cond_1a

    goto :goto_11

    .line 370
    .local v1, "it\\9":Ljava/lang/String;
    :cond_1a
    const/4 v2, 0x0

    .line 204
    .local v2, "$i$a$-let-StoreBrowseKt$AppListing$2\\9\\204\\0":I
    shr-int/lit8 v5, p6, 0x9

    and-int/lit8 v5, v5, 0x70

    invoke-static {v1, v9, v15, v5}, Lorg/lighttouch/android/StoreBrowseKt;->ErrorLine(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .end local v1    # "it\\9":Ljava/lang/String;
    .end local v2    # "$i$a$-let-StoreBrowseKt$AppListing$2\\9\\204\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_11
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v1, -0x14357bbc

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "204@10528L10,204@10573L11,204@10469L133"

    invoke-static {v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 205
    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getLoaded()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getRows()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-virtual {v6}, Lorg/lighttouch/android/Listing;->getError()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1b

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x10

    .local v2, "$this$dp\\10":I
    const/4 v5, 0x0

    .line 371
    .local v5, "$i$f$getDp\\10\\205":I
    int-to-float v11, v2

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 205
    .end local v2    # "$this$dp\\10":I
    .end local v5    # "$i$f$getDp\\10\\205":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v12

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v15, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v31

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v15, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v13

    shr-int/lit8 v1, p6, 0xf

    and-int/lit8 v1, v1, 0xe

    or-int/lit8 v33, v1, 0x30

    const/16 v34, 0x0

    const v35, 0xfff8

    move-object/from16 v32, v15

    .end local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v32    # "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const-wide/16 v20, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    move-object v11, v3

    .end local v3    # "empty":Ljava/lang/String;
    .local v11, "empty":Ljava/lang/String;
    invoke-static/range {v11 .. v35}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v23, v11

    move-object/from16 v15, v32

    .end local v11    # "empty":Ljava/lang/String;
    .end local v32    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .local v23, "empty":Ljava/lang/String;
    goto :goto_12

    .end local v23    # "empty":Ljava/lang/String;
    .restart local v3    # "empty":Ljava/lang/String;
    :cond_1b
    move-object/from16 v23, v3

    .end local v3    # "empty":Ljava/lang/String;
    .restart local v23    # "empty":Ljava/lang/String;
    :goto_12
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 206
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    move-object v2, v4

    const/4 v4, 0x2

    const/4 v5, 0x0

    move-object v3, v2

    const/high16 v2, 0x3f800000    # 1.0f

    move-object v11, v3

    const/4 v3, 0x0

    move-object/from16 v12, p5

    move/from16 v24, p6

    move-object/from16 v25, v0

    move-object/from16 v0, p0

    .end local v0    # "atEnd$delegate":Landroidx/compose/runtime/State;
    .end local p5    # "state":Landroidx/compose/foundation/lazy/LazyListState;
    .end local p6    # "$dirty":I
    .local v12, "state":Landroidx/compose/foundation/lazy/LazyListState;
    .local v24, "$dirty":I
    .local v25, "atEnd$delegate":Landroidx/compose/runtime/State;
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v0, "store_browse_results"

    invoke-static {v1, v0}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x8

    .local v1, "$this$dp\\11":I
    const/4 v2, 0x0

    .line 372
    .local v2, "$i$f$getDp\\11\\206":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 206
    .end local v1    # "$this$dp\\11":I
    .end local v2    # "$i$f$getDp\\11\\206":I
    const/4 v2, 0x4

    .local v2, "$this$dp\\12":I
    const/4 v3, 0x0

    .line 372
    .local v3, "$i$f$getDp\\12\\206":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 206
    .end local v2    # "$this$dp\\12":I
    .end local v3    # "$i$f$getDp\\12\\206":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v13

    const v1, -0x615d173a

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v15, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v1, v2

    .local v1, "invalid\\13":Z
    move-object v2, v15

    .local v2, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 373
    .local v3, "$i$f$cache\\13\\206":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\13":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 374
    .local v5, "$i$a$-let-ComposerKt$cache$1\\14\\373\\13":I
    if-nez v1, :cond_1d

    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v4, v11, :cond_1c

    goto :goto_13

    .line 378
    :cond_1c
    move-object v14, v4

    goto :goto_14

    .line 375
    :cond_1d
    :goto_13
    const/4 v11, 0x0

    .line 206
    .local v11, "$i$a$-cache-StoreBrowseKt$AppListing$3\\15\\375\\0":I
    new-instance v14, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda19;

    invoke-direct {v14, v6, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda19;-><init>(Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreModel;)V

    .line 375
    .end local v11    # "$i$a$-cache-StoreBrowseKt$AppListing$3\\15\\375\\0":I
    nop

    .line 376
    .local v14, "value\\14":Ljava/lang/Object;
    invoke-interface {v2, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 377
    nop

    .line 374
    .end local v14    # "value\\14":Ljava/lang/Object;
    :goto_14
    nop

    .line 373
    .end local v4    # "it\\13":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\14\\373\\13":I
    nop

    .line 206
    .end local v1    # "invalid\\13":Z
    .end local v2    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\13\\206":I
    move-object/from16 v19, v14

    check-cast v19, Lkotlin/jvm/functions/Function1;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v21, 0x180

    const/16 v22, 0xf8

    const/4 v14, 0x0

    move-object/from16 v32, v15

    .end local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v32    # "$composer":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object v11, v0

    move-object/from16 v20, v32

    .end local v32    # "$composer":Landroidx/compose/runtime/Composer;
    .local v20, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v22}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v15, v20

    .end local v20    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v15    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v12    # "state":Landroidx/compose/foundation/lazy/LazyListState;
    .end local v25    # "atEnd$delegate":Landroidx/compose/runtime/State;
    :cond_1e
    :goto_15
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_1f

    new-instance v0, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda20;

    move-object/from16 v1, p0

    move-object v2, v6

    move-object v3, v7

    move-object v4, v8

    move-object v5, v9

    move v7, v10

    move-object/from16 v6, v23

    move/from16 v8, p8

    .end local v23    # "empty":Ljava/lang/String;
    .local v6, "empty":Ljava/lang/String;
    invoke-direct/range {v0 .. v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda20;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;II)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_16

    .end local v6    # "empty":Ljava/lang/String;
    .restart local v23    # "empty":Ljava/lang/String;
    :cond_1f
    move-object/from16 v6, v23

    .line 210
    .end local v23    # "empty":Ljava/lang/String;
    .restart local v6    # "empty":Ljava/lang/String;
    :goto_16
    return-void
.end method

.method private static final AppListing$lambda$10(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 10

    or-int/lit8 v0, p6, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v8

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move/from16 v9, p7

    move-object/from16 v7, p8

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AppListing$lambda$3$lambda$2(Landroidx/compose/foundation/lazy/LazyListState;)Z
    .locals 6
    .param p0, "$state"    # Landroidx/compose/foundation/lazy/LazyListState;

    .line 201
    invoke-virtual {p0}, Landroidx/compose/foundation/lazy/LazyListState;->getLayoutInfo()Landroidx/compose/foundation/lazy/LazyListLayoutInfo;

    move-result-object v0

    invoke-interface {v0}, Landroidx/compose/foundation/lazy/LazyListLayoutInfo;->getVisibleItemsInfo()Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->lastOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/foundation/lazy/LazyListItemInfo;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    .line 370
    .local v0, "it\\1":Landroidx/compose/foundation/lazy/LazyListItemInfo;
    const/4 v2, 0x0

    .line 201
    .local v2, "$i$a$-let-StoreBrowseKt$AppListing$atEnd$2$1$1\\1\\201\\0":I
    invoke-interface {v0}, Landroidx/compose/foundation/lazy/LazyListItemInfo;->getIndex()I

    move-result v3

    invoke-virtual {p0}, Landroidx/compose/foundation/lazy/LazyListState;->getLayoutInfo()Landroidx/compose/foundation/lazy/LazyListLayoutInfo;

    move-result-object v4

    invoke-interface {v4}, Landroidx/compose/foundation/lazy/LazyListLayoutInfo;->getTotalItemsCount()I

    move-result v4

    add-int/lit8 v4, v4, -0x5

    const/4 v5, 0x1

    if-lt v3, v4, :cond_0

    move v0, v5

    goto :goto_0

    :cond_0
    move v0, v1

    .end local v0    # "it\\1":Landroidx/compose/foundation/lazy/LazyListItemInfo;
    .end local v2    # "$i$a$-let-StoreBrowseKt$AppListing$atEnd$2$1$1\\1\\201\\0":I
    :goto_0
    if-ne v0, v5, :cond_1

    move v1, v5

    :cond_1
    return v1
.end method

.method private static final AppListing$lambda$4(Landroidx/compose/runtime/State;)Z
    .locals 4
    .param p0, "$atEnd$delegate"    # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 201
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 953
    .local v3, "$i$f$getValue\\1\\201":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3    # "$i$f$getValue\\1\\201":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 201
    return v0
.end method

.method private static final AppListing$lambda$9$lambda$8(Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 10
    .param p0, "$listing"    # Lorg/lighttouch/android/Listing;
    .param p1, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 207
    invoke-virtual {p0}, Lorg/lighttouch/android/Listing;->getRows()Ljava/util/List;

    move-result-object v0

    .local v0, "items\\1":Ljava/util/List;
    move-object v1, p2

    .line 954
    .local v1, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 956
    const/4 v2, 0x0

    .line 954
    .local v2, "key\\1":Lkotlin/jvm/functions/Function1;
    nop

    .line 957
    sget-object v3, Lorg/lighttouch/android/StoreBrowseKt$AppListing$lambda$9$lambda$8$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreBrowseKt$AppListing$lambda$9$lambda$8$$inlined$items$default$1;

    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 954
    .local v3, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v4, 0x0

    .line 959
    .local v4, "$i$f$items\\1\\207":I
    nop

    .line 960
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    .line 961
    nop

    .line 959
    new-instance v6, Lorg/lighttouch/android/StoreBrowseKt$AppListing$lambda$9$lambda$8$$inlined$items$default$3;

    invoke-direct {v6, v3, v0}, Lorg/lighttouch/android/StoreBrowseKt$AppListing$lambda$9$lambda$8$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 963
    new-instance v7, Lorg/lighttouch/android/StoreBrowseKt$AppListing$lambda$9$lambda$8$$inlined$items$default$4;

    invoke-direct {v7, v0, p1}, Lorg/lighttouch/android/StoreBrowseKt$AppListing$lambda$9$lambda$8$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    const v8, -0x25b7f321

    const/4 v9, 0x1

    invoke-static {v8, v9, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function4;

    .line 959
    const/4 v8, 0x0

    invoke-interface {v1, v5, v8, v6, v7}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 965
    nop

    .line 208
    .end local v0    # "items\\1":Ljava/util/List;
    .end local v1    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v2    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v3    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v4    # "$i$f$items\\1\\207":I
    invoke-virtual {p0}, Lorg/lighttouch/android/Listing;->getLoading()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/Listing;->getRows()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$-1131248729$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p2

    .end local p2    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .local v1, "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    goto :goto_0

    .end local v1    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .restart local p2    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    :cond_0
    move-object v1, p2

    .line 209
    .end local p2    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .restart local v1    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    :goto_0
    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p2
.end method

.method public static final BrowseTabs(Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V
    .locals 17
    .param p0, "browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    move/from16 v1, p2

    const-string v2, "browser"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 191
    const v2, -0x123be802

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(BrowseTabs)191@9465L186,191@9296L355:StoreBrowse.kt#o13vsk"

    invoke-static {v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 192
    :cond_2
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v2, v3

    goto :goto_2

    .line 191
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.BrowseTabs (StoreBrowse.kt:190)"

    invoke-static {v2, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 192
    :cond_4
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreBrowser;->getTab()Lorg/lighttouch/android/StoreTab;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreTab;->ordinal()I

    move-result v2

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const-string v5, "store_tabs"

    invoke-static {v4, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v5, 0x8

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 356
    .local v6, "$i$f$getDp\\1\\192":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 192
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\192":I
    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v5

    sget-object v7, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v7}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$-1449609315$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    new-instance v7, Lorg/lighttouch/android/StoreBrowseKt$BrowseTabs$1;

    invoke-direct {v7, v0}, Lorg/lighttouch/android/StoreBrowseKt$BrowseTabs$1;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    const/16 v8, 0x36

    const v10, -0x1300d922

    const/4 v12, 0x1

    invoke-static {v10, v12, v7, v13, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    move-object v12, v7

    check-cast v12, Lkotlin/jvm/functions/Function2;

    const v14, 0xd861b0

    const/16 v15, 0x28

    const-wide/16 v7, 0x0

    const/4 v10, 0x0

    move/from16 v16, v3

    move v3, v2

    move/from16 v2, v16

    .end local v3    # "$dirty":I
    .local v2, "$dirty":I
    invoke-static/range {v3 .. v15}, Landroidx/compose/material3/TabRowKt;->ScrollableTabRow-sKfQg0A(ILandroidx/compose/ui/Modifier;JJFLkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_5
    :goto_2
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_6

    new-instance v4, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda10;

    invoke-direct {v4, v0, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/StoreBrowser;I)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 195
    :cond_6
    return-void
.end method

.method private static final BrowseTabs$lambda$0(Lorg/lighttouch/android/StoreBrowser;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/StoreBrowseKt;->BrowseTabs(Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final CategoriesTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 53
    .param p0, "$this$CategoriesTab"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move/from16 v9, p3

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 294
    const v1, 0x381a03fa

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(CategoriesTab):StoreBrowse.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p3

    .local v3, "$dirty":I
    and-int/lit8 v4, v9, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_3

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_1

    :cond_2
    const/16 v4, 0x10

    :goto_1
    or-int/2addr v3, v4

    :cond_3
    move v7, v3

    .end local v3    # "$dirty":I
    .local v7, "$dirty":I
    and-int/lit8 v3, v7, 0x13

    const/16 v4, 0x12

    if-ne v3, v4, :cond_5

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    .line 310
    :cond_4
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v17, v2

    move-object v3, v6

    move v10, v7

    goto/16 :goto_15

    .line 294
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_6

    const/4 v3, -0x1

    const-string v4, "org.lighttouch.android.CategoriesTab (StoreBrowse.kt:293)"

    invoke-static {v1, v7, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 295
    :cond_6
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getBrowser()Lorg/lighttouch/android/StoreBrowser;

    move-result-object v8

    .line 296
    .local v8, "browser":Lorg/lighttouch/android/StoreBrowser;
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCategory()Lorg/lighttouch/android/StoreGenre;

    move-result-object v22

    .line 297
    .local v22, "category":Lorg/lighttouch/android/StoreGenre;
    const/4 v3, 0x0

    const v4, 0x4c5de2

    const/4 v10, 0x0

    const-string v11, "CC(remember):StoreBrowse.kt#9igjgp"

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-nez v22, :cond_d

    const v5, -0x64883ed9

    invoke-interface {v2, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "300@16725L589,300@16570L744"

    invoke-static {v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 298
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getGenres()Ljava/util/List;

    move-result-object v5

    .local v5, "genres":Ljava/util/List;
    const v14, -0x6656f776

    invoke-interface {v2, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v14, "298@16392L93"

    invoke-static {v2, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 299
    if-nez v5, :cond_7

    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getGenresError()Ljava/lang/String;

    move-result-object v14

    if-nez v14, :cond_7

    sget-object v14, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v14, Landroidx/compose/ui/Modifier;

    invoke-static {v14, v3, v12, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v10, 0x10

    .local v10, "$this$dp\\1":I
    const/4 v12, 0x0

    .line 785
    .local v12, "$i$f$getDp\\1\\299":I
    int-to-float v14, v10

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 299
    .end local v10    # "$this$dp\\1":I
    .end local v12    # "$i$f$getDp\\1\\299":I
    const/16 v12, 0x8

    .local v12, "$this$dp\\2":I
    const/4 v14, 0x0

    .line 785
    .local v14, "$i$f$getDp\\2\\299":I
    int-to-float v15, v12

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 299
    .end local v12    # "$this$dp\\2":I
    .end local v14    # "$i$f$getDp\\2\\299":I
    invoke-static {v3, v10, v12}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v10

    const/16 v18, 0x6

    const/16 v19, 0x1e

    move-object v3, v11

    const-wide/16 v11, 0x0

    move v15, v13

    const-wide/16 v13, 0x0

    move/from16 v16, v15

    const/4 v15, 0x0

    move/from16 v17, v16

    const/16 v16, 0x0

    move/from16 v52, v17

    move-object/from16 v17, v2

    move/from16 v2, v52

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v19}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v10, v17

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_3

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_7
    move-object v10, v2

    move-object v3, v11

    move v2, v13

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    :goto_3
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 300
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getGenresError()Ljava/lang/String;

    move-result-object v11

    const v12, -0x6656e218

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "*299@16535L24,299@16521L38"

    invoke-static {v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v11, :cond_8

    goto :goto_6

    .line 370
    .local v11, "it\\3":Ljava/lang/String;
    :cond_8
    const/4 v12, 0x0

    .line 300
    .local v12, "$i$a$-let-StoreBrowseKt$CategoriesTab$1\\3\\300\\0":I
    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    .local v4, "invalid\\4":Z
    move-object v13, v10

    .local v13, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 786
    .local v14, "$i$f$cache\\4\\300":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 787
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\786\\4":I
    if-nez v4, :cond_a

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v15, v1, :cond_9

    goto :goto_4

    .line 791
    :cond_9
    move-object v2, v15

    goto :goto_5

    .line 788
    :cond_a
    :goto_4
    const/4 v1, 0x0

    .line 300
    .local v1, "$i$a$-cache-StoreBrowseKt$CategoriesTab$1$1\\6\\788\\3":I
    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda5;

    invoke-direct {v2, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    .line 788
    .end local v1    # "$i$a$-cache-StoreBrowseKt$CategoriesTab$1$1\\6\\788\\3":I
    nop

    .line 789
    .local v2, "value\\5":Ljava/lang/Object;
    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 790
    nop

    .line 787
    .end local v2    # "value\\5":Ljava/lang/Object;
    :goto_5
    nop

    .line 786
    .end local v15    # "it\\4":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\5\\786\\4":I
    nop

    .line 300
    .end local v4    # "invalid\\4":Z
    .end local v13    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\4\\300":I
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v15, 0x0

    invoke-static {v11, v2, v10, v15}, Lorg/lighttouch/android/StoreBrowseKt;->ErrorLine(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .end local v11    # "it\\3":Ljava/lang/String;
    .end local v12    # "$i$a$-let-StoreBrowseKt$CategoriesTab$1\\3\\300\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_6
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 301
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    move-object v2, v5

    .end local v5    # "genres":Ljava/util/List;
    .local v2, "genres":Ljava/util/List;
    const/4 v5, 0x0

    move-object v11, v2

    .end local v2    # "genres":Ljava/util/List;
    .local v11, "genres":Ljava/util/List;
    const/high16 v2, 0x3f800000    # 1.0f

    move-object v12, v3

    const/4 v3, 0x0

    move-object v14, v12

    const v13, -0x615d173a

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v0, "store_categories"

    invoke-static {v1, v0}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getGenreList()Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v1

    const/16 v2, 0x8

    .local v2, "$this$dp\\7":I
    const/4 v3, 0x0

    .line 792
    .local v3, "$i$f$getDp\\7\\301":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 301
    .end local v2    # "$this$dp\\7":I
    .end local v3    # "$i$f$getDp\\7\\301":I
    const/4 v3, 0x4

    .local v3, "$this$dp\\8":I
    const/4 v4, 0x0

    .line 792
    .local v4, "$i$f$getDp\\8\\301":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 301
    .end local v3    # "$this$dp\\8":I
    .end local v4    # "$i$f$getDp\\8\\301":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v12

    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\9":Z
    move-object v3, v10

    .local v3, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 793
    .local v4, "$i$f$cache\\9\\301":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\9":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 794
    .local v13, "$i$a$-let-ComposerKt$cache$1\\10\\793\\9":I
    if-nez v2, :cond_c

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v5, v14, :cond_b

    goto :goto_7

    .line 798
    :cond_b
    move-object v15, v5

    goto :goto_8

    .line 795
    :cond_c
    :goto_7
    const/4 v14, 0x0

    .line 301
    .local v14, "$i$a$-cache-StoreBrowseKt$CategoriesTab$2\\11\\795\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda6;

    invoke-direct {v15, v11, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda6;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;)V

    .line 795
    .end local v14    # "$i$a$-cache-StoreBrowseKt$CategoriesTab$2\\11\\795\\0":I
    nop

    .line 796
    .local v15, "value\\10":Ljava/lang/Object;
    invoke-interface {v3, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 797
    nop

    .line 794
    .end local v15    # "value\\10":Ljava/lang/Object;
    :goto_8
    nop

    .line 793
    .end local v5    # "it\\9":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\10\\793\\9":I
    nop

    .line 301
    .end local v2    # "invalid\\9":Z
    .end local v3    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\9\\301":I
    move-object/from16 v18, v15

    check-cast v18, Lkotlin/jvm/functions/Function1;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v20, 0x180

    const/16 v21, 0xf8

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v19, v10

    move-object v2, v11

    move-object v10, v0

    move-object v11, v1

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v11    # "genres":Ljava/util/List;
    .local v2, "genres":Ljava/util/List;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v21}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 297
    move-object/from16 v0, v19

    .end local v2    # "genres":Ljava/util/List;
    .end local v19    # "$composer":Landroidx/compose/runtime/Composer;
    .local v0, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v17, v0

    move-object v3, v6

    move v10, v7

    move-object v2, v8

    move-object/from16 v0, p0

    goto/16 :goto_14

    .line 310
    .end local v0    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    :cond_d
    move-object v0, v2

    move-object v14, v11

    const v13, -0x615d173a

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v0    # "$composer":Landroidx/compose/runtime/Composer;
    const v1, -0x6478e045

    invoke-interface {v0, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "310@17336L94,311@17469L21,311@17439L297,314@17794L50,314@17745L100"

    invoke-static {v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 311
    invoke-virtual/range {v22 .. v22}, Lorg/lighttouch/android/StoreGenre;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCategoryApps()Lorg/lighttouch/android/Listing;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/Listing;->getTotal()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object v11, v2

    check-cast v11, Ljava/lang/Number;

    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    move-result v11

    .line 370
    nop

    .local v11, "it\\12":I
    const/4 v15, 0x0

    .line 311
    .local v15, "$i$a$-takeIf-StoreBrowseKt$CategoriesTab$3\\12\\311\\0":I
    if-lez v11, :cond_e

    move v11, v12

    goto :goto_9

    :cond_e
    const/4 v11, 0x0

    .end local v11    # "it\\12":I
    .end local v15    # "$i$a$-takeIf-StoreBrowseKt$CategoriesTab$3\\12\\311\\0":I
    :goto_9
    if-eqz v11, :cond_f

    goto :goto_a

    :cond_f
    move-object v2, v10

    :goto_a
    if-eqz v2, :cond_10

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .line 370
    nop

    .local v2, "it\\13":I
    const/4 v11, 0x0

    .line 311
    .local v11, "$i$a$-let-StoreBrowseKt$CategoriesTab$4\\13\\311\\0":I
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v4, " \u4e2a\u5e94\u7528"

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .end local v2    # "it\\13":I
    .end local v11    # "$i$a$-let-StoreBrowseKt$CategoriesTab$4\\13\\311\\0":I
    goto :goto_b

    :cond_10
    move-object v2, v10

    :goto_b
    const/4 v15, 0x0

    invoke-static {v1, v2, v0, v15}, Lorg/lighttouch/android/StoreBrowseKt;->SectionHeader(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 312
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v23, v1

    check-cast v23, Landroidx/compose/ui/Modifier;

    invoke-static {v15, v0, v15, v12}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v24

    const/16 v28, 0xe

    const/16 v29, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    invoke-static/range {v23 .. v29}, Landroidx/compose/foundation/ScrollKt;->horizontalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x10

    .local v2, "$this$dp\\14":I
    const/4 v4, 0x0

    .line 799
    .local v4, "$i$f$getDp\\14\\312":I
    int-to-float v11, v2

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 312
    .end local v2    # "$this$dp\\14":I
    .end local v4    # "$i$f$getDp\\14\\312":I
    invoke-static {v1, v2, v3, v5, v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v3, 0x8

    .local v3, "$this$dp\\15":I
    const/4 v4, 0x0

    .line 799
    .local v4, "$i$f$getDp\\15\\312":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 312
    .end local v3    # "$this$dp\\15":I
    .end local v4    # "$i$f$getDp\\15\\312":I
    invoke-virtual {v2, v3}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v2, "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v3, 0x30

    .local v1, "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v3, "$changed\\16":I
    const/4 v4, 0x0

    .line 800
    .local v4, "$i$f$Row\\16\\312":I
    const v5, 0x2952b718

    const-string v10, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v0, v5, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 801
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 804
    .local v5, "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v10, v3, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v2, v5, v0, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 805
    nop

    .local v11, "$changed\\17":I
    const/4 v15, 0x0

    .line 806
    .local v15, "$i$f$Layout\\17\\805":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v0, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 807
    const/4 v12, 0x0

    invoke-static {v0, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v12

    .line 808
    .local v12, "compositeKeyHash\\17":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 809
    .local v13, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v17, v2

    .end local v2    # "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v17, "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v0, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 811
    .local v2, "materialized\\17":Landroidx/compose/ui/Modifier;
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v19

    move-object/from16 v20, v1

    .end local v1    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\16":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v11, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 810
    nop

    .local v1, "$changed\\18":I
    move-object/from16 v21, v19

    .local v21, "factory\\18":Lkotlin/jvm/functions/Function0;
    const/16 v19, 0x0

    .line 812
    .local v19, "$i$f$ReusableComposeNode\\18\\810":I
    move/from16 v23, v1

    .end local v1    # "$changed\\18":I
    .local v23, "$changed\\18":I
    const v1, -0x2942ffcf

    move/from16 v24, v3

    .end local v3    # "$changed\\16":I
    .local v24, "$changed\\16":I
    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 813
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 814
    :cond_11
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 815
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_12

    .line 816
    move-object/from16 v1, v21

    .end local v21    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v0, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 818
    .end local v1    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v21    # "factory\\18":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v1, v21

    .end local v21    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 820
    :goto_c
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 821
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\820\\17":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v26, v1

    .end local v1    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v26, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v3, v10, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 822
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v3, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 824
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\20":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 825
    .local v25, "$i$f$set-impl\\20\\824":I
    move-object/from16 v27, v3

    .local v27, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 826
    .local v28, "$i$a$-with-Updater$set$1\\21\\825\\20":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v29

    if-nez v29, :cond_14

    move/from16 v29, v4

    .end local v4    # "$i$f$Row\\16\\312":I
    .local v29, "$i$f$Row\\16\\312":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v30, v5

    .end local v5    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .local v30, "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_13

    goto :goto_d

    :cond_13
    move-object/from16 v5, v27

    goto :goto_e

    .end local v29    # "$i$f$Row\\16\\312":I
    .end local v30    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v4    # "$i$f$Row\\16\\312":I
    .restart local v5    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    :cond_14
    move/from16 v29, v4

    move-object/from16 v30, v5

    .line 827
    .end local v4    # "$i$f$Row\\16\\312":I
    .end local v5    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v29    # "$i$f$Row\\16\\312":I
    .restart local v30    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    :goto_d
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 828
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 830
    :goto_e
    nop

    .line 825
    .end local v5    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-with-Updater$set$1\\21\\825\\20":I
    nop

    .line 830
    nop

    .line 831
    .end local v1    # "block\\20":Lkotlin/jvm/functions/Function2;
    .end local v25    # "$i$f$set-impl\\20\\824":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v3, v2, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 832
    nop

    .line 820
    .end local v3    # "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\820\\17":I
    nop

    .line 833
    shr-int/lit8 v1, v23, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\22":I
    move-object v3, v0

    .local v3, "$composer\\22":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 834
    .local v4, "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    const v5, -0x184f2606

    move/from16 v21, v1

    .end local v1    # "$changed\\22":I
    .local v21, "$changed\\22":I
    const-string v1, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v24, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\23":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$CategoriesTab_u24lambda_u2469\\23":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v43, v3

    .local v43, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 313
    .local v25, "$i$a$-Row-StoreBrowseKt$CategoriesTab$5\\23\\834\\0":I
    move-object/from16 v27, v1

    .end local v1    # "$this$CategoriesTab_u24lambda_u2469\\23":Landroidx/compose/foundation/layout/RowScope;
    .local v27, "$this$CategoriesTab_u24lambda_u2469\\23":Landroidx/compose/foundation/layout/RowScope;
    const v1, -0x5584661a

    move-object/from16 v28, v2

    .end local v2    # "materialized\\17":Landroidx/compose/ui/Modifier;
    .local v28, "materialized\\17":Landroidx/compose/ui/Modifier;
    const-string v2, "C:StoreBrowse.kt#o13vsk"

    move-object/from16 v47, v3

    .end local v43    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v47, "$composer\\22":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v1, 0x26881dbd

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "*312@17666L34,312@17710L15,312@17625L101"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Lorg/lighttouch/android/LegacyStoreKt;->getCATEGORY_SORTS()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_17

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkotlin/Pair;

    invoke-virtual {v2}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v31

    move-object/from16 v48, v1

    move-object/from16 v1, v31

    check-cast v1, Ljava/lang/String;

    .local v1, "sort\\23":Ljava/lang/String;
    invoke-virtual {v2}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    move/from16 v49, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    .local v2, "title\\23":Ljava/lang/String;
    .local v49, "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCategorySort()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v31

    const v4, -0x615d173a

    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v18

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v32

    or-int v18, v18, v32

    .local v18, "invalid\\24":Z
    move-object/from16 v32, v3

    .local v32, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 835
    .local v33, "$i$f$cache\\24\\313":I
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\24":Ljava/lang/Object;
    const/16 v34, 0x0

    .line 836
    .local v34, "$i$a$-let-ComposerKt$cache$1\\25\\835\\24":I
    if-nez v18, :cond_16

    sget-object v35, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v50, v5

    .end local v5    # "$changed\\23":I
    .local v50, "$changed\\23":I
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_15

    goto :goto_10

    .line 840
    :cond_15
    move-object/from16 v35, v4

    move-object/from16 v5, v32

    goto :goto_11

    .line 836
    .end local v50    # "$changed\\23":I
    .restart local v5    # "$changed\\23":I
    :cond_16
    move/from16 v50, v5

    .line 837
    .end local v5    # "$changed\\23":I
    .restart local v50    # "$changed\\23":I
    :goto_10
    const/4 v5, 0x0

    .line 313
    .local v5, "$i$a$-cache-StoreBrowseKt$CategoriesTab$5$1\\26\\837\\23":I
    move-object/from16 v35, v4

    .end local v4    # "it\\24":Ljava/lang/Object;
    .local v35, "it\\24":Ljava/lang/Object;
    new-instance v4, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda7;

    invoke-direct {v4, v8, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)V

    .line 837
    .end local v5    # "$i$a$-cache-StoreBrowseKt$CategoriesTab$5$1\\26\\837\\23":I
    nop

    .line 838
    .local v4, "value\\25":Ljava/lang/Object;
    move-object/from16 v5, v32

    .end local v32    # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .local v5, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 839
    nop

    .line 836
    .end local v4    # "value\\25":Ljava/lang/Object;
    :goto_11
    nop

    .line 835
    .end local v34    # "$i$a$-let-ComposerKt$cache$1\\25\\835\\24":I
    .end local v35    # "it\\24":Ljava/lang/Object;
    nop

    .line 313
    .end local v5    # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .end local v18    # "invalid\\24":Z
    .end local v33    # "$i$f$cache\\24\\313":I
    move-object/from16 v32, v4

    check-cast v32, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v4, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$5$2;

    invoke-direct {v4, v2}, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$5$2;-><init>(Ljava/lang/String;)V

    const/16 v5, 0x36

    move-object/from16 v18, v1

    .end local v1    # "sort\\23":Ljava/lang/String;
    .local v18, "sort\\23":Ljava/lang/String;
    const v1, -0x641719a8

    move-object/from16 v51, v2

    const/4 v2, 0x1

    .end local v2    # "title\\23":Ljava/lang/String;
    .local v51, "title\\23":Ljava/lang/String;
    invoke-static {v1, v2, v4, v3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object/from16 v33, v1

    check-cast v33, Lkotlin/jvm/functions/Function2;

    const/16 v45, 0x0

    const/16 v46, 0xff8

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v44, 0x180

    move-object/from16 v43, v3

    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v43    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v46}, Landroidx/compose/material3/ChipKt;->FilterChip(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/SelectableChipColors;Landroidx/compose/material3/SelectableChipElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v1, v48

    move/from16 v4, v49

    move/from16 v5, v50

    .end local v18    # "sort\\23":Ljava/lang/String;
    .end local v43    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v51    # "title\\23":Ljava/lang/String;
    .restart local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    goto/16 :goto_f

    .end local v49    # "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    .end local v50    # "$changed\\23":I
    .local v4, "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    .local v5, "$changed\\23":I
    :cond_17
    move/from16 v49, v4

    move/from16 v50, v5

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    .end local v5    # "$changed\\23":I
    .restart local v49    # "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    .restart local v50    # "$changed\\23":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 314
    nop

    .line 834
    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-Row-StoreBrowseKt$CategoriesTab$5\\23\\834\\0":I
    .end local v27    # "$this$CategoriesTab_u24lambda_u2469\\23":Landroidx/compose/foundation/layout/RowScope;
    .end local v50    # "$changed\\23":I
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 833
    .end local v21    # "$changed\\22":I
    .end local v47    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .end local v49    # "$i$a$-Layout-RowKt$Row$1\\22\\833\\16":I
    nop

    .line 841
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 812
    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 842
    nop

    .line 806
    .end local v19    # "$i$f$ReusableComposeNode\\18\\810":I
    .end local v23    # "$changed\\18":I
    .end local v26    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 843
    nop

    .line 800
    .end local v11    # "$changed\\17":I
    .end local v12    # "compositeKeyHash\\17":I
    .end local v13    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "$i$f$Layout\\17\\805":I
    .end local v28    # "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 844
    nop

    .line 315
    .end local v10    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v17    # "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v20    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .end local v24    # "$changed\\16":I
    .end local v29    # "$i$f$Row\\16\\312":I
    .end local v30    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCategoryApps()Lorg/lighttouch/android/Listing;

    move-result-object v1

    const v2, 0x4c5de2

    invoke-interface {v0, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v0, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v0, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\27":Z
    move-object v3, v0

    .local v3, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 845
    .local v4, "$i$f$cache\\27\\315":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\27":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 846
    .local v10, "$i$a$-let-ComposerKt$cache$1\\28\\845\\27":I
    if-nez v2, :cond_19

    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v5, v11, :cond_18

    goto :goto_12

    .line 850
    :cond_18
    move-object v12, v5

    goto :goto_13

    .line 847
    :cond_19
    :goto_12
    const/4 v11, 0x0

    .line 315
    .local v11, "$i$a$-cache-StoreBrowseKt$CategoriesTab$6\\29\\847\\0":I
    new-instance v12, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda8;

    invoke-direct {v12, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    .line 847
    .end local v11    # "$i$a$-cache-StoreBrowseKt$CategoriesTab$6\\29\\847\\0":I
    nop

    .line 848
    .local v12, "value\\28":Ljava/lang/Object;
    invoke-interface {v3, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 849
    nop

    .line 846
    .end local v12    # "value\\28":Ljava/lang/Object;
    :goto_13
    nop

    .line 845
    .end local v5    # "it\\27":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\28\\845\\27":I
    nop

    .line 315
    .end local v2    # "invalid\\27":Z
    .end local v3    # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\27\\315":I
    move-object v4, v12

    check-cast v4, Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v2, v7, 0xe

    shl-int/lit8 v3, v7, 0x6

    and-int/lit16 v3, v3, 0x1c00

    or-int/2addr v2, v3

    move v3, v7

    move v7, v2

    move-object v2, v8

    .end local v7    # "$dirty":I
    .end local v8    # "browser":Lorg/lighttouch/android/StoreBrowser;
    .local v2, "browser":Lorg/lighttouch/android/StoreBrowser;
    .local v3, "$dirty":I
    const/16 v8, 0x10

    const/4 v5, 0x0

    move v10, v3

    move-object v3, v6

    move-object v6, v0

    move-object/from16 v0, p0

    .end local v0    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$dirty":I
    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 310
    move-object/from16 v17, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_14
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "browser":Lorg/lighttouch/android/StoreBrowser;
    .end local v22    # "category":Lorg/lighttouch/android/StoreGenre;
    :cond_1a
    :goto_15
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_1b

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda9;

    invoke-direct {v2, v0, v3, v9}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda9;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 317
    :cond_1b
    return-void
.end method

.method private static final CategoriesTab$lambda$58$lambda$57$lambda$56(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;

    .line 300
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->loadGenres()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CategoriesTab$lambda$64$lambda$63(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 11
    .param p0, "$genres"    # Ljava/util/List;
    .param p1, "$browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 302
    if-nez p0, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, p0

    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda17;

    invoke-direct {v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda17;-><init>()V

    .local v0, "items\\1":Ljava/util/List;
    move-object v2, p2

    .line 987
    .local v1, "key\\1":Lkotlin/jvm/functions/Function1;
    .local v2, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 990
    sget-object v3, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$1;

    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 987
    .local v3, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v4, 0x0

    .line 992
    .local v4, "$i$f$items\\1\\302":I
    nop

    .line 993
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    .line 994
    nop

    .line 992
    new-instance v6, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$2;

    invoke-direct {v6, v1, v0}, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    new-instance v7, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$3;

    invoke-direct {v7, v3, v0}, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v7, Lkotlin/jvm/functions/Function1;

    .line 996
    new-instance v8, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$4;

    invoke-direct {v8, v0, p1}, Lorg/lighttouch/android/StoreBrowseKt$CategoriesTab$lambda$64$lambda$63$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;)V

    const v9, -0x25b7f321

    const/4 v10, 0x1

    invoke-static {v9, v10, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    check-cast v8, Lkotlin/jvm/functions/Function4;

    .line 992
    invoke-interface {v2, v5, v6, v7, v8}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 998
    nop

    .line 309
    .end local v0    # "items\\1":Ljava/util/List;
    .end local v1    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v2    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v3    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v4    # "$i$f$items\\1\\302":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CategoriesTab$lambda$64$lambda$63$lambda$59(Lorg/lighttouch/android/StoreGenre;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/StoreGenre;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 302
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreGenre;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final CategoriesTab$lambda$69$lambda$68$lambda$67(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p1, "$sort"    # Ljava/lang/String;

    .line 313
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->pickCategorySort(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CategoriesTab$lambda$71$lambda$70(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;

    .line 315
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreBrowser;->getCategorySort()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->pickCategorySort(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CategoriesTab$lambda$72(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->CategoriesTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final ChartsTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 78
    .param p0, "$this$ChartsTab"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move/from16 v7, p3

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 229
    const v1, 0xf6daef3

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(ChartsTab)230@11918L21,230@11888L280,233@12203L21,233@12173L988,248@13591L465,248@13441L615:StoreBrowse.kt#o13vsk"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v3, v7, 0x6

    const/4 v4, 0x2

    if-nez v3, :cond_1

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    move v3, v4

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v7, 0x30

    if-nez v3, :cond_3

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    and-int/lit8 v3, v2, 0x13

    const/16 v5, 0x12

    if-ne v3, v5, :cond_5

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    .line 249
    :cond_4
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v28, v2

    goto/16 :goto_1b

    .line 229
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_6

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.ChartsTab (StoreBrowse.kt:228)"

    invoke-static {v1, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 230
    :cond_6
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getBrowser()Lorg/lighttouch/android/StoreBrowser;

    move-result-object v1

    .line 231
    .local v1, "browser":Lorg/lighttouch/android/StoreBrowser;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v8, v3

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v5, 0x1

    invoke-static {v3, v15, v3, v5}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v9

    const/16 v13, 0xe

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/ScrollKt;->horizontalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v9, 0x10

    .local v9, "$this$dp\\1":I
    const/4 v10, 0x0

    .line 427
    .local v10, "$i$f$getDp\\1\\231":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 231
    .end local v9    # "$this$dp\\1":I
    .end local v10    # "$i$f$getDp\\1\\231":I
    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v8, v9, v10, v4, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v12, 0x8

    .local v12, "$this$dp\\2":I
    const/4 v13, 0x0

    .line 427
    .local v13, "$i$f$getDp\\2\\231":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 231
    .end local v12    # "$this$dp\\2":I
    .end local v13    # "$i$f$getDp\\2\\231":I
    invoke-virtual {v9, v12}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v9

    check-cast v9, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v9, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v12, 0x30

    .local v8, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v12, "$changed\\3":I
    const/4 v13, 0x0

    .line 428
    .local v13, "$i$f$Row\\3\\231":I
    const v14, 0x2952b718

    const-string v4, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v15, v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 429
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v14

    .line 432
    .local v14, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v16, v12, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v18, v12, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v10, v16, v18

    invoke-static {v9, v14, v15, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v12, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 433
    nop

    .local v16, "$changed\\4":I
    const/16 v18, 0x0

    .line 434
    .local v18, "$i$f$Layout\\4\\433":I
    const v11, -0x4ee9b9da

    const-string v5, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v15, v11, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 435
    invoke-static {v15, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v22

    .line 436
    .local v22, "compositeKeyHash\\4":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 437
    .local v11, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v15, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 439
    .local v3, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v25

    shl-int/lit8 v0, v16, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 438
    move-object/from16 v26, v25

    .local v0, "$changed\\5":I
    .local v26, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v25, 0x0

    .line 440
    .local v25, "$i$f$ReusableComposeNode\\5\\438":I
    move/from16 v27, v0

    .end local v0    # "$changed\\5":I
    .local v27, "$changed\\5":I
    const v0, -0x2942ffcf

    move/from16 v28, v2

    .end local v2    # "$dirty":I
    .local v28, "$dirty":I
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v15, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 441
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 442
    :cond_7
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 443
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_8

    .line 444
    move-object/from16 v0, v26

    .end local v26    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 446
    .end local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v0, v26

    .end local v26    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 448
    :goto_3
    move-object/from16 v26, v0

    .end local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v15}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 449
    .local v30, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\448\\4":I
    sget-object v31, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v32, v8

    .end local v8    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v32, "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v0, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 450
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v0, v11, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 452
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v31, 0x0

    .line 453
    .local v31, "$i$f$set-impl\\7\\452":I
    move-object/from16 v33, v0

    .local v33, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 454
    .local v34, "$i$a$-with-Updater$set$1\\8\\453\\7":I
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v35

    if-nez v35, :cond_a

    move-object/from16 v35, v9

    .end local v9    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v35, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v36, v10

    .end local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v36, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v10, v33

    goto :goto_5

    .end local v35    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v36    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_a
    move-object/from16 v35, v9

    move-object/from16 v36, v10

    .line 455
    .end local v9    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v35    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v36    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_4
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v33

    .end local v33    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 456
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v0, v9, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 458
    :goto_5
    nop

    .line 453
    .end local v10    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-with-Updater$set$1\\8\\453\\7":I
    nop

    .line 458
    nop

    .line 459
    .end local v8    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v31    # "$i$f$set-impl\\7\\452":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v0, v3, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 460
    nop

    .line 448
    .end local v0    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\448\\4":I
    nop

    .line 461
    shr-int/lit8 v0, v27, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v8, v15

    .local v8, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 462
    .local v9, "$i$a$-Layout-RowKt$Row$1\\9\\461\\3":I
    const v10, -0x184f2606

    move/from16 v30, v0

    .end local v0    # "$changed\\9":I
    .local v30, "$changed\\9":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v8, v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v31, v12, 0x6

    and-int/lit8 v31, v31, 0x70

    or-int/lit8 v31, v31, 0x6

    .local v31, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$ChartsTab_u24lambda_u2417\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v49, v8

    .local v49, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 232
    .local v33, "$i$a$-Row-StoreBrowseKt$ChartsTab$1\\10\\462\\0":I
    const v10, 0x7df3be12

    move-object/from16 v53, v0

    .end local v0    # "$this$ChartsTab_u24lambda_u2417\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v53, "$this$ChartsTab_u24lambda_u2417\\10":Landroidx/compose/foundation/layout/RowScope;
    const-string v0, "C:StoreBrowse.kt#o13vsk"

    move-object/from16 v54, v3

    move-object/from16 v3, v49

    .end local v49    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v54, "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v3, v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, 0x56a4c411

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "*231@12105L31,231@12146L15,231@12067L95"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Lorg/lighttouch/android/LegacyStoreKt;->getCHART_TYPES()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    move/from16 v55, v9

    .end local v9    # "$i$a$-Layout-RowKt$Row$1\\9\\461\\3":I
    .local v55, "$i$a$-Layout-RowKt$Row$1\\9\\461\\3":I
    move/from16 v38, v10

    const-string v10, "CC(remember):StoreBrowse.kt#9igjgp"

    if-eqz v38, :cond_d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v38

    check-cast v38, Lkotlin/Pair;

    invoke-virtual/range {v38 .. v38}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v39

    move-object/from16 v9, v39

    check-cast v9, Ljava/lang/String;

    .local v9, "slug\\10":Ljava/lang/String;
    invoke-virtual/range {v38 .. v38}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v38

    move-object/from16 v56, v0

    move-object/from16 v0, v38

    check-cast v0, Ljava/lang/String;

    move-object/from16 v57, v8

    .end local v8    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v0, "title\\10":Ljava/lang/String;
    .local v57, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChartType()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    move/from16 v38, v8

    const v8, -0x615d173a

    invoke-interface {v3, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    or-int/2addr v8, v10

    .local v8, "invalid\\11":Z
    move-object v10, v3

    .local v10, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/16 v37, 0x0

    .line 463
    .local v37, "$i$f$cache\\11\\232":I
    move/from16 v39, v8

    .end local v8    # "invalid\\11":Z
    .local v39, "invalid\\11":Z
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\11":Ljava/lang/Object;
    const/16 v41, 0x0

    .line 464
    .local v41, "$i$a$-let-ComposerKt$cache$1\\12\\463\\11":I
    if-nez v39, :cond_c

    sget-object v42, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v58, v11

    .end local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v58, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-virtual/range {v42 .. v42}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v8, v11, :cond_b

    goto :goto_7

    .line 468
    :cond_b
    move-object/from16 v42, v8

    goto :goto_8

    .line 464
    .end local v58    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_c
    move-object/from16 v58, v11

    .line 465
    .end local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v58    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_7
    const/4 v11, 0x0

    .line 232
    .local v11, "$i$a$-cache-StoreBrowseKt$ChartsTab$1$1\\13\\465\\10":I
    move-object/from16 v42, v8

    .end local v8    # "it\\11":Ljava/lang/Object;
    .local v42, "it\\11":Ljava/lang/Object;
    new-instance v8, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda28;

    invoke-direct {v8, v1, v9}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda28;-><init>(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)V

    .line 465
    .end local v11    # "$i$a$-cache-StoreBrowseKt$ChartsTab$1$1\\13\\465\\10":I
    nop

    .line 466
    .local v8, "value\\12":Ljava/lang/Object;
    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 467
    nop

    .line 464
    .end local v8    # "value\\12":Ljava/lang/Object;
    :goto_8
    nop

    .line 463
    .end local v41    # "$i$a$-let-ComposerKt$cache$1\\12\\463\\11":I
    .end local v42    # "it\\11":Ljava/lang/Object;
    nop

    .line 232
    .end local v10    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v37    # "$i$f$cache\\11\\232":I
    .end local v39    # "invalid\\11":Z
    check-cast v8, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v10, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$1$2;

    invoke-direct {v10, v0}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$1$2;-><init>(Ljava/lang/String;)V

    const v11, -0x1969082f

    move-object/from16 v59, v0

    move-object/from16 v37, v8

    const/16 v0, 0x36

    const/4 v8, 0x1

    .end local v0    # "title\\10":Ljava/lang/String;
    .local v59, "title\\10":Ljava/lang/String;
    invoke-static {v11, v8, v10, v3, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v39, v0

    check-cast v39, Lkotlin/jvm/functions/Function2;

    const/16 v51, 0x0

    const/16 v52, 0xff8

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v50, 0x180

    move/from16 v49, v38

    move-object/from16 v38, v37

    move/from16 v37, v49

    move-object/from16 v49, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v49    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v37 .. v52}, Landroidx/compose/material3/ChipKt;->FilterChip(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/SelectableChipColors;Landroidx/compose/material3/SelectableChipElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;III)V

    move/from16 v9, v55

    move-object/from16 v0, v56

    move-object/from16 v8, v57

    move-object/from16 v11, v58

    .end local v9    # "slug\\10":Ljava/lang/String;
    .end local v59    # "title\\10":Ljava/lang/String;
    goto/16 :goto_6

    .end local v49    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v58    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v11, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_d
    move-object/from16 v49, v3

    move-object/from16 v57, v8

    move-object/from16 v58, v11

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v8    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v49    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v58    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 233
    nop

    .line 462
    .end local v31    # "$changed\\10":I
    .end local v33    # "$i$a$-Row-StoreBrowseKt$ChartsTab$1\\10\\462\\0":I
    .end local v49    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v53    # "$this$ChartsTab_u24lambda_u2417\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 461
    .end local v30    # "$changed\\9":I
    .end local v55    # "$i$a$-Layout-RowKt$Row$1\\9\\461\\3":I
    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 469
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 440
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 470
    nop

    .line 434
    .end local v25    # "$i$f$ReusableComposeNode\\5\\438":I
    .end local v26    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v27    # "$changed\\5":I
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 471
    nop

    .line 428
    .end local v16    # "$changed\\4":I
    .end local v18    # "$i$f$Layout\\4\\433":I
    .end local v22    # "compositeKeyHash\\4":I
    .end local v54    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v58    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 472
    nop

    .line 234
    .end local v12    # "$changed\\3":I
    .end local v13    # "$i$f$Row\\3\\231":I
    .end local v14    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v32    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v35    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v36    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v41, v0

    check-cast v41, Landroidx/compose/ui/Modifier;

    const/4 v0, 0x0

    const/4 v8, 0x1

    invoke-static {v0, v15, v0, v8}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v42

    const/16 v46, 0xe

    const/16 v47, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    invoke-static/range {v41 .. v47}, Landroidx/compose/foundation/ScrollKt;->horizontalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0x10

    .local v3, "$this$dp\\14":I
    const/4 v8, 0x0

    .line 473
    .local v8, "$i$f$getDp\\14\\234":I
    int-to-float v9, v3

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 234
    .end local v3    # "$this$dp\\14":I
    .end local v8    # "$i$f$getDp\\14\\234":I
    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v11, 0x0

    invoke-static {v0, v3, v8, v9, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v8, 0x8

    .local v8, "$this$dp\\15":I
    const/4 v9, 0x0

    .line 473
    .local v9, "$i$f$getDp\\15\\234":I
    int-to-float v11, v8

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 234
    .end local v8    # "$this$dp\\15":I
    .end local v9    # "$i$f$getDp\\15\\234":I
    invoke-virtual {v3, v8}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v3, "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v8

    .local v8, "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v9, 0x1b0

    .local v0, "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v9, "$changed\\16":I
    const/4 v11, 0x0

    .line 474
    .local v11, "$i$f$Row\\16\\234":I
    const v12, 0x2952b718

    invoke-static {v15, v12, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 475
    shr-int/lit8 v4, v9, 0x3

    and-int/lit8 v4, v4, 0xe

    shr-int/lit8 v12, v9, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v4, v12

    invoke-static {v3, v8, v15, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v9, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 476
    nop

    .local v12, "$changed\\17":I
    const/4 v13, 0x0

    .line 477
    .local v13, "$i$f$Layout\\17\\476":I
    const v14, -0x4ee9b9da

    invoke-static {v15, v14, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 478
    const/4 v14, 0x0

    invoke-static {v15, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v16

    .line 479
    .local v16, "compositeKeyHash\\17":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 480
    .local v14, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v17, v3

    .end local v3    # "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v17, "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v15, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 482
    .local v3, "materialized\\17":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v22, v0

    .end local v0    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\16":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v12, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 481
    move-object/from16 v25, v18

    .local v0, "$changed\\18":I
    .local v25, "factory\\18":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 483
    .local v18, "$i$f$ReusableComposeNode\\18\\481":I
    move/from16 v26, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\18":I
    .local v26, "$changed\\18":I
    invoke-static {v15, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 484
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 485
    :cond_e
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 486
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_f

    .line 487
    move-object/from16 v0, v25

    .end local v25    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 489
    .end local v0    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\18":Lkotlin/jvm/functions/Function0;
    :cond_f
    move-object/from16 v0, v25

    .end local v25    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 491
    :goto_9
    move-object/from16 v25, v0

    .end local v0    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-static {v15}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 492
    .local v27, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\491\\17":I
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v31, v8

    .end local v8    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .local v31, "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v0, v4, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 493
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v0, v14, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 495
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\20":Lkotlin/jvm/functions/Function2;
    const/16 v30, 0x0

    .line 496
    .local v30, "$i$f$set-impl\\20\\495":I
    move-object/from16 v32, v0

    .local v32, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 497
    .local v33, "$i$a$-with-Updater$set$1\\21\\496\\20":I
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v35

    if-nez v35, :cond_11

    move-object/from16 v35, v4

    .end local v4    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v35, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v36, v9

    .end local v9    # "$changed\\16":I
    .local v36, "$changed\\16":I
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_10

    goto :goto_a

    :cond_10
    move-object/from16 v9, v32

    goto :goto_b

    .end local v35    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v36    # "$changed\\16":I
    .restart local v4    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9    # "$changed\\16":I
    :cond_11
    move-object/from16 v35, v4

    move/from16 v36, v9

    .line 498
    .end local v4    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v9    # "$changed\\16":I
    .restart local v35    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v36    # "$changed\\16":I
    :goto_a
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v9, v32

    .end local v32    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 499
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 501
    :goto_b
    nop

    .line 496
    .end local v9    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-with-Updater$set$1\\21\\496\\20":I
    nop

    .line 501
    nop

    .line 502
    .end local v8    # "block\\20":Lkotlin/jvm/functions/Function2;
    .end local v30    # "$i$f$set-impl\\20\\495":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v0, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 503
    nop

    .line 491
    .end local v0    # "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\491\\17":I
    nop

    .line 504
    shr-int/lit8 v0, v26, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\22":I
    move-object v4, v15

    .local v4, "$composer\\22":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 505
    .local v8, "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    const-string v9, "C101@5126L9:Row.kt#2w3rfo"

    move/from16 v27, v0

    const v0, -0x184f2606

    .end local v0    # "$changed\\22":I
    .local v27, "$changed\\22":I
    invoke-static {v4, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v9, v36, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\23":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$ChartsTab_u24lambda_u2428\\23":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v53, v4

    .local v53, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 235
    .local v30, "$i$a$-Row-StoreBrowseKt$ChartsTab$2\\23\\505\\0":I
    move-object/from16 v32, v0

    .end local v0    # "$this$ChartsTab_u24lambda_u2428\\23":Landroidx/compose/foundation/layout/RowScope;
    .local v32, "$this$ChartsTab_u24lambda_u2428\\23":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x1f4afc0b

    move-object/from16 v33, v3

    .end local v3    # "materialized\\17":Landroidx/compose/ui/Modifier;
    .local v33, "materialized\\17":Landroidx/compose/ui/Modifier;
    const-string v3, "C235@12561L34,236@12604L551:StoreBrowse.kt#o13vsk"

    move-object/from16 v34, v4

    .end local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v34, "$composer\\22":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, 0xf81b367

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "*234@12479L35,234@12524L15,234@12437L103"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x2

    new-array v3, v0, [Lkotlin/Pair;

    const-string v0, "iphone"

    move-object/from16 v38, v3

    const-string v3, "iPhone"

    invoke-static {v0, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v24, 0x0

    aput-object v0, v38, v24

    const-string v0, "ipad"

    const-string v3, "iPad"

    invoke-static {v0, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v21, 0x1

    aput-object v0, v38, v21

    invoke-static/range {v38 .. v38}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_14

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lkotlin/Pair;

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v38

    move-object/from16 v39, v0

    move-object/from16 v0, v38

    check-cast v0, Ljava/lang/String;

    .local v0, "device\\23":Ljava/lang/String;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    move/from16 v38, v8

    .end local v8    # "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    .local v3, "title\\23":Ljava/lang/String;
    .local v38, "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChartDevice()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v41

    const v8, -0x615d173a

    invoke-interface {v4, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v37

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v42

    or-int v37, v37, v42

    .local v37, "invalid\\24":Z
    move-object/from16 v42, v4

    .local v42, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 506
    .local v43, "$i$f$cache\\24\\235":I
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\24":Ljava/lang/Object;
    const/16 v44, 0x0

    .line 507
    .local v44, "$i$a$-let-ComposerKt$cache$1\\25\\506\\24":I
    if-nez v37, :cond_13

    sget-object v45, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v58, v9

    .end local v9    # "$changed\\23":I
    .local v58, "$changed\\23":I
    invoke-virtual/range {v45 .. v45}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v8, v9, :cond_12

    goto :goto_d

    .line 511
    :cond_12
    move-object/from16 v45, v8

    move-object/from16 v9, v42

    goto :goto_e

    .line 507
    .end local v58    # "$changed\\23":I
    .restart local v9    # "$changed\\23":I
    :cond_13
    move/from16 v58, v9

    .line 508
    .end local v9    # "$changed\\23":I
    .restart local v58    # "$changed\\23":I
    :goto_d
    const/4 v9, 0x0

    .line 235
    .local v9, "$i$a$-cache-StoreBrowseKt$ChartsTab$2$1\\26\\508\\23":I
    move-object/from16 v45, v8

    .end local v8    # "it\\24":Ljava/lang/Object;
    .local v45, "it\\24":Ljava/lang/Object;
    new-instance v8, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda29;

    invoke-direct {v8, v1, v0}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda29;-><init>(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)V

    .line 508
    .end local v9    # "$i$a$-cache-StoreBrowseKt$ChartsTab$2$1\\26\\508\\23":I
    nop

    .line 509
    .local v8, "value\\25":Ljava/lang/Object;
    move-object/from16 v9, v42

    .end local v42    # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .local v9, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 510
    nop

    .line 507
    .end local v8    # "value\\25":Ljava/lang/Object;
    :goto_e
    nop

    .line 506
    .end local v44    # "$i$a$-let-ComposerKt$cache$1\\25\\506\\24":I
    .end local v45    # "it\\24":Ljava/lang/Object;
    nop

    .line 235
    .end local v9    # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .end local v37    # "invalid\\24":Z
    .end local v43    # "$i$f$cache\\24\\235":I
    move-object/from16 v42, v8

    check-cast v42, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v8, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$2$2;

    invoke-direct {v8, v3}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$2$2;-><init>(Ljava/lang/String;)V

    const v9, -0x1969082f

    move-object/from16 v37, v0

    move-object/from16 v59, v3

    const/16 v0, 0x36

    const/4 v3, 0x1

    .end local v0    # "device\\23":Ljava/lang/String;
    .end local v3    # "title\\23":Ljava/lang/String;
    .local v37, "device\\23":Ljava/lang/String;
    .local v59, "title\\23":Ljava/lang/String;
    invoke-static {v9, v3, v8, v4, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    move-object/from16 v43, v8

    check-cast v43, Lkotlin/jvm/functions/Function2;

    const/16 v55, 0x0

    const/16 v56, 0xff8

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v54, 0x180

    move-object/from16 v53, v4

    .end local v4    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v41 .. v56}, Landroidx/compose/material3/ChipKt;->FilterChip(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/SelectableChipColors;Landroidx/compose/material3/SelectableChipElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;III)V

    move/from16 v8, v38

    move-object/from16 v0, v39

    move/from16 v9, v58

    .end local v37    # "device\\23":Ljava/lang/String;
    .end local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v59    # "title\\23":Ljava/lang/String;
    .restart local v4    # "$composer\\23":Landroidx/compose/runtime/Composer;
    goto/16 :goto_c

    .end local v38    # "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    .end local v58    # "$changed\\23":I
    .local v8, "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    .local v9, "$changed\\23":I
    :cond_14
    move/from16 v38, v8

    move/from16 v58, v9

    .end local v8    # "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    .end local v9    # "$changed\\23":I
    .restart local v38    # "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    .restart local v58    # "$changed\\23":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v0, 0x6e3c21fe

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 236
    move-object v0, v4

    const/16 v24, 0x0

    .local v0, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    move/from16 v3, v24

    .local v3, "invalid\\27":Z
    const/4 v8, 0x0

    .line 512
    .local v8, "$i$f$cache\\27\\236":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\27":Ljava/lang/Object;
    const/16 v37, 0x0

    .line 513
    .local v37, "$i$a$-let-ComposerKt$cache$1\\28\\512\\27":I
    sget-object v39, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v41, v3

    .end local v3    # "invalid\\27":Z
    .local v41, "invalid\\27":Z
    invoke-virtual/range {v39 .. v39}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v9, v3, :cond_15

    .line 514
    const/4 v3, 0x0

    .line 236
    .local v3, "$i$a$-cache-StoreBrowseKt$ChartsTab$2$menu$2\\29\\514\\23":I
    move/from16 v39, v3

    const/16 v24, 0x0

    .end local v3    # "$i$a$-cache-StoreBrowseKt$ChartsTab$2$menu$2\\29\\514\\23":I
    .local v39, "$i$a$-cache-StoreBrowseKt$ChartsTab$2$menu$2\\29\\514\\23":I
    invoke-static/range {v24 .. v24}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    move/from16 v42, v8

    move-object/from16 p2, v9

    const/4 v8, 0x2

    const/4 v9, 0x0

    .end local v8    # "$i$f$cache\\27\\236":I
    .end local v9    # "it\\27":Ljava/lang/Object;
    .local v42, "$i$f$cache\\27\\236":I
    .local p2, "it\\27":Ljava/lang/Object;
    invoke-static {v3, v9, v8, v9}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    .line 514
    .end local v39    # "$i$a$-cache-StoreBrowseKt$ChartsTab$2$menu$2\\29\\514\\23":I
    nop

    .line 515
    .local v3, "value\\28":Ljava/lang/Object;
    invoke-interface {v0, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 516
    nop

    .end local v3    # "value\\28":Ljava/lang/Object;
    goto :goto_f

    .line 517
    .end local v42    # "$i$f$cache\\27\\236":I
    .end local p2    # "it\\27":Ljava/lang/Object;
    .restart local v8    # "$i$f$cache\\27\\236":I
    .restart local v9    # "it\\27":Ljava/lang/Object;
    :cond_15
    move/from16 v42, v8

    move-object/from16 p2, v9

    .end local v8    # "$i$f$cache\\27\\236":I
    .end local v9    # "it\\27":Ljava/lang/Object;
    .restart local v42    # "$i$f$cache\\27\\236":I
    .restart local p2    # "it\\27":Ljava/lang/Object;
    move-object/from16 v3, p2

    .line 513
    :goto_f
    nop

    .line 512
    .end local v37    # "$i$a$-let-ComposerKt$cache$1\\28\\512\\27":I
    .end local p2    # "it\\27":Ljava/lang/Object;
    nop

    .line 236
    .end local v0    # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v41    # "invalid\\27":Z
    .end local v42    # "$i$f$cache\\27\\236":I
    move-object v0, v3

    check-cast v0, Landroidx/compose/runtime/MutableState;

    .local v0, "menu$delegate\\23":Landroidx/compose/runtime/MutableState;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 237
    const/16 v24, 0x0

    move/from16 v3, v24

    .local v3, "$changed\\30":I
    const/4 v8, 0x0

    .line 518
    .local v8, "$i$f$Box\\30\\237":I
    const v9, 0x2bb5b5d7

    move/from16 p2, v3

    .end local v3    # "$changed\\30":I
    .local p2, "$changed\\30":I
    const-string v3, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v4, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 519
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    .line 520
    .local v3, "modifier\\30":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v9

    .line 521
    .local v9, "contentAlignment\\30":Landroidx/compose/ui/Alignment;
    move/from16 v37, v8

    .end local v8    # "$i$f$Box\\30\\237":I
    .local v37, "$i$f$Box\\30\\237":I
    const/4 v8, 0x0

    .line 524
    .local v8, "propagateMinConstraints\\30":Z
    move/from16 v39, v11

    .end local v11    # "$i$f$Row\\16\\234":I
    .local v39, "$i$f$Row\\16\\234":I
    invoke-static {v9, v8}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v41, p2, 0x3

    and-int/lit8 v41, v41, 0x70

    .line 525
    nop

    .local v41, "$changed\\31":I
    const/16 v42, 0x0

    .line 526
    .local v42, "$i$f$Layout\\31\\525":I
    move/from16 v43, v8

    const v8, -0x4ee9b9da

    .end local v8    # "propagateMinConstraints\\30":Z
    .local v43, "propagateMinConstraints\\30":Z
    invoke-static {v4, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 527
    const/4 v5, 0x0

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v8

    .line 528
    .local v8, "compositeKeyHash\\31":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 529
    .local v5, "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v23, v8

    .end local v8    # "compositeKeyHash\\31":I
    .local v23, "compositeKeyHash\\31":I
    invoke-static {v4, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 531
    .local v8, "materialized\\31":Landroidx/compose/ui/Modifier;
    sget-object v44, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v44 .. v44}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v44

    move-object/from16 v45, v3

    .end local v3    # "modifier\\30":Landroidx/compose/ui/Modifier;
    .local v45, "modifier\\30":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v41, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 530
    move-object/from16 v46, v44

    .local v3, "$changed\\32":I
    .local v46, "factory\\32":Lkotlin/jvm/functions/Function0;
    const/16 v44, 0x0

    .line 532
    .local v44, "$i$f$ReusableComposeNode\\32\\530":I
    move/from16 v47, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\32":I
    .local v47, "$changed\\32":I
    invoke-static {v4, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 533
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 534
    :cond_16
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 535
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_17

    .line 536
    move-object/from16 v2, v46

    .end local v46    # "factory\\32":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 538
    .end local v2    # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v46    # "factory\\32":Lkotlin/jvm/functions/Function0;
    :cond_17
    move-object/from16 v2, v46

    .end local v46    # "factory\\32":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 540
    :goto_10
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 541
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\33\\540\\31":I
    sget-object v46, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v48, v2

    .end local v2    # "factory\\32":Lkotlin/jvm/functions/Function0;
    .local v48, "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v46 .. v46}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v11, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 542
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 544
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\34":Lkotlin/jvm/functions/Function2;
    const/16 v46, 0x0

    .line 545
    .local v46, "$i$f$set-impl\\34\\544":I
    move-object/from16 v49, v3

    .local v49, "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    const/16 v50, 0x0

    .line 546
    .local v50, "$i$a$-with-Updater$set$1\\35\\545\\34":I
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v51

    if-nez v51, :cond_19

    move-object/from16 v53, v4

    .end local v4    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v51, v5

    .end local v5    # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .local v51, "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_18

    goto :goto_11

    :cond_18
    move-object/from16 v5, v49

    goto :goto_12

    .end local v51    # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v5    # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_19
    move-object/from16 v53, v4

    move-object/from16 v51, v5

    .line 547
    .end local v4    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v5    # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v51    # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    :goto_11
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v49

    .end local v49    # "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 548
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 550
    :goto_12
    nop

    .line 545
    .end local v5    # "$this$set_impl_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-with-Updater$set$1\\35\\545\\34":I
    nop

    .line 550
    nop

    .line 551
    .end local v2    # "block\\34":Lkotlin/jvm/functions/Function2;
    .end local v46    # "$i$f$set-impl\\34\\544":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v8, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 552
    nop

    .line 540
    .end local v3    # "$this$Layout_u24lambda_u240\\33":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\33\\540\\31":I
    nop

    .line 553
    shr-int/lit8 v2, v47, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\36":I
    move-object/from16 v3, v53

    .local v3, "$composer\\36":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 554
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\36\\553\\30":I
    const v5, -0x7ff519f7    # -1.000876E-39f

    move/from16 v29, v2

    .end local v2    # "$changed\\36":I
    .local v29, "$changed\\36":I
    const-string v2, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v3, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v5, p2, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\37":I
    check-cast v2, Landroidx/compose/foundation/layout/BoxScope;

    .local v2, "$this$ChartsTab_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v70, v3

    .local v70, "$composer\\37":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 238
    .local v46, "$i$a$-Box-StoreBrowseKt$ChartsTab$2$3\\37\\554\\23":I
    move-object/from16 v49, v2

    .end local v2    # "$this$ChartsTab_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/BoxScope;
    .local v49, "$this$ChartsTab_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/BoxScope;
    const v2, -0x5da31d5a

    move-object/from16 v50, v3

    .end local v3    # "$composer\\36":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\36":Landroidx/compose/runtime/Composer;
    const-string v3, "C237@12633L15,237@12658L48,237@12622L144,238@12798L16,238@12849L296,238@12779L366:StoreBrowse.kt#o13vsk"

    move/from16 v52, v4

    move-object/from16 v4, v70

    .end local v70    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v52, "$i$a$-Layout-BoxKt$Box$1\\36\\553\\30":I
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, 0x4c5de2

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\38":Z
    move-object/from16 v54, v4

    .local v54, "$this$cache\\38":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 555
    .local v55, "$i$f$cache\\38\\238":I
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\38":Ljava/lang/Object;
    const/16 v59, 0x0

    .line 556
    .local v59, "$i$a$-let-ComposerKt$cache$1\\39\\555\\38":I
    sget-object v60, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v61, v3

    .end local v3    # "invalid\\38":Z
    .local v61, "invalid\\38":Z
    invoke-virtual/range {v60 .. v60}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_1a

    .line 557
    const/4 v3, 0x0

    .line 238
    .local v3, "$i$a$-cache-StoreBrowseKt$ChartsTab$2$3$1\\40\\557\\37":I
    move-object/from16 v60, v2

    .end local v2    # "it\\38":Ljava/lang/Object;
    .local v60, "it\\38":Ljava/lang/Object;
    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda30;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda30;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 557
    .end local v3    # "$i$a$-cache-StoreBrowseKt$ChartsTab$2$3$1\\40\\557\\37":I
    nop

    .line 558
    .local v2, "value\\39":Ljava/lang/Object;
    move-object/from16 v3, v54

    .end local v54    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    .local v3, "$this$cache\\38":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 559
    nop

    .end local v2    # "value\\39":Ljava/lang/Object;
    goto :goto_13

    .line 560
    .end local v3    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    .end local v60    # "it\\38":Ljava/lang/Object;
    .local v2, "it\\38":Ljava/lang/Object;
    .restart local v54    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    :cond_1a
    move-object/from16 v60, v2

    move-object/from16 v3, v54

    .line 556
    .end local v2    # "it\\38":Ljava/lang/Object;
    .end local v54    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    .restart local v60    # "it\\38":Ljava/lang/Object;
    :goto_13
    nop

    .line 555
    .end local v59    # "$i$a$-let-ComposerKt$cache$1\\39\\555\\38":I
    .end local v60    # "it\\38":Ljava/lang/Object;
    nop

    .line 238
    .end local v3    # "$this$cache\\38":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$f$cache\\38\\238":I
    .end local v61    # "invalid\\38":Z
    move-object/from16 v59, v2

    check-cast v59, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$2$3$2;

    invoke-direct {v2, v1}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$2$3$2;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    const v3, -0x4f7e0691

    move/from16 v54, v5

    move-object/from16 v55, v8

    const/16 v5, 0x36

    const/4 v8, 0x1

    .end local v5    # "$changed\\37":I
    .end local v8    # "materialized\\31":Landroidx/compose/ui/Modifier;
    .local v54, "$changed\\37":I
    .local v55, "materialized\\31":Landroidx/compose/ui/Modifier;
    invoke-static {v3, v8, v2, v4, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object/from16 v60, v2

    check-cast v60, Lkotlin/jvm/functions/Function2;

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$-906425109$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v64

    const/16 v72, 0x0

    const/16 v73, 0x7dc

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const v71, 0x30036

    move-object/from16 v70, v4

    .end local v4    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v70    # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static/range {v59 .. v73}, Landroidx/compose/material3/ChipKt;->AssistChip(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ChipColors;Landroidx/compose/material3/ChipElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;III)V

    .line 239
    move-object/from16 v3, v70

    .end local v70    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static {v0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$21(Landroidx/compose/runtime/MutableState;)Z

    move-result v59

    const v2, 0x4c5de2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\41":Z
    move-object v4, v3

    .local v4, "$this$cache\\41":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 561
    .local v5, "$i$f$cache\\41\\239":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\41":Ljava/lang/Object;
    const/16 v60, 0x0

    .line 562
    .local v60, "$i$a$-let-ComposerKt$cache$1\\42\\561\\41":I
    sget-object v61, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v62, v2

    .end local v2    # "invalid\\41":Z
    .local v62, "invalid\\41":Z
    invoke-virtual/range {v61 .. v61}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v8, v2, :cond_1b

    .line 563
    const/4 v2, 0x0

    .line 239
    .local v2, "$i$a$-cache-StoreBrowseKt$ChartsTab$2$3$3\\43\\563\\37":I
    move/from16 v61, v2

    .end local v2    # "$i$a$-cache-StoreBrowseKt$ChartsTab$2$3$3\\43\\563\\37":I
    .local v61, "$i$a$-cache-StoreBrowseKt$ChartsTab$2$3$3\\43\\563\\37":I
    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 563
    .end local v61    # "$i$a$-cache-StoreBrowseKt$ChartsTab$2$3$3\\43\\563\\37":I
    nop

    .line 564
    .local v2, "value\\42":Ljava/lang/Object;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 565
    nop

    .end local v2    # "value\\42":Ljava/lang/Object;
    goto :goto_14

    .line 566
    :cond_1b
    move-object v2, v8

    .line 562
    :goto_14
    nop

    .line 561
    .end local v8    # "it\\41":Ljava/lang/Object;
    .end local v60    # "$i$a$-let-ComposerKt$cache$1\\42\\561\\41":I
    nop

    .line 239
    .end local v4    # "$this$cache\\41":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\41\\239":I
    .end local v62    # "invalid\\41":Z
    move-object/from16 v60, v2

    check-cast v60, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x168

    .local v4, "$this$dp\\44":I
    const/4 v5, 0x0

    .line 567
    .local v5, "$i$f$getDp\\44\\239":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 239
    .end local v4    # "$this$dp\\44":I
    .end local v5    # "$i$f$getDp\\44\\239":I
    move-object/from16 v77, v9

    const/4 v5, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    .end local v9    # "contentAlignment\\30":Landroidx/compose/ui/Alignment;
    .local v77, "contentAlignment\\30":Landroidx/compose/ui/Alignment;
    invoke-static {v2, v8, v4, v9, v5}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v61

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$2$3$4;

    invoke-direct {v2, v1, v0}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$2$3$4;-><init>(Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/MutableState;)V

    const v4, 0x6abd64ad

    const/16 v5, 0x36

    invoke-static {v4, v9, v2, v3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object/from16 v72, v2

    check-cast v72, Lkotlin/jvm/functions/Function3;

    const/16 v75, 0x30

    const/16 v76, 0x7f8

    const-wide/16 v62, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v74, 0x1b0

    move-object/from16 v73, v3

    .end local v3    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v73, "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static/range {v59 .. v76}, Landroidx/compose/material3/AndroidMenu_androidKt;->DropdownMenu-IlH_yew(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/ScrollState;Landroidx/compose/ui/window/PopupProperties;Landroidx/compose/ui/graphics/Shape;JFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    .line 238
    .end local v73    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\37":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 243
    nop

    .line 554
    .end local v3    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .end local v46    # "$i$a$-Box-StoreBrowseKt$ChartsTab$2$3\\37\\554\\23":I
    .end local v49    # "$this$ChartsTab_u24lambda_u2428_u24lambda_u2427\\37":Landroidx/compose/foundation/layout/BoxScope;
    .end local v54    # "$changed\\37":I
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 553
    .end local v29    # "$changed\\36":I
    .end local v50    # "$composer\\36":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-Layout-BoxKt$Box$1\\36\\553\\30":I
    nop

    .line 568
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 532
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 569
    nop

    .line 526
    .end local v44    # "$i$f$ReusableComposeNode\\32\\530":I
    .end local v47    # "$changed\\32":I
    .end local v48    # "factory\\32":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 570
    nop

    .line 518
    .end local v23    # "compositeKeyHash\\31":I
    .end local v41    # "$changed\\31":I
    .end local v42    # "$i$f$Layout\\31\\525":I
    .end local v51    # "localMap\\31":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v55    # "materialized\\31":Landroidx/compose/ui/Modifier;
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 571
    nop

    .line 235
    .end local v11    # "measurePolicy\\30":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v37    # "$i$f$Box\\30\\237":I
    .end local v43    # "propagateMinConstraints\\30":Z
    .end local v45    # "modifier\\30":Landroidx/compose/ui/Modifier;
    .end local v77    # "contentAlignment\\30":Landroidx/compose/ui/Alignment;
    .end local p2    # "$changed\\30":I
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 244
    .end local v0    # "menu$delegate\\23":Landroidx/compose/runtime/MutableState;
    nop

    .line 505
    .end local v30    # "$i$a$-Row-StoreBrowseKt$ChartsTab$2\\23\\505\\0":I
    .end local v32    # "$this$ChartsTab_u24lambda_u2428\\23":Landroidx/compose/foundation/layout/RowScope;
    .end local v53    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v58    # "$changed\\23":I
    invoke-static/range {v34 .. v34}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 504
    .end local v27    # "$changed\\22":I
    .end local v34    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .end local v38    # "$i$a$-Layout-RowKt$Row$1\\22\\504\\16":I
    nop

    .line 572
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 483
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 573
    nop

    .line 477
    .end local v18    # "$i$f$ReusableComposeNode\\18\\481":I
    .end local v25    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .end local v26    # "$changed\\18":I
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 574
    nop

    .line 474
    .end local v12    # "$changed\\17":I
    .end local v13    # "$i$f$Layout\\17\\476":I
    .end local v14    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16    # "compositeKeyHash\\17":I
    .end local v33    # "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 575
    nop

    .line 245
    .end local v17    # "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v22    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .end local v31    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .end local v35    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v36    # "$changed\\16":I
    .end local v39    # "$i$f$Row\\16\\234":I
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChart()Lorg/lighttouch/android/StoreChart;

    move-result-object v0

    .local v0, "chart":Lorg/lighttouch/android/StoreChart;
    const v2, -0x1541911f

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "245@13215L27"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 246
    if-eqz v0, :cond_1c

    const/4 v14, 0x0

    invoke-static {v0, v1, v15, v14}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V

    :cond_1c
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, -0x15418a76

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "246@13273L93"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 247
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChartLoading()Z

    move-result v2

    if-eqz v2, :cond_1d

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x0

    invoke-static {v2, v8, v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v3, 0x10

    .local v3, "$this$dp\\45":I
    const/4 v4, 0x0

    .line 576
    .local v4, "$i$f$getDp\\45\\247":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 247
    .end local v3    # "$this$dp\\45":I
    .end local v4    # "$i$f$getDp\\45\\247":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\46":I
    const/4 v5, 0x0

    .line 576
    .local v5, "$i$f$getDp\\46\\247":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 247
    .end local v4    # "$this$dp\\46":I
    .end local v5    # "$i$f$getDp\\46\\247":I
    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v16, 0x6

    const/16 v17, 0x1e

    move-object v2, v10

    const-wide/16 v9, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const v37, -0x615d173a

    invoke-static/range {v8 .. v17}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    goto :goto_15

    :cond_1d
    move-object v2, v10

    const v37, -0x615d173a

    :goto_15
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 248
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChartError()Ljava/lang/String;

    move-result-object v3

    const v4, -0x154178c0

    invoke-interface {v15, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "*247@13411L23,247@13397L37"

    invoke-static {v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v3, :cond_1e

    goto :goto_18

    .line 370
    .local v3, "it\\47":Ljava/lang/String;
    :cond_1e
    const/4 v4, 0x0

    .line 248
    .local v4, "$i$a$-let-StoreBrowseKt$ChartsTab$3\\47\\248\\0":I
    const v5, 0x4c5de2

    invoke-interface {v15, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    .local v5, "invalid\\48":Z
    move-object v8, v15

    .local v8, "$this$cache\\48":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 577
    .local v9, "$i$f$cache\\48\\248":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\48":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 578
    .local v11, "$i$a$-let-ComposerKt$cache$1\\49\\577\\48":I
    if-nez v5, :cond_20

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v10, v12, :cond_1f

    goto :goto_16

    .line 582
    :cond_1f
    move-object v13, v10

    goto :goto_17

    .line 579
    :cond_20
    :goto_16
    const/4 v12, 0x0

    .line 248
    .local v12, "$i$a$-cache-StoreBrowseKt$ChartsTab$3$1\\50\\579\\47":I
    new-instance v13, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda2;

    invoke-direct {v13, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    .line 579
    .end local v12    # "$i$a$-cache-StoreBrowseKt$ChartsTab$3$1\\50\\579\\47":I
    nop

    .line 580
    .local v13, "value\\49":Ljava/lang/Object;
    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 581
    nop

    .line 578
    .end local v13    # "value\\49":Ljava/lang/Object;
    :goto_17
    nop

    .line 577
    .end local v10    # "it\\48":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\49\\577\\48":I
    nop

    .line 248
    .end local v5    # "invalid\\48":Z
    .end local v8    # "$this$cache\\48":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\48\\248":I
    check-cast v13, Lkotlin/jvm/functions/Function0;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v14, 0x0

    invoke-static {v3, v13, v15, v14}, Lorg/lighttouch/android/StoreBrowseKt;->ErrorLine(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .end local v3    # "it\\47":Ljava/lang/String;
    .end local v4    # "$i$a$-let-StoreBrowseKt$ChartsTab$3\\47\\248\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_18
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 249
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    const/4 v5, 0x0

    move-object v8, v2

    const/high16 v2, 0x3f800000    # 1.0f

    move-object v9, v1

    move-object v1, v3

    .end local v1    # "browser":Lorg/lighttouch/android/StoreBrowser;
    .local v9, "browser":Lorg/lighttouch/android/StoreBrowser;
    const/4 v3, 0x0

    move-object v10, v8

    move-object/from16 v20, v9

    move/from16 v9, v37

    move-object v8, v0

    move-object/from16 v0, p0

    .end local v0    # "chart":Lorg/lighttouch/android/StoreChart;
    .end local v9    # "browser":Lorg/lighttouch/android/StoreBrowser;
    .local v8, "chart":Lorg/lighttouch/android/StoreChart;
    .local v20, "browser":Lorg/lighttouch/android/StoreBrowser;
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "store_chart"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-virtual/range {v20 .. v20}, Lorg/lighttouch/android/StoreBrowser;->getChartList()Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v2

    const/16 v3, 0x8

    .local v3, "$this$dp\\51":I
    const/4 v4, 0x0

    .line 583
    .local v4, "$i$f$getDp\\51\\249":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 249
    .end local v3    # "$this$dp\\51":I
    .end local v4    # "$i$f$getDp\\51\\249":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\52":I
    const/4 v5, 0x0

    .line 583
    .local v5, "$i$f$getDp\\52\\249":I
    int-to-float v11, v4

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 249
    .end local v4    # "$this$dp\\52":I
    .end local v5    # "$i$f$getDp\\52\\249":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v3

    invoke-interface {v15, v9}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v4, v5

    .local v4, "invalid\\53":Z
    move-object v5, v15

    .local v5, "$this$cache\\53":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 584
    .local v9, "$i$f$cache\\53\\249":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\53":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 585
    .local v11, "$i$a$-let-ComposerKt$cache$1\\54\\584\\53":I
    if-nez v4, :cond_22

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v10, v12, :cond_21

    goto :goto_19

    .line 589
    :cond_21
    move-object v13, v10

    goto :goto_1a

    .line 586
    :cond_22
    :goto_19
    const/4 v12, 0x0

    .line 249
    .local v12, "$i$a$-cache-StoreBrowseKt$ChartsTab$4\\55\\586\\0":I
    new-instance v13, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda3;

    invoke-direct {v13, v8, v6}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreModel;)V

    .line 586
    .end local v12    # "$i$a$-cache-StoreBrowseKt$ChartsTab$4\\55\\586\\0":I
    nop

    .line 587
    .local v13, "value\\54":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 588
    nop

    .line 585
    .end local v13    # "value\\54":Ljava/lang/Object;
    :goto_1a
    nop

    .line 584
    .end local v10    # "it\\53":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\54\\584\\53":I
    nop

    .line 249
    .end local v4    # "invalid\\53":Z
    .end local v5    # "$this$cache\\53":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\53\\249":I
    move-object/from16 v16, v13

    check-cast v16, Lkotlin/jvm/functions/Function1;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v18, 0x180

    const/16 v19, 0xf8

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    move-object/from16 v17, v15

    .end local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    move-object v9, v8

    move-object v8, v1

    move-object v1, v9

    move-object v9, v2

    move-object v10, v3

    .end local v8    # "chart":Lorg/lighttouch/android/StoreChart;
    .local v1, "chart":Lorg/lighttouch/android/StoreChart;
    invoke-static/range {v8 .. v19}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v15, v17

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v15    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "chart":Lorg/lighttouch/android/StoreChart;
    .end local v20    # "browser":Lorg/lighttouch/android/StoreBrowser;
    :cond_23
    :goto_1b
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_24

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda4;

    invoke-direct {v2, v0, v6, v7}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda4;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 257
    :cond_24
    return-void
.end method

.method private static final ChartsTab$lambda$17$lambda$16$lambda$15(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p1, "$slug"    # Ljava/lang/String;

    .line 232
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->pickChartType(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ChartsTab$lambda$28$lambda$19$lambda$18(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p1, "$device"    # Ljava/lang/String;

    .line 235
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->pickChartDevice(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ChartsTab$lambda$28$lambda$21(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 236
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 966
    .local v3, "$i$f$getValue\\1\\236":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\236":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 236
    return v0
.end method

.method private static final ChartsTab$lambda$28$lambda$22(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 236
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 967
    .local v4, "$i$f$setValue\\1\\236":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 968
    nop

    .line 236
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\236":I
    return-void
.end method

.method private static final ChartsTab$lambda$28$lambda$27$lambda$24$lambda$23(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 238
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$22(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ChartsTab$lambda$28$lambda$27$lambda$26$lambda$25(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 239
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$22(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ChartsTab$lambda$31$lambda$30$lambda$29(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 2
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;

    .line 248
    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0, v0, v1, v0}, Lorg/lighttouch/android/StoreBrowser;->loadChart$default(Lorg/lighttouch/android/StoreBrowser;Ljava/lang/String;ILjava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ChartsTab$lambda$36$lambda$35(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 11
    .param p0, "$chart"    # Lorg/lighttouch/android/StoreChart;
    .param p1, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 250
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreChart;->getRows()Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    :cond_1
    new-instance v1, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda23;

    invoke-direct {v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda23;-><init>()V

    .local v0, "items\\1":Ljava/util/List;
    move-object v2, p2

    .line 969
    .local v1, "key\\1":Lkotlin/jvm/functions/Function1;
    .local v2, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 972
    sget-object v3, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$1;

    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 969
    .local v3, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v4, 0x0

    .line 974
    .local v4, "$i$f$items\\1\\250":I
    nop

    .line 975
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    .line 976
    nop

    .line 974
    new-instance v6, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$2;

    invoke-direct {v6, v1, v0}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    new-instance v7, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$3;

    invoke-direct {v7, v3, v0}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v7, Lkotlin/jvm/functions/Function1;

    .line 978
    new-instance v8, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$4;

    invoke-direct {v8, v0, p1}, Lorg/lighttouch/android/StoreBrowseKt$ChartsTab$lambda$36$lambda$35$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    const v9, -0x25b7f321

    const/4 v10, 0x1

    invoke-static {v9, v10, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    check-cast v8, Lkotlin/jvm/functions/Function4;

    .line 974
    invoke-interface {v2, v5, v6, v7, v8}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 980
    nop

    .line 253
    .end local v0    # "items\\1":Ljava/util/List;
    .end local v1    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v2    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v3    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v4    # "$i$f$items\\1\\250":I
    if-eqz p0, :cond_6

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreChart;->getRows()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\2":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 981
    .local v1, "$i$f$any\\2\\253":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_2

    move v10, v3

    goto :goto_2

    .line 982
    :cond_2
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\2":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lorg/lighttouch/android/ChartRow;

    .local v5, "it\\3":Lorg/lighttouch/android/ChartRow;
    const/4 v6, 0x0

    .line 253
    .local v6, "$i$a$-any-StoreBrowseKt$ChartsTab$4$1$3\\3\\982\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/ChartRow;->getApp()Lorg/json/JSONObject;

    move-result-object v7

    if-nez v7, :cond_4

    move v5, v10

    goto :goto_1

    :cond_4
    move v5, v3

    .line 982
    .end local v5    # "it\\3":Lorg/lighttouch/android/ChartRow;
    .end local v6    # "$i$a$-any-StoreBrowseKt$ChartsTab$4$1$3\\3\\982\\0":I
    :goto_1
    if-eqz v5, :cond_3

    goto :goto_2

    .line 983
    .end local v4    # "element\\2":Ljava/lang/Object;
    :cond_5
    move v10, v3

    .line 253
    .end local v0    # "$this$any\\2":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any\\2\\253":I
    :goto_2
    if-eqz v10, :cond_6

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$-54345052$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p2

    .end local p2    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .local v1, "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    goto :goto_3

    .end local v1    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .restart local p2    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    :cond_6
    move-object v1, p2

    .line 256
    .end local p2    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .restart local v1    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    :goto_3
    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p2
.end method

.method private static final ChartsTab$lambda$36$lambda$35$lambda$32(Lorg/lighttouch/android/ChartRow;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/ChartRow;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 250
    invoke-virtual {p0}, Lorg/lighttouch/android/ChartRow;->getPosition()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0
.end method

.method private static final ChartsTab$lambda$37(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final CollectionsTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 23
    .param p0, "$this$CollectionsTab"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move/from16 v9, p3

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 320
    const v1, 0x36a6cb7

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(CollectionsTab):StoreBrowse.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p3

    .local v3, "$dirty":I
    and-int/lit8 v4, v9, 0x6

    if-nez v4, :cond_1

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_3

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_1

    :cond_2
    const/16 v4, 0x10

    :goto_1
    or-int/2addr v3, v4

    :cond_3
    move v7, v3

    .end local v3    # "$dirty":I
    .local v7, "$dirty":I
    and-int/lit8 v3, v7, 0x13

    const/16 v4, 0x12

    if-ne v3, v4, :cond_5

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    .line 339
    :cond_4
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v17, v2

    move-object v3, v6

    move v10, v7

    goto/16 :goto_c

    .line 320
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_6

    const/4 v3, -0x1

    const-string v4, "org.lighttouch.android.CollectionsTab (StoreBrowse.kt:319)"

    invoke-static {v1, v7, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 321
    :cond_6
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getBrowser()Lorg/lighttouch/android/StoreBrowser;

    move-result-object v8

    .line 322
    .local v8, "browser":Lorg/lighttouch/android/StoreBrowser;
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCollection()Lorg/lighttouch/android/StoreCollection;

    move-result-object v1

    .line 323
    .local v1, "collection":Lorg/lighttouch/android/StoreCollection;
    const-string v5, "CC(remember):StoreBrowse.kt#9igjgp"

    if-nez v1, :cond_d

    const v10, 0x7dc479a9

    invoke-interface {v2, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "326@18477L795,326@18316L956"

    invoke-static {v2, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 324
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCollections()Ljava/util/List;

    move-result-object v10

    .local v10, "list":Ljava/util/List;
    const v11, -0x2d7dc8b6

    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "324@18131L93"

    invoke-static {v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 325
    if-nez v10, :cond_7

    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCollectionsError()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_7

    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static {v11, v14, v12, v13}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/16 v12, 0x10

    .local v12, "$this$dp\\1":I
    const/4 v13, 0x0

    .line 851
    .local v13, "$i$f$getDp\\1\\325":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 325
    .end local v12    # "$this$dp\\1":I
    .end local v13    # "$i$f$getDp\\1\\325":I
    const/16 v13, 0x8

    .local v13, "$this$dp\\2":I
    const/4 v14, 0x0

    .line 851
    .local v14, "$i$f$getDp\\2\\325":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 325
    .end local v13    # "$this$dp\\2":I
    .end local v14    # "$i$f$getDp\\2\\325":I
    invoke-static {v11, v12, v13}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/16 v18, 0x6

    const/16 v19, 0x1e

    move-object v13, v10

    move-object v10, v11

    .end local v10    # "list":Ljava/util/List;
    .local v13, "list":Ljava/util/List;
    const-wide/16 v11, 0x0

    move-object v15, v13

    .end local v13    # "list":Ljava/util/List;
    .local v15, "list":Ljava/util/List;
    const-wide/16 v13, 0x0

    move-object/from16 v16, v15

    .end local v15    # "list":Ljava/util/List;
    .local v16, "list":Ljava/util/List;
    const/4 v15, 0x0

    move-object/from16 v17, v16

    .end local v16    # "list":Ljava/util/List;
    .local v17, "list":Ljava/util/List;
    const/16 v16, 0x0

    move-object/from16 v22, v17

    move-object/from16 v17, v2

    move-object/from16 v2, v22

    .local v2, "list":Ljava/util/List;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v19}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v10, v17

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_3

    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "list":Ljava/util/List;
    :cond_7
    move-object/from16 v22, v10

    move-object v10, v2

    move-object/from16 v2, v22

    .local v2, "list":Ljava/util/List;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    :goto_3
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 326
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCollectionsError()Ljava/lang/String;

    move-result-object v11

    const v12, -0x2d7db259

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "*325@18279L25,325@18265L40"

    invoke-static {v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v11, :cond_8

    goto :goto_6

    .line 370
    .local v11, "it\\3":Ljava/lang/String;
    :cond_8
    const/4 v12, 0x0

    .line 326
    .local v12, "$i$a$-let-StoreBrowseKt$CollectionsTab$1\\3\\326\\0":I
    const v13, 0x4c5de2

    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    .local v13, "invalid\\4":Z
    move-object v14, v10

    .local v14, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 852
    .local v15, "$i$f$cache\\4\\326":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 853
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\852\\4":I
    if-nez v13, :cond_a

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_9

    goto :goto_4

    .line 857
    :cond_9
    move-object v0, v3

    goto :goto_5

    .line 854
    :cond_a
    :goto_4
    const/4 v4, 0x0

    .line 326
    .local v4, "$i$a$-cache-StoreBrowseKt$CollectionsTab$1$1\\6\\854\\3":I
    new-instance v0, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$1$1$1;

    invoke-direct {v0, v8}, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$1$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v0, Lkotlin/reflect/KFunction;

    .line 854
    .end local v4    # "$i$a$-cache-StoreBrowseKt$CollectionsTab$1$1\\6\\854\\3":I
    nop

    .line 855
    .local v0, "value\\5":Ljava/lang/Object;
    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 856
    nop

    .line 853
    .end local v0    # "value\\5":Ljava/lang/Object;
    :goto_5
    nop

    .line 852
    .end local v3    # "it\\4":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\5\\852\\4":I
    nop

    .line 326
    .end local v13    # "invalid\\4":Z
    .end local v14    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\4\\326":I
    check-cast v0, Lkotlin/reflect/KFunction;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    check-cast v0, Lkotlin/jvm/functions/Function0;

    const/4 v3, 0x0

    invoke-static {v11, v0, v10, v3}, Lorg/lighttouch/android/StoreBrowseKt;->ErrorLine(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .end local v11    # "it\\3":Ljava/lang/String;
    .end local v12    # "$i$a$-let-StoreBrowseKt$CollectionsTab$1\\3\\326\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_6
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 327
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    move-object v3, v5

    const/4 v5, 0x0

    move-object v13, v2

    .end local v2    # "list":Ljava/util/List;
    .local v13, "list":Ljava/util/List;
    const/high16 v2, 0x3f800000    # 1.0f

    move-object v11, v3

    const/4 v3, 0x0

    move-object v14, v11

    move-object v12, v13

    const v13, -0x615d173a

    move-object v11, v1

    move-object v1, v0

    move-object/from16 v0, p0

    .end local v1    # "collection":Lorg/lighttouch/android/StoreCollection;
    .end local v13    # "list":Ljava/util/List;
    .local v11, "collection":Lorg/lighttouch/android/StoreCollection;
    .local v12, "list":Ljava/util/List;
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v0, "store_collections"

    invoke-static {v1, v0}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object v1, v11

    .end local v11    # "collection":Lorg/lighttouch/android/StoreCollection;
    .restart local v1    # "collection":Lorg/lighttouch/android/StoreCollection;
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCollectionList()Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v11

    const/16 v2, 0x8

    .local v2, "$this$dp\\7":I
    const/4 v3, 0x0

    .line 858
    .local v3, "$i$f$getDp\\7\\327":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 327
    .end local v2    # "$this$dp\\7":I
    .end local v3    # "$i$f$getDp\\7\\327":I
    const/4 v3, 0x4

    .local v3, "$this$dp\\8":I
    const/4 v4, 0x0

    .line 858
    .local v4, "$i$f$getDp\\8\\327":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 327
    .end local v3    # "$this$dp\\8":I
    .end local v4    # "$i$f$getDp\\8\\327":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v2

    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    .local v3, "invalid\\9":Z
    move-object v4, v10

    .local v4, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 859
    .local v5, "$i$f$cache\\9\\327":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\9":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 860
    .local v14, "$i$a$-let-ComposerKt$cache$1\\10\\859\\9":I
    if-nez v3, :cond_c

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_b

    goto :goto_7

    .line 864
    :cond_b
    move-object/from16 p2, v0

    move-object v0, v13

    goto :goto_8

    .line 861
    :cond_c
    :goto_7
    const/4 v15, 0x0

    .line 327
    .local v15, "$i$a$-cache-StoreBrowseKt$CollectionsTab$2\\11\\861\\0":I
    move-object/from16 p2, v0

    new-instance v0, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda14;

    invoke-direct {v0, v12, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda14;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;)V

    .line 861
    .end local v15    # "$i$a$-cache-StoreBrowseKt$CollectionsTab$2\\11\\861\\0":I
    nop

    .line 862
    .local v0, "value\\10":Ljava/lang/Object;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 863
    nop

    .line 860
    .end local v0    # "value\\10":Ljava/lang/Object;
    :goto_8
    nop

    .line 859
    .end local v13    # "it\\9":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\10\\859\\9":I
    nop

    .line 327
    .end local v3    # "invalid\\9":Z
    .end local v4    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\9\\327":I
    move-object/from16 v18, v0

    check-cast v18, Lkotlin/jvm/functions/Function1;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v20, 0x180

    const/16 v21, 0xf8

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object v0, v12

    move-object v12, v2

    move-object v2, v0

    move-object v0, v1

    move-object/from16 v19, v10

    move-object/from16 v10, p2

    .end local v1    # "collection":Lorg/lighttouch/android/StoreCollection;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v12    # "list":Ljava/util/List;
    .local v0, "collection":Lorg/lighttouch/android/StoreCollection;
    .local v2, "list":Ljava/util/List;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v21}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 323
    move-object/from16 v10, v19

    .end local v2    # "list":Ljava/util/List;
    .end local v19    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v11, v0

    move-object v3, v6

    move-object v2, v8

    move-object/from16 v17, v10

    move-object/from16 v0, p0

    move v10, v7

    goto/16 :goto_b

    .line 339
    .end local v0    # "collection":Lorg/lighttouch/android/StoreCollection;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v1    # "collection":Lorg/lighttouch/android/StoreCollection;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    :cond_d
    move-object v0, v1

    move-object v10, v2

    move-object v14, v5

    const v13, -0x615d173a

    .end local v1    # "collection":Lorg/lighttouch/android/StoreCollection;
    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v0    # "collection":Lorg/lighttouch/android/StoreCollection;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    const v1, 0x7dd6f984

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "339@19294L52,340@19406L38,340@19355L90"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 340
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreCollection;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreCollection;->getSubtitle()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v1, v2, v10, v3}, Lorg/lighttouch/android/StoreBrowseKt;->SectionHeader(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 341
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreBrowser;->getCollectionApps()Lorg/lighttouch/android/Listing;

    move-result-object v1

    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\12":Z
    move-object v3, v10

    .local v3, "$this$cache\\12":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 865
    .local v4, "$i$f$cache\\12\\341":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\12":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 866
    .local v11, "$i$a$-let-ComposerKt$cache$1\\13\\865\\12":I
    if-nez v2, :cond_f

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v5, v12, :cond_e

    goto :goto_9

    .line 870
    :cond_e
    move-object v13, v5

    goto :goto_a

    .line 867
    :cond_f
    :goto_9
    const/4 v12, 0x0

    .line 341
    .local v12, "$i$a$-cache-StoreBrowseKt$CollectionsTab$3\\14\\867\\0":I
    new-instance v13, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda15;

    invoke-direct {v13, v8, v0}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda15;-><init>(Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreCollection;)V

    .line 867
    .end local v12    # "$i$a$-cache-StoreBrowseKt$CollectionsTab$3\\14\\867\\0":I
    nop

    .line 868
    .local v13, "value\\13":Ljava/lang/Object;
    invoke-interface {v3, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 869
    nop

    .line 866
    .end local v13    # "value\\13":Ljava/lang/Object;
    :goto_a
    nop

    .line 865
    .end local v5    # "it\\12":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\13\\865\\12":I
    nop

    .line 341
    .end local v2    # "invalid\\12":Z
    .end local v3    # "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\12\\341":I
    move-object v4, v13

    check-cast v4, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v2, v7, 0xe

    shl-int/lit8 v3, v7, 0x6

    and-int/lit16 v3, v3, 0x1c00

    or-int/2addr v2, v3

    move v3, v7

    move v7, v2

    move-object v2, v8

    .end local v7    # "$dirty":I
    .end local v8    # "browser":Lorg/lighttouch/android/StoreBrowser;
    .local v2, "browser":Lorg/lighttouch/android/StoreBrowser;
    .local v3, "$dirty":I
    const/16 v8, 0x10

    const/4 v5, 0x0

    move-object v11, v10

    move v10, v3

    move-object v3, v6

    move-object v6, v11

    move-object v11, v0

    move-object/from16 v0, p0

    .end local v0    # "collection":Lorg/lighttouch/android/StoreCollection;
    .end local v3    # "$dirty":I
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$dirty":I
    .local v11, "collection":Lorg/lighttouch/android/StoreCollection;
    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 339
    move-object/from16 v17, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v17    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_b
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "browser":Lorg/lighttouch/android/StoreBrowser;
    .end local v11    # "collection":Lorg/lighttouch/android/StoreCollection;
    :cond_10
    :goto_c
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_11

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda16;

    invoke-direct {v2, v0, v3, v9}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda16;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 343
    :cond_11
    return-void
.end method

.method private static final CollectionsTab$lambda$82$lambda$81(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 11
    .param p0, "$list"    # Ljava/util/List;
    .param p1, "$browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 328
    if-nez p0, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, p0

    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda13;

    invoke-direct {v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda13;-><init>()V

    .local v0, "items\\1":Ljava/util/List;
    move-object v2, p2

    .line 999
    .local v1, "key\\1":Lkotlin/jvm/functions/Function1;
    .local v2, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 1002
    sget-object v3, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$1;

    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 999
    .local v3, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v4, 0x0

    .line 1004
    .local v4, "$i$f$items\\1\\328":I
    nop

    .line 1005
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    .line 1006
    nop

    .line 1004
    new-instance v6, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$2;

    invoke-direct {v6, v1, v0}, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    new-instance v7, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$3;

    invoke-direct {v7, v3, v0}, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v7, Lkotlin/jvm/functions/Function1;

    .line 1008
    new-instance v8, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$4;

    invoke-direct {v8, v0, p1}, Lorg/lighttouch/android/StoreBrowseKt$CollectionsTab$lambda$82$lambda$81$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreBrowser;)V

    const v9, -0x25b7f321

    const/4 v10, 0x1

    invoke-static {v9, v10, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    check-cast v8, Lkotlin/jvm/functions/Function4;

    .line 1004
    invoke-interface {v2, v5, v6, v7, v8}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 1010
    nop

    .line 338
    .end local v0    # "items\\1":Ljava/util/List;
    .end local v1    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v2    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v3    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v4    # "$i$f$items\\1\\328":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CollectionsTab$lambda$82$lambda$81$lambda$75(Lorg/lighttouch/android/StoreCollection;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/StoreCollection;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 328
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreCollection;->getSlug()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final CollectionsTab$lambda$84$lambda$83(Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreCollection;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p1, "$collection"    # Lorg/lighttouch/android/StoreCollection;

    .line 341
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreBrowser;->openCollection(Lorg/lighttouch/android/StoreCollection;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CollectionsTab$lambda$85(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->CollectionsTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ErrorLine(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 49
    .param p0, "message"    # Ljava/lang/String;
    .param p1, "onRetry"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 213
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v2, -0x45eadd84

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(ErrorLine)213@11035L298:StoreBrowse.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, p3, 0x6

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_3

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_2

    .line 419
    :cond_4
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v13, v0

    move-object v0, v1

    move-object/from16 v39, v3

    move/from16 v40, v4

    goto/16 :goto_4

    .line 213
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.ErrorLine (StoreBrowse.kt:212)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 214
    :cond_6
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x10

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 379
    .local v6, "$i$f$getDp\\1\\214":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 214
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\214":I
    const/4 v6, 0x4

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 379
    .local v7, "$i$f$getDp\\2\\214":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 214
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\214":I
    invoke-static {v2, v5, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v25, 0x186

    .local v25, "$changed\\3":I
    const/16 v26, 0x0

    .line 380
    .local v26, "$i$f$Row\\3\\214":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v3, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 381
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 385
    .local v6, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v7, v25, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v8, v25, 0x3

    and-int/lit8 v8, v8, 0x70

    or-int/2addr v7, v8

    invoke-static {v6, v5, v3, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v25, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 386
    move/from16 v27, v8

    .local v27, "$changed\\4":I
    const/16 v28, 0x0

    .line 387
    .local v28, "$i$f$Layout\\4\\386":I
    const v8, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 388
    const/4 v8, 0x0

    invoke-static {v3, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 389
    .local v29, "compositeKeyHash\\4":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 390
    .local v8, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 392
    .local v9, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v10

    shl-int/lit8 v11, v27, 0x6

    and-int/lit16 v11, v11, 0x380

    or-int/lit8 v11, v11, 0x6

    .line 391
    nop

    .local v10, "factory\\5":Lkotlin/jvm/functions/Function0;
    move/from16 v30, v11

    .local v30, "$changed\\5":I
    const/16 v31, 0x0

    .line 393
    .local v31, "$i$f$ReusableComposeNode\\5\\391":I
    const v11, -0x2942ffcf

    const-string v12, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 394
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v11

    instance-of v11, v11, Landroidx/compose/runtime/Applier;

    if-nez v11, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 395
    :cond_7
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 396
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-eqz v11, :cond_8

    .line 397
    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 399
    :cond_8
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 401
    :goto_3
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .local v11, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 402
    .local v12, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\401\\4":I
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v11, v7, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 403
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v11, v8, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 405
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\7":Lkotlin/jvm/functions/Function2;
    const/4 v14, 0x0

    .line 406
    .local v14, "$i$f$set-impl\\7\\405":I
    move-object v15, v11

    .local v15, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 407
    .local v16, "$i$a$-with-Updater$set$1\\8\\406\\7":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v17

    if-nez v17, :cond_9

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    .line 408
    :cond_9
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 409
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v11, v0, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 411
    :cond_a
    nop

    .line 406
    .end local v15    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-with-Updater$set$1\\8\\406\\7":I
    nop

    .line 411
    nop

    .line 412
    .end local v13    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v14    # "$i$f$set-impl\\7\\405":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v11, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 413
    nop

    .line 401
    .end local v11    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\401\\4":I
    nop

    .line 414
    shr-int/lit8 v0, v30, 0x6

    and-int/lit8 v32, v0, 0xe

    .local v32, "$changed\\9":I
    move-object v0, v3

    .local v0, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 415
    .local v33, "$i$a$-Layout-RowKt$Row$1\\9\\414\\3":I
    const v1, -0x184f2606

    const-string v11, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v0, v1, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v11, v25, 0x6

    and-int/lit8 v11, v11, 0x70

    or-int/lit8 v34, v11, 0x6

    .local v34, "$changed\\10":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$ErrorLine_u24lambda_u2411\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object v11, v0

    .local v11, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object v12, v1

    .end local v1    # "$this$ErrorLine_u24lambda_u2411\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v12, "$this$ErrorLine_u24lambda_u2411\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v35, 0x0

    .line 215
    .local v35, "$i$a$-Row-StoreBrowseKt$ErrorLine$1\\10\\415\\0":I
    const v1, 0x4dce125c    # 4.321637E8f

    const-string v13, "C214@11209L10,214@11253L11,214@11152L119,215@11280L47:StoreBrowse.kt#o13vsk"

    invoke-static {v11, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v13, v1

    check-cast v13, Landroidx/compose/ui/Modifier;

    const/16 v16, 0x2

    const/16 v17, 0x0

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    move-object/from16 v36, v12

    .end local v12    # "$this$ErrorLine_u24lambda_u2411\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v36, "$this$ErrorLine_u24lambda_u2411\\10":Landroidx/compose/foundation/layout/RowScope;
    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v12

    and-int/lit8 v22, v4, 0xe

    const/16 v23, 0x0

    const v24, 0xfff8

    move v14, v4

    move-object v15, v5

    .end local v4    # "$dirty":I
    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v14, "$dirty":I
    .local v15, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const-wide/16 v4, 0x0

    move-object/from16 v16, v6

    .end local v6    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v16, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/4 v6, 0x0

    move-object/from16 v17, v7

    .end local v7    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v17, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v7, 0x0

    move-object/from16 v18, v8

    .end local v8    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v18, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v8, 0x0

    move-object/from16 v19, v9

    move-object/from16 v21, v10

    .end local v9    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v10    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v19, "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v21, "factory\\5":Lkotlin/jvm/functions/Function0;
    const-wide/16 v9, 0x0

    move-object/from16 v37, v21

    move-object/from16 v21, v11

    .end local v11    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v37, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/4 v11, 0x0

    move-object/from16 v38, v2

    move-wide/from16 v47, v12

    move-object v13, v3

    move-wide/from16 v2, v47

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    .local v38, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v39, v13

    move/from16 v40, v14

    .end local v13    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v14    # "$dirty":I
    .local v39, "$composer":Landroidx/compose/runtime/Composer;
    .local v40, "$dirty":I
    const-wide/16 v13, 0x0

    move-object/from16 v41, v15

    .end local v15    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v41, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const/4 v15, 0x0

    move-object/from16 v42, v16

    .end local v16    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v42, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v16, 0x0

    move-object/from16 v43, v17

    .end local v17    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v43, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v17, 0x0

    move-object/from16 v44, v18

    .end local v18    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v44, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v18, 0x0

    move-object/from16 v45, v19

    .end local v19    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v45, "materialized\\4":Landroidx/compose/ui/Modifier;
    const/16 v19, 0x0

    move-object/from16 v46, v0

    move-object/from16 v0, p0

    .end local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 216
    move-object v13, v0

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$-759746245$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    shr-int/lit8 v0, v40, 0x3

    and-int/lit8 v0, v0, 0xe

    const/high16 v1, 0x30000000

    or-int v11, v0, v1

    const/16 v12, 0x1fe

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object/from16 v0, p1

    move-object/from16 v10, v21

    .end local v21    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 215
    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 217
    nop

    .line 415
    .end local v21    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\10":I
    .end local v35    # "$i$a$-Row-StoreBrowseKt$ErrorLine$1\\10\\415\\0":I
    .end local v36    # "$this$ErrorLine_u24lambda_u2411\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 414
    .end local v32    # "$changed\\9":I
    .end local v33    # "$i$a$-Layout-RowKt$Row$1\\9\\414\\3":I
    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 416
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 393
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 417
    nop

    .line 387
    .end local v30    # "$changed\\5":I
    .end local v31    # "$i$f$ReusableComposeNode\\5\\391":I
    .end local v37    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 418
    nop

    .line 380
    .end local v27    # "$changed\\4":I
    .end local v28    # "$i$f$Layout\\4\\386":I
    .end local v29    # "compositeKeyHash\\4":I
    .end local v44    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v45    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 419
    nop

    .end local v25    # "$changed\\3":I
    .end local v26    # "$i$f$Row\\3\\214":I
    .end local v38    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v41    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v42    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v43    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_b
    :goto_4
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_c

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda27;

    move/from16 v3, p3

    invoke-direct {v2, v13, v0, v3}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda27;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_5

    :cond_c
    move/from16 v3, p3

    .line 218
    :goto_5
    return-void
.end method

.method private static final ErrorLine$lambda$12(Ljava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->ErrorLine(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final FeaturedTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 35
    .param p0, "$this$FeaturedTab"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v3, p1

    move/from16 v9, p3

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    const v1, -0x960baf4

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(FeaturedTab)223@11635L10,223@11679L11,222@11443L265,224@11758L21,224@11713L67:StoreBrowse.kt#o13vsk"

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v4, v9, 0x6

    if-nez v4, :cond_1

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v2, v4

    :cond_1
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_3

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_1

    :cond_2
    const/16 v4, 0x10

    :goto_1
    or-int/2addr v2, v4

    :cond_3
    and-int/lit8 v4, v2, 0x13

    const/16 v5, 0x12

    if-ne v4, v5, :cond_5

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_4

    goto :goto_2

    .line 225
    :cond_4
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v10, v2

    goto/16 :goto_5

    .line 221
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_6

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.FeaturedTab (StoreBrowse.kt:220)"

    invoke-static {v1, v2, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 222
    :cond_6
    move v1, v2

    .end local v2    # "$dirty":I
    .local v1, "$dirty":I
    invoke-virtual {v3}, Lorg/lighttouch/android/StoreModel;->getBrowser()Lorg/lighttouch/android/StoreBrowser;

    move-result-object v2

    .line 223
    .local v2, "browser":Lorg/lighttouch/android/StoreBrowser;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x10

    .local v5, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 420
    .local v7, "$i$f$getDp\\1\\223":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 223
    .end local v5    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\223":I
    const/4 v7, 0x4

    .local v7, "$this$dp\\2":I
    const/4 v8, 0x0

    .line 420
    .local v8, "$i$f$getDp\\2\\223":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 223
    .end local v7    # "$this$dp\\2":I
    .end local v8    # "$i$f$getDp\\2\\223":I
    invoke-static {v4, v5, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 224
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v30

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v12

    .line 223
    nop

    .line 224
    nop

    .line 223
    const-string v10, "\u7531\u5b58\u6863\u65b9\u7cbe\u9009\u3002\u67d0\u4e00\u7248\u672c\u80fd\u5426\u5728\u6b64\u8bbe\u5907\u8fd0\u884c\uff0c\u4f1a\u5728\u6253\u5f00\u5e94\u7528\u65f6\u68c0\u67e5\u3002"

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const-wide/16 v19, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const-wide/16 v23, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v32, 0x36

    const/16 v33, 0x0

    const v34, 0xfff8

    move-object/from16 v31, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v31, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v34}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 225
    .end local v31    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer":Landroidx/compose/runtime/Composer;
    move v4, v1

    .end local v1    # "$dirty":I
    .local v4, "$dirty":I
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreBrowser;->getFeatured()Lorg/lighttouch/android/Listing;

    move-result-object v1

    const v5, 0x4c5de2

    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "CC(remember):StoreBrowse.kt#9igjgp"

    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    .local v5, "invalid\\3":Z
    move-object v7, v6

    .local v7, "$this$cache\\3":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 421
    .local v8, "$i$f$cache\\3\\225":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\3":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 422
    .local v11, "$i$a$-let-ComposerKt$cache$1\\4\\421\\3":I
    if-nez v5, :cond_8

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v10, v12, :cond_7

    goto :goto_3

    .line 426
    :cond_7
    move-object v13, v10

    goto :goto_4

    .line 423
    :cond_8
    :goto_3
    const/4 v12, 0x0

    .line 225
    .local v12, "$i$a$-cache-StoreBrowseKt$FeaturedTab$1\\5\\423\\0":I
    new-instance v13, Lorg/lighttouch/android/StoreBrowseKt$FeaturedTab$1$1;

    invoke-direct {v13, v2}, Lorg/lighttouch/android/StoreBrowseKt$FeaturedTab$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v13, Lkotlin/reflect/KFunction;

    .line 423
    .end local v12    # "$i$a$-cache-StoreBrowseKt$FeaturedTab$1\\5\\423\\0":I
    nop

    .line 424
    .local v13, "value\\4":Ljava/lang/Object;
    invoke-interface {v7, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 425
    nop

    .line 422
    .end local v13    # "value\\4":Ljava/lang/Object;
    :goto_4
    nop

    .line 421
    .end local v10    # "it\\3":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\4\\421\\3":I
    nop

    .line 225
    .end local v5    # "invalid\\3":Z
    .end local v7    # "$this$cache\\3":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\3\\225":I
    check-cast v13, Lkotlin/reflect/KFunction;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    check-cast v13, Lkotlin/jvm/functions/Function0;

    and-int/lit8 v5, v4, 0xe

    shl-int/lit8 v7, v4, 0x6

    and-int/lit16 v7, v7, 0x1c00

    or-int/2addr v7, v5

    const/16 v8, 0x10

    const/4 v5, 0x0

    move v10, v4

    move-object v4, v13

    .end local v4    # "$dirty":I
    .local v10, "$dirty":I
    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/Listing;Lorg/lighttouch/android/StoreBrowser;Lorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "browser":Lorg/lighttouch/android/StoreBrowser;
    :cond_9
    :goto_5
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_a

    new-instance v2, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda0;

    invoke-direct {v2, v0, v3, v9}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 226
    :cond_a
    return-void
.end method

.method private static final FeaturedTab$lambda$14(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->FeaturedTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final GhostRow(Lorg/lighttouch/android/ChartRow;Landroidx/compose/runtime/Composer;I)V
    .locals 83
    .param p0, "row"    # Lorg/lighttouch/android/ChartRow;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 282
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x5c9765b0

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(GhostRow)282@15530L595:StoreBrowse.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    move v5, v6

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v4, 0x3

    if-ne v5, v6, :cond_3

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_1

    .line 784
    :cond_2
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v26, v3

    move/from16 v22, v4

    goto/16 :goto_8

    .line 282
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_4

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.GhostRow (StoreBrowse.kt:281)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 283
    :cond_4
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v2, v7, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/high16 v5, 0x3f000000    # 0.5f

    invoke-static {v2, v5}, Landroidx/compose/ui/draw/AlphaKt;->alpha(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v5, 0x8

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 701
    .local v6, "$i$f$getDp\\1\\283":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 283
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\283":I
    const/16 v6, 0x8

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 701
    .local v7, "$i$f$getDp\\2\\283":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 283
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\283":I
    invoke-static {v2, v5, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v6, 0x186

    .local v6, "$changed\\3":I
    const/4 v7, 0x0

    .line 702
    .local v7, "$i$f$Row\\3\\283":I
    const v8, 0x2952b718

    const-string v9, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 703
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v8

    .line 707
    .local v8, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v9, v6, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v8, v5, v3, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 708
    nop

    .local v10, "$changed\\4":I
    const/4 v11, 0x0

    .line 709
    .local v11, "$i$f$Layout\\4\\708":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 710
    const/4 v14, 0x0

    invoke-static {v3, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v15

    .line 711
    .local v15, "compositeKeyHash\\4":I
    move/from16 p1, v14

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 712
    .local v14, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 714
    .local v12, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 v18, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\3":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v10, 0x6

    and-int/lit16 v2, v2, 0x380

    move/from16 v19, v2

    const/4 v2, 0x6

    or-int/lit8 v19, v19, 0x6

    .line 713
    move-object/from16 v20, v17

    .local v19, "$changed\\5":I
    .local v20, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 715
    .local v17, "$i$f$ReusableComposeNode\\5\\713":I
    move/from16 v21, v2

    const v2, -0x2942ffcf

    move/from16 v22, v4

    .end local v4    # "$dirty":I
    .local v22, "$dirty":I
    const-string v4, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 716
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 717
    :cond_5
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 718
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_6

    .line 719
    move-object/from16 v2, v20

    .end local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_2

    .line 721
    .end local v2    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_6
    move-object/from16 v2, v20

    .end local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 723
    :goto_2
    move-object/from16 v20, v2

    .end local v2    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 724
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\723\\4":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v26, v3

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v26, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 725
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v14, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 727
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 728
    .local v25, "$i$f$set-impl\\7\\727":I
    move-object/from16 v27, v2

    .local v27, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 729
    .local v28, "$i$a$-with-Updater$set$1\\8\\728\\7":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v29

    if-nez v29, :cond_8

    move-object/from16 v29, v5

    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v29, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move/from16 v30, v6

    .end local v6    # "$changed\\3":I
    .local v30, "$changed\\3":I
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_7

    goto :goto_3

    :cond_7
    move-object/from16 v6, v27

    goto :goto_4

    .end local v29    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v30    # "$changed\\3":I
    .restart local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v6    # "$changed\\3":I
    :cond_8
    move-object/from16 v29, v5

    move/from16 v30, v6

    .line 730
    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v6    # "$changed\\3":I
    .restart local v29    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v30    # "$changed\\3":I
    :goto_3
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 731
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v2, v5, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 733
    :goto_4
    nop

    .line 728
    .end local v6    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-with-Updater$set$1\\8\\728\\7":I
    nop

    .line 733
    nop

    .line 734
    .end local v3    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v25    # "$i$f$set-impl\\7\\727":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 735
    nop

    .line 723
    .end local v2    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\723\\4":I
    nop

    .line 736
    shr-int/lit8 v2, v19, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\9":I
    move-object/from16 v3, v26

    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 737
    .local v5, "$i$a$-Layout-RowKt$Row$1\\9\\736\\3":I
    const v6, -0x184f2606

    move/from16 v24, v2

    .end local v2    # "$changed\\9":I
    .local v24, "$changed\\9":I
    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v3, v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v30, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\10":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$GhostRow_u24lambda_u2454\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v52, v3

    .local v52, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 284
    .local v25, "$i$a$-Row-StoreBrowseKt$GhostRow$1\\10\\737\\0":I
    move-object/from16 v27, v2

    .end local v2    # "$this$GhostRow_u24lambda_u2454\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v27, "$this$GhostRow_u24lambda_u2454\\10":Landroidx/compose/foundation/layout/RowScope;
    const v2, 0x504a0591

    move-object/from16 v28, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v28, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v3, "C283@15748L10,283@15673L127,284@15809L28,285@15846L273:StoreBrowse.kt#o13vsk"

    move/from16 v56, v5

    move-object/from16 v5, v52

    .end local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v56, "$i$a$-Layout-RowKt$Row$1\\9\\736\\3":I
    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/ChartRow;->getPosition()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v31

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x20

    .local v3, "$this$dp\\11":I
    const/16 v32, 0x0

    .line 738
    .local v32, "$i$f$getDp\\11\\284":I
    move/from16 v57, v6

    .end local v6    # "$changed\\10":I
    .local v57, "$changed\\10":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 284
    .end local v3    # "$this$dp\\11":I
    .end local v32    # "$i$f$getDp\\11\\284":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v32

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v51

    sget-object v2, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v2

    invoke-static {v2}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v43

    const/16 v54, 0x0

    const v55, 0xfdfc

    const-wide/16 v33, 0x0

    const-wide/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const-wide/16 v44, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v53, 0x30

    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v55}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 285
    .end local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x8

    .local v3, "$this$dp\\12":I
    const/4 v6, 0x0

    .line 739
    .local v6, "$i$f$getDp\\12\\285":I
    move/from16 v31, v6

    .end local v6    # "$i$f$getDp\\12\\285":I
    .local v31, "$i$f$getDp\\12\\285":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 285
    .end local v3    # "$this$dp\\12":I
    .end local v31    # "$i$f$getDp\\12\\285":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    move/from16 v3, v21

    invoke-static {v2, v5, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 286
    move/from16 v2, p1

    .local v2, "$changed\\13":I
    const/4 v3, 0x0

    .line 740
    .local v3, "$i$f$Column\\13\\286":I
    const v6, -0x1cd0f17e

    move/from16 v31, v2

    .end local v2    # "$changed\\13":I
    .local v31, "$changed\\13":I
    const-string v2, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v5, v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 741
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    .line 742
    .local v2, "modifier\\13":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v6

    .line 743
    .local v6, "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v32, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v33, v3

    .end local v3    # "$i$f$Column\\13\\286":I
    .local v33, "$i$f$Column\\13\\286":I
    invoke-virtual/range {v32 .. v32}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v3

    .line 746
    .local v3, "horizontalAlignment\\13":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v32, v31, 0x3

    and-int/lit8 v32, v32, 0xe

    shr-int/lit8 v34, v31, 0x3

    and-int/lit8 v34, v34, 0x70

    move/from16 v35, v7

    .end local v7    # "$i$f$Row\\3\\283":I
    .local v35, "$i$f$Row\\3\\283":I
    or-int v7, v32, v34

    invoke-static {v6, v3, v5, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v32, v31, 0x3

    and-int/lit8 v32, v32, 0x70

    .line 747
    nop

    .local v32, "$changed\\14":I
    const/16 v34, 0x0

    .line 748
    .local v34, "$i$f$Layout\\14\\747":I
    move-object/from16 v36, v3

    const v3, -0x4ee9b9da

    .end local v3    # "horizontalAlignment\\13":Landroidx/compose/ui/Alignment$Horizontal;
    .local v36, "horizontalAlignment\\13":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v5, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 749
    move/from16 v3, p1

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 750
    .local v3, "compositeKeyHash\\14":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 751
    .local v13, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p1, v3

    .end local v3    # "compositeKeyHash\\14":I
    .local p1, "compositeKeyHash\\14":I
    invoke-static {v5, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 753
    .local v3, "materialized\\14":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v37, v2

    .end local v2    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v37, "modifier\\13":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v32, 0x6

    and-int/lit16 v2, v2, 0x380

    const/16 v21, 0x6

    or-int/lit8 v2, v2, 0x6

    .line 752
    move-object/from16 v38, v16

    .local v2, "$changed\\15":I
    .local v38, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 754
    .local v16, "$i$f$ReusableComposeNode\\15\\752":I
    move/from16 v39, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\15":I
    .local v39, "$changed\\15":I
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 755
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 756
    :cond_9
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 757
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_a

    .line 758
    move-object/from16 v2, v38

    .end local v38    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_5

    .line 760
    .end local v2    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v38    # "factory\\15":Lkotlin/jvm/functions/Function0;
    :cond_a
    move-object/from16 v2, v38

    .end local v38    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 762
    :goto_5
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 763
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\762\\14":I
    sget-object v38, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v40, v2

    .end local v2    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v40, "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v38 .. v38}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v7, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 764
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v13, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 766
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\17":Lkotlin/jvm/functions/Function2;
    const/16 v38, 0x0

    .line 767
    .local v38, "$i$f$set-impl\\17\\766":I
    move-object/from16 v41, v4

    .local v41, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v42, 0x0

    .line 768
    .local v42, "$i$a$-with-Updater$set$1\\18\\767\\17":I
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v43

    if-nez v43, :cond_c

    move-object/from16 v52, v5

    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v43, v6

    .end local v6    # "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v43, "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_b

    goto :goto_6

    :cond_b
    move-object/from16 v6, v41

    goto :goto_7

    .end local v43    # "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v6    # "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_c
    move-object/from16 v52, v5

    move-object/from16 v43, v6

    .line 769
    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v6    # "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v43    # "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :goto_6
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v41

    .end local v41    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 770
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 772
    :goto_7
    nop

    .line 767
    .end local v6    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v42    # "$i$a$-with-Updater$set$1\\18\\767\\17":I
    nop

    .line 772
    nop

    .line 773
    .end local v2    # "block\\17":Lkotlin/jvm/functions/Function2;
    .end local v38    # "$i$f$set-impl\\17\\766":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v3, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 774
    nop

    .line 762
    .end local v4    # "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\762\\14":I
    nop

    .line 775
    shr-int/lit8 v2, v39, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\19":I
    move-object/from16 v4, v52

    .local v4, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 776
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\19\\775\\13":I
    const v6, -0x16ef5699

    move/from16 v23, v2

    .end local v2    # "$changed\\19":I
    .local v23, "$changed\\19":I
    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v6, v31, 0x6

    and-int/lit8 v6, v6, 0x70

    const/16 v21, 0x6

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\20":I
    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    .local v2, "$this$GhostRow_u24lambda_u2454_u24lambda_u2453\\20":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v79, v4

    .local v79, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 287
    .local v21, "$i$a$-Column-StoreBrowseKt$GhostRow$1$1\\20\\776\\10":I
    move-object/from16 v38, v2

    .end local v2    # "$this$GhostRow_u24lambda_u2454_u24lambda_u2453\\20":Landroidx/compose/foundation/layout/ColumnScope;
    .local v38, "$this$GhostRow_u24lambda_u2454_u24lambda_u2453\\20":Landroidx/compose/foundation/layout/ColumnScope;
    const v2, -0x786a0659

    move-object/from16 v41, v3

    .end local v3    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .local v41, "materialized\\14":Landroidx/compose/ui/Modifier;
    const-string v3, "C286@15952L10,286@15867L107,287@16036L10,287@16080L11,287@15987L122:StoreBrowse.kt#o13vsk"

    move-object/from16 v42, v4

    .end local v79    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/ChartRow;->getName()Ljava/lang/String;

    move-result-object v58

    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v73

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v78

    const/16 v81, 0xc30

    const v82, 0xd7fe

    const/16 v59, 0x0

    const-wide/16 v60, 0x0

    const-wide/16 v62, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const-wide/16 v71, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x1

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v80, 0x0

    .end local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v79    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v82}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 288
    .end local v79    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v78

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v60

    const/16 v81, 0x0

    const v82, 0xfffa

    const-string v58, "\u4e0d\u5728\u5b58\u6863\u4e2d"

    const/16 v73, 0x0

    const/16 v75, 0x0

    const/16 v80, 0x6

    .end local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v79    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v82}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 287
    invoke-static/range {v79 .. v79}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 289
    nop

    .line 776
    .end local v6    # "$changed\\20":I
    .end local v21    # "$i$a$-Column-StoreBrowseKt$GhostRow$1$1\\20\\776\\10":I
    .end local v38    # "$this$GhostRow_u24lambda_u2454_u24lambda_u2453\\20":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v79    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v42 .. v42}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 775
    .end local v5    # "$i$a$-Layout-ColumnKt$Column$1\\19\\775\\13":I
    .end local v23    # "$changed\\19":I
    .end local v42    # "$composer\\19":Landroidx/compose/runtime/Composer;
    nop

    .line 777
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 754
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 778
    nop

    .line 748
    .end local v16    # "$i$f$ReusableComposeNode\\15\\752":I
    .end local v39    # "$changed\\15":I
    .end local v40    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 779
    nop

    .line 740
    .end local v13    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v32    # "$changed\\14":I
    .end local v34    # "$i$f$Layout\\14\\747":I
    .end local v41    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .end local p1    # "compositeKeyHash\\14":I
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 780
    nop

    .line 284
    .end local v7    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v31    # "$changed\\13":I
    .end local v33    # "$i$f$Column\\13\\286":I
    .end local v36    # "horizontalAlignment\\13":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v37    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v43    # "verticalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 290
    nop

    .line 737
    .end local v25    # "$i$a$-Row-StoreBrowseKt$GhostRow$1\\10\\737\\0":I
    .end local v27    # "$this$GhostRow_u24lambda_u2454\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v57    # "$changed\\10":I
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 736
    .end local v24    # "$changed\\9":I
    .end local v28    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v56    # "$i$a$-Layout-RowKt$Row$1\\9\\736\\3":I
    nop

    .line 781
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 715
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 782
    nop

    .line 709
    .end local v17    # "$i$f$ReusableComposeNode\\5\\713":I
    .end local v19    # "$changed\\5":I
    .end local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 783
    nop

    .line 702
    .end local v10    # "$changed\\4":I
    .end local v11    # "$i$f$Layout\\4\\708":I
    .end local v12    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v14    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "compositeKeyHash\\4":I
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 784
    nop

    .end local v8    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v9    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v29    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v30    # "$changed\\3":I
    .end local v35    # "$i$f$Row\\3\\283":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_d
    :goto_8
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_e

    new-instance v3, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda21;

    invoke-direct {v3, v0, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda21;-><init>(Lorg/lighttouch/android/ChartRow;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 291
    :cond_e
    return-void
.end method

.method private static final GhostRow$lambda$55(Lorg/lighttouch/android/ChartRow;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/StoreBrowseKt;->GhostRow(Lorg/lighttouch/android/ChartRow;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SectionHeader(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 93
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "subtitle"    # Ljava/lang/String;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 346
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v2, -0x12fcd873

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(SectionHeader)P(1)347@19622L442:StoreBrowse.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, p3, 0x6

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_3

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_2

    .line 952
    :cond_4
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v2, v1

    move-object/from16 v74, v3

    move/from16 v75, v4

    goto/16 :goto_a

    .line 346
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.SectionHeader (StoreBrowse.kt:345)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 348
    :cond_6
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x10

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 871
    .local v6, "$i$f$getDp\\1\\348":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 348
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\348":I
    const/4 v6, 0x4

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 871
    .local v7, "$i$f$getDp\\2\\348":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 348
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\348":I
    invoke-static {v2, v5, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v25, 0x186

    .local v25, "$changed\\3":I
    const/16 v26, 0x0

    .line 872
    .local v26, "$i$f$Row\\3\\348":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v3, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 873
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 877
    .local v6, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v7, v25, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v8, v25, 0x3

    and-int/lit8 v8, v8, 0x70

    or-int/2addr v7, v8

    invoke-static {v6, v5, v3, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v25, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 878
    move/from16 v27, v8

    .local v27, "$changed\\4":I
    const/16 v28, 0x0

    .line 879
    .local v28, "$i$f$Layout\\4\\878":I
    const v8, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 880
    const/4 v10, 0x0

    invoke-static {v3, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 881
    .local v29, "compositeKeyHash\\4":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 882
    .local v11, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 884
    .local v12, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v27, 0x6

    and-int/lit16 v14, v14, 0x380

    or-int/lit8 v14, v14, 0x6

    .line 883
    nop

    .local v13, "factory\\5":Lkotlin/jvm/functions/Function0;
    move/from16 v30, v14

    .local v30, "$changed\\5":I
    const/16 v31, 0x0

    .line 885
    .local v31, "$i$f$ReusableComposeNode\\5\\883":I
    const v14, -0x2942ffcf

    const-string v15, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 886
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 887
    :cond_7
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 888
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_8

    .line 889
    invoke-interface {v3, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 891
    :cond_8
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 893
    :goto_3
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 894
    .local v16, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\893\\4":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v14, v7, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 895
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v14, v11, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 897
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 898
    .local v17, "$i$f$set-impl\\7\\897":I
    move-object/from16 v19, v14

    .local v19, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 899
    .local v20, "$i$a$-with-Updater$set$1\\8\\898\\7":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v21

    if-nez v21, :cond_a

    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v8, v19

    goto :goto_5

    .line 900
    :cond_a
    :goto_4
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v8, v19

    .end local v19    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 901
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v14, v0, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 903
    :goto_5
    nop

    .line 898
    .end local v8    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-with-Updater$set$1\\8\\898\\7":I
    nop

    .line 903
    nop

    .line 904
    .end local v10    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\7\\897":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v14, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 905
    nop

    .line 893
    .end local v14    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\893\\4":I
    nop

    .line 906
    shr-int/lit8 v0, v30, 0x6

    and-int/lit8 v32, v0, 0xe

    .local v32, "$changed\\9":I
    move-object v0, v3

    .local v0, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 907
    .local v33, "$i$a$-Layout-RowKt$Row$1\\9\\906\\3":I
    const v8, -0x184f2606

    const-string v10, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v0, v8, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v25, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v34, v10, 0x6

    .local v34, "$changed\\10":I
    check-cast v8, Landroidx/compose/foundation/layout/RowScope;

    .local v8, "$this$SectionHeader_u24lambda_u2488\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object v10, v0

    .local v10, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v35, v8

    .end local v8    # "$this$SectionHeader_u24lambda_u2488\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v35, "$this$SectionHeader_u24lambda_u2488\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v36, 0x0

    .line 349
    .local v36, "$i$a$-Row-StoreBrowseKt$SectionHeader$1\\10\\907\\0":I
    const v8, 0x407d50d3

    const-string v14, "C348@19739L319:StoreBrowse.kt#o13vsk"

    invoke-static {v10, v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v37, 0x0

    .local v37, "$changed\\11":I
    const/16 v38, 0x0

    .line 908
    .local v38, "$i$f$Column\\11\\349":I
    const v8, -0x1cd0f17e

    const-string v14, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v8, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 909
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 910
    .local v8, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v14

    .line 911
    .local v14, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    .line 914
    .local v1, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v37, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v17, v37, 0x3

    and-int/lit8 v17, v17, 0x70

    move-object/from16 v19, v0

    .end local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\9":Landroidx/compose/runtime/Composer;
    or-int v0, v16, v17

    invoke-static {v14, v1, v10, v0}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v0

    .local v0, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v37, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 915
    move/from16 v39, v16

    .local v39, "$changed\\12":I
    const/16 v40, 0x0

    .line 916
    .local v40, "$i$f$Layout\\12\\915":I
    move-object/from16 v16, v1

    const v1, -0x4ee9b9da

    .end local v1    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .local v16, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v10, v1, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 917
    const/4 v1, 0x0

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v41

    .line 918
    .local v41, "compositeKeyHash\\12":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 919
    .local v1, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 921
    .local v9, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 v18, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\3":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v39, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 920
    move/from16 v42, v2

    .local v42, "$changed\\13":I
    move-object/from16 v2, v17

    .local v2, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v43, 0x0

    .line 922
    .local v43, "$i$f$ReusableComposeNode\\13\\920":I
    move-object/from16 v17, v3

    const v3, -0x2942ffcf

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {v10, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 923
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 924
    :cond_b
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 925
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_c

    .line 926
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 928
    :cond_c
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 930
    :goto_6
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 931
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\930\\12":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 p2, v2

    .end local v2    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local p2, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 932
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 934
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 935
    .local v20, "$i$f$set-impl\\15\\934":I
    move-object/from16 v21, v3

    .local v21, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 936
    .local v22, "$i$a$-with-Updater$set$1\\16\\935\\15":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_e

    move-object/from16 v23, v0

    .end local v0    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v23, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v24, v1

    .end local v1    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v24, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d

    goto :goto_7

    :cond_d
    move-object/from16 v1, v21

    goto :goto_8

    .end local v23    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v0    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v1    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_e
    move-object/from16 v23, v0

    move-object/from16 v24, v1

    .line 937
    .end local v0    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v1    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v23    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v24    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_7
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v1, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 938
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v3, v0, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 940
    :goto_8
    nop

    .line 935
    .end local v1    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\16\\935\\15":I
    nop

    .line 940
    nop

    .line 941
    .end local v2    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v20    # "$i$f$set-impl\\15\\934":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v3, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 942
    nop

    .line 930
    .end local v3    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\930\\12":I
    nop

    .line 943
    shr-int/lit8 v0, v42, 0x6

    and-int/lit8 v44, v0, 0xe

    .local v44, "$changed\\17":I
    move-object v0, v10

    .local v0, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/16 v45, 0x0

    .line 944
    .local v45, "$i$a$-Layout-ColumnKt$Column$1\\17\\943\\11":I
    const v1, -0x16ef5699

    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v2, v37, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v46, v2, 0x6

    .local v46, "$changed\\18":I
    move-object/from16 v47, v1

    check-cast v47, Landroidx/compose/foundation/layout/ColumnScope;

    .local v47, "$this$SectionHeader_u24lambda_u2488_u24lambda_u2487\\18":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v1, v0

    .local v1, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v73, 0x0

    .line 350
    .local v73, "$i$a$-Column-StoreBrowseKt$SectionHeader$1$1\\18\\944\\10":I
    const v2, 0x24ccc55c

    const-string v3, "C349@19794L10,349@19760L105:StoreBrowse.kt#o13vsk"

    invoke-static {v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v1, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v15

    and-int/lit8 v22, v4, 0xe

    move-object/from16 v2, v23

    .end local v23    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v2, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v23, 0xc30

    move-object/from16 v3, v24

    .end local v24    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    const v24, 0xd7fe

    move-object/from16 v21, v1

    .end local v1    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    move-object/from16 v48, v2

    move-object/from16 v49, v3

    .end local v2    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v3    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v48, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v49, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    const-wide/16 v2, 0x0

    move/from16 v50, v4

    move-object/from16 v51, v5

    .end local v4    # "$dirty":I
    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v50, "$dirty":I
    .local v51, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const-wide/16 v4, 0x0

    move-object/from16 v52, v6

    .end local v6    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v52, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/4 v6, 0x0

    move-object/from16 v53, v7

    .end local v7    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v53, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v7, 0x0

    move-object/from16 v54, v8

    .end local v8    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v54, "modifier\\11":Landroidx/compose/ui/Modifier;
    const/4 v8, 0x0

    move-object/from16 v56, v9

    move-object/from16 v55, v10

    .end local v9    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v56, "materialized\\12":Landroidx/compose/ui/Modifier;
    const-wide/16 v9, 0x0

    move-object/from16 v57, v11

    .end local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v57, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v11, 0x0

    move-object/from16 v58, v12

    .end local v12    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v58, "materialized\\4":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v59, v13

    move-object/from16 v60, v14

    .end local v13    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v14    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v59, "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v60, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const-wide/16 v13, 0x0

    move-object/from16 v61, v16

    .end local v16    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .local v61, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v16, 0x0

    move-object/from16 v62, v17

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .local v62, "$composer":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x1

    move-object/from16 v63, v18

    .end local v18    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v63, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/16 v18, 0x0

    move-object/from16 v64, v19

    .end local v19    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    move-object/from16 v91, p2

    move-object/from16 v92, v0

    move-object/from16 v88, v48

    move-object/from16 v89, v49

    move/from16 v75, v50

    move-object/from16 v77, v51

    move-object/from16 v78, v52

    move-object/from16 v79, v53

    move-object/from16 v85, v54

    move-object/from16 v84, v55

    move-object/from16 v90, v56

    move-object/from16 v80, v57

    move-object/from16 v81, v58

    move-object/from16 v82, v59

    move-object/from16 v86, v60

    move-object/from16 v87, v61

    move-object/from16 v74, v62

    move-object/from16 v76, v63

    move-object/from16 v83, v64

    move-object/from16 v0, p0

    .end local v0    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v48    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v49    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "$dirty":I
    .end local v51    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v52    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v53    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v54    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v55    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v56    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v57    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v58    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v59    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v60    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v61    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v62    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v63    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v64    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local p2    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v74, "$composer":Landroidx/compose/runtime/Composer;
    .local v75, "$dirty":I
    .local v76, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v77, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v78, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v79, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v80, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v81, "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v82, "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v83, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v84, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v85, "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v86, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v87, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .local v88, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v89, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v90, "materialized\\12":Landroidx/compose/ui/Modifier;
    .local v91, "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v92, "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v1, v21

    .end local v21    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v1    # "$composer\\18":Landroidx/compose/runtime/Composer;
    const v2, 0x6448bb07

    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*350@19925L10,350@19969L11,350@19894L152"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 351
    move-object/from16 v2, p1

    if-nez v2, :cond_f

    move-object/from16 v21, v1

    goto :goto_9

    :cond_f
    move-object/from16 v48, p1

    .line 370
    .local v48, "it\\19":Ljava/lang/String;
    const/4 v3, 0x0

    .line 351
    .local v3, "$i$a$-let-StoreBrowseKt$SectionHeader$1$1$1\\19\\351\\18":I
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v1, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v68

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v1, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v50

    sget-object v4, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v63

    const/16 v71, 0xc30

    const v72, 0xd7fa

    const/16 v49, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const-wide/16 v57, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x1

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v70, 0x0

    move-object/from16 v69, v1

    .end local v1    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v69, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v48 .. v72}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v21, v69

    .end local v3    # "$i$a$-let-StoreBrowseKt$SectionHeader$1$1$1\\19\\351\\18":I
    .end local v48    # "it\\19":Ljava/lang/String;
    .end local v69    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer\\18":Landroidx/compose/runtime/Composer;
    :goto_9
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 350
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 352
    nop

    .line 944
    .end local v21    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v46    # "$changed\\18":I
    .end local v47    # "$this$SectionHeader_u24lambda_u2488_u24lambda_u2487\\18":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v73    # "$i$a$-Column-StoreBrowseKt$SectionHeader$1$1\\18\\944\\10":I
    invoke-static/range {v92 .. v92}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 943
    .end local v44    # "$changed\\17":I
    .end local v45    # "$i$a$-Layout-ColumnKt$Column$1\\17\\943\\11":I
    .end local v92    # "$composer\\17":Landroidx/compose/runtime/Composer;
    nop

    .line 945
    invoke-interface/range {v84 .. v84}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 922
    invoke-static/range {v84 .. v84}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 946
    nop

    .line 916
    .end local v42    # "$changed\\13":I
    .end local v43    # "$i$f$ReusableComposeNode\\13\\920":I
    .end local v91    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v84 .. v84}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 947
    nop

    .line 908
    .end local v39    # "$changed\\12":I
    .end local v40    # "$i$f$Layout\\12\\915":I
    .end local v41    # "compositeKeyHash\\12":I
    .end local v89    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v90    # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static/range {v84 .. v84}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 948
    nop

    .line 349
    .end local v37    # "$changed\\11":I
    .end local v38    # "$i$f$Column\\11\\349":I
    .end local v85    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v86    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v87    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v88    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v84 .. v84}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 353
    nop

    .line 907
    .end local v34    # "$changed\\10":I
    .end local v35    # "$this$SectionHeader_u24lambda_u2488\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v36    # "$i$a$-Row-StoreBrowseKt$SectionHeader$1\\10\\907\\0":I
    .end local v84    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v83 .. v83}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 906
    .end local v32    # "$changed\\9":I
    .end local v33    # "$i$a$-Layout-RowKt$Row$1\\9\\906\\3":I
    .end local v83    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 949
    invoke-interface/range {v74 .. v74}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 885
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 950
    nop

    .line 879
    .end local v30    # "$changed\\5":I
    .end local v31    # "$i$f$ReusableComposeNode\\5\\883":I
    .end local v82    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 951
    nop

    .line 872
    .end local v27    # "$changed\\4":I
    .end local v28    # "$i$f$Layout\\4\\878":I
    .end local v29    # "compositeKeyHash\\4":I
    .end local v80    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v81    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 952
    nop

    .end local v25    # "$changed\\3":I
    .end local v26    # "$i$f$Row\\3\\348":I
    .end local v76    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v77    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v78    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v79    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_10
    :goto_a
    invoke-interface/range {v74 .. v74}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_11

    new-instance v3, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda12;

    move/from16 v4, p3

    invoke-direct {v3, v0, v2, v4}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda12;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-interface {v1, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_b

    :cond_11
    move/from16 v4, p3

    .line 354
    :goto_b
    return-void
.end method

.method private static final SectionHeader$lambda$89(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->SectionHeader(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SnapshotBar(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V
    .locals 74
    .param p0, "chart"    # Lorg/lighttouch/android/StoreChart;
    .param p1, "browser"    # Lorg/lighttouch/android/StoreBrowser;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 261
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const v3, 0x481a534

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(SnapshotBar)P(1)262@14282L34,263@14321L978:StoreBrowse.kt#o13vsk"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    const/4 v7, 0x2

    if-nez v6, :cond_1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    move v6, v7

    :goto_0
    or-int/2addr v5, v6

    :cond_1
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_3

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_1

    :cond_2
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v5, v6

    :cond_3
    and-int/lit8 v6, v5, 0x13

    const/16 v8, 0x12

    if-ne v6, v8, :cond_5

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_4

    goto :goto_2

    .line 700
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v21, v5

    goto/16 :goto_13

    .line 261
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, -0x1

    const-string v8, "org.lighttouch.android.SnapshotBar (StoreBrowse.kt:260)"

    invoke-static {v3, v5, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 262
    :cond_6
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreChart;->getDates()Ljava/util/List;

    move-result-object v3

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreChart;->getDate()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v3, v6}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v3

    .local v3, "index":I
    const v6, 0x6e3c21fe

    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "CC(remember):StoreBrowse.kt#9igjgp"

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 263
    move-object v8, v4

    .local v8, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    move v10, v9

    .local v10, "invalid\\1":Z
    const/4 v11, 0x0

    .line 590
    .local v11, "$i$f$cache\\1\\263":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\1":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 591
    .local v13, "$i$a$-let-ComposerKt$cache$1\\2\\590\\1":I
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    const/4 v15, 0x0

    if-ne v12, v14, :cond_7

    .line 592
    const/4 v14, 0x0

    .line 263
    .local v14, "$i$a$-cache-StoreBrowseKt$SnapshotBar$menu$2\\3\\592\\0":I
    move/from16 p2, v9

    invoke-static/range {p2 .. p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    invoke-static {v9, v15, v7, v15}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v9

    .line 592
    .end local v14    # "$i$a$-cache-StoreBrowseKt$SnapshotBar$menu$2\\3\\592\\0":I
    nop

    .line 593
    .local v9, "value\\2":Ljava/lang/Object;
    invoke-interface {v8, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 594
    nop

    .end local v9    # "value\\2":Ljava/lang/Object;
    goto :goto_3

    .line 595
    :cond_7
    move/from16 p2, v9

    move-object v9, v12

    .line 591
    :goto_3
    nop

    .line 590
    .end local v12    # "it\\1":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\2\\590\\1":I
    nop

    .line 263
    .end local v8    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "invalid\\1":Z
    .end local v11    # "$i$f$cache\\1\\263":I
    move-object v8, v9

    check-cast v8, Landroidx/compose/runtime/MutableState;

    .local v8, "menu$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 264
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x8

    .local v10, "$this$dp\\4":I
    const/4 v11, 0x0

    .line 596
    .local v11, "$i$f$getDp\\4\\264":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 264
    .end local v10    # "$this$dp\\4":I
    .end local v11    # "$i$f$getDp\\4\\264":I
    const/4 v11, 0x0

    invoke-static {v9, v10, v11, v7, v15}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .local v7, "modifier\\5":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v9

    .local v9, "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v10, 0x186

    .local v10, "$changed\\5":I
    const/4 v12, 0x0

    .line 597
    .local v12, "$i$f$Row\\5\\264":I
    const v13, 0x2952b718

    const-string v14, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v4, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 598
    sget-object v13, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v13}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v13

    .line 602
    .local v13, "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v14, v10, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v16, v10, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v14, v14, v16

    invoke-static {v13, v9, v4, v14}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v10, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 603
    nop

    .local v16, "$changed\\6":I
    const/16 v17, 0x0

    .line 604
    .local v17, "$i$f$Layout\\6\\603":I
    const v11, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v4, v11, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 605
    move/from16 v11, p2

    invoke-static {v4, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v20

    .line 606
    .local v20, "compositeKeyHash\\6":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 607
    .local v11, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v21, v5

    .end local v5    # "$dirty":I
    .local v21, "$dirty":I
    invoke-static {v4, v7}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 609
    .local v5, "materialized\\6":Landroidx/compose/ui/Modifier;
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v22

    move-object/from16 v23, v7

    .end local v7    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v23, "modifier\\5":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v7, v16, 0x6

    and-int/lit16 v7, v7, 0x380

    or-int/lit8 v7, v7, 0x6

    .line 608
    nop

    .local v7, "$changed\\7":I
    move-object/from16 v24, v22

    .local v24, "factory\\7":Lkotlin/jvm/functions/Function0;
    const/16 v22, 0x0

    .line 610
    .local v22, "$i$f$ReusableComposeNode\\7\\608":I
    move/from16 v25, v7

    .end local v7    # "$changed\\7":I
    .local v25, "$changed\\7":I
    const v7, -0x2942ffcf

    move-object/from16 v26, v9

    .end local v9    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    .local v26, "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    const-string v9, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v4, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 611
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 612
    :cond_8
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 613
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_9

    .line 614
    move-object/from16 v7, v24

    .end local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v7, "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v7}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 616
    .end local v7    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    :cond_9
    move-object/from16 v7, v24

    .end local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 618
    :goto_4
    move-object/from16 v24, v7

    .end local v7    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 619
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\618\\6":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v30, v10

    .end local v10    # "$changed\\5":I
    .local v30, "$changed\\5":I
    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v7, v14, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 620
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v7, v11, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 622
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\9":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 623
    .local v29, "$i$f$set-impl\\9\\622":I
    move-object/from16 v31, v7

    .local v31, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 624
    .local v32, "$i$a$-with-Updater$set$1\\10\\623\\9":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v33

    if-nez v33, :cond_b

    move-object/from16 v33, v11

    .end local v11    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .local v33, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    move/from16 v34, v12

    .end local v12    # "$i$f$Row\\5\\264":I
    .local v34, "$i$f$Row\\5\\264":I
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_a

    goto :goto_5

    :cond_a
    move-object/from16 v12, v31

    goto :goto_6

    .end local v33    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v34    # "$i$f$Row\\5\\264":I
    .restart local v11    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "$i$f$Row\\5\\264":I
    :cond_b
    move-object/from16 v33, v11

    move/from16 v34, v12

    .line 625
    .end local v11    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "$i$f$Row\\5\\264":I
    .restart local v33    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v34    # "$i$f$Row\\5\\264":I
    :goto_5
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    move-object/from16 v12, v31

    .end local v31    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 626
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v7, v11, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 628
    :goto_6
    nop

    .line 623
    .end local v12    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-with-Updater$set$1\\10\\623\\9":I
    nop

    .line 628
    nop

    .line 629
    .end local v10    # "block\\9":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\9\\622":I
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v7, v5, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 630
    nop

    .line 618
    .end local v7    # "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\618\\6":I
    nop

    .line 631
    shr-int/lit8 v7, v25, 0x6

    and-int/lit8 v7, v7, 0xe

    .local v7, "$changed\\11":I
    move-object v10, v4

    .local v10, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 632
    .local v11, "$i$a$-Layout-RowKt$Row$1\\11\\631\\5":I
    const v12, -0x184f2606

    move-object/from16 v28, v5

    .end local v5    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .local v28, "materialized\\6":Landroidx/compose/ui/Modifier;
    const-string v5, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v10, v12, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v12, v30, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v12, v12, 0x6

    .local v12, "$changed\\12":I
    check-cast v5, Landroidx/compose/foundation/layout/RowScope;

    .local v5, "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v41, v10

    .local v41, "$composer\\12":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 265
    .local v29, "$i$a$-Row-StoreBrowseKt$SnapshotBar$1\\12\\632\\0":I
    move-object/from16 v31, v5

    .end local v5    # "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    .local v31, "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    const v5, -0x3ab7fb1e

    move/from16 v32, v7

    .end local v7    # "$changed\\11":I
    .local v32, "$changed\\11":I
    const-string v7, "C264@14441L26,264@14420L168,265@14597L493,273@15120L25,273@15099L194:StoreBrowse.kt#o13vsk"

    move-object/from16 v44, v10

    .end local v41    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v10, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v5, 0x4c5de2

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    .local v7, "invalid\\13":Z
    move-object/from16 v35, v10

    .local v35, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 633
    .local v36, "$i$f$cache\\13\\265":I
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\13":Ljava/lang/Object;
    const/16 v37, 0x0

    .line 634
    .local v37, "$i$a$-let-ComposerKt$cache$1\\14\\633\\13":I
    if-nez v7, :cond_d

    sget-object v38, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v39, v7

    .end local v7    # "invalid\\13":Z
    .local v39, "invalid\\13":Z
    invoke-virtual/range {v38 .. v38}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_c

    goto :goto_7

    .line 638
    :cond_c
    move-object/from16 v38, v5

    move-object/from16 v7, v35

    goto :goto_8

    .line 634
    .end local v39    # "invalid\\13":Z
    .restart local v7    # "invalid\\13":Z
    :cond_d
    move/from16 v39, v7

    .line 635
    .end local v7    # "invalid\\13":Z
    .restart local v39    # "invalid\\13":Z
    :goto_7
    const/4 v7, 0x0

    .line 265
    .local v7, "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$1\\15\\635\\12":I
    move-object/from16 v38, v5

    .end local v5    # "it\\13":Ljava/lang/Object;
    .local v38, "it\\13":Ljava/lang/Object;
    new-instance v5, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda11;

    invoke-direct {v5, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    .line 635
    .end local v7    # "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$1\\15\\635\\12":I
    nop

    .line 636
    .local v5, "value\\14":Ljava/lang/Object;
    move-object/from16 v7, v35

    .end local v35    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .local v7, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 637
    nop

    .line 634
    .end local v5    # "value\\14":Ljava/lang/Object;
    :goto_8
    nop

    .line 633
    .end local v37    # "$i$a$-let-ComposerKt$cache$1\\14\\633\\13":I
    .end local v38    # "it\\13":Ljava/lang/Object;
    nop

    .line 265
    .end local v7    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$f$cache\\13\\265":I
    .end local v39    # "invalid\\13":Z
    move-object/from16 v35, v5

    check-cast v35, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    if-lez v3, :cond_e

    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChartLoading()Z

    move-result v7

    if-nez v7, :cond_e

    const/16 v37, 0x1

    goto :goto_9

    :cond_e
    const/16 v37, 0x0

    :goto_9
    sget-object v7, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v7}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$-629678091$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v40

    const/high16 v42, 0x30000

    const/16 v43, 0x1a

    const/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    move-object/from16 v41, v10

    .end local v10    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .restart local v41    # "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static/range {v35 .. v43}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 266
    move-object/from16 v7, v41

    .end local v41    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\12":Landroidx/compose/runtime/Composer;
    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v36, v10

    check-cast v36, Landroidx/compose/ui/Modifier;

    const/16 v39, 0x2

    const/16 v40, 0x0

    const/high16 v37, 0x3f800000    # 1.0f

    const/16 v38, 0x0

    move-object/from16 v35, v31

    .end local v31    # "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    .local v35, "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v35 .. v40}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .end local v35    # "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    .local v10, "modifier\\16":Landroidx/compose/ui/Modifier;
    .restart local v31    # "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    sget-object v35, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v5

    .local v5, "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    const/16 v35, 0x30

    .local v35, "$changed\\16":I
    const/16 v37, 0x0

    .line 639
    .local v37, "$i$f$Box\\16\\266":I
    move/from16 v45, v11

    .end local v11    # "$i$a$-Layout-RowKt$Row$1\\11\\631\\5":I
    .local v45, "$i$a$-Layout-RowKt$Row$1\\11\\631\\5":I
    const v11, 0x2bb5b5d7

    move/from16 v46, v12

    .end local v12    # "$changed\\12":I
    .local v46, "$changed\\12":I
    const-string v12, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v7, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 640
    const/4 v11, 0x0

    .line 643
    .local v11, "propagateMinConstraints\\16":Z
    invoke-static {v5, v11}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v38, v35, 0x3

    and-int/lit8 v38, v38, 0x70

    .line 644
    nop

    .local v38, "$changed\\17":I
    const/16 v39, 0x0

    .line 645
    .local v39, "$i$f$Layout\\17\\644":I
    move-object/from16 v40, v5

    const v5, -0x4ee9b9da

    .end local v5    # "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    .local v40, "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    invoke-static {v7, v5, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 646
    const/4 v5, 0x0

    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v15

    .line 647
    .local v15, "compositeKeyHash\\17":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 648
    .local v5, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v19, v11

    .end local v11    # "propagateMinConstraints\\16":Z
    .local v19, "propagateMinConstraints\\16":Z
    invoke-static {v7, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 650
    .local v11, "materialized\\17":Landroidx/compose/ui/Modifier;
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v41

    move-object/from16 v42, v10

    .end local v10    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v42, "modifier\\16":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v10, v38, 0x6

    and-int/lit16 v10, v10, 0x380

    or-int/lit8 v10, v10, 0x6

    .line 649
    nop

    .local v10, "$changed\\18":I
    move-object/from16 v43, v41

    .local v43, "factory\\18":Lkotlin/jvm/functions/Function0;
    const/16 v41, 0x0

    .line 651
    .local v41, "$i$f$ReusableComposeNode\\18\\649":I
    move/from16 v47, v10

    const v10, -0x2942ffcf

    .end local v10    # "$changed\\18":I
    .local v47, "$changed\\18":I
    invoke-static {v7, v10, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 652
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v9

    instance-of v9, v9, Landroidx/compose/runtime/Applier;

    if-nez v9, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 653
    :cond_f
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 654
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-eqz v9, :cond_10

    .line 655
    move-object/from16 v9, v43

    .end local v43    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v9, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 657
    .end local v9    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v43    # "factory\\18":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v9, v43

    .end local v43    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v9    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 659
    :goto_a
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .local v10, "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 660
    .local v27, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\659\\17":I
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v48, v9

    .end local v9    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v48, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v10, v12, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 661
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v10, v5, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 663
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .local v9, "block\\20":Lkotlin/jvm/functions/Function2;
    const/16 v43, 0x0

    .line 664
    .local v43, "$i$f$set-impl\\20\\663":I
    move-object/from16 v49, v10

    .local v49, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v50, 0x0

    .line 665
    .local v50, "$i$a$-with-Updater$set$1\\21\\664\\20":I
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v51

    if-nez v51, :cond_12

    move-object/from16 v51, v5

    .end local v5    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .local v51, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v52, v12

    .end local v12    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v52, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v5, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_11

    goto :goto_b

    :cond_11
    move-object/from16 v12, v49

    goto :goto_c

    .end local v51    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v52    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v5    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_12
    move-object/from16 v51, v5

    move-object/from16 v52, v12

    .line 666
    .end local v5    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v51    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v52    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_b
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v12, v49

    .end local v49    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 667
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v10, v5, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 669
    :goto_c
    nop

    .line 664
    .end local v12    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-with-Updater$set$1\\21\\664\\20":I
    nop

    .line 669
    nop

    .line 670
    .end local v9    # "block\\20":Lkotlin/jvm/functions/Function2;
    .end local v43    # "$i$f$set-impl\\20\\663":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v10, v11, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 671
    nop

    .line 659
    .end local v10    # "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\659\\17":I
    nop

    .line 672
    shr-int/lit8 v5, v47, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\22":I
    move-object v9, v7

    .local v9, "$composer\\22":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 673
    .local v10, "$i$a$-Layout-BoxKt$Box$1\\22\\672\\16":I
    const v12, -0x7ff519f7    # -1.000876E-39f

    move/from16 v27, v5

    .end local v5    # "$changed\\22":I
    .local v27, "$changed\\22":I
    const-string v5, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v9, v12, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v12, v35, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v12, v12, 0x6

    .local v12, "$changed\\23":I
    check-cast v5, Landroidx/compose/foundation/layout/BoxScope;

    .local v5, "$this$SnapshotBar_u24lambda_u2450_u24lambda_u2447\\23":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v63, v9

    .local v63, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 267
    .local v43, "$i$a$-Box-StoreBrowseKt$SnapshotBar$1$2\\23\\673\\12":I
    move-object/from16 v49, v5

    .end local v5    # "$this$SnapshotBar_u24lambda_u2450_u24lambda_u2447\\23":Landroidx/compose/foundation/layout/BoxScope;
    .local v49, "$this$SnapshotBar_u24lambda_u2450_u24lambda_u2447\\23":Landroidx/compose/foundation/layout/BoxScope;
    const v5, 0x389ddd2e

    move-object/from16 v50, v9

    .end local v9    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\22":Landroidx/compose/runtime/Composer;
    const-string v9, "C266@14694L15,266@14711L102,266@14673L140,269@14845L16,269@14896L184,269@14826L254:StoreBrowse.kt#o13vsk"

    move/from16 v71, v10

    move-object/from16 v10, v63

    .end local v63    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v71, "$i$a$-Layout-BoxKt$Box$1\\22\\672\\16":I
    invoke-static {v10, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v5, 0x4c5de2

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v5, 0x0

    .local v5, "invalid\\24":Z
    move-object v9, v10

    .local v9, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 674
    .local v53, "$i$f$cache\\24\\267":I
    move/from16 v54, v5

    .end local v5    # "invalid\\24":Z
    .local v54, "invalid\\24":Z
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\24":Ljava/lang/Object;
    const/16 v55, 0x0

    .line 675
    .local v55, "$i$a$-let-ComposerKt$cache$1\\25\\674\\24":I
    sget-object v56, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v72, v11

    .end local v11    # "materialized\\17":Landroidx/compose/ui/Modifier;
    .local v72, "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v5, v11, :cond_13

    .line 676
    const/4 v11, 0x0

    .line 267
    .local v11, "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$2$1\\26\\676\\23":I
    move-object/from16 v56, v5

    .end local v5    # "it\\24":Ljava/lang/Object;
    .local v56, "it\\24":Ljava/lang/Object;
    new-instance v5, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda22;

    invoke-direct {v5, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda22;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 676
    .end local v11    # "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$2$1\\26\\676\\23":I
    nop

    .line 677
    .local v5, "value\\25":Ljava/lang/Object;
    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 678
    nop

    .end local v5    # "value\\25":Ljava/lang/Object;
    goto :goto_d

    .line 679
    .end local v56    # "it\\24":Ljava/lang/Object;
    .local v5, "it\\24":Ljava/lang/Object;
    :cond_13
    move-object/from16 v56, v5

    .line 675
    .end local v5    # "it\\24":Ljava/lang/Object;
    .restart local v56    # "it\\24":Ljava/lang/Object;
    :goto_d
    nop

    .line 674
    .end local v55    # "$i$a$-let-ComposerKt$cache$1\\25\\674\\24":I
    .end local v56    # "it\\24":Ljava/lang/Object;
    nop

    .line 267
    .end local v9    # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$f$cache\\24\\267":I
    .end local v54    # "invalid\\24":Z
    move-object/from16 v53, v5

    check-cast v53, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v5, Lorg/lighttouch/android/StoreBrowseKt$SnapshotBar$1$2$2;

    invoke-direct {v5, v0}, Lorg/lighttouch/android/StoreBrowseKt$SnapshotBar$1$2$2;-><init>(Lorg/lighttouch/android/StoreChart;)V

    const v9, 0x1889139b

    const/16 v11, 0x36

    move/from16 v73, v12

    const/4 v12, 0x1

    .end local v12    # "$changed\\23":I
    .local v73, "$changed\\23":I
    invoke-static {v9, v12, v5, v10, v11}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object/from16 v62, v5

    check-cast v62, Lkotlin/jvm/functions/Function3;

    const v64, 0x30000006

    const/16 v65, 0x1fe

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    move-object/from16 v63, v10

    .end local v10    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v63    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v53 .. v65}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 270
    .end local v63    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static {v8}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$39(Landroidx/compose/runtime/MutableState;)Z

    move-result v53

    const v5, 0x4c5de2

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v5, 0x0

    .local v5, "invalid\\27":Z
    move-object v9, v10

    .local v9, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 680
    .local v12, "$i$f$cache\\27\\270":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\27":Ljava/lang/Object;
    const/16 v55, 0x0

    .line 681
    .local v55, "$i$a$-let-ComposerKt$cache$1\\28\\680\\27":I
    sget-object v56, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v57, v5

    .end local v5    # "invalid\\27":Z
    .local v57, "invalid\\27":Z
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v11, v5, :cond_14

    .line 682
    const/4 v5, 0x0

    .line 270
    .local v5, "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$2$3\\29\\682\\23":I
    move/from16 v56, v5

    .end local v5    # "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$2$3\\29\\682\\23":I
    .local v56, "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$2$3\\29\\682\\23":I
    new-instance v5, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda24;

    invoke-direct {v5, v8}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda24;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 682
    .end local v56    # "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$2$3\\29\\682\\23":I
    nop

    .line 683
    .local v5, "value\\28":Ljava/lang/Object;
    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 684
    nop

    .end local v5    # "value\\28":Ljava/lang/Object;
    goto :goto_e

    .line 685
    :cond_14
    move-object v5, v11

    .line 681
    :goto_e
    nop

    .line 680
    .end local v11    # "it\\27":Ljava/lang/Object;
    .end local v55    # "$i$a$-let-ComposerKt$cache$1\\28\\680\\27":I
    nop

    .line 270
    .end local v9    # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\27\\270":I
    .end local v57    # "invalid\\27":Z
    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/16 v11, 0x168

    .local v11, "$this$dp\\30":I
    const/4 v12, 0x0

    .line 686
    .local v12, "$i$f$getDp\\30\\270":I
    move-object/from16 v55, v5

    int-to-float v5, v11

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 270
    .end local v11    # "$this$dp\\30":I
    .end local v12    # "$i$f$getDp\\30\\270":I
    move-object/from16 v18, v13

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x1

    .end local v13    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v18, "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v9, v11, v5, v13, v12}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    new-instance v9, Lorg/lighttouch/android/StoreBrowseKt$SnapshotBar$1$2$4;

    invoke-direct {v9, v0, v1, v8}, Lorg/lighttouch/android/StoreBrowseKt$SnapshotBar$1$2$4;-><init>(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/MutableState;)V

    const v11, -0x16dbe9fd

    const/16 v12, 0x36

    invoke-static {v11, v13, v9, v10, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v9

    move-object/from16 v66, v9

    check-cast v66, Lkotlin/jvm/functions/Function3;

    const/16 v69, 0x30

    const/16 v70, 0x7f8

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v68, 0x1b0

    move-object/from16 v67, v10

    move-object/from16 v54, v55

    move-object/from16 v55, v5

    .end local v10    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v67, "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v53 .. v70}, Landroidx/compose/material3/AndroidMenu_androidKt;->DropdownMenu-IlH_yew(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/ScrollState;Landroidx/compose/ui/window/PopupProperties;Landroidx/compose/ui/graphics/Shape;JFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    .line 267
    .end local v67    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 273
    nop

    .line 673
    .end local v10    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-Box-StoreBrowseKt$SnapshotBar$1$2\\23\\673\\12":I
    .end local v49    # "$this$SnapshotBar_u24lambda_u2450_u24lambda_u2447\\23":Landroidx/compose/foundation/layout/BoxScope;
    .end local v73    # "$changed\\23":I
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 672
    .end local v27    # "$changed\\22":I
    .end local v50    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .end local v71    # "$i$a$-Layout-BoxKt$Box$1\\22\\672\\16":I
    nop

    .line 687
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 651
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 688
    nop

    .line 645
    .end local v41    # "$i$f$ReusableComposeNode\\18\\649":I
    .end local v47    # "$changed\\18":I
    .end local v48    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 689
    nop

    .line 639
    .end local v15    # "compositeKeyHash\\17":I
    .end local v38    # "$changed\\17":I
    .end local v39    # "$i$f$Layout\\17\\644":I
    .end local v51    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v72    # "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 690
    const v5, 0x4c5de2

    .end local v19    # "propagateMinConstraints\\16":Z
    .end local v35    # "$changed\\16":I
    .end local v37    # "$i$f$Box\\16\\266":I
    .end local v40    # "contentAlignment\\16":Landroidx/compose/ui/Alignment;
    .end local v42    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .end local v52    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    .line 274
    nop

    .local v5, "invalid\\31":Z
    move-object v6, v7

    .local v6, "$this$cache\\31":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 691
    .local v9, "$i$f$cache\\31\\274":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\31":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 692
    .local v11, "$i$a$-let-ComposerKt$cache$1\\32\\691\\31":I
    if-nez v5, :cond_16

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v10, v12, :cond_15

    goto :goto_f

    .line 696
    :cond_15
    move-object v13, v10

    goto :goto_10

    .line 693
    :cond_16
    :goto_f
    const/4 v12, 0x0

    .line 274
    .local v12, "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$3\\33\\693\\12":I
    new-instance v13, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda25;

    invoke-direct {v13, v1}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda25;-><init>(Lorg/lighttouch/android/StoreBrowser;)V

    .line 693
    .end local v12    # "$i$a$-cache-StoreBrowseKt$SnapshotBar$1$3\\33\\693\\12":I
    nop

    .line 694
    .local v13, "value\\32":Ljava/lang/Object;
    invoke-interface {v6, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 695
    nop

    .line 692
    .end local v13    # "value\\32":Ljava/lang/Object;
    :goto_10
    nop

    .line 691
    .end local v10    # "it\\31":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\32\\691\\31":I
    nop

    .line 274
    .end local v5    # "invalid\\31":Z
    .end local v6    # "$this$cache\\31":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\31\\274":I
    move-object/from16 v35, v13

    check-cast v35, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    if-ltz v3, :cond_17

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreChart;->getDates()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    const/16 v36, 0x1

    add-int/lit8 v5, v5, -0x1

    if-ge v3, v5, :cond_18

    move/from16 v11, v36

    goto :goto_11

    :cond_17
    const/16 v36, 0x1

    :cond_18
    const/4 v11, 0x0

    :goto_11
    if-eqz v11, :cond_19

    invoke-virtual {v1}, Lorg/lighttouch/android/StoreBrowser;->getChartLoading()Z

    move-result v5

    if-nez v5, :cond_19

    move/from16 v37, v36

    goto :goto_12

    :cond_19
    const/16 v37, 0x0

    :goto_12
    sget-object v5, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;

    invoke-virtual {v5}, Lorg/lighttouch/android/ComposableSingletons$StoreBrowseKt;->getLambda$842539884$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v40

    const/high16 v42, 0x30000

    const/16 v43, 0x1a

    const/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    move-object/from16 v41, v7

    .end local v7    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static/range {v35 .. v43}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 265
    .end local v41    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 275
    nop

    .line 632
    .end local v7    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-Row-StoreBrowseKt$SnapshotBar$1\\12\\632\\0":I
    .end local v31    # "$this$SnapshotBar_u24lambda_u2450\\12":Landroidx/compose/foundation/layout/RowScope;
    .end local v46    # "$changed\\12":I
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 631
    .end local v32    # "$changed\\11":I
    .end local v44    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v45    # "$i$a$-Layout-RowKt$Row$1\\11\\631\\5":I
    nop

    .line 697
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 610
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 698
    nop

    .line 604
    .end local v22    # "$i$f$ReusableComposeNode\\7\\608":I
    .end local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .end local v25    # "$changed\\7":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 699
    nop

    .line 597
    .end local v16    # "$changed\\6":I
    .end local v17    # "$i$f$Layout\\6\\603":I
    .end local v20    # "compositeKeyHash\\6":I
    .end local v28    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .end local v33    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 700
    nop

    .end local v14    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v23    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .end local v26    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    .end local v30    # "$changed\\5":I
    .end local v34    # "$i$f$Row\\5\\264":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v3    # "index":I
    .end local v8    # "menu$delegate":Landroidx/compose/runtime/MutableState;
    :cond_1a
    :goto_13
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_1b

    new-instance v5, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda26;

    invoke-direct {v5, v0, v1, v2}, Lorg/lighttouch/android/StoreBrowseKt$$ExternalSyntheticLambda26;-><init>(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;I)V

    invoke-interface {v3, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 276
    :cond_1b
    return-void
.end method

.method private static final SnapshotBar$lambda$39(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 263
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 984
    .local v3, "$i$f$getValue\\1\\263":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\263":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 263
    return v0
.end method

.method private static final SnapshotBar$lambda$40(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 263
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 985
    .local v4, "$i$f$setValue\\1\\263":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 986
    nop

    .line 263
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\263":I
    return-void
.end method

.method private static final SnapshotBar$lambda$50$lambda$42$lambda$41(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;

    .line 265
    const/4 v0, -0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->shiftChart(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SnapshotBar$lambda$50$lambda$47$lambda$44$lambda$43(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 267
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$40(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SnapshotBar$lambda$50$lambda$47$lambda$46$lambda$45(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 270
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$40(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SnapshotBar$lambda$50$lambda$49$lambda$48(Lorg/lighttouch/android/StoreBrowser;)Lkotlin/Unit;
    .locals 1
    .param p0, "$browser"    # Lorg/lighttouch/android/StoreBrowser;

    .line 274
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreBrowser;->shiftChart(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SnapshotBar$lambda$51(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar(Lorg/lighttouch/android/StoreChart;Lorg/lighttouch/android/StoreBrowser;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$AppListing$lambda$4(Landroidx/compose/runtime/State;)Z
    .locals 1
    .param p0, "$atEnd$delegate"    # Landroidx/compose/runtime/State;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->AppListing$lambda$4(Landroidx/compose/runtime/State;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$ChartsTab$lambda$28$lambda$22(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowseKt;->ChartsTab$lambda$28$lambda$22(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$GhostRow(Lorg/lighttouch/android/ChartRow;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "row"    # Lorg/lighttouch/android/ChartRow;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreBrowseKt;->GhostRow(Lorg/lighttouch/android/ChartRow;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$SnapshotBar$lambda$40(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreBrowseKt;->SnapshotBar$lambda$40(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$snapshotDate(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p0, "date"    # Ljava/lang/String;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/StoreBrowseKt;->snapshotDate(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final snapshotDate(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "date"    # Ljava/lang/String;

    .line 279
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 370
    const/4 v0, 0x0

    .line 279
    .local v0, "$i$a$-runCatching-StoreBrowseKt$snapshotDate$1\\1\\279\\0":I
    move-object v1, p0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Ljava/time/LocalDate;->parse(Ljava/lang/CharSequence;)Ljava/time/LocalDate;

    move-result-object v1

    sget-object v2, Ljava/time/format/FormatStyle;->MEDIUM:Ljava/time/format/FormatStyle;

    invoke-static {v2}, Ljava/time/format/DateTimeFormatter;->ofLocalizedDate(Ljava/time/format/FormatStyle;)Ljava/time/format/DateTimeFormatter;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    move-result-object v1

    .end local v0    # "$i$a$-runCatching-StoreBrowseKt$snapshotDate$1\\1\\279\\0":I
    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    move-object v0, p0

    :cond_0
    check-cast v0, Ljava/lang/String;

    return-object v0
.end method

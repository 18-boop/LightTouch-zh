.class public final Lorg/lighttouch/android/WorkerPerformanceSampler;
.super Ljava/lang/Object;
.source "WorkerPerformanceSampler.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nWorkerPerformanceSampler.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WorkerPerformanceSampler.kt\norg/lighttouch/android/WorkerPerformanceSampler\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,82:1\n1#2:83\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\u0008\u0001\u0018\u00002\u00020\u0001:\u0001\u001bB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0016\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015J\u0010\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0006\u0010\u0019\u001a\u00020\u001aR\u0016\u0010\u0006\u001a\n \u0007*\u0004\u0018\u00010\u00030\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u000c\u001a\n \u0007*\u0004\u0018\u00010\r0\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001c"
    }
    d2 = {
        "Lorg/lighttouch/android/WorkerPerformanceSampler;",
        "",
        "context",
        "Landroid/content/Context;",
        "<init>",
        "(Landroid/content/Context;)V",
        "application",
        "kotlin.jvm.PlatformType",
        "gate",
        "Lorg/lighttouch/android/PerformanceSamplingGate;",
        "counters",
        "Lorg/lighttouch/android/PerformanceCounters;",
        "executor",
        "Ljava/util/concurrent/ExecutorService;",
        "cached",
        "Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;",
        "request",
        "Landroid/os/Bundle;",
        "callerPid",
        "",
        "observationEpoch",
        "",
        "collect",
        "ticket",
        "Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;",
        "close",
        "",
        "Cached",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final application:Landroid/content/Context;

.field private volatile cached:Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;

.field private final counters:Lorg/lighttouch/android/PerformanceCounters;

.field private final executor:Ljava/util/concurrent/ExecutorService;

.field private final gate:Lorg/lighttouch/android/PerformanceSamplingGate;


# direct methods
.method public static synthetic $r8$lambda$K278fP6vbjysB-ecWZdMrksm_xU(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/WorkerPerformanceSampler;->executor$lambda$1(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NN3ujzWtLhml4NVE5N8pMfsHCI8(Lorg/lighttouch/android/WorkerPerformanceSampler;Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/WorkerPerformanceSampler;->request$lambda$3$lambda$2(Lorg/lighttouch/android/WorkerPerformanceSampler;Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/WorkerPerformanceSampler;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 8
    .param p1, "context"    # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->application:Landroid/content/Context;

    .line 15
    new-instance v1, Lorg/lighttouch/android/PerformanceSamplingGate;

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    invoke-direct/range {v1 .. v7}, Lorg/lighttouch/android/PerformanceSamplingGate;-><init>(JJILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v1, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->gate:Lorg/lighttouch/android/PerformanceSamplingGate;

    .line 16
    new-instance v0, Lorg/lighttouch/android/PerformanceCounters;

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/PerformanceCounters;-><init>(JILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->counters:Lorg/lighttouch/android/PerformanceCounters;

    .line 17
    new-instance v0, Lorg/lighttouch/android/WorkerPerformanceSampler$$ExternalSyntheticLambda1;

    invoke-direct {v0}, Lorg/lighttouch/android/WorkerPerformanceSampler$$ExternalSyntheticLambda1;-><init>()V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->executor:Ljava/util/concurrent/ExecutorService;

    .line 13
    return-void
.end method

.method private final collect(Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)Landroid/os/Bundle;
    .locals 14
    .param p1, "ticket"    # Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;

    .line 47
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    .line 48
    .local v4, "begin":J
    :try_start_0
    invoke-static {}, Landroid/os/Process;->getElapsedCpuTime()J

    move-result-wide v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    move-wide v6, v0

    goto :goto_0

    :catch_0
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/RuntimeException;
    const-wide/16 v1, -0x1

    move-wide v6, v1

    .line 49
    .end local v0    # "<unused var>":Ljava/lang/RuntimeException;
    .local v6, "cpuTime":J
    :goto_0
    iget-object v8, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->counters:Lorg/lighttouch/android/PerformanceCounters;

    new-instance v0, Lorg/lighttouch/android/PerformanceCounters$Counter;

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-virtual {p1}, Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;->getEpoch()J

    move-result-wide v2

    invoke-direct/range {v0 .. v7}, Lorg/lighttouch/android/PerformanceCounters$Counter;-><init>(IJJJ)V

    invoke-virtual {v8, v0}, Lorg/lighttouch/android/PerformanceCounters;->sample(Lorg/lighttouch/android/PerformanceCounters$Counter;)Lorg/lighttouch/android/PerformanceCounters$Reading;

    move-result-object v1

    .line 50
    .local v1, "cpu":Lorg/lighttouch/android/PerformanceCounters$Reading;
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v2, v0

    .local v2, "$this$collect_u24lambda_u249\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 51
    .local v3, "$i$a$-apply-WorkerPerformanceSampler$collect$values$1\\1\\50\\0":I
    const-string v8, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v9

    invoke-virtual {v2, v8, v9}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v8, "uid"

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v9

    invoke-virtual {v2, v8, v9}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 52
    const-string v8, "cpuSampleElapsedMs"

    invoke-virtual {v2, v8, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v8, "processCpuMs"

    invoke-virtual {v2, v8, v6, v7}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 53
    const-string v8, "cpuState"

    invoke-virtual {v1}, Lorg/lighttouch/android/PerformanceCounters$Reading;->getState()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v8, v9}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    invoke-virtual {v1}, Lorg/lighttouch/android/PerformanceCounters$Reading;->getPercent()Ljava/lang/Double;

    move-result-object v8

    if-eqz v8, :cond_0

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v8

    .line 83
    .local v8, "it\\2":D
    const/4 v10, 0x0

    .line 54
    .local v10, "$i$a$-let-WorkerPerformanceSampler$collect$values$1$1\\2\\54\\1":I
    const-string v11, "workerCpuPercentOfOneCore"

    invoke-virtual {v2, v11, v8, v9}, Landroid/os/Bundle;->putDouble(Ljava/lang/String;D)V

    .line 55
    .end local v8    # "it\\2":D
    .end local v10    # "$i$a$-let-WorkerPerformanceSampler$collect$values$1$1\\2\\54\\1":I
    :cond_0
    nop

    .line 50
    .end local v2    # "$this$collect_u24lambda_u249\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-WorkerPerformanceSampler$collect$values$1\\1\\50\\0":I
    move-object v2, v0

    .line 56
    .local v2, "values":Landroid/os/Bundle;
    nop

    .line 57
    :try_start_1
    new-instance v0, Landroid/os/Debug$MemoryInfo;

    invoke-direct {v0}, Landroid/os/Debug$MemoryInfo;-><init>()V

    .line 58
    .local v0, "memory":Landroid/os/Debug$MemoryInfo;
    invoke-static {v0}, Landroid/os/Debug;->getMemoryInfo(Landroid/os/Debug$MemoryInfo;)V

    .line 59
    sget-object v3, Lorg/lighttouch/android/PerformanceMemoryReading;->INSTANCE:Lorg/lighttouch/android/PerformanceMemoryReading;

    invoke-virtual {v0}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result v8

    int-to-long v8, v8

    invoke-virtual {v3, v8, v9}, Lorg/lighttouch/android/PerformanceMemoryReading;->workerPssKiB(J)Ljava/lang/Long;

    move-result-object v3

    .line 60
    .local v3, "pss":Ljava/lang/Long;
    if-eqz v3, :cond_1

    .line 61
    const-string v8, "workerPssKiB"

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    invoke-virtual {v2, v8, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 62
    const-string v8, "pssSampleElapsedMs"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v9

    invoke-virtual {v2, v8, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    .end local v0    # "memory":Landroid/os/Debug$MemoryInfo;
    .end local v3    # "pss":Ljava/lang/Long;
    goto :goto_1

    .line 64
    :catch_1
    move-exception v0

    .line 65
    :cond_1
    :goto_1
    nop

    .line 66
    :try_start_2
    iget-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->application:Landroid/content/Context;

    const-class v3, Landroid/app/ActivityManager;

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    .line 67
    .local v0, "manager":Landroid/app/ActivityManager;
    new-instance v3, Landroid/app/ActivityManager$MemoryInfo;

    invoke-direct {v3}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    .line 68
    .local v3, "memory":Landroid/app/ActivityManager$MemoryInfo;
    if-eqz v0, :cond_2

    invoke-virtual {v0, v3}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    .line 69
    :cond_2
    if-eqz v0, :cond_4

    iget-wide v8, v3, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    const-wide/16 v10, 0x0

    cmp-long v8, v8, v10

    if-lez v8, :cond_4

    iget-wide v8, v3, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    iget-wide v12, v3, Landroid/app/ActivityManager$MemoryInfo;->availMem:J

    cmp-long v10, v10, v12

    const/4 v11, 0x0

    if-gtz v10, :cond_3

    cmp-long v8, v12, v8

    if-gtz v8, :cond_3

    const/4 v11, 0x1

    :cond_3
    if-eqz v11, :cond_4

    .line 70
    const-string v8, "deviceAvailableBytes"

    iget-wide v9, v3, Landroid/app/ActivityManager$MemoryInfo;->availMem:J

    invoke-virtual {v2, v8, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 71
    const-string v8, "deviceTotalBytes"

    iget-wide v9, v3, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    invoke-virtual {v2, v8, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 72
    const-string v8, "deviceMemorySampleElapsedMs"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v9

    invoke-virtual {v2, v8, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2

    .end local v0    # "manager":Landroid/app/ActivityManager;
    .end local v3    # "memory":Landroid/app/ActivityManager$MemoryInfo;
    goto :goto_2

    .line 74
    :catch_2
    move-exception v0

    .line 75
    :cond_4
    :goto_2
    const-string v0, "collectionCompletedElapsedMs"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    invoke-virtual {v2, v0, v8, v9}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 76
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    sub-long/2addr v8, v4

    const-string v0, "collectionCostMs"

    invoke-virtual {v2, v0, v8, v9}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 77
    return-object v2
.end method

.method private static final executor$lambda$1(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 4
    .param p0, "task"    # Ljava/lang/Runnable;

    .line 18
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "worker-performance"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    move-object v1, v0

    .line 83
    .local v1, "$this$executor_u24lambda_u241_u24lambda_u240\\1":Ljava/lang/Thread;
    const/4 v2, 0x0

    .line 18
    .local v2, "$i$a$-apply-WorkerPerformanceSampler$executor$1$1\\1\\18\\0":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/Thread;->setDaemon(Z)V

    .end local v1    # "$this$executor_u24lambda_u241_u24lambda_u240\\1":Ljava/lang/Thread;
    .end local v2    # "$i$a$-apply-WorkerPerformanceSampler$executor$1$1\\1\\18\\0":I
    return-object v0
.end method

.method private static final request$lambda$3$lambda$2(Lorg/lighttouch/android/WorkerPerformanceSampler;Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/WorkerPerformanceSampler;
    .param p1, "$ticket"    # Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;

    .line 28
    invoke-direct {p0, p1}, Lorg/lighttouch/android/WorkerPerformanceSampler;->collect(Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)Landroid/os/Bundle;

    move-result-object v0

    .line 31
    .local v0, "result":Landroid/os/Bundle;
    iget-object v1, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->gate:Lorg/lighttouch/android/PerformanceSamplingGate;

    invoke-virtual {v1, p1}, Lorg/lighttouch/android/PerformanceSamplingGate;->complete(Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v1, Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;

    invoke-virtual {p1}, Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;->getEpoch()J

    move-result-wide v2

    invoke-direct {v1, v2, v3, v0}, Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;-><init>(JLandroid/os/Bundle;)V

    iput-object v1, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->cached:Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;

    .line 32
    :cond_0
    return-void
.end method


# virtual methods
.method public final close()V
    .locals 1

    .line 80
    iget-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->gate:Lorg/lighttouch/android/PerformanceSamplingGate;

    invoke-virtual {v0}, Lorg/lighttouch/android/PerformanceSamplingGate;->close()V

    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->cached:Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;

    iget-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->executor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    return-void
.end method

.method public final request(IJ)Landroid/os/Bundle;
    .locals 9
    .param p1, "callerPid"    # I
    .param p2, "observationEpoch"    # J

    .line 24
    iget-object v0, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->gate:Lorg/lighttouch/android/PerformanceSamplingGate;

    new-instance v1, Lorg/lighttouch/android/PerformanceSamplingGate$Observer;

    invoke-direct {v1, p1, p2, p3}, Lorg/lighttouch/android/PerformanceSamplingGate$Observer;-><init>(IJ)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lorg/lighttouch/android/PerformanceSamplingGate;->request(Lorg/lighttouch/android/PerformanceSamplingGate$Observer;J)Lorg/lighttouch/android/PerformanceSamplingGate$Demand;

    move-result-object v0

    .line 25
    .local v0, "demand":Lorg/lighttouch/android/PerformanceSamplingGate$Demand;
    invoke-virtual {v0}, Lorg/lighttouch/android/PerformanceSamplingGate$Demand;->getTicket()Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;

    move-result-object v1

    if-eqz v1, :cond_0

    .local v1, "ticket\\1":Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;
    const/4 v2, 0x0

    .line 26
    .local v2, "$i$a$-let-WorkerPerformanceSampler$request$1\\1\\25\\0":I
    nop

    .line 27
    :try_start_0
    iget-object v3, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->executor:Ljava/util/concurrent/ExecutorService;

    new-instance v4, Lorg/lighttouch/android/WorkerPerformanceSampler$$ExternalSyntheticLambda0;

    invoke-direct {v4, p0, v1}, Lorg/lighttouch/android/WorkerPerformanceSampler$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/WorkerPerformanceSampler;Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)V

    invoke-interface {v3, v4}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 33
    :catch_0
    move-exception v3

    .local v3, "<unused var>\\1":Ljava/util/concurrent/RejectedExecutionException;
    iget-object v4, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->gate:Lorg/lighttouch/android/PerformanceSamplingGate;

    invoke-virtual {v4, v1}, Lorg/lighttouch/android/PerformanceSamplingGate;->complete(Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;)Z

    move-result v4

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 25
    .end local v1    # "ticket\\1":Lorg/lighttouch/android/PerformanceSamplingGate$Ticket;
    .end local v2    # "$i$a$-let-WorkerPerformanceSampler$request$1\\1\\25\\0":I
    .end local v3    # "<unused var>\\1":Ljava/util/concurrent/RejectedExecutionException;
    :cond_0
    :goto_0
    nop

    .line 35
    iget-object v1, p0, Lorg/lighttouch/android/WorkerPerformanceSampler;->cached:Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;

    const/4 v2, 0x0

    if-eqz v1, :cond_3

    move-object v3, v1

    .line 83
    .local v3, "it\\2":Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;
    const/4 v4, 0x0

    .line 35
    .local v4, "$i$a$-takeIf-WorkerPerformanceSampler$request$sample$1\\2\\35\\0":I
    invoke-virtual {v3}, Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;->getEpoch()J

    move-result-wide v5

    invoke-virtual {v0}, Lorg/lighttouch/android/PerformanceSamplingGate$Demand;->getEpoch()J

    move-result-wide v7

    cmp-long v5, v5, v7

    if-nez v5, :cond_1

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    .end local v3    # "it\\2":Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;
    .end local v4    # "$i$a$-takeIf-WorkerPerformanceSampler$request$sample$1\\2\\35\\0":I
    :goto_1
    if-eqz v5, :cond_2

    goto :goto_2

    :cond_2
    move-object v1, v2

    :goto_2
    if-eqz v1, :cond_3

    invoke-virtual {v1}, Lorg/lighttouch/android/WorkerPerformanceSampler$Cached;->getValues()Landroid/os/Bundle;

    move-result-object v2

    .line 36
    .local v2, "sample":Landroid/os/Bundle;
    :cond_3
    if-eqz v2, :cond_4

    move-object v1, v2

    .line 83
    .local v1, "it\\3":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 36
    .local v3, "$i$a$-let-WorkerPerformanceSampler$request$2\\3\\36\\0":I
    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4, v1}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .end local v1    # "it\\3":Landroid/os/Bundle;
    .end local v3    # "$i$a$-let-WorkerPerformanceSampler$request$2\\3\\36\\0":I
    goto :goto_3

    :cond_4
    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    move-object v1, v4

    .local v1, "$this$request_u24lambda_u246\\4":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 37
    .local v3, "$i$a$-apply-WorkerPerformanceSampler$request$3\\4\\36\\0":I
    const-string v5, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v6

    invoke-virtual {v1, v5, v6}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v5, "cpuState"

    const-string v6, "\u9884\u70ed\u4e2d"

    invoke-virtual {v1, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 38
    nop

    .line 36
    .end local v1    # "$this$request_u24lambda_u246\\4":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-WorkerPerformanceSampler$request$3\\4\\36\\0":I
    nop

    .line 38
    :goto_3
    move-object v1, v4

    .local v1, "$this$request_u24lambda_u247\\5":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 39
    .local v3, "$i$a$-apply-WorkerPerformanceSampler$request$4\\5\\38\\0":I
    const-string v5, "samplingEpoch"

    invoke-virtual {v0}, Lorg/lighttouch/android/PerformanceSamplingGate$Demand;->getEpoch()J

    move-result-wide v6

    invoke-virtual {v1, v5, v6, v7}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 40
    const-string v5, "deviceCpuState"

    const-string v6, "unavailable"

    invoke-virtual {v1, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    const-string v5, "guestCpuState"

    invoke-virtual {v1, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    const-string v5, "guestMemoryState"

    invoke-virtual {v1, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 43
    nop

    .line 38
    .end local v1    # "$this$request_u24lambda_u247\\5":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-WorkerPerformanceSampler$request$4\\5\\38\\0":I
    nop

    .line 36
    return-object v4
.end method

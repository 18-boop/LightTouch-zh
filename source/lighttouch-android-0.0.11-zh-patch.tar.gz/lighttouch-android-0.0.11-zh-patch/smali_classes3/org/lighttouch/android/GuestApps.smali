.class public final Lorg/lighttouch/android/GuestApps;
.super Ljava/lang/Object;
.source "GuestApps.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/GuestApps$Failure;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nGuestApps.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GuestApps.kt\norg/lighttouch/android/GuestApps\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 ReadWrite.kt\nkotlin/io/TextStreamsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,89:1\n1#2:90\n1#2:92\n1#2:103\n57#3:91\n1617#4,9:93\n1869#4:102\n1870#4:104\n1626#4:105\n774#4:106\n865#4,2:107\n1563#4:109\n1634#4,3:110\n1056#4:113\n*S KotlinDebug\n*F\n+ 1 GuestApps.kt\norg/lighttouch/android/GuestApps\n*L\n43#1:92\n70#1:103\n43#1:91\n70#1:93,9\n70#1:102\n70#1:104\n70#1:105\n70#1:106\n70#1:107,2\n71#1:109\n71#1:110,3\n72#1:113\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008\u0001\u0018\u00002\u00020\u0001:\u0001$B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005JJ\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u000c\u0010\u0012\u001a\u0008\u0012\u0004\u0012\u00020\u00110\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u000e\u0008\u0002\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00172\u0014\u0008\u0002\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u001a0\u0019J\u000e\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0010\u001a\u00020\u0011J\u0014\u0010\u001d\u001a\u0008\u0012\u0004\u0012\u00020\u001e0\u00132\u0006\u0010\u0010\u001a\u00020\u0011J\u001c\u0010\u001f\u001a\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u0011\u0018\u00010 2\u0006\u0010\u0010\u001a\u00020\u0011J@\u0010!\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\"\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u00112\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00172\u0012\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u001a0\u0019R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0008\u0010\tR\u0011\u0010\n\u001a\u00020\u000b8F\u00a2\u0006\u0006\u001a\u0004\u0008\u000c\u0010\r\u00a8\u0006%"
    }
    d2 = {
        "Lorg/lighttouch/android/GuestApps;",
        "",
        "context",
        "Landroid/content/Context;",
        "<init>",
        "(Landroid/content/Context;)V",
        "helper",
        "Ljava/io/File;",
        "getHelper",
        "()Ljava/io/File;",
        "available",
        "",
        "getAvailable",
        "()Z",
        "run",
        "Lorg/json/JSONObject;",
        "socket",
        "",
        "args",
        "",
        "timeoutSeconds",
        "",
        "cancelled",
        "Lkotlin/Function0;",
        "event",
        "Lkotlin/Function1;",
        "",
        "target",
        "Lorg/lighttouch/android/StoreTarget;",
        "installedApps",
        "Lorg/lighttouch/android/InstalledApp;",
        "lastCrash",
        "Lkotlin/Pair;",
        "install",
        "ipa",
        "bundleId",
        "Failure",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final context:Landroid/content/Context;


# direct methods
.method public static synthetic $r8$lambda$GTA4fnVIrflhiuw-fVPokuT7Xxo(Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/GuestApps;->run$lambda$1(Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_aC27IoV5v-ZnWHKEUbsIrtAUss()Z
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/GuestApps;->run$lambda$0()Z

    move-result v0

    return v0
.end method

.method public static synthetic $r8$lambda$h5UwuodVSVuFMOkYWUTbzaC5LaY(JLjava/lang/Process;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/GuestApps;->run$lambda$2(JLjava/lang/Process;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zUdpXEK7lNvLjvLj732WSclwlnk(Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/GuestApps;->target$lambda$8(Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/GuestApps;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/GuestApps;->context:Landroid/content/Context;

    return-void
.end method

.method private final getHelper()Ljava/io/File;
    .locals 3

    .line 23
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lorg/lighttouch/android/GuestApps;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    iget-object v1, v1, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;

    const-string v2, "liblt_appservice.so"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public static synthetic run$default(Lorg/lighttouch/android/GuestApps;Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Lorg/json/JSONObject;
    .locals 7

    .line 27
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_0

    new-instance p5, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda1;

    invoke-direct {p5}, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda1;-><init>()V

    :cond_0
    move-object v5, p5

    and-int/lit8 p5, p7, 0x10

    if-eqz p5, :cond_1

    new-instance p6, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda2;

    invoke-direct {p6}, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda2;-><init>()V

    :cond_1
    move-object v6, p6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-wide v3, p3

    invoke-virtual/range {v0 .. v6}, Lorg/lighttouch/android/GuestApps;->run(Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private static final run$lambda$0()Z
    .locals 1

    .line 27
    const/4 v0, 0x0

    return v0
.end method

.method private static final run$lambda$1(Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 1
    .param p0, "it"    # Lorg/json/JSONObject;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final run$lambda$2(JLjava/lang/Process;Lkotlin/jvm/functions/Function0;)V
    .locals 5
    .param p0, "$timeoutSeconds"    # J
    .param p2, "$process"    # Ljava/lang/Process;
    .param p3, "$cancelled"    # Lkotlin/jvm/functions/Function0;

    .line 33
    nop

    .line 35
    :try_start_0
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v2, p0, p1}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v2

    add-long/2addr v0, v2

    .line 36
    .local v0, "deadline":J
    :cond_0
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0xfa

    invoke-virtual {p2, v3, v4, v2}, Ljava/lang/Process;->waitFor(JLjava/util/concurrent/TimeUnit;)Z

    move-result v2

    if-nez v2, :cond_2

    .line 37
    invoke-interface {p3}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    cmp-long v2, v2, v0

    if-lez v2, :cond_0

    :cond_1
    invoke-virtual {p2}, Ljava/lang/Process;->destroyForcibly()Ljava/lang/Process;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 39
    .end local v0    # "deadline":J
    :catch_0
    move-exception v0

    .line 40
    :cond_2
    :goto_0
    return-void
.end method

.method private static final target$lambda$8(Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 6
    .param p0, "$target"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p1, "e"    # Lorg/json/JSONObject;

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    const-string v0, "target"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 90
    .local v0, "it\\1":Lorg/json/JSONObject;
    const/4 v1, 0x0

    .line 63
    .local v1, "$i$a$-let-GuestApps$target$1$1\\1\\63\\0":I
    sget-object v2, Lorg/lighttouch/android/StoreTarget;->Companion:Lorg/lighttouch/android/StoreTarget$Companion;

    const-string v3, "product_type"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "getString(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "ios"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3, v5}, Lorg/lighttouch/android/StoreTarget$Companion;->of(Ljava/lang/String;Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;

    move-result-object v2

    iput-object v2, p0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .end local v0    # "it\\1":Lorg/json/JSONObject;
    .end local v1    # "$i$a$-let-GuestApps$target$1$1\\1\\63\\0":I
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public final getAvailable()Z
    .locals 1

    .line 24
    invoke-direct {p0}, Lorg/lighttouch/android/GuestApps;->getHelper()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->canExecute()Z

    move-result v0

    return v0
.end method

.method public final install(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lorg/json/JSONObject;
    .locals 9
    .param p1, "socket"    # Ljava/lang/String;
    .param p2, "ipa"    # Ljava/io/File;
    .param p3, "bundleId"    # Ljava/lang/String;
    .param p4, "cancelled"    # Lkotlin/jvm/functions/Function0;
    .param p5, "event"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/io/File;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/json/JSONObject;",
            "Lkotlin/Unit;",
            ">;)",
            "Lorg/json/JSONObject;"
        }
    .end annotation

    const-string v0, "socket"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ipa"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bundleId"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cancelled"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "event"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    const/4 v0, 0x5

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "install"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "--ipa"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    invoke-virtual {p2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "--bundle-id"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    aput-object p3, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-wide/16 v5, 0x384

    move-object v2, p0

    move-object v3, p1

    move-object v7, p4

    move-object v8, p5

    .end local p1    # "socket":Ljava/lang/String;
    .end local p4    # "cancelled":Lkotlin/jvm/functions/Function0;
    .end local p5    # "event":Lkotlin/jvm/functions/Function1;
    .local v3, "socket":Ljava/lang/String;
    .local v7, "cancelled":Lkotlin/jvm/functions/Function0;
    .local v8, "event":Lkotlin/jvm/functions/Function1;
    invoke-virtual/range {v2 .. v8}, Lorg/lighttouch/android/GuestApps;->run(Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lorg/json/JSONObject;

    move-result-object p1

    return-object p1
.end method

.method public final installedApps(Ljava/lang/String;)Ljava/util/List;
    .locals 17
    .param p1, "socket"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;"
        }
    .end annotation

    const-string v0, "socket"

    move-object/from16 v2, p1

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 69
    const-string v0, "list"

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    const/16 v8, 0x18

    const/4 v9, 0x0

    const-wide/16 v4, 0x5a

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object/from16 v1, p0

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/GuestApps;->run$default(Lorg/lighttouch/android/GuestApps;Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "apps"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 70
    .local v0, "apps":Lorg/json/JSONArray;
    :cond_0
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2, v1}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 93
    .local v3, "$i$f$mapNotNull\\1\\70":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 101
    .local v6, "$i$f$mapNotNullTo\\2\\93":I
    move-object v7, v5

    .local v7, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 102
    .local v8, "$i$f$forEach\\3\\101":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2

    move-object v10, v9

    check-cast v10, Lkotlin/collections/IntIterator;

    invoke-virtual {v10}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v10

    .local v10, "element\\3":I
    move v11, v10

    .local v11, "element\\4":I
    const/4 v12, 0x0

    .line 101
    .local v12, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\102\\2":I
    move v13, v11

    .local v13, "it\\6":I
    const/4 v14, 0x0

    .line 70
    .local v14, "$i$a$-mapNotNull-GuestApps$installedApps$1\\6\\101\\0":I
    invoke-virtual {v0, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    .line 101
    .end local v13    # "it\\6":I
    .end local v14    # "$i$a$-mapNotNull-GuestApps$installedApps$1\\6\\101\\0":I
    if-eqz v13, :cond_1

    .line 103
    .local v13, "it\\4":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 101
    .local v14, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\103\\4":I
    invoke-interface {v4, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 102
    .end local v11    # "element\\4":I
    .end local v12    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\102\\2":I
    .end local v13    # "it\\4":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\103\\4":I
    :cond_1
    nop

    .end local v10    # "element\\3":I
    goto :goto_0

    .line 104
    :cond_2
    nop

    .line 105
    .end local v7    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\3\\101":I
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapNotNullTo\\2\\93":I
    check-cast v4, Ljava/util/List;

    .line 93
    nop

    .end local v1    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\1\\70":I
    check-cast v4, Ljava/lang/Iterable;

    .line 70
    nop

    .local v4, "$this$filter\\7":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 106
    .local v1, "$i$f$filter\\7\\70":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\8":Ljava/util/Collection;
    move-object v5, v4

    .local v5, "$this$filterTo\\8":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 107
    .local v6, "$i$f$filterTo\\8\\106":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_3
    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const-string v9, "optString(...)"

    const-string v10, "bundle_id"

    if-eqz v8, :cond_5

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\8":Ljava/lang/Object;
    move-object v11, v8

    check-cast v11, Lorg/json/JSONObject;

    .local v11, "it\\9":Lorg/json/JSONObject;
    const/4 v12, 0x0

    .line 70
    .local v12, "$i$a$-filter-GuestApps$installedApps$2\\9\\107\\0":I
    invoke-virtual {v11, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v10, Ljava/lang/CharSequence;

    invoke-interface {v10}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-lez v9, :cond_4

    const/4 v9, 0x1

    goto :goto_2

    :cond_4
    move v9, v2

    .line 107
    .end local v11    # "it\\9":Lorg/json/JSONObject;
    .end local v12    # "$i$a$-filter-GuestApps$installedApps$2\\9\\107\\0":I
    :goto_2
    if-eqz v9, :cond_3

    invoke-interface {v3, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 108
    .end local v8    # "element\\8":Ljava/lang/Object;
    :cond_5
    nop

    .end local v3    # "destination\\8":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\8":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo\\8\\106":I
    move-object v2, v3

    check-cast v2, Ljava/util/List;

    .line 106
    nop

    .end local v1    # "$i$f$filter\\7\\70":I
    .end local v4    # "$this$filter\\7":Ljava/lang/Iterable;
    check-cast v2, Ljava/lang/Iterable;

    .line 71
    nop

    .local v2, "$this$map\\10":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 109
    .local v1, "$i$f$map\\10\\71":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v2, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\11":Ljava/util/Collection;
    move-object v4, v2

    .local v4, "$this$mapTo\\11":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 110
    .local v5, "$i$f$mapTo\\11\\109":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_3
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_6

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 111
    .local v7, "item\\11":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lorg/json/JSONObject;

    .local v8, "it\\12":Lorg/json/JSONObject;
    const/4 v11, 0x0

    .line 71
    .local v11, "$i$a$-map-GuestApps$installedApps$3\\12\\111\\0":I
    new-instance v12, Lorg/lighttouch/android/InstalledApp;

    invoke-virtual {v8, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "name"

    invoke-static {v8, v14}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "version"

    invoke-static {v8, v15}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v16, v0

    .end local v0    # "apps":Lorg/json/JSONArray;
    .local v16, "apps":Lorg/json/JSONArray;
    const-string v0, "short_version"

    invoke-static {v8, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v12, v13, v14, v15, v0}, Lorg/lighttouch/android/InstalledApp;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    .end local v8    # "it\\12":Lorg/json/JSONObject;
    .end local v11    # "$i$a$-map-GuestApps$installedApps$3\\12\\111\\0":I
    invoke-interface {v3, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, v16

    goto :goto_3

    .line 112
    .end local v7    # "item\\11":Ljava/lang/Object;
    .end local v16    # "apps":Lorg/json/JSONArray;
    .restart local v0    # "apps":Lorg/json/JSONArray;
    :cond_6
    move-object/from16 v16, v0

    .end local v0    # "apps":Lorg/json/JSONArray;
    .end local v3    # "destination\\11":Ljava/util/Collection;
    .end local v4    # "$this$mapTo\\11":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo\\11\\109":I
    .restart local v16    # "apps":Lorg/json/JSONArray;
    move-object v0, v3

    check-cast v0, Ljava/util/List;

    .line 109
    nop

    .end local v1    # "$i$f$map\\10\\71":I
    .end local v2    # "$this$map\\10":Ljava/lang/Iterable;
    check-cast v0, Ljava/lang/Iterable;

    .line 72
    nop

    .local v0, "$this$sortedBy\\13":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 113
    .local v1, "$i$f$sortedBy\\13\\72":I
    new-instance v2, Lorg/lighttouch/android/GuestApps$installedApps$$inlined$sortedBy$1;

    invoke-direct {v2}, Lorg/lighttouch/android/GuestApps$installedApps$$inlined$sortedBy$1;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .line 70
    .end local v0    # "$this$sortedBy\\13":Ljava/lang/Iterable;
    .end local v1    # "$i$f$sortedBy\\13\\72":I
    return-object v0
.end method

.method public final lastCrash(Ljava/lang/String;)Lkotlin/Pair;
    .locals 16
    .param p1, "socket"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v0, "socket"

    move-object/from16 v2, p1

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    const-string v0, "crashlog"

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    const/16 v8, 0x18

    const/4 v9, 0x0

    const-wide/16 v4, 0x3c

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object/from16 v1, p0

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/GuestApps;->run$default(Lorg/lighttouch/android/GuestApps;Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 78
    .local v0, "result":Lorg/json/JSONObject;
    const-string v1, "name"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    return-object v3

    :cond_0
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 79
    .local v1, "name":Ljava/lang/String;
    const-string v2, "text"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 81
    .local v2, "text":Ljava/lang/String;
    nop

    .line 82
    nop

    .line 81
    new-instance v4, Lkotlin/text/Regex;

    const-string v5, "<key>description</key>\\s*<string>(.*?)</string>"

    sget-object v6, Lkotlin/text/RegexOption;->DOT_MATCHES_ALL:Lkotlin/text/RegexOption;

    invoke-direct {v4, v5, v6}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;Lkotlin/text/RegexOption;)V

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v5, v2

    check-cast v5, Ljava/lang/CharSequence;

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v4, v5, v6, v7, v3}, Lkotlin/text/Regex;->find$default(Lkotlin/text/Regex;Ljava/lang/CharSequence;IILjava/lang/Object;)Lkotlin/text/MatchResult;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-interface {v3}, Lkotlin/text/MatchResult;->getGroupValues()Ljava/util/List;

    move-result-object v3

    if-eqz v3, :cond_1

    const/4 v4, 0x1

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    move-object v4, v3

    check-cast v4, Ljava/lang/String;

    .line 82
    if-eqz v4, :cond_1

    .line 81
    nop

    .line 82
    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string v5, "&lt;"

    const-string v6, "<"

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_1

    .line 81
    nop

    .line 82
    const/4 v14, 0x4

    const/4 v15, 0x0

    const-string v11, "&gt;"

    const-string v12, ">"

    const/4 v13, 0x0

    invoke-static/range {v10 .. v15}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1

    .line 81
    nop

    .line 82
    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v4, "&amp;"

    const-string v5, "&"

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 81
    if-eqz v3, :cond_1

    goto :goto_0

    .line 82
    :cond_1
    move-object v3, v2

    .line 81
    :goto_0
    nop

    .line 83
    .local v3, "body":Ljava/lang/String;
    invoke-static {v1, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    return-object v4
.end method

.method public final run(Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lorg/json/JSONObject;
    .locals 23
    .param p1, "socket"    # Ljava/lang/String;
    .param p2, "args"    # Ljava/util/List;
    .param p3, "timeoutSeconds"    # J
    .param p5, "cancelled"    # Lkotlin/jvm/functions/Function0;
    .param p6, "event"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;J",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/json/JSONObject;",
            "Lkotlin/Unit;",
            ">;)",
            "Lorg/json/JSONObject;"
        }
    .end annotation

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p5

    move-object/from16 v4, p6

    const-string v5, "error"

    const-string v0, "socket"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "args"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cancelled"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "event"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/GuestApps;->getAvailable()Z

    move-result v0

    if-eqz v0, :cond_9

    .line 29
    new-instance v0, Ljava/lang/ProcessBuilder;

    invoke-direct/range {p0 .. p0}, Lorg/lighttouch/android/GuestApps;->getHelper()Ljava/io/File;

    move-result-object v6

    invoke-virtual {v6}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/util/Collection;

    move-object v7, v2

    check-cast v7, Ljava/lang/Iterable;

    const/4 v8, 0x1

    invoke-static {v7, v8}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/lang/Iterable;

    invoke-static {v6, v7}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/util/Collection;

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/String;

    const/4 v9, 0x0

    const-string v10, "--socket"

    aput-object v10, v7, v9

    aput-object v1, v7, v8

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/lang/Iterable;

    invoke-static {v6, v7}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/util/Collection;

    move-object v7, v2

    check-cast v7, Ljava/lang/Iterable;

    invoke-static {v7, v8}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/lang/Iterable;

    invoke-static {v6, v7}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v6

    invoke-direct {v0, v6}, Ljava/lang/ProcessBuilder;-><init>(Ljava/util/List;)V

    .line 30
    invoke-virtual {v0, v8}, Ljava/lang/ProcessBuilder;->redirectErrorStream(Z)Ljava/lang/ProcessBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/ProcessBuilder;->start()Ljava/lang/Process;

    move-result-object v0

    .line 29
    move-object v6, v0

    .line 31
    .local v6, "process":Ljava/lang/Process;
    invoke-virtual {v6}, Ljava/lang/Process;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    .line 32
    new-instance v0, Ljava/lang/Thread;

    .line 40
    new-instance v7, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda3;

    move-wide/from16 v9, p3

    invoke-direct {v7, v9, v10, v6, v3}, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda3;-><init>(JLjava/lang/Process;Lkotlin/jvm/functions/Function0;)V

    .line 32
    const-string v11, "guest-apps-watchdog"

    invoke-direct {v0, v7, v11}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 40
    move-object v7, v0

    .line 90
    .local v7, "$this$run_u24lambda_u243\\1":Ljava/lang/Thread;
    const/4 v11, 0x0

    .line 40
    .local v11, "$i$a$-apply-GuestApps$run$watchdog$2\\1\\40\\0":I
    invoke-virtual {v7, v8}, Ljava/lang/Thread;->setDaemon(Z)V

    invoke-virtual {v7}, Ljava/lang/Thread;->start()V

    .line 32
    .end local v7    # "$this$run_u24lambda_u243\\1":Ljava/lang/Thread;
    .end local v11    # "$i$a$-apply-GuestApps$run$watchdog$2\\1\\40\\0":I
    nop

    .line 41
    .local v7, "watchdog":Ljava/lang/Thread;
    const/4 v8, 0x0

    .local v8, "result":Ljava/lang/Object;
    const/4 v11, 0x0

    .local v11, "error":Ljava/lang/Object;
    const/4 v0, 0x0

    .local v0, "lastLine":Ljava/lang/Object;
    const-string v12, ""

    .line 42
    .end local v0    # "lastLine":Ljava/lang/Object;
    .local v12, "lastLine":Ljava/lang/Object;
    nop

    .line 43
    :try_start_0
    invoke-virtual {v6}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    const-string v13, "getInputStream(...)"

    invoke-static {v0, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v13, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v14, Ljava/io/InputStreamReader;

    invoke-direct {v14, v0, v13}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v14, Ljava/io/Reader;

    instance-of v0, v14, Ljava/io/BufferedReader;

    const/16 v13, 0x2000

    if-eqz v0, :cond_0

    check-cast v14, Ljava/io/BufferedReader;

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/io/BufferedReader;

    invoke-direct {v0, v14, v13}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v14, v0

    :goto_0
    check-cast v14, Ljava/io/Reader;

    .local v14, "$this$useLines\\2":Ljava/io/Reader;
    const/4 v15, 0x0

    .line 91
    .local v15, "$i$f$useLines\\2\\43":I
    instance-of v0, v14, Ljava/io/BufferedReader;

    if-eqz v0, :cond_1

    move-object v0, v14

    check-cast v0, Ljava/io/BufferedReader;

    goto :goto_1

    :cond_1
    new-instance v0, Ljava/io/BufferedReader;

    invoke-direct {v0, v14, v13}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    :goto_1
    move-object v13, v0

    check-cast v13, Ljava/io/Closeable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    move-object v0, v13

    check-cast v0, Ljava/io/BufferedReader;

    move-object/from16 v16, v0

    .line 92
    .local v16, "it\\2":Ljava/io/BufferedReader;
    const/16 v17, 0x0

    .line 91
    .local v17, "$i$a$-use-TextStreamsKt$useLines$1\\3\\92\\2":I
    invoke-static/range {v16 .. v16}, Lkotlin/io/TextStreamsKt;->lineSequence(Ljava/io/BufferedReader;)Lkotlin/sequences/Sequence;

    move-result-object v0

    move-object/from16 v18, v0

    .local v18, "lines\\4":Lkotlin/sequences/Sequence;
    const/16 v19, 0x0

    .line 44
    .local v19, "$i$a$-useLines-GuestApps$run$3\\4\\91\\0":I
    invoke-interface/range {v18 .. v18}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_2
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    move-object/from16 v21, v0

    .line 45
    .local v21, "line\\4":Ljava/lang/String;
    move-object/from16 v0, v21

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4

    .line 46
    const/16 v0, 0x12c

    move-object/from16 v1, v21

    .end local v21    # "line\\4":Ljava/lang/String;
    .local v1, "line\\4":Ljava/lang/String;
    invoke-static {v1, v0}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v12, v0

    .line 47
    :try_start_2
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 48
    .local v0, "value\\4":Lorg/json/JSONObject;
    move-object/from16 v21, v1

    .end local v1    # "line\\4":Ljava/lang/String;
    .restart local v21    # "line\\4":Ljava/lang/String;
    :try_start_3
    const-string v1, "result"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v1, :cond_2

    .line 90
    .local v1, "it\\5":Lorg/json/JSONObject;
    const/16 v22, 0x0

    .line 48
    .local v22, "$i$a$-let-GuestApps$run$3$1\\5\\48\\4":I
    move-object v8, v1

    .line 49
    .end local v1    # "it\\5":Lorg/json/JSONObject;
    .end local v22    # "$i$a$-let-GuestApps$run$3$1\\5\\48\\4":I
    :cond_2
    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object v11, v1

    .line 50
    :cond_3
    invoke-interface {v4, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, p1

    goto :goto_2

    .line 47
    .end local v0    # "value\\4":Lorg/json/JSONObject;
    .end local v21    # "line\\4":Ljava/lang/String;
    .local v1, "line\\4":Ljava/lang/String;
    :catch_0
    move-exception v0

    move-object/from16 v21, v1

    .end local v1    # "line\\4":Ljava/lang/String;
    .restart local v21    # "line\\4":Ljava/lang/String;
    move-object/from16 v1, p1

    .local v0, "<unused var>\\4":Lorg/json/JSONException;
    goto :goto_2

    .line 45
    .end local v0    # "<unused var>\\4":Lorg/json/JSONException;
    :cond_4
    move-object/from16 v1, p1

    goto :goto_2

    .line 52
    .end local v21    # "line\\4":Ljava/lang/String;
    :cond_5
    nop

    .end local v18    # "lines\\4":Lkotlin/sequences/Sequence;
    .end local v19    # "$i$a$-useLines-GuestApps$run$3\\4\\91\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 91
    .end local v16    # "it\\2":Ljava/io/BufferedReader;
    .end local v17    # "$i$a$-use-TextStreamsKt$useLines$1\\3\\92\\2":I
    const/4 v0, 0x0

    :try_start_4
    invoke-static {v13, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 53
    .end local v14    # "$this$useLines\\2":Ljava/io/Reader;
    .end local v15    # "$i$f$useLines\\2\\43":I
    invoke-virtual {v6}, Ljava/lang/Process;->waitFor()I

    move-result v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 54
    .local v0, "code":I
    if-nez v11, :cond_8

    .line 55
    if-nez v0, :cond_7

    if-nez v8, :cond_6

    goto :goto_3

    .line 57
    :cond_6
    nop

    .line 58
    .end local v0    # "code":I
    invoke-virtual {v7}, Ljava/lang/Thread;->interrupt()V

    invoke-virtual {v6}, Ljava/lang/Process;->destroy()V

    .line 57
    .restart local v0    # "code":I
    return-object v8

    .line 55
    :cond_7
    :goto_3
    :try_start_5
    new-instance v1, Lorg/lighttouch/android/GuestApps$Failure;

    sparse-switch v0, :sswitch_data_0

    .line 56
    new-instance v5, Ljava/lang/StringBuilder;

    goto :goto_4

    .line 55
    :sswitch_0
    const-string v5, "\u5ba2\u6237\u673a\u672a\u53ca\u65f6\u54cd\u5e94\uff0c\u7ed3\u679c\u65e0\u6cd5\u786e\u8ba4\u3002"

    goto :goto_5

    .line 56
    :goto_4
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Guest app service exited ("

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v13, ") without a result. "

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 55
    :goto_5
    invoke-direct {v1, v5}, Lorg/lighttouch/android/GuestApps$Failure;-><init>(Ljava/lang/String;)V

    .end local v6    # "process":Ljava/lang/Process;
    .end local v7    # "watchdog":Ljava/lang/Thread;
    .end local v8    # "result":Ljava/lang/Object;
    .end local v11    # "error":Ljava/lang/Object;
    .end local v12    # "lastLine":Ljava/lang/Object;
    .end local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .end local p1    # "socket":Ljava/lang/String;
    .end local p2    # "args":Ljava/util/List;
    .end local p3    # "timeoutSeconds":J
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .end local p6    # "event":Lkotlin/jvm/functions/Function1;
    throw v1

    .line 54
    .restart local v6    # "process":Ljava/lang/Process;
    .restart local v7    # "watchdog":Ljava/lang/Thread;
    .restart local v8    # "result":Ljava/lang/Object;
    .restart local v11    # "error":Ljava/lang/Object;
    .restart local v12    # "lastLine":Ljava/lang/Object;
    .restart local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .restart local p1    # "socket":Ljava/lang/String;
    .restart local p2    # "args":Ljava/util/List;
    .restart local p3    # "timeoutSeconds":J
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .restart local p6    # "event":Lkotlin/jvm/functions/Function1;
    :cond_8
    move-object v1, v11

    .line 90
    .local v1, "it\\6":Ljava/lang/String;
    const/4 v5, 0x0

    .line 54
    .local v5, "$i$a$-let-GuestApps$run$4\\6\\54\\0":I
    new-instance v13, Lorg/lighttouch/android/GuestApps$Failure;

    invoke-direct {v13, v1}, Lorg/lighttouch/android/GuestApps$Failure;-><init>(Ljava/lang/String;)V

    .end local v6    # "process":Ljava/lang/Process;
    .end local v7    # "watchdog":Ljava/lang/Thread;
    .end local v8    # "result":Ljava/lang/Object;
    .end local v11    # "error":Ljava/lang/Object;
    .end local v12    # "lastLine":Ljava/lang/Object;
    .end local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .end local p1    # "socket":Ljava/lang/String;
    .end local p2    # "args":Ljava/util/List;
    .end local p3    # "timeoutSeconds":J
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .end local p6    # "event":Lkotlin/jvm/functions/Function1;
    throw v13
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 91
    .end local v0    # "code":I
    .end local v1    # "it\\6":Ljava/lang/String;
    .end local v5    # "$i$a$-let-GuestApps$run$4\\6\\54\\0":I
    .restart local v6    # "process":Ljava/lang/Process;
    .restart local v7    # "watchdog":Ljava/lang/Thread;
    .restart local v8    # "result":Ljava/lang/Object;
    .restart local v11    # "error":Ljava/lang/Object;
    .restart local v12    # "lastLine":Ljava/lang/Object;
    .restart local v14    # "$this$useLines\\2":Ljava/io/Reader;
    .restart local v15    # "$i$f$useLines\\2\\43":I
    .restart local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .restart local p1    # "socket":Ljava/lang/String;
    .restart local p2    # "args":Ljava/util/List;
    .restart local p3    # "timeoutSeconds":J
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .restart local p6    # "event":Lkotlin/jvm/functions/Function1;
    :catchall_0
    move-exception v0

    move-object v1, v0

    .end local v6    # "process":Ljava/lang/Process;
    .end local v7    # "watchdog":Ljava/lang/Thread;
    .end local v8    # "result":Ljava/lang/Object;
    .end local v11    # "error":Ljava/lang/Object;
    .end local v12    # "lastLine":Ljava/lang/Object;
    .end local v14    # "$this$useLines\\2":Ljava/io/Reader;
    .end local v15    # "$i$f$useLines\\2\\43":I
    .end local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .end local p1    # "socket":Ljava/lang/String;
    .end local p2    # "args":Ljava/util/List;
    .end local p3    # "timeoutSeconds":J
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .end local p6    # "event":Lkotlin/jvm/functions/Function1;
    :try_start_6
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .restart local v6    # "process":Ljava/lang/Process;
    .restart local v7    # "watchdog":Ljava/lang/Thread;
    .restart local v8    # "result":Ljava/lang/Object;
    .restart local v11    # "error":Ljava/lang/Object;
    .restart local v12    # "lastLine":Ljava/lang/Object;
    .restart local v14    # "$this$useLines\\2":Ljava/io/Reader;
    .restart local v15    # "$i$f$useLines\\2\\43":I
    .restart local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .restart local p1    # "socket":Ljava/lang/String;
    .restart local p2    # "args":Ljava/util/List;
    .restart local p3    # "timeoutSeconds":J
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .restart local p6    # "event":Lkotlin/jvm/functions/Function1;
    :catchall_1
    move-exception v0

    :try_start_7
    invoke-static {v13, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v6    # "process":Ljava/lang/Process;
    .end local v7    # "watchdog":Ljava/lang/Thread;
    .end local v8    # "result":Ljava/lang/Object;
    .end local v11    # "error":Ljava/lang/Object;
    .end local v12    # "lastLine":Ljava/lang/Object;
    .end local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .end local p1    # "socket":Ljava/lang/String;
    .end local p2    # "args":Ljava/util/List;
    .end local p3    # "timeoutSeconds":J
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .end local p6    # "event":Lkotlin/jvm/functions/Function1;
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 57
    .end local v14    # "$this$useLines\\2":Ljava/io/Reader;
    .end local v15    # "$i$f$useLines\\2\\43":I
    .restart local v6    # "process":Ljava/lang/Process;
    .restart local v7    # "watchdog":Ljava/lang/Thread;
    .restart local v8    # "result":Ljava/lang/Object;
    .restart local v11    # "error":Ljava/lang/Object;
    .restart local v12    # "lastLine":Ljava/lang/Object;
    .restart local p0    # "this":Lorg/lighttouch/android/GuestApps;
    .restart local p1    # "socket":Ljava/lang/String;
    .restart local p2    # "args":Ljava/util/List;
    .restart local p3    # "timeoutSeconds":J
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    .restart local p6    # "event":Lkotlin/jvm/functions/Function1;
    :catchall_2
    move-exception v0

    invoke-virtual {v7}, Ljava/lang/Thread;->interrupt()V

    invoke-virtual {v6}, Ljava/lang/Process;->destroy()V

    throw v0

    .line 28
    .end local v6    # "process":Ljava/lang/Process;
    .end local v7    # "watchdog":Ljava/lang/Thread;
    .end local v8    # "result":Ljava/lang/Object;
    .end local v11    # "error":Ljava/lang/Object;
    .end local v12    # "lastLine":Ljava/lang/Object;
    :cond_9
    move-wide/from16 v9, p3

    new-instance v0, Lorg/lighttouch/android/GuestApps$Failure;

    const-string v1, "\u6b64\u7248\u672c\u4e0d\u5305\u542b\u5ba2\u6237\u673a\u5e94\u7528\u670d\u52a1\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/GuestApps$Failure;-><init>(Ljava/lang/String;)V

    throw v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x9 -> :sswitch_0
        0x89 -> :sswitch_0
    .end sparse-switch
.end method

.method public final target(Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;
    .locals 11
    .param p1, "socket"    # Ljava/lang/String;

    const-string v0, "socket"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 63
    .local v0, "target":Lkotlin/jvm/internal/Ref$ObjectRef;
    const-string v1, "info"

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    new-instance v8, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda0;

    invoke-direct {v8, v0}, Lorg/lighttouch/android/GuestApps$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/internal/Ref$ObjectRef;)V

    const/16 v9, 0x8

    const/4 v10, 0x0

    const-wide/16 v5, 0x3c

    const/4 v7, 0x0

    move-object v2, p0

    move-object v3, p1

    .end local p1    # "socket":Ljava/lang/String;
    .local v3, "socket":Ljava/lang/String;
    invoke-static/range {v2 .. v10}, Lorg/lighttouch/android/GuestApps;->run$default(Lorg/lighttouch/android/GuestApps;Ljava/lang/String;Ljava/util/List;JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Lorg/json/JSONObject;

    .line 64
    iget-object p1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast p1, Lorg/lighttouch/android/StoreTarget;

    if-eqz p1, :cond_0

    return-object p1

    :cond_0
    new-instance p1, Lorg/lighttouch/android/GuestApps$Failure;

    const-string v1, "\u5ba2\u6237\u673a\u672a\u62a5\u544a\u5176\u8bbe\u5907\u7c7b\u578b\u3002"

    invoke-direct {p1, v1}, Lorg/lighttouch/android/GuestApps$Failure;-><init>(Ljava/lang/String;)V

    throw p1
.end method

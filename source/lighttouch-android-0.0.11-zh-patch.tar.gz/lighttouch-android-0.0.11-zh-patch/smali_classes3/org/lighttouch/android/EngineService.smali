.class public final Lorg/lighttouch/android/EngineService;
.super Landroid/app/Service;
.source "EngineService.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEngineService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EngineService.kt\norg/lighttouch/android/EngineService\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,678:1\n1#2:679\n1878#3,3:680\n*S KotlinDebug\n*F\n+ 1 EngineService.kt\norg/lighttouch/android/EngineService\n*L\n577#1:680,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00f5\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0007*\u0001M\u0008\u0007\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010O\u001a\u00020P2\u0006\u0010Q\u001a\u00020\u0005H\u0002J\u0010\u0010R\u001a\u00020S2\u0006\u0010T\u001a\u00020UH\u0002J\u0010\u0010V\u001a\u00020P2\u0006\u0010W\u001a\u00020\u0005H\u0002J\u0010\u0010X\u001a\u00020\u00052\u0006\u0010Y\u001a\u00020ZH\u0002J\u0010\u0010[\u001a\u00020\\2\u0006\u0010Y\u001a\u00020ZH\u0002J\u0010\u0010]\u001a\u00020P2\u0006\u0010Y\u001a\u00020ZH\u0002J\u0010\u0010^\u001a\u00020P2\u0006\u0010Y\u001a\u00020ZH\u0002J\"\u0010_\u001a\u00020`2\u0008\u0010a\u001a\u0004\u0018\u00010b2\u0006\u0010c\u001a\u00020`2\u0006\u0010d\u001a\u00020`H\u0016J\u0010\u0010e\u001a\u00020f2\u0006\u0010a\u001a\u00020bH\u0016J\u0008\u0010g\u001a\u00020PH\u0016J\u0008\u0010h\u001a\u00020PH\u0002J\u0008\u0010i\u001a\u00020PH\u0002J\u0008\u0010j\u001a\u00020PH\u0002J\u0008\u0010k\u001a\u00020SH\u0002J\u0010\u0010l\u001a\n ?*\u0004\u0018\u00010m0mH\u0002J\u0008\u0010n\u001a\u00020PH\u0002J\u0008\u0010o\u001a\u00020PH\u0002J\u0008\u0010p\u001a\u00020PH\u0002J\u0008\u0010q\u001a\u00020PH\u0002J\u0008\u0010r\u001a\u00020PH\u0002J\u0008\u0010s\u001a\u00020PH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010$\u001a\u0004\u0018\u00010%X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\'X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\'X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010-\u001a\u00020.8BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u00081\u00102\u001a\u0004\u0008/\u00100R\u001b\u00103\u001a\u0002048BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u00087\u00102\u001a\u0004\u00085\u00106R\u001b\u00108\u001a\u0002098BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008<\u00102\u001a\u0004\u0008:\u0010;R\u0016\u0010=\u001a\n ?*\u0004\u0018\u00010>0>X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001b\u0010A\u001a\u00020B8BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008E\u00102\u001a\u0004\u0008C\u0010DR\u000e\u0010F\u001a\u00020GX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010H\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010J\u001a\n ?*\u0004\u0018\u00010K0KX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010L\u001a\u00020MX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010N\u00a8\u0006t"
    }
    d2 = {
        "Lorg/lighttouch/android/EngineService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "error",
        "",
        "userPaused",
        "",
        "focusPaused",
        "started",
        "Lorg/lighttouch/android/WorkerStartAdmission;",
        "failureRecorded",
        "Ljava/util/concurrent/atomic/AtomicBoolean;",
        "stopping",
        "alive",
        "audio",
        "Landroid/media/AudioTrack;",
        "audioOn",
        "touchAdmissionGuard",
        "",
        "lifecycleAdmission",
        "Lorg/lighttouch/android/WorkerLifecycleAdmission;",
        "touchTimestampOrder",
        "Lorg/lighttouch/android/TouchTimestampOrder;",
        "displayCancellations",
        "Lorg/lighttouch/android/DisplayCancellationHistory;",
        "audioGuard",
        "Lorg/lighttouch/android/AudioPacketEpoch;",
        "audioObservations",
        "Lorg/lighttouch/android/AudioObservations;",
        "audioError",
        "microphoneWanted",
        "microphoneOn",
        "microphoneError",
        "microphoneThread",
        "Ljava/lang/Thread;",
        "recorder",
        "Landroid/media/AudioRecord;",
        "buttonDownAdmissions",
        "Ljava/util/concurrent/atomic/AtomicLongArray;",
        "buttonUpAdmissions",
        "buttonRejections",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "shutdownWatchdog",
        "Lorg/lighttouch/android/ShutdownWatchdog;",
        "profileCapture",
        "Lorg/lighttouch/android/ProfileCapture;",
        "getProfileCapture",
        "()Lorg/lighttouch/android/ProfileCapture;",
        "profileCapture$delegate",
        "Lkotlin/Lazy;",
        "performanceSampler",
        "Lorg/lighttouch/android/WorkerPerformanceSampler;",
        "getPerformanceSampler",
        "()Lorg/lighttouch/android/WorkerPerformanceSampler;",
        "performanceSampler$delegate",
        "usb",
        "Lorg/lighttouch/android/UsbBridge;",
        "getUsb",
        "()Lorg/lighttouch/android/UsbBridge;",
        "usb$delegate",
        "usbThread",
        "Ljava/util/concurrent/ExecutorService;",
        "kotlin.jvm.PlatformType",
        "usbError",
        "cpuSampler",
        "Lorg/lighttouch/android/WorkerCpuSampler;",
        "getCpuSampler",
        "()Lorg/lighttouch/android/WorkerCpuSampler;",
        "cpuSampler$delegate",
        "profileTail",
        "Lorg/lighttouch/android/ProfileTail;",
        "detailedTiming",
        "detailedTimingError",
        "detailedTimingThread",
        "Ljava/util/concurrent/ScheduledExecutorService;",
        "binder",
        "org/lighttouch/android/EngineService$binder$1",
        "Lorg/lighttouch/android/EngineService$binder$1;",
        "persistObservations",
        "",
        "reason",
        "shutdownProgressBundle",
        "Landroid/os/Bundle;",
        "snapshot",
        "Lorg/lighttouch/android/ShutdownDebugProgress;",
        "persistStopError",
        "message",
        "shutdownMessage",
        "receipt",
        "Lorg/lighttouch/android/ShutdownReceipt;",
        "shutdownRecord",
        "Lorg/json/JSONObject;",
        "persistTerminalReceipt",
        "disposeAfterShutdown",
        "onStartCommand",
        "",
        "intent",
        "Landroid/content/Intent;",
        "flags",
        "startId",
        "onBind",
        "Landroid/os/IBinder;",
        "onCreate",
        "pauseAudio",
        "flushAudioLocked",
        "playAudio",
        "observations",
        "audioAttributes",
        "Landroid/media/AudioAttributes;",
        "startAudioOutput",
        "stopAudioOutput",
        "startMicrophone",
        "stopMicrophone",
        "foreground",
        "onDestroy",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final alive:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private volatile audio:Landroid/media/AudioTrack;

.field private volatile audioError:Ljava/lang/String;

.field private final audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

.field private final audioObservations:Lorg/lighttouch/android/AudioObservations;

.field private volatile audioOn:Z

.field private final binder:Lorg/lighttouch/android/EngineService$binder$1;

.field private final buttonDownAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

.field private final buttonRejections:Ljava/util/concurrent/atomic/AtomicLong;

.field private final buttonUpAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

.field private final cpuSampler$delegate:Lkotlin/Lazy;

.field private volatile detailedTiming:Z

.field private volatile detailedTimingError:Ljava/lang/String;

.field private final detailedTimingThread:Ljava/util/concurrent/ScheduledExecutorService;

.field private final displayCancellations:Lorg/lighttouch/android/DisplayCancellationHistory;

.field private volatile error:Ljava/lang/String;

.field private final failureRecorded:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private volatile focusPaused:Z

.field private final lifecycleAdmission:Lorg/lighttouch/android/WorkerLifecycleAdmission;

.field private volatile microphoneError:Ljava/lang/String;

.field private volatile microphoneOn:Z

.field private microphoneThread:Ljava/lang/Thread;

.field private volatile microphoneWanted:Z

.field private final performanceSampler$delegate:Lkotlin/Lazy;

.field private final profileCapture$delegate:Lkotlin/Lazy;

.field private final profileTail:Lorg/lighttouch/android/ProfileTail;

.field private recorder:Landroid/media/AudioRecord;

.field private final shutdownWatchdog:Lorg/lighttouch/android/ShutdownWatchdog;

.field private final started:Lorg/lighttouch/android/WorkerStartAdmission;

.field private final stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final touchAdmissionGuard:Ljava/lang/Object;

.field private final touchTimestampOrder:Lorg/lighttouch/android/TouchTimestampOrder;

.field private final usb$delegate:Lkotlin/Lazy;

.field private volatile usbError:Ljava/lang/String;

.field private final usbThread:Ljava/util/concurrent/ExecutorService;

.field private volatile userPaused:Z


# direct methods
.method public static synthetic $r8$lambda$2q1Rqn88ZDqCqmB9oKyzaNSoKNY(Ljava/lang/String;Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/EngineService;->disposeAfterShutdown$lambda$30(Ljava/lang/String;Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$33L78QrCulPMIeuUPMVO8z45u1c()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/EngineService;->shutdownWatchdog$lambda$0()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$4M5X1cwexPDspo1-FkNEHb3zQac(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->detailedTimingThread$lambda$10(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7nTDju1pn5IVJpFxm55JODW36PM(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->stopAudioOutput$lambda$57(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7tl8l8aznUbir9BmAR4k4v5nFPk(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService;->shutdownWatchdog$lambda$3(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$HFP7r-vutrQ7yLEQN1X3kduUPts(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->startAudioOutput$lambda$56(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Jn-cXyirXDOKXyAk1wkzTeWxv5w(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->usbThread$lambda$8(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RmtCxm5G67GcFcKIFiDUmMKt1hE(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->profileCapture_delegate$lambda$5(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RuF_tkB2a_XykXXM7qzWyFOm-9Y(Lorg/lighttouch/android/EngineService;Landroid/media/AudioRecord;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService;->startMicrophone$lambda$60(Lorg/lighttouch/android/EngineService;Landroid/media/AudioRecord;)V

    return-void
.end method

.method public static synthetic $r8$lambda$X_-C-_bZzSm5xmt0fAdcKzsT1TE(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerPerformanceSampler;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->performanceSampler_delegate$lambda$6(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerPerformanceSampler;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$bsjcfhv2lsFc2BiUINbU0902D-M(Lorg/lighttouch/android/EngineService;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->onCreate$lambda$44(Lorg/lighttouch/android/EngineService;)V

    return-void
.end method

.method public static synthetic $r8$lambda$cwtA3BIlT4iIT9ieYM7fiJqXEx4(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/UsbBridge;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->usb_delegate$lambda$7(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/UsbBridge;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$d2joPD5FYePsXhUmGyLsVPnltPA()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/EngineService;->disposeAfterShutdown$lambda$31()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$etu9kH9XC0V1nlBBadRwBEl1_8k(Lorg/lighttouch/android/EngineService;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->onCreate$lambda$32(Lorg/lighttouch/android/EngineService;)V

    return-void
.end method

.method public static synthetic $r8$lambda$fPP_sbTnbmIUmySo6qtQe6ciRZY(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService;->shutdownWatchdog$lambda$4(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tkmmd-hCWb0Y7niFps8aKJGGKMI()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/EngineService;->shutdownWatchdog$lambda$1()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$wzXZUYxAzM4sm-r4KMRDGx0tIZM()[Ljava/lang/String;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/EngineService;->shutdownWatchdog$lambda$2()[Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$x3nBlyuClIXFkspNdejKBpKw1aI()Lorg/lighttouch/android/WorkerCpuSampler;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/EngineService;->cpuSampler_delegate$lambda$9()Lorg/lighttouch/android/WorkerCpuSampler;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/EngineService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .locals 13

    .line 13
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    .line 14
    const-string v0, ""

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->error:Ljava/lang/String;

    .line 17
    new-instance v1, Lorg/lighttouch/android/WorkerStartAdmission;

    invoke-direct {v1}, Lorg/lighttouch/android/WorkerStartAdmission;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->started:Lorg/lighttouch/android/WorkerStartAdmission;

    .line 18
    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->failureRecorded:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 20
    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 24
    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->touchAdmissionGuard:Ljava/lang/Object;

    .line 25
    new-instance v1, Lorg/lighttouch/android/WorkerLifecycleAdmission;

    invoke-direct {v1}, Lorg/lighttouch/android/WorkerLifecycleAdmission;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->lifecycleAdmission:Lorg/lighttouch/android/WorkerLifecycleAdmission;

    .line 26
    new-instance v1, Lorg/lighttouch/android/TouchTimestampOrder;

    invoke-direct {v1}, Lorg/lighttouch/android/TouchTimestampOrder;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->touchTimestampOrder:Lorg/lighttouch/android/TouchTimestampOrder;

    .line 27
    new-instance v1, Lorg/lighttouch/android/DisplayCancellationHistory;

    invoke-direct {v1}, Lorg/lighttouch/android/DisplayCancellationHistory;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->displayCancellations:Lorg/lighttouch/android/DisplayCancellationHistory;

    .line 28
    new-instance v1, Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-direct {v1}, Lorg/lighttouch/android/AudioPacketEpoch;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    .line 29
    new-instance v1, Lorg/lighttouch/android/AudioObservations;

    invoke-direct {v1}, Lorg/lighttouch/android/AudioObservations;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    .line 30
    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->audioError:Ljava/lang/String;

    .line 34
    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    .line 37
    new-instance v1, Ljava/util/concurrent/atomic/AtomicLongArray;

    const/4 v2, 0x2

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicLongArray;-><init>(I)V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->buttonDownAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

    .line 38
    new-instance v1, Ljava/util/concurrent/atomic/AtomicLongArray;

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicLongArray;-><init>(I)V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->buttonUpAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

    .line 39
    new-instance v1, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v2, 0x0

    invoke-direct {v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->buttonRejections:Ljava/util/concurrent/atomic/AtomicLong;

    .line 40
    new-instance v4, Lorg/lighttouch/android/ShutdownWatchdog;

    sget-object v1, Lorg/lighttouch/android/EngineService$shutdownWatchdog$1;->INSTANCE:Lorg/lighttouch/android/EngineService$shutdownWatchdog$1;

    move-object v7, v1

    check-cast v7, Lkotlin/jvm/functions/Function0;

    new-instance v8, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda13;

    invoke-direct {v8}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda13;-><init>()V

    new-instance v9, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda15;

    invoke-direct {v9}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda15;-><init>()V

    new-instance v10, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda16;

    invoke-direct {v10}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda16;-><init>()V

    .line 42
    new-instance v11, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda17;

    invoke-direct {v11, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda17;-><init>(Lorg/lighttouch/android/EngineService;)V

    .line 43
    new-instance v12, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda1;

    invoke-direct {v12, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/EngineService;)V

    .line 40
    const-wide/32 v5, 0x88b8

    invoke-direct/range {v4 .. v12}, Lorg/lighttouch/android/ShutdownWatchdog;-><init>(JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    iput-object v4, p0, Lorg/lighttouch/android/EngineService;->shutdownWatchdog:Lorg/lighttouch/android/ShutdownWatchdog;

    .line 44
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/EngineService;)V

    invoke-static {v1}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v1

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->profileCapture$delegate:Lkotlin/Lazy;

    .line 45
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/EngineService;)V

    invoke-static {v1}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v1

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->performanceSampler$delegate:Lkotlin/Lazy;

    .line 46
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/EngineService;)V

    invoke-static {v1}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v1

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->usb$delegate:Lkotlin/Lazy;

    .line 48
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda5;

    invoke-direct {v1}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda5;-><init>()V

    invoke-static {v1}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->usbThread:Ljava/util/concurrent/ExecutorService;

    .line 49
    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->usbError:Ljava/lang/String;

    .line 50
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda6;

    invoke-direct {v1}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda6;-><init>()V

    invoke-static {v1}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v1

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->cpuSampler$delegate:Lkotlin/Lazy;

    .line 51
    new-instance v1, Lorg/lighttouch/android/ProfileTail;

    invoke-direct {v1}, Lorg/lighttouch/android/ProfileTail;-><init>()V

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->profileTail:Lorg/lighttouch/android/ProfileTail;

    .line 54
    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingError:Ljava/lang/String;

    .line 57
    new-instance v0, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda14;

    invoke-direct {v0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda14;-><init>()V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingThread:Ljava/util/concurrent/ScheduledExecutorService;

    .line 58
    new-instance v0, Lorg/lighttouch/android/EngineService$binder$1;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/EngineService$binder$1;-><init>(Lorg/lighttouch/android/EngineService;)V

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->binder:Lorg/lighttouch/android/EngineService$binder$1;

    .line 13
    return-void
.end method

.method public static final synthetic access$flushAudioLocked(Lorg/lighttouch/android/EngineService;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->flushAudioLocked()V

    return-void
.end method

.method public static final synthetic access$foreground(Lorg/lighttouch/android/EngineService;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->foreground()V

    return-void
.end method

.method public static final synthetic access$getAlive$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method public static final synthetic access$getAudioError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audioError:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getAudioGuard$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioPacketEpoch;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    return-object v0
.end method

.method public static final synthetic access$getAudioObservations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioObservations;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    return-object v0
.end method

.method public static final synthetic access$getButtonDownAdmissions$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicLongArray;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->buttonDownAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

    return-object v0
.end method

.method public static final synthetic access$getButtonRejections$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicLong;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->buttonRejections:Ljava/util/concurrent/atomic/AtomicLong;

    return-object v0
.end method

.method public static final synthetic access$getButtonUpAdmissions$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicLongArray;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->buttonUpAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

    return-object v0
.end method

.method public static final synthetic access$getCpuSampler(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerCpuSampler;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getCpuSampler()Lorg/lighttouch/android/WorkerCpuSampler;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getDetailedTiming$p(Lorg/lighttouch/android/EngineService;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-boolean v0, p0, Lorg/lighttouch/android/EngineService;->detailedTiming:Z

    return v0
.end method

.method public static final synthetic access$getDetailedTimingError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingError:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getDisplayCancellations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/DisplayCancellationHistory;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->displayCancellations:Lorg/lighttouch/android/DisplayCancellationHistory;

    return-object v0
.end method

.method public static final synthetic access$getError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->error:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getFailureRecorded$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->failureRecorded:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method public static final synthetic access$getFocusPaused$p(Lorg/lighttouch/android/EngineService;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-boolean v0, p0, Lorg/lighttouch/android/EngineService;->focusPaused:Z

    return v0
.end method

.method public static final synthetic access$getLifecycleAdmission$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerLifecycleAdmission;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->lifecycleAdmission:Lorg/lighttouch/android/WorkerLifecycleAdmission;

    return-object v0
.end method

.method public static final synthetic access$getPerformanceSampler(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerPerformanceSampler;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getPerformanceSampler()Lorg/lighttouch/android/WorkerPerformanceSampler;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getProfileCapture()Lorg/lighttouch/android/ProfileCapture;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getProfileTail$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileTail;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->profileTail:Lorg/lighttouch/android/ProfileTail;

    return-object v0
.end method

.method public static final synthetic access$getShutdownWatchdog$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ShutdownWatchdog;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->shutdownWatchdog:Lorg/lighttouch/android/ShutdownWatchdog;

    return-object v0
.end method

.method public static final synthetic access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->started:Lorg/lighttouch/android/WorkerStartAdmission;

    return-object v0
.end method

.method public static final synthetic access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-object v0
.end method

.method public static final synthetic access$getTouchAdmissionGuard$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/Object;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->touchAdmissionGuard:Ljava/lang/Object;

    return-object v0
.end method

.method public static final synthetic access$getTouchTimestampOrder$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/TouchTimestampOrder;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->touchTimestampOrder:Lorg/lighttouch/android/TouchTimestampOrder;

    return-object v0
.end method

.method public static final synthetic access$getUsb(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/UsbBridge;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getUsb()Lorg/lighttouch/android/UsbBridge;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getUsbError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->usbError:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getUsbThread$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/ExecutorService;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->usbThread:Ljava/util/concurrent/ExecutorService;

    return-object v0
.end method

.method public static final synthetic access$getUserPaused$p(Lorg/lighttouch/android/EngineService;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    iget-boolean v0, p0, Lorg/lighttouch/android/EngineService;->userPaused:Z

    return v0
.end method

.method public static final synthetic access$observations(Lorg/lighttouch/android/EngineService;)Landroid/os/Bundle;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->observations()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$pauseAudio(Lorg/lighttouch/android/EngineService;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->pauseAudio()V

    return-void
.end method

.method public static final synthetic access$persistObservations(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "reason"    # Ljava/lang/String;

    .line 13
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->persistObservations(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$persistStopError(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "message"    # Ljava/lang/String;

    .line 13
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->persistStopError(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setDetailedTiming$p(Lorg/lighttouch/android/EngineService;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Z

    .line 13
    iput-boolean p1, p0, Lorg/lighttouch/android/EngineService;->detailedTiming:Z

    return-void
.end method

.method public static final synthetic access$setDetailedTimingError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 13
    iput-object p1, p0, Lorg/lighttouch/android/EngineService;->detailedTimingError:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 13
    iput-object p1, p0, Lorg/lighttouch/android/EngineService;->error:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setFocusPaused$p(Lorg/lighttouch/android/EngineService;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Z

    .line 13
    iput-boolean p1, p0, Lorg/lighttouch/android/EngineService;->focusPaused:Z

    return-void
.end method

.method public static final synthetic access$setMicrophoneError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 13
    iput-object p1, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setMicrophoneWanted$p(Lorg/lighttouch/android/EngineService;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Z

    .line 13
    iput-boolean p1, p0, Lorg/lighttouch/android/EngineService;->microphoneWanted:Z

    return-void
.end method

.method public static final synthetic access$setUsbError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 13
    iput-object p1, p0, Lorg/lighttouch/android/EngineService;->usbError:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setUserPaused$p(Lorg/lighttouch/android/EngineService;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "<set-?>"    # Z

    .line 13
    iput-boolean p1, p0, Lorg/lighttouch/android/EngineService;->userPaused:Z

    return-void
.end method

.method public static final synthetic access$shutdownProgressBundle(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownDebugProgress;)Landroid/os/Bundle;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;
    .param p1, "snapshot"    # Lorg/lighttouch/android/ShutdownDebugProgress;

    .line 13
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->shutdownProgressBundle(Lorg/lighttouch/android/ShutdownDebugProgress;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$startAudioOutput(Lorg/lighttouch/android/EngineService;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->startAudioOutput()V

    return-void
.end method

.method public static final synthetic access$stopAudioOutput(Lorg/lighttouch/android/EngineService;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/EngineService;

    .line 13
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->stopAudioOutput()V

    return-void
.end method

.method private final audioAttributes()Landroid/media/AudioAttributes;
    .locals 2

    .line 590
    new-instance v0, Landroid/media/AudioAttributes$Builder;

    invoke-direct {v0}, Landroid/media/AudioAttributes$Builder;-><init>()V

    const/16 v1, 0xe

    invoke-virtual {v0, v1}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object v0

    return-object v0
.end method

.method private static final cpuSampler_delegate$lambda$9()Lorg/lighttouch/android/WorkerCpuSampler;
    .locals 1

    .line 50
    new-instance v0, Lorg/lighttouch/android/WorkerCpuSampler;

    invoke-direct {v0}, Lorg/lighttouch/android/WorkerCpuSampler;-><init>()V

    return-object v0
.end method

.method private static final detailedTimingThread$lambda$10(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 2
    .param p0, "it"    # Ljava/lang/Runnable;

    .line 57
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "detailed-timing"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    return-object v0
.end method

.method private final disposeAfterShutdown(Lorg/lighttouch/android/ShutdownReceipt;)V
    .locals 3
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 426
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 427
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->shutdownMessage(Lorg/lighttouch/android/ShutdownReceipt;)Ljava/lang/String;

    move-result-object v0

    .line 428
    .local v0, "message":Ljava/lang/String;
    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->error:Ljava/lang/String;

    .line 429
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getReason()Ljava/lang/String;

    move-result-object v1

    const-string v2, "native-terminal"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 431
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 432
    return-void

    .line 434
    :cond_0
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda0;

    invoke-direct {v1, v0, p0, p1}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)V

    new-instance v2, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda9;

    invoke-direct {v2}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda9;-><init>()V

    invoke-static {v1, v2}, Lorg/lighttouch/android/ShutdownWatchdogKt;->disposeWithoutWaitingForReceipt(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 442
    return-void
.end method

.method private static final disposeAfterShutdown$lambda$30(Ljava/lang/String;Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 6
    .param p0, "$message"    # Ljava/lang/String;
    .param p1, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p2, "$receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 435
    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x1

    if-lez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    invoke-direct {p1, p0}, Lorg/lighttouch/android/EngineService;->persistStopError(Ljava/lang/String;)V

    .line 438
    :cond_1
    invoke-direct {p1, p2}, Lorg/lighttouch/android/EngineService;->shutdownRecord(Lorg/lighttouch/android/ShutdownReceipt;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v2, "receiptPersistenceBestEffort"

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    .line 439
    .local v0, "record":Lorg/json/JSONObject;
    :try_start_0
    new-instance v1, Ljava/io/File;

    invoke-virtual {p1}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "worker-shutdown-deadline-"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ".json"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v2, 0x2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "toString(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v1, v3, v4, v2, v4}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 440
    :catch_0
    move-exception v1

    .line 441
    :goto_1
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final disposeAfterShutdown$lambda$31()Lkotlin/Unit;
    .locals 1

    .line 441
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final flushAudioLocked()V
    .locals 5

    .line 532
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v0, :cond_0

    .line 679
    .local v0, "it\\1":Landroid/media/AudioTrack;
    const/4 v1, 0x0

    .line 532
    .local v1, "$i$a$-let-EngineService$flushAudioLocked$1\\1\\532\\0":I
    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getPlaybackHeadPosition()I

    move-result v3

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getUnderrunCount()I

    move-result v4

    invoke-virtual {v2, v3, v4}, Lorg/lighttouch/android/AudioObservations;->observeTrack(II)V

    invoke-virtual {v0}, Landroid/media/AudioTrack;->pause()V

    invoke-virtual {v0}, Landroid/media/AudioTrack;->flush()V

    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v2}, Lorg/lighttouch/android/AudioObservations;->flushed()V

    .line 533
    .end local v0    # "it\\1":Landroid/media/AudioTrack;
    .end local v1    # "$i$a$-let-EngineService$flushAudioLocked$1\\1\\532\\0":I
    :cond_0
    return-void
.end method

.method private final foreground()V
    .locals 6

    .line 670
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/EngineService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 671
    .local v0, "manager":Landroid/app/NotificationManager;
    new-instance v1, Landroid/app/NotificationChannel;

    const-string v2, "Running guest"

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v3, 0x2

    const-string v4, "guest"

    invoke-direct {v1, v4, v2, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    invoke-virtual {v0, v1}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 672
    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    new-instance v2, Landroid/content/Intent;

    move-object v3, p0

    check-cast v3, Landroid/content/Context;

    const-class v5, Lorg/lighttouch/android/MainActivity;

    invoke-direct {v2, v3, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v3, 0x4000000

    const/4 v5, 0x0

    invoke-static {v1, v5, v2, v3}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    .line 673
    .local v1, "launch":Landroid/app/PendingIntent;
    new-instance v2, Landroid/app/Notification$Builder;

    move-object v3, p0

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3, v4}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v3, 0x1080024

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v2

    .line 674
    const-string v3, "LightTouch guest"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const-string v3, "Tap to return; Stop ends this worker"

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v2

    .line 673
    invoke-virtual {p0, v3, v2}, Lorg/lighttouch/android/EngineService;->startForeground(ILandroid/app/Notification;)V

    .line 675
    return-void
.end method

.method private final getCpuSampler()Lorg/lighttouch/android/WorkerCpuSampler;
    .locals 1

    .line 50
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->cpuSampler$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/WorkerCpuSampler;

    return-object v0
.end method

.method private final getPerformanceSampler()Lorg/lighttouch/android/WorkerPerformanceSampler;
    .locals 1

    .line 45
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->performanceSampler$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/WorkerPerformanceSampler;

    return-object v0
.end method

.method private final getProfileCapture()Lorg/lighttouch/android/ProfileCapture;
    .locals 1

    .line 44
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->profileCapture$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/ProfileCapture;

    return-object v0
.end method

.method private final getUsb()Lorg/lighttouch/android/UsbBridge;
    .locals 1

    .line 46
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->usb$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/UsbBridge;

    return-object v0
.end method

.method private final observations()Landroid/os/Bundle;
    .locals 26

    .line 535
    move-object/from16 v1, p0

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v2, v0

    .local v2, "$this$observations_u24lambda_u2454\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 536
    .local v3, "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    sget-object v4, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v4}, Lorg/lighttouch/android/Native;->observations()[J

    move-result-object v4

    .line 537
    .local v4, "values\\1":[J
    const/16 v5, 0x41

    new-array v5, v5, [Ljava/lang/String;

    const-string v6, "hostMonotonicNs"

    const/4 v7, 0x0

    aput-object v6, v5, v7

    const-string v6, "presentedFrames"

    const/4 v8, 0x1

    aput-object v6, v5, v8

    const-string v6, "firstPresentHostNs"

    const/4 v9, 0x2

    aput-object v6, v5, v9

    const/4 v6, 0x3

    const-string v10, "lastPresentHostNs"

    aput-object v10, v5, v6

    const/4 v6, 0x4

    const-string v10, "maxPresentGapNs"

    aput-object v10, v5, v6

    const/4 v6, 0x5

    const-string v10, "maxPresentWorkNs"

    aput-object v10, v5, v6

    .line 538
    const-string v6, "windowFailures"

    const/4 v10, 0x6

    aput-object v6, v5, v10

    .line 537
    nop

    .line 538
    const-string v6, "frameCopyFailures"

    const/4 v10, 0x7

    aput-object v6, v5, v10

    .line 537
    nop

    .line 538
    const-string v6, "surfaceGeneration"

    const/16 v10, 0x8

    aput-object v6, v5, v10

    .line 537
    nop

    .line 538
    const-string v6, "guestFrameSequence"

    const/16 v11, 0x9

    aput-object v6, v5, v11

    .line 537
    nop

    .line 538
    const-string v6, "guestFrameTimestampNs"

    const/16 v11, 0xa

    aput-object v6, v5, v11

    .line 537
    nop

    .line 538
    const-string v6, "nativePcmFailures"

    const/16 v11, 0xb

    aput-object v6, v5, v11

    .line 537
    nop

    .line 538
    const-string v6, "pcmDroppedFrames"

    const/16 v11, 0xc

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "presentIntervalsTo16ms"

    const/16 v11, 0xd

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "presentIntervalsTo33ms"

    const/16 v11, 0xe

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "presentIntervalsTo50ms"

    const/16 v11, 0xf

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "presentIntervalsTo100ms"

    const/16 v11, 0x10

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "presentIntervalsTo250ms"

    const/16 v11, 0x11

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "presentIntervalsOver250ms"

    const/16 v11, 0x12

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "producedFrames"

    const/16 v11, 0x13

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "producerFrameSequence"

    const/16 v11, 0x14

    aput-object v6, v5, v11

    .line 537
    nop

    .line 539
    const-string v6, "producerFrameTimestampNs"

    const/16 v11, 0x15

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "framePublishedHostNs"

    const/16 v11, 0x16

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "pcmCapturedFrames"

    const/16 v11, 0x17

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "pcmPulledFrames"

    const/16 v11, 0x18

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "sharedPcmDroppedFrames"

    const/16 v11, 0x19

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "inputRequests"

    const/16 v11, 0x1a

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "pcmQueuedPackets"

    const/16 v11, 0x1b

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "firstWindowLockError"

    const/16 v11, 0x1c

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "lastWindowLockError"

    const/16 v11, 0x1d

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "firstWindowPostError"

    const/16 v11, 0x1e

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "lastWindowPostError"

    const/16 v11, 0x1f

    aput-object v6, v5, v11

    .line 537
    nop

    .line 540
    const-string v6, "lastWindowGeometryError"

    const/16 v11, 0x20

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "windowGeometryFailures"

    const/16 v11, 0x21

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "windowBufferFormat"

    const/16 v11, 0x22

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "windowBufferWidth"

    const/16 v11, 0x23

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "windowBufferHeight"

    const/16 v11, 0x24

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "windowBufferStride"

    const/16 v11, 0x25

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "invalidWindowBuffers"

    const/16 v11, 0x26

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "firstWindowErrorHostNs"

    const/16 v11, 0x27

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "runtimeDiagnosticsStatus"

    const/16 v11, 0x28

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "engineReady"

    const/16 v11, 0x29

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "displaySleeping"

    const/16 v11, 0x2a

    aput-object v6, v5, v11

    .line 537
    nop

    .line 541
    const-string v6, "backlightLevel"

    const/16 v11, 0x2b

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestAgentSampleStatus"

    const/16 v11, 0x2c

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestAgentState"

    const/16 v11, 0x2d

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "shutdownPhase"

    const/16 v11, 0x2e

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "shutdownRoute"

    const/16 v11, 0x2f

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "shutdownReplyStatus"

    const/16 v11, 0x30

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "shutdownReplyReceived"

    const/16 v11, 0x31

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestFrameWidth"

    const/16 v11, 0x32

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestFrameHeight"

    const/16 v11, 0x33

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestFrameSamplePixels"

    const/16 v11, 0x34

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestFrameNonzeroRgbSamples"

    const/16 v11, 0x35

    aput-object v6, v5, v11

    .line 537
    nop

    .line 542
    const-string v6, "guestFrameRgbSampleSum"

    const/16 v11, 0x36

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "windowAttached"

    const/16 v11, 0x37

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presentationEpoch"

    const/16 v11, 0x38

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presenterPhase"

    const/16 v11, 0x39

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presenterPhaseEntryHostNs"

    const/16 v11, 0x3a

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presenterPhaseGeneration"

    const/16 v11, 0x3b

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presenterPhaseEpoch"

    const/16 v11, 0x3c

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presenterPhaseRevision"

    const/16 v11, 0x3d

    aput-object v6, v5, v11

    .line 537
    nop

    .line 543
    const-string v6, "presenterPhaseSampleStable"

    const/16 v11, 0x3e

    aput-object v6, v5, v11

    .line 537
    nop

    .line 544
    const-string v6, "ignoredInputRejections"

    const/16 v11, 0x3f

    aput-object v6, v5, v11

    .line 537
    nop

    .line 544
    const-string v6, "lastIgnoredInputRequest"

    const/16 v11, 0x40

    aput-object v6, v5, v11

    .line 537
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    .line 545
    .local v5, "keys\\1":Ljava/util/List;
    move-object v6, v5

    check-cast v6, Ljava/lang/Iterable;

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    move v11, v7

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_0

    move v12, v11

    .local v12, "index\\1":I
    add-int/2addr v11, v8

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    .local v13, "key\\1":Ljava/lang/String;
    aget-wide v14, v4, v12

    invoke-virtual {v2, v13, v14, v15}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    goto :goto_0

    .line 546
    .end local v12    # "index\\1":I
    .end local v13    # "key\\1":Ljava/lang/String;
    :cond_0
    const-string v6, "presenterTelemetryGuestEvidence"

    invoke-virtual {v2, v6, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 547
    const-string v6, "runtimeDiagnosticsStatus"

    invoke-virtual {v2, v6}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v11

    const-wide/16 v13, 0x0

    cmp-long v6, v11, v13

    if-nez v6, :cond_1

    move v6, v8

    goto :goto_1

    :cond_1
    move v6, v7

    .line 548
    .local v6, "diagnosticAvailable\\1":Z
    :goto_1
    const-string v11, "guestAgentSampleStatus"

    invoke-virtual {v2, v11}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v11

    cmp-long v11, v11, v13

    if-nez v11, :cond_2

    goto :goto_2

    :cond_2
    move v8, v7

    .line 549
    .local v8, "agentAvailable\\1":Z
    :goto_2
    const-string v11, "runtimeDiagnosticsAvailable"

    invoke-virtual {v2, v11, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 550
    const-string v11, "guestAgentStateAvailable"

    invoke-virtual {v2, v11, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 551
    const-string v11, "guestAgentEndpointAvailable"

    invoke-virtual {v2, v11, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 552
    const-string v11, "guestAgentFreshnessAgeAvailable"

    invoke-virtual {v2, v11, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 553
    const-string v11, "guestAgentStateLabel"

    .line 554
    if-nez v8, :cond_3

    const-string v12, "unavailable"

    goto :goto_4

    .line 555
    :cond_3
    if-eqz v6, :cond_7

    const-string v12, "engineReady"

    invoke-virtual {v2, v12}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v15

    cmp-long v12, v15, v13

    if-nez v12, :cond_4

    goto :goto_3

    .line 556
    :cond_4
    const-string v12, "guestAgentState"

    invoke-virtual {v2, v12}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v12

    const-wide/16 v14, 0x1

    cmp-long v12, v12, v14

    if-nez v12, :cond_5

    const-string v12, "alive"

    goto :goto_4

    .line 557
    :cond_5
    const-string v12, "guestAgentState"

    invoke-virtual {v2, v12}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v12

    const-wide/16 v14, 0x2

    cmp-long v12, v12, v14

    if-nez v12, :cond_6

    const-string v12, "stale"

    goto :goto_4

    .line 558
    :cond_6
    const-string v12, "absent"

    goto :goto_4

    .line 555
    :cond_7
    :goto_3
    const-string v12, "not ready"

    .line 553
    :goto_4
    invoke-virtual {v2, v11, v12}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 560
    const-string v11, "audio"

    iget-object v12, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v12

    .line 679
    const/4 v13, 0x0

    .line 560
    .local v13, "$i$a$-synchronized-EngineService$observations$1$1\\2\\560\\1":I
    :try_start_0
    iget-object v14, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v14}, Lorg/lighttouch/android/AudioObservations;->snapshot()Landroid/os/Bundle;

    move-result-object v14

    move-object v15, v14

    .local v15, "$this$observations_u24lambda_u2454_u24lambda_u2449_u24lambda_u2448\\3":Landroid/os/Bundle;
    const/16 v16, 0x0

    .line 561
    .local v16, "$i$a$-apply-EngineService$observations$1$1$1\\3\\560\\2":I
    const-string v7, "packetGeneration"

    iget-object v10, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v10}, Lorg/lighttouch/android/AudioPacketEpoch;->currentGeneration()J

    move-result-wide v9

    invoke-virtual {v15, v7, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v7, "packetAdmissionOpen"

    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v9}, Lorg/lighttouch/android/AudioPacketEpoch;->admissionOpen()Z

    move-result v9

    invoke-virtual {v15, v7, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 562
    nop

    .line 560
    .end local v15    # "$this$observations_u24lambda_u2454_u24lambda_u2449_u24lambda_u2448\\3":Landroid/os/Bundle;
    .end local v16    # "$i$a$-apply-EngineService$observations$1$1$1\\3\\560\\2":I
    nop

    .line 562
    nop

    .line 560
    .end local v13    # "$i$a$-synchronized-EngineService$observations$1$1\\2\\560\\1":I
    monitor-exit v12

    invoke-virtual {v2, v11, v14}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 563
    const-string v7, "userPaused"

    iget-boolean v9, v1, Lorg/lighttouch/android/EngineService;->userPaused:Z

    invoke-virtual {v2, v7, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v7, "focusPaused"

    iget-boolean v9, v1, Lorg/lighttouch/android/EngineService;->focusPaused:Z

    invoke-virtual {v2, v7, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v7, "audioOutputOn"

    iget-boolean v9, v1, Lorg/lighttouch/android/EngineService;->audioOn:Z

    invoke-virtual {v2, v7, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 564
    const-string v7, "microphoneOn"

    iget-boolean v9, v1, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    invoke-virtual {v2, v7, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v7, "microphoneError"

    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    invoke-virtual {v2, v7, v9}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 565
    const-string v7, "buttonDownAdmissions"

    const/4 v9, 0x2

    new-array v10, v9, [J

    const/4 v11, 0x0

    :goto_5
    if-ge v11, v9, :cond_8

    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->buttonDownAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

    invoke-virtual {v9, v11}, Ljava/util/concurrent/atomic/AtomicLongArray;->get(I)J

    move-result-wide v12

    aput-wide v12, v10, v11

    add-int/lit8 v11, v11, 0x1

    const/4 v9, 0x2

    goto :goto_5

    :cond_8
    invoke-virtual {v2, v7, v10}, Landroid/os/Bundle;->putLongArray(Ljava/lang/String;[J)V

    .line 566
    const-string v7, "buttonUpAdmissions"

    const/4 v9, 0x2

    new-array v10, v9, [J

    const/4 v11, 0x0

    :goto_6
    if-ge v11, v9, :cond_9

    iget-object v12, v1, Lorg/lighttouch/android/EngineService;->buttonUpAdmissions:Ljava/util/concurrent/atomic/AtomicLongArray;

    invoke-virtual {v12, v11}, Ljava/util/concurrent/atomic/AtomicLongArray;->get(I)J

    move-result-wide v12

    aput-wide v12, v10, v11

    add-int/lit8 v11, v11, 0x1

    goto :goto_6

    :cond_9
    invoke-virtual {v2, v7, v10}, Landroid/os/Bundle;->putLongArray(Ljava/lang/String;[J)V

    .line 567
    const-string v7, "buttonRejections"

    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->buttonRejections:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v9}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v9

    invoke-virtual {v2, v7, v9, v10}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 570
    iget-object v7, v1, Lorg/lighttouch/android/EngineService;->displayCancellations:Lorg/lighttouch/android/DisplayCancellationHistory;

    invoke-virtual {v7}, Lorg/lighttouch/android/DisplayCancellationHistory;->getSnapshot()Lorg/lighttouch/android/DisplayCancellationSnapshot;

    move-result-object v7

    .line 571
    .local v7, "cancellations\\1":Lorg/lighttouch/android/DisplayCancellationSnapshot;
    const-string v9, "displayInputCancellations"

    new-instance v10, Landroid/os/Bundle;

    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    move-object v11, v10

    .local v11, "$this$observations_u24lambda_u2454_u24lambda_u2452\\4":Landroid/os/Bundle;
    const/4 v12, 0x0

    .line 572
    .local v12, "$i$a$-apply-EngineService$observations$1$4\\4\\571\\1":I
    const-string v13, "count"

    invoke-virtual {v7}, Lorg/lighttouch/android/DisplayCancellationSnapshot;->getCount()J

    move-result-wide v14

    invoke-virtual {v11, v13, v14, v15}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 573
    const-string v13, "lastReason"

    invoke-virtual {v7}, Lorg/lighttouch/android/DisplayCancellationSnapshot;->getReasons()Ljava/util/List;

    move-result-object v14

    invoke-static {v14}, Lkotlin/collections/CollectionsKt;->lastOrNull(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    if-nez v14, :cond_a

    const-string v14, ""

    :cond_a
    invoke-virtual {v11, v13, v14}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 576
    const-string v13, "reasons"

    new-instance v14, Landroid/os/Bundle;

    invoke-direct {v14}, Landroid/os/Bundle;-><init>()V

    move-object v15, v14

    .local v15, "$this$observations_u24lambda_u2454_u24lambda_u2452_u24lambda_u2451\\5":Landroid/os/Bundle;
    const/16 v16, 0x0

    .line 577
    .local v16, "$i$a$-apply-EngineService$observations$1$4$1\\5\\576\\4":I
    invoke-virtual {v7}, Lorg/lighttouch/android/DisplayCancellationSnapshot;->getReasons()Ljava/util/List;

    move-result-object v17

    check-cast v17, Ljava/lang/Iterable;

    .local v17, "$this$forEachIndexed\\6":Ljava/lang/Iterable;
    const/16 v18, 0x0

    .line 680
    .local v18, "$i$f$forEachIndexed\\6\\577":I
    const/16 v19, 0x0

    .line 681
    .local v19, "index\\6":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_7
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_c

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v21

    .local v21, "item\\6":Ljava/lang/Object;
    add-int/lit8 v22, v19, 0x1

    .end local v19    # "index\\6":I
    .local v22, "index\\6":I
    if-gez v19, :cond_b

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_b
    move-object/from16 v23, v0

    move-object/from16 v0, v21

    check-cast v0, Ljava/lang/String;

    .local v0, "reason\\7":Ljava/lang/String;
    .local v19, "index\\7":I
    const/16 v24, 0x0

    .line 577
    .local v24, "$i$a$-forEachIndexed-EngineService$observations$1$4$1$1\\7\\681\\5":I
    move/from16 v25, v3

    .end local v3    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    .local v25, "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    invoke-static/range {v19 .. v19}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v15, v3, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 681
    .end local v0    # "reason\\7":Ljava/lang/String;
    .end local v19    # "index\\7":I
    .end local v24    # "$i$a$-forEachIndexed-EngineService$observations$1$4$1$1\\7\\681\\5":I
    move/from16 v19, v22

    move-object/from16 v0, v23

    move/from16 v3, v25

    .end local v21    # "item\\6":Ljava/lang/Object;
    goto :goto_7

    .line 682
    .end local v22    # "index\\6":I
    .end local v25    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    .restart local v3    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    .local v19, "index\\6":I
    :cond_c
    move-object/from16 v23, v0

    move/from16 v25, v3

    .line 578
    .end local v3    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    .end local v17    # "$this$forEachIndexed\\6":Ljava/lang/Iterable;
    .end local v18    # "$i$f$forEachIndexed\\6\\577":I
    .end local v19    # "index\\6":I
    .restart local v25    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    nop

    .end local v15    # "$this$observations_u24lambda_u2454_u24lambda_u2452_u24lambda_u2451\\5":Landroid/os/Bundle;
    .end local v16    # "$i$a$-apply-EngineService$observations$1$4$1\\5\\576\\4":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 576
    invoke-virtual {v11, v13, v14}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 579
    const-string v0, "historyLimit"

    const/16 v3, 0x8

    invoke-virtual {v11, v0, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 580
    const-string v0, "guestConsumptionInferred"

    const/4 v3, 0x0

    invoke-virtual {v11, v0, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 581
    nop

    .end local v11    # "$this$observations_u24lambda_u2454_u24lambda_u2452\\4":Landroid/os/Bundle;
    .end local v12    # "$i$a$-apply-EngineService$observations$1$4\\4\\571\\1":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 571
    invoke-virtual {v2, v9, v10}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 583
    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->touchTimestampOrder:Lorg/lighttouch/android/TouchTimestampOrder;

    invoke-virtual {v0}, Lorg/lighttouch/android/TouchTimestampOrder;->getSnapshot()Lorg/lighttouch/android/TouchTimestampSnapshot;

    move-result-object v0

    .line 584
    .local v0, "touchClock\\1":Lorg/lighttouch/android/TouchTimestampSnapshot;
    const-string v3, "touchTimestampSelection"

    new-instance v9, Landroid/os/Bundle;

    invoke-direct {v9}, Landroid/os/Bundle;-><init>()V

    move-object v10, v9

    .local v10, "$this$observations_u24lambda_u2454_u24lambda_u2453\\8":Landroid/os/Bundle;
    const/4 v11, 0x0

    .line 585
    .local v11, "$i$a$-apply-EngineService$observations$1$5\\8\\584\\1":I
    const-string v12, "rawUptimeNs"

    invoke-virtual {v0}, Lorg/lighttouch/android/TouchTimestampSnapshot;->getRawUptimeNs()J

    move-result-wide v13

    invoke-virtual {v10, v12, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v12, "orderedUptimeNs"

    invoke-virtual {v0}, Lorg/lighttouch/android/TouchTimestampSnapshot;->getOrderedUptimeNs()J

    move-result-wide v13

    invoke-virtual {v10, v12, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 586
    const-string v12, "selections"

    invoke-virtual {v0}, Lorg/lighttouch/android/TouchTimestampSnapshot;->getSelections()J

    move-result-wide v13

    invoke-virtual {v10, v12, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v12, "adjustedSelections"

    invoke-virtual {v0}, Lorg/lighttouch/android/TouchTimestampSnapshot;->getAdjustedSelections()J

    move-result-wide v13

    invoke-virtual {v10, v12, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 587
    const-string v12, "rejectedSelections"

    invoke-virtual {v0}, Lorg/lighttouch/android/TouchTimestampSnapshot;->getRejectedSelections()J

    move-result-wide v13

    invoke-virtual {v10, v12, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v12, "guestConsumptionInferred"

    const/4 v13, 0x0

    invoke-virtual {v10, v12, v13}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 588
    nop

    .end local v10    # "$this$observations_u24lambda_u2454_u24lambda_u2453\\8":Landroid/os/Bundle;
    .end local v11    # "$i$a$-apply-EngineService$observations$1$5\\8\\584\\1":I
    sget-object v10, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 584
    invoke-virtual {v2, v3, v9}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 589
    nop

    .line 535
    .end local v0    # "touchClock\\1":Lorg/lighttouch/android/TouchTimestampSnapshot;
    .end local v2    # "$this$observations_u24lambda_u2454\\1":Landroid/os/Bundle;
    .end local v4    # "values\\1":[J
    .end local v5    # "keys\\1":Ljava/util/List;
    .end local v6    # "diagnosticAvailable\\1":Z
    .end local v7    # "cancellations\\1":Lorg/lighttouch/android/DisplayCancellationSnapshot;
    .end local v8    # "agentAvailable\\1":Z
    .end local v25    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    nop

    .line 589
    return-object v23

    .line 560
    .restart local v2    # "$this$observations_u24lambda_u2454\\1":Landroid/os/Bundle;
    .restart local v3    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    .restart local v4    # "values\\1":[J
    .restart local v5    # "keys\\1":Ljava/util/List;
    .restart local v6    # "diagnosticAvailable\\1":Z
    .restart local v8    # "agentAvailable\\1":Z
    :catchall_0
    move-exception v0

    move/from16 v25, v3

    .end local v3    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    .restart local v25    # "$i$a$-apply-EngineService$observations$1\\1\\535\\0":I
    monitor-exit v12

    throw v0
.end method

.method private static final onCreate$lambda$32(Lorg/lighttouch/android/EngineService;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 448
    nop

    .line 449
    :try_start_0
    iget-boolean v0, p0, Lorg/lighttouch/android/EngineService;->detailedTiming:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingError:Ljava/lang/String;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-nez v0, :cond_2

    .line 450
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getProfileCapture()Lorg/lighttouch/android/ProfileCapture;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v1}, Lorg/lighttouch/android/Native;->status()[Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lkotlin/collections/ArraysKt;->firstOrNull([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_1

    const-string v1, "stopped"

    :cond_1
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/ProfileCapture;->startAutomatic(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingError:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    .line 452
    :catch_0
    move-exception v0

    .line 453
    :cond_2
    :goto_1
    return-void
.end method

.method private static final onCreate$lambda$44(Lorg/lighttouch/android/EngineService;)V
    .locals 24
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 458
    move-object/from16 v1, p0

    const/16 v0, 0x2000

    new-array v2, v0, [S

    .line 459
    .local v2, "samples":[S
    const/4 v0, 0x0

    .local v0, "format":Ljava/lang/Object;
    const-string v0, ""

    move-object v3, v0

    .line 460
    .end local v0    # "format":Ljava/lang/Object;
    .local v3, "format":Ljava/lang/Object;
    :goto_0
    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_17

    .line 463
    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v0}, Lorg/lighttouch/android/AudioPacketEpoch;->capture()J

    move-result-wide v5

    .line 464
    .local v5, "packetEpoch":J
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/Native;->audio([S)I

    move-result v7

    .line 465
    .local v7, "count":I
    const-wide/16 v8, 0x64

    const-wide/16 v10, 0x1

    if-gez v7, :cond_0

    .line 466
    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v4

    .line 679
    const/4 v0, 0x0

    .line 466
    .local v0, "$i$a$-synchronized-EngineService$onCreate$2$1\\1\\466\\0":I
    :try_start_0
    iget-object v12, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v12}, Lorg/lighttouch/android/AudioObservations;->getNativePullFailures()J

    move-result-wide v13

    add-long/2addr v13, v10

    invoke-virtual {v12, v13, v14}, Lorg/lighttouch/android/AudioObservations;->setNativePullFailures(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v0    # "$i$a$-synchronized-EngineService$onCreate$2$1\\1\\466\\0":I
    monitor-exit v4

    .line 467
    neg-int v0, v7

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Guest audio could not be read (status "

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, "). Stop and restart the guest."

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lorg/lighttouch/android/EngineService;->audioError:Ljava/lang/String;

    .line 468
    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V

    .line 469
    goto :goto_0

    .line 466
    :catchall_0
    move-exception v0

    monitor-exit v4

    throw v0

    .line 471
    :cond_0
    const/4 v0, 0x0

    if-lez v7, :cond_1

    iget-object v12, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v12

    .line 679
    const/4 v13, 0x0

    .line 471
    .local v13, "$i$a$-synchronized-EngineService$onCreate$2$2\\2\\471\\0":I
    :try_start_1
    iget-object v14, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v14, v2, v0, v7, v0}, Lorg/lighttouch/android/AudioObservations;->samples([SIIZ)V

    .end local v13    # "$i$a$-synchronized-EngineService$onCreate$2$2\\2\\471\\0":I
    sget-object v13, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit v12

    goto :goto_1

    :catchall_1
    move-exception v0

    monitor-exit v12

    throw v0

    .line 472
    :cond_1
    :goto_1
    if-lez v7, :cond_15

    iget-boolean v12, v1, Lorg/lighttouch/android/EngineService;->audioOn:Z

    if-eqz v12, :cond_15

    iget-boolean v12, v1, Lorg/lighttouch/android/EngineService;->focusPaused:Z

    if-nez v12, :cond_15

    iget-boolean v12, v1, Lorg/lighttouch/android/EngineService;->userPaused:Z

    if-nez v12, :cond_15

    iget-object v12, v1, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v12}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v12

    if-nez v12, :cond_15

    .line 473
    nop

    .line 474
    :try_start_2
    sget-object v12, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v12}, Lorg/lighttouch/android/Native;->audioInfo()[I

    move-result-object v12

    move-object v13, v12

    .line 475
    .local v13, "spec":[I
    aget v12, v13, v0

    const/4 v14, 0x1

    if-lez v12, :cond_3

    aget v12, v13, v14

    if-gt v14, v12, :cond_2

    const/4 v15, 0x3

    if-ge v12, v15, :cond_2

    move v12, v14

    goto :goto_2

    :cond_2
    move v12, v0

    :goto_2
    if-eqz v12, :cond_3

    move v12, v14

    goto :goto_3

    :cond_3
    move v12, v0

    :goto_3
    if-eqz v12, :cond_12

    .line 476
    const/16 v20, 0x3f

    const/16 v21, 0x0

    move v12, v14

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v13 .. v21}, Lkotlin/collections/ArraysKt;->joinToString$default([ILjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v14

    .line 477
    .local v14, "next":Ljava/lang/String;
    iget-object v15, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v15
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    const/16 v16, 0x0

    .line 478
    .local v16, "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    move-wide/from16 v17, v8

    :try_start_3
    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v8, v5, v6}, Lorg/lighttouch/android/AudioPacketEpoch;->isCurrent(J)Z

    move-result v8

    if-eqz v8, :cond_11

    iget-boolean v8, v1, Lorg/lighttouch/android/EngineService;->audioOn:Z

    if-eqz v8, :cond_11

    iget-boolean v8, v1, Lorg/lighttouch/android/EngineService;->focusPaused:Z

    if-nez v8, :cond_11

    iget-boolean v8, v1, Lorg/lighttouch/android/EngineService;->userPaused:Z

    if-nez v8, :cond_11

    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v8

    if-eqz v8, :cond_4

    move-wide/from16 v19, v10

    move-object v11, v13

    goto/16 :goto_c

    .line 482
    :cond_4
    invoke-static {v14, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_6

    if-nez v8, :cond_b

    .line 483
    :try_start_4
    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    if-eqz v8, :cond_5

    .line 679
    .local v8, "it\\5":Landroid/media/AudioTrack;
    const/4 v9, 0x0

    .line 483
    .local v9, "$i$a$-let-EngineService$onCreate$2$4$1\\5\\483\\4":I
    move-wide/from16 v19, v10

    :try_start_5
    iget-object v10, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v8}, Landroid/media/AudioTrack;->getPlaybackHeadPosition()I

    move-result v11

    invoke-virtual {v8}, Landroid/media/AudioTrack;->getUnderrunCount()I

    move-result v4

    invoke-virtual {v10, v11, v4}, Lorg/lighttouch/android/AudioObservations;->observeTrack(II)V

    invoke-virtual {v8}, Landroid/media/AudioTrack;->release()V

    .end local v8    # "it\\5":Landroid/media/AudioTrack;
    .end local v9    # "$i$a$-let-EngineService$onCreate$2$4$1\\5\\483\\4":I
    goto :goto_4

    .line 477
    .end local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    :catchall_2
    move-exception v0

    goto/16 :goto_8

    .line 483
    .restart local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    :cond_5
    move-wide/from16 v19, v10

    .line 484
    :goto_4
    aget v4, v13, v12

    if-ne v4, v12, :cond_6

    const/4 v4, 0x4

    goto :goto_5

    :cond_6
    const/16 v4, 0xc

    .line 485
    .local v4, "mask\\4":I
    :goto_5
    aget v8, v13, v0

    const/4 v9, 0x2

    invoke-static {v8, v4, v9}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v8

    .line 486
    .local v8, "minimum\\4":I
    if-lez v8, :cond_7

    move v10, v12

    goto :goto_6

    :cond_7
    move v10, v0

    :goto_6
    if-eqz v10, :cond_a

    .line 487
    new-instance v10, Landroid/media/AudioTrack$Builder;

    invoke-direct {v10}, Landroid/media/AudioTrack$Builder;-><init>()V

    invoke-direct {v1}, Lorg/lighttouch/android/EngineService;->audioAttributes()Landroid/media/AudioAttributes;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/media/AudioTrack$Builder;->setAudioAttributes(Landroid/media/AudioAttributes;)Landroid/media/AudioTrack$Builder;

    move-result-object v10

    .line 488
    new-instance v11, Landroid/media/AudioFormat$Builder;

    invoke-direct {v11}, Landroid/media/AudioFormat$Builder;-><init>()V

    move/from16 v22, v0

    aget v0, v13, v22

    invoke-virtual {v11, v0}, Landroid/media/AudioFormat$Builder;->setSampleRate(I)Landroid/media/AudioFormat$Builder;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/media/AudioFormat$Builder;->setChannelMask(I)Landroid/media/AudioFormat$Builder;

    move-result-object v0

    invoke-virtual {v0, v9}, Landroid/media/AudioFormat$Builder;->setEncoding(I)Landroid/media/AudioFormat$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/AudioFormat$Builder;->build()Landroid/media/AudioFormat;

    move-result-object v0

    .line 487
    invoke-virtual {v10, v0}, Landroid/media/AudioTrack$Builder;->setAudioFormat(Landroid/media/AudioFormat;)Landroid/media/AudioTrack$Builder;

    move-result-object v0

    .line 489
    mul-int/lit8 v9, v7, 0x4

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-virtual {v0, v9}, Landroid/media/AudioTrack$Builder;->setBufferSizeInBytes(I)Landroid/media/AudioTrack$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/AudioTrack$Builder;->build()Landroid/media/AudioTrack;

    move-result-object v0

    .line 487
    iput-object v0, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    .line 490
    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v0}, Landroid/media/AudioTrack;->getState()I

    move-result v0

    if-ne v0, v12, :cond_8

    move v0, v12

    goto :goto_7

    :cond_8
    move/from16 v0, v22

    :goto_7
    if-eqz v0, :cond_9

    .line 491
    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    aget v9, v13, v22

    aget v10, v13, v12

    invoke-virtual {v0, v9, v10}, Lorg/lighttouch/android/AudioObservations;->trackCreated(II)V

    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    move-object v3, v14

    goto :goto_9

    .line 679
    :cond_9
    const/4 v0, 0x0

    .line 490
    .local v0, "$i$a$-check-EngineService$onCreate$2$4$3\\7\\490\\4":I
    const-string v9, "Audio output did not initialize"

    .end local v0    # "$i$a$-check-EngineService$onCreate$2$4$3\\7\\490\\4":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v0, v9}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v2    # "samples":[S
    .end local v3    # "format":Ljava/lang/Object;
    .end local v5    # "packetEpoch":J
    .end local v7    # "count":I
    .end local v13    # "spec":[I
    .end local v14    # "next":Ljava/lang/String;
    .end local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    throw v0

    .line 679
    .restart local v2    # "samples":[S
    .restart local v3    # "format":Ljava/lang/Object;
    .restart local v5    # "packetEpoch":J
    .restart local v7    # "count":I
    .restart local v13    # "spec":[I
    .restart local v14    # "next":Ljava/lang/String;
    .restart local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    :cond_a
    const/4 v0, 0x0

    .line 486
    .local v0, "$i$a$-require-EngineService$onCreate$2$4$2\\6\\486\\4":I
    const-string v9, "Guest audio format unavailable"

    .end local v0    # "$i$a$-require-EngineService$onCreate$2$4$2\\6\\486\\4":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v2    # "samples":[S
    .end local v3    # "format":Ljava/lang/Object;
    .end local v5    # "packetEpoch":J
    .end local v7    # "count":I
    .end local v13    # "spec":[I
    .end local v14    # "next":Ljava/lang/String;
    .end local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 477
    .end local v4    # "mask\\4":I
    .end local v8    # "minimum\\4":I
    .end local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    .restart local v2    # "samples":[S
    .restart local v3    # "format":Ljava/lang/Object;
    .restart local v5    # "packetEpoch":J
    .restart local v7    # "count":I
    .restart local v13    # "spec":[I
    .restart local v14    # "next":Ljava/lang/String;
    .restart local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    :catchall_3
    move-exception v0

    move-wide/from16 v19, v10

    :goto_8
    move-object v11, v13

    goto/16 :goto_f

    .line 482
    .restart local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    :cond_b
    move/from16 v22, v0

    move-wide/from16 v19, v10

    .line 493
    :goto_9
    const/4 v0, 0x0

    .line 496
    .local v0, "offset\\4":I
    :goto_a
    if-ge v0, v7, :cond_f

    :try_start_6
    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v4, v5, v6}, Lorg/lighttouch/android/AudioPacketEpoch;->isCurrent(J)Z

    move-result v4

    if-eqz v4, :cond_f

    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    if-eqz v4, :cond_f

    iget-boolean v4, v1, Lorg/lighttouch/android/EngineService;->audioOn:Z

    if-eqz v4, :cond_f

    iget-boolean v4, v1, Lorg/lighttouch/android/EngineService;->focusPaused:Z

    if-nez v4, :cond_f

    iget-boolean v4, v1, Lorg/lighttouch/android/EngineService;->userPaused:Z

    if-nez v4, :cond_f

    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    if-nez v4, :cond_f

    .line 497
    sub-int v4, v7, v0

    .line 498
    .local v4, "requested\\4":I
    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    invoke-static {v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move/from16 v9, v22

    invoke-virtual {v8, v2, v0, v4, v9}, Landroid/media/AudioTrack;->write([SIII)I

    move-result v8

    .line 499
    .local v8, "written\\4":I
    iget-object v10, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v10}, Lorg/lighttouch/android/AudioObservations;->getWriteCalls()J

    move-result-wide v22
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    move-object v11, v13

    .end local v13    # "spec":[I
    .local v11, "spec":[I
    add-long v12, v22, v19

    :try_start_7
    invoke-virtual {v10, v12, v13}, Lorg/lighttouch/android/AudioObservations;->setWriteCalls(J)V

    iget-object v10, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v10, v8}, Lorg/lighttouch/android/AudioObservations;->setLastWriteCode(I)V

    .line 500
    if-gtz v8, :cond_d

    .line 501
    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v9}, Lorg/lighttouch/android/AudioObservations;->getWriteFailures()J

    move-result-wide v12

    add-long v12, v12, v19

    invoke-virtual {v9, v12, v13}, Lorg/lighttouch/android/AudioObservations;->setWriteFailures(J)V

    .line 502
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Guest audio output stopped (code "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "). Stop and restart if it does not recover."

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    iput-object v9, v1, Lorg/lighttouch/android/EngineService;->audioError:Ljava/lang/String;

    .line 503
    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v9, :cond_c

    invoke-virtual {v9}, Landroid/media/AudioTrack;->release()V

    :cond_c
    const/4 v9, 0x0

    iput-object v9, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    const-string v9, ""

    move-object v3, v9

    .line 504
    goto :goto_b

    .line 506
    :cond_d
    if-ge v8, v4, :cond_e

    iget-object v10, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v10}, Lorg/lighttouch/android/AudioObservations;->getShortWrites()J

    move-result-wide v12

    add-long v12, v12, v19

    invoke-virtual {v10, v12, v13}, Lorg/lighttouch/android/AudioObservations;->setShortWrites(J)V

    .line 507
    :cond_e
    iget-object v10, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    const/4 v12, 0x1

    invoke-virtual {v10, v2, v0, v8, v12}, Lorg/lighttouch/android/AudioObservations;->samples([SIIZ)V

    add-int/2addr v0, v8

    const-string v10, ""

    iput-object v10, v1, Lorg/lighttouch/android/EngineService;->audioError:Ljava/lang/String;

    move/from16 v22, v9

    move-object v13, v11

    .end local v4    # "requested\\4":I
    .end local v8    # "written\\4":I
    goto/16 :goto_a

    .line 477
    .end local v0    # "offset\\4":I
    .end local v11    # "spec":[I
    .end local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    .restart local v13    # "spec":[I
    :catchall_4
    move-exception v0

    goto :goto_e

    .line 496
    .restart local v0    # "offset\\4":I
    .restart local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    :cond_f
    move-object v11, v13

    .line 509
    .end local v13    # "spec":[I
    .restart local v11    # "spec":[I
    :goto_b
    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v4, :cond_10

    .line 679
    .local v4, "it\\8":Landroid/media/AudioTrack;
    const/4 v8, 0x0

    .line 509
    .local v8, "$i$a$-let-EngineService$onCreate$2$4$4\\8\\509\\4":I
    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v4}, Landroid/media/AudioTrack;->getPlaybackHeadPosition()I

    move-result v10

    invoke-virtual {v4}, Landroid/media/AudioTrack;->getUnderrunCount()I

    move-result v12

    invoke-virtual {v9, v10, v12}, Lorg/lighttouch/android/AudioObservations;->observeTrack(II)V

    .line 510
    .end local v4    # "it\\8":Landroid/media/AudioTrack;
    .end local v8    # "$i$a$-let-EngineService$onCreate$2$4$4\\8\\509\\4":I
    :cond_10
    goto :goto_d

    .line 478
    .end local v0    # "offset\\4":I
    .end local v11    # "spec":[I
    .restart local v13    # "spec":[I
    :cond_11
    move-wide/from16 v19, v10

    move-object v11, v13

    .line 479
    .end local v13    # "spec":[I
    .restart local v11    # "spec":[I
    :goto_c
    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v0}, Lorg/lighttouch/android/AudioObservations;->getDiscardedReadPackets()J

    move-result-wide v8

    add-long v8, v8, v19

    invoke-virtual {v0, v8, v9}, Lorg/lighttouch/android/AudioObservations;->setDiscardedReadPackets(J)V

    iget-object v0, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v0}, Lorg/lighttouch/android/AudioObservations;->getDiscardedReadSamples()J

    move-result-wide v8

    int-to-long v12, v7

    add-long/2addr v8, v12

    invoke-virtual {v0, v8, v9}, Lorg/lighttouch/android/AudioObservations;->setDiscardedReadSamples(J)V

    .line 480
    nop

    .line 510
    .end local v16    # "$i$a$-synchronized-EngineService$onCreate$2$4\\4\\477\\0":I
    :goto_d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .line 477
    :try_start_8
    monitor-exit v15

    goto/16 :goto_0

    :catchall_5
    move-exception v0

    goto :goto_f

    .end local v11    # "spec":[I
    .restart local v13    # "spec":[I
    :catchall_6
    move-exception v0

    move-wide/from16 v19, v10

    :goto_e
    move-object v11, v13

    .end local v13    # "spec":[I
    .restart local v11    # "spec":[I
    :goto_f
    monitor-exit v15

    .end local v2    # "samples":[S
    .end local v3    # "format":Ljava/lang/Object;
    .end local v5    # "packetEpoch":J
    .end local v7    # "count":I
    .end local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    throw v0

    .line 679
    .end local v11    # "spec":[I
    .end local v14    # "next":Ljava/lang/String;
    .restart local v2    # "samples":[S
    .restart local v3    # "format":Ljava/lang/Object;
    .restart local v5    # "packetEpoch":J
    .restart local v7    # "count":I
    .restart local v13    # "spec":[I
    .restart local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    :cond_12
    move-wide/from16 v17, v8

    move-wide/from16 v19, v10

    move-object v11, v13

    .end local v13    # "spec":[I
    .restart local v11    # "spec":[I
    const/4 v0, 0x0

    .line 475
    .local v0, "$i$a$-require-EngineService$onCreate$2$3\\3\\475\\0":I
    const-string v4, "Invalid guest audio format"

    .end local v0    # "$i$a$-require-EngineService$onCreate$2$3\\3\\475\\0":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v2    # "samples":[S
    .end local v3    # "format":Ljava/lang/Object;
    .end local v5    # "packetEpoch":J
    .end local v7    # "count":I
    .end local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    throw v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 511
    .end local v11    # "spec":[I
    .restart local v2    # "samples":[S
    .restart local v3    # "format":Ljava/lang/Object;
    .restart local v5    # "packetEpoch":J
    .restart local v7    # "count":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/EngineService;
    :catch_0
    move-exception v0

    goto :goto_10

    :catch_1
    move-exception v0

    move-wide/from16 v17, v8

    move-wide/from16 v19, v10

    :goto_10
    move-object v4, v0

    .line 512
    .local v4, "failure":Ljava/lang/Exception;
    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v8

    .line 679
    const/4 v0, 0x0

    .line 512
    .local v0, "$i$a$-synchronized-EngineService$onCreate$2$5\\9\\512\\0":I
    :try_start_9
    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v9}, Lorg/lighttouch/android/AudioObservations;->getWriteFailures()J

    move-result-wide v10

    add-long v10, v10, v19

    invoke-virtual {v9, v10, v11}, Lorg/lighttouch/android/AudioObservations;->setWriteFailures(J)V

    iget-object v9, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v9, :cond_13

    invoke-virtual {v9}, Landroid/media/AudioTrack;->release()V

    :cond_13
    const/4 v9, 0x0

    iput-object v9, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    const-string v9, ""

    move-object v3, v9

    .end local v0    # "$i$a$-synchronized-EngineService$onCreate$2$5\\9\\512\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_7

    monitor-exit v8

    .line 513
    invoke-virtual {v4}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_14

    const-string v0, "\u672a\u77e5\u9519\u8bef"

    :cond_14
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Guest audio output failed: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, ". Stop and restart the guest."

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lorg/lighttouch/android/EngineService;->audioError:Ljava/lang/String;

    .line 514
    invoke-static/range {v17 .. v18}, Ljava/lang/Thread;->sleep(J)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .end local v4    # "failure":Ljava/lang/Exception;
    goto/16 :goto_0

    .line 512
    .restart local v4    # "failure":Ljava/lang/Exception;
    :catchall_7
    move-exception v0

    monitor-exit v8

    throw v0

    .line 472
    .end local v4    # "failure":Ljava/lang/Exception;
    :cond_15
    move-wide/from16 v19, v10

    .line 517
    if-lez v7, :cond_16

    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v4

    const/4 v0, 0x0

    .line 518
    .local v0, "$i$a$-synchronized-EngineService$onCreate$2$6\\10\\517\\0":I
    :try_start_a
    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v8}, Lorg/lighttouch/android/AudioObservations;->getDiscardedReadPackets()J

    move-result-wide v9

    add-long v9, v9, v19

    invoke-virtual {v8, v9, v10}, Lorg/lighttouch/android/AudioObservations;->setDiscardedReadPackets(J)V

    iget-object v8, v1, Lorg/lighttouch/android/EngineService;->audioObservations:Lorg/lighttouch/android/AudioObservations;

    invoke-virtual {v8}, Lorg/lighttouch/android/AudioObservations;->getDiscardedReadSamples()J

    move-result-wide v9

    int-to-long v11, v7

    add-long/2addr v9, v11

    invoke-virtual {v8, v9, v10}, Lorg/lighttouch/android/AudioObservations;->setDiscardedReadSamples(J)V

    .line 519
    nop

    .end local v0    # "$i$a$-synchronized-EngineService$onCreate$2$6\\10\\517\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_8

    .line 517
    monitor-exit v4

    goto :goto_11

    :catchall_8
    move-exception v0

    monitor-exit v4

    throw v0

    .line 520
    :cond_16
    :goto_11
    const-wide/16 v8, 0xa

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V

    .end local v5    # "packetEpoch":J
    .end local v7    # "count":I
    goto/16 :goto_0

    .line 523
    :cond_17
    iget-object v4, v1, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v4

    .line 679
    const/4 v0, 0x0

    .line 523
    .local v0, "$i$a$-synchronized-EngineService$onCreate$2$7\\11\\523\\0":I
    :try_start_b
    iget-object v5, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v5, :cond_18

    invoke-virtual {v5}, Landroid/media/AudioTrack;->release()V

    :cond_18
    const/4 v9, 0x0

    iput-object v9, v1, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    .end local v0    # "$i$a$-synchronized-EngineService$onCreate$2$7\\11\\523\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_9

    monitor-exit v4

    .line 524
    return-void

    .line 523
    :catchall_9
    move-exception v0

    monitor-exit v4

    throw v0
.end method

.method private final pauseAudio()V
    .locals 3

    .line 526
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v0

    const/4 v1, 0x0

    .line 527
    .local v1, "$i$a$-synchronized-EngineService$pauseAudio$1\\1\\526\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v2}, Lorg/lighttouch/android/AudioPacketEpoch;->pause()V

    .line 528
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->flushAudioLocked()V

    .line 529
    nop

    .end local v1    # "$i$a$-synchronized-EngineService$pauseAudio$1\\1\\526\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 526
    monitor-exit v0

    .line 529
    return-void

    .line 526
    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private static final performanceSampler_delegate$lambda$6(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerPerformanceSampler;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 45
    new-instance v0, Lorg/lighttouch/android/WorkerPerformanceSampler;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lorg/lighttouch/android/WorkerPerformanceSampler;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method private final persistObservations(Ljava/lang/String;)V
    .locals 6
    .param p1, "reason"    # Ljava/lang/String;

    .line 346
    nop

    .line 347
    :try_start_0
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->binder:Lorg/lighttouch/android/EngineService$binder$1;

    invoke-virtual {v0}, Lorg/lighttouch/android/EngineService$binder$1;->status()Landroid/os/Bundle;

    move-result-object v0

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->persistObservations$encode(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "reason"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "hostElapsedMs"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v0

    .line 348
    const-string v1, "audiblePlaybackVerified"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "visibleGuestVerified"

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    .line 347
    nop

    .line 349
    .local v0, "receipt":Lorg/json/JSONObject;
    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "worker-observations-"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ".json"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v2, 0x2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "toString(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v1, v3, v4, v2, v4}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "receipt":Lorg/json/JSONObject;
    goto :goto_0

    .line 350
    :catch_0
    move-exception v0

    .line 351
    :goto_0
    return-void
.end method

.method private static final persistObservations$encode(Landroid/os/Bundle;)Lorg/json/JSONObject;
    .locals 7
    .param p0, "bundle"    # Landroid/os/Bundle;

    .line 343
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    move-object v1, v0

    .local v1, "$this$persistObservations_u24encode_u24lambda_u2411\\1":Lorg/json/JSONObject;
    const/4 v2, 0x0

    .line 344
    .local v2, "$i$a$-apply-EngineService$persistObservations$encode$1\\1\\343\\0":I
    invoke-virtual {p0}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "key\\1":Ljava/lang/String;
    invoke-virtual {p0, v4}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    .local v5, "value\\1":Ljava/lang/Object;
    instance-of v6, v5, Landroid/os/Bundle;

    if-eqz v6, :cond_0

    move-object v6, v5

    check-cast v6, Landroid/os/Bundle;

    invoke-static {v6}, Lorg/lighttouch/android/EngineService;->persistObservations$encode(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object v6

    invoke-virtual {v1, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_0

    :cond_0
    invoke-virtual {v1, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_0

    .line 345
    .end local v4    # "key\\1":Ljava/lang/String;
    .end local v5    # "value\\1":Ljava/lang/Object;
    :cond_1
    nop

    .line 343
    .end local v1    # "$this$persistObservations_u24encode_u24lambda_u2411\\1":Lorg/json/JSONObject;
    .end local v2    # "$i$a$-apply-EngineService$persistObservations$encode$1\\1\\343\\0":I
    nop

    .line 345
    return-object v0
.end method

.method private final persistStopError(Ljava/lang/String;)V
    .locals 7
    .param p1, "message"    # Ljava/lang/String;

    .line 391
    const/4 v0, 0x2

    const/4 v1, 0x0

    :try_start_0
    new-instance v2, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v3

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "worker-stop-error-"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ".txt"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v2, p1, v1, v0, v1}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v2

    .line 392
    :goto_0
    :try_start_1
    new-instance v2, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "worker-stop-error.txt"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v2, p1, v1, v0, v1}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    .line 393
    :goto_1
    return-void
.end method

.method private final persistTerminalReceipt(Lorg/lighttouch/android/ShutdownReceipt;)V
    .locals 8
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 413
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "worker-shutdown-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".json"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 414
    .local v0, "target":Ljava/io/File;
    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, ".worker-shutdown-"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ".pending"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 415
    .local v1, "temporary":Ljava/io/File;
    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v2, Ljava/io/Closeable;

    :try_start_0
    move-object v3, v2

    check-cast v3, Ljava/io/FileOutputStream;

    .local v3, "output\\1":Ljava/io/FileOutputStream;
    const/4 v4, 0x0

    .line 416
    .local v4, "$i$a$-use-EngineService$persistTerminalReceipt$1\\1\\415\\0":I
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x180

    invoke-static {v5, v6}, Landroid/system/Os;->chmod(Ljava/lang/String;I)V

    .line 417
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->shutdownRecord(Lorg/lighttouch/android/ShutdownReceipt;)Lorg/json/JSONObject;

    move-result-object v5

    const-string v6, "receiptPersistenceBestEffort"

    const/4 v7, 0x0

    invoke-virtual {v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v6, 0x2

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v5

    const-string v6, "toString(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v6, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v5, v6}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    const-string v6, "getBytes(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/io/FileOutputStream;->write([B)V

    .line 418
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v5

    invoke-virtual {v5}, Ljava/io/FileDescriptor;->sync()V

    .line 419
    nop

    .end local v3    # "output\\1":Ljava/io/FileOutputStream;
    .end local v4    # "$i$a$-use-EngineService$persistTerminalReceipt$1\\1\\415\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 415
    const/4 v3, 0x0

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 420
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/system/Os;->rename(Ljava/lang/String;Ljava/lang/String;)V

    .line 421
    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    .line 422
    sget v3, Landroid/system/OsConstants;->O_RDONLY:I

    sget v4, Landroid/system/OsConstants;->O_CLOEXEC:I

    or-int/2addr v3, v4

    .line 421
    invoke-static {v2, v3, v7}, Landroid/system/Os;->open(Ljava/lang/String;II)Ljava/io/FileDescriptor;

    move-result-object v2

    .line 423
    .local v2, "directory":Ljava/io/FileDescriptor;
    :try_start_1
    invoke-static {v2}, Landroid/system/Os;->fsync(Ljava/io/FileDescriptor;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-static {v2}, Landroid/system/Os;->close(Ljava/io/FileDescriptor;)V

    .line 424
    return-void

    .line 423
    :catchall_0
    move-exception v3

    invoke-static {v2}, Landroid/system/Os;->close(Ljava/io/FileDescriptor;)V

    throw v3

    .line 415
    .end local v2    # "directory":Ljava/io/FileDescriptor;
    :catchall_1
    move-exception v3

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/EngineService;
    .end local p1    # "receipt":Lorg/lighttouch/android/ShutdownReceipt;
    :try_start_2
    throw v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/EngineService;
    .restart local p1    # "receipt":Lorg/lighttouch/android/ShutdownReceipt;
    :catchall_2
    move-exception v4

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v4
.end method

.method private final playAudio()V
    .locals 3

    .line 534
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v0

    .line 679
    const/4 v1, 0x0

    .line 534
    .local v1, "$i$a$-synchronized-EngineService$playAudio$1\\1\\534\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/media/AudioTrack;->play()V

    :cond_0
    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v2}, Lorg/lighttouch/android/AudioPacketEpoch;->resume()V

    .end local v1    # "$i$a$-synchronized-EngineService$playAudio$1\\1\\534\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method private static final profileCapture_delegate$lambda$5(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 44
    new-instance v0, Lorg/lighttouch/android/ProfileCapture;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lorg/lighttouch/android/EngineService$profileCapture$2$1;

    invoke-direct {v2, p0}, Lorg/lighttouch/android/EngineService$profileCapture$2$1;-><init>(Ljava/lang/Object;)V

    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-direct {v0, v1, v2}, Lorg/lighttouch/android/ProfileCapture;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V

    return-object v0
.end method

.method private final shutdownMessage(Lorg/lighttouch/android/ShutdownReceipt;)Ljava/lang/String;
    .locals 3
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 394
    nop

    .line 395
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getReason()Ljava/lang/String;

    move-result-object v0

    const-string v1, "deadline-unconfirmed"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getProgress()Lorg/lighttouch/android/ShutdownProgress;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownProgress;->getError()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Guest shutdown was not confirmed within 35 seconds; worker disposed and writable state retained. "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 396
    :cond_0
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getTerminalState()Ljava/lang/String;

    move-result-object v0

    const-string v1, "failed"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getProgress()Lorg/lighttouch/android/ShutdownProgress;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownProgress;->getError()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Guest worker reported failure; writable state retained: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 397
    :cond_1
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getCleanConfirmed()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getProgress()Lorg/lighttouch/android/ShutdownProgress;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownProgress;->getError()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Native terminal shutdown was not explicitly confirmed clean; writable state and diagnostics retained. "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 398
    :cond_2
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getProgress()Lorg/lighttouch/android/ShutdownProgress;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownProgress;->getError()Ljava/lang/String;

    move-result-object v0

    .line 399
    :goto_0
    const/16 v1, 0x1000

    invoke-static {v0, v1}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private final shutdownProgressBundle(Lorg/lighttouch/android/ShutdownDebugProgress;)Landroid/os/Bundle;
    .locals 16
    .param p1, "snapshot"    # Lorg/lighttouch/android/ShutdownDebugProgress;

    .line 354
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 361
    .local v0, "observedAt":J
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    move-object v3, v2

    .local v3, "$this$shutdownProgressBundle_u24lambda_u2428\\1":Landroid/os/Bundle;
    const/4 v4, 0x0

    .line 362
    .local v4, "$i$a$-apply-EngineService$shutdownProgressBundle$1\\1\\361\\0":I
    const-string v5, "workerPid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v6

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v5, "workerUid"

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v6

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 363
    const-string v5, "clock"

    const-string v6, "android.SystemClock.elapsedRealtime/BOOTTIME"

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 364
    const-string v5, "observedAtHostMs"

    invoke-virtual {v3, v5, v0, v1}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v5, "revision"

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getRevision()J

    move-result-wide v6

    invoke-virtual {v3, v5, v6, v7}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 365
    const-string v5, "cachedJavaProgressOnly"

    const/4 v6, 0x1

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v5, "shutdownConfirmationInferred"

    const/4 v7, 0x0

    invoke-virtual {v3, v5, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 366
    const-string v5, "diagnosticPublicationBestEffort"

    invoke-virtual {v3, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 367
    const-string v5, "terminalReceiptAuthority"

    invoke-virtual {v3, v5, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v5, "requested"

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getRequested()Z

    move-result v8

    invoke-virtual {v3, v5, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 368
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getUpdatedAtMs()Ljava/lang/Long;

    move-result-object v5

    const-wide/16 v8, 0x0

    if-eqz v5, :cond_0

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v10

    .line 679
    .local v10, "it\\2":J
    const/4 v5, 0x0

    .line 368
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$1$1\\2\\368\\1":I
    const-string v12, "snapshotUpdatedAtHostMs"

    invoke-virtual {v3, v12, v10, v11}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    sub-long v12, v0, v10

    invoke-static {v12, v13, v8, v9}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v12

    const-string v14, "snapshotAgeMs"

    invoke-virtual {v3, v14, v12, v13}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 369
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$1$1\\2\\368\\1":I
    .end local v10    # "it\\2":J
    :cond_0
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getAcceptedAtMs()Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_1

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v10

    .line 679
    .local v10, "it\\3":J
    const/4 v5, 0x0

    .line 369
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$1$2\\3\\369\\1":I
    const-string v12, "acceptedAtHostMs"

    invoke-virtual {v3, v12, v10, v11}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 370
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$1$2\\3\\369\\1":I
    .end local v10    # "it\\3":J
    :cond_1
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getDeadlineMs()Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_2

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v10

    .line 679
    .local v10, "it\\4":J
    const/4 v5, 0x0

    .line 370
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$1$3\\4\\370\\1":I
    const-string v12, "deadlineHostMs"

    invoke-virtual {v3, v12, v10, v11}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 371
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$1$3\\4\\370\\1":I
    .end local v10    # "it\\4":J
    :cond_2
    const-string v5, "phase"

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getPhase()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v5, v10}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, "progressError"

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getError()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v5, v10}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 372
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getPhaseEnteredAtMs()Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_3

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v10

    .line 679
    .local v10, "it\\5":J
    const/4 v5, 0x0

    .line 372
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$1$4\\5\\372\\1":I
    const-string v12, "phaseEnteredAtHostMs"

    invoke-virtual {v3, v12, v10, v11}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 373
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$1$4\\5\\372\\1":I
    .end local v10    # "it\\5":J
    :cond_3
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getPhaseLastReturnedAtMs()Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_4

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v10

    .line 679
    .local v10, "it\\6":J
    const/4 v5, 0x0

    .line 373
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$1$5\\6\\373\\1":I
    const-string v12, "phaseLastReturnedAtHostMs"

    invoke-virtual {v3, v12, v10, v11}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 374
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$1$5\\6\\373\\1":I
    .end local v10    # "it\\6":J
    :cond_4
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getStop()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v5

    invoke-static {v5}, Lorg/lighttouch/android/EngineService;->shutdownProgressBundle$call(Lorg/lighttouch/android/ShutdownCallProgress;)Landroid/os/Bundle;

    move-result-object v5

    const-string v10, "stopCall"

    invoke-virtual {v3, v10, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getCancel()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v5

    invoke-static {v5}, Lorg/lighttouch/android/EngineService;->shutdownProgressBundle$call(Lorg/lighttouch/android/ShutdownCallProgress;)Landroid/os/Bundle;

    move-result-object v5

    const-string v10, "cancelCall"

    invoke-virtual {v3, v10, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 375
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getStatus()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v5

    invoke-static {v5}, Lorg/lighttouch/android/EngineService;->shutdownProgressBundle$call(Lorg/lighttouch/android/ShutdownCallProgress;)Landroid/os/Bundle;

    move-result-object v5

    const-string v10, "statusCall"

    invoke-virtual {v3, v10, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getReceipt()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v5

    invoke-static {v5}, Lorg/lighttouch/android/EngineService;->shutdownProgressBundle$call(Lorg/lighttouch/android/ShutdownCallProgress;)Landroid/os/Bundle;

    move-result-object v5

    const-string v10, "receiptCall"

    invoke-virtual {v3, v10, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 376
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getLastReturnedStatus()Lorg/lighttouch/android/ShutdownReturnedStatus;

    move-result-object v5

    if-eqz v5, :cond_5

    move v7, v6

    :cond_5
    const-string v5, "nativeStatusEverReturned"

    invoke-virtual {v3, v5, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 377
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getLastReturnedStatus()Lorg/lighttouch/android/ShutdownReturnedStatus;

    move-result-object v5

    if-eqz v5, :cond_9

    .line 679
    .local v5, "returned\\7":Lorg/lighttouch/android/ShutdownReturnedStatus;
    const/4 v7, 0x0

    .line 377
    .local v7, "$i$a$-let-EngineService$shutdownProgressBundle$1$6\\7\\377\\1":I
    new-instance v10, Landroid/os/Bundle;

    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    move-object v11, v10

    .local v11, "$this$shutdownProgressBundle_u24lambda_u2428_u24lambda_u2425_u24lambda_u2424\\8":Landroid/os/Bundle;
    const/4 v12, 0x0

    .line 378
    .local v12, "$i$a$-apply-EngineService$shutdownProgressBundle$1$6$1\\8\\377\\7":I
    const-string v13, "returnedAtHostMs"

    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getReturnedAtMs()J

    move-result-wide v14

    invoke-virtual {v11, v13, v14, v15}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getReturnedAtMs()J

    move-result-wide v13

    sub-long v13, v0, v13

    invoke-static {v13, v14, v8, v9}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v8

    const-string v13, "ageMs"

    invoke-virtual {v11, v13, v8, v9}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 379
    const-string v8, "pollNumber"

    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getPollNumber()J

    move-result-wide v13

    invoke-virtual {v11, v8, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v8, "state"

    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getState()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v8, v9}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v8, "error"

    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getError()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v11, v8, v9}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 380
    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getNative()Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v8

    invoke-virtual {v8}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getValid()Z

    move-result v8

    const-string v9, "pollSnapshotValid"

    invoke-virtual {v11, v9, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getNative()Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v8

    invoke-virtual {v8}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getConfirmed()Z

    move-result v8

    const-string v9, "guestShutdownConfirmed"

    invoke-virtual {v11, v9, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 381
    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getNative()Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v8

    invoke-virtual {v8}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getDirty()Ljava/lang/Boolean;

    move-result-object v8

    if-eqz v8, :cond_6

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    .line 679
    .local v8, "it\\9":Z
    const/4 v9, 0x0

    .line 381
    .local v9, "$i$a$-let-EngineService$shutdownProgressBundle$1$6$1$1\\9\\381\\8":I
    const-string v13, "dirty"

    invoke-virtual {v11, v13, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 382
    .end local v8    # "it\\9":Z
    .end local v9    # "$i$a$-let-EngineService$shutdownProgressBundle$1$6$1$1\\9\\381\\8":I
    :cond_6
    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getNative()Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v8

    invoke-virtual {v8}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getStorageFailed()Ljava/lang/Boolean;

    move-result-object v8

    if-eqz v8, :cond_7

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    .line 679
    .local v8, "it\\10":Z
    const/4 v9, 0x0

    .line 382
    .local v9, "$i$a$-let-EngineService$shutdownProgressBundle$1$6$1$2\\10\\382\\8":I
    const-string v13, "storageFailed"

    invoke-virtual {v11, v13, v8}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 383
    .end local v8    # "it\\10":Z
    .end local v9    # "$i$a$-let-EngineService$shutdownProgressBundle$1$6$1$2\\10\\382\\8":I
    :cond_7
    invoke-virtual {v5}, Lorg/lighttouch/android/ShutdownReturnedStatus;->getNative()Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v8

    invoke-virtual {v8}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getEngineExit()Ljava/lang/Integer;

    move-result-object v8

    if-eqz v8, :cond_8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    .line 679
    .local v8, "it\\11":I
    const/4 v9, 0x0

    .line 383
    .local v9, "$i$a$-let-EngineService$shutdownProgressBundle$1$6$1$3\\11\\383\\8":I
    const-string v13, "engineExit"

    invoke-virtual {v11, v13, v8}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 384
    .end local v8    # "it\\11":I
    .end local v9    # "$i$a$-let-EngineService$shutdownProgressBundle$1$6$1$3\\11\\383\\8":I
    :cond_8
    const-string v8, "cachedOnlyNotCurrentPoll"

    invoke-virtual {v11, v8, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v8, "flagsRequireValidSnapshot"

    invoke-virtual {v11, v8, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 385
    nop

    .end local v11    # "$this$shutdownProgressBundle_u24lambda_u2428_u24lambda_u2425_u24lambda_u2424\\8":Landroid/os/Bundle;
    .end local v12    # "$i$a$-apply-EngineService$shutdownProgressBundle$1$6$1\\8\\377\\7":I
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 377
    const-string v6, "lastReturnedNativeStatus"

    invoke-virtual {v3, v6, v10}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 385
    nop

    .line 377
    .end local v5    # "returned\\7":Lorg/lighttouch/android/ShutdownReturnedStatus;
    .end local v7    # "$i$a$-let-EngineService$shutdownProgressBundle$1$6\\7\\377\\1":I
    nop

    .line 386
    :cond_9
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getDisposalReason()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_a

    .line 679
    .local v5, "it\\12":Ljava/lang/String;
    const/4 v6, 0x0

    .line 386
    .local v6, "$i$a$-let-EngineService$shutdownProgressBundle$1$7\\12\\386\\1":I
    const-string v7, "disposalReason"

    invoke-virtual {v3, v7, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 387
    .end local v5    # "it\\12":Ljava/lang/String;
    .end local v6    # "$i$a$-let-EngineService$shutdownProgressBundle$1$7\\12\\386\\1":I
    :cond_a
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getDisposalRequestedAtMs()Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_b

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    .line 679
    .local v5, "it\\13":J
    const/4 v7, 0x0

    .line 387
    .local v7, "$i$a$-let-EngineService$shutdownProgressBundle$1$8\\13\\387\\1":I
    const-string v8, "disposalRequestedAtHostMs"

    invoke-virtual {v3, v8, v5, v6}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 388
    .end local v5    # "it\\13":J
    .end local v7    # "$i$a$-let-EngineService$shutdownProgressBundle$1$8\\13\\387\\1":I
    :cond_b
    nop

    .line 361
    .end local v3    # "$this$shutdownProgressBundle_u24lambda_u2428\\1":Landroid/os/Bundle;
    .end local v4    # "$i$a$-apply-EngineService$shutdownProgressBundle$1\\1\\361\\0":I
    return-object v2
.end method

.method private static final shutdownProgressBundle$call(Lorg/lighttouch/android/ShutdownCallProgress;)Landroid/os/Bundle;
    .locals 7
    .param p0, "value"    # Lorg/lighttouch/android/ShutdownCallProgress;

    .line 355
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v1, v0

    .local v1, "$this$shutdownProgressBundle_u24call_u24lambda_u2415\\1":Landroid/os/Bundle;
    const/4 v2, 0x0

    .line 356
    .local v2, "$i$a$-apply-EngineService$shutdownProgressBundle$call$1\\1\\355\\0":I
    const-string v3, "entered"

    invoke-virtual {p0}, Lorg/lighttouch/android/ShutdownCallProgress;->getEntered()J

    move-result-wide v4

    invoke-virtual {v1, v3, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v3, "returned"

    invoke-virtual {p0}, Lorg/lighttouch/android/ShutdownCallProgress;->getReturned()J

    move-result-wide v4

    invoke-virtual {v1, v3, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v3, "threw"

    invoke-virtual {p0}, Lorg/lighttouch/android/ShutdownCallProgress;->getThrew()J

    move-result-wide v4

    invoke-virtual {v1, v3, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 357
    invoke-virtual {p0}, Lorg/lighttouch/android/ShutdownCallProgress;->getLastEnteredAtMs()Ljava/lang/Long;

    move-result-object v3

    if-eqz v3, :cond_0

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    .line 679
    .local v3, "it\\2":J
    const/4 v5, 0x0

    .line 357
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$call$1$1\\2\\357\\1":I
    const-string v6, "lastEnteredAtHostMs"

    invoke-virtual {v1, v6, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 358
    .end local v3    # "it\\2":J
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$call$1$1\\2\\357\\1":I
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/ShutdownCallProgress;->getLastReturnedAtMs()Ljava/lang/Long;

    move-result-object v3

    if-eqz v3, :cond_1

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    .line 679
    .local v3, "it\\3":J
    const/4 v5, 0x0

    .line 358
    .local v5, "$i$a$-let-EngineService$shutdownProgressBundle$call$1$2\\3\\358\\1":I
    const-string v6, "lastReturnedAtHostMs"

    invoke-virtual {v1, v6, v3, v4}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 359
    .end local v3    # "it\\3":J
    .end local v5    # "$i$a$-let-EngineService$shutdownProgressBundle$call$1$2\\3\\358\\1":I
    :cond_1
    invoke-virtual {p0}, Lorg/lighttouch/android/ShutdownCallProgress;->getLastException()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_2

    .line 679
    .local v3, "it\\4":Ljava/lang/String;
    const/4 v4, 0x0

    .line 359
    .local v4, "$i$a$-let-EngineService$shutdownProgressBundle$call$1$3\\4\\359\\1":I
    const-string v5, "lastException"

    invoke-virtual {v1, v5, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 360
    .end local v3    # "it\\4":Ljava/lang/String;
    .end local v4    # "$i$a$-let-EngineService$shutdownProgressBundle$call$1$3\\4\\359\\1":I
    :cond_2
    nop

    .line 355
    .end local v1    # "$this$shutdownProgressBundle_u24call_u24lambda_u2415\\1":Landroid/os/Bundle;
    .end local v2    # "$i$a$-apply-EngineService$shutdownProgressBundle$call$1\\1\\355\\0":I
    nop

    .line 360
    return-object v0
.end method

.method private final shutdownRecord(Lorg/lighttouch/android/ShutdownReceipt;)Lorg/json/JSONObject;
    .locals 6
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 401
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getNativeSnapshot()Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v0

    .line 402
    .local v0, "native":Lorg/lighttouch/android/ShutdownNativeSnapshot;
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "reason"

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getReason()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getProgress()Lorg/lighttouch/android/ShutdownProgress;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/ShutdownProgress;->getStage()Ljava/lang/String;

    move-result-object v2

    const-string v3, "admissionStage"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    .line 403
    const-string v2, "error"

    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->shutdownMessage(Lorg/lighttouch/android/ShutdownReceipt;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getTerminalState()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_0

    sget-object v2, Lorg/json/JSONObject;->NULL:Ljava/lang/Object;

    :cond_0
    const-string v3, "nativeTerminalState"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    .line 404
    const-string v2, "acceptedAtHostMs"

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getAcceptedAtMs()J

    move-result-wide v3

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "deadlineHostMs"

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getDeadlineMs()J

    move-result-wide v3

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "observedAtHostMs"

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getObservedAtMs()J

    move-result-wide v3

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v1

    .line 405
    const-string v2, "workerPid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "workerUid"

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    .line 406
    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getValid()Z

    move-result v4

    if-ne v4, v2, :cond_1

    move v4, v2

    goto :goto_0

    :cond_1
    move v4, v3

    :goto_0
    const-string v5, "nativePollSnapshotValid"

    invoke-virtual {v1, v5, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getConfirmed()Z

    move-result v4

    if-ne v4, v2, :cond_2

    goto :goto_1

    :cond_2
    move v2, v3

    :goto_1
    const-string v4, "guestShutdownConfirmed"

    invoke-virtual {v1, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    .line 407
    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getDirty()Ljava/lang/Boolean;

    move-result-object v2

    if-nez v2, :cond_4

    :cond_3
    sget-object v2, Lorg/json/JSONObject;->NULL:Ljava/lang/Object;

    :cond_4
    const-string v4, "nativeStateDirty"

    invoke-virtual {v1, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getStorageFailed()Ljava/lang/Boolean;

    move-result-object v2

    if-nez v2, :cond_6

    :cond_5
    sget-object v2, Lorg/json/JSONObject;->NULL:Ljava/lang/Object;

    :cond_6
    const-string v4, "nativeStorageFailed"

    invoke-virtual {v1, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    .line 408
    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getEngineExit()Ljava/lang/Integer;

    move-result-object v2

    if-nez v2, :cond_8

    :cond_7
    sget-object v2, Lorg/json/JSONObject;->NULL:Ljava/lang/Object;

    :cond_8
    const-string v4, "nativeEngineExit"

    invoke-virtual {v1, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "cleanShutdownConfirmed"

    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownReceipt;->getCleanConfirmed()Z

    move-result v4

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    .line 409
    const-string v2, "shutdownConfirmationInferred"

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "nativeStateMarkersModified"

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "put(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 402
    return-object v1
.end method

.method private static final shutdownWatchdog$lambda$0()Ljava/lang/String;
    .locals 1

    .line 41
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->stop()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final shutdownWatchdog$lambda$1()Lkotlin/Unit;
    .locals 1

    .line 41
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->cancelInput()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final shutdownWatchdog$lambda$2()[Ljava/lang/String;
    .locals 1

    .line 42
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->status()[Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final shutdownWatchdog$lambda$3(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    const-string v0, "receipt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->disposeAfterShutdown(Lorg/lighttouch/android/ShutdownReceipt;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final shutdownWatchdog$lambda$4(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    const-string v0, "receipt"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    invoke-direct {p0, p1}, Lorg/lighttouch/android/EngineService;->persistTerminalReceipt(Lorg/lighttouch/android/ShutdownReceipt;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final startAudioOutput()V
    .locals 2

    .line 595
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->lifecycleAdmission:Lorg/lighttouch/android/WorkerLifecycleAdmission;

    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda10;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/EngineService;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/WorkerLifecycleAdmission;->run(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 606
    return-void
.end method

.method private static final startAudioOutput$lambda$56(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 596
    iget-boolean v0, p0, Lorg/lighttouch/android/EngineService;->userPaused:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 597
    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->startMicrophone()V

    .line 598
    iget-boolean v0, p0, Lorg/lighttouch/android/EngineService;->audioOn:Z

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->playAudio()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 599
    :cond_1
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    monitor-enter v0

    const/4 v1, 0x0

    .line 602
    .local v1, "$i$a$-synchronized-EngineService$startAudioOutput$1$1\\1\\599\\0":I
    :try_start_0
    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audio:Landroid/media/AudioTrack;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Landroid/media/AudioTrack;->play()V

    .line 603
    :cond_2
    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->audioGuard:Lorg/lighttouch/android/AudioPacketEpoch;

    invoke-virtual {v2}, Lorg/lighttouch/android/AudioPacketEpoch;->resume()V

    .line 604
    const/4 v2, 0x1

    iput-boolean v2, p0, Lorg/lighttouch/android/EngineService;->audioOn:Z

    .line 605
    nop

    .end local v1    # "$i$a$-synchronized-EngineService$startAudioOutput$1$1\\1\\599\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 599
    monitor-exit v0

    .line 606
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 599
    :catchall_0
    move-exception v1

    monitor-exit v0

    throw v1

    .line 596
    :cond_3
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final startMicrophone()V
    .locals 9

    .line 615
    const-string v0, "\u672a\u77e5\u9519\u8bef"

    const-string v1, "Microphone unavailable: "

    iget-boolean v2, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    if-nez v2, :cond_6

    iget-boolean v2, p0, Lorg/lighttouch/android/EngineService;->microphoneWanted:Z

    if-eqz v2, :cond_6

    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_6

    iget-object v2, p0, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_0

    goto/16 :goto_2

    .line 616
    :cond_0
    const-string v2, "android.permission.RECORD_AUDIO"

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/EngineService;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_1

    .line 617
    const-string v0, "Microphone off: LightTouch has no microphone permission. Turn the switch off and on again to grant it."

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    .line 618
    return-void

    .line 620
    :cond_1
    const v2, 0xac44

    .line 621
    .local v2, "rate":I
    const/16 v3, 0x10

    const/4 v4, 0x2

    invoke-static {v2, v3, v4}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result v5

    .line 622
    .local v5, "minimum":I
    if-gtz v5, :cond_2

    .line 623
    const-string v0, "Microphone unavailable: this phone refused 44.1 kHz mono capture."

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    .line 624
    return-void

    .line 626
    :cond_2
    nop

    .line 627
    :try_start_0
    new-instance v6, Landroid/media/AudioRecord$Builder;

    invoke-direct {v6}, Landroid/media/AudioRecord$Builder;-><init>()V

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/media/AudioRecord$Builder;->setAudioSource(I)Landroid/media/AudioRecord$Builder;

    move-result-object v6

    .line 628
    new-instance v8, Landroid/media/AudioFormat$Builder;

    invoke-direct {v8}, Landroid/media/AudioFormat$Builder;-><init>()V

    invoke-virtual {v8, v4}, Landroid/media/AudioFormat$Builder;->setEncoding(I)Landroid/media/AudioFormat$Builder;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/media/AudioFormat$Builder;->setSampleRate(I)Landroid/media/AudioFormat$Builder;

    move-result-object v4

    .line 629
    invoke-virtual {v4, v3}, Landroid/media/AudioFormat$Builder;->setChannelMask(I)Landroid/media/AudioFormat$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/media/AudioFormat$Builder;->build()Landroid/media/AudioFormat;

    move-result-object v3

    .line 627
    invoke-virtual {v6, v3}, Landroid/media/AudioRecord$Builder;->setAudioFormat(Landroid/media/AudioFormat;)Landroid/media/AudioRecord$Builder;

    move-result-object v3

    .line 630
    const/16 v4, 0x2000

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/media/AudioRecord$Builder;->setBufferSizeInBytes(I)Landroid/media/AudioRecord$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/media/AudioRecord$Builder;->build()Landroid/media/AudioRecord;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 626
    nop

    .line 635
    .local v3, "record":Landroid/media/AudioRecord;
    invoke-virtual {v3}, Landroid/media/AudioRecord;->getState()I

    move-result v4

    if-eq v4, v7, :cond_3

    .line 636
    invoke-virtual {v3}, Landroid/media/AudioRecord;->release()V

    const-string v0, "Microphone unavailable: the recorder did not initialize"

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    return-void

    .line 638
    :cond_3
    :try_start_1
    invoke-virtual {v3}, Landroid/media/AudioRecord;->startRecording()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 641
    iput-object v3, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    iput-boolean v7, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    const-string v0, ""

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    .line 642
    new-instance v0, Ljava/lang/Thread;

    .line 662
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0, v3}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/EngineService;Landroid/media/AudioRecord;)V

    .line 642
    const-string v4, "microphone"

    invoke-direct {v0, v1, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 662
    nop

    .line 679
    move-object v1, v0

    .local v1, "$this$startMicrophone_u24lambda_u2461\\1":Ljava/lang/Thread;
    const/4 v4, 0x0

    .line 662
    .local v4, "$i$a$-apply-EngineService$startMicrophone$2\\1\\662\\0":I
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 642
    .end local v1    # "$this$startMicrophone_u24lambda_u2461\\1":Ljava/lang/Thread;
    .end local v4    # "$i$a$-apply-EngineService$startMicrophone$2\\1\\662\\0":I
    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneThread:Ljava/lang/Thread;

    .line 663
    return-void

    .line 638
    :catch_0
    move-exception v4

    .line 639
    .local v4, "failure":Ljava/lang/Exception;
    invoke-virtual {v3}, Landroid/media/AudioRecord;->release()V

    invoke-virtual {v4}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_4

    goto :goto_0

    :cond_4
    move-object v0, v6

    :goto_0
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    return-void

    .line 631
    .end local v3    # "record":Landroid/media/AudioRecord;
    .end local v4    # "failure":Ljava/lang/Exception;
    :catch_1
    move-exception v3

    .line 632
    .local v3, "failure":Ljava/lang/Exception;
    invoke-virtual {v3}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_5

    goto :goto_1

    :cond_5
    move-object v0, v4

    :goto_1
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    .line 633
    return-void

    .line 615
    .end local v2    # "rate":I
    .end local v3    # "failure":Ljava/lang/Exception;
    .end local v5    # "minimum":I
    :cond_6
    :goto_2
    return-void
.end method

.method private static final startMicrophone$lambda$60(Lorg/lighttouch/android/EngineService;Landroid/media/AudioRecord;)V
    .locals 8
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "$record"    # Landroid/media/AudioRecord;

    .line 643
    const/16 v0, 0x400

    new-array v0, v0, [S

    .line 644
    .local v0, "samples":[S
    nop

    .line 645
    :cond_0
    const/4 v1, 0x0

    const/4 v2, 0x0

    :try_start_0
    iget-boolean v3, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    if-eqz v3, :cond_2

    iget-object v3, p0, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    if-eqz v3, :cond_2

    iget-object v3, p0, Lorg/lighttouch/android/EngineService;->stopping:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    if-nez v3, :cond_2

    .line 646
    array-length v3, v0

    invoke-virtual {p1, v0, v2, v3}, Landroid/media/AudioRecord;->read([SII)I

    move-result v3

    .line 647
    .local v3, "read":I
    if-gez v3, :cond_1

    iget-boolean v4, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    if-eqz v4, :cond_2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Microphone read failed ("

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ")"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;

    goto :goto_0

    .line 648
    :cond_1
    if-eqz v3, :cond_0

    .line 649
    sget-object v4, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v4, v0, v3}, Lorg/lighttouch/android/Native;->microphone([SI)I

    move-result v4

    .line 652
    .local v4, "taken":I
    if-gez v4, :cond_0

    iget-boolean v5, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    if-eqz v5, :cond_2

    neg-int v5, v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "The engine could not take the microphone ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ")"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/EngineService;->microphoneError:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 657
    .end local v3    # "read":I
    .end local v4    # "taken":I
    :cond_2
    :goto_0
    :try_start_1
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v3, p0

    .line 679
    .local v3, "$this$startMicrophone_u24lambda_u2460_u24lambda_u2458\\1":Lorg/lighttouch/android/EngineService;
    const/4 v4, 0x0

    .line 657
    .local v4, "$i$a$-runCatching-EngineService$startMicrophone$1$2\\1\\657\\0":I
    invoke-virtual {p1}, Landroid/media/AudioRecord;->stop()V

    .end local v3    # "$this$startMicrophone_u24lambda_u2460_u24lambda_u2458\\1":Lorg/lighttouch/android/EngineService;
    .end local v4    # "$i$a$-runCatching-EngineService$startMicrophone$1$2\\1\\657\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v3

    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v3}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 658
    :goto_1
    invoke-virtual {p1}, Landroid/media/AudioRecord;->release()V

    .line 659
    sget-object v3, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v3}, Lorg/lighttouch/android/Native;->microphoneFlush()V

    .line 660
    monitor-enter p0

    .line 679
    const/4 v3, 0x0

    .line 660
    .local v3, "$i$a$-synchronized-EngineService$startMicrophone$1$3\\2\\660\\0":I
    :try_start_2
    iget-object v4, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    if-ne v4, p1, :cond_3

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    iput-boolean v2, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    .end local v3    # "$i$a$-synchronized-EngineService$startMicrophone$1$3\\2\\660\\0":I
    :cond_3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v1

    monitor-exit p0

    throw v1

    .line 657
    :catchall_2
    move-exception v3

    :try_start_3
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v4, p0

    .line 679
    .local v4, "$this$startMicrophone_u24lambda_u2460_u24lambda_u2458\\5":Lorg/lighttouch/android/EngineService;
    const/4 v5, 0x0

    .line 657
    .local v5, "$i$a$-runCatching-EngineService$startMicrophone$1$2\\5\\657\\0":I
    invoke-virtual {p1}, Landroid/media/AudioRecord;->stop()V

    .end local v4    # "$this$startMicrophone_u24lambda_u2460_u24lambda_u2458\\5":Lorg/lighttouch/android/EngineService;
    .end local v5    # "$i$a$-runCatching-EngineService$startMicrophone$1$2\\5\\657\\0":I
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    goto :goto_2

    :catchall_3
    move-exception v4

    sget-object v5, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v4}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 658
    :goto_2
    invoke-virtual {p1}, Landroid/media/AudioRecord;->release()V

    .line 659
    sget-object v4, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v4}, Lorg/lighttouch/android/Native;->microphoneFlush()V

    .line 660
    monitor-enter p0

    .line 679
    const/4 v4, 0x0

    .line 660
    .local v4, "$i$a$-synchronized-EngineService$startMicrophone$1$3\\6\\660\\0":I
    :try_start_4
    iget-object v5, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    if-ne v5, p1, :cond_4

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    iput-boolean v2, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    .end local v4    # "$i$a$-synchronized-EngineService$startMicrophone$1$3\\6\\660\\0":I
    :cond_4
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    monitor-exit p0

    throw v3

    :catchall_4
    move-exception v1

    monitor-exit p0

    throw v1

    .line 654
    :catch_0
    move-exception v3

    .line 657
    :try_start_5
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v3, p0

    .line 679
    .local v3, "$this$startMicrophone_u24lambda_u2460_u24lambda_u2458\\3":Lorg/lighttouch/android/EngineService;
    const/4 v4, 0x0

    .line 657
    .local v4, "$i$a$-runCatching-EngineService$startMicrophone$1$2\\3\\657\\0":I
    invoke-virtual {p1}, Landroid/media/AudioRecord;->stop()V

    .end local v3    # "$this$startMicrophone_u24lambda_u2460_u24lambda_u2458\\3":Lorg/lighttouch/android/EngineService;
    .end local v4    # "$i$a$-runCatching-EngineService$startMicrophone$1$2\\3\\657\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    goto :goto_3

    :catchall_5
    move-exception v3

    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v3}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 658
    :goto_3
    invoke-virtual {p1}, Landroid/media/AudioRecord;->release()V

    .line 659
    sget-object v3, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v3}, Lorg/lighttouch/android/Native;->microphoneFlush()V

    .line 660
    monitor-enter p0

    .line 679
    const/4 v3, 0x0

    .line 660
    .local v3, "$i$a$-synchronized-EngineService$startMicrophone$1$3\\4\\660\\0":I
    :try_start_6
    iget-object v4, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    if-ne v4, p1, :cond_5

    iput-object v1, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    iput-boolean v2, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    .end local v3    # "$i$a$-synchronized-EngineService$startMicrophone$1$3\\4\\660\\0":I
    :cond_5
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_6

    :goto_4
    monitor-exit p0

    .line 661
    nop

    .line 662
    return-void

    .line 660
    :catchall_6
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method private final stopAudioOutput()V
    .locals 2

    .line 607
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->lifecycleAdmission:Lorg/lighttouch/android/WorkerLifecycleAdmission;

    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/EngineService;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/WorkerLifecycleAdmission;->run(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    return-void
.end method

.method private static final stopAudioOutput$lambda$57(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 607
    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/EngineService;->audioOn:Z

    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->stopMicrophone()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final stopMicrophone()V
    .locals 4

    .line 666
    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/EngineService;->microphoneOn:Z

    .line 667
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->recorder:Landroid/media/AudioRecord;

    if-eqz v0, :cond_0

    .line 679
    .local v0, "it\\1":Landroid/media/AudioRecord;
    const/4 v1, 0x0

    .line 667
    .local v1, "$i$a$-let-EngineService$stopMicrophone$1\\1\\667\\0":I
    :try_start_0
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p0

    check-cast v2, Lorg/lighttouch/android/EngineService;

    .line 679
    .local v2, "$this$stopMicrophone_u24lambda_u2463_u24lambda_u2462\\2":Lorg/lighttouch/android/EngineService;
    const/4 v3, 0x0

    .line 667
    .local v3, "$i$a$-runCatching-EngineService$stopMicrophone$1$1\\2\\667\\1":I
    invoke-virtual {v0}, Landroid/media/AudioRecord;->stop()V

    .end local v2    # "$this$stopMicrophone_u24lambda_u2463_u24lambda_u2462\\2":Lorg/lighttouch/android/EngineService;
    .end local v3    # "$i$a$-runCatching-EngineService$stopMicrophone$1$1\\2\\667\\1":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .end local v0    # "it\\1":Landroid/media/AudioRecord;
    .end local v1    # "$i$a$-let-EngineService$stopMicrophone$1\\1\\667\\0":I
    :goto_0
    invoke-static {v2}, Lkotlin/Result;->box-impl(Ljava/lang/Object;)Lkotlin/Result;

    .line 668
    :cond_0
    return-void
.end method

.method private static final usbThread$lambda$8(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 2
    .param p0, "it"    # Ljava/lang/Runnable;

    .line 48
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "usb-bridge"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    return-object v0
.end method

.method private static final usb_delegate$lambda$7(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/UsbBridge;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 46
    new-instance v0, Lorg/lighttouch/android/UsbBridge;

    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lorg/lighttouch/android/UsbBridge;-><init>(Landroid/content/Context;)V

    return-object v0
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    const-string v0, "intent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 444
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->binder:Lorg/lighttouch/android/EngineService$binder$1;

    check-cast v0, Landroid/os/IBinder;

    return-object v0
.end method

.method public onCreate()V
    .locals 7

    .line 446
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    .line 447
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingThread:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/EngineService;)V

    .line 453
    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 447
    const-wide/16 v2, 0x3

    const-wide/16 v4, 0x3

    invoke-interface/range {v0 .. v6}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 457
    new-instance v0, Ljava/lang/Thread;

    .line 524
    new-instance v1, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/EngineService$$ExternalSyntheticLambda12;-><init>(Lorg/lighttouch/android/EngineService;)V

    .line 457
    const-string v2, "guest-audio"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 524
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 525
    return-void
.end method

.method public onDestroy()V
    .locals 2

    .line 676
    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->detailedTimingThread:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getUsb()Lorg/lighttouch/android/UsbBridge;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/UsbBridge;->stop()V

    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->getPerformanceSampler()Lorg/lighttouch/android/WorkerPerformanceSampler;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/WorkerPerformanceSampler;->close()V

    iget-object v0, p0, Lorg/lighttouch/android/EngineService;->alive:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->cancelInput()V

    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->stopAudioOutput()V

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 443
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService;->foreground()V

    const/4 v0, 0x2

    return v0
.end method

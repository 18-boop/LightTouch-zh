.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n1225#2,6:209\n1225#2,6:215\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3\n*L\n62#1:197,6\n63#1:203,6\n64#1:209,6\n65#1:215,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method public static synthetic $r8$lambda$AALlqvLqaKJ_stob8aSOIrPSJLU(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/ThemeMode;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/ThemeMode;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$S2HiCQOAnu9ErY3pF81TzS-5KW4(Lorg/lighttouch/android/ScreenScaling;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->invoke$lambda$5$lambda$4(Lorg/lighttouch/android/ScreenScaling;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pixxACrq1Csf1rhTbwaYYfO9OLs(Lorg/lighttouch/android/ThemeMode;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->invoke$lambda$1$lambda$0(Lorg/lighttouch/android/ThemeMode;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wDJ1rZWY8TmDLDG2Ca7q3vEzScg(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/ScreenScaling;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->invoke$lambda$7$lambda$6(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/ScreenScaling;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$yB8G8fz27u0Ooxi7VM2uM_1o1Jk(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->invoke$lambda$9$lambda$8(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Lorg/lighttouch/android/ThemeMode;)Ljava/lang/String;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/ThemeMode;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    invoke-virtual {p0}, Lorg/lighttouch/android/ThemeMode;->getLabel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/ThemeMode;)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Lorg/lighttouch/android/ThemeMode;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setTheme(Lorg/lighttouch/android/ThemeMode;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4(Lorg/lighttouch/android/ScreenScaling;)Ljava/lang/String;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/ScreenScaling;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    invoke-virtual {p0}, Lorg/lighttouch/android/ScreenScaling;->getLabel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final invoke$lambda$7$lambda$6(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/ScreenScaling;)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p2, "it"    # Lorg/lighttouch/android/ScreenScaling;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    invoke-virtual {p0, p2}, Lorg/lighttouch/android/AppSettings;->setScaling(Lorg/lighttouch/android/ScreenScaling;)V

    invoke-interface {p1}, Lorg/lighttouch/android/GuestHost;->applySettings()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$9$lambda$8(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Z

    .line 65
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setAutoResume(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 61
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 19
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v9, p2

    move/from16 v12, p3

    const-string v1, "$this$Group"

    move-object/from16 v13, p1

    invoke-static {v13, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C61@4618L12,61@4632L16,61@4554L94,62@4747L12,63@4902L40,62@4669L273,64@5183L21,64@4963L241:SettingsScreen.kt#o13vsk"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v12, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 65
    :cond_0
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_a

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:61)"

    const v3, 0x35a14b22

    invoke-static {v3, v12, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 62
    :cond_2
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getPalette()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    invoke-static {}, Lorg/lighttouch/android/ThemeMode;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/util/List;

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getTheme()Lorg/lighttouch/android/ThemeMode;

    move-result-object v4

    const v14, 0x6e3c21fe

    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v15, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\1":Z
    move-object/from16 v5, p2

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 197
    .local v6, "$i$f$cache\\1\\62":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\1":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 198
    .local v8, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_3

    .line 199
    const/4 v10, 0x0

    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$1\\3\\199\\0":I
    new-instance v11, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda0;

    invoke-direct {v11}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda0;-><init>()V

    .line 200
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$1\\3\\199\\0":I
    .local v11, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .end local v11    # "value\\2":Ljava/lang/Object;
    goto :goto_1

    .line 202
    :cond_3
    move-object v11, v7

    .line 198
    :goto_1
    nop

    .line 197
    .end local v7    # "it\\1":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 62
    .end local v2    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\1\\62":I
    move-object v5, v11

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x4c5de2

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v6, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    .local v6, "invalid\\4":Z
    iget-object v7, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v8, p2

    .local v8, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 197
    .local v10, "$i$f$cache\\4\\62":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 198
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\197\\4":I
    if-nez v6, :cond_5

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v11, v2, :cond_4

    goto :goto_2

    .line 202
    :cond_4
    move-object v14, v11

    goto :goto_3

    .line 199
    :cond_5
    :goto_2
    const/4 v2, 0x0

    .line 62
    .local v2, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$2\\6\\199\\0":I
    new-instance v14, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda1;

    invoke-direct {v14, v7}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 199
    .end local v2    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$2\\6\\199\\0":I
    nop

    .line 200
    .local v14, "value\\5":Ljava/lang/Object;
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .line 198
    .end local v14    # "value\\5":Ljava/lang/Object;
    :goto_3
    nop

    .line 197
    .end local v11    # "it\\4":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\5\\197\\4":I
    nop

    .line 62
    .end local v6    # "invalid\\4":Z
    .end local v8    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\4\\62":I
    move-object v8, v14

    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v10, 0x6030

    const/16 v11, 0x60

    const-string v2, "\u4e3b\u9898"

    const/4 v6, 0x0

    const/4 v7, 0x0

    const v14, 0x4c5de2

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SettingsScreenKt;->access$ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/util/List;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 63
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getLayers()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    invoke-static {}, Lorg/lighttouch/android/ScreenScaling;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/util/List;

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getScaling()Lorg/lighttouch/android/ScreenScaling;

    move-result-object v4

    const v2, 0x6e3c21fe

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\7":Z
    move-object/from16 v5, p2

    .local v5, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 203
    .local v6, "$i$f$cache\\7\\63":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\7":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 204
    .local v8, "$i$a$-let-ComposerKt$cache$1\\8\\203\\7":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_6

    .line 205
    const/4 v10, 0x0

    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$3\\9\\205\\0":I
    new-instance v11, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda2;

    invoke-direct {v11}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda2;-><init>()V

    .line 206
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$3\\9\\205\\0":I
    .local v11, "value\\8":Ljava/lang/Object;
    invoke-interface {v5, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .end local v11    # "value\\8":Ljava/lang/Object;
    goto :goto_4

    .line 208
    :cond_6
    move-object v11, v7

    .line 204
    :goto_4
    nop

    .line 203
    .end local v7    # "it\\7":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\8\\203\\7":I
    nop

    .line 63
    .end local v2    # "invalid\\7":Z
    .end local v5    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\7\\63":I
    move-object v5, v11

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 64
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getScaling()Lorg/lighttouch/android/ScreenScaling;

    move-result-object v2

    sget-object v6, Lorg/lighttouch/android/ScreenScaling;->SMOOTH:Lorg/lighttouch/android/ScreenScaling;

    if-ne v2, v6, :cond_7

    const-string v2, "\u7531\u663e\u793a\u786c\u4ef6\u505a\u6ee4\u955c\u5904\u7406"

    goto :goto_5

    :cond_7
    const-string v2, "\u4fdd\u6301\u50cf\u7d20\u9510\u5229\uff0c\u518d\u7f29\u653e\u9002\u914d"

    :goto_5
    move-object v6, v2

    const v2, -0x615d173a

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    iget-object v7, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    or-int/2addr v2, v7

    .local v2, "invalid\\10":Z
    iget-object v7, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    iget-object v8, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v10, p2

    .local v10, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 209
    .local v11, "$i$f$cache\\10\\64":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\10":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 210
    .local v16, "$i$a$-let-ComposerKt$cache$1\\11\\209\\10":I
    if-nez v2, :cond_9

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v18, v1

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v14, v1, :cond_8

    goto :goto_6

    .line 214
    :cond_8
    move-object v1, v14

    goto :goto_7

    .line 210
    :cond_9
    move-object/from16 v18, v1

    .line 211
    :goto_6
    const/4 v1, 0x0

    .line 64
    .local v1, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$4\\12\\211\\0":I
    move/from16 v17, v1

    .end local v1    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$4\\12\\211\\0":I
    .local v17, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$4\\12\\211\\0":I
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda3;

    invoke-direct {v1, v7, v8}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V

    .line 211
    .end local v17    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$4\\12\\211\\0":I
    nop

    .line 212
    .local v1, "value\\11":Ljava/lang/Object;
    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    nop

    .line 210
    .end local v1    # "value\\11":Ljava/lang/Object;
    :goto_7
    nop

    .line 209
    .end local v14    # "it\\10":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\11\\209\\10":I
    nop

    .line 64
    .end local v2    # "invalid\\10":Z
    .end local v10    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\10\\64":I
    move-object v8, v1

    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 63
    const-string v2, "\u753b\u9762\u7f29\u653e"

    const/4 v7, 0x0

    const/16 v10, 0x6030

    const/16 v11, 0x40

    move-object/from16 v1, v18

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SettingsScreenKt;->access$ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/util/List;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 65
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getPlay()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getAutoResume()Z

    move-result v4

    const v14, 0x4c5de2

    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\13":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 215
    .local v6, "$i$f$cache\\13\\65":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\13":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 216
    .local v8, "$i$a$-let-ComposerKt$cache$1\\14\\215\\13":I
    if-nez v2, :cond_b

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_a

    goto :goto_8

    .line 220
    :cond_a
    move-object v11, v7

    goto :goto_9

    .line 217
    :cond_b
    :goto_8
    const/4 v10, 0x0

    .line 65
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$5\\15\\217\\0":I
    new-instance v11, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda4;

    invoke-direct {v11, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 217
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$3$5\\15\\217\\0":I
    nop

    .line 218
    .local v11, "value\\14":Ljava/lang/Object;
    invoke-interface {v5, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 219
    nop

    .line 216
    .end local v11    # "value\\14":Ljava/lang/Object;
    :goto_9
    nop

    .line 215
    .end local v7    # "it\\13":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\14\\215\\13":I
    nop

    .line 65
    .end local v2    # "invalid\\13":Z
    .end local v5    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\13\\65":I
    move-object v7, v11

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x1b0

    const/16 v10, 0x30

    const-string v2, "\u8fd4\u56de\u65f6\u81ea\u52a8\u7ee7\u7eed"

    const-string v3, "LightTouch \u8f6c\u5165\u540e\u53f0\u65f6 iOS \u4f1a\u6682\u505c\uff08\u5b89\u88c5\u5e94\u7528\u65f6\u9664\u5916\uff09\u3002\u5f00\u542f\u5219\u8fd4\u56de\u540e\u81ea\u52a8\u7ee7\u7eed\uff1b\u5173\u95ed\u5219\u7b49\u5f85\u4f60\u8f7b\u6309\u300c\u7ee7\u7eed\u300d"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v8, p2

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 66
    :cond_c
    :goto_a
    return-void
.end method

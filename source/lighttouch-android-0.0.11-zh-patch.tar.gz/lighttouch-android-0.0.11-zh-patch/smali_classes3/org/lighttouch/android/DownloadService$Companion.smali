.class public final Lorg/lighttouch/android/DownloadService$Companion;
.super Ljava/lang/Object;
.source "DownloadService.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/lighttouch/android/DownloadService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDownloadService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DownloadService.kt\norg/lighttouch/android/DownloadService$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n1#2:71\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0005\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\tH\u0002J\u0018\u0010\n\u001a\n \u000c*\u0004\u0018\u00010\u000b0\u000b2\u0006\u0010\u0008\u001a\u00020\tH\u0002J\'\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0002\u00a2\u0006\u0002\u0010\u0013J\u0016\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u0010J\u000e\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0008\u001a\u00020\tJ%\u0010\u0017\u001a\u00020\u00152\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0012\u00a2\u0006\u0002\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u00152\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u0010R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001a"
    }
    d2 = {
        "Lorg/lighttouch/android/DownloadService$Companion;",
        "",
        "<init>",
        "()V",
        "holders",
        "",
        "manager",
        "Landroid/app/NotificationManager;",
        "context",
        "Landroid/content/Context;",
        "launch",
        "Landroid/app/PendingIntent;",
        "kotlin.jvm.PlatformType",
        "notification",
        "Landroid/app/Notification;",
        "text",
        "",
        "fraction",
        "",
        "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)Landroid/app/Notification;",
        "hold",
        "",
        "release",
        "update",
        "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)V",
        "finished",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0}, Lorg/lighttouch/android/DownloadService$Companion;-><init>()V

    return-void
.end method

.method public static final synthetic access$notification(Lorg/lighttouch/android/DownloadService$Companion;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)Landroid/app/Notification;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/DownloadService$Companion;
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "fraction"    # Ljava/lang/Float;

    .line 29
    invoke-direct {p0, p1, p2, p3}, Lorg/lighttouch/android/DownloadService$Companion;->notification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)Landroid/app/Notification;

    move-result-object v0

    return-object v0
.end method

.method private final launch(Landroid/content/Context;)Landroid/app/PendingIntent;
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    .line 36
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lorg/lighttouch/android/MainActivity;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x4000000

    const/4 v2, 0x3

    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    return-object v0
.end method

.method private final manager(Landroid/content/Context;)Landroid/app/NotificationManager;
    .locals 7
    .param p1, "context"    # Landroid/content/Context;

    .line 32
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/app/NotificationManager;

    .local v1, "it\\1":Landroid/app/NotificationManager;
    const/4 v2, 0x0

    .line 33
    .local v2, "$i$a$-also-DownloadService$Companion$manager$1\\1\\32\\0":I
    new-instance v3, Landroid/app/NotificationChannel;

    const-string v4, "\u4e0b\u8f7d"

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const-string v6, "download"

    invoke-direct {v3, v6, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    invoke-virtual {v1, v3}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 34
    new-instance v3, Landroid/app/NotificationChannel;

    const-string v4, "\u5df2\u5b8c\u6210\u5b89\u88c5"

    check-cast v4, Ljava/lang/CharSequence;

    const/4 v5, 0x3

    const-string v6, "installed"

    invoke-direct {v3, v6, v4, v5}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    invoke-virtual {v1, v3}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 35
    nop

    .line 32
    .end local v1    # "it\\1":Landroid/app/NotificationManager;
    .end local v2    # "$i$a$-also-DownloadService$Companion$manager$1\\1\\32\\0":I
    const-string v1, "also(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/app/NotificationManager;

    .line 35
    return-object v0
.end method

.method private final notification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)Landroid/app/Notification;
    .locals 6
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "fraction"    # Ljava/lang/Float;

    .line 40
    invoke-direct {p0, p1}, Lorg/lighttouch/android/DownloadService$Companion;->manager(Landroid/content/Context;)Landroid/app/NotificationManager;

    .line 41
    new-instance v0, Landroid/app/Notification$Builder;

    const-string v1, "download"

    invoke-direct {v0, p1, v1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v1, 0x1080081

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v0

    .line 42
    const-string v1, "LightTouch"

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v0

    move-object v1, p2

    check-cast v1, Ljava/lang/CharSequence;

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/DownloadService$Companion;->launch(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v0

    .line 43
    move-object v1, v0

    .line 71
    .local v1, "$this$notification_u24lambda_u241\\1":Landroid/app/Notification$Builder;
    const/4 v2, 0x0

    .line 43
    .local v2, "$i$a$-apply-DownloadService$Companion$notification$1\\1\\43\\0":I
    if-eqz p3, :cond_0

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    const/4 v4, 0x0

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v3, v4, v5}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v3

    const/16 v4, 0x64

    int-to-float v5, v4

    mul-float/2addr v3, v5

    float-to-int v3, v3

    const/4 v5, 0x0

    invoke-virtual {v1, v4, v3, v5}, Landroid/app/Notification$Builder;->setProgress(IIZ)Landroid/app/Notification$Builder;

    .end local v1    # "$this$notification_u24lambda_u241\\1":Landroid/app/Notification$Builder;
    .end local v2    # "$i$a$-apply-DownloadService$Companion$notification$1\\1\\43\\0":I
    :cond_0
    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const-string v1, "build(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    return-object v0
.end method


# virtual methods
.method public final finished(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    invoke-direct {p0, p1}, Lorg/lighttouch/android/DownloadService$Companion;->manager(Landroid/content/Context;)Landroid/app/NotificationManager;

    move-result-object v0

    new-instance v1, Landroid/app/Notification$Builder;

    const-string v2, "installed"

    invoke-direct {v1, p1, v2}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v2, 0x1080082

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v1

    .line 66
    const-string v2, "LightTouch"

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v1

    move-object v2, p2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v1

    invoke-direct {p0, p1}, Lorg/lighttouch/android/DownloadService$Companion;->launch(Landroid/content/Context;)Landroid/app/PendingIntent;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v1

    .line 65
    const/4 v2, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 67
    return-void
.end method

.method public final hold(Landroid/content/Context;Ljava/lang/String;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 47
    monitor-enter p0

    const/4 v0, 0x0

    .line 48
    .local v0, "$i$a$-synchronized-DownloadService$Companion$hold$1\\1\\47\\0":I
    :try_start_0
    invoke-static {}, Lorg/lighttouch/android/DownloadService;->access$getHolders$cp()I

    move-result v1

    sget-object v2, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    add-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Lorg/lighttouch/android/DownloadService;->access$setHolders$cp(I)V

    .line 50
    sget-object v1, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    .line 71
    .local v1, "$this$hold_u24lambda_u243_u24lambda_u242\\2":Lorg/lighttouch/android/DownloadService$Companion;
    const/4 v2, 0x0

    .line 50
    .local v2, "$i$a$-runCatching-DownloadService$Companion$hold$1$1\\2\\50\\1":I
    new-instance v3, Landroid/content/Intent;

    const-class v4, Lorg/lighttouch/android/DownloadService;

    invoke-direct {v3, p1, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v4, "text"

    invoke-virtual {v3, v4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    invoke-virtual {p1, v3}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object v3

    .end local v1    # "$this$hold_u24lambda_u243_u24lambda_u242\\2":Lorg/lighttouch/android/DownloadService$Companion;
    .end local v2    # "$i$a$-runCatching-DownloadService$Companion$hold$1$1\\2\\50\\1":I
    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_2
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    :goto_0
    nop

    .line 52
    nop

    .end local v0    # "$i$a$-synchronized-DownloadService$Companion$hold$1\\1\\47\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 47
    monitor-exit p0

    .line 52
    return-void

    .line 47
    :catchall_1
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final release(Landroid/content/Context;)V
    .locals 3
    .param p1, "context"    # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    monitor-enter p0

    const/4 v0, 0x0

    .line 55
    .local v0, "$i$a$-synchronized-DownloadService$Companion$release$1\\1\\54\\0":I
    :try_start_0
    invoke-static {}, Lorg/lighttouch/android/DownloadService;->access$getHolders$cp()I

    move-result v1

    if-lez v1, :cond_0

    sget-object v1, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-static {}, Lorg/lighttouch/android/DownloadService;->access$getHolders$cp()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-static {v1}, Lorg/lighttouch/android/DownloadService;->access$setHolders$cp(I)V

    invoke-static {}, Lorg/lighttouch/android/DownloadService;->access$getHolders$cp()I

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Landroid/content/Intent;

    const-class v2, Lorg/lighttouch/android/DownloadService;

    invoke-direct {v1, p1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, v1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 56
    :cond_0
    nop

    .end local v0    # "$i$a$-synchronized-DownloadService$Companion$release$1\\1\\54\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 54
    monitor-exit p0

    .line 56
    return-void

    .line 54
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final update(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "fraction"    # Ljava/lang/Float;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "text"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    monitor-enter p0

    const/4 v0, 0x0

    .line 60
    .local v0, "$i$a$-synchronized-DownloadService$Companion$update$1\\1\\59\\0":I
    :try_start_0
    invoke-static {}, Lorg/lighttouch/android/DownloadService;->access$getHolders$cp()I

    move-result v1

    if-lez v1, :cond_0

    sget-object v1, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/DownloadService$Companion;->manager(Landroid/content/Context;)Landroid/app/NotificationManager;

    move-result-object v1

    sget-object v2, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-direct {v2, p1, p2, p3}, Lorg/lighttouch/android/DownloadService$Companion;->notification(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)Landroid/app/Notification;

    move-result-object v2

    const/4 v3, 0x3

    invoke-virtual {v1, v3, v2}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 61
    :cond_0
    nop

    .end local v0    # "$i$a$-synchronized-DownloadService$Companion$update$1\\1\\59\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 59
    monitor-exit p0

    .line 61
    return-void

    .line 59
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.class final Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;
.super Ljava/lang/Object;
.source "DeviceFrame.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DeviceFrameKt;->DeviceFrame(Lorg/lighttouch/android/DeviceSkin;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;ZLandroidx/compose/runtime/Composer;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/BoxWithConstraintsScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeviceFrame.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeviceFrame.kt\norg/lighttouch/android/DeviceFrameKt$DeviceFrame$1\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 9 Dp.kt\nandroidx/compose/ui/unit/Dp\n*L\n1#1,128:1\n77#2:129\n1225#3,6:130\n1225#3,6:215\n71#4:136\n68#4,6:137\n74#4:171\n71#4:172\n68#4,6:173\n74#4:207\n78#4:211\n78#4:224\n79#5,6:143\n86#5,4:158\n90#5,2:168\n79#5,6:179\n86#5,4:194\n90#5,2:204\n94#5:210\n94#5:223\n368#6,9:149\n377#6:170\n368#6,9:185\n377#6:206\n378#6,2:208\n378#6,2:221\n4034#7,6:162\n4034#7,6:198\n149#8:212\n169#8:225\n72#9:213\n57#9:214\n*S KotlinDebug\n*F\n+ 1 DeviceFrame.kt\norg/lighttouch/android/DeviceFrameKt$DeviceFrame$1\n*L\n80#1:129\n81#1:130,6\n98#1:215,6\n82#1:136\n82#1:137,6\n82#1:171\n86#1:172\n86#1:173,6\n86#1:207\n86#1:211\n82#1:224\n82#1:143,6\n82#1:158,4\n82#1:168,2\n86#1:179,6\n86#1:194,4\n86#1:204,2\n86#1:210\n82#1:223\n82#1:149,9\n82#1:170\n86#1:185,9\n86#1:206\n86#1:208,2\n82#1:221,2\n82#1:162,6\n86#1:198,6\n96#1:212\n72#1:225\n97#1:213\n97#1:214\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $button:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $enabled:Z

.field final synthetic $haptics:Z

.field final synthetic $screen:Lkotlin/jvm/functions/Function3;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function3<",
            "Landroidx/compose/ui/Modifier;",
            "Landroidx/compose/runtime/Composer;",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $skin:Lorg/lighttouch/android/DeviceSkin;


# direct methods
.method public static synthetic $r8$lambda$fS-m6sFtaAaC9PgeWydApVOWKJY(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$lambda$5$lambda$4$lambda$3(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ySIjoEUyNe5YQnXGpNEbfHQsET0(ZLandroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$lambda$1$lambda$0(ZLandroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/DeviceSkin;ZZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/DeviceSkin;",
            "ZZ",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/ui/Modifier;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    iput-boolean p2, p0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$haptics:Z

    iput-boolean p3, p0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$enabled:Z

    iput-object p4, p0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$button:Lkotlin/jvm/functions/Function2;

    iput-object p5, p0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$screen:Lkotlin/jvm/functions/Function3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(ZLandroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;
    .locals 1
    .param p0, "$haptics"    # Z
    .param p1, "$feedback"    # Landroidx/compose/ui/hapticfeedback/HapticFeedback;

    .line 81
    if-eqz p0, :cond_0

    sget-object v0, Landroidx/compose/ui/hapticfeedback/HapticFeedbackType;->Companion:Landroidx/compose/ui/hapticfeedback/HapticFeedbackType$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/hapticfeedback/HapticFeedbackType$Companion;->getLongPress-5zf0vsI()I

    move-result v0

    invoke-interface {p1, v0}, Landroidx/compose/ui/hapticfeedback/HapticFeedback;->performHapticFeedback-CdsT49E(I)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4$lambda$3(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/semantics/Role$Companion;->getButton-o7Vup1c()I

    move-result v0

    invoke-static {p1, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setRole-kuIjeqM(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$mm(FF)F
    .locals 2
    .param p0, "scale"    # F
    .param p1, "value"    # F

    .line 72
    mul-float v0, p1, p0

    .local v0, "$this$dp\\1":F
    const/4 v1, 0x0

    .line 225
    .local v1, "$i$f$getDp\\1\\72":I
    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 72
    .end local v0    # "$this$dp\\1":F
    .end local v1    # "$i$f$getDp\\1\\72":I
    return v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 68
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke(Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)V
    .locals 68
    .param p1, "$this$BoxWithConstraints"    # Landroidx/compose/foundation/layout/BoxWithConstraintsScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v3, "$this$BoxWithConstraints"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C79@4608L7,80@4637L77,81@4723L1658:DeviceFrame.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p3

    .local v3, "$dirty":I
    and-int/lit8 v4, p3, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-nez v4, :cond_1

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    move v4, v5

    goto :goto_0

    :cond_0
    move v4, v6

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x13

    const/16 v7, 0x12

    if-ne v4, v7, :cond_3

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 224
    :cond_2
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v27, v3

    goto/16 :goto_e

    .line 0
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v7, "org.lighttouch.android.DeviceFrame.<anonymous> (DeviceFrame.kt:69)"

    const v8, -0x4daf4f8e

    invoke-static {v8, v3, v4, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 70
    :cond_4
    const/high16 v4, 0x40400000    # 3.0f

    .line 71
    .local v4, "margin":F
    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxWidth-D9Ej5fM()F

    move-result v7

    iget-object v8, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v8}, Lorg/lighttouch/android/DeviceSkin;->getWidth()F

    move-result v8

    int-to-float v9, v6

    mul-float v10, v9, v4

    add-float/2addr v8, v10

    div-float/2addr v7, v8

    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxHeight-D9Ej5fM()F

    move-result v8

    iget-object v10, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v10}, Lorg/lighttouch/android/DeviceSkin;->getHeight()F

    move-result v10

    mul-float v11, v9, v4

    add-float/2addr v10, v11

    div-float/2addr v8, v10

    invoke-static {v7, v8}, Ljava/lang/Math;->min(FF)F

    move-result v7

    .line 75
    .local v7, "scale":F
    iget-object v8, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v8}, Lorg/lighttouch/android/DeviceSkin;->getHeight()F

    move-result v8

    const v10, 0x3d851eb8    # 0.065f

    mul-float/2addr v8, v10

    .line 77
    .local v8, "side":F
    const/4 v10, 0x3

    new-array v11, v10, [Lkotlin/Triple;

    new-instance v12, Lkotlin/Triple;

    const/4 v13, 0x1

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    iget-object v15, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v15}, Lorg/lighttouch/android/DeviceSkin;->getWidth()F

    move-result v15

    const v16, 0x3f1eb852    # 0.62f

    mul-float v15, v15, v16

    add-float/2addr v15, v4

    const v16, 0x3fb33333    # 1.4f

    sub-float v16, v4, v16

    move/from16 v17, v6

    iget-object v6, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v6}, Lorg/lighttouch/android/DeviceSkin;->getWidth()F

    move-result v6

    const v18, 0x3e4ccccd    # 0.2f

    mul-float v6, v6, v18

    move/from16 v18, v10

    new-array v10, v5, [F

    move/from16 v19, v13

    const/4 v13, 0x0

    aput v15, v10, v13

    aput v16, v10, v19

    aput v6, v10, v17

    const/high16 v6, 0x40000000    # 2.0f

    aput v6, v10, v18

    const-string v15, "\u7761\u7720/\u5524\u9192"

    invoke-direct {v12, v14, v15, v10}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v12, v11, v13

    .line 78
    new-instance v10, Lkotlin/Triple;

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const v14, 0x3fa66666    # 1.3f

    sub-float v15, v4, v14

    move/from16 v16, v6

    iget-object v6, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v6}, Lorg/lighttouch/android/DeviceSkin;->getHeight()F

    move-result v6

    const v20, 0x3e051eb8    # 0.13f

    mul-float v6, v6, v20

    add-float/2addr v6, v4

    move/from16 v20, v14

    new-array v14, v5, [F

    aput v15, v14, v13

    aput v6, v14, v19

    aput v16, v14, v17

    aput v8, v14, v18

    const-string v6, "\u97f3\u91cf +"

    invoke-direct {v10, v12, v6, v14}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v10, v11, v19

    .line 77
    nop

    .line 79
    new-instance v6, Lkotlin/Triple;

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    sub-float v12, v4, v20

    iget-object v14, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v14}, Lorg/lighttouch/android/DeviceSkin;->getHeight()F

    move-result v14

    const v15, 0x3e570a3d    # 0.21f

    mul-float/2addr v14, v15

    add-float/2addr v14, v4

    new-array v5, v5, [F

    aput v12, v5, v13

    aput v14, v5, v19

    aput v16, v5, v17

    aput v8, v5, v18

    const-string v12, "\u97f3\u91cf \u2212"

    invoke-direct {v6, v10, v12, v5}, Lkotlin/Triple;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    aput-object v6, v11, v17

    .line 77
    nop

    .line 76
    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    .line 80
    .local v5, "buttons":Ljava/util/List;
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalHapticFeedback()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v6

    check-cast v6, Landroidx/compose/runtime/CompositionLocal;

    .local v6, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v10, 0x0

    .local v10, "$changed\\1":I
    const/4 v11, 0x0

    .line 129
    .local v11, "$i$f$getCurrent\\1\\80":I
    const v12, 0x789c5f52

    const-string v14, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v2, v12, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v12

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 80
    .end local v6    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v10    # "$changed\\1":I
    .end local v11    # "$i$f$getCurrent\\1\\80":I
    move-object v6, v12

    check-cast v6, Landroidx/compose/ui/hapticfeedback/HapticFeedback;

    .local v6, "feedback":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    const v10, -0x615d173a

    invoke-interface {v2, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "CC(remember):DeviceFrame.kt#9igjgp"

    invoke-static {v2, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-boolean v11, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$haptics:Z

    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v11

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v12

    or-int/2addr v11, v12

    .line 81
    iget-boolean v12, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$haptics:Z

    move-object/from16 v14, p2

    .local v11, "invalid\\2":Z
    .local v14, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 130
    .local v15, "$i$f$cache\\2\\81":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\2":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 131
    .local v20, "$i$a$-let-ComposerKt$cache$1\\3\\130\\2":I
    if-nez v11, :cond_6

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v13, v1, :cond_5

    goto :goto_2

    .line 135
    :cond_5
    move-object v1, v13

    goto :goto_3

    .line 132
    :cond_6
    :goto_2
    const/4 v1, 0x0

    .line 81
    .local v1, "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$haptic$1\\4\\132\\0":I
    move/from16 v21, v1

    .end local v1    # "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$haptic$1\\4\\132\\0":I
    .local v21, "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$haptic$1\\4\\132\\0":I
    new-instance v1, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1$$ExternalSyntheticLambda0;

    invoke-direct {v1, v12, v6}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1$$ExternalSyntheticLambda0;-><init>(ZLandroidx/compose/ui/hapticfeedback/HapticFeedback;)V

    .line 132
    .end local v21    # "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$haptic$1\\4\\132\\0":I
    nop

    .line 133
    .local v1, "value\\3":Ljava/lang/Object;
    invoke-interface {v14, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 134
    nop

    .line 131
    .end local v1    # "value\\3":Ljava/lang/Object;
    :goto_3
    nop

    .line 130
    .end local v13    # "it\\2":Ljava/lang/Object;
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\3\\130\\2":I
    nop

    .line 81
    .end local v11    # "invalid\\2":Z
    .end local v14    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\2\\81":I
    move-object/from16 v24, v1

    check-cast v24, Lkotlin/jvm/functions/Function0;

    .local v24, "haptic":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 82
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    iget-object v11, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getWidth()F

    move-result v11

    mul-float v12, v9, v4

    add-float/2addr v11, v12

    invoke-static {v7, v11}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v11

    iget-object v12, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    invoke-virtual {v12}, Lorg/lighttouch/android/DeviceSkin;->getHeight()F

    move-result v12

    mul-float v13, v9, v4

    add-float/2addr v12, v13

    invoke-static {v7, v12}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v12

    invoke-static {v1, v11, v12}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\5":Landroidx/compose/ui/Modifier;
    iget-object v11, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$skin:Lorg/lighttouch/android/DeviceSkin;

    iget-boolean v12, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$enabled:Z

    iget-object v13, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$button:Lkotlin/jvm/functions/Function2;

    iget-object v14, v0, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->$screen:Lkotlin/jvm/functions/Function3;

    const/4 v15, 0x0

    .local v15, "$changed\\5":I
    const/16 v20, 0x0

    .line 136
    .local v20, "$i$f$Box\\5\\82":I
    const v0, 0x2bb5b5d7

    move/from16 v27, v3

    .end local v3    # "$dirty":I
    .local v27, "$dirty":I
    const-string v3, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v2, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 137
    sget-object v21, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v0

    .line 138
    .local v0, "contentAlignment\\5":Landroidx/compose/ui/Alignment;
    move-object/from16 v28, v5

    .end local v5    # "buttons":Ljava/util/List;
    .local v28, "buttons":Ljava/util/List;
    const/4 v5, 0x0

    .line 141
    .local v5, "propagateMinConstraints\\5":Z
    move-object/from16 v29, v6

    .end local v6    # "feedback":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    .local v29, "feedback":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    invoke-static {v0, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v21, v15, 0x3

    and-int/lit8 v21, v21, 0x70

    .line 142
    move/from16 v30, v21

    .local v30, "$changed\\6":I
    const/16 v31, 0x0

    .line 143
    .local v31, "$i$f$Layout\\6\\142":I
    move-object/from16 v32, v0

    .end local v0    # "contentAlignment\\5":Landroidx/compose/ui/Alignment;
    .local v32, "contentAlignment\\5":Landroidx/compose/ui/Alignment;
    const v0, -0x4ee9b9da

    move/from16 v33, v5

    .end local v5    # "propagateMinConstraints\\5":Z
    .local v33, "propagateMinConstraints\\5":Z
    const-string v5, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v2, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 144
    const/4 v0, 0x0

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v34

    .line 145
    .local v34, "compositeKeyHash\\6":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 146
    .local v0, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v35, v8

    .end local v8    # "side":F
    .local v35, "side":F
    invoke-static {v2, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 148
    .local v8, "materialized\\6":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v36, v1

    .end local v1    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v36, "modifier\\5":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v30, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 147
    nop

    .local v1, "$changed\\7":I
    move-object/from16 v37, v23

    .local v37, "factory\\7":Lkotlin/jvm/functions/Function0;
    const/16 v38, 0x0

    .line 149
    .local v38, "$i$f$ReusableComposeNode\\7\\147":I
    move/from16 v39, v1

    .end local v1    # "$changed\\7":I
    .local v39, "$changed\\7":I
    const v1, -0x2942ffcf

    move/from16 v40, v9

    const-string v9, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v2, v1, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 150
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 151
    :cond_7
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 152
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_8

    .line 153
    move-object/from16 v1, v37

    .end local v37    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 155
    .end local v1    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\7":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v1, v37

    .end local v37    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 157
    :goto_4
    move-object/from16 v37, v1

    .end local v1    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 158
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\157\\6":I
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 159
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 161
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\9":Lkotlin/jvm/functions/Function2;
    const/16 v26, 0x0

    .line 162
    .local v26, "$i$f$set-impl\\9\\161":I
    move-object/from16 v41, v1

    .local v41, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v42, 0x0

    .line 163
    .local v42, "$i$a$-with-Updater$set$1\\10\\162\\9":I
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v43

    if-nez v43, :cond_a

    move-object/from16 v43, v0

    .end local v0    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .local v43, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v44, v6

    .end local v6    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v44, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_5

    :cond_9
    move-object/from16 v6, v41

    goto :goto_6

    .end local v43    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v44    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v0    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_a
    move-object/from16 v43, v0

    move-object/from16 v44, v6

    .line 164
    .end local v0    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v43    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v44    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_5
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v6, v41

    .end local v41    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 165
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v0, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 167
    :goto_6
    nop

    .line 162
    .end local v6    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v42    # "$i$a$-with-Updater$set$1\\10\\162\\9":I
    nop

    .line 167
    nop

    .line 168
    .end local v2    # "block\\9":Lkotlin/jvm/functions/Function2;
    .end local v26    # "$i$f$set-impl\\9\\161":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 169
    nop

    .line 157
    .end local v1    # "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\157\\6":I
    nop

    .line 170
    shr-int/lit8 v0, v39, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\11":I
    move-object/from16 v1, p2

    .local v1, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 171
    .local v2, "$i$a$-Layout-BoxKt$Box$1\\11\\170\\5":I
    const v6, -0x7ff519f7    # -1.000876E-39f

    move/from16 v41, v0

    .end local v0    # "$changed\\11":I
    .local v41, "$changed\\11":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v25, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v26, v15, 0x6

    and-int/lit8 v26, v26, 0x70

    or-int/lit8 v42, v26, 0x6

    .local v42, "$changed\\12":I
    check-cast v25, Landroidx/compose/foundation/layout/BoxScope;

    .local v25, "$this$invoke_u24lambda_u245\\12":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v45, v1

    .local v45, "$composer\\12":Landroidx/compose/runtime/Composer;
    move-object/from16 v46, v25

    .end local v25    # "$this$invoke_u24lambda_u245\\12":Landroidx/compose/foundation/layout/BoxScope;
    .local v46, "$this$invoke_u24lambda_u245\\12":Landroidx/compose/foundation/layout/BoxScope;
    const/16 v47, 0x0

    .line 83
    .local v47, "$i$a$-Box-DeviceFrameKt$DeviceFrame$1$1\\12\\171\\0":I
    const v6, -0x122a93c9

    move-object/from16 v48, v1

    .end local v1    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\11":Landroidx/compose/runtime/Composer;
    const-string v1, "C85@5068L723:DeviceFrame.kt#o13vsk"

    move/from16 v49, v2

    move-object/from16 v2, v45

    .end local v45    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v49, "$i$a$-Layout-BoxKt$Box$1\\11\\170\\5":I
    invoke-static {v2, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v1, 0x207237ed

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "*83@4858L138"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface/range {v28 .. v28}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_7
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lkotlin/Triple;

    invoke-virtual {v6}, Lkotlin/Triple;->component3()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [F

    .line 84
    .local v6, "r\\12":[F
    sget-object v26, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v45, v1

    move-object/from16 v1, v26

    check-cast v1, Landroidx/compose/ui/Modifier;

    move-object/from16 v26, v6

    const/16 v16, 0x0

    .end local v6    # "r\\12":[F
    .local v26, "r\\12":[F
    aget v6, v26, v16

    invoke-static {v7, v6}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v6

    move-object/from16 v50, v8

    .end local v8    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .local v50, "materialized\\6":Landroidx/compose/ui/Modifier;
    aget v8, v26, v19

    invoke-static {v7, v8}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v8

    invoke-static {v1, v6, v8}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    aget v6, v26, v17

    invoke-static {v7, v6}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v6

    aget v8, v26, v18

    invoke-static {v7, v8}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v8

    invoke-static {v1, v6, v8}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v51

    sget-object v52, Landroidx/compose/ui/graphics/Brush;->Companion:Landroidx/compose/ui/graphics/Brush$Companion;

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getRim()Ljava/util/List;

    move-result-object v53

    const/16 v59, 0xe

    const/16 v60, 0x0

    const-wide/16 v54, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    invoke-static/range {v52 .. v60}, Landroidx/compose/ui/graphics/Brush$Companion;->linearGradient-mHitzGk$default(Landroidx/compose/ui/graphics/Brush$Companion;Ljava/util/List;JJIILjava/lang/Object;)Landroidx/compose/ui/graphics/Brush;

    move-result-object v52

    const v1, 0x3f4ccccd    # 0.8f

    invoke-static {v7, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-static {v1}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    move-object/from16 v53, v1

    check-cast v53, Landroidx/compose/ui/graphics/Shape;

    const/16 v55, 0x4

    const/16 v56, 0x0

    const/16 v54, 0x0

    invoke-static/range {v51 .. v56}, Landroidx/compose/foundation/BackgroundKt;->background$default(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Brush;Landroidx/compose/ui/graphics/Shape;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v6, 0x0

    invoke-static {v1, v2, v6}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    move-object/from16 v1, v45

    move-object/from16 v8, v50

    .end local v26    # "r\\12":[F
    goto :goto_7

    .end local v50    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .restart local v8    # "materialized\\6":Landroidx/compose/ui/Modifier;
    :cond_b
    move-object/from16 v50, v8

    .end local v8    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .restart local v50    # "materialized\\6":Landroidx/compose/ui/Modifier;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 85
    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getCorner()F

    move-result v1

    invoke-static {v7, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-static {v1}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    .line 86
    .local v1, "body\\12":Landroidx/compose/foundation/shape/RoundedCornerShape;
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    invoke-static {v7, v4}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v8

    move-object/from16 v45, v1

    .end local v1    # "body\\12":Landroidx/compose/foundation/shape/RoundedCornerShape;
    .local v45, "body\\12":Landroidx/compose/foundation/shape/RoundedCornerShape;
    invoke-static {v7, v4}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-static {v6, v8, v1}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getWidth()F

    move-result v6

    invoke-static {v7, v6}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v6

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getHeight()F

    move-result v8

    invoke-static {v7, v8}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v8

    invoke-static {v1, v6, v8}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v51

    .line 87
    const/high16 v1, 0x40800000    # 4.0f

    invoke-static {v7, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v52

    move-object/from16 v53, v45

    check-cast v53, Landroidx/compose/ui/graphics/Shape;

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v55

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v57

    const/16 v59, 0x4

    const/16 v60, 0x0

    const/16 v54, 0x0

    invoke-static/range {v51 .. v60}, Landroidx/compose/ui/draw/ShadowKt;->shadow-s4CzXII$default(Landroidx/compose/ui/Modifier;FLandroidx/compose/ui/graphics/Shape;ZJJILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v61

    .line 88
    sget-object v51, Landroidx/compose/ui/graphics/Brush;->Companion:Landroidx/compose/ui/graphics/Brush$Companion;

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getRim()Ljava/util/List;

    move-result-object v52

    const/16 v58, 0xe

    const/16 v59, 0x0

    const-wide/16 v53, 0x0

    const-wide/16 v55, 0x0

    const/16 v57, 0x0

    invoke-static/range {v51 .. v59}, Landroidx/compose/ui/graphics/Brush$Companion;->linearGradient-mHitzGk$default(Landroidx/compose/ui/graphics/Brush$Companion;Ljava/util/List;JJIILjava/lang/Object;)Landroidx/compose/ui/graphics/Brush;

    move-result-object v62

    move-object/from16 v63, v45

    check-cast v63, Landroidx/compose/ui/graphics/Shape;

    const/16 v65, 0x4

    const/16 v66, 0x0

    const/16 v64, 0x0

    invoke-static/range {v61 .. v66}, Landroidx/compose/foundation/BackgroundKt;->background$default(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Brush;Landroidx/compose/ui/graphics/Shape;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const v6, 0x3f333333    # 0.7f

    invoke-static {v7, v6}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v8

    invoke-static {v1, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 89
    move/from16 v26, v6

    move v8, v7

    .end local v7    # "scale":F
    .local v8, "scale":F
    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getFace-0d7_KjU()J

    move-result-wide v6

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getCorner()F

    move-result v51

    move/from16 v52, v4

    .end local v4    # "margin":F
    .local v52, "margin":F
    sub-float v4, v51, v26

    invoke-static {v8, v4}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v4

    invoke-static {v4}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v6, v7, v4}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 86
    const/16 v16, 0x0

    .local v1, "modifier\\13":Landroidx/compose/ui/Modifier;
    move/from16 v4, v16

    .local v4, "$changed\\13":I
    const/4 v6, 0x0

    .line 172
    .local v6, "$i$f$Box\\13\\86":I
    const v7, 0x2bb5b5d7

    invoke-static {v2, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 173
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v3

    .line 174
    .local v3, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    const/4 v7, 0x0

    .line 177
    .local v7, "propagateMinConstraints\\13":Z
    move/from16 v51, v4

    .end local v4    # "$changed\\13":I
    .local v51, "$changed\\13":I
    invoke-static {v3, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v22, v51, 0x3

    and-int/lit8 v22, v22, 0x70

    .line 178
    move/from16 v53, v22

    .local v53, "$changed\\14":I
    const/16 v54, 0x0

    .line 179
    .local v54, "$i$f$Layout\\14\\178":I
    move-object/from16 v55, v3

    const v3, -0x4ee9b9da

    .end local v3    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .local v55, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    invoke-static {v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 180
    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v5

    .line 181
    .local v5, "compositeKeyHash\\14":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 182
    .local v3, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v56, v5

    .end local v5    # "compositeKeyHash\\14":I
    .local v56, "compositeKeyHash\\14":I
    invoke-static {v2, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 184
    .local v5, "materialized\\14":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    move-object/from16 v57, v1

    .end local v1    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v57, "modifier\\13":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v53, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 183
    move-object/from16 v58, v21

    .local v1, "$changed\\15":I
    .local v58, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/16 v59, 0x0

    .line 185
    .local v59, "$i$f$ReusableComposeNode\\15\\183":I
    move/from16 v60, v1

    const v1, -0x2942ffcf

    .end local v1    # "$changed\\15":I
    .local v60, "$changed\\15":I
    invoke-static {v2, v1, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 186
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 187
    :cond_c
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 188
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_d

    .line 189
    move-object/from16 v1, v58

    .end local v58    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_8

    .line 191
    .end local v1    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v58    # "factory\\15":Lkotlin/jvm/functions/Function0;
    :cond_d
    move-object/from16 v1, v58

    .end local v58    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 193
    :goto_8
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 194
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\193\\14":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v58, v1

    .end local v1    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v58    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v9, v4, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 195
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v9, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 197
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\17":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 198
    .local v22, "$i$f$set-impl\\17\\197":I
    move-object/from16 v23, v9

    .local v23, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v61, 0x0

    .line 199
    .local v61, "$i$a$-with-Updater$set$1\\18\\198\\17":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v62

    if-nez v62, :cond_f

    move-object/from16 v62, v3

    .end local v3    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v62, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v63, v4

    .end local v4    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v63, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v56 .. v56}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e

    goto :goto_9

    :cond_e
    move-object/from16 v4, v23

    goto :goto_a

    .end local v62    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v63    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_f
    move-object/from16 v62, v3

    move-object/from16 v63, v4

    .line 200
    .end local v3    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v62    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v63    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_9
    invoke-static/range {v56 .. v56}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    invoke-static/range {v56 .. v56}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v9, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 203
    :goto_a
    nop

    .line 198
    .end local v4    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v61    # "$i$a$-with-Updater$set$1\\18\\198\\17":I
    nop

    .line 203
    nop

    .line 204
    .end local v1    # "block\\17":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\17\\197":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v9, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 205
    nop

    .line 193
    .end local v9    # "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\193\\14":I
    nop

    .line 206
    shr-int/lit8 v1, v60, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\19":I
    move-object v3, v2

    .local v3, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 207
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\19\\206\\13":I
    const v9, -0x7ff519f7    # -1.000876E-39f

    invoke-static {v3, v9, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v9, v51, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\20":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$invoke_u24lambda_u245_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v25, v3

    .local v25, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v61, 0x0

    .line 90
    .local v61, "$i$a$-Box-DeviceFrameKt$DeviceFrame$1$1$1\\20\\207\\12":I
    move-object/from16 v64, v0

    .end local v0    # "$this$invoke_u24lambda_u245_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    .local v64, "$this$invoke_u24lambda_u245_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    const v0, 0x3630ab67

    move/from16 v65, v1

    .end local v1    # "$changed\\19":I
    .local v65, "$changed\\19":I
    const-string v1, "C89@5427L128,90@5572L205:DeviceFrame.kt#o13vsk"

    move-object/from16 v66, v3

    .end local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getScreenLeft()F

    move-result v1

    sub-float v1, v1, v26

    invoke-static {v8, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getScreenTop()F

    move-result v21

    move/from16 v67, v4

    .end local v4    # "$i$a$-Layout-BoxKt$Box$1\\19\\206\\13":I
    .local v67, "$i$a$-Layout-BoxKt$Box$1\\19\\206\\13":I
    sub-float v4, v21, v26

    invoke-static {v8, v4}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v4

    invoke-static {v0, v1, v4}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getScreenWidth()F

    move-result v1

    invoke-static {v8, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getScreenHeight()F

    move-result v4

    invoke-static {v8, v4}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v4

    invoke-static {v0, v1, v4}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v16, 0x0

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v14, v0, v3, v1}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getWidth()F

    move-result v1

    div-float v1, v1, v40

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getHomeDiameter()F

    move-result v4

    div-float v4, v4, v40

    sub-float/2addr v1, v4

    sub-float v1, v1, v26

    invoke-static {v8, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getHomeCenterY()F

    move-result v4

    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getHomeDiameter()F

    move-result v14

    div-float v14, v14, v40

    sub-float/2addr v4, v14

    sub-float v4, v4, v26

    invoke-static {v8, v4}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v4

    invoke-static {v0, v1, v4}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 92
    invoke-virtual {v11}, Lorg/lighttouch/android/DeviceSkin;->getHomeDiameter()F

    move-result v1

    invoke-static {v8, v1}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v1

    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v21

    .line 91
    const/16 v26, 0x0

    move/from16 v22, v12

    move-object/from16 v23, v13

    .end local v3    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v26}, Lorg/lighttouch/android/DeviceFrameKt;->access$HomeButton(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .line 90
    move/from16 v1, v22

    move-object/from16 v3, v23

    move-object/from16 v0, v24

    .end local v24    # "haptic":Lkotlin/jvm/functions/Function0;
    .local v0, "haptic":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 93
    nop

    .line 207
    .end local v9    # "$changed\\20":I
    .end local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v61    # "$i$a$-Box-DeviceFrameKt$DeviceFrame$1$1$1\\20\\207\\12":I
    .end local v64    # "$this$invoke_u24lambda_u245_u24lambda_u242\\20":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 206
    .end local v65    # "$changed\\19":I
    .end local v66    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v67    # "$i$a$-Layout-BoxKt$Box$1\\19\\206\\13":I
    nop

    .line 208
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 185
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 209
    nop

    .line 179
    .end local v58    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .end local v59    # "$i$f$ReusableComposeNode\\15\\183":I
    .end local v60    # "$changed\\15":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 210
    nop

    .line 172
    .end local v5    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .end local v53    # "$changed\\14":I
    .end local v54    # "$i$f$Layout\\14\\178":I
    .end local v56    # "compositeKeyHash\\14":I
    .end local v62    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 211
    nop

    .end local v6    # "$i$f$Box\\13\\86":I
    .end local v7    # "propagateMinConstraints\\13":Z
    .end local v51    # "$changed\\13":I
    .end local v55    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .end local v57    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v63    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    const v4, 0x2072c204

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "*97@6160L50,96@6040L317"

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 95
    invoke-interface/range {v28 .. v28}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_b
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_12

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lkotlin/Triple;

    invoke-virtual {v5}, Lkotlin/Triple;->component1()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    .local v6, "id\\12":I
    invoke-virtual {v5}, Lkotlin/Triple;->component2()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .local v7, "label\\12":Ljava/lang/String;
    invoke-virtual {v5}, Lkotlin/Triple;->component3()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [F

    .line 96
    .local v5, "r\\12":[F
    aget v9, v5, v17

    invoke-static {v8, v9}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v9

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->box-impl(F)Landroidx/compose/ui/unit/Dp;

    move-result-object v9

    const/16 v11, 0x30

    .local v11, "$this$dp\\21":I
    const/4 v12, 0x0

    .line 212
    .local v12, "$i$f$getDp\\21\\96":I
    int-to-float v13, v11

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .end local v11    # "$this$dp\\21":I
    .end local v12    # "$i$f$getDp\\21\\96":I
    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->box-impl(F)Landroidx/compose/ui/unit/Dp;

    move-result-object v11

    .line 96
    invoke-static {v9, v11}, Lkotlin/comparisons/ComparisonsKt;->maxOf(Ljava/lang/Comparable;Ljava/lang/Comparable;)Ljava/lang/Comparable;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/unit/Dp;

    invoke-virtual {v9}, Landroidx/compose/ui/unit/Dp;->unbox-impl()F

    move-result v9

    .local v9, "w\\12":F
    aget v11, v5, v18

    invoke-static {v8, v11}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v11

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->box-impl(F)Landroidx/compose/ui/unit/Dp;

    move-result-object v11

    const/16 v12, 0x30

    .local v12, "$this$dp\\22":I
    const/4 v13, 0x0

    .line 212
    .local v13, "$i$f$getDp\\22\\96":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .end local v12    # "$this$dp\\22":I
    .end local v13    # "$i$f$getDp\\22\\96":I
    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->box-impl(F)Landroidx/compose/ui/unit/Dp;

    move-result-object v12

    .line 96
    invoke-static {v11, v12}, Lkotlin/comparisons/ComparisonsKt;->maxOf(Ljava/lang/Comparable;Ljava/lang/Comparable;)Ljava/lang/Comparable;

    move-result-object v11

    check-cast v11, Landroidx/compose/ui/unit/Dp;

    invoke-virtual {v11}, Landroidx/compose/ui/unit/Dp;->unbox-impl()F

    move-result v11

    .line 97
    .local v11, "h\\12":F
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/16 v16, 0x0

    aget v13, v5, v16

    aget v14, v5, v17

    div-float v14, v14, v40

    add-float/2addr v13, v14

    invoke-static {v8, v13}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v13

    const/4 v14, 0x2

    .local v14, "other\\23":I
    const/16 v21, 0x0

    .line 213
    .local v21, "$i$f$div-u2uoSUM\\23\\97":I
    move-object/from16 v22, v4

    int-to-float v4, v14

    div-float v4, v9, v4

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 97
    .end local v14    # "other\\23":I
    .end local v21    # "$i$f$div-u2uoSUM\\23\\97":I
    nop

    .local v4, "other\\24":F
    .local v13, "arg0\\24":F
    const/4 v14, 0x0

    .line 214
    .local v14, "$i$f$minus-5rwHm24\\24\\97":I
    sub-float v21, v13, v4

    invoke-static/range {v21 .. v21}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 97
    .end local v4    # "other\\24":F
    .end local v13    # "arg0\\24":F
    .end local v14    # "$i$f$minus-5rwHm24\\24\\97":I
    aget v13, v5, v19

    aget v14, v5, v18

    div-float v14, v14, v40

    add-float/2addr v13, v14

    invoke-static {v8, v13}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1;->invoke$mm(FF)F

    move-result v13

    const/4 v14, 0x2

    .local v14, "other\\25":I
    const/16 v21, 0x0

    .line 213
    .local v21, "$i$f$div-u2uoSUM\\25\\97":I
    move-object/from16 v23, v5

    .end local v5    # "r\\12":[F
    .local v23, "r\\12":[F
    int-to-float v5, v14

    div-float v5, v11, v5

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 97
    .end local v14    # "other\\25":I
    .end local v21    # "$i$f$div-u2uoSUM\\25\\97":I
    nop

    .local v5, "other\\26":F
    .local v13, "arg0\\26":F
    const/4 v14, 0x0

    .line 214
    .local v14, "$i$f$minus-5rwHm24\\26\\97":I
    sub-float v21, v13, v5

    invoke-static/range {v21 .. v21}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 97
    .end local v5    # "other\\26":F
    .end local v13    # "arg0\\26":F
    .end local v14    # "$i$f$minus-5rwHm24\\26\\97":I
    invoke-static {v12, v4, v5}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v4

    invoke-static {v4, v9, v11}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 98
    const v5, 0x4c5de2

    invoke-interface {v2, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    .local v5, "invalid\\27":Z
    move-object v12, v2

    .local v12, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 215
    .local v13, "$i$f$cache\\27\\98":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\27":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 216
    .local v21, "$i$a$-let-ComposerKt$cache$1\\28\\215\\27":I
    if-nez v5, :cond_11

    sget-object v24, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v25, v5

    .end local v5    # "invalid\\27":Z
    .local v25, "invalid\\27":Z
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v14, v5, :cond_10

    goto :goto_c

    .line 220
    :cond_10
    move-object v5, v14

    goto :goto_d

    .line 216
    .end local v25    # "invalid\\27":Z
    .restart local v5    # "invalid\\27":Z
    :cond_11
    move/from16 v25, v5

    .line 217
    .end local v5    # "invalid\\27":Z
    .restart local v25    # "invalid\\27":Z
    :goto_c
    const/4 v5, 0x0

    .line 98
    .local v5, "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$1$2\\29\\217\\12":I
    move/from16 v24, v5

    .end local v5    # "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$1$2\\29\\217\\12":I
    .local v24, "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$1$2\\29\\217\\12":I
    new-instance v5, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1$$ExternalSyntheticLambda1;

    invoke-direct {v5, v7}, Lorg/lighttouch/android/DeviceFrameKt$DeviceFrame$1$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V

    .line 217
    .end local v24    # "$i$a$-cache-DeviceFrameKt$DeviceFrame$1$1$2\\29\\217\\12":I
    nop

    .line 218
    .local v5, "value\\28":Ljava/lang/Object;
    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 219
    nop

    .line 216
    .end local v5    # "value\\28":Ljava/lang/Object;
    :goto_d
    nop

    .line 215
    .end local v14    # "it\\27":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\28\\215\\27":I
    nop

    .line 98
    .end local v12    # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$cache\\27\\98":I
    .end local v25    # "invalid\\27":Z
    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v12, 0x0

    move/from16 v13, v19

    const/4 v14, 0x0

    invoke-static {v4, v14, v5, v13, v12}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 99
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    const-string v12, "toLowerCase(...)"

    invoke-static {v5, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v5, Ljava/lang/CharSequence;

    new-instance v12, Lkotlin/text/Regex;

    const-string v14, "[^a-z]+"

    invoke-direct {v12, v14}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const-string v14, "_"

    invoke-virtual {v12, v5, v14}, Lkotlin/text/Regex;->replace(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "device_"

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 100
    invoke-static {v4, v1, v6, v3, v0}, Lorg/lighttouch/android/DeviceFrameKt;->held(Landroidx/compose/ui/Modifier;ZILkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 97
    const/4 v14, 0x0

    invoke-static {v4, v2, v14}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    move-object/from16 v4, v22

    .end local v6    # "id\\12":I
    .end local v7    # "label\\12":Ljava/lang/String;
    .end local v9    # "w\\12":F
    .end local v11    # "h\\12":F
    .end local v23    # "r\\12":[F
    goto/16 :goto_b

    :cond_12
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 83
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 102
    .end local v45    # "body\\12":Landroidx/compose/foundation/shape/RoundedCornerShape;
    nop

    .line 171
    .end local v2    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v42    # "$changed\\12":I
    .end local v46    # "$this$invoke_u24lambda_u245\\12":Landroidx/compose/foundation/layout/BoxScope;
    .end local v47    # "$i$a$-Box-DeviceFrameKt$DeviceFrame$1$1\\12\\171\\0":I
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 170
    .end local v41    # "$changed\\11":I
    .end local v48    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v49    # "$i$a$-Layout-BoxKt$Box$1\\11\\170\\5":I
    nop

    .line 221
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 149
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 222
    nop

    .line 143
    .end local v37    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .end local v38    # "$i$f$ReusableComposeNode\\7\\147":I
    .end local v39    # "$changed\\7":I
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 223
    nop

    .line 136
    .end local v30    # "$changed\\6":I
    .end local v31    # "$i$f$Layout\\6\\142":I
    .end local v34    # "compositeKeyHash\\6":I
    .end local v43    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "materialized\\6":Landroidx/compose/ui/Modifier;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 224
    nop

    .end local v15    # "$changed\\5":I
    .end local v20    # "$i$f$Box\\5\\82":I
    .end local v32    # "contentAlignment\\5":Landroidx/compose/ui/Alignment;
    .end local v33    # "propagateMinConstraints\\5":Z
    .end local v36    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .end local v44    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 103
    .end local v0    # "haptic":Lkotlin/jvm/functions/Function0;
    .end local v8    # "scale":F
    .end local v28    # "buttons":Ljava/util/List;
    .end local v29    # "feedback":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    .end local v35    # "side":F
    .end local v52    # "margin":F
    :cond_13
    :goto_e
    return-void
.end method

.class final Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;
.super Ljava/lang/Object;
.source "DeviceDetails.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeviceDetails.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeviceDetails.kt\norg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,189:1\n149#2:190\n149#2:227\n86#3:191\n83#3,6:192\n89#3:226\n93#3:231\n79#4,6:198\n86#4,4:213\n90#4,2:223\n94#4:230\n368#5,9:204\n377#5:225\n378#5,2:228\n4034#6,6:217\n*S KotlinDebug\n*F\n+ 1 DeviceDetails.kt\norg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2\n*L\n124#1:190\n166#1:227\n124#1:191\n124#1:192,6\n124#1:226\n124#1:231\n124#1:198,6\n124#1:213,4\n124#1:223,2\n124#1:230\n124#1:204,9\n124#1:225\n124#1:228,2\n124#1:217,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $device:Lorg/lighttouch/android/DeviceSummary;

.field final synthetic $facts$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceFacts;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $space$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceFacts$Space;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lorg/lighttouch/android/DeviceSummary;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/DeviceSummary;",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceFacts;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceFacts$Space;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->$device:Lorg/lighttouch/android/DeviceSummary;

    iput-object p2, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->$facts$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->$space$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;

    .line 123
    move-object v0, p1

    check-cast v0, Landroidx/compose/runtime/Composer;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->invoke(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/runtime/Composer;I)V
    .locals 38
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    const-string v3, "C123@7405L21,123@7360L3236:DeviceDetails.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 231
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_6

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.DeviceDetails.<anonymous>.<anonymous>.<anonymous> (DeviceDetails.kt:123)"

    const v6, -0x25498768    # -2.568052E16f

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 124
    :cond_2
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v3, v5, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/4 v3, 0x0

    invoke-static {v3, v1, v3, v6}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v9

    const/16 v13, 0xe

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v9, 0x10

    .local v9, "$this$dp\\1":I
    const/4 v10, 0x0

    .line 190
    .local v10, "$i$f$getDp\\1\\124":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 124
    .end local v9    # "$this$dp\\1":I
    .end local v10    # "$i$f$getDp\\1\\124":I
    invoke-static {v8, v9, v5, v4, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .local v4, "modifier\\2":Landroidx/compose/ui/Modifier;
    iget-object v5, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->$device:Lorg/lighttouch/android/DeviceSummary;

    iget-object v8, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->$facts$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v9, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->$space$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v10, 0x0

    .local v10, "$changed\\2":I
    const/4 v11, 0x0

    .line 191
    .local v11, "$i$f$Column\\2\\124":I
    const v12, -0x1cd0f17e

    const-string v13, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 192
    sget-object v12, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v12}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v12

    .line 193
    .local v12, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 196
    .local v13, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v14, v10, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v15, v10, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v14, v15

    invoke-static {v12, v13, v1, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v10, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 197
    nop

    .local v15, "$changed\\3":I
    const/16 v16, 0x0

    .line 198
    .local v16, "$i$f$Layout\\3\\197":I
    const v7, -0x4ee9b9da

    const-string v6, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v7, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 199
    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 200
    .local v3, "compositeKeyHash\\3":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v6

    .line 201
    .local v6, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 203
    .local v7, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v0, v15, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v19, v0

    const/4 v0, 0x6

    or-int/lit8 v19, v19, 0x6

    .line 202
    move-object/from16 v20, v18

    .local v19, "$changed\\4":I
    .local v20, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 204
    .local v18, "$i$f$ReusableComposeNode\\4\\202":I
    move/from16 v21, v0

    const v0, -0x2942ffcf

    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 205
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 206
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 207
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 208
    move-object/from16 v0, v20

    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 210
    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v0, v20

    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 212
    :goto_1
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 213
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\212\\3":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v0

    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v2, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 214
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v2, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 216
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 217
    .local v22, "$i$f$set-impl\\6\\216":I
    move-object/from16 v24, v2

    .local v24, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 218
    .local v25, "$i$a$-with-Updater$set$1\\7\\217\\6":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_6

    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v26, v3

    .end local v3    # "compositeKeyHash\\3":I
    .local v26, "compositeKeyHash\\3":I
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v3, v24

    goto :goto_3

    .end local v26    # "compositeKeyHash\\3":I
    .restart local v3    # "compositeKeyHash\\3":I
    :cond_6
    move/from16 v26, v3

    .line 219
    .end local v3    # "compositeKeyHash\\3":I
    .restart local v26    # "compositeKeyHash\\3":I
    :goto_2
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v3, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 220
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 222
    :goto_3
    nop

    .line 217
    .end local v3    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\7\\217\\6":I
    nop

    .line 222
    nop

    .line 223
    .end local v0    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\6\\216":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v2, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    nop

    .line 212
    .end local v2    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\212\\3":I
    nop

    .line 225
    shr-int/lit8 v0, v19, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object/from16 v1, p1

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 226
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\8\\225\\2":I
    const v3, -0x16ef5699

    move/from16 v20, v0

    .end local v0    # "$changed\\8":I
    .local v20, "$changed\\8":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v10, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$invoke_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v30, v1

    .local v30, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 125
    .local v22, "$i$a$-Column-DeviceDetailsKt$DeviceDetails$4$1$2$1\\9\\226\\0":I
    move-object/from16 v24, v0

    .end local v0    # "$this$invoke_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v24, "$this$invoke_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x66ca0ee6

    move-object/from16 v25, v1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C126@7578L786,126@7560L804,146@9241L597,146@9133L705,156@9881L646,156@9859L668,165@10548L30:DeviceDetails.kt#o13vsk"

    move/from16 v33, v2

    move-object/from16 v2, v30

    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v33, "$i$a$-Layout-ColumnKt$Column$1\\8\\225\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {v8}, Lorg/lighttouch/android/DeviceDetailsKt;->access$DeviceDetails$lambda$1(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/DeviceFacts;

    move-result-object v0

    .line 126
    .local v0, "f\\9":Lorg/lighttouch/android/DeviceFacts;
    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceFacts;->getIdentity()Lorg/json/JSONObject;

    move-result-object v1

    move-object/from16 v17, v1

    goto :goto_4

    :cond_7
    const/16 v17, 0x0

    :goto_4
    move-object/from16 v1, v17

    .line 127
    .local v1, "identity\\9":Lorg/json/JSONObject;
    new-instance v8, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;

    invoke-direct {v8, v5, v1}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$1;-><init>(Lorg/lighttouch/android/DeviceSummary;Lorg/json/JSONObject;)V

    .end local v1    # "identity\\9":Lorg/json/JSONObject;
    .local v17, "identity\\9":Lorg/json/JSONObject;
    const v1, 0x8c471fa

    move/from16 v34, v3

    .end local v3    # "$changed\\9":I
    .local v34, "$changed\\9":I
    const/16 v3, 0x36

    move-object/from16 v35, v4

    const/4 v4, 0x1

    .end local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v35, "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v1, v4, v8, v2, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object/from16 v29, v1

    check-cast v29, Lkotlin/jvm/functions/Function3;

    const/16 v31, 0x186

    const/16 v32, 0x2

    const-string v27, "\u8bbe\u5907"

    const/16 v28, 0x0

    move-object/from16 v30, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v32}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Section(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 136
    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual {v5}, Lorg/lighttouch/android/DeviceSummary;->getBoard()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/lighttouch/android/DeviceDetailsKt;->boardSpecs(Ljava/lang/String;)Lorg/lighttouch/android/BoardSpecs;

    move-result-object v1

    const v4, 0x1c1773df

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "*136@8548L542,136@8446L644"

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v1, :cond_8

    goto :goto_5

    .local v1, "s\\10":Lorg/lighttouch/android/BoardSpecs;
    :cond_8
    const/4 v4, 0x0

    .line 137
    .local v4, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$2\\10\\136\\9":I
    new-instance v8, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;

    invoke-direct {v8, v1, v5}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;-><init>(Lorg/lighttouch/android/BoardSpecs;Lorg/lighttouch/android/DeviceSummary;)V

    move-object/from16 v36, v1

    .end local v1    # "s\\10":Lorg/lighttouch/android/BoardSpecs;
    .local v36, "s\\10":Lorg/lighttouch/android/BoardSpecs;
    const v1, -0x17905d59

    move/from16 v37, v4

    const/4 v4, 0x1

    .end local v4    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$2\\10\\136\\9":I
    .local v37, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$2\\10\\136\\9":I
    invoke-static {v1, v4, v8, v2, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object/from16 v29, v1

    check-cast v29, Lkotlin/jvm/functions/Function3;

    const/16 v31, 0x1b6

    const/16 v32, 0x0

    const-string v27, "Hardware"

    const-string v28, "\u4e0e\u771f\u673a\u89c4\u683c\u4e00\u81f4\uff1b\u7531 LightTouch \u6a21\u62df\uff0c\u901f\u5ea6\u53d6\u51b3\u4e8e\u4f60\u7684\u624b\u673a\u3002"

    move-object/from16 v30, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v32}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Section(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 146
    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 136
    .end local v36    # "s\\10":Lorg/lighttouch/android/BoardSpecs;
    .end local v37    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$2\\10\\136\\9":I
    nop

    :goto_5
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 147
    new-instance v1, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;

    invoke-direct {v1, v0, v9}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$3;-><init>(Lorg/lighttouch/android/DeviceFacts;Landroidx/compose/runtime/MutableState;)V

    const v4, 0x75c43ae3

    const/4 v8, 0x1

    invoke-static {v4, v8, v1, v2, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object/from16 v29, v1

    check-cast v29, Lkotlin/jvm/functions/Function3;

    const/16 v31, 0x1b6

    const/16 v32, 0x0

    const-string v27, "\u5b58\u50a8"

    const-string v28, "iOS \u91ca\u653e\u7684\u7a7a\u95f4\u6682\u65f6\u4e0d\u4f1a\u5f52\u8fd8\u7ed9\u624b\u673a\uff0c\u56e0\u6b64\u8bbe\u5907\u5360\u7528\u53ea\u4f1a\u4e0d\u65ad\u589e\u957f\u3002"

    move-object/from16 v30, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v32}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Section(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 157
    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    new-instance v1, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;

    invoke-direct {v1, v0, v5}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;-><init>(Lorg/lighttouch/android/DeviceFacts;Lorg/lighttouch/android/DeviceSummary;)V

    const v4, -0x4e3b087e

    invoke-static {v4, v8, v1, v2, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object/from16 v29, v1

    check-cast v29, Lkotlin/jvm/functions/Function3;

    const/16 v31, 0x186

    const/16 v32, 0x2

    const-string v27, "LightTouch"

    const/16 v28, 0x0

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v32}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Section(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 166
    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x18

    .local v3, "$this$dp\\11":I
    const/4 v4, 0x0

    .line 227
    .local v4, "$i$f$getDp\\11\\166":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 166
    .end local v3    # "$this$dp\\11":I
    .end local v4    # "$i$f$getDp\\11\\166":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    move/from16 v3, v21

    invoke-static {v1, v2, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 125
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 167
    .end local v0    # "f\\9":Lorg/lighttouch/android/DeviceFacts;
    .end local v17    # "identity\\9":Lorg/json/JSONObject;
    nop

    .line 226
    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-Column-DeviceDetailsKt$DeviceDetails$4$1$2$1\\9\\226\\0":I
    .end local v24    # "$this$invoke_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v34    # "$changed\\9":I
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 225
    .end local v20    # "$changed\\8":I
    .end local v25    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-Layout-ColumnKt$Column$1\\8\\225\\2":I
    nop

    .line 228
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 204
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 229
    nop

    .line 198
    .end local v18    # "$i$f$ReusableComposeNode\\4\\202":I
    .end local v19    # "$changed\\4":I
    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 230
    nop

    .line 191
    .end local v6    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v7    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v15    # "$changed\\3":I
    .end local v16    # "$i$f$Layout\\3\\197":I
    .end local v26    # "compositeKeyHash\\3":I
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 231
    nop

    .end local v10    # "$changed\\2":I
    .end local v11    # "$i$f$Column\\2\\124":I
    .end local v12    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v13    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v14    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 168
    :cond_9
    :goto_6
    return-void
.end method

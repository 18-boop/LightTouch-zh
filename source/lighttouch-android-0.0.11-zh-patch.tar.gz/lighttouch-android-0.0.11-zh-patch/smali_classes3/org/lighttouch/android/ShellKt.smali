.class public final Lorg/lighttouch/android/ShellKt;
.super Ljava/lang/Object;
.source "Shell.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nShell.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Shell.kt\norg/lighttouch/android/ShellKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n*L\n1#1,141:1\n149#2:142\n149#2:149\n149#2:186\n149#2:187\n149#2:228\n149#2:270\n149#2:275\n1225#3,6:143\n1225#3,6:229\n86#4:150\n83#4,6:151\n89#4:185\n93#4:191\n86#4:192\n83#4,6:193\n89#4:227\n93#4:279\n79#5,6:157\n86#5,4:172\n90#5,2:182\n94#5:190\n79#5,6:199\n86#5,4:214\n90#5,2:224\n79#5,6:241\n86#5,4:256\n90#5,2:266\n94#5:273\n94#5:278\n368#6,9:163\n377#6:184\n378#6,2:188\n368#6,9:205\n377#6:226\n368#6,9:247\n377#6:268\n378#6,2:271\n378#6,2:276\n4034#7,6:176\n4034#7,6:218\n4034#7,6:260\n71#8:235\n69#8,5:236\n74#8:269\n78#8:274\n*S KotlinDebug\n*F\n+ 1 Shell.kt\norg/lighttouch/android/ShellKt\n*L\n89#1:142\n91#1:149\n93#1:186\n94#1:187\n123#1:228\n126#1:270\n128#1:275\n90#1:143,6\n125#1:229,6\n89#1:150\n89#1:151,6\n89#1:185\n89#1:191\n122#1:192\n122#1:193,6\n122#1:227\n122#1:279\n89#1:157,6\n89#1:172,4\n89#1:182,2\n89#1:190\n122#1:199,6\n122#1:214,4\n122#1:224,2\n123#1:241,6\n123#1:256,4\n123#1:266,2\n123#1:273\n122#1:278\n89#1:163,9\n89#1:184\n89#1:188,2\n122#1:205,9\n122#1:226\n123#1:247,9\n123#1:268\n123#1:271,2\n122#1:276,2\n89#1:176,6\n122#1:218,6\n123#1:260,6\n123#1:235\n123#1:236,5\n123#1:269\n123#1:274\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0012\u001aW\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000e2\u000c\u0010\u000f\u001a\u0008\u0012\u0004\u0012\u00020\n0\u00102\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u00122\u0008\u0008\u0002\u0010\u0013\u001a\u00020\u00012\u0008\u0008\u0002\u0010\u0014\u001a\u00020\u00152\n\u0008\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u000eH\u0001\u00a2\u0006\u0004\u0008\u0017\u0010\u0018\u001a-\u0010\u0019\u001a\u00020\n2\u0006\u0010\u001a\u001a\u00020\u000e2\u000c\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\n0\u00102\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u0012H\u0001\u00a2\u0006\u0002\u0010\u001c\u001aA\u0010\u001d\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000e2\u000c\u0010\u000f\u001a\u0008\u0012\u0004\u0012\u00020\n0\u00102\u0008\u0008\u0002\u0010\u0011\u001a\u00020\u00122\n\u0008\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u000eH\u0001\u00a2\u0006\u0002\u0010\u001e\u001a\u0010\u0010\u001f\u001a\u00020\u000e2\u0006\u0010 \u001a\u00020\u000eH\u0000\"\u0018\u0010\u0000\u001a\u00020\u0001*\u00020\u00028@X\u0080\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0003\u0010\u0004\"\u0018\u0010\u0005\u001a\u00020\u0001*\u00020\u00028@X\u0080\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0006\u0010\u0004\"\u0018\u0010\u0007\u001a\u00020\u0001*\u00020\u00028@X\u0080\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0008\u0010\u0004\"\u001a\u0010!\u001a\u00020\u0012X\u0080\u0004\u00a2\u0006\u000e\n\u0000\u0012\u0004\u0008\"\u0010#\u001a\u0004\u0008$\u0010%\u00a8\u0006&\u00b2\u0006\n\u0010\'\u001a\u00020\u0001X\u008a\u008e\u0002"
    }
    d2 = {
        "running",
        "",
        "Lorg/lighttouch/android/GuestHost;",
        "getRunning",
        "(Lorg/lighttouch/android/GuestHost;)Z",
        "paused",
        "getPaused",
        "active",
        "getActive",
        "DockButton",
        "",
        "icon",
        "Landroidx/compose/ui/graphics/vector/ImageVector;",
        "label",
        "",
        "onClick",
        "Lkotlin/Function0;",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "enabled",
        "tint",
        "Landroidx/compose/ui/graphics/Color;",
        "tag",
        "DockButton-cd68TDI",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V",
        "ErrorBanner",
        "message",
        "onDismiss",
        "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V",
        "ScreenAction",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V",
        "statusLabel",
        "status",
        "DialogTags",
        "getDialogTags$annotations",
        "()V",
        "getDialogTags",
        "()Landroidx/compose/ui/Modifier;",
        "app_debug",
        "expanded"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final DialogTags:Landroidx/compose/ui/Modifier;


# direct methods
.method public static synthetic $r8$lambda$3og-KKu9WejCW4tUaxzZk8DF4_s(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/ShellKt;->DockButton_cd68TDI$lambda$1$lambda$0(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RJYLkKx3prcPaCnprxkibH47K9w(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p8}, Lorg/lighttouch/android/ShellKt;->ScreenAction$lambda$9(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$h9tRIE0Y0aydV283US_MIg5FjOs(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/ShellKt;->DialogTags$lambda$10(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$hx10gkNCIueNP0mRHpCPViiuKUU(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/ShellKt;->ScreenAction$lambda$8$lambda$6$lambda$5(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$k5xaIwGTO72D473cUzwgUpl8ilo(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/ShellKt;->ErrorBanner$lambda$4(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$x--5NKnlNv9Z8PZR517vXWUNv-E(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p11}, Lorg/lighttouch/android/ShellKt;->DockButton_cd68TDI$lambda$3(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 5

    .line 140
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    new-instance v1, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda0;

    invoke-direct {v1}, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda0;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v4, v1, v2, v3}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/ShellKt;->DialogTags:Landroidx/compose/ui/Modifier;

    return-void
.end method

.method private static final DialogTags$lambda$10(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    const/4 v0, 0x1

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsProperties_androidKt;->setTestTagsAsResourceId(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V
    .locals 50
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "onClick"    # Lkotlin/jvm/functions/Function0;
    .param p3, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p4, "enabled"    # Z
    .param p5, "tint"    # J
    .param p7, "tag"    # Ljava/lang/String;
    .param p8, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "ZJ",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v8, p1

    move-object/from16 v5, p2

    move/from16 v9, p9

    const-string v1, "icon"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "label"

    invoke-static {v8, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "onClick"

    invoke-static {v5, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    const v1, 0x3f0ccd27    # 0.5500054f

    move-object/from16 v2, p8

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p8    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(DockButton)P(1,2,4,3!1,6:c#ui.graphics.Color)89@3688L30,88@3489L606:Shell.kt#o13vsk"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p9

    .local v2, "$dirty":I
    and-int/lit8 v3, p10, 0x1

    if-eqz v3, :cond_0

    or-int/lit8 v2, v2, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v3, v9, 0x6

    if-nez v3, :cond_2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_2
    :goto_1
    and-int/lit8 v3, p10, 0x2

    if-eqz v3, :cond_3

    or-int/lit8 v2, v2, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v3, v9, 0x30

    if-nez v3, :cond_5

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x20

    goto :goto_2

    :cond_4
    const/16 v3, 0x10

    :goto_2
    or-int/2addr v2, v3

    :cond_5
    :goto_3
    and-int/lit8 v3, p10, 0x4

    if-eqz v3, :cond_6

    or-int/lit16 v2, v2, 0x180

    goto :goto_5

    :cond_6
    and-int/lit16 v3, v9, 0x180

    if-nez v3, :cond_8

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    const/16 v3, 0x100

    goto :goto_4

    :cond_7
    const/16 v3, 0x80

    :goto_4
    or-int/2addr v2, v3

    :cond_8
    :goto_5
    and-int/lit8 v3, p10, 0x8

    if-eqz v3, :cond_9

    or-int/lit16 v2, v2, 0xc00

    move-object/from16 v4, p3

    goto :goto_7

    :cond_9
    and-int/lit16 v4, v9, 0xc00

    if-nez v4, :cond_b

    move-object/from16 v4, p3

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_a

    const/16 v6, 0x800

    goto :goto_6

    :cond_a
    const/16 v6, 0x400

    :goto_6
    or-int/2addr v2, v6

    goto :goto_7

    :cond_b
    move-object/from16 v4, p3

    :goto_7
    and-int/lit8 v6, p10, 0x10

    if-eqz v6, :cond_c

    or-int/lit16 v2, v2, 0x6000

    move/from16 v7, p4

    goto :goto_9

    :cond_c
    and-int/lit16 v7, v9, 0x6000

    if-nez v7, :cond_e

    move/from16 v7, p4

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v12

    if-eqz v12, :cond_d

    const/16 v12, 0x4000

    goto :goto_8

    :cond_d
    const/16 v12, 0x2000

    :goto_8
    or-int/2addr v2, v12

    goto :goto_9

    :cond_e
    move/from16 v7, p4

    :goto_9
    const/high16 v12, 0x30000

    and-int/2addr v12, v9

    if-nez v12, :cond_11

    and-int/lit8 v12, p10, 0x20

    if-nez v12, :cond_f

    move-wide/from16 v12, p5

    invoke-interface {v10, v12, v13}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v14

    if-eqz v14, :cond_10

    const/high16 v14, 0x20000

    goto :goto_a

    :cond_f
    move-wide/from16 v12, p5

    :cond_10
    const/high16 v14, 0x10000

    :goto_a
    or-int/2addr v2, v14

    goto :goto_b

    :cond_11
    move-wide/from16 v12, p5

    :goto_b
    and-int/lit8 v14, p10, 0x40

    const/high16 v15, 0x180000

    if-eqz v14, :cond_12

    or-int/2addr v2, v15

    move-object/from16 v15, p7

    goto :goto_d

    :cond_12
    and-int/2addr v15, v9

    if-nez v15, :cond_14

    move-object/from16 v15, p7

    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_13

    const/high16 v16, 0x100000

    goto :goto_c

    :cond_13
    const/high16 v16, 0x80000

    :goto_c
    or-int v2, v2, v16

    goto :goto_d

    :cond_14
    move-object/from16 v15, p7

    :goto_d
    const v16, 0x92493

    and-int v11, v2, v16

    const v1, 0x92492

    if-ne v11, v1, :cond_16

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_15

    goto :goto_e

    .line 191
    :cond_15
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v47, v2

    move v5, v7

    move-object/from16 v46, v10

    move-wide v6, v12

    move-object v8, v15

    goto/16 :goto_19

    .line 88
    :cond_16
    :goto_e
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startDefaults()V

    const-string v1, "87@3439L11"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v9, 0x1

    const v11, -0x70001

    if-eqz v1, :cond_19

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getDefaultsInvalid()Z

    move-result v1

    if-eqz v1, :cond_17

    goto :goto_f

    :cond_17
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    and-int/lit8 v1, p10, 0x20

    if-eqz v1, :cond_18

    and-int/2addr v2, v11

    move-object v11, v4

    move-object v14, v15

    move v15, v2

    move v2, v7

    goto :goto_11

    :cond_18
    move-object v11, v4

    move-object v14, v15

    move v15, v2

    move v2, v7

    goto :goto_11

    :cond_19
    :goto_f
    if-eqz v3, :cond_1a

    .line 87
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .end local p3    # "modifier":Landroidx/compose/ui/Modifier;
    .local v1, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_10

    .line 88
    .end local v1    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p3    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_1a
    move-object v1, v4

    .line 87
    .end local p3    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v1    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_10
    if-eqz v6, :cond_1b

    .line 88
    const/4 v3, 0x1

    move v7, v3

    .end local p4    # "enabled":Z
    .local v7, "enabled":Z
    :cond_1b
    and-int/lit8 v3, p10, 0x20

    if-eqz v3, :cond_1c

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v10, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v3

    .end local p5    # "tint":J
    .local v3, "tint":J
    and-int/2addr v2, v11

    move-wide v12, v3

    .end local v3    # "tint":J
    .local v12, "tint":J
    :cond_1c
    if-eqz v14, :cond_1d

    const/4 v3, 0x0

    move-object v11, v1

    move v15, v2

    move-object v14, v3

    move v2, v7

    .end local p7    # "tag":Ljava/lang/String;
    .local v3, "tag":Ljava/lang/String;
    goto :goto_11

    .end local v3    # "tag":Ljava/lang/String;
    .restart local p7    # "tag":Ljava/lang/String;
    :cond_1d
    move-object v11, v1

    move-object v14, v15

    move v15, v2

    move v2, v7

    .end local v1    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v7    # "enabled":Z
    .end local p7    # "tag":Ljava/lang/String;
    .local v2, "enabled":Z
    .local v11, "modifier":Landroidx/compose/ui/Modifier;
    .local v14, "tag":Ljava/lang/String;
    .local v15, "$dirty":I
    :goto_11
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endDefaults()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1e

    const/4 v1, -0x1

    const-string v3, "org.lighttouch.android.DockButton (Shell.kt:87)"

    const v4, 0x3f0ccd27    # 0.5500054f

    invoke-static {v4, v15, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 89
    :cond_1e
    const/16 v1, 0xe

    .local v1, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 142
    .local v3, "$i$f$getDp\\1\\89":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 89
    .end local v1    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\89":I
    invoke-static {v1}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    check-cast v1, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v11, v1}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 90
    move/from16 v25, v2

    .end local v2    # "enabled":Z
    .local v25, "enabled":Z
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    if-eqz v14, :cond_1f

    invoke-static {v2, v14}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    :cond_1f
    invoke-interface {v1, v2}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const v2, 0x4c5de2

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):Shell.kt#9igjgp"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v15, 0x70

    const/16 v5, 0x20

    if-ne v2, v5, :cond_20

    const/4 v2, 0x1

    goto :goto_12

    :cond_20
    const/4 v2, 0x0

    .local v2, "invalid\\2":Z
    :goto_12
    move-object v5, v10

    .local v5, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 143
    .local v6, "$i$f$cache\\2\\90":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\2":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 144
    .local v16, "$i$a$-let-ComposerKt$cache$1\\3\\143\\2":I
    if-nez v2, :cond_22

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v7, v3, :cond_21

    goto :goto_13

    .line 148
    :cond_21
    move-object v4, v7

    goto :goto_14

    .line 145
    :cond_22
    :goto_13
    const/4 v3, 0x0

    .line 90
    .local v3, "$i$a$-cache-ShellKt$DockButton$1\\4\\145\\0":I
    new-instance v4, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda4;

    invoke-direct {v4, v8}, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;)V

    .line 145
    .end local v3    # "$i$a$-cache-ShellKt$DockButton$1\\4\\145\\0":I
    nop

    .line 146
    .local v4, "value\\3":Ljava/lang/Object;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 147
    nop

    .line 144
    .end local v4    # "value\\3":Ljava/lang/Object;
    :goto_14
    nop

    .line 143
    .end local v7    # "it\\2":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\3\\143\\2":I
    nop

    .line 90
    .end local v2    # "invalid\\2":Z
    .end local v5    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\2\\90":I
    check-cast v4, Lkotlin/jvm/functions/Function1;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v2, 0x1

    invoke-static {v1, v2, v4}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 91
    const/4 v2, 0x4

    .local v2, "$this$dp\\5":I
    const/4 v3, 0x0

    .line 149
    .local v3, "$i$f$getDp\\5\\91":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 91
    .end local v2    # "$this$dp\\5":I
    .end local v3    # "$i$f$getDp\\5\\91":I
    const/16 v3, 0x8

    .local v3, "$this$dp\\6":I
    const/4 v4, 0x0

    .line 149
    .local v4, "$i$f$getDp\\6\\91":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 91
    .end local v3    # "$this$dp\\6":I
    .end local v4    # "$i$f$getDp\\6\\91":I
    invoke-static {v1, v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    if-eqz v25, :cond_23

    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_15

    :cond_23
    const v2, 0x3ec28f5c    # 0.38f

    :goto_15
    invoke-static {v1, v2}, Landroidx/compose/ui/draw/AlphaKt;->alpha(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 92
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v2

    .line 89
    const/16 v3, 0x180

    move/from16 v26, v3

    .local v1, "modifier\\7":Landroidx/compose/ui/Modifier;
    .local v2, "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .local v26, "$changed\\7":I
    const/16 v27, 0x0

    .line 150
    .local v27, "$i$f$Column\\7\\89":I
    const v3, -0x1cd0f17e

    const-string v4, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 151
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v3

    .line 155
    .local v3, "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v4, v26, 0x3

    and-int/lit8 v4, v4, 0xe

    shr-int/lit8 v5, v26, 0x3

    and-int/lit8 v5, v5, 0x70

    or-int/2addr v4, v5

    invoke-static {v3, v2, v10, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v5, v26, 0x3

    and-int/lit8 v5, v5, 0x70

    .line 156
    move/from16 v28, v5

    .local v28, "$changed\\8":I
    const/16 v29, 0x0

    .line 157
    .local v29, "$i$f$Layout\\8\\156":I
    const v5, -0x4ee9b9da

    const-string v6, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 158
    const/4 v5, 0x0

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v30

    .line 159
    .local v30, "compositeKeyHash\\8":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 160
    .local v5, "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 162
    .local v6, "materialized\\8":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v7

    shl-int/lit8 v0, v28, 0x6

    and-int/lit16 v0, v0, 0x380

    move-object/from16 p3, v1

    .end local v1    # "modifier\\7":Landroidx/compose/ui/Modifier;
    .local p3, "modifier\\7":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x6

    or-int/2addr v0, v1

    .line 161
    move/from16 v31, v0

    .local v31, "$changed\\9":I
    move-object v0, v7

    .local v0, "factory\\9":Lkotlin/jvm/functions/Function0;
    const/16 v32, 0x0

    .line 163
    .local v32, "$i$f$ReusableComposeNode\\9\\161":I
    const v7, -0x2942ffcf

    move/from16 p4, v1

    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 164
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_24

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 165
    :cond_24
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 166
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_25

    .line 167
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_16

    .line 169
    :cond_25
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 171
    :goto_16
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 172
    .local v7, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\10\\171\\8":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 p5, v0

    .end local v0    # "factory\\9":Lkotlin/jvm/functions/Function0;
    .local p5, "factory\\9":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 173
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v5, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 175
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\11":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 176
    .local v16, "$i$f$set-impl\\11\\175":I
    move-object/from16 p6, v1

    .local p6, "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 177
    .local v17, "$i$a$-with-Updater$set$1\\12\\176\\11":I
    invoke-interface/range {p6 .. p6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v18

    if-nez v18, :cond_27

    move-object/from16 p7, v2

    .end local v2    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .local p7, "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-interface/range {p6 .. p6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 p8, v3

    .end local v3    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local p8, "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v30 .. v30}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_26

    goto :goto_17

    :cond_26
    move-object/from16 v3, p6

    goto :goto_18

    .end local p7    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .end local p8    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v2    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v3    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_27
    move-object/from16 p7, v2

    move-object/from16 p8, v3

    .line 178
    .end local v2    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v3    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local p7    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local p8    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_17
    invoke-static/range {v30 .. v30}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, p6

    .end local p6    # "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 179
    invoke-static/range {v30 .. v30}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 181
    :goto_18
    nop

    .line 176
    .end local v3    # "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-with-Updater$set$1\\12\\176\\11":I
    nop

    .line 181
    nop

    .line 182
    .end local v0    # "block\\11":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\11\\175":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 183
    nop

    .line 171
    .end local v1    # "$this$Layout_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\10\\171\\8":I
    nop

    .line 184
    shr-int/lit8 v0, v31, 0x6

    and-int/lit8 v33, v0, 0xe

    .local v33, "$changed\\13":I
    move-object v0, v10

    .local v0, "$composer\\13":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 185
    .local v34, "$i$a$-Layout-ColumnKt$Column$1\\13\\184\\7":I
    const v1, -0x16ef5699

    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v2, v26, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v35, v2, 0x6

    .local v35, "$changed\\14":I
    move-object/from16 v36, v1

    check-cast v36, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, v5

    .end local v5    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .local v1, "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .local v36, "$this$DockButton_cd68TDI_u24lambda_u242\\14":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v5, v0

    .local v5, "$composer\\14":Landroidx/compose/runtime/Composer;
    const/16 v37, 0x0

    .line 93
    .local v37, "$i$a$-Column-ShellKt$DockButton$2\\14\\185\\0":I
    const v2, 0x6a020b32

    const-string v3, "C92@3877L51,93@3937L29,94@4009L10,94@3975L114:Shell.kt#o13vsk"

    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x18

    .local v3, "$this$dp\\15":I
    const/4 v7, 0x0

    .line 186
    .local v7, "$i$f$getDp\\15\\93":I
    move-object/from16 p6, v0

    .end local v0    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local p6, "$composer\\13":Landroidx/compose/runtime/Composer;
    int-to-float v0, v3

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 93
    .end local v3    # "$this$dp\\15":I
    .end local v7    # "$i$f$getDp\\15\\93":I
    invoke-static {v2, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    and-int/lit8 v0, v15, 0xe

    or-int/lit16 v0, v0, 0x1b0

    shr-int/lit8 v3, v15, 0x6

    and-int/lit16 v3, v3, 0x1c00

    or-int/2addr v0, v3

    const/4 v7, 0x0

    move-object v3, v1

    .end local v1    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v1, 0x0

    move-object/from16 v39, p3

    move-object/from16 v44, p5

    move-object/from16 v45, p6

    move-object/from16 v38, p7

    move-object/from16 v40, p8

    move-object/from16 v42, v3

    move-object/from16 v41, v4

    move-object/from16 v43, v6

    move-wide v3, v12

    move/from16 v12, p4

    move v6, v0

    move-object/from16 v0, p0

    .end local v4    # "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v6    # "materialized\\8":Landroidx/compose/ui/Modifier;
    .end local v12    # "tint":J
    .end local p3    # "modifier\\7":Landroidx/compose/ui/Modifier;
    .end local p5    # "factory\\9":Lkotlin/jvm/functions/Function0;
    .end local p6    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local p7    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .end local p8    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v3, "tint":J
    .local v38, "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .local v39, "modifier\\7":Landroidx/compose/ui/Modifier;
    .local v40, "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v41, "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v42, "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .local v43, "materialized\\8":Landroidx/compose/ui/Modifier;
    .local v44, "factory\\9":Lkotlin/jvm/functions/Function0;
    .local v45, "$composer\\13":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v7}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 94
    move-wide v2, v3

    .end local v3    # "tint":J
    .local v2, "tint":J
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x4

    .local v1, "$this$dp\\16":I
    const/4 v4, 0x0

    .line 187
    .local v4, "$i$f$getDp\\16\\94":I
    int-to-float v6, v1

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 94
    .end local v1    # "$this$dp\\16":I
    .end local v4    # "$i$f$getDp\\16\\94":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {v0, v5, v12}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 95
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v5, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v0, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v12

    shr-int/lit8 v0, v15, 0x3

    and-int/lit8 v0, v0, 0xe

    shr-int/lit8 v1, v15, 0x9

    and-int/lit16 v1, v1, 0x380

    or-int v22, v0, v1

    const/16 v23, 0xc00

    const v24, 0xddfa

    const/4 v1, 0x0

    move-object/from16 v21, v5

    .end local v5    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\14":Landroidx/compose/runtime/Composer;
    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v0, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v0, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v9, 0x0

    move-object v13, v11

    .end local v11    # "modifier":Landroidx/compose/ui/Modifier;
    .local v13, "modifier":Landroidx/compose/ui/Modifier;
    const/4 v11, 0x0

    move-object/from16 v16, v13

    move-object/from16 v17, v14

    .end local v13    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v14    # "tag":Ljava/lang/String;
    .local v16, "modifier":Landroidx/compose/ui/Modifier;
    .local v17, "tag":Ljava/lang/String;
    const-wide/16 v13, 0x0

    move/from16 v18, v15

    .end local v15    # "$dirty":I
    .local v18, "$dirty":I
    const/4 v15, 0x0

    move-object/from16 v19, v16

    .end local v16    # "modifier":Landroidx/compose/ui/Modifier;
    .local v19, "modifier":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    move-object/from16 v46, v17

    .end local v17    # "tag":Ljava/lang/String;
    .local v46, "tag":Ljava/lang/String;
    const/16 v17, 0x1

    move/from16 v47, v18

    .end local v18    # "$dirty":I
    .local v47, "$dirty":I
    const/16 v18, 0x0

    move-object/from16 v48, v19

    .end local v19    # "modifier":Landroidx/compose/ui/Modifier;
    .local v48, "modifier":Landroidx/compose/ui/Modifier;
    const/16 v19, 0x0

    move-object/from16 v49, v46

    move-object/from16 v46, v0

    move-object/from16 v0, p1

    .end local v0    # "$composer":Landroidx/compose/runtime/Composer;
    .local v46, "$composer":Landroidx/compose/runtime/Composer;
    .local v49, "tag":Ljava/lang/String;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 93
    move-object/from16 v5, v21

    .end local v21    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 96
    nop

    .line 185
    .end local v5    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local v35    # "$changed\\14":I
    .end local v36    # "$this$DockButton_cd68TDI_u24lambda_u242\\14":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v37    # "$i$a$-Column-ShellKt$DockButton$2\\14\\185\\0":I
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 184
    .end local v33    # "$changed\\13":I
    .end local v34    # "$i$a$-Layout-ColumnKt$Column$1\\13\\184\\7":I
    .end local v45    # "$composer\\13":Landroidx/compose/runtime/Composer;
    nop

    .line 188
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 163
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 189
    nop

    .line 157
    .end local v31    # "$changed\\9":I
    .end local v32    # "$i$f$ReusableComposeNode\\9\\161":I
    .end local v44    # "factory\\9":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 190
    nop

    .line 150
    .end local v28    # "$changed\\8":I
    .end local v29    # "$i$f$Layout\\8\\156":I
    .end local v30    # "compositeKeyHash\\8":I
    .end local v42    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v43    # "materialized\\8":Landroidx/compose/ui/Modifier;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 191
    nop

    .end local v26    # "$changed\\7":I
    .end local v27    # "$i$f$Column\\7\\89":I
    .end local v38    # "horizontalAlignment\\7":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v39    # "modifier\\7":Landroidx/compose/ui/Modifier;
    .end local v40    # "verticalArrangement\\7":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v41    # "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_28

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_28
    move-wide v6, v2

    move/from16 v5, v25

    move-object/from16 v4, v48

    move-object/from16 v8, v49

    .end local v2    # "tint":J
    .end local v25    # "enabled":Z
    .end local v48    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v49    # "tag":Ljava/lang/String;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    .local v5, "enabled":Z
    .local v6, "tint":J
    .local v8, "tag":Ljava/lang/String;
    :goto_19
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_29

    new-instance v0, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda5;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v9, p9

    move/from16 v10, p10

    invoke-direct/range {v0 .. v10}, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda5;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;II)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 97
    :cond_29
    return-void
.end method

.method private static final DockButton_cd68TDI$lambda$1$lambda$0(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DockButton_cd68TDI$lambda$3(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 12

    or-int/lit8 v0, p8, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v10

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move/from16 v5, p4

    move-wide/from16 v6, p5

    move-object/from16 v8, p7

    move/from16 v11, p9

    move-object/from16 v9, p10

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/ShellKt;->DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final ErrorBanner(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V
    .locals 15
    .param p0, "message"    # Ljava/lang/String;
    .param p1, "onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v2, p1

    move/from16 v4, p4

    const-string v0, "message"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDismiss"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 101
    const v0, -0x2d2c067c

    move-object/from16 v1, p3

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(ErrorBanner)P(!1,2)101@4326L1115,101@4275L1166:Shell.kt#o13vsk"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p4

    .local v1, "$dirty":I
    and-int/lit8 v3, p5, 0x1

    if-eqz v3, :cond_0

    or-int/lit8 v1, v1, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v3, v4, 0x6

    if-nez v3, :cond_2

    invoke-interface {v11, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v1, v3

    :cond_2
    :goto_1
    and-int/lit8 v3, p5, 0x2

    if-eqz v3, :cond_3

    or-int/lit8 v1, v1, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v3, v4, 0x30

    if-nez v3, :cond_5

    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x20

    goto :goto_2

    :cond_4
    const/16 v3, 0x10

    :goto_2
    or-int/2addr v1, v3

    :cond_5
    :goto_3
    and-int/lit8 v3, p5, 0x4

    if-eqz v3, :cond_6

    or-int/lit16 v1, v1, 0x180

    move-object/from16 v5, p2

    goto :goto_5

    :cond_6
    and-int/lit16 v5, v4, 0x180

    if-nez v5, :cond_8

    move-object/from16 v5, p2

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    const/16 v6, 0x100

    goto :goto_4

    :cond_7
    const/16 v6, 0x80

    :goto_4
    or-int/2addr v1, v6

    goto :goto_5

    :cond_8
    move-object/from16 v5, p2

    :goto_5
    move v14, v1

    .end local v1    # "$dirty":I
    .local v14, "$dirty":I
    and-int/lit16 v1, v14, 0x93

    const/16 v6, 0x92

    if-ne v1, v6, :cond_a

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_9

    goto :goto_6

    .line 102
    :cond_9
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v3, v5

    goto :goto_9

    .line 101
    :cond_a
    :goto_6
    if-eqz v3, :cond_b

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    move-object v6, v1

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v1, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_7

    .end local v1    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p2    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_b
    move-object v6, v5

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v6, "modifier":Landroidx/compose/ui/Modifier;
    :goto_7
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_c

    const/4 v1, -0x1

    const-string v3, "org.lighttouch.android.ErrorBanner (Shell.kt:100)"

    invoke-static {v0, v14, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 102
    :cond_c
    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x1

    if-lez v0, :cond_d

    move v5, v1

    goto :goto_8

    :cond_d
    const/4 v0, 0x0

    move v5, v0

    :goto_8
    new-instance v0, Lorg/lighttouch/android/ShellKt$ErrorBanner$1;

    invoke-direct {v0, p0, v2}, Lorg/lighttouch/android/ShellKt$ErrorBanner$1;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    const/16 v3, 0x36

    const v7, 0x37fa2c5c

    invoke-static {v7, v1, v0, v11, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lkotlin/jvm/functions/Function3;

    shr-int/lit8 v0, v14, 0x3

    and-int/lit8 v0, v0, 0x70

    const/high16 v1, 0x30000

    or-int v12, v0, v1

    const/16 v13, 0x1c

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v5 .. v13}, Landroidx/compose/animation/AnimatedVisibilityKt;->AnimatedVisibility(ZLandroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransition;Landroidx/compose/animation/ExitTransition;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_e
    move-object v3, v6

    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "modifier":Landroidx/compose/ui/Modifier;
    :goto_9
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_f

    new-instance v0, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda3;

    move-object v1, p0

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;II)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 117
    :cond_f
    return-void
.end method

.method private static final ErrorBanner$lambda$4(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v6, p4

    move-object v4, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/ShellKt;->ErrorBanner(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V
    .locals 57
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "onClick"    # Lkotlin/jvm/functions/Function0;
    .param p3, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p4, "tag"    # Ljava/lang/String;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v8, p1

    move-object/from16 v3, p2

    move/from16 v9, p6

    const-string v1, "icon"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "label"

    invoke-static {v8, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "onClick"

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 121
    const v1, 0x6ff080dd

    move-object/from16 v2, p5

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(ScreenAction)P(!2,3)121@5660L635:Shell.kt#o13vsk"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p6

    .local v2, "$dirty":I
    and-int/lit8 v4, p7, 0x1

    if-eqz v4, :cond_0

    or-int/lit8 v2, v2, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v4, v9, 0x6

    if-nez v4, :cond_2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v2, v4

    :cond_2
    :goto_1
    and-int/lit8 v4, p7, 0x2

    if-eqz v4, :cond_3

    or-int/lit8 v2, v2, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_5

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    const/16 v4, 0x20

    goto :goto_2

    :cond_4
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v2, v4

    :cond_5
    :goto_3
    and-int/lit8 v4, p7, 0x4

    if-eqz v4, :cond_6

    or-int/lit16 v2, v2, 0x180

    goto :goto_5

    :cond_6
    and-int/lit16 v4, v9, 0x180

    if-nez v4, :cond_8

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_7

    const/16 v4, 0x100

    goto :goto_4

    :cond_7
    const/16 v4, 0x80

    :goto_4
    or-int/2addr v2, v4

    :cond_8
    :goto_5
    and-int/lit8 v4, p7, 0x8

    if-eqz v4, :cond_9

    or-int/lit16 v2, v2, 0xc00

    move-object/from16 v5, p3

    goto :goto_7

    :cond_9
    and-int/lit16 v5, v9, 0xc00

    if-nez v5, :cond_b

    move-object/from16 v5, p3

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_a

    const/16 v6, 0x800

    goto :goto_6

    :cond_a
    const/16 v6, 0x400

    :goto_6
    or-int/2addr v2, v6

    goto :goto_7

    :cond_b
    move-object/from16 v5, p3

    :goto_7
    and-int/lit8 v6, p7, 0x10

    if-eqz v6, :cond_c

    or-int/lit16 v2, v2, 0x6000

    move-object/from16 v7, p4

    goto :goto_9

    :cond_c
    and-int/lit16 v7, v9, 0x6000

    if-nez v7, :cond_e

    move-object/from16 v7, p4

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_d

    const/16 v12, 0x4000

    goto :goto_8

    :cond_d
    const/16 v12, 0x2000

    :goto_8
    or-int/2addr v2, v12

    goto :goto_9

    :cond_e
    move-object/from16 v7, p4

    :goto_9
    move v12, v2

    .end local v2    # "$dirty":I
    .local v12, "$dirty":I
    and-int/lit16 v2, v12, 0x2493

    const/16 v13, 0x2492

    if-ne v2, v13, :cond_10

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_f

    goto :goto_a

    .line 279
    :cond_f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v4, v5

    move-object v5, v7

    move-object/from16 v43, v10

    move/from16 v41, v12

    goto/16 :goto_16

    .line 121
    :cond_10
    :goto_a
    if-eqz v4, :cond_11

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v25, v2

    .end local p3    # "modifier":Landroidx/compose/ui/Modifier;
    .local v2, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_b

    .end local v2    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p3    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_11
    move-object/from16 v25, v5

    .end local p3    # "modifier":Landroidx/compose/ui/Modifier;
    .local v25, "modifier":Landroidx/compose/ui/Modifier;
    :goto_b
    if-eqz v6, :cond_12

    const/4 v2, 0x0

    move-object v13, v2

    .end local p4    # "tag":Ljava/lang/String;
    .local v2, "tag":Ljava/lang/String;
    goto :goto_c

    .end local v2    # "tag":Ljava/lang/String;
    .restart local p4    # "tag":Ljava/lang/String;
    :cond_12
    move-object v13, v7

    .end local p4    # "tag":Ljava/lang/String;
    .local v13, "tag":Ljava/lang/String;
    :goto_c
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_13

    const/4 v2, -0x1

    const-string v4, "org.lighttouch.android.ScreenAction (Shell.kt:120)"

    invoke-static {v1, v12, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 122
    :cond_13
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v14

    .local v14, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v1, v12, 0x9

    and-int/lit8 v1, v1, 0xe

    or-int/lit16 v15, v1, 0x180

    .local v15, "$changed\\1":I
    move-object/from16 v1, v25

    .local v1, "modifier\\1":Landroidx/compose/ui/Modifier;
    const/16 v26, 0x0

    .line 192
    .local v26, "$i$f$Column\\1\\122":I
    const v2, -0x1cd0f17e

    const-string v4, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 193
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v2

    .line 197
    .local v2, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v4, v15, 0x3

    and-int/lit8 v4, v4, 0xe

    shr-int/lit8 v5, v15, 0x3

    and-int/lit8 v5, v5, 0x70

    or-int/2addr v4, v5

    invoke-static {v2, v14, v10, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v5, v15, 0x3

    and-int/lit8 v5, v5, 0x70

    .line 198
    move/from16 v27, v5

    .local v27, "$changed\\2":I
    const/16 v28, 0x0

    .line 199
    .local v28, "$i$f$Layout\\2\\198":I
    const v5, -0x4ee9b9da

    const-string v6, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 200
    const/4 v7, 0x0

    invoke-static {v10, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 201
    .local v29, "compositeKeyHash\\2":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 202
    .local v9, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 p3, v14

    .end local v14    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local p3, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v10, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 204
    .local v14, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v5, v27, 0x6

    and-int/lit16 v5, v5, 0x380

    const/4 v11, 0x6

    or-int/2addr v5, v11

    .line 203
    move/from16 v30, v5

    .local v30, "$changed\\3":I
    move-object/from16 v5, v16

    .local v5, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v31, 0x0

    .line 205
    .local v31, "$i$f$ReusableComposeNode\\3\\203":I
    move/from16 v16, v11

    const v11, -0x2942ffcf

    move-object/from16 v17, v2

    .end local v2    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v17, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v11, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 206
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 207
    :cond_14
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 208
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_15

    .line 209
    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 211
    :cond_15
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 213
    :goto_d
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 214
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\213\\2":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v7, v4, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 215
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v7, v9, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 217
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    .local v11, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 218
    .local v20, "$i$f$set-impl\\5\\217":I
    move-object/from16 v22, v7

    .local v22, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 219
    .local v23, "$i$a$-with-Updater$set$1\\6\\218\\5":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_17

    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v24, v1

    .end local v1    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\1":Landroidx/compose/ui/Modifier;
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_16

    goto :goto_e

    :cond_16
    move-object/from16 v1, v22

    goto :goto_f

    .end local v24    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .restart local v1    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :cond_17
    move-object/from16 v24, v1

    .line 220
    .end local v1    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .restart local v24    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :goto_e
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, v22

    .end local v22    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v1, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 221
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v7, v0, v11}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 223
    :goto_f
    nop

    .line 218
    .end local v1    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-with-Updater$set$1\\6\\218\\5":I
    nop

    .line 223
    nop

    .line 224
    .end local v11    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v20    # "$i$f$set-impl\\5\\217":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v7, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 225
    nop

    .line 213
    .end local v7    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\213\\2":I
    nop

    .line 226
    shr-int/lit8 v0, v30, 0x6

    and-int/lit8 v32, v0, 0xe

    .local v32, "$changed\\7":I
    move-object v0, v10

    .local v0, "$composer\\7":Landroidx/compose/runtime/Composer;
    move-object v11, v0

    .end local v0    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 227
    .local v33, "$i$a$-Layout-ColumnKt$Column$1\\7\\226\\1":I
    const v0, -0x16ef5699

    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v11, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v1, v15, 0x6

    and-int/lit8 v1, v1, 0x70

    or-int/lit8 v34, v1, 0x6

    .local v34, "$changed\\8":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$ScreenAction_u24lambda_u248\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v1, v11

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    move-object/from16 v35, v0

    .end local v0    # "$this$ScreenAction_u24lambda_u248\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v35, "$this$ScreenAction_u24lambda_u248\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const/16 v36, 0x0

    .line 123
    .local v36, "$i$a$-Column-ShellKt$ScreenAction$1\\8\\227\\0":I
    const v0, 0x565a7baa

    const-string v7, "C124@5963L30,122@5739L375,127@6123L30,128@6196L10,128@6162L127:Shell.kt#o13vsk"

    invoke-static {v1, v0, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x40

    .local v7, "$this$dp\\9":I
    const/16 v19, 0x0

    .line 228
    .local v19, "$i$f$getDp\\9\\123":I
    move-object/from16 v20, v1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\8":Landroidx/compose/runtime/Composer;
    int-to-float v1, v7

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 123
    .end local v7    # "$this$dp\\9":I
    .end local v19    # "$i$f$getDp\\9\\123":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v37

    const/16 v43, 0xe

    const/16 v44, 0x0

    const v39, 0x3e0f5c29    # 0.14f

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    move-object v7, v2

    invoke-static/range {v37 .. v44}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v1

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v19

    move-object/from16 v3, v19

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    check-cast v1, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v1}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 124
    move-object v0, v6

    const/4 v6, 0x7

    move-object v2, v7

    const/4 v7, 0x0

    move-object v3, v2

    const/4 v2, 0x0

    move-object/from16 v19, v3

    const/4 v3, 0x0

    move-object/from16 v22, v4

    .end local v4    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v22, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v4, 0x0

    move-object/from16 v40, v5

    move-object/from16 p4, v9

    move-object/from16 v38, v17

    move-object/from16 v9, v19

    move-object/from16 v39, v22

    move-object/from16 v37, v24

    move-object/from16 v5, p2

    move-object/from16 v17, v10

    move-object/from16 v19, v11

    const v11, -0x4ee9b9da

    move-object v10, v0

    move-object/from16 v0, v20

    .end local v5    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v9    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v11    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v20    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v22    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v37, "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v38, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v39, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v40, "factory\\3":Lkotlin/jvm/functions/Function0;
    .local p4, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    if-eqz v13, :cond_18

    invoke-static {v2, v13}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    :cond_18
    invoke-interface {v1, v2}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 125
    const v2, 0x4c5de2

    invoke-interface {v0, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):Shell.kt#9igjgp"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v12, 0x70

    const/16 v3, 0x20

    if-ne v2, v3, :cond_19

    const/4 v2, 0x1

    goto :goto_10

    :cond_19
    const/4 v2, 0x0

    .local v2, "invalid\\10":Z
    :goto_10
    move-object v3, v0

    .local v3, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 229
    .local v4, "$i$f$cache\\10\\125":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\10":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 230
    .local v6, "$i$a$-let-ComposerKt$cache$1\\11\\229\\10":I
    if-nez v2, :cond_1b

    sget-object v20, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v5, v11, :cond_1a

    goto :goto_11

    .line 234
    :cond_1a
    move-object v7, v5

    goto :goto_12

    .line 231
    :cond_1b
    :goto_11
    const/4 v11, 0x0

    .line 125
    .local v11, "$i$a$-cache-ShellKt$ScreenAction$1$1\\12\\231\\8":I
    new-instance v7, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda1;

    invoke-direct {v7, v8}, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V

    .line 231
    .end local v11    # "$i$a$-cache-ShellKt$ScreenAction$1$1\\12\\231\\8":I
    nop

    .line 232
    .local v7, "value\\11":Ljava/lang/Object;
    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 233
    nop

    .line 230
    .end local v7    # "value\\11":Ljava/lang/Object;
    :goto_12
    nop

    .line 229
    .end local v5    # "it\\10":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\11\\229\\10":I
    nop

    .line 125
    .end local v2    # "invalid\\10":Z
    .end local v3    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\10\\125":I
    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v3, v7, v4, v2}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v2

    .line 123
    move-object v11, v2

    .local v11, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    const/16 v2, 0x30

    move/from16 v20, v2

    .local v1, "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v20, "$changed\\13":I
    const/16 v23, 0x0

    .line 235
    .local v23, "$i$f$Box\\13\\123":I
    const v2, 0x2bb5b5d7

    const-string v3, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v0, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 236
    const/4 v2, 0x0

    .line 239
    .local v2, "propagateMinConstraints\\13":Z
    invoke-static {v11, v2}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .local v3, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v4, v20, 0x3

    and-int/lit8 v4, v4, 0x70

    .line 240
    move/from16 v24, v4

    .local v24, "$changed\\14":I
    const/16 v41, 0x0

    .line 241
    .local v41, "$i$f$Layout\\14\\240":I
    const v4, -0x4ee9b9da

    invoke-static {v0, v4, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 242
    const/4 v4, 0x0

    invoke-static {v0, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v10

    .line 243
    .local v10, "compositeKeyHash\\14":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 244
    .local v4, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v0, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 246
    .local v5, "materialized\\14":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v6

    shl-int/lit8 v7, v24, 0x6

    and-int/lit16 v7, v7, 0x380

    or-int/lit8 v7, v7, 0x6

    .line 245
    nop

    .local v6, "factory\\15":Lkotlin/jvm/functions/Function0;
    move/from16 v18, v7

    .local v18, "$changed\\15":I
    const/16 v22, 0x0

    .line 247
    .local v22, "$i$f$ReusableComposeNode\\15\\245":I
    const v7, -0x2942ffcf

    invoke-static {v0, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 248
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 249
    :cond_1c
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 250
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_1d

    .line 251
    invoke-interface {v0, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_13

    .line 253
    :cond_1d
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 255
    :goto_13
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 256
    .local v9, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\255\\14":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v42, v0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v7, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 257
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v7, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 259
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\17":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 260
    .local v21, "$i$f$set-impl\\17\\259":I
    move-object/from16 p5, v7

    .local p5, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 261
    .local v43, "$i$a$-with-Updater$set$1\\18\\260\\17":I
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_1f

    move-object/from16 v44, v1

    .end local v1    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v44, "modifier\\13":Landroidx/compose/ui/Modifier;
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v45, v2

    .end local v2    # "propagateMinConstraints\\13":Z
    .local v45, "propagateMinConstraints\\13":Z
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    goto :goto_14

    :cond_1e
    move-object/from16 v2, p5

    goto :goto_15

    .end local v44    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v45    # "propagateMinConstraints\\13":Z
    .restart local v1    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .restart local v2    # "propagateMinConstraints\\13":Z
    :cond_1f
    move-object/from16 v44, v1

    move/from16 v45, v2

    .line 262
    .end local v1    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v2    # "propagateMinConstraints\\13":Z
    .restart local v44    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .restart local v45    # "propagateMinConstraints\\13":Z
    :goto_14
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, p5

    .end local p5    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 263
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v7, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 265
    :goto_15
    nop

    .line 260
    .end local v2    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\18\\260\\17":I
    nop

    .line 265
    nop

    .line 266
    .end local v0    # "block\\17":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\17\\259":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v7, v5, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 267
    nop

    .line 255
    .end local v7    # "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\255\\14":I
    nop

    .line 268
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v9, v0, 0xe

    .local v9, "$changed\\19":I
    move-object/from16 v0, v42

    .local v0, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 269
    .local v21, "$i$a$-Layout-BoxKt$Box$1\\19\\268\\13":I
    const v1, -0x7ff519f7    # -1.000876E-39f

    const-string v2, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v2, v20, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v43, v2, 0x6

    .local v43, "$changed\\20":I
    check-cast v1, Landroidx/compose/foundation/layout/BoxScope;

    move-object v2, v5

    .end local v5    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .local v1, "$this$ScreenAction_u24lambda_u248_u24lambda_u247\\20":Landroidx/compose/foundation/layout/BoxScope;
    .local v2, "materialized\\14":Landroidx/compose/ui/Modifier;
    move-object v5, v0

    .local v5, "$composer\\20":Landroidx/compose/runtime/Composer;
    move-object/from16 v46, v1

    .end local v1    # "$this$ScreenAction_u24lambda_u248_u24lambda_u247\\20":Landroidx/compose/foundation/layout/BoxScope;
    .local v46, "$this$ScreenAction_u24lambda_u248_u24lambda_u247\\20":Landroidx/compose/foundation/layout/BoxScope;
    const/16 v47, 0x0

    .line 126
    .local v47, "$i$a$-Box-ShellKt$ScreenAction$1$2\\20\\269\\8":I
    const v1, 0x6064950

    const-string v7, "C125@6046L58:Shell.kt#o13vsk"

    invoke-static {v5, v1, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x20

    .local v7, "$this$dp\\21":I
    const/16 v48, 0x0

    .line 270
    .local v48, "$i$f$getDp\\21\\126":I
    move-object/from16 p5, v0

    .end local v0    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local p5, "$composer\\19":Landroidx/compose/runtime/Composer;
    int-to-float v0, v7

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 126
    .end local v7    # "$this$dp\\21":I
    .end local v48    # "$i$f$getDp\\21\\126":I
    invoke-static {v1, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v48

    and-int/lit8 v1, v12, 0xe

    or-int/lit16 v1, v1, 0xdb0

    const/4 v7, 0x0

    move-object/from16 v50, v6

    move v6, v1

    .end local v6    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v50, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/4 v1, 0x0

    move-object/from16 v52, p5

    move-object/from16 v51, v42

    move-object/from16 v42, v3

    move-object/from16 v53, v0

    move-object/from16 v0, p0

    move-object/from16 v54, v2

    move-object/from16 v2, v53

    move-wide/from16 v55, v48

    move-object/from16 v49, v54

    move-object/from16 v48, v4

    move-wide/from16 v3, v55

    .end local v2    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .end local v3    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local p5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v42, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v48, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v49, "materialized\\14":Landroidx/compose/ui/Modifier;
    .local v51, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v52, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v7}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 127
    nop

    .line 269
    .end local v5    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v43    # "$changed\\20":I
    .end local v46    # "$this$ScreenAction_u24lambda_u248_u24lambda_u247\\20":Landroidx/compose/foundation/layout/BoxScope;
    .end local v47    # "$i$a$-Box-ShellKt$ScreenAction$1$2\\20\\269\\8":I
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 268
    .end local v9    # "$changed\\19":I
    .end local v21    # "$i$a$-Layout-BoxKt$Box$1\\19\\268\\13":I
    .end local v52    # "$composer\\19":Landroidx/compose/runtime/Composer;
    nop

    .line 271
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 247
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 272
    nop

    .line 241
    .end local v18    # "$changed\\15":I
    .end local v22    # "$i$f$ReusableComposeNode\\15\\245":I
    .end local v50    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 273
    nop

    .line 235
    .end local v10    # "compositeKeyHash\\14":I
    .end local v24    # "$changed\\14":I
    .end local v41    # "$i$f$Layout\\14\\240":I
    .end local v48    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v49    # "materialized\\14":Landroidx/compose/ui/Modifier;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 274
    nop

    .line 128
    .end local v11    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .end local v20    # "$changed\\13":I
    .end local v23    # "$i$f$Box\\13\\123":I
    .end local v42    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v44    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v45    # "propagateMinConstraints\\13":Z
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0xa

    .local v1, "$this$dp\\22":I
    const/4 v2, 0x0

    .line 275
    .local v2, "$i$f$getDp\\22\\128":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 128
    .end local v1    # "$this$dp\\22":I
    .end local v2    # "$i$f$getDp\\22\\128":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v16

    move-object/from16 v11, v51

    .end local v51    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v0, v11, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 129
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v11, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v0, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v41

    const/16 v47, 0xe

    const/16 v48, 0x0

    const v43, 0x3f59999a    # 0.85f

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    invoke-static/range {v41 .. v48}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    sget-object v0, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v0

    invoke-static {v0}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v0

    shr-int/lit8 v1, v12, 0x3

    and-int/lit8 v1, v1, 0xe

    or-int/lit16 v1, v1, 0x180

    const/16 v23, 0x0

    const v24, 0xfdfa

    move/from16 v22, v1

    const/4 v1, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v9, 0x0

    move-object/from16 v42, v11

    .end local v11    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    move-object/from16 v18, v13

    move-object/from16 v16, v14

    .end local v13    # "tag":Ljava/lang/String;
    .end local v14    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v16, "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v18, "tag":Ljava/lang/String;
    const-wide/16 v13, 0x0

    move/from16 v21, v15

    .end local v15    # "$changed\\1":I
    .local v21, "$changed\\1":I
    const/4 v15, 0x0

    move-object/from16 v41, v16

    .end local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v41, "materialized\\2":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    move-object/from16 v43, v17

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .local v43, "$composer":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    move-object/from16 v44, v18

    .end local v18    # "tag":Ljava/lang/String;
    .local v44, "tag":Ljava/lang/String;
    const/16 v18, 0x0

    move-object/from16 v51, v19

    .end local v19    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    move-object/from16 v45, p4

    move-object/from16 v46, v41

    move-object/from16 v47, v44

    move/from16 v41, v12

    move/from16 v44, v21

    move-object/from16 v21, v42

    move-object/from16 v42, p3

    move-object v12, v0

    move-object/from16 v0, p1

    .end local v12    # "$dirty":I
    .end local p3    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local p4    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v21, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v41, "$dirty":I
    .local v42, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v44, "$changed\\1":I
    .local v45, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v46, "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v47, "tag":Ljava/lang/String;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 123
    move-object/from16 v11, v21

    .end local v21    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 130
    nop

    .line 227
    .end local v11    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\8":I
    .end local v35    # "$this$ScreenAction_u24lambda_u248\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v36    # "$i$a$-Column-ShellKt$ScreenAction$1\\8\\227\\0":I
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 226
    .end local v32    # "$changed\\7":I
    .end local v33    # "$i$a$-Layout-ColumnKt$Column$1\\7\\226\\1":I
    .end local v51    # "$composer\\7":Landroidx/compose/runtime/Composer;
    nop

    .line 276
    invoke-interface/range {v43 .. v43}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 205
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 277
    nop

    .line 199
    .end local v30    # "$changed\\3":I
    .end local v31    # "$i$f$ReusableComposeNode\\3\\203":I
    .end local v40    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 278
    nop

    .line 192
    .end local v27    # "$changed\\2":I
    .end local v28    # "$i$f$Layout\\2\\198":I
    .end local v29    # "compositeKeyHash\\2":I
    .end local v45    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v46    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 279
    nop

    .end local v26    # "$i$f$Column\\1\\122":I
    .end local v37    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v38    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v39    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v42    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v44    # "$changed\\1":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_20
    move-object/from16 v4, v25

    move-object/from16 v5, v47

    .end local v25    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v47    # "tag":Ljava/lang/String;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    .local v5, "tag":Ljava/lang/String;
    :goto_16
    invoke-interface/range {v43 .. v43}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_21

    new-instance v0, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda2;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v6, p6

    move/from16 v7, p7

    invoke-direct/range {v0 .. v7}, Lorg/lighttouch/android/ShellKt$$ExternalSyntheticLambda2;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;II)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 131
    :cond_21
    return-void
.end method

.method private static final ScreenAction$lambda$8$lambda$6$lambda$5(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ScreenAction$lambda$9(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 9

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move v8, p6

    move-object/from16 v6, p7

    invoke-static/range {v1 .. v8}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final getActive(Lorg/lighttouch/android/GuestHost;)Z
    .locals 3
    .param p0, "$this$active"    # Lorg/lighttouch/android/GuestHost;

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "running"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "paused"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "starting"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "stopping"

    aput-object v2, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public static final getDialogTags()Landroidx/compose/ui/Modifier;
    .locals 1

    .line 139
    sget-object v0, Lorg/lighttouch/android/ShellKt;->DialogTags:Landroidx/compose/ui/Modifier;

    return-object v0
.end method

.method public static synthetic getDialogTags$annotations()V
    .locals 0

    return-void
.end method

.method public static final getPaused(Lorg/lighttouch/android/GuestHost;)Z
    .locals 2
    .param p0, "$this$paused"    # Lorg/lighttouch/android/GuestHost;

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 82
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v0

    const-string v1, "paused"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public static final getRunning(Lorg/lighttouch/android/GuestHost;)Z
    .locals 2
    .param p0, "$this$running"    # Lorg/lighttouch/android/GuestHost;

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v0

    const-string v1, "running"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public static final statusLabel(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p0, "status"    # Ljava/lang/String;

    const-string v0, "status"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    :goto_0
    goto :goto_1

    :sswitch_0
    const-string v0, "stopping"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 134
    :cond_0
    const-string v0, "\u6b63\u5728\u5173\u673a"

    goto :goto_2

    .line 133
    :sswitch_1
    const-string v0, "running"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 134
    :cond_1
    const-string v0, "\u8fd0\u884c\u4e2d"

    goto :goto_2

    .line 133
    :sswitch_2
    const-string v0, "starting"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 134
    :cond_2
    const-string v0, "\u6b63\u5728\u542f\u52a8"

    goto :goto_2

    .line 133
    :sswitch_3
    const-string v0, "paused"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    .line 134
    :cond_3
    const-string v0, "\u5df2\u6682\u505c"

    goto :goto_2

    .line 133
    :sswitch_4
    const-string v0, "failed"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    .line 135
    :cond_4
    const-string v0, "\u610f\u5916\u505c\u6b62"

    goto :goto_2

    :goto_1
    const-string v0, "\u5df2\u5173\u95ed"

    .line 136
    :goto_2
    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x4c696bc3 -> :sswitch_4
        -0x3b5366d2 -> :sswitch_3
        0x4e7ce040 -> :sswitch_2
        0x5c6f15bf -> :sswitch_1
        0x6642b874 -> :sswitch_0
    .end sparse-switch
.end method

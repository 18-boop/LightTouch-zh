.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n1225#2,6:209\n1225#2,6:252\n1225#2,6:262\n149#3:215\n86#4:216\n83#4,6:217\n89#4:251\n93#4:261\n79#5,6:223\n86#5,4:238\n90#5,2:248\n94#5:260\n368#6,9:229\n377#6:250\n378#6,2:258\n4034#7,6:242\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6\n*L\n75#1:197,6\n78#1:203,6\n79#1:209,6\n82#1:252,6\n84#1:262,6\n80#1:215\n80#1:216\n80#1:217,6\n80#1:251\n80#1:261\n80#1:223,6\n80#1:238,4\n80#1:248,2\n80#1:260\n80#1:229,9\n80#1:250\n80#1:258,2\n80#1:242,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method public static synthetic $r8$lambda$4HBOf9mzY5QPrGt5-n6-cXqM0Nc(Lorg/lighttouch/android/OverlayGraph;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$5$lambda$4(Lorg/lighttouch/android/OverlayGraph;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$CNuDo1uBMntcJ53MZb4rl4VZbwg(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayCorner;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$11$lambda$10(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayCorner;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FiDcikOajH5hS5i6MYKuGibTo1s(Lorg/lighttouch/android/OverlayLevel;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$1$lambda$0(Lorg/lighttouch/android/OverlayLevel;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$I10L01vidOimhHHf_ywOyC38okI(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayLevel;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayLevel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$O3MSNGWeJRURHoNJFhcv5ZgRUjU(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$16$lambda$15(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$PY_xKMoxvoPqqALsrMH8GXlXSKg(Lorg/lighttouch/android/AppSettings;F)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$14$lambda$13$lambda$12(Lorg/lighttouch/android/AppSettings;F)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mJjDkX87rECsoUdxj35Rjunc7_k(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayGraph;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$7$lambda$6(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayGraph;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wfLdz6dtEN-_8G4lrBPZAFAZqTY(Lorg/lighttouch/android/OverlayCorner;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke$lambda$9$lambda$8(Lorg/lighttouch/android/OverlayCorner;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Lorg/lighttouch/android/OverlayLevel;)Ljava/lang/String;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/OverlayLevel;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    invoke-virtual {p0}, Lorg/lighttouch/android/OverlayLevel;->getLabel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final invoke$lambda$11$lambda$10(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayCorner;)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Lorg/lighttouch/android/OverlayCorner;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setOverlayCorner(Lorg/lighttouch/android/OverlayCorner;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$14$lambda$13$lambda$12(Lorg/lighttouch/android/AppSettings;F)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # F

    .line 82
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setOverlayOpacity(F)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$16$lambda$15(Lorg/lighttouch/android/AppSettings;Z)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Z

    .line 84
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setOverlayInDeviceView(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayLevel;)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Lorg/lighttouch/android/OverlayLevel;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setOverlay(Lorg/lighttouch/android/OverlayLevel;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4(Lorg/lighttouch/android/OverlayGraph;)Ljava/lang/String;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/OverlayGraph;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    invoke-virtual {p0}, Lorg/lighttouch/android/OverlayGraph;->getLabel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final invoke$lambda$7$lambda$6(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/OverlayGraph;)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Lorg/lighttouch/android/OverlayGraph;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setOverlayGraph(Lorg/lighttouch/android/OverlayGraph;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$9$lambda$8(Lorg/lighttouch/android/OverlayCorner;)Ljava/lang/String;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/OverlayCorner;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    invoke-virtual {p0}, Lorg/lighttouch/android/OverlayCorner;->getGlyph()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 74
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 55
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v9, p2

    move/from16 v12, p3

    const-string v1, "$this$Group"

    move-object/from16 v13, p1

    invoke-static {v13, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C74@6180L12,74@6217L18,74@6112L123,76@6317L20,77@6425L12,77@6439L23,77@6362L100,78@6555L12,78@6592L24,78@6487L129,79@6641L301,83@7090L30,83@6967L153:SettingsScreen.kt#o13vsk"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v12, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 84
    :cond_0
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_11

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:74)"

    const v3, -0x3ec04120

    invoke-static {v3, v12, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 75
    :cond_2
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getSpeed()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    invoke-static {}, Lorg/lighttouch/android/OverlayLevel;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/util/List;

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getOverlay()Lorg/lighttouch/android/OverlayLevel;

    move-result-object v4

    const v14, 0x6e3c21fe

    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v15, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\1":Z
    move-object/from16 v5, p2

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 197
    .local v6, "$i$f$cache\\1\\75":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\1":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 198
    .local v8, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_3

    .line 199
    const/4 v10, 0x0

    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$1\\3\\199\\0":I
    new-instance v11, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda0;

    invoke-direct {v11}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda0;-><init>()V

    .line 200
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$1\\3\\199\\0":I
    .local v11, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .end local v11    # "value\\2":Ljava/lang/Object;
    goto :goto_1

    .line 202
    :cond_3
    move-object v11, v7

    .line 198
    :goto_1
    nop

    .line 197
    .end local v7    # "it\\1":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 75
    .end local v2    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\1\\75":I
    move-object v5, v11

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x4c5de2

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v6, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    .local v6, "invalid\\4":Z
    iget-object v7, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v8, p2

    .local v8, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 197
    .local v10, "$i$f$cache\\4\\75":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 198
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\197\\4":I
    if-nez v6, :cond_5

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v11, v2, :cond_4

    goto :goto_2

    .line 202
    :cond_4
    move-object v14, v11

    goto :goto_3

    .line 199
    :cond_5
    :goto_2
    const/4 v2, 0x0

    .line 75
    .local v2, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$2\\6\\199\\0":I
    new-instance v14, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda1;

    invoke-direct {v14, v7}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 199
    .end local v2    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$2\\6\\199\\0":I
    nop

    .line 200
    .local v14, "value\\5":Ljava/lang/Object;
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .line 198
    .end local v14    # "value\\5":Ljava/lang/Object;
    :goto_3
    nop

    .line 197
    .end local v11    # "it\\4":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\5\\197\\4":I
    nop

    .line 75
    .end local v6    # "invalid\\4":Z
    .end local v8    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\4\\75":I
    move-object v8, v14

    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v10, 0x186030

    const/16 v11, 0x20

    const-string v2, "\u8be6\u7ec6\u7a0b\u5ea6"

    const/4 v6, 0x0

    const-string v7, "overlay_level"

    const v14, 0x4c5de2

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SettingsScreenKt;->access$ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/util/List;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 76
    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getOverlay()Lorg/lighttouch/android/OverlayLevel;

    move-result-object v1

    sget-object v2, Lorg/lighttouch/android/OverlayLevel;->OFF:Lorg/lighttouch/android/OverlayLevel;

    if-eq v1, v2, :cond_14

    .line 77
    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$host:Lorg/lighttouch/android/GuestHost;

    const/4 v2, 0x0

    invoke-static {v1, v9, v2}, Lorg/lighttouch/android/SettingsScreenKt;->access$OverlayPreview(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/Composer;I)V

    .line 78
    invoke-static {}, Lorg/lighttouch/android/OverlayGraph;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Ljava/util/List;

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getOverlayGraph()Lorg/lighttouch/android/OverlayGraph;

    move-result-object v4

    const v1, 0x6e3c21fe

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v1, 0x0

    .local v1, "invalid\\7":Z
    move-object/from16 v5, p2

    .local v5, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 203
    .local v6, "$i$f$cache\\7\\78":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\7":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 204
    .local v8, "$i$a$-let-ComposerKt$cache$1\\8\\203\\7":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_6

    .line 205
    const/4 v10, 0x0

    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$3\\9\\205\\0":I
    new-instance v11, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda2;

    invoke-direct {v11}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda2;-><init>()V

    .line 206
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$3\\9\\205\\0":I
    .local v11, "value\\8":Ljava/lang/Object;
    invoke-interface {v5, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .end local v11    # "value\\8":Ljava/lang/Object;
    goto :goto_4

    .line 208
    :cond_6
    move-object v11, v7

    .line 204
    :goto_4
    nop

    .line 203
    .end local v7    # "it\\7":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\8\\203\\7":I
    nop

    .line 78
    .end local v1    # "invalid\\7":Z
    .end local v5    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\7\\78":I
    move-object v5, v11

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\10":Z
    iget-object v6, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v7, p2

    .local v7, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 203
    .local v8, "$i$f$cache\\10\\78":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\10":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 204
    .local v11, "$i$a$-let-ComposerKt$cache$1\\11\\203\\10":I
    if-nez v1, :cond_8

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v10, v2, :cond_7

    goto :goto_5

    .line 208
    :cond_7
    move-object v14, v10

    goto :goto_6

    .line 205
    :cond_8
    :goto_5
    const/4 v2, 0x0

    .line 78
    .local v2, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$4\\12\\205\\0":I
    new-instance v14, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda3;

    invoke-direct {v14, v6}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 205
    .end local v2    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$4\\12\\205\\0":I
    nop

    .line 206
    .local v14, "value\\11":Ljava/lang/Object;
    invoke-interface {v7, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 204
    .end local v14    # "value\\11":Ljava/lang/Object;
    :goto_6
    nop

    .line 203
    .end local v10    # "it\\10":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\11\\203\\10":I
    nop

    .line 78
    .end local v1    # "invalid\\10":Z
    .end local v7    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\10\\78":I
    move-object v8, v14

    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v10, 0x6036

    const/16 v11, 0x60

    const/4 v1, 0x0

    const-string v2, "\u56fe\u8868"

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v14, 0x0

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SettingsScreenKt;->access$ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/util/List;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 79
    invoke-static {}, Lorg/lighttouch/android/OverlayCorner;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Ljava/util/List;

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getOverlayCorner()Lorg/lighttouch/android/OverlayCorner;

    move-result-object v4

    const v1, 0x6e3c21fe

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v1, 0x0

    .local v1, "invalid\\13":Z
    move-object/from16 v2, p2

    .local v2, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 209
    .local v5, "$i$f$cache\\13\\79":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\13":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 210
    .local v7, "$i$a$-let-ComposerKt$cache$1\\14\\209\\13":I
    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_9

    .line 211
    const/4 v8, 0x0

    .local v8, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$5\\15\\211\\0":I
    new-instance v10, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda4;

    invoke-direct {v10}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda4;-><init>()V

    .line 212
    .end local v8    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$5\\15\\211\\0":I
    .local v10, "value\\14":Ljava/lang/Object;
    invoke-interface {v2, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    nop

    .end local v10    # "value\\14":Ljava/lang/Object;
    goto :goto_7

    .line 214
    :cond_9
    move-object v10, v6

    .line 210
    :goto_7
    nop

    .line 209
    .end local v6    # "it\\13":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\14\\209\\13":I
    nop

    .line 79
    .end local v1    # "invalid\\13":Z
    .end local v2    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\13\\79":I
    move-object v5, v10

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getOverlayCorner()Lorg/lighttouch/android/OverlayCorner;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/OverlayCorner;->getLabel()Ljava/lang/String;

    move-result-object v6

    const v1, 0x4c5de2

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\16":Z
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v7, p2

    .local v7, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 209
    .local v8, "$i$f$cache\\16\\79":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\16":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 210
    .local v11, "$i$a$-let-ComposerKt$cache$1\\17\\209\\16":I
    if-nez v1, :cond_b

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v10, v14, :cond_a

    goto :goto_8

    .line 214
    :cond_a
    move/from16 v17, v1

    move-object v1, v10

    goto :goto_9

    .line 211
    :cond_b
    :goto_8
    const/4 v14, 0x0

    .line 79
    .local v14, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$6\\18\\211\\0":I
    move/from16 v17, v1

    .end local v1    # "invalid\\16":Z
    .local v17, "invalid\\16":Z
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda5;

    invoke-direct {v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 211
    .end local v14    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$6\\18\\211\\0":I
    nop

    .line 212
    .local v1, "value\\17":Ljava/lang/Object;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    nop

    .line 210
    .end local v1    # "value\\17":Ljava/lang/Object;
    :goto_9
    nop

    .line 209
    .end local v10    # "it\\16":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\17\\209\\16":I
    nop

    .line 79
    .end local v7    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\16\\79":I
    .end local v17    # "invalid\\16":Z
    move-object v8, v1

    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v10, 0x6036

    const/16 v11, 0x40

    const/4 v1, 0x0

    const-string v2, "\u4f4d\u7f6e"

    const/4 v7, 0x0

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SettingsScreenKt;->access$ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/util/List;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 80
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    const/16 v2, 0x36

    .local v2, "$this$dp\\19":I
    const/4 v3, 0x0

    .line 215
    .local v3, "$i$f$getDp\\19\\80":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 80
    .end local v2    # "$this$dp\\19":I
    .end local v3    # "$i$f$getDp\\19\\80":I
    const/16 v3, 0x10

    .local v3, "$this$dp\\20":I
    const/4 v4, 0x0

    .line 215
    .local v4, "$i$f$getDp\\20\\80":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 80
    .end local v3    # "$this$dp\\20":I
    .end local v4    # "$i$f$getDp\\20\\80":I
    const/16 v4, 0x8

    .local v4, "$this$dp\\21":I
    const/4 v5, 0x0

    .line 215
    .local v5, "$i$f$getDp\\21\\80":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 80
    .end local v4    # "$this$dp\\21":I
    .end local v5    # "$i$f$getDp\\21\\80":I
    const/16 v5, 0x8

    .local v5, "$this$dp\\22":I
    const/4 v6, 0x0

    .line 215
    .local v6, "$i$f$getDp\\22\\80":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 80
    .end local v5    # "$this$dp\\22":I
    .end local v6    # "$i$f$getDp\\22\\80":I
    check-cast v1, Landroidx/compose/ui/Modifier;

    invoke-static {v1, v2, v4, v3, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0(Landroidx/compose/ui/Modifier;FFFF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\23":Landroidx/compose/ui/Modifier;
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    const/4 v3, 0x0

    .local v3, "$changed\\23":I
    const/4 v4, 0x0

    .line 216
    .local v4, "$i$f$Column\\23\\80":I
    const v5, -0x1cd0f17e

    const-string v6, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v9, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 217
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v5

    .line 218
    .local v5, "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .line 221
    .local v6, "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v7, v3, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v8, v3, 0x3

    and-int/lit8 v8, v8, 0x70

    or-int/2addr v7, v8

    invoke-static {v5, v6, v9, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v3, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 222
    nop

    .local v8, "$changed\\24":I
    const/4 v10, 0x0

    .line 223
    .local v10, "$i$f$Layout\\24\\222":I
    const v11, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v9, v11, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 224
    const/4 v14, 0x0

    invoke-static {v9, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v11

    .line 225
    .local v11, "compositeKeyHash\\24":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 226
    .local v14, "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v17, v3

    .end local v3    # "$changed\\23":I
    .local v17, "$changed\\23":I
    invoke-static {v9, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 228
    .local v3, "materialized\\24":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v19, v1

    .end local v1    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\23":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v8, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 227
    move-object/from16 v20, v18

    .local v1, "$changed\\25":I
    .local v20, "factory\\25":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 229
    .local v18, "$i$f$ReusableComposeNode\\25\\227":I
    move/from16 v21, v1

    .end local v1    # "$changed\\25":I
    .local v21, "$changed\\25":I
    const v1, -0x2942ffcf

    move/from16 v22, v4

    .end local v4    # "$i$f$Column\\23\\80":I
    .local v22, "$i$f$Column\\23\\80":I
    const-string v4, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v9, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 230
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 231
    :cond_c
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 232
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_d

    .line 233
    move-object/from16 v1, v20

    .end local v20    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 235
    .end local v1    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\25":Lkotlin/jvm/functions/Function0;
    :cond_d
    move-object/from16 v1, v20

    .end local v20    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 237
    :goto_a
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 238
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\26\\237\\24":I
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v24, v1

    .end local v1    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .local v24, "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v7, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 239
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 241
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\27":Lkotlin/jvm/functions/Function2;
    const/16 v23, 0x0

    .line 242
    .local v23, "$i$f$set-impl\\27\\241":I
    move-object/from16 v25, v4

    .local v25, "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 243
    .local v26, "$i$a$-with-Updater$set$1\\28\\242\\27":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_f

    move-object/from16 v27, v5

    .end local v5    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v27, "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v28, v6

    .end local v6    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    .local v28, "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_e

    goto :goto_b

    :cond_e
    move-object/from16 v6, v25

    goto :goto_c

    .end local v27    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v28    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v5    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v6    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_f
    move-object/from16 v27, v5

    move-object/from16 v28, v6

    .line 244
    .end local v5    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v6    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v27    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v28    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    :goto_b
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v25

    .end local v25    # "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 245
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 247
    :goto_c
    nop

    .line 242
    .end local v6    # "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\28\\242\\27":I
    nop

    .line 247
    nop

    .line 248
    .end local v1    # "block\\27":Lkotlin/jvm/functions/Function2;
    .end local v23    # "$i$f$set-impl\\27\\241":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 249
    nop

    .line 237
    .end local v4    # "$this$Layout_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\26\\237\\24":I
    nop

    .line 250
    shr-int/lit8 v1, v21, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\29":I
    move-object/from16 v4, p2

    .local v4, "$composer\\29":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 251
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\29\\250\\23":I
    const v6, -0x16ef5699

    move/from16 v20, v1

    .end local v1    # "$changed\\29":I
    .local v20, "$changed\\29":I
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v6, v17, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\30":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$invoke_u24lambda_u2414\\30":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v50, v4

    .local v50, "$composer\\30":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 81
    .local v23, "$i$a$-Column-SettingsScreenKt$SettingsScreen$4$1$2$6$7\\30\\251\\0":I
    move-object/from16 v25, v1

    .end local v1    # "$this$invoke_u24lambda_u2414\\30":Landroidx/compose/foundation/layout/ColumnScope;
    .local v25, "$this$invoke_u24lambda_u2414\\30":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x24fc3c2d

    move-object/from16 v26, v3

    .end local v3    # "materialized\\24":Landroidx/compose/ui/Modifier;
    .local v26, "materialized\\24":Landroidx/compose/ui/Modifier;
    const-string v3, "C80@6792L10,80@6751L62,81@6867L25,81@6842L74:SettingsScreen.kt#o13vsk"

    move-object/from16 v54, v4

    .end local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\29":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v49

    const/16 v52, 0x0

    const v53, 0xfffe

    const-string v29, "\u80cc\u666f"

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v51, 0x6

    .end local v4    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v53}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 82
    .end local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getOverlayOpacity()F

    move-result v29

    const v1, 0x4c5de2

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\31":Z
    move-object v3, v4

    .local v3, "$this$cache\\31":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 252
    .local v30, "$i$f$cache\\31\\82":I
    move/from16 v31, v1

    .end local v1    # "invalid\\31":Z
    .local v31, "invalid\\31":Z
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\31":Ljava/lang/Object;
    const/16 v32, 0x0

    .line 253
    .local v32, "$i$a$-let-ComposerKt$cache$1\\32\\252\\31":I
    if-nez v31, :cond_11

    sget-object v33, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v50, v4

    .end local v4    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v33 .. v33}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v1, v4, :cond_10

    goto :goto_d

    .line 257
    :cond_10
    move-object/from16 v33, v1

    goto :goto_e

    .line 253
    .end local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\30":Landroidx/compose/runtime/Composer;
    :cond_11
    move-object/from16 v50, v4

    .line 254
    .end local v4    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    :goto_d
    const/4 v4, 0x0

    .line 82
    .local v4, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$7$1\\33\\254\\30":I
    move-object/from16 v33, v1

    .end local v1    # "it\\31":Ljava/lang/Object;
    .local v33, "it\\31":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda6;

    invoke-direct {v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 254
    .end local v4    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$7$1\\33\\254\\30":I
    nop

    .line 255
    .local v1, "value\\32":Ljava/lang/Object;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 256
    nop

    .line 253
    .end local v1    # "value\\32":Ljava/lang/Object;
    :goto_e
    nop

    .line 252
    .end local v32    # "$i$a$-let-ComposerKt$cache$1\\32\\252\\31":I
    .end local v33    # "it\\31":Ljava/lang/Object;
    nop

    .line 82
    .end local v3    # "$this$cache\\31":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$f$cache\\31\\82":I
    .end local v31    # "invalid\\31":Z
    move-object/from16 v30, v1

    check-cast v30, Lkotlin/jvm/functions/Function1;

    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v1, 0x0

    const v2, 0x3f666666    # 0.9f

    invoke-static {v1, v2}, Lkotlin/ranges/RangesKt;->rangeTo(FF)Lkotlin/ranges/ClosedFloatingPointRange;

    move-result-object v33

    const/16 v39, 0x0

    const/16 v40, 0x1ec

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    move-object/from16 v38, v50

    .end local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v40}, Landroidx/compose/material3/SliderKt;->Slider(FLkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;ZLkotlin/ranges/ClosedFloatingPointRange;ILkotlin/jvm/functions/Function0;Landroidx/compose/material3/SliderColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    .line 81
    .end local v38    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 83
    nop

    .line 251
    .end local v6    # "$changed\\30":I
    .end local v23    # "$i$a$-Column-SettingsScreenKt$SettingsScreen$4$1$2$6$7\\30\\251\\0":I
    .end local v25    # "$this$invoke_u24lambda_u2414\\30":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v50    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 250
    .end local v5    # "$i$a$-Layout-ColumnKt$Column$1\\29\\250\\23":I
    .end local v20    # "$changed\\29":I
    .end local v54    # "$composer\\29":Landroidx/compose/runtime/Composer;
    nop

    .line 258
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 229
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 259
    nop

    .line 223
    .end local v18    # "$i$f$ReusableComposeNode\\25\\227":I
    .end local v21    # "$changed\\25":I
    .end local v24    # "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 260
    nop

    .line 216
    .end local v8    # "$changed\\24":I
    .end local v10    # "$i$f$Layout\\24\\222":I
    .end local v11    # "compositeKeyHash\\24":I
    .end local v14    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v26    # "materialized\\24":Landroidx/compose/ui/Modifier;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 261
    nop

    .line 84
    .end local v7    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v17    # "$changed\\23":I
    .end local v19    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .end local v22    # "$i$f$Column\\23\\80":I
    .end local v27    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v28    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getOverlayInDeviceView()Z

    move-result v4

    const v1, 0x4c5de2

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\34":Z
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;->$s:Lorg/lighttouch/android/AppSettings;

    move-object/from16 v3, p2

    .local v3, "$this$cache\\34":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 262
    .local v5, "$i$f$cache\\34\\84":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\34":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 263
    .local v7, "$i$a$-let-ComposerKt$cache$1\\35\\262\\34":I
    if-nez v1, :cond_13

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_12

    goto :goto_f

    .line 267
    :cond_12
    move-object v10, v6

    goto :goto_10

    .line 264
    :cond_13
    :goto_f
    const/4 v8, 0x0

    .line 84
    .local v8, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$8\\36\\264\\0":I
    new-instance v10, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda7;

    invoke-direct {v10, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 264
    .end local v8    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$6$8\\36\\264\\0":I
    nop

    .line 265
    .local v10, "value\\35":Ljava/lang/Object;
    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 266
    nop

    .line 263
    .end local v10    # "value\\35":Ljava/lang/Object;
    :goto_10
    nop

    .line 262
    .end local v6    # "it\\34":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\35\\262\\34":I
    nop

    .line 84
    .end local v1    # "invalid\\34":Z
    .end local v3    # "$this$cache\\34":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\34\\84":I
    move-object v7, v10

    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v9, 0x1b6

    const/16 v10, 0x30

    const/4 v1, 0x0

    const-string v2, "\u5728\u8bbe\u5907\u89c6\u56fe\u4e2d\u663e\u793a"

    const-string v3, "\u540c\u65f6\u663e\u793a\u5728\u7ed8\u5236\u7684\u8bbe\u5907\u4e0a\uff0c\u800c\u4e0d\u53ea\u662f\u5168\u5c4f"

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v8, p2

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SettingsScreenKt;->access$SwitchRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    :cond_14
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 86
    :cond_15
    :goto_11
    return-void
.end method

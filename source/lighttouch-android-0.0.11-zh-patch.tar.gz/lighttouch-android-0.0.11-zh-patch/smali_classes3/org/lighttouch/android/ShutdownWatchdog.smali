.class public final Lorg/lighttouch/android/ShutdownWatchdog;
.super Ljava/lang/Object;
.source "ShutdownWatchdog.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/ShutdownWatchdog$Call;,
        Lorg/lighttouch/android/ShutdownWatchdog$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nShutdownWatchdog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ShutdownWatchdog.kt\norg/lighttouch/android/ShutdownWatchdog\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,176:1\n77#1,6:177\n77#1,6:183\n77#1,6:189\n77#1,6:195\n77#1,6:202\n1#2:201\n*S KotlinDebug\n*F\n+ 1 ShutdownWatchdog.kt\norg/lighttouch/android/ShutdownWatchdog\n*L\n85#1:177,6\n96#1:183,6\n100#1:189,6\n123#1:195,6\n172#1:202,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0010\u000b\n\u0002\u0008\u0005\u0008\u0001\u0018\u00002\u00020\u0001:\u0001;Bw\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0005\u0012\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00070\u0005\u0012\u000c\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0005\u0012\u0012\u0010\n\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00070\u000b0\u0005\u0012\u0012\u0010\u000c\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\t0\r\u0012\u0014\u0008\u0002\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\t0\r\u00a2\u0006\u0004\u0008\u0010\u0010\u0011J\u0006\u0010\u001f\u001a\u00020\u001aJ%\u0010 \u001a\u00020\t2\u001a\u0008\u0004\u0010!\u001a\u0014\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u001a0\"H\u0082\u0008J\u0010\u0010#\u001a\u00020\t2\u0006\u0010$\u001a\u00020\u0017H\u0002J\u0014\u0010%\u001a\u00020&*\u00020\u001a2\u0006\u0010\'\u001a\u00020(H\u0002J\u001c\u0010)\u001a\u00020\u001a*\u00020\u001a2\u0006\u0010\'\u001a\u00020(2\u0006\u0010$\u001a\u00020&H\u0002J\u0010\u0010*\u001a\u00020\t2\u0006\u0010\'\u001a\u00020(H\u0002J9\u0010+\u001a\u00020\t2\u0006\u0010\'\u001a\u00020(2\u0010\u0008\u0002\u0010,\u001a\n\u0018\u00010-j\u0004\u0018\u0001`.2\u0010\u0008\u0002\u0010/\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u000bH\u0002\u00a2\u0006\u0002\u00100JG\u00101\u001a\u0002H2\"\u0004\u0008\u0000\u001022\u0006\u0010\'\u001a\u00020(2\u000c\u00103\u001a\u0008\u0012\u0004\u0012\u0002H20\u00052\u001c\u0008\u0002\u00104\u001a\u0016\u0012\u0004\u0012\u0002H2\u0012\u000c\u0012\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u000b0\rH\u0002\u00a2\u0006\u0002\u00105J\u0006\u00106\u001a\u000207J\u001a\u00108\u001a\u00020\t2\u0006\u00109\u001a\u00020\u00072\u0008\u0010/\u001a\u0004\u0018\u00010\u0007H\u0002J\u0010\u00108\u001a\u00020\t2\u0006\u0010:\u001a\u00020\u000eH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00070\u000b0\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000c\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\t0\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\t0\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0015\u001a\u0010\u0012\u000c\u0012\n \u0018*\u0004\u0018\u00010\u00170\u00170\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0019\u001a\u0010\u0012\u000c\u0012\n \u0018*\u0004\u0018\u00010\u001a0\u001a0\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u001b\u001a\n \u0018*\u0004\u0018\u00010\u001c0\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006<"
    }
    d2 = {
        "Lorg/lighttouch/android/ShutdownWatchdog;",
        "",
        "graceMs",
        "",
        "now",
        "Lkotlin/Function0;",
        "requestNativeStop",
        "",
        "cancelNativeContacts",
        "",
        "nativeStatus",
        "",
        "dispose",
        "Lkotlin/Function1;",
        "Lorg/lighttouch/android/ShutdownReceipt;",
        "persistTerminal",
        "<init>",
        "(JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V",
        "requested",
        "Ljava/util/concurrent/atomic/AtomicBoolean;",
        "disposed",
        "progress",
        "Ljava/util/concurrent/atomic/AtomicReference;",
        "Lorg/lighttouch/android/ShutdownProgress;",
        "kotlin.jvm.PlatformType",
        "debugProgress",
        "Lorg/lighttouch/android/ShutdownDebugProgress;",
        "timer",
        "Ljava/util/concurrent/ScheduledExecutorService;",
        "acceptedAt",
        "deadline",
        "cachedProgress",
        "publish",
        "change",
        "Lkotlin/Function2;",
        "setProgress",
        "value",
        "call",
        "Lorg/lighttouch/android/ShutdownCallProgress;",
        "kind",
        "Lorg/lighttouch/android/ShutdownWatchdog$Call;",
        "withCall",
        "enter",
        "returned",
        "failure",
        "Ljava/lang/Exception;",
        "Lkotlin/Exception;",
        "state",
        "(Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;)V",
        "tracked",
        "T",
        "action",
        "returnedState",
        "(Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;",
        "request",
        "",
        "finish",
        "reason",
        "receipt",
        "Call",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private acceptedAt:J

.field private final cancelNativeContacts:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private deadline:J

.field private final debugProgress:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lorg/lighttouch/android/ShutdownDebugProgress;",
            ">;"
        }
    .end annotation
.end field

.field private final dispose:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Lorg/lighttouch/android/ShutdownReceipt;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final graceMs:J

.field private final nativeStatus:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final now:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private final persistTerminal:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Lorg/lighttouch/android/ShutdownReceipt;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final progress:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lorg/lighttouch/android/ShutdownProgress;",
            ">;"
        }
    .end annotation
.end field

.field private final requestNativeStop:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final requested:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final timer:Ljava/util/concurrent/ScheduledExecutorService;


# direct methods
.method public static synthetic $r8$lambda$3AY0e69Gz9Ix2ykRPccvfAcjtas(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/ShutdownWatchdog;->timer$lambda$2(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$OVJBcOKBrZ-NEVxwiTynEddVYuA(Lorg/lighttouch/android/ShutdownWatchdog;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/ShutdownWatchdog;->request$lambda$7(Lorg/lighttouch/android/ShutdownWatchdog;)V

    return-void
.end method

.method public static synthetic $r8$lambda$SNMU1vv4hvcJl3wAUqsuDS2j-bQ(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/ShutdownWatchdog;->request$lambda$13$lambda$12(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TJlIL-lI1k28I4YlXoG720uJpFo([Ljava/lang/String;)[Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/ShutdownWatchdog;->request$lambda$13$lambda$8([Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$b5T3lbfjU6hJTkhDjlVuuTwcQ9o(Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/ShutdownWatchdog;->_init_$lambda$0(Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$gBMjcDSxiYMYMD6c_4d6eZdEzLE(Lorg/lighttouch/android/ShutdownWatchdog;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/ShutdownWatchdog;->request$lambda$13(Lorg/lighttouch/android/ShutdownWatchdog;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/ShutdownWatchdog;->$stable:I

    return-void
.end method

.method public constructor <init>(JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V
    .locals 30
    .param p1, "graceMs"    # J
    .param p3, "now"    # Lkotlin/jvm/functions/Function0;
    .param p4, "requestNativeStop"    # Lkotlin/jvm/functions/Function0;
    .param p5, "cancelNativeContacts"    # Lkotlin/jvm/functions/Function0;
    .param p6, "nativeStatus"    # Lkotlin/jvm/functions/Function0;
    .param p7, "dispose"    # Lkotlin/jvm/functions/Function1;
    .param p8, "persistTerminal"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Long;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "[",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/lighttouch/android/ShutdownReceipt;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/lighttouch/android/ShutdownReceipt;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v3, p5

    move-object/from16 v4, p6

    move-object/from16 v5, p7

    move-object/from16 v6, p8

    const-string v7, "now"

    invoke-static {v1, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "requestNativeStop"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "cancelNativeContacts"

    invoke-static {v3, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "nativeStatus"

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "dispose"

    invoke-static {v5, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v7, "persistTerminal"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 54
    move-wide/from16 v7, p1

    iput-wide v7, v0, Lorg/lighttouch/android/ShutdownWatchdog;->graceMs:J

    .line 55
    iput-object v1, v0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    .line 56
    iput-object v2, v0, Lorg/lighttouch/android/ShutdownWatchdog;->requestNativeStop:Lkotlin/jvm/functions/Function0;

    .line 57
    iput-object v3, v0, Lorg/lighttouch/android/ShutdownWatchdog;->cancelNativeContacts:Lkotlin/jvm/functions/Function0;

    .line 58
    iput-object v4, v0, Lorg/lighttouch/android/ShutdownWatchdog;->nativeStatus:Lkotlin/jvm/functions/Function0;

    .line 59
    iput-object v5, v0, Lorg/lighttouch/android/ShutdownWatchdog;->dispose:Lkotlin/jvm/functions/Function1;

    .line 60
    iput-object v6, v0, Lorg/lighttouch/android/ShutdownWatchdog;->persistTerminal:Lkotlin/jvm/functions/Function1;

    .line 62
    new-instance v9, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v10, 0x0

    invoke-direct {v9, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v9, v0, Lorg/lighttouch/android/ShutdownWatchdog;->requested:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 63
    new-instance v9, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v9, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v9, v0, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 64
    new-instance v9, Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v10, Lorg/lighttouch/android/ShutdownProgress;

    const/4 v11, 0x0

    const/4 v12, 0x2

    const-string v13, "not-requested"

    invoke-direct {v10, v13, v11, v12, v11}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-direct {v9, v10}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object v9, v0, Lorg/lighttouch/android/ShutdownWatchdog;->progress:Ljava/util/concurrent/atomic/AtomicReference;

    .line 65
    new-instance v9, Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v10, Lorg/lighttouch/android/ShutdownDebugProgress;

    const v28, 0xffff

    const/16 v29, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    invoke-direct/range {v10 .. v29}, Lorg/lighttouch/android/ShutdownDebugProgress;-><init>(JLjava/lang/Long;ZLjava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownReturnedStatus;Ljava/lang/String;Ljava/lang/Long;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-direct {v9, v10}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object v9, v0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    .line 66
    new-instance v9, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda0;

    invoke-direct {v9}, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda0;-><init>()V

    invoke-static {v9}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v9

    iput-object v9, v0, Lorg/lighttouch/android/ShutdownWatchdog;->timer:Ljava/util/concurrent/ScheduledExecutorService;

    .line 53
    return-void
.end method

.method public synthetic constructor <init>(JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 10

    .line 53
    and-int/lit8 v0, p9, 0x40

    if-eqz v0, :cond_0

    .line 60
    new-instance v0, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda3;

    invoke-direct {v0}, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda3;-><init>()V

    move-object v9, v0

    goto :goto_0

    .line 53
    :cond_0
    move-object/from16 v9, p8

    :goto_0
    move-object v1, p0

    move-wide v2, p1

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    invoke-direct/range {v1 .. v9}, Lorg/lighttouch/android/ShutdownWatchdog;-><init>(JLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V

    .line 61
    return-void
.end method

.method private static final _init_$lambda$0(Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/ShutdownReceipt;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$call(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownDebugProgress;Lorg/lighttouch/android/ShutdownWatchdog$Call;)Lorg/lighttouch/android/ShutdownCallProgress;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/ShutdownWatchdog;
    .param p1, "$receiver"    # Lorg/lighttouch/android/ShutdownDebugProgress;
    .param p2, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;

    .line 53
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/ShutdownWatchdog;->call(Lorg/lighttouch/android/ShutdownDebugProgress;Lorg/lighttouch/android/ShutdownWatchdog$Call;)Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getAcceptedAt$p(Lorg/lighttouch/android/ShutdownWatchdog;)J
    .locals 2
    .param p0, "$this"    # Lorg/lighttouch/android/ShutdownWatchdog;

    .line 53
    iget-wide v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->acceptedAt:J

    return-wide v0
.end method

.method public static final synthetic access$getDeadline$p(Lorg/lighttouch/android/ShutdownWatchdog;)J
    .locals 2
    .param p0, "$this"    # Lorg/lighttouch/android/ShutdownWatchdog;

    .line 53
    iget-wide v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->deadline:J

    return-wide v0
.end method

.method public static final synthetic access$withCall(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownDebugProgress;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lorg/lighttouch/android/ShutdownCallProgress;)Lorg/lighttouch/android/ShutdownDebugProgress;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/ShutdownWatchdog;
    .param p1, "$receiver"    # Lorg/lighttouch/android/ShutdownDebugProgress;
    .param p2, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .param p3, "value"    # Lorg/lighttouch/android/ShutdownCallProgress;

    .line 53
    invoke-direct {p0, p1, p2, p3}, Lorg/lighttouch/android/ShutdownWatchdog;->withCall(Lorg/lighttouch/android/ShutdownDebugProgress;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lorg/lighttouch/android/ShutdownCallProgress;)Lorg/lighttouch/android/ShutdownDebugProgress;

    move-result-object v0

    return-object v0
.end method

.method private final call(Lorg/lighttouch/android/ShutdownDebugProgress;Lorg/lighttouch/android/ShutdownWatchdog$Call;)Lorg/lighttouch/android/ShutdownCallProgress;
    .locals 2
    .param p1, "$this$call"    # Lorg/lighttouch/android/ShutdownDebugProgress;
    .param p2, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;

    .line 89
    sget-object v0, Lorg/lighttouch/android/ShutdownWatchdog$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p2}, Lorg/lighttouch/android/ShutdownWatchdog$Call;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    .line 90
    :pswitch_0
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getReceipt()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v0

    goto :goto_0

    :pswitch_1
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getStatus()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v0

    goto :goto_0

    :pswitch_2
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getCancel()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v0

    goto :goto_0

    :pswitch_3
    invoke-virtual {p1}, Lorg/lighttouch/android/ShutdownDebugProgress;->getStop()Lorg/lighttouch/android/ShutdownCallProgress;

    move-result-object v0

    .line 91
    :goto_0
    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private final enter(Lorg/lighttouch/android/ShutdownWatchdog$Call;)V
    .locals 6
    .param p1, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;

    .line 96
    move-object v0, p0

    .local v0, "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    const/4 v1, 0x0

    .line 183
    .local v1, "$i$f$publish\\1\\96":I
    nop

    .line 184
    :try_start_0
    iget-object v2, v0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .line 185
    .local v2, "at\\1":J
    iget-object v4, v0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v5, Lorg/lighttouch/android/ShutdownWatchdog$enter$$inlined$publish$1;

    invoke-direct {v5, v2, v3, p0, p1}, Lorg/lighttouch/android/ShutdownWatchdog$enter$$inlined$publish$1;-><init>(JLorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;)V

    check-cast v5, Ljava/util/function/UnaryOperator;

    invoke-virtual {v4, v5}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .end local v2    # "at\\1":J
    goto :goto_0

    .line 187
    :catch_0
    move-exception v2

    goto :goto_0

    .line 186
    :catch_1
    move-exception v2

    .line 188
    :goto_0
    nop

    .line 99
    .end local v0    # "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    .end local v1    # "$i$f$publish\\1\\96":I
    return-void
.end method

.method private final finish(Ljava/lang/String;Ljava/lang/String;)V
    .locals 13
    .param p1, "reason"    # Ljava/lang/String;
    .param p2, "state"    # Ljava/lang/String;

    .line 168
    new-instance v0, Lorg/lighttouch/android/ShutdownReceipt;

    iget-object v1, p0, Lorg/lighttouch/android/ShutdownWatchdog;->progress:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    const-string v2, "get(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v1

    check-cast v2, Lorg/lighttouch/android/ShutdownProgress;

    iget-wide v4, p0, Lorg/lighttouch/android/ShutdownWatchdog;->acceptedAt:J

    iget-wide v6, p0, Lorg/lighttouch/android/ShutdownWatchdog;->deadline:J

    iget-object v1, p0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v8

    const/16 v11, 0x40

    const/4 v12, 0x0

    const/4 v10, 0x0

    move-object v1, p1

    move-object v3, p2

    .end local p1    # "reason":Ljava/lang/String;
    .end local p2    # "state":Ljava/lang/String;
    .local v1, "reason":Ljava/lang/String;
    .local v3, "state":Ljava/lang/String;
    invoke-direct/range {v0 .. v12}, Lorg/lighttouch/android/ShutdownReceipt;-><init>(Ljava/lang/String;Lorg/lighttouch/android/ShutdownProgress;Ljava/lang/String;JJJLorg/lighttouch/android/ShutdownNativeSnapshot;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-direct {p0, v0}, Lorg/lighttouch/android/ShutdownWatchdog;->finish(Lorg/lighttouch/android/ShutdownReceipt;)V

    .line 169
    return-void
.end method

.method private final finish(Lorg/lighttouch/android/ShutdownReceipt;)V
    .locals 6
    .param p1, "receipt"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 171
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 172
    :cond_0
    move-object v0, p0

    .local v0, "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    const/4 v1, 0x0

    .line 202
    .local v1, "$i$f$publish\\1\\172":I
    nop

    .line 203
    :try_start_0
    iget-object v2, v0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .line 204
    .local v2, "at\\1":J
    iget-object v4, v0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v5, Lorg/lighttouch/android/ShutdownWatchdog$finish$$inlined$publish$1;

    invoke-direct {v5, v2, v3, p1}, Lorg/lighttouch/android/ShutdownWatchdog$finish$$inlined$publish$1;-><init>(JLorg/lighttouch/android/ShutdownReceipt;)V

    check-cast v5, Ljava/util/function/UnaryOperator;

    invoke-virtual {v4, v5}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .end local v2    # "at\\1":J
    goto :goto_0

    .line 206
    :catch_0
    move-exception v2

    goto :goto_0

    .line 205
    :catch_1
    move-exception v2

    .line 207
    :goto_0
    nop

    .line 173
    .end local v0    # "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    .end local v1    # "$i$f$publish\\1\\172":I
    :try_start_1
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->dispose:Lkotlin/jvm/functions/Function1;

    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->timer:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    .line 174
    return-void

    .line 173
    :catchall_0
    move-exception v0

    iget-object v1, p0, Lorg/lighttouch/android/ShutdownWatchdog;->timer:Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v1}, Ljava/util/concurrent/ScheduledExecutorService;->shutdownNow()Ljava/util/List;

    throw v0
.end method

.method private final publish(Lkotlin/jvm/functions/Function2;)V
    .locals 5
    .param p1, "change"    # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lorg/lighttouch/android/ShutdownDebugProgress;",
            "-",
            "Ljava/lang/Long;",
            "Lorg/lighttouch/android/ShutdownDebugProgress;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    .line 77
    .local v0, "$i$f$publish":I
    nop

    .line 78
    :try_start_0
    iget-object v1, p0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    .line 79
    .local v1, "at":J
    iget-object v3, p0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v4, Lorg/lighttouch/android/ShutdownWatchdog$publish$1;

    invoke-direct {v4, p1, v1, v2}, Lorg/lighttouch/android/ShutdownWatchdog$publish$1;-><init>(Lkotlin/jvm/functions/Function2;J)V

    check-cast v4, Ljava/util/function/UnaryOperator;

    invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .end local v1    # "at":J
    goto :goto_0

    .line 81
    :catch_0
    move-exception v1

    goto :goto_0

    .line 80
    :catch_1
    move-exception v1

    .line 82
    :goto_0
    return-void
.end method

.method private static final request$lambda$13(Lorg/lighttouch/android/ShutdownWatchdog;)V
    .locals 24
    .param p0, "this$0"    # Lorg/lighttouch/android/ShutdownWatchdog;

    .line 128
    move-object/from16 v1, p0

    const-string v0, "failed"

    const-string v7, "terminal-receipt"

    .line 129
    const/16 v8, 0x1000

    :try_start_0
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_0

    return-void

    .line 130
    :cond_0
    sget-object v2, Lorg/lighttouch/android/ShutdownWatchdog$Call;->STOP:Lorg/lighttouch/android/ShutdownWatchdog$Call;

    iget-object v3, v1, Lorg/lighttouch/android/ShutdownWatchdog;->requestNativeStop:Lkotlin/jvm/functions/Function0;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/ShutdownWatchdog;->tracked$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2, v8}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    move-object v9, v2

    .line 131
    .local v9, "admissionError":Ljava/lang/String;
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_1

    return-void

    .line 132
    :cond_1
    new-instance v2, Lorg/lighttouch/android/ShutdownProgress;

    const-string v3, "contact-cancellation"

    invoke-direct {v2, v3, v9}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v1, v2}, Lorg/lighttouch/android/ShutdownWatchdog;->setProgress(Lorg/lighttouch/android/ShutdownProgress;)V

    .line 133
    sget-object v2, Lorg/lighttouch/android/ShutdownWatchdog$Call;->CANCEL:Lorg/lighttouch/android/ShutdownWatchdog$Call;

    iget-object v3, v1, Lorg/lighttouch/android/ShutdownWatchdog;->cancelNativeContacts:Lkotlin/jvm/functions/Function0;

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/ShutdownWatchdog;->tracked$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/Object;

    .line 134
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_2

    return-void

    .line 135
    :cond_2
    new-instance v2, Lorg/lighttouch/android/ShutdownProgress;

    const-string v3, "terminal-poll"

    invoke-direct {v2, v3, v9}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v1, v2}, Lorg/lighttouch/android/ShutdownWatchdog;->setProgress(Lorg/lighttouch/android/ShutdownProgress;)V

    .line 136
    :goto_0
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_11

    .line 137
    sget-object v2, Lorg/lighttouch/android/ShutdownWatchdog$Call;->STATUS:Lorg/lighttouch/android/ShutdownWatchdog$Call;

    iget-object v3, v1, Lorg/lighttouch/android/ShutdownWatchdog;->nativeStatus:Lkotlin/jvm/functions/Function0;

    new-instance v4, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda1;

    invoke-direct {v4}, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda1;-><init>()V

    invoke-direct {v1, v2, v3, v4}, Lorg/lighttouch/android/ShutdownWatchdog;->tracked(Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    move-object v10, v2

    .line 138
    .local v10, "state":[Ljava/lang/String;
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->disposed:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_3

    return-void

    .line 139
    :cond_3
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    iget-wide v4, v1, Lorg/lighttouch/android/ShutdownWatchdog;->deadline:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    cmp-long v2, v2, v4

    const-string v11, "deadline-unconfirmed"

    const/4 v12, 0x0

    if-ltz v2, :cond_4

    :try_start_1
    invoke-direct {v1, v11, v12}, Lorg/lighttouch/android/ShutdownWatchdog;->finish(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 140
    :cond_4
    const/4 v2, 0x2

    new-array v3, v2, [Ljava/lang/String;

    const-string v4, "stopped"

    const/4 v5, 0x0

    aput-object v4, v3, v5

    const/4 v4, 0x1

    aput-object v0, v3, v4

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    invoke-static {v10}, Lkotlin/collections/ArraysKt;->firstOrNull([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v3, v6}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    .line 141
    invoke-static {v10}, Lkotlin/collections/ArraysKt;->firstOrNull([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 142
    invoke-static {v10, v2}, Lkotlin/collections/ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_7

    move-object v2, v0

    .line 201
    .local v2, "it\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 142
    .local v3, "$i$a$-takeIf-ShutdownWatchdog$request$3$reportedError$1\\1\\142\\0":I
    move-object v6, v2

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-lez v6, :cond_5

    move v6, v4

    goto :goto_1

    :cond_5
    move v6, v5

    .end local v2    # "it\\1":Ljava/lang/String;
    .end local v3    # "$i$a$-takeIf-ShutdownWatchdog$request$3$reportedError$1\\1\\142\\0":I
    :goto_1
    if-eqz v6, :cond_6

    goto :goto_2

    :cond_6
    move-object v0, v12

    :goto_2
    if-nez v0, :cond_d

    .line 143
    :cond_7
    move-object v0, v9

    .line 201
    .local v0, "it\\2":Ljava/lang/String;
    const/4 v2, 0x0

    .line 143
    .local v2, "$i$a$-takeIf-ShutdownWatchdog$request$3$reportedError$2\\2\\143\\0":I
    move-object v3, v0

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_8

    move v3, v4

    goto :goto_3

    :cond_8
    move v3, v5

    .end local v0    # "it\\2":Ljava/lang/String;
    .end local v2    # "$i$a$-takeIf-ShutdownWatchdog$request$3$reportedError$2\\2\\143\\0":I
    :goto_3
    if-eqz v3, :cond_9

    move-object v0, v9

    goto :goto_4

    :cond_9
    move-object v0, v12

    .line 142
    :goto_4
    if-nez v0, :cond_d

    .line 144
    array-length v0, v10

    if-ge v4, v0, :cond_a

    move v5, v4

    :cond_a
    if-eqz v5, :cond_b

    aget-object v0, v10, v4

    goto :goto_5

    .line 201
    .local v4, "it\\3":I
    :cond_b
    const/4 v0, 0x0

    .line 144
    .local v0, "$i$a$-getOrElse-ShutdownWatchdog$request$3$reportedError$3\\3\\144\\0":I
    const-string v2, "\u5173\u673a\u672a\u5f97\u5230\u786e\u8ba4"

    move-object v0, v2

    .end local v0    # "$i$a$-getOrElse-ShutdownWatchdog$request$3$reportedError$3\\3\\144\\0":I
    .end local v4    # "it\\3":I
    goto :goto_5

    .line 145
    :cond_c
    move-object v0, v9

    .line 141
    :cond_d
    :goto_5
    nop

    .line 146
    .local v0, "reportedError":Ljava/lang/String;
    new-instance v2, Lorg/lighttouch/android/ShutdownProgress;

    const-string v3, "native-terminal"

    invoke-static {v0, v8}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v1, v2}, Lorg/lighttouch/android/ShutdownWatchdog;->setProgress(Lorg/lighttouch/android/ShutdownProgress;)V

    .line 147
    new-instance v13, Lorg/lighttouch/android/ShutdownReceipt;

    const-string v14, "native-terminal"

    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->progress:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    const-string v3, "get(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v15, v2

    check-cast v15, Lorg/lighttouch/android/ShutdownProgress;

    invoke-static {v10}, Lkotlin/collections/ArraysKt;->firstOrNull([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v16, v2

    check-cast v16, Ljava/lang/String;

    .line 148
    iget-wide v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->acceptedAt:J

    iget-wide v4, v1, Lorg/lighttouch/android/ShutdownWatchdog;->deadline:J

    iget-object v6, v1, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v6}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    move-result-wide v21

    sget-object v6, Lorg/lighttouch/android/ShutdownNativeSnapshot;->Companion:Lorg/lighttouch/android/ShutdownNativeSnapshot$Companion;

    invoke-virtual {v6, v10}, Lorg/lighttouch/android/ShutdownNativeSnapshot$Companion;->from([Ljava/lang/String;)Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v23

    .line 147
    move-wide/from16 v17, v2

    move-wide/from16 v19, v4

    invoke-direct/range {v13 .. v23}, Lorg/lighttouch/android/ShutdownReceipt;-><init>(Ljava/lang/String;Lorg/lighttouch/android/ShutdownProgress;Ljava/lang/String;JJJLorg/lighttouch/android/ShutdownNativeSnapshot;)V

    .line 151
    .local v13, "terminal":Lorg/lighttouch/android/ShutdownReceipt;
    new-instance v2, Lorg/lighttouch/android/ShutdownProgress;

    invoke-static {v0, v8}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v7, v3}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v1, v2}, Lorg/lighttouch/android/ShutdownWatchdog;->setProgress(Lorg/lighttouch/android/ShutdownProgress;)V

    .line 152
    sget-object v2, Lorg/lighttouch/android/ShutdownWatchdog$Call;->RECEIPT:Lorg/lighttouch/android/ShutdownWatchdog$Call;

    new-instance v3, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda2;

    invoke-direct {v3, v1, v13}, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownReceipt;)V

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/ShutdownWatchdog;->tracked$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/Object;

    .line 153
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    iget-wide v4, v1, Lorg/lighttouch/android/ShutdownWatchdog;->deadline:J

    cmp-long v2, v2, v4

    if-ltz v2, :cond_e

    invoke-direct {v1, v11, v12}, Lorg/lighttouch/android/ShutdownWatchdog;->finish(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 154
    :cond_e
    invoke-direct {v1, v13}, Lorg/lighttouch/android/ShutdownWatchdog;->finish(Lorg/lighttouch/android/ShutdownReceipt;)V

    return-void

    .line 156
    .end local v0    # "reportedError":Ljava/lang/String;
    .end local v13    # "terminal":Lorg/lighttouch/android/ShutdownReceipt;
    :cond_f
    const-wide/16 v2, 0x64

    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .end local v10    # "state":[Ljava/lang/String;
    goto/16 :goto_0

    .line 158
    .end local v9    # "admissionError":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 160
    .local v0, "failure":Ljava/lang/Exception;
    iget-object v2, v1, Lorg/lighttouch/android/ShutdownWatchdog;->progress:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/ShutdownProgress;

    invoke-virtual {v2}, Lorg/lighttouch/android/ShutdownProgress;->getStage()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_10

    const-string v2, "terminal-receipt-failed"

    goto :goto_6

    :cond_10
    const-string v2, "native-call-failed"

    .line 161
    .local v2, "stage":Ljava/lang/String;
    :goto_6
    new-instance v3, Lorg/lighttouch/android/ShutdownProgress;

    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v8}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v2, v4}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v1, v3}, Lorg/lighttouch/android/ShutdownWatchdog;->setProgress(Lorg/lighttouch/android/ShutdownProgress;)V

    .line 163
    .end local v0    # "failure":Ljava/lang/Exception;
    .end local v2    # "stage":Ljava/lang/String;
    :cond_11
    return-void
.end method

.method private static final request$lambda$13$lambda$12(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownReceipt;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/ShutdownWatchdog;
    .param p1, "$terminal"    # Lorg/lighttouch/android/ShutdownReceipt;

    .line 152
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->persistTerminal:Lkotlin/jvm/functions/Function1;

    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final request$lambda$13$lambda$8([Ljava/lang/String;)[Ljava/lang/String;
    .locals 1
    .param p0, "it"    # [Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    return-object p0
.end method

.method private static final request$lambda$7(Lorg/lighttouch/android/ShutdownWatchdog;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/ShutdownWatchdog;

    .line 126
    const-string v0, "deadline-unconfirmed"

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lorg/lighttouch/android/ShutdownWatchdog;->finish(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private final returned(Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;)V
    .locals 12
    .param p1, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .param p2, "failure"    # Ljava/lang/Exception;
    .param p3, "state"    # [Ljava/lang/String;

    .line 100
    move-object v1, p0

    .local v1, "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    const/4 v2, 0x0

    .line 189
    .local v2, "$i$f$publish\\1\\100":I
    nop

    .line 190
    :try_start_0
    iget-object v0, v1, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    move-wide v6, v3

    .line 191
    .local v6, "at\\1":J
    iget-object v0, v1, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v5, Lorg/lighttouch/android/ShutdownWatchdog$returned$$inlined$publish$1;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_2

    move-object v8, p0

    move-object v9, p1

    move-object v10, p2

    move-object v11, p3

    .end local p1    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .end local p2    # "failure":Ljava/lang/Exception;
    .end local p3    # "state":[Ljava/lang/String;
    .local v9, "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .local v10, "failure":Ljava/lang/Exception;
    .local v11, "state":[Ljava/lang/String;
    :try_start_1
    invoke-direct/range {v5 .. v11}, Lorg/lighttouch/android/ShutdownWatchdog$returned$$inlined$publish$1;-><init>(JLorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;)V

    check-cast v5, Ljava/util/function/UnaryOperator;

    invoke-virtual {v0, v5}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_0

    .end local v6    # "at\\1":J
    goto :goto_0

    .line 193
    :catch_0
    move-exception v0

    goto :goto_0

    .line 192
    :catch_1
    move-exception v0

    goto :goto_0

    .line 193
    .end local v9    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .end local v10    # "failure":Ljava/lang/Exception;
    .end local v11    # "state":[Ljava/lang/String;
    .restart local p1    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .restart local p2    # "failure":Ljava/lang/Exception;
    .restart local p3    # "state":[Ljava/lang/String;
    :catch_2
    move-exception v0

    move-object v9, p1

    move-object v10, p2

    move-object v11, p3

    .end local p1    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .end local p2    # "failure":Ljava/lang/Exception;
    .end local p3    # "state":[Ljava/lang/String;
    .restart local v9    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .restart local v10    # "failure":Ljava/lang/Exception;
    .restart local v11    # "state":[Ljava/lang/String;
    goto :goto_0

    .line 192
    .end local v9    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .end local v10    # "failure":Ljava/lang/Exception;
    .end local v11    # "state":[Ljava/lang/String;
    .restart local p1    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .restart local p2    # "failure":Ljava/lang/Exception;
    .restart local p3    # "state":[Ljava/lang/String;
    :catch_3
    move-exception v0

    move-object v9, p1

    move-object v10, p2

    move-object v11, p3

    .line 194
    .end local p1    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .end local p2    # "failure":Ljava/lang/Exception;
    .end local p3    # "state":[Ljava/lang/String;
    .restart local v9    # "kind":Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .restart local v10    # "failure":Ljava/lang/Exception;
    .restart local v11    # "state":[Ljava/lang/String;
    :goto_0
    nop

    .line 108
    .end local v1    # "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    .end local v2    # "$i$f$publish\\1\\100":I
    return-void
.end method

.method static synthetic returned$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;ILjava/lang/Object;)V
    .locals 1

    .line 100
    and-int/lit8 p5, p4, 0x2

    const/4 v0, 0x0

    if-eqz p5, :cond_0

    move-object p2, v0

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    move-object p3, v0

    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lorg/lighttouch/android/ShutdownWatchdog;->returned(Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;)V

    return-void
.end method

.method private final setProgress(Lorg/lighttouch/android/ShutdownProgress;)V
    .locals 6
    .param p1, "value"    # Lorg/lighttouch/android/ShutdownProgress;

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->progress:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 85
    move-object v0, p0

    .local v0, "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    const/4 v1, 0x0

    .line 177
    .local v1, "$i$f$publish\\1\\85":I
    nop

    .line 178
    :try_start_0
    iget-object v2, v0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .line 179
    .local v2, "at\\1":J
    iget-object v4, v0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v5, Lorg/lighttouch/android/ShutdownWatchdog$setProgress$$inlined$publish$1;

    invoke-direct {v5, v2, v3, p1}, Lorg/lighttouch/android/ShutdownWatchdog$setProgress$$inlined$publish$1;-><init>(JLorg/lighttouch/android/ShutdownProgress;)V

    check-cast v5, Ljava/util/function/UnaryOperator;

    invoke-virtual {v4, v5}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .end local v2    # "at\\1":J
    goto :goto_0

    .line 181
    :catch_0
    move-exception v2

    goto :goto_0

    .line 180
    :catch_1
    move-exception v2

    .line 182
    :goto_0
    nop

    .line 88
    .end local v0    # "this_\\1":Lorg/lighttouch/android/ShutdownWatchdog;
    .end local v1    # "$i$f$publish\\1\\85":I
    return-void
.end method

.method private static final timer$lambda$2(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 4
    .param p0, "task"    # Ljava/lang/Runnable;

    .line 66
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "guest-stop-deadline"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    move-object v1, v0

    .line 201
    .local v1, "$this$timer_u24lambda_u242_u24lambda_u241\\1":Ljava/lang/Thread;
    const/4 v2, 0x0

    .line 66
    .local v2, "$i$a$-apply-ShutdownWatchdog$timer$1$1\\1\\66\\0":I
    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/Thread;->setDaemon(Z)V

    .end local v1    # "$this$timer_u24lambda_u242_u24lambda_u241\\1":Ljava/lang/Thread;
    .end local v2    # "$i$a$-apply-ShutdownWatchdog$timer$1$1\\1\\66\\0":I
    return-object v0
.end method

.method private final tracked(Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;
    .locals 15
    .param p1, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .param p2, "action"    # Lkotlin/jvm/functions/Function0;
    .param p3, "returnedState"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lorg/lighttouch/android/ShutdownWatchdog$Call;",
            "Lkotlin/jvm/functions/Function0<",
            "+TT;>;",
            "Lkotlin/jvm/functions/Function1<",
            "-TT;[",
            "Ljava/lang/String;",
            ">;)TT;"
        }
    .end annotation

    .line 110
    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/ShutdownWatchdog;->enter(Lorg/lighttouch/android/ShutdownWatchdog$Call;)V

    .line 111
    nop

    .line 112
    :try_start_0
    invoke-interface/range {p2 .. p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 113
    .local v0, "value":Ljava/lang/Object;
    move-object/from16 v1, p3

    :try_start_1
    invoke-interface {v1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    move-object v6, v2

    check-cast v6, [Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v5, 0x0

    move-object v3, p0

    move-object/from16 v4, p1

    invoke-static/range {v3 .. v8}, Lorg/lighttouch/android/ShutdownWatchdog;->returned$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;ILjava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 114
    return-object v0

    .line 115
    .end local v0    # "value":Ljava/lang/Object;
    :catch_0
    move-exception v0

    goto :goto_0

    :catch_1
    move-exception v0

    move-object/from16 v1, p3

    :goto_0
    move-object v11, v0

    .local v11, "failure":Ljava/lang/Exception;
    const/4 v13, 0x4

    const/4 v14, 0x0

    const/4 v12, 0x0

    move-object v9, p0

    move-object/from16 v10, p1

    invoke-static/range {v9 .. v14}, Lorg/lighttouch/android/ShutdownWatchdog;->returned$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Ljava/lang/Exception;[Ljava/lang/String;ILjava/lang/Object;)V

    throw v11
.end method

.method static synthetic tracked$default(Lorg/lighttouch/android/ShutdownWatchdog;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 109
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    sget-object p3, Lorg/lighttouch/android/ShutdownWatchdog$tracked$1;->INSTANCE:Lorg/lighttouch/android/ShutdownWatchdog$tracked$1;

    check-cast p3, Lkotlin/jvm/functions/Function1;

    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lorg/lighttouch/android/ShutdownWatchdog;->tracked(Lorg/lighttouch/android/ShutdownWatchdog$Call;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method private final withCall(Lorg/lighttouch/android/ShutdownDebugProgress;Lorg/lighttouch/android/ShutdownWatchdog$Call;Lorg/lighttouch/android/ShutdownCallProgress;)Lorg/lighttouch/android/ShutdownDebugProgress;
    .locals 21
    .param p1, "$this$withCall"    # Lorg/lighttouch/android/ShutdownDebugProgress;
    .param p2, "kind"    # Lorg/lighttouch/android/ShutdownWatchdog$Call;
    .param p3, "value"    # Lorg/lighttouch/android/ShutdownCallProgress;

    .line 92
    sget-object v0, Lorg/lighttouch/android/ShutdownWatchdog$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/ShutdownWatchdog$Call;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    .line 94
    :pswitch_0
    const v19, 0xefff

    const/16 v20, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v1, p1

    move-object/from16 v15, p3

    goto :goto_0

    :pswitch_1
    const v19, 0xf7ff

    const/16 v20, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v1, p1

    move-object/from16 v14, p3

    :goto_0
    invoke-static/range {v1 .. v20}, Lorg/lighttouch/android/ShutdownDebugProgress;->copy$default(Lorg/lighttouch/android/ShutdownDebugProgress;JLjava/lang/Long;ZLjava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownReturnedStatus;Ljava/lang/String;Ljava/lang/Long;ILjava/lang/Object;)Lorg/lighttouch/android/ShutdownDebugProgress;

    move-result-object v0

    goto :goto_2

    .line 93
    :pswitch_2
    const v19, 0xfbff

    const/16 v20, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v1, p1

    move-object/from16 v13, p3

    goto :goto_1

    :pswitch_3
    const v19, 0xfdff

    const/16 v20, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v1, p1

    move-object/from16 v12, p3

    :goto_1
    invoke-static/range {v1 .. v20}, Lorg/lighttouch/android/ShutdownDebugProgress;->copy$default(Lorg/lighttouch/android/ShutdownDebugProgress;JLjava/lang/Long;ZLjava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/String;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownCallProgress;Lorg/lighttouch/android/ShutdownReturnedStatus;Ljava/lang/String;Ljava/lang/Long;ILjava/lang/Object;)Lorg/lighttouch/android/ShutdownDebugProgress;

    move-result-object v0

    .line 95
    :goto_2
    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final cachedProgress()Lorg/lighttouch/android/ShutdownDebugProgress;
    .locals 2

    .line 70
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "get(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lorg/lighttouch/android/ShutdownDebugProgress;

    return-object v0
.end method

.method public final request()Z
    .locals 7

    .line 119
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->requested:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_0

    return v1

    .line 120
    :cond_0
    iget-wide v3, p0, Lorg/lighttouch/android/ShutdownWatchdog;->graceMs:J

    const-wide/16 v5, 0x0

    cmp-long v0, v3, v5

    if-lez v0, :cond_1

    move v1, v2

    :cond_1
    if-eqz v1, :cond_2

    .line 121
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    iput-wide v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->acceptedAt:J

    iget-wide v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->acceptedAt:J

    iget-wide v3, p0, Lorg/lighttouch/android/ShutdownWatchdog;->graceMs:J

    add-long/2addr v0, v3

    iput-wide v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->deadline:J

    .line 122
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->progress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v1, Lorg/lighttouch/android/ShutdownProgress;

    const-string v3, "shutdown-admission"

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v1, v3, v5, v4, v5}, Lorg/lighttouch/android/ShutdownProgress;-><init>(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 123
    move-object v0, p0

    .local v0, "this_\\2":Lorg/lighttouch/android/ShutdownWatchdog;
    const/4 v1, 0x0

    .line 195
    .local v1, "$i$f$publish\\2\\123":I
    nop

    .line 196
    :try_start_0
    iget-object v3, v0, Lorg/lighttouch/android/ShutdownWatchdog;->now:Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    .line 197
    .local v3, "at\\2":J
    iget-object v5, v0, Lorg/lighttouch/android/ShutdownWatchdog;->debugProgress:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v6, Lorg/lighttouch/android/ShutdownWatchdog$request$$inlined$publish$1;

    invoke-direct {v6, v3, v4, p0}, Lorg/lighttouch/android/ShutdownWatchdog$request$$inlined$publish$1;-><init>(JLorg/lighttouch/android/ShutdownWatchdog;)V

    check-cast v6, Ljava/util/function/UnaryOperator;

    invoke-virtual {v5, v6}, Ljava/util/concurrent/atomic/AtomicReference;->updateAndGet(Ljava/util/function/UnaryOperator;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .end local v3    # "at\\2":J
    goto :goto_0

    .line 199
    :catch_0
    move-exception v3

    goto :goto_0

    .line 198
    :catch_1
    move-exception v3

    .line 200
    :goto_0
    nop

    .line 126
    .end local v0    # "this_\\2":Lorg/lighttouch/android/ShutdownWatchdog;
    .end local v1    # "$i$f$publish\\2\\123":I
    iget-object v0, p0, Lorg/lighttouch/android/ShutdownWatchdog;->timer:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/ShutdownWatchdog;)V

    iget-wide v3, p0, Lorg/lighttouch/android/ShutdownWatchdog;->graceMs:J

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v3, v4, v5}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    .line 127
    new-instance v0, Ljava/lang/Thread;

    .line 163
    new-instance v1, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/ShutdownWatchdog$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/ShutdownWatchdog;)V

    .line 127
    const-string v3, "guest-stop-admission"

    invoke-direct {v0, v1, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 163
    move-object v1, v0

    .line 201
    .local v1, "$this$request_u24lambda_u2414\\3":Ljava/lang/Thread;
    const/4 v3, 0x0

    .line 163
    .local v3, "$i$a$-apply-ShutdownWatchdog$request$4\\3\\163\\0":I
    invoke-virtual {v1, v2}, Ljava/lang/Thread;->setDaemon(Z)V

    .end local v1    # "$this$request_u24lambda_u2414\\3":Ljava/lang/Thread;
    .end local v3    # "$i$a$-apply-ShutdownWatchdog$request$4\\3\\163\\0":I
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 164
    return v2

    .line 120
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u65ad\u8a00\u5931\u8d25\u3002"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

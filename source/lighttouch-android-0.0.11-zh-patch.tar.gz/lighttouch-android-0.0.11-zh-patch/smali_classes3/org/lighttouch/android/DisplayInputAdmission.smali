.class public final Lorg/lighttouch/android/DisplayInputAdmission;
.super Ljava/lang/Object;
.source "DisplayOwnership.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0005\n\u0002\u0010\u000b\n\u0002\u0008\u0002\u0008\u00c1\u0002\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"
    }
    d2 = {
        "Lorg/lighttouch/android/DisplayInputAdmission;",
        "",
        "<init>",
        "()V",
        "GENERATION_RETIRED",
        "",
        "PAUSED",
        "VIEWPORT_CANCELLED",
        "NO_SESSION",
        "NO_FRAME",
        "isCancellation",
        "",
        "value",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x0

.field public static final GENERATION_RETIRED:Ljava/lang/String; = "Display input generation retired"

.field public static final INSTANCE:Lorg/lighttouch/android/DisplayInputAdmission;

.field public static final NO_FRAME:Ljava/lang/String; = "No active guest frame; gesture cancelled"

.field public static final NO_SESSION:Ljava/lang/String; = "No active guest session; touch was not admitted"

.field public static final PAUSED:Ljava/lang/String; = "Display input is paused"

.field public static final VIEWPORT_CANCELLED:Ljava/lang/String; = "Display input outside guest viewport; gesture cancelled"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lorg/lighttouch/android/DisplayInputAdmission;

    invoke-direct {v0}, Lorg/lighttouch/android/DisplayInputAdmission;-><init>()V

    sput-object v0, Lorg/lighttouch/android/DisplayInputAdmission;->INSTANCE:Lorg/lighttouch/android/DisplayInputAdmission;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final isCancellation(Ljava/lang/String;)Z
    .locals 1
    .param p1, "value"    # Ljava/lang/String;

    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    const-string v0, "\u663e\u793a\u8f93\u5165\u4ee3\u6b21\u5df2\u91ca\u653e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "\u663e\u793a\u8f93\u5165\u5df2\u6682\u505c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Display input outside guest viewport; gesture cancelled"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 54
    const-string v0, "No active guest session; touch was not admitted"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "No active guest frame; gesture cancelled"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

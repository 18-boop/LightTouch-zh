.class public final Lorg/lighttouch/android/EngineService$binder$1;
.super Lorg/lighttouch/android/IEngine$Stub;
.source "EngineService.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/EngineService;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEngineService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EngineService.kt\norg/lighttouch/android/EngineService$binder$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,678:1\n1#2:679\n1#2:690\n11546#3,9:680\n13472#3:689\n13473#3:691\n11555#3:692\n37#4:693\n36#4,3:694\n1869#5,2:697\n*S KotlinDebug\n*F\n+ 1 EngineService.kt\norg/lighttouch/android/EngineService$binder$1\n*L\n139#1:690\n139#1:680,9\n139#1:689\n139#1:691\n139#1:692\n147#1:693\n147#1:694,3\n173#1:697,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000W\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0015\n\u0002\u0010\u0011\n\u0002\u0008\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0015\n\u0002\u0008\u0002\n\u0002\u0010\u0014\n\u0002\u0008\u0014*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0003H\u0016J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0016J0\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u000c\u001a\u00020\u0003H\u0016J\u0008\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\u0010\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J\u0010\u0010\u0019\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u0018H\u0016J\u0008\u0010\u001b\u001a\u00020\u000eH\u0016J\u0008\u0010\u001c\u001a\u00020\u000eH\u0016J\u0010\u0010\u001d\u001a\u00020\u000e2\u0006\u0010\u001e\u001a\u00020\u0011H\u0016J\u0008\u0010\u001f\u001a\u00020\u0013H\u0002J\u0008\u0010 \u001a\u00020\u000eH\u0016J\u0008\u0010!\u001a\u00020\u0003H\u0016J\u0008\u0010\"\u001a\u00020\u0003H\u0016J\u0010\u0010#\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u0018H\u0016J\u0008\u0010$\u001a\u00020\u0003H\u0016J\u0010\u0010%\u001a\u00020\u00032\u0006\u0010&\u001a\u00020\u0015H\u0016J\u0008\u0010\'\u001a\u00020\u000eH\u0016J\u0018\u0010(\u001a\u00020\u00032\u0006\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0003H\u0016J \u0010)\u001a\u00020\u00032\u0006\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0003H\u0016J \u0010*\u001a\u00020\u00032\u0006\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0003H\u0016J\u0018\u0010+\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010,\u001a\u00020\u0003H\u0016J\u0013\u0010-\u001a\u0008\u0012\u0004\u0012\u00020\u000e0.H\u0016\u00a2\u0006\u0002\u0010/J\u0010\u00100\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0003H\u0016J\u0010\u00101\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u0003H\u0016J\u0010\u00102\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u0003H\u0016J\u0018\u00103\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u00104\u001a\u00020\u0018H\u0002J\u0010\u00105\u001a\u00020\u000e2\u0006\u00106\u001a\u00020\u0018H\u0016J\u0008\u00107\u001a\u00020\u000eH\u0016J\u0008\u00108\u001a\u00020\u0011H\u0016J\u0010\u00109\u001a\u00020\u00112\u0006\u0010:\u001a\u00020\u0011H\u0016J\u0018\u0010;\u001a\u00020\u00032\u0006\u0010:\u001a\u00020\u00112\u0006\u0010<\u001a\u00020=H\u0016J\u0010\u0010>\u001a\u00020\u00132\u0006\u0010:\u001a\u00020\u0011H\u0016J\u0010\u0010?\u001a\u00020\u00132\u0006\u0010:\u001a\u00020\u0011H\u0016J\u0010\u0010@\u001a\u00020\u00132\u0006\u0010:\u001a\u00020\u0011H\u0016J\u0010\u0010A\u001a\u00020\u00132\u0006\u0010:\u001a\u00020\u0011H\u0016J\u0010\u0010B\u001a\u00020\u00132\u0006\u0010C\u001a\u00020\u0018H\u0016J\u0008\u0010D\u001a\u00020\u0013H\u0016J\u0018\u0010E\u001a\u00020\u00132\u0006\u0010E\u001a\u00020\u00152\u0006\u0010F\u001a\u00020\u0018H\u0016J@\u0010G\u001a\u00020\u00032\u0006\u0010H\u001a\u00020\u00112\u0006\u0010I\u001a\u00020J2\u0006\u0010K\u001a\u00020J2\u0006\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020\u00152\u0006\u0010O\u001a\u00020\u00152\u0006\u0010P\u001a\u00020\u0015H\u0016JP\u0010Q\u001a\u00020\u00032\u0006\u0010:\u001a\u00020\u00112\u0006\u0010R\u001a\u00020\u00112\u0006\u0010H\u001a\u00020\u00112\u0006\u0010I\u001a\u00020J2\u0006\u0010K\u001a\u00020J2\u0006\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020\u00152\u0006\u0010O\u001a\u00020\u00152\u0006\u0010P\u001a\u00020\u0015H\u0016JW\u0010S\u001a\u00020\u00032\u0008\u0010:\u001a\u0004\u0018\u00010\u00112\u0006\u0010R\u001a\u00020\u00112\u0006\u0010H\u001a\u00020\u00112\u0006\u0010I\u001a\u00020J2\u0006\u0010K\u001a\u00020J2\u0006\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020\u00152\u0006\u0010O\u001a\u00020\u00152\u0006\u0010P\u001a\u00020\u0015H\u0002\u00a2\u0006\u0002\u0010TJ\u0008\u0010U\u001a\u00020\u0013H\u0016J(\u0010V\u001a\u00020\u00132\u0006\u0010W\u001a\u00020\u00152\u0006\u0010H\u001a\u00020\u00112\u0006\u0010X\u001a\u00020M2\u0006\u0010P\u001a\u00020\u0015H\u0016J \u0010Y\u001a\u00020\u000e2\u0006\u0010Z\u001a\u00020\u00152\u0006\u0010[\u001a\u00020\u00032\u0006\u0010\\\u001a\u00020\u0015H\u0016J\u0010\u0010]\u001a\u00020\u000e2\u0006\u0010^\u001a\u00020\u0011H\u0016J\u0010\u0010_\u001a\u00020\u00132\u0006\u0010^\u001a\u00020\u0011H\u0016J\u0010\u0010`\u001a\u00020\u00032\u0006\u0010,\u001a\u00020\u0003H\u0016\u00a8\u0006a"
    }
    d2 = {
        "org/lighttouch/android/EngineService$binder$1",
        "Lorg/lighttouch/android/IEngine$Stub;",
        "rename",
        "",
        "recordId",
        "name",
        "remove",
        "importDevice",
        "source",
        "displayName",
        "rom",
        "guest",
        "sha256",
        "importProgress",
        "Landroid/os/Bundle;",
        "frameStats",
        "sinceSequence",
        "",
        "setPresentScale",
        "",
        "mode",
        "",
        "setPresentVisible",
        "visible",
        "",
        "setDetailedTiming",
        "enabled",
        "hitchSnapshot",
        "frontmostApp",
        "performance",
        "observationEpoch",
        "requireDebugDiagnosis",
        "debugShutdownProgress",
        "debugArmQmp",
        "debugArmVcpuAccounting",
        "debugSelectTcgIrCache",
        "debugEnableTouchTrace",
        "debugSelectGraphicsProvider",
        "choice",
        "debugQmpSnapshot",
        "importBase",
        "importPrepared",
        "adoptPrepared",
        "setGuestPackage",
        "path",
        "records",
        "",
        "()[Landroid/os/Bundle;",
        "select",
        "start",
        "recoverStart",
        "startRecord",
        "coldRecovery",
        "profile",
        "recording",
        "status",
        "claimDisplay",
        "displayInputGeneration",
        "lease",
        "attachDisplay",
        "surface",
        "Landroid/view/Surface;",
        "releaseDisplay",
        "detachDisplay",
        "cancelDisplayInput",
        "backgroundDisplay",
        "pause",
        "paused",
        "stop",
        "button",
        "down",
        "touch",
        "timestampNanos",
        "ids",
        "",
        "phases",
        "coordinates",
        "",
        "width",
        "height",
        "rotation",
        "touchDisplay",
        "inputGeneration",
        "admitTouch",
        "(Ljava/lang/Long;JJ[I[I[FIII)Ljava/lang/String;",
        "cancelInput",
        "motion",
        "kind",
        "xyz",
        "guestRequest",
        "operation",
        "argument",
        "timeoutMs",
        "guestPoll",
        "requestId",
        "guestCancel",
        "screenshot",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lorg/lighttouch/android/EngineService;


# direct methods
.method public static synthetic $r8$lambda$BO_wdKr1rPi8nmNqDStgBfcUDTQ()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/EngineService$binder$1;->debugArmVcpuAccounting$lambda$10()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$EHr-1A2WvAOPNOK8XA-Xh90BIg8(Lorg/lighttouch/android/EngineService;J)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/EngineService$binder$1;->backgroundDisplay$lambda$49(Lorg/lighttouch/android/EngineService;J)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$J1irr7Uqnq3DEBEoXpg6MN_nYK0(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService$binder$1;->backgroundDisplay$lambda$49$lambda$48(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Kt3705FYQAtk2DPYrjYQ4zBMhpU(J)Ljava/lang/String;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService$binder$1;->backgroundDisplay$lambda$49$lambda$47(J)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NxVA5e5Rm8dha-dFc7mP7rR1FME(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService$binder$1;->status$lambda$28(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Sm9s1lGPdelU8IrD0yl8LunklGs(Z)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService$binder$1;->debugSelectTcgIrCache$lambda$11(Z)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$T09nStESIKvxZ7IWm92FvPlExc8(Lorg/lighttouch/android/EngineService;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/EngineService$binder$1;->startRecord$lambda$24(Lorg/lighttouch/android/EngineService;)V

    return-void
.end method

.method public static synthetic $r8$lambda$cj8hxBKumYkXOYI7mxHHMxtXByw(Lorg/lighttouch/android/EngineService;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService$binder$1;->pause$lambda$51(Lorg/lighttouch/android/EngineService;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lBlB1AbhI6BK4WC0HN3GDzdi2AU(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/EngineService$binder$1;JJJ[I[I[FIII)Ljava/lang/String;
    .locals 0

    invoke-static/range {p0 .. p13}, Lorg/lighttouch/android/EngineService$binder$1;->touchDisplay$lambda$53(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/EngineService$binder$1;JJJ[I[I[FIII)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vLzACSzZM4r-gcHaeQUn_SkxFLw(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService$binder$1;->startRecord$lambda$20(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/EngineService;)V
    .locals 0
    .param p1, "$receiver"    # Lorg/lighttouch/android/EngineService;

    iput-object p1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    .line 58
    invoke-direct {p0}, Lorg/lighttouch/android/IEngine$Stub;-><init>()V

    return-void
.end method

.method private final admitTouch(Ljava/lang/Long;JJ[I[I[FIII)Ljava/lang/String;
    .locals 28
    .param p1, "lease"    # Ljava/lang/Long;
    .param p2, "inputGeneration"    # J
    .param p4, "timestampNanos"    # J
    .param p6, "ids"    # [I
    .param p7, "phases"    # [I
    .param p8, "coordinates"    # [F
    .param p9, "width"    # I
    .param p10, "height"    # I
    .param p11, "rotation"    # I

    .line 290
    move-object/from16 v1, p0

    iget-object v0, v1, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getTouchAdmissionGuard$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/Object;

    move-result-object v15

    iget-object v2, v1, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    monitor-enter v15

    const/16 v16, 0x0

    .line 293
    .local v16, "$i$a$-synchronized-EngineService$binder$1$admitTouch$1\\1\\290\\0":I
    if-eqz p1, :cond_0

    :try_start_0
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-virtual {v0, v3, v4}, Lorg/lighttouch/android/Native;->ownsDisplay(J)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "\u663e\u793a\u5f52\u5c5e\u5df2\u91ca\u653e"

    move-wide/from16 v5, p2

    goto/16 :goto_5

    .line 290
    .end local v16    # "$i$a$-synchronized-EngineService$binder$1$admitTouch$1\\1\\290\\0":I
    :catchall_0
    move-exception v0

    move-wide/from16 v5, p2

    goto/16 :goto_6

    .line 294
    .restart local v16    # "$i$a$-synchronized-EngineService$binder$1$admitTouch$1\\1\\290\\0":I
    :cond_0
    if-eqz p1, :cond_2

    const-wide/16 v3, 0x0

    cmp-long v0, p2, v3

    if-lez v0, :cond_1

    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    invoke-virtual {v0, v3, v4}, Lorg/lighttouch/android/Native;->displayInputGeneration(J)J

    move-result-wide v3

    cmp-long v0, v3, p2

    if-eqz v0, :cond_2

    .line 295
    :cond_1
    const-string v0, "\u663e\u793a\u8f93\u5165\u4ee3\u6b21\u5df2\u91ca\u653e"
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-wide/from16 v5, p2

    goto/16 :goto_5

    .line 296
    :cond_2
    const/16 v17, 0x1

    const/16 v18, 0x0

    :try_start_1
    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$getTouchTimestampOrder$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/TouchTimestampOrder;

    move-result-object v0

    move-wide/from16 v3, p4

    invoke-virtual {v0, v3, v4}, Lorg/lighttouch/android/TouchTimestampOrder;->select(J)J

    move-result-wide v7
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-wide/from16 v20, v7

    .line 312
    .local v20, "ordered\\1":J
    if-nez p1, :cond_3

    :try_start_2
    sget-object v19, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    move-object/from16 v22, p6

    move-object/from16 v23, p7

    move-object/from16 v24, p8

    move/from16 v25, p9

    move/from16 v26, p10

    move/from16 v27, p11

    invoke-virtual/range {v19 .. v27}, Lorg/lighttouch/android/Native;->touch(J[I[I[FIII)Ljava/lang/String;

    move-result-object v0

    move-wide/from16 v5, p2

    move-object v1, v2

    goto :goto_0

    .line 313
    :cond_3
    move-object v5, v2

    sget-object v2, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object/from16 v9, p6

    move-object/from16 v10, p7

    move-object/from16 v11, p8

    move/from16 v12, p9

    move/from16 v13, p10

    move/from16 v14, p11

    move-object v1, v5

    move-wide/from16 v7, v20

    move-wide/from16 v5, p2

    .end local v20    # "ordered\\1":J
    .local v7, "ordered\\1":J
    :try_start_3
    invoke-virtual/range {v2 .. v14}, Lorg/lighttouch/android/Native;->touchDisplay(JJJ[I[I[FIII)Ljava/lang/String;

    move-result-object v0

    .line 312
    .end local v7    # "ordered\\1":J
    .restart local v20    # "ordered\\1":J
    :goto_0
    nop

    .line 314
    .local v0, "result\\1":Ljava/lang/String;
    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_4

    goto :goto_1

    :cond_4
    move/from16 v17, v18

    :goto_1
    if-eqz v17, :cond_5

    const-string v2, "\u663e\u793a\u5f52\u5c5e\u5df2\u91ca\u653e"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_5

    sget-object v2, Lorg/lighttouch/android/DisplayInputAdmission;->INSTANCE:Lorg/lighttouch/android/DisplayInputAdmission;

    invoke-virtual {v2, v0}, Lorg/lighttouch/android/DisplayInputAdmission;->isCancellation(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_5

    invoke-static {v1, v0}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 315
    :cond_5
    goto/16 :goto_5

    .line 297
    .end local v0    # "result\\1":Ljava/lang/String;
    .end local v20    # "ordered\\1":J
    :catch_0
    move-exception v0

    move-wide/from16 v5, p2

    move-object v1, v2

    .line 298
    .local v0, "failure\\1":Ljava/lang/IllegalArgumentException;
    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->getMessage()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "; gesture cancelled. Start a new gesture."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 299
    .local v2, "rejected\\1":Ljava/lang/String;
    if-nez p1, :cond_6

    invoke-static {v1, v2}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v1}, Lorg/lighttouch/android/Native;->cancelInput()V

    .line 310
    move-object v0, v2

    goto :goto_5

    .line 303
    :cond_6
    sget-object v3, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    invoke-virtual {v3, v7, v8, v5, v6}, Lorg/lighttouch/android/Native;->cancelDisplayInput(JJ)Ljava/lang/String;

    move-result-object v3

    .line 304
    .local v3, "release\\1":Ljava/lang/String;
    const-string v4, "\u663e\u793a\u5f52\u5c5e\u5df2\u91ca\u653e"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_a

    sget-object v4, Lorg/lighttouch/android/DisplayInputAdmission;->INSTANCE:Lorg/lighttouch/android/DisplayInputAdmission;

    invoke-virtual {v4, v3}, Lorg/lighttouch/android/DisplayInputAdmission;->isCancellation(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_7

    goto :goto_4

    .line 306
    :cond_7
    move-object v4, v3

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_8

    goto :goto_2

    :cond_8
    move/from16 v17, v18

    :goto_2
    if-eqz v17, :cond_9

    move-object v4, v2

    goto :goto_3

    :cond_9
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v7, "; input release failed: "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 307
    .local v4, "failureMessage\\1":Ljava/lang/String;
    :goto_3
    invoke-static {v1, v4}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 308
    move-object v0, v4

    goto :goto_5

    .line 305
    .end local v4    # "failureMessage\\1":Ljava/lang/String;
    :cond_a
    :goto_4
    const-string v1, "\u663e\u793a\u8f93\u5165\u4ee3\u6b21\u5df2\u91ca\u653e"
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    move-object v0, v1

    .line 290
    .end local v0    # "failure\\1":Ljava/lang/IllegalArgumentException;
    .end local v2    # "rejected\\1":Ljava/lang/String;
    .end local v3    # "release\\1":Ljava/lang/String;
    .end local v16    # "$i$a$-synchronized-EngineService$binder$1$admitTouch$1\\1\\290\\0":I
    :goto_5
    monitor-exit v15

    .line 316
    return-object v0

    .line 290
    :catchall_1
    move-exception v0

    :goto_6
    monitor-exit v15

    throw v0
.end method

.method private static final backgroundDisplay$lambda$49(Lorg/lighttouch/android/EngineService;J)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "$lease"    # J

    .line 244
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 248
    :cond_0
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getAudioGuard$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioPacketEpoch;

    move-result-object v0

    new-instance v1, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda1;

    invoke-direct {v1, p1, p2}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda1;-><init>(J)V

    new-instance v2, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/EngineService;)V

    invoke-virtual {v0, v1, v2}, Lorg/lighttouch/android/AudioPacketEpoch;->closeAfterAdmission(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)Ljava/lang/String;

    move-result-object v0

    .line 253
    .local v0, "result":Ljava/lang/String;
    const-string v1, "\u663e\u793a\u5f52\u5c5e\u5df2\u91ca\u653e"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    .line 254
    :cond_1
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-lez v1, :cond_2

    const/4 v1, 0x1

    goto :goto_0

    :cond_2
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_3

    invoke-static {p0, v0}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    .line 255
    :cond_3
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$stopAudioOutput(Lorg/lighttouch/android/EngineService;)V

    .line 256
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final backgroundDisplay$lambda$49$lambda$47(J)Ljava/lang/String;
    .locals 1
    .param p0, "$lease"    # J

    .line 248
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p0, p1}, Lorg/lighttouch/android/Native;->backgroundDisplay(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final backgroundDisplay$lambda$49$lambda$48(Lorg/lighttouch/android/EngineService;)Lkotlin/Unit;
    .locals 5
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 249
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/EngineService;->access$setUserPaused$p(Lorg/lighttouch/android/EngineService;Z)V

    .line 250
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getAudioObservations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioObservations;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/AudioObservations;->getPauses()J

    move-result-wide v1

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Lorg/lighttouch/android/AudioObservations;->setPauses(J)V

    .line 251
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$flushAudioLocked(Lorg/lighttouch/android/EngineService;)V

    .line 252
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final debugArmVcpuAccounting$lambda$10()Ljava/lang/String;
    .locals 1

    .line 112
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->debugArmVcpuAccounting()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final debugSelectTcgIrCache$lambda$11(Z)Ljava/lang/String;
    .locals 1
    .param p0, "$enabled"    # Z

    .line 117
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p0}, Lorg/lighttouch/android/Native;->debugSelectTcgIrCache(Z)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final pause$lambda$51(Lorg/lighttouch/android/EngineService;Z)Lkotlin/Unit;
    .locals 8
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "$paused"    # Z

    .line 260
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 261
    :cond_0
    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService;->access$setUserPaused$p(Lorg/lighttouch/android/EngineService;Z)V

    .line 262
    const/4 v0, 0x0

    if-nez p1, :cond_1

    invoke-static {p0, v0}, Lorg/lighttouch/android/EngineService;->access$setFocusPaused$p(Lorg/lighttouch/android/EngineService;Z)V

    .line 263
    :cond_1
    if-eqz p1, :cond_2

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$pauseAudio(Lorg/lighttouch/android/EngineService;)V

    .line 264
    :cond_2
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v1}, Lorg/lighttouch/android/Native;->cancelInput()V

    .line 265
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v1, p1}, Lorg/lighttouch/android/Native;->pause(Z)Ljava/lang/String;

    move-result-object v1

    .line 266
    .local v1, "result":Ljava/lang/String;
    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_3

    const/4 v0, 0x1

    :cond_3
    if-eqz v0, :cond_4

    invoke-static {p0, v1}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 267
    :cond_4
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getAudioGuard$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioPacketEpoch;

    move-result-object v0

    monitor-enter v0

    .line 679
    const/4 v2, 0x0

    .line 267
    .local v2, "$i$a$-synchronized-EngineService$binder$1$pause$1$1\\1\\267\\0":I
    const-wide/16 v3, 0x1

    if-eqz p1, :cond_5

    :try_start_0
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getAudioObservations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioObservations;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/AudioObservations;->getPauses()J

    move-result-wide v6

    add-long/2addr v6, v3

    invoke-virtual {v5, v6, v7}, Lorg/lighttouch/android/AudioObservations;->setPauses(J)V

    goto :goto_0

    :cond_5
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getAudioObservations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/AudioObservations;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/AudioObservations;->getResumes()J

    move-result-wide v6

    add-long/2addr v6, v3

    invoke-virtual {v5, v6, v7}, Lorg/lighttouch/android/AudioObservations;->setResumes(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v2    # "$i$a$-synchronized-EngineService$binder$1$pause$1$1\\1\\267\\0":I
    :goto_0
    monitor-exit v0

    .line 268
    if-eqz p1, :cond_6

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$stopAudioOutput(Lorg/lighttouch/android/EngineService;)V

    goto :goto_1

    .line 269
    :cond_6
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$startAudioOutput(Lorg/lighttouch/android/EngineService;)V

    .line 270
    :goto_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 267
    :catchall_0
    move-exception v2

    monitor-exit v0

    throw v2
.end method

.method private final requireDebugDiagnosis()V
    .locals 2

    .line 102
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v0}, Lorg/lighttouch/android/EngineService;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    return-void

    .line 679
    :cond_1
    const/4 v0, 0x0

    .line 102
    .local v0, "$i$a$-check-EngineService$binder$1$requireDebugDiagnosis$1\\1\\102\\0":I
    nop

    .end local v0    # "$i$a$-check-EngineService$binder$1$requireDebugDiagnosis$1\\1\\102\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Debug diagnosis is unavailable in this build"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private final startRecord(Ljava/lang/String;Z)Landroid/os/Bundle;
    .locals 23
    .param p1, "recordId"    # Ljava/lang/String;
    .param p2, "coldRecovery"    # Z

    .line 152
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    const-string v3, "error"

    if-eqz v2, :cond_0

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    move-object v4, v2

    .local v4, "$this$startRecord_u24lambda_u2418\\1":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 153
    .local v5, "$i$a$-apply-EngineService$binder$1$startRecord$1\\1\\152\\0":I
    const-string v6, "state"

    const-string v7, "stopping"

    invoke-virtual {v4, v6, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "This worker is disposing; recovery and Start require a fresh worker."

    invoke-virtual {v4, v3, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 154
    nop

    .line 152
    .end local v4    # "$this$startRecord_u24lambda_u2418\\1":Landroid/os/Bundle;
    .end local v5    # "$i$a$-apply-EngineService$binder$1$startRecord$1\\1\\152\\0":I
    return-object v2

    .line 155
    :cond_0
    iget-object v2, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/WorkerStartAdmission;->tryConsume()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/EngineService$binder$1;->status()Landroid/os/Bundle;

    move-result-object v2

    move-object v4, v2

    .local v4, "$this$startRecord_u24lambda_u2419\\2":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 156
    .local v5, "$i$a$-apply-EngineService$binder$1$startRecord$2\\2\\155\\0":I
    const-string v6, "Start and recovery require a fresh unused guest worker. Stop this worker first."

    invoke-virtual {v4, v3, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 157
    nop

    .line 155
    .end local v4    # "$this$startRecord_u24lambda_u2419\\2":Landroid/os/Bundle;
    .end local v5    # "$i$a$-apply-EngineService$binder$1$startRecord$2\\2\\155\\0":I
    return-object v2

    .line 158
    :cond_1
    iget-object v2, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$foreground(Lorg/lighttouch/android/EngineService;)V

    .line 159
    new-instance v2, Ljava/io/File;

    iget-object v3, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v3}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "library"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    .line 161
    .local v2, "libraryRoot":Ljava/lang/String;
    iget-object v3, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getUsbThread$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/ExecutorService;

    move-result-object v4

    iget-object v5, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    new-instance v6, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda4;

    invoke-direct {v6, v5, v1}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    invoke-interface {v4, v6}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const-string v5, ""

    if-nez v4, :cond_2

    move-object v4, v5

    :cond_2
    invoke-static {v3, v4}, Lorg/lighttouch/android/EngineService;->access$setUsbError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 162
    iget-object v3, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    const-string v4, "ui"

    const/4 v6, 0x0

    invoke-virtual {v3, v4, v6}, Lorg/lighttouch/android/EngineService;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    .line 163
    const-string v7, "reduceAppSwitchPauses"

    const/4 v8, 0x1

    invoke-interface {v3, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 162
    nop

    .line 164
    .local v3, "reduceAppSwitchPauses":Z
    if-eqz v3, :cond_3

    const-string v7, "off"

    goto :goto_0

    :cond_3
    const-string v7, "on"

    .line 165
    .local v7, "flushCodeCacheOnApp":Ljava/lang/String;
    :goto_0
    const-string v9, "LT_FLUSH_ON_APP"

    invoke-static {v9, v7, v8}, Landroid/system/Os;->setenv(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 166
    const-string v9, "LT_FLUSH_SETTLE"

    invoke-static {v9, v7, v8}, Landroid/system/Os;->setenv(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 171
    iget-object v9, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v9}, Lorg/lighttouch/android/EngineService;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v9

    iget v9, v9, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v10, 0x2

    and-int/2addr v9, v10

    if-eqz v9, :cond_b

    .line 172
    new-instance v9, Ljava/io/File;

    iget-object v11, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v11}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v11

    const-string v12, "debug-vcpu-accounting"

    invoke-direct {v9, v11, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v9}, Ljava/io/File;->exists()Z

    move-result v9

    if-eqz v9, :cond_4

    sget-object v9, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v9}, Lorg/lighttouch/android/Native;->debugArmVcpuAccounting()Ljava/lang/String;

    .line 173
    :cond_4
    new-instance v9, Ljava/io/File;

    iget-object v11, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v11}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v11

    const-string v12, "debug-env"

    invoke-direct {v9, v11, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v11, v9

    .line 679
    .local v11, "it\\3":Ljava/io/File;
    const/4 v12, 0x0

    .line 173
    .local v12, "$i$a$-takeIf-EngineService$binder$1$startRecord$4\\3\\173\\0":I
    invoke-virtual {v11}, Ljava/io/File;->exists()Z

    move-result v11

    .end local v11    # "it\\3":Ljava/io/File;
    .end local v12    # "$i$a$-takeIf-EngineService$binder$1$startRecord$4\\3\\173\\0":I
    const/4 v12, 0x0

    if-eqz v11, :cond_5

    goto :goto_1

    :cond_5
    move-object v9, v12

    :goto_1
    if-eqz v9, :cond_a

    invoke-static {v9, v12, v8, v12}, Lkotlin/io/FilesKt;->readLines$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v9

    if-eqz v9, :cond_a

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$forEach\\4":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 697
    .local v11, "$i$f$forEach\\4\\173":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_2
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_9

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\4":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/lang/String;

    .local v15, "line\\5":Ljava/lang/String;
    const/16 v16, 0x0

    .line 174
    .local v16, "$i$a$-forEach-EngineService$binder$1$startRecord$5\\5\\697\\0":I
    move-object/from16 v17, v15

    check-cast v17, Ljava/lang/CharSequence;

    new-array v12, v8, [C

    const/16 v18, 0x3d

    aput-char v18, v12, v6

    const/16 v21, 0x2

    const/16 v22, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x2

    move-object/from16 v18, v12

    invoke-static/range {v17 .. v22}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v12

    move-object/from16 v17, v12

    .line 679
    .local v17, "it\\6":Ljava/util/List;
    const/16 v18, 0x0

    .line 174
    .local v18, "$i$a$-takeIf-EngineService$binder$1$startRecord$5$1\\6\\174\\5":I
    invoke-interface/range {v17 .. v17}, Ljava/util/List;->size()I

    move-result v8

    if-ne v8, v10, :cond_6

    const/4 v8, 0x1

    goto :goto_3

    :cond_6
    move v8, v6

    .end local v17    # "it\\6":Ljava/util/List;
    .end local v18    # "$i$a$-takeIf-EngineService$binder$1$startRecord$5$1\\6\\174\\5":I
    :goto_3
    if-eqz v8, :cond_7

    goto :goto_4

    :cond_7
    const/4 v12, 0x0

    :goto_4
    if-nez v12, :cond_8

    move/from16 v21, v3

    goto :goto_5

    :cond_8
    invoke-interface {v12, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    const/4 v10, 0x1

    .local v8, "key\\5":Ljava/lang/String;
    invoke-interface {v12, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .line 175
    .local v12, "value\\5":Ljava/lang/String;
    move-object/from16 v18, v8

    check-cast v18, Ljava/lang/CharSequence;

    invoke-static/range {v18 .. v18}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    move-object/from16 v18, v12

    check-cast v18, Ljava/lang/CharSequence;

    invoke-static/range {v18 .. v18}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v18

    move/from16 v21, v3

    .end local v3    # "reduceAppSwitchPauses":Z
    .local v21, "reduceAppSwitchPauses":Z
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v6, v3, v10}, Landroid/system/Os;->setenv(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 176
    nop

    .line 697
    .end local v8    # "key\\5":Ljava/lang/String;
    .end local v12    # "value\\5":Ljava/lang/String;
    .end local v15    # "line\\5":Ljava/lang/String;
    .end local v16    # "$i$a$-forEach-EngineService$binder$1$startRecord$5\\5\\697\\0":I
    :goto_5
    move/from16 v3, v21

    const/4 v6, 0x0

    const/4 v8, 0x1

    const/4 v10, 0x2

    const/4 v12, 0x0

    .end local v14    # "element\\4":Ljava/lang/Object;
    goto :goto_2

    .line 698
    .end local v21    # "reduceAppSwitchPauses":Z
    .restart local v3    # "reduceAppSwitchPauses":Z
    :cond_9
    move/from16 v21, v3

    .end local v3    # "reduceAppSwitchPauses":Z
    .end local v9    # "$this$forEach\\4":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEach\\4\\173":I
    .restart local v21    # "reduceAppSwitchPauses":Z
    goto :goto_6

    .line 173
    .end local v21    # "reduceAppSwitchPauses":Z
    .restart local v3    # "reduceAppSwitchPauses":Z
    :cond_a
    move/from16 v21, v3

    .end local v3    # "reduceAppSwitchPauses":Z
    .restart local v21    # "reduceAppSwitchPauses":Z
    goto :goto_6

    .line 171
    .end local v21    # "reduceAppSwitchPauses":Z
    .restart local v3    # "reduceAppSwitchPauses":Z
    :cond_b
    move/from16 v21, v3

    .line 179
    .end local v3    # "reduceAppSwitchPauses":Z
    .restart local v21    # "reduceAppSwitchPauses":Z
    :goto_6
    iget-object v3, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    const/4 v6, 0x0

    invoke-virtual {v3, v4, v6}, Lorg/lighttouch/android/EngineService;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    const-string v8, "headphones"

    const/4 v10, 0x1

    invoke-interface {v3, v8, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 180
    .local v3, "headphones":Z
    iget-object v8, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    iget-object v9, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v9, v4, v6}, Lorg/lighttouch/android/EngineService;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v4

    const-string v9, "microphone"

    invoke-interface {v4, v9, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    invoke-static {v8, v4}, Lorg/lighttouch/android/EngineService;->access$setMicrophoneWanted$p(Lorg/lighttouch/android/EngineService;Z)V

    .line 181
    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v4, v5}, Lorg/lighttouch/android/EngineService;->access$setMicrophoneError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 182
    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    sget-object v5, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    if-eqz p2, :cond_c

    invoke-virtual {v5, v2, v1, v3}, Lorg/lighttouch/android/Native;->recoverStart(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v5

    goto :goto_7

    :cond_c
    invoke-virtual {v5, v2, v1, v3}, Lorg/lighttouch/android/Native;->start(Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v5

    :goto_7
    invoke-static {v4, v5}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 183
    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_d

    move v4, v10

    goto :goto_8

    :cond_d
    move v4, v6

    :goto_8
    if-eqz v4, :cond_e

    new-instance v4, Ljava/io/File;

    iget-object v5, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v5}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v5

    const-string v8, "worker-stop-error.txt"

    invoke-direct {v4, v5, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getUserPaused$p(Lorg/lighttouch/android/EngineService;)Z

    move-result v4

    if-nez v4, :cond_e

    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    if-nez v4, :cond_e

    iget-object v4, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$startAudioOutput(Lorg/lighttouch/android/EngineService;)V

    .line 184
    :cond_e
    invoke-virtual {v0}, Lorg/lighttouch/android/EngineService$binder$1;->status()Landroid/os/Bundle;

    move-result-object v4

    .line 185
    .local v4, "response":Landroid/os/Bundle;
    iget-object v5, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v5}, Lorg/lighttouch/android/EngineService;->access$getError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_f

    move v6, v10

    :cond_f
    if-eqz v6, :cond_10

    new-instance v5, Landroid/os/Handler;

    iget-object v6, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v6}, Lorg/lighttouch/android/EngineService;->getMainLooper()Landroid/os/Looper;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iget-object v6, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    new-instance v8, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda5;

    invoke-direct {v8, v6}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/EngineService;)V

    .line 192
    nop

    .line 185
    const-wide/16 v9, 0x3e8

    invoke-virtual {v5, v8, v9, v10}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 193
    :cond_10
    return-object v4
.end method

.method private static final startRecord$lambda$20(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "$recordId"    # Ljava/lang/String;

    .line 161
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getUsb(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/UsbBridge;

    move-result-object v0

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/UsbBridge;->start(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final startRecord$lambda$24(Lorg/lighttouch/android/EngineService;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;

    .line 186
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0}, Lorg/lighttouch/android/EngineService;->access$persistStopError(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 187
    const-string v0, "start-failed"

    invoke-static {p0, v0}, Lorg/lighttouch/android/EngineService;->access$persistObservations(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 188
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getAlive$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 189
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/EngineService;->stopForeground(I)V

    .line 190
    invoke-virtual {p0}, Lorg/lighttouch/android/EngineService;->stopSelf()V

    .line 191
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    .line 192
    return-void
.end method

.method private static final status$lambda$28(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "$retainedError"    # Ljava/lang/String;

    .line 202
    invoke-static {p0, p1}, Lorg/lighttouch/android/EngineService;->access$persistStopError(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    const-string v0, "unexpected-engine-exit"

    invoke-static {p0, v0}, Lorg/lighttouch/android/EngineService;->access$persistObservations(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    return-void
.end method

.method private static final touchDisplay$lambda$53(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/EngineService$binder$1;JJJ[I[I[FIII)Ljava/lang/String;
    .locals 13
    .param p0, "this$0"    # Lorg/lighttouch/android/EngineService;
    .param p1, "this$1"    # Lorg/lighttouch/android/EngineService$binder$1;
    .param p2, "$lease"    # J
    .param p4, "$inputGeneration"    # J
    .param p6, "$timestampNanos"    # J
    .param p8, "$ids"    # [I
    .param p9, "$phases"    # [I
    .param p10, "$coordinates"    # [F
    .param p11, "$width"    # I
    .param p12, "$height"    # I
    .param p13, "$rotation"    # I

    .line 287
    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getUserPaused$p(Lorg/lighttouch/android/EngineService;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getFocusPaused$p(Lorg/lighttouch/android/EngineService;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {p0}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 288
    :cond_0
    invoke-static/range {p2 .. p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    move-object v1, p1

    move-wide/from16 v3, p4

    move-wide/from16 v5, p6

    move-object/from16 v7, p8

    move-object/from16 v8, p9

    move-object/from16 v9, p10

    move/from16 v10, p11

    move/from16 v11, p12

    move/from16 v12, p13

    invoke-direct/range {v1 .. v12}, Lorg/lighttouch/android/EngineService$binder$1;->admitTouch(Ljava/lang/Long;JJ[I[I[FIII)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    .line 287
    :cond_1
    :goto_0
    const-string v0, "\u663e\u793a\u8f93\u5165\u5df2\u6682\u505c"

    .line 288
    :goto_1
    return-object v0
.end method


# virtual methods
.method public adoptPrepared(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "source"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;
    .param p3, "rom"    # Ljava/lang/String;

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "displayName"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "rom"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, p1, v1, p2, p3}, Lorg/lighttouch/android/Native;->adoptPrepared(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public attachDisplay(JLandroid/view/Surface;)Ljava/lang/String;
    .locals 1
    .param p1, "lease"    # J
    .param p3, "surface"    # Landroid/view/Surface;

    const-string v0, "surface"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 237
    nop

    .line 238
    :try_start_0
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2, p3}, Lorg/lighttouch/android/Native;->attachDisplay(JLandroid/view/Surface;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 239
    invoke-virtual {p3}, Landroid/view/Surface;->release()V

    return-object v0

    :catchall_0
    move-exception v0

    invoke-virtual {p3}, Landroid/view/Surface;->release()V

    throw v0
.end method

.method public backgroundDisplay(J)V
    .locals 3
    .param p1, "lease"    # J

    .line 243
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getLifecycleAdmission$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerLifecycleAdmission;

    move-result-object v0

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    new-instance v2, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda6;

    invoke-direct {v2, v1, p1, p2}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/EngineService;J)V

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/WorkerLifecycleAdmission;->run(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 256
    return-void
.end method

.method public button(IZ)V
    .locals 4
    .param p1, "button"    # I
    .param p2, "down"    # Z

    .line 277
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/Native;->button(IZ)Ljava/lang/String;

    move-result-object v0

    .line 278
    .local v0, "result":Ljava/lang/String;
    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lez v1, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    move v1, v3

    :goto_0
    if-eqz v1, :cond_1

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v1, v0}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getButtonRejections$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicLong;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    goto :goto_3

    .line 279
    :cond_1
    if-ltz p1, :cond_2

    const/4 v1, 0x2

    if-ge p1, v1, :cond_2

    goto :goto_1

    :cond_2
    move v2, v3

    :goto_1
    if-eqz v2, :cond_4

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    if-eqz p2, :cond_3

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getButtonDownAdmissions$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicLongArray;

    move-result-object v1

    goto :goto_2

    :cond_3
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getButtonUpAdmissions$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicLongArray;

    move-result-object v1

    :goto_2
    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicLongArray;->incrementAndGet(I)J

    .line 280
    :cond_4
    :goto_3
    return-void
.end method

.method public cancelDisplayInput(J)V
    .locals 3
    .param p1, "lease"    # J

    .line 242
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    const-wide/16 v1, 0x0

    invoke-virtual {v0, p1, p2, v1, v2}, Lorg/lighttouch/android/Native;->cancelDisplayInput(JJ)Ljava/lang/String;

    return-void
.end method

.method public cancelInput()V
    .locals 1

    .line 317
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->cancelInput()V

    return-void
.end method

.method public claimDisplay()J
    .locals 2

    .line 235
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->claimDisplay()J

    move-result-wide v0

    return-wide v0
.end method

.method public debugArmQmp()Ljava/lang/String;
    .locals 1

    .line 108
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->debugArmQmp()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public debugArmVcpuAccounting()Ljava/lang/String;
    .locals 4

    .line 110
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    .line 111
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "This worker is disposing; vCPU accounting requires a fresh worker"

    return-object v0

    .line 112
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v0

    new-instance v1, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda0;

    invoke-direct {v1}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda0;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v3, v1, v2, v3}, Lorg/lighttouch/android/WorkerStartAdmission;->configureUnused$default(Lorg/lighttouch/android/WorkerStartAdmission;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public debugEnableTouchTrace()Ljava/lang/String;
    .locals 1

    .line 120
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    .line 121
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/WorkerStartAdmission;->isConsumed()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "Touch trace selection requires a fresh unused worker"

    return-object v0

    .line 122
    :cond_0
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->debugEnableTouchTrace()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public debugQmpSnapshot()Landroid/os/Bundle;
    .locals 6

    .line 130
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    .line 131
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->debugQmpSnapshot()[Ljava/lang/String;

    move-result-object v0

    .line 132
    .local v0, "result":[Ljava/lang/String;
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    move-object v2, v1

    .line 679
    .local v2, "$this$debugQmpSnapshot_u24lambda_u2412\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 132
    .local v3, "$i$a$-apply-EngineService$binder$1$debugQmpSnapshot$1\\1\\132\\0":I
    const/4 v4, 0x0

    aget-object v4, v0, v4

    const-string v5, "error"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    aget-object v4, v0, v4

    const-string v5, "path"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .end local v2    # "$this$debugQmpSnapshot_u24lambda_u2412\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-EngineService$binder$1$debugQmpSnapshot$1\\1\\132\\0":I
    return-object v1
.end method

.method public debugSelectGraphicsProvider(I)Ljava/lang/String;
    .locals 1
    .param p1, "choice"    # I

    .line 125
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    .line 126
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/WorkerStartAdmission;->isConsumed()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "Graphics provider selection requires a fresh unused worker"

    return-object v0

    .line 127
    :cond_0
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/Native;->debugSelectGraphicsProvider(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public debugSelectTcgIrCache(Z)Ljava/lang/String;
    .locals 3
    .param p1, "enabled"    # Z

    .line 115
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    .line 116
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "This worker is disposing; experimental cache selection requires a fresh worker"

    return-object v0

    .line 117
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v0

    new-instance v1, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda8;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda8;-><init>(Z)V

    const-string v2, "Experimental cache selection"

    invoke-virtual {v0, v2, v1}, Lorg/lighttouch/android/WorkerStartAdmission;->configureUnused(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public debugShutdownProgress()Landroid/os/Bundle;
    .locals 2

    .line 104
    invoke-direct {p0}, Lorg/lighttouch/android/EngineService$binder$1;->requireDebugDiagnosis()V

    .line 106
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getShutdownWatchdog$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ShutdownWatchdog;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/ShutdownWatchdog;->cachedProgress()Lorg/lighttouch/android/ShutdownDebugProgress;

    move-result-object v1

    invoke-static {v0, v1}, Lorg/lighttouch/android/EngineService;->access$shutdownProgressBundle(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/ShutdownDebugProgress;)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public detachDisplay(J)V
    .locals 1
    .param p1, "lease"    # J

    .line 241
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/Native;->detachDisplay(J)V

    return-void
.end method

.method public displayInputGeneration(J)J
    .locals 2
    .param p1, "lease"    # J

    .line 236
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/Native;->displayInputGeneration(J)J

    move-result-wide v0

    return-wide v0
.end method

.method public frameStats(J)Landroid/os/Bundle;
    .locals 7
    .param p1, "sinceSequence"    # J

    .line 66
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    move-object v2, v0

    .local v2, "$this$frameStats_u24lambda_u243\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 67
    .local v3, "$i$a$-apply-EngineService$binder$1$frameStats$1\\1\\66\\0":I
    sget-object v4, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v4, p1, p2}, Lorg/lighttouch/android/Native;->frameTimeline(J)[J

    move-result-object v4

    const-string v5, "frames"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putLongArray(Ljava/lang/String;[J)V

    .line 68
    const-string v4, "nowNs"

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v5

    invoke-virtual {v2, v4, v5, v6}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 69
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getCpuSampler(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerCpuSampler;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/WorkerCpuSampler;->sample()[J

    move-result-object v4

    const-string v5, "cpu"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putLongArray(Ljava/lang/String;[J)V

    .line 70
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getProfileTail$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileTail;

    move-result-object v4

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getDetailedTiming$p(Lorg/lighttouch/android/EngineService;)Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/ProfileCapture;->getAutomatic()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/ProfileCapture;->currentEvents()Ljava/io/File;

    move-result-object v5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    :goto_0
    invoke-virtual {v4, v5}, Lorg/lighttouch/android/ProfileTail;->follow(Ljava/io/File;)V

    .line 71
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getProfileTail$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileTail;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/ProfileTail;->summary()Landroid/os/Bundle;

    move-result-object v4

    if-eqz v4, :cond_1

    .line 679
    .local v4, "it\\2":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 71
    .local v5, "$i$a$-let-EngineService$binder$1$frameStats$1$1\\2\\71\\1":I
    const-string v6, "detailed"

    invoke-virtual {v2, v6, v4}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 72
    .end local v4    # "it\\2":Landroid/os/Bundle;
    .end local v5    # "$i$a$-let-EngineService$binder$1$frameStats$1$1\\2\\71\\1":I
    :cond_1
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getDetailedTiming$p(Lorg/lighttouch/android/EngineService;)Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getDetailedTimingError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_2

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    :goto_1
    if-eqz v4, :cond_3

    const-string v4, "detailedError"

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getDetailedTimingError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v4, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    :cond_3
    nop

    .line 66
    .end local v2    # "$this$frameStats_u24lambda_u243\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-EngineService$binder$1$frameStats$1\\1\\66\\0":I
    nop

    .line 73
    return-object v0
.end method

.method public frontmostApp()Landroid/os/Bundle;
    .locals 7

    .line 97
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    move-object v2, v0

    .local v2, "$this$frontmostApp_u24lambda_u248\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 98
    .local v3, "$i$a$-apply-EngineService$binder$1$frontmostApp$1\\1\\97\\0":I
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/ProfileCapture;->frontmostIdentity()Lkotlin/Pair;

    move-result-object v1

    .line 99
    .local v1, "app\\1":Lkotlin/Pair;
    const-string v4, ""

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-nez v5, :cond_1

    :cond_0
    move-object v5, v4

    :cond_1
    const-string v6, "bundleId"

    invoke-virtual {v2, v6, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-nez v5, :cond_2

    goto :goto_0

    :cond_2
    move-object v4, v5

    :cond_3
    :goto_0
    const-string v5, "appName"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    nop

    .line 97
    .end local v1    # "app\\1":Lkotlin/Pair;
    .end local v2    # "$this$frontmostApp_u24lambda_u248\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-EngineService$binder$1$frontmostApp$1\\1\\97\\0":I
    nop

    .line 100
    return-object v0
.end method

.method public guestCancel(J)V
    .locals 1
    .param p1, "requestId"    # J

    .line 330
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/Native;->guestCancel(J)V

    return-void
.end method

.method public guestPoll(J)Landroid/os/Bundle;
    .locals 6
    .param p1, "requestId"    # J

    .line 327
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/Native;->guestPoll(J)[Ljava/lang/String;

    move-result-object v0

    .line 328
    .local v0, "result":[Ljava/lang/String;
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    move-object v2, v1

    .line 679
    .local v2, "$this$guestPoll_u24lambda_u2457\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 328
    .local v3, "$i$a$-apply-EngineService$binder$1$guestPoll$1\\1\\328\\0":I
    const/4 v4, 0x0

    aget-object v4, v0, v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const-string v5, "state"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x1

    aget-object v4, v0, v4

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    const-string v5, "guestStatus"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x2

    aget-object v4, v0, v4

    const-string v5, "output"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    aget-object v4, v0, v4

    const-string v5, "error"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .end local v2    # "$this$guestPoll_u24lambda_u2457\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-EngineService$binder$1$guestPoll$1\\1\\328\\0":I
    return-object v1
.end method

.method public guestRequest(ILjava/lang/String;I)Landroid/os/Bundle;
    .locals 7
    .param p1, "operation"    # I
    .param p2, "argument"    # Ljava/lang/String;
    .param p3, "timeoutMs"    # I

    const-string v0, "argument"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 323
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2, p3}, Lorg/lighttouch/android/Native;->guestRequest(ILjava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    .line 324
    .local v0, "result":[Ljava/lang/String;
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    move-object v2, v1

    .line 679
    .local v2, "$this$guestRequest_u24lambda_u2456\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 324
    .local v3, "$i$a$-apply-EngineService$binder$1$guestRequest$1\\1\\324\\0":I
    const/4 v4, 0x0

    aget-object v4, v0, v4

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const-string v6, "requestId"

    invoke-virtual {v2, v6, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const/4 v4, 0x1

    aget-object v4, v0, v4

    const-string v5, "error"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .end local v2    # "$this$guestRequest_u24lambda_u2456\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-EngineService$binder$1$guestRequest$1\\1\\324\\0":I
    return-object v1
.end method

.method public hitchSnapshot()Landroid/os/Bundle;
    .locals 21

    .line 83
    move-object/from16 v1, p0

    const-string v0, " "

    iget-object v2, v1, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/ProfileCapture;->getAutomatic()Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, v1, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/ProfileCapture;->currentEvents()Ljava/io/File;

    move-result-object v2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    .line 84
    .local v2, "events":Ljava/io/File;
    :goto_0
    if-eqz v2, :cond_1

    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v4

    if-nez v4, :cond_2

    :cond_1
    new-instance v4, Ljava/io/File;

    iget-object v5, v1, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v5}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "hitches/"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v5, v4

    .line 679
    .local v5, "$this$hitchSnapshot_u24lambda_u244\\1":Ljava/io/File;
    const/4 v6, 0x0

    .line 84
    .local v6, "$i$a$-apply-EngineService$binder$1$hitchSnapshot$directory$1\\1\\84\\0":I
    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    .line 85
    .end local v5    # "$this$hitchSnapshot_u24lambda_u244\\1":Ljava/io/File;
    .end local v6    # "$i$a$-apply-EngineService$binder$1$hitchSnapshot$directory$1\\1\\84\\0":I
    .local v4, "directory":Ljava/io/File;
    :cond_2
    const/4 v5, 0x1

    if-eqz v2, :cond_3

    iget-object v6, v1, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v6}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v6

    const-string v7, "hitch"

    invoke-virtual {v6, v7, v5}, Lorg/lighttouch/android/ProfileCapture;->finish(Ljava/lang/String;Z)V

    .line 86
    :cond_3
    sget-object v6, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    const-wide/16 v7, 0x0

    invoke-virtual {v6, v7, v8}, Lorg/lighttouch/android/Native;->frameTimeline(J)[J

    move-result-object v6

    .line 87
    .local v6, "frames":[J
    new-instance v7, Ljava/io/File;

    const-string v8, "frames.tsv"

    invoke-direct {v7, v4, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    sget-object v8, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v9, Ljava/io/OutputStreamWriter;

    new-instance v10, Ljava/io/FileOutputStream;

    invoke-direct {v10, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v10, Ljava/io/OutputStream;

    invoke-direct {v9, v10, v8}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    check-cast v9, Ljava/io/Writer;

    instance-of v7, v9, Ljava/io/BufferedWriter;

    if-eqz v7, :cond_4

    check-cast v9, Ljava/io/BufferedWriter;

    goto :goto_1

    :cond_4
    new-instance v7, Ljava/io/BufferedWriter;

    const/16 v8, 0x2000

    invoke-direct {v7, v9, v8}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;I)V

    move-object v9, v7

    :goto_1
    check-cast v9, Ljava/io/Closeable;

    :try_start_0
    move-object v7, v9

    check-cast v7, Ljava/io/BufferedWriter;

    .local v7, "out\\2":Ljava/io/BufferedWriter;
    const/4 v8, 0x0

    .line 88
    .local v8, "$i$a$-use-EngineService$binder$1$hitchSnapshot$1\\2\\87\\0":I
    const-string v10, "# sequence published-ns presented-ns presenter-work-ns (CLOCK_MONOTONIC)\n"

    invoke-virtual {v7, v10}, Ljava/io/BufferedWriter;->write(Ljava/lang/String;)V

    .line 89
    array-length v10, v6

    add-int/lit8 v10, v10, -0x1

    const/4 v11, 0x0

    .local v11, "i\\2":I
    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-static {v13, v10, v12}, Lkotlin/internal/ProgressionUtilKt;->getProgressionLastElement(III)I

    move-result v10

    if-gt v11, v10, :cond_5

    :goto_2
    aget-wide v14, v6, v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    add-int/lit8 v12, v11, 0x1

    move-object/from16 v17, v6

    .end local v6    # "frames":[J
    .local v17, "frames":[J
    :try_start_1
    aget-wide v5, v17, v12
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    add-int/lit8 v12, v11, 0x2

    move-object/from16 v18, v4

    .end local v4    # "directory":Ljava/io/File;
    .local v18, "directory":Ljava/io/File;
    :try_start_2
    aget-wide v3, v17, v12

    add-int/lit8 v12, v11, 0x3

    move-wide/from16 v19, v14

    aget-wide v13, v17, v12

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object v15, v2

    move-wide/from16 v1, v19

    .end local v2    # "events":Ljava/io/File;
    .local v15, "events":Ljava/io/File;
    :try_start_3
    invoke-virtual {v12, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/io/BufferedWriter;->write(Ljava/lang/String;)V

    if-eq v11, v10, :cond_6

    add-int/lit8 v11, v11, 0x4

    move-object/from16 v1, p0

    move-object v2, v15

    move-object/from16 v6, v17

    move-object/from16 v4, v18

    const/4 v5, 0x1

    const/4 v13, 0x0

    goto :goto_2

    .line 87
    .end local v7    # "out\\2":Ljava/io/BufferedWriter;
    .end local v8    # "$i$a$-use-EngineService$binder$1$hitchSnapshot$1\\2\\87\\0":I
    .end local v11    # "i\\2":I
    .end local v15    # "events":Ljava/io/File;
    .restart local v2    # "events":Ljava/io/File;
    :catchall_0
    move-exception v0

    move-object v15, v2

    move-object v1, v0

    .end local v2    # "events":Ljava/io/File;
    .restart local v15    # "events":Ljava/io/File;
    goto/16 :goto_6

    .end local v15    # "events":Ljava/io/File;
    .end local v18    # "directory":Ljava/io/File;
    .restart local v2    # "events":Ljava/io/File;
    .restart local v4    # "directory":Ljava/io/File;
    :catchall_1
    move-exception v0

    move-object v15, v2

    move-object/from16 v18, v4

    move-object v1, v0

    .end local v2    # "events":Ljava/io/File;
    .end local v4    # "directory":Ljava/io/File;
    .restart local v15    # "events":Ljava/io/File;
    .restart local v18    # "directory":Ljava/io/File;
    goto :goto_6

    .line 89
    .end local v15    # "events":Ljava/io/File;
    .end local v17    # "frames":[J
    .end local v18    # "directory":Ljava/io/File;
    .restart local v2    # "events":Ljava/io/File;
    .restart local v4    # "directory":Ljava/io/File;
    .restart local v6    # "frames":[J
    .restart local v7    # "out\\2":Ljava/io/BufferedWriter;
    .restart local v8    # "$i$a$-use-EngineService$binder$1$hitchSnapshot$1\\2\\87\\0":I
    .restart local v11    # "i\\2":I
    :cond_5
    move-object v15, v2

    move-object/from16 v18, v4

    move-object/from16 v17, v6

    .line 90
    .end local v2    # "events":Ljava/io/File;
    .end local v4    # "directory":Ljava/io/File;
    .end local v6    # "frames":[J
    .end local v11    # "i\\2":I
    .restart local v15    # "events":Ljava/io/File;
    .restart local v17    # "frames":[J
    .restart local v18    # "directory":Ljava/io/File;
    :cond_6
    nop

    .end local v7    # "out\\2":Ljava/io/BufferedWriter;
    .end local v8    # "$i$a$-use-EngineService$binder$1$hitchSnapshot$1\\2\\87\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 87
    const/4 v0, 0x0

    invoke-static {v9, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 91
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v1, v0

    .local v1, "$this$hitchSnapshot_u24lambda_u247\\3":Landroid/os/Bundle;
    const/4 v2, 0x0

    .line 92
    .local v2, "$i$a$-apply-EngineService$binder$1$hitchSnapshot$2\\3\\91\\0":I
    const-string v3, "directory"

    invoke-virtual/range {v18 .. v18}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v15, :cond_7

    const/4 v3, 0x1

    goto :goto_3

    :cond_7
    const/4 v3, 0x0

    :goto_3
    const-string v4, "detailed"

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 93
    const-string v3, "snapshotNs"

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v4

    invoke-virtual {v1, v3, v4, v5}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    sget-object v3, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v3}, Lorg/lighttouch/android/Native;->status()[Ljava/lang/String;

    move-result-object v3

    array-length v4, v3

    const/4 v5, 0x3

    if-ge v5, v4, :cond_8

    const/16 v16, 0x1

    goto :goto_4

    :cond_8
    const/16 v16, 0x0

    :goto_4
    if-eqz v16, :cond_9

    aget-object v3, v3, v5

    goto :goto_5

    .line 679
    :cond_9
    nop

    .local v5, "it\\4":I
    const/4 v3, 0x0

    .line 93
    .local v3, "$i$a$-getOrElse-EngineService$binder$1$hitchSnapshot$2$1\\4\\93\\3":I
    nop

    .end local v3    # "$i$a$-getOrElse-EngineService$binder$1$hitchSnapshot$2$1\\4\\93\\3":I
    .end local v5    # "it\\4":I
    const-string v3, ""

    :goto_5
    const-string v4, "engineLog"

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 94
    nop

    .line 91
    .end local v1    # "$this$hitchSnapshot_u24lambda_u247\\3":Landroid/os/Bundle;
    .end local v2    # "$i$a$-apply-EngineService$binder$1$hitchSnapshot$2\\3\\91\\0":I
    return-object v0

    .line 87
    :catchall_2
    move-exception v0

    move-object v1, v0

    goto :goto_6

    .end local v15    # "events":Ljava/io/File;
    .end local v17    # "frames":[J
    .end local v18    # "directory":Ljava/io/File;
    .local v2, "events":Ljava/io/File;
    .restart local v4    # "directory":Ljava/io/File;
    .restart local v6    # "frames":[J
    :catchall_3
    move-exception v0

    move-object v15, v2

    move-object/from16 v18, v4

    move-object/from16 v17, v6

    move-object v1, v0

    .end local v2    # "events":Ljava/io/File;
    .end local v4    # "directory":Ljava/io/File;
    .end local v6    # "frames":[J
    .end local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    :goto_6
    :try_start_4
    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    .restart local v15    # "events":Ljava/io/File;
    .restart local v17    # "frames":[J
    .restart local v18    # "directory":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    :catchall_4
    move-exception v0

    invoke-static {v9, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public importBase(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 10
    .param p1, "source"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "displayName"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v0, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const-string v0, "getAbsolutePath(...)"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    new-instance v2, Ljava/io/File;

    iget-object v4, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v4}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const-string v5, "bootrom.bin"

    invoke-direct {v2, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Ljava/io/File;

    iget-object v4, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v4}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const-string v6, "guest.itpack"

    invoke-direct {v2, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 134
    const/16 v8, 0x20

    const/4 v9, 0x0

    const/4 v7, 0x0

    move-object v2, p1

    move-object v4, p2

    .end local p1    # "source":Ljava/lang/String;
    .end local p2    # "displayName":Ljava/lang/String;
    .local v2, "source":Ljava/lang/String;
    .local v4, "displayName":Ljava/lang/String;
    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/Native;->importBase$default(Lorg/lighttouch/android/Native;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    .line 135
    return-object p1
.end method

.method public importDevice(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 8
    .param p1, "source"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;
    .param p3, "rom"    # Ljava/lang/String;
    .param p4, "guest"    # Ljava/lang/String;
    .param p5, "sha256"    # Ljava/lang/String;

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "displayName"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "rom"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "guest"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sha256"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v0, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const-string v0, "getAbsolutePath(...)"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    move-object v7, p5

    .end local p1    # "source":Ljava/lang/String;
    .end local p2    # "displayName":Ljava/lang/String;
    .end local p3    # "rom":Ljava/lang/String;
    .end local p4    # "guest":Ljava/lang/String;
    .end local p5    # "sha256":Ljava/lang/String;
    .local v2, "source":Ljava/lang/String;
    .local v4, "displayName":Ljava/lang/String;
    .local v5, "rom":Ljava/lang/String;
    .local v6, "guest":Ljava/lang/String;
    .local v7, "sha256":Ljava/lang/String;
    invoke-virtual/range {v1 .. v7}, Lorg/lighttouch/android/Native;->importBase(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public importPrepared(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 10
    .param p1, "source"    # Ljava/lang/String;
    .param p2, "displayName"    # Ljava/lang/String;
    .param p3, "rom"    # Ljava/lang/String;

    const-string v0, "source"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "displayName"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "rom"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 136
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v0, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const-string v0, "getAbsolutePath(...)"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v8, 0x20

    const/4 v9, 0x0

    const-string v6, ""

    const/4 v7, 0x0

    move-object v2, p1

    move-object v4, p2

    move-object v5, p3

    .end local p1    # "source":Ljava/lang/String;
    .end local p2    # "displayName":Ljava/lang/String;
    .end local p3    # "rom":Ljava/lang/String;
    .local v2, "source":Ljava/lang/String;
    .local v4, "displayName":Ljava/lang/String;
    .local v5, "rom":Ljava/lang/String;
    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/Native;->importBase$default(Lorg/lighttouch/android/Native;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public importProgress()Landroid/os/Bundle;
    .locals 10

    .line 63
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->importProgress()[Ljava/lang/String;

    move-result-object v0

    .local v0, "p\\1":[Ljava/lang/String;
    const/4 v1, 0x0

    .line 64
    .local v1, "$i$a$-let-EngineService$binder$1$importProgress$1\\1\\63\\0":I
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    move-object v3, v2

    .line 679
    .local v3, "$this$importProgress_u24lambda_u241_u24lambda_u240\\2":Landroid/os/Bundle;
    const/4 v4, 0x0

    .line 64
    .local v4, "$i$a$-apply-EngineService$binder$1$importProgress$1$1\\2\\64\\1":I
    const/4 v5, 0x0

    aget-object v5, v0, v5

    const-string v6, "phase"

    invoke-virtual {v3, v6, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    aget-object v5, v0, v5

    invoke-static {v5}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    const-wide/16 v6, 0x0

    if-eqz v5, :cond_0

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    goto :goto_0

    :cond_0
    move-wide v8, v6

    :goto_0
    const-string v5, "done"

    invoke-virtual {v3, v5, v8, v9}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const/4 v5, 0x2

    aget-object v5, v0, v5

    invoke-static {v5}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    if-eqz v5, :cond_1

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    :cond_1
    const-string v5, "total"

    invoke-virtual {v3, v5, v6, v7}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 63
    .end local v0    # "p\\1":[Ljava/lang/String;
    .end local v1    # "$i$a$-let-EngineService$binder$1$importProgress$1\\1\\63\\0":I
    .end local v3    # "$this$importProgress_u24lambda_u241_u24lambda_u240\\2":Landroid/os/Bundle;
    .end local v4    # "$i$a$-apply-EngineService$binder$1$importProgress$1$1\\2\\64\\1":I
    nop

    .line 65
    return-object v2
.end method

.method public motion(IJ[FI)V
    .locals 7
    .param p1, "kind"    # I
    .param p2, "timestampNanos"    # J
    .param p4, "xyz"    # [F
    .param p5, "rotation"    # I

    const-string v0, "xyz"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 319
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    move v2, p1

    move-wide v3, p2

    move-object v5, p4

    move v6, p5

    .end local p1    # "kind":I
    .end local p2    # "timestampNanos":J
    .end local p4    # "xyz":[F
    .end local p5    # "rotation":I
    .local v2, "kind":I
    .local v3, "timestampNanos":J
    .local v5, "xyz":[F
    .local v6, "rotation":I
    invoke-virtual/range {v1 .. v6}, Lorg/lighttouch/android/Native;->motion(IJ[FI)Ljava/lang/String;

    move-result-object p1

    .line 320
    .local p1, "result":Ljava/lang/String;
    move-object p2, p1

    check-cast p2, Ljava/lang/CharSequence;

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result p2

    if-lez p2, :cond_0

    const/4 p2, 0x1

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    if-eqz p2, :cond_1

    iget-object p2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {p2, p1}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 321
    :cond_1
    return-void
.end method

.method public pause(Z)V
    .locals 3
    .param p1, "paused"    # Z

    .line 257
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getLifecycleAdmission$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerLifecycleAdmission;

    move-result-object v0

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    new-instance v2, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda9;

    invoke-direct {v2, v1, p1}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda9;-><init>(Lorg/lighttouch/android/EngineService;Z)V

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/WorkerLifecycleAdmission;->run(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    .line 270
    return-void
.end method

.method public performance(J)Landroid/os/Bundle;
    .locals 2
    .param p1, "observationEpoch"    # J

    .line 101
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getPerformanceSampler(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerPerformanceSampler;

    move-result-object v0

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v1

    invoke-virtual {v0, v1, p1, p2}, Lorg/lighttouch/android/WorkerPerformanceSampler;->request(IJ)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public profile(Z)Landroid/os/Bundle;
    .locals 7
    .param p1, "recording"    # Z

    .line 196
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v1

    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->status()[Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/ArraysKt;->firstOrNull([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, "stopped"

    :cond_0
    move-object v3, v0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x0

    move v2, p1

    .end local p1    # "recording":Z
    .local v2, "recording":Z
    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/ProfileCapture;->change$default(Lorg/lighttouch/android/ProfileCapture;ZLjava/lang/String;ZILjava/lang/Object;)Landroid/os/Bundle;

    move-result-object p1

    return-object p1
.end method

.method public records()[Landroid/os/Bundle;
    .locals 24

    .line 139
    move-object/from16 v0, p0

    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v2, Ljava/io/File;

    iget-object v3, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v3}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "library"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const-string v3, "getAbsolutePath(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/Native;->records(Ljava/lang/String;)[[Ljava/lang/String;

    move-result-object v1

    check-cast v1, [Ljava/lang/Object;

    .local v1, "$this$mapNotNull\\1":[Ljava/lang/Object;
    iget-object v2, v0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    const/4 v3, 0x0

    .line 680
    .local v3, "$i$f$mapNotNull\\1\\139":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$mapNotNullTo\\2":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 688
    .local v6, "$i$f$mapNotNullTo\\2\\680":I
    move-object v7, v5

    .local v7, "$this$forEach\\3":[Ljava/lang/Object;
    const/4 v8, 0x0

    .line 689
    .local v8, "$i$f$forEach\\3\\688":I
    array-length v9, v7

    const/4 v10, 0x0

    move v11, v10

    :goto_0
    if-ge v11, v9, :cond_9

    aget-object v12, v7, v11

    .local v12, "element\\3":Ljava/lang/Object;
    move-object v13, v12

    .local v13, "element\\4":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 688
    .local v14, "$i$a$-forEach-ArraysKt___ArraysKt$mapNotNullTo$1\\4\\689\\2":I
    move-object v15, v13

    check-cast v15, [Ljava/lang/String;

    .local v15, "row\\6":[Ljava/lang/String;
    const/16 v16, 0x0

    .line 140
    .local v16, "$i$a$-mapNotNull-EngineService$binder$1$records$1\\6\\688\\0":I
    aget-object v17, v15, v10

    check-cast v17, Ljava/lang/CharSequence;

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->length()I

    move-result v17

    move/from16 v18, v10

    const/4 v10, 0x1

    if-nez v17, :cond_0

    move/from16 v17, v10

    goto :goto_1

    :cond_0
    move/from16 v17, v18

    :goto_1
    if-eqz v17, :cond_3

    array-length v0, v15

    if-ge v10, v0, :cond_1

    move v0, v10

    goto :goto_2

    :cond_1
    move/from16 v0, v18

    :goto_2
    if-eqz v0, :cond_2

    aget-object v0, v15, v10

    goto :goto_3

    .line 679
    :cond_2
    nop

    .local v10, "it\\7":I
    const/4 v0, 0x0

    .line 140
    .local v0, "$i$a$-getOrElse-EngineService$binder$1$records$1$1\\7\\140\\6":I
    nop

    .end local v0    # "$i$a$-getOrElse-EngineService$binder$1$records$1$1\\7\\140\\6":I
    .end local v10    # "it\\7":I
    const-string v0, "Device library unavailable"

    :goto_3
    invoke-static {v2, v0}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    const/4 v0, 0x0

    move-object/from16 v22, v1

    move-object/from16 v17, v2

    goto/16 :goto_8

    .line 141
    :cond_3
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object/from16 v17, v0

    .local v17, "$this$records_u24lambda_u2417_u24lambda_u2416\\8":Landroid/os/Bundle;
    const/16 v19, 0x0

    .line 142
    .local v19, "$i$a$-apply-EngineService$binder$1$records$1$2\\8\\141\\6":I
    move/from16 v20, v10

    const-string v10, "id"

    move-object/from16 v21, v0

    aget-object v0, v15, v18

    move-object/from16 v22, v1

    move-object/from16 v1, v17

    .end local v17    # "$this$records_u24lambda_u2417_u24lambda_u2416\\8":Landroid/os/Bundle;
    .local v1, "$this$records_u24lambda_u2417_u24lambda_u2416\\8":Landroid/os/Bundle;
    .local v22, "$this$mapNotNull\\1":[Ljava/lang/Object;
    invoke-virtual {v1, v10, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "name"

    aget-object v10, v15, v20

    invoke-virtual {v1, v0, v10}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x2

    aget-object v0, v15, v0

    const-string v10, "board"

    invoke-virtual {v1, v10, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x3

    aget-object v0, v15, v0

    const-string v10, "build"

    invoke-virtual {v1, v10, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    const/4 v0, 0x4

    aget-object v0, v15, v0

    const-string v10, "1"

    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    move-object/from16 v17, v2

    const-string v2, "selected"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v0, 0x5

    aget-object v0, v15, v0

    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "dirty"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 144
    array-length v0, v15

    const/16 v2, 0x9

    if-ge v2, v0, :cond_4

    move/from16 v0, v20

    goto :goto_4

    :cond_4
    move/from16 v0, v18

    :goto_4
    const-string v23, "0"

    if-eqz v0, :cond_5

    aget-object v0, v15, v2

    goto :goto_5

    .line 679
    :cond_5
    nop

    .local v2, "it\\9":I
    const/4 v0, 0x0

    .line 144
    .local v0, "$i$a$-getOrElse-EngineService$binder$1$records$1$2$1\\9\\144\\8":I
    move-object/from16 v0, v23

    .end local v0    # "$i$a$-getOrElse-EngineService$binder$1$records$1$2$1\\9\\144\\8":I
    .end local v2    # "it\\9":I
    :goto_5
    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "bootromAvailable"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    array-length v0, v15

    const/16 v2, 0xa

    if-ge v2, v0, :cond_6

    goto :goto_6

    :cond_6
    move/from16 v20, v18

    :goto_6
    if-eqz v20, :cond_7

    aget-object v23, v15, v2

    move-object/from16 v0, v23

    goto :goto_7

    .line 679
    :cond_7
    nop

    .local v2, "it\\10":I
    const/4 v0, 0x0

    .line 144
    .local v0, "$i$a$-getOrElse-EngineService$binder$1$records$1$2$2\\10\\144\\8":I
    move-object/from16 v0, v23

    .end local v0    # "$i$a$-getOrElse-EngineService$binder$1$records$1$2$2\\10\\144\\8":I
    .end local v2    # "it\\10":I
    :goto_7
    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "guestPackageAvailable"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 145
    const/4 v0, 0x6

    aget-object v0, v15, v0

    const-string v2, "contacts"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x7

    aget-object v0, v15, v0

    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "gyro"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x8

    aget-object v0, v15, v0

    invoke-static {v0, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "acceleration"

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 146
    nop

    .line 141
    .end local v1    # "$this$records_u24lambda_u2417_u24lambda_u2416\\8":Landroid/os/Bundle;
    .end local v19    # "$i$a$-apply-EngineService$binder$1$records$1$2\\8\\141\\6":I
    move-object/from16 v0, v21

    .line 146
    :goto_8
    nop

    .line 688
    .end local v15    # "row\\6":[Ljava/lang/String;
    .end local v16    # "$i$a$-mapNotNull-EngineService$binder$1$records$1\\6\\688\\0":I
    if-eqz v0, :cond_8

    .line 690
    .local v0, "it\\4":Ljava/lang/Object;
    const/4 v1, 0x0

    .line 688
    .local v1, "$i$a$-let-ArraysKt___ArraysKt$mapNotNullTo$1$1\\5\\690\\4":I
    invoke-interface {v4, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 689
    .end local v0    # "it\\4":Ljava/lang/Object;
    .end local v1    # "$i$a$-let-ArraysKt___ArraysKt$mapNotNullTo$1$1\\5\\690\\4":I
    .end local v13    # "element\\4":Ljava/lang/Object;
    .end local v14    # "$i$a$-forEach-ArraysKt___ArraysKt$mapNotNullTo$1\\4\\689\\2":I
    :cond_8
    nop

    .end local v12    # "element\\3":Ljava/lang/Object;
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v0, p0

    move-object/from16 v2, v17

    move/from16 v10, v18

    move-object/from16 v1, v22

    goto/16 :goto_0

    .line 691
    .end local v22    # "$this$mapNotNull\\1":[Ljava/lang/Object;
    .local v1, "$this$mapNotNull\\1":[Ljava/lang/Object;
    :cond_9
    move-object/from16 v22, v1

    move/from16 v18, v10

    .line 692
    .end local v1    # "$this$mapNotNull\\1":[Ljava/lang/Object;
    .end local v7    # "$this$forEach\\3":[Ljava/lang/Object;
    .end local v8    # "$i$f$forEach\\3\\688":I
    .restart local v22    # "$this$mapNotNull\\1":[Ljava/lang/Object;
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapNotNullTo\\2":[Ljava/lang/Object;
    .end local v6    # "$i$f$mapNotNullTo\\2\\680":I
    move-object v0, v4

    check-cast v0, Ljava/util/List;

    .line 680
    nop

    .end local v3    # "$i$f$mapNotNull\\1\\139":I
    .end local v22    # "$this$mapNotNull\\1":[Ljava/lang/Object;
    check-cast v0, Ljava/util/Collection;

    .line 147
    nop

    .local v0, "$this$toTypedArray\\11":Ljava/util/Collection;
    const/4 v1, 0x0

    .line 693
    .local v1, "$i$f$toTypedArray\\11\\147":I
    nop

    .line 694
    move-object v2, v0

    .line 696
    .local v2, "this_\\11":Ljava/util/Collection;
    move/from16 v3, v18

    new-array v3, v3, [Landroid/os/Bundle;

    invoke-interface {v2, v3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$toTypedArray\\11":Ljava/util/Collection;
    .end local v1    # "$i$f$toTypedArray\\11\\147":I
    .end local v2    # "this_\\11":Ljava/util/Collection;
    check-cast v0, [Landroid/os/Bundle;

    .line 147
    return-object v0
.end method

.method public recoverStart(Ljava/lang/String;)Landroid/os/Bundle;
    .locals 1
    .param p1, "recordId"    # Ljava/lang/String;

    const-string v0, "recordId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 150
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, Lorg/lighttouch/android/EngineService$binder$1;->startRecord(Ljava/lang/String;Z)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public releaseDisplay(J)V
    .locals 1
    .param p1, "lease"    # J

    .line 240
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/Native;->releaseDisplay(J)V

    return-void
.end method

.method public remove(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "recordId"    # Ljava/lang/String;

    const-string v0, "recordId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, p1}, Lorg/lighttouch/android/Native;->remove(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public rename(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "recordId"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "recordId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, p1, p2}, Lorg/lighttouch/android/Native;->rename(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public screenshot(Ljava/lang/String;)Ljava/lang/String;
    .locals 9
    .param p1, "path"    # Ljava/lang/String;

    const-string v0, "path"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 331
    nop

    .line 332
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v0

    .line 333
    .local v0, "target":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getPath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v3}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "screenshots"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1, v2, v3, v4, v5}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 334
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 335
    :cond_0
    sget-object v1, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v1}, Lorg/lighttouch/android/Native;->capture()Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_1

    .local v1, "bitmap":Landroid/graphics/Bitmap;
    new-instance v2, Ljava/io/FileOutputStream;

    .line 336
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v2, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    move-object v3, v2

    check-cast v3, Ljava/io/FileOutputStream;

    .line 679
    .local v3, "it\\2":Ljava/io/FileOutputStream;
    const/4 v4, 0x0

    .line 336
    .local v4, "$i$a$-use-EngineService$binder$1$screenshot$1\\2\\336\\0":I
    sget-object v6, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    move-object v7, v3

    check-cast v7, Ljava/io/OutputStream;

    const/16 v8, 0x64

    invoke-virtual {v1, v6, v8, v7}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v3    # "it\\2":Ljava/io/FileOutputStream;
    .end local v4    # "$i$a$-use-EngineService$binder$1$screenshot$1\\2\\336\\0":I
    :try_start_2
    invoke-static {v2, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 337
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    .line 338
    const-string v2, ""
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "bitmap":Landroid/graphics/Bitmap;
    goto :goto_0

    .line 336
    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "bitmap":Landroid/graphics/Bitmap;
    :catchall_0
    move-exception v3

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "bitmap":Landroid/graphics/Bitmap;
    .end local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .end local p1    # "path":Ljava/lang/String;
    :try_start_3
    throw v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "bitmap":Landroid/graphics/Bitmap;
    .restart local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .restart local p1    # "path":Ljava/lang/String;
    :catchall_1
    move-exception v4

    :try_start_4
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .end local p1    # "path":Ljava/lang/String;
    throw v4

    .line 335
    .end local v1    # "bitmap":Landroid/graphics/Bitmap;
    .restart local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .restart local p1    # "path":Ljava/lang/String;
    :cond_1
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "No guest frame available"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .end local p1    # "path":Ljava/lang/String;
    throw v1

    .line 333
    .restart local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .restart local p1    # "path":Ljava/lang/String;
    :cond_2
    const-string v1, "\u65ad\u8a00\u5931\u8d25\u3002"

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .end local p1    # "path":Ljava/lang/String;
    throw v2
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 339
    .end local v0    # "target":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/EngineService$binder$1;
    .restart local p1    # "path":Ljava/lang/String;
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_3

    const-string v1, "\u622a\u5c4f\u5931\u8d25"

    :cond_3
    move-object v2, v1

    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-object v2
.end method

.method public select(Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "recordId"    # Ljava/lang/String;

    const-string v0, "recordId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, p1}, Lorg/lighttouch/android/Native;->select(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public setDetailedTiming(Z)V
    .locals 5
    .param p1, "enabled"    # Z

    .line 77
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0, p1}, Lorg/lighttouch/android/EngineService;->access$setDetailedTiming$p(Lorg/lighttouch/android/EngineService;Z)V

    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    const-string v1, ""

    invoke-static {v0, v1}, Lorg/lighttouch/android/EngineService;->access$setDetailedTimingError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 78
    if-nez p1, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/ProfileCapture;->getAutomatic()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v3, "detailed-timing-off"

    const/4 v4, 0x0

    invoke-static {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/ProfileCapture;->finish$default(Lorg/lighttouch/android/ProfileCapture;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 79
    :cond_0
    return-void
.end method

.method public setGuestPackage(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4
    .param p1, "recordId"    # Ljava/lang/String;
    .param p2, "path"    # Ljava/lang/String;

    const-string v0, "recordId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "path"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 138
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-virtual {v2}, Lorg/lighttouch/android/EngineService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "library"

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, p1, p2}, Lorg/lighttouch/android/Native;->setGuestPackage(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public setPresentScale(I)V
    .locals 1
    .param p1, "mode"    # I

    .line 74
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/Native;->setPresentScale(I)V

    return-void
.end method

.method public setPresentVisible(Z)V
    .locals 1
    .param p1, "visible"    # Z

    .line 75
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/Native;->setPresentVisible(Z)V

    return-void
.end method

.method public start(Ljava/lang/String;)Landroid/os/Bundle;
    .locals 1
    .param p1, "recordId"    # Ljava/lang/String;

    const-string v0, "recordId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 149
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lorg/lighttouch/android/EngineService$binder$1;->startRecord(Ljava/lang/String;Z)Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public status()Landroid/os/Bundle;
    .locals 15

    .line 198
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->status()[Ljava/lang/String;

    move-result-object v0

    .line 199
    .local v0, "s":[Ljava/lang/String;
    const/4 v1, 0x2

    invoke-static {v0, v1}, Lkotlin/collections/ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    move-object v4, v1

    .line 679
    .local v4, "it\\1":Ljava/lang/String;
    const/4 v5, 0x0

    .line 199
    .local v5, "$i$a$-takeIf-EngineService$binder$1$status$1\\1\\199\\0":I
    move-object v6, v4

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-lez v6, :cond_0

    move v6, v2

    goto :goto_0

    :cond_0
    move v6, v3

    .end local v4    # "it\\1":Ljava/lang/String;
    .end local v5    # "$i$a$-takeIf-EngineService$binder$1$status$1\\1\\199\\0":I
    :goto_0
    if-eqz v6, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_1
    if-eqz v1, :cond_2

    iget-object v4, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    .line 679
    .local v1, "it\\2":Ljava/lang/String;
    const/4 v5, 0x0

    .line 199
    .local v5, "$i$a$-let-EngineService$binder$1$status$2\\2\\199\\0":I
    invoke-static {v4, v1}, Lorg/lighttouch/android/EngineService;->access$setError$p(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    .line 200
    .end local v1    # "it\\2":Ljava/lang/String;
    .end local v5    # "$i$a$-let-EngineService$binder$1$status$2\\2\\199\\0":I
    :cond_2
    invoke-static {v0}, Lkotlin/collections/ArraysKt;->firstOrNull([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const-string v4, "failed"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/WorkerStartAdmission;->isConsumed()Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getFailureRecorded$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v1

    invoke-virtual {v1, v3, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 201
    iget-object v1, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_3

    move v4, v2

    goto :goto_2

    :cond_3
    move v4, v3

    :goto_2
    if-eqz v4, :cond_4

    .line 679
    const/4 v1, 0x0

    .line 201
    .local v1, "$i$a$-ifEmpty-EngineService$binder$1$status$retainedError$1\\3\\201\\0":I
    nop

    .end local v1    # "$i$a$-ifEmpty-EngineService$binder$1$status$retainedError$1\\3\\201\\0":I
    const-string v1, "Guest worker failed; writable state and diagnostics retained. Start a fresh worker."

    :cond_4
    check-cast v1, Ljava/lang/String;

    .line 202
    .local v1, "retainedError":Ljava/lang/String;
    new-instance v4, Ljava/lang/Thread;

    iget-object v5, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    new-instance v6, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda3;

    invoke-direct {v6, v5, v1}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/EngineService;Ljava/lang/String;)V

    const-string v5, "guest-failure-record"

    invoke-direct {v4, v6, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    .line 204
    .end local v1    # "retainedError":Ljava/lang/String;
    :cond_5
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    iget-object v4, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    move-object v5, v1

    .local v5, "$this$status_u24lambda_u2446\\4":Landroid/os/Bundle;
    const/4 v6, 0x0

    .line 205
    .local v6, "$i$a$-apply-EngineService$binder$1$status$4\\4\\204\\0":I
    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v7

    array-length v8, v0

    if-lez v8, :cond_6

    move v8, v2

    goto :goto_3

    :cond_6
    move v8, v3

    :goto_3
    const-string v9, "stopped"

    if-eqz v8, :cond_7

    aget-object v8, v0, v3

    goto :goto_4

    .line 679
    :cond_7
    move v8, v3

    .local v8, "it\\5":I
    const/4 v10, 0x0

    .line 205
    .local v10, "$i$a$-getOrElse-EngineService$binder$1$status$4$1\\5\\205\\4":I
    move-object v8, v9

    .end local v8    # "it\\5":I
    .end local v10    # "$i$a$-getOrElse-EngineService$binder$1$status$4$1\\5\\205\\4":I
    :goto_4
    invoke-virtual {v7, v8}, Lorg/lighttouch/android/ProfileCapture;->snapshot(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 206
    array-length v7, v0

    if-lez v7, :cond_8

    move v7, v2

    goto :goto_5

    :cond_8
    move v7, v3

    :goto_5
    if-eqz v7, :cond_9

    aget-object v9, v0, v3

    goto :goto_6

    .line 679
    :cond_9
    move v7, v3

    .local v7, "it\\6":I
    const/4 v8, 0x0

    .line 206
    .local v8, "$i$a$-getOrElse-EngineService$binder$1$status$4$2\\6\\206\\4":I
    nop

    .end local v7    # "it\\6":I
    .end local v8    # "$i$a$-getOrElse-EngineService$binder$1$status$4$2\\6\\206\\4":I
    :goto_6
    const-string v7, "state"

    invoke-virtual {v5, v7, v9}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 207
    array-length v7, v0

    if-ge v2, v7, :cond_a

    move v7, v2

    goto :goto_7

    :cond_a
    move v7, v3

    :goto_7
    const-string v8, ""

    if-eqz v7, :cond_b

    aget-object v7, v0, v2

    goto :goto_8

    .line 679
    :cond_b
    move v7, v2

    .local v7, "it\\7":I
    const/4 v9, 0x0

    .line 207
    .local v9, "$i$a$-getOrElse-EngineService$binder$1$status$4$3\\7\\207\\4":I
    move-object v7, v8

    .end local v7    # "it\\7":I
    .end local v9    # "$i$a$-getOrElse-EngineService$binder$1$status$4$3\\7\\207\\4":I
    :goto_8
    const-string v9, "detail"

    invoke-virtual {v5, v9, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 208
    array-length v7, v0

    const/4 v9, 0x3

    if-ge v9, v7, :cond_c

    move v7, v2

    goto :goto_9

    :cond_c
    move v7, v3

    :goto_9
    if-eqz v7, :cond_d

    aget-object v7, v0, v9

    goto :goto_a

    .line 679
    :cond_d
    nop

    .local v9, "it\\8":I
    const/4 v7, 0x0

    .line 208
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$4\\8\\208\\4":I
    move-object v7, v8

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$4\\8\\208\\4":I
    .end local v9    # "it\\8":I
    :goto_a
    const-string v9, "engineLog"

    invoke-virtual {v5, v9, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 209
    array-length v7, v0

    const/4 v9, 0x4

    if-ge v9, v7, :cond_e

    move v7, v2

    goto :goto_b

    :cond_e
    move v7, v3

    :goto_b
    if-eqz v7, :cond_f

    aget-object v7, v0, v9

    goto :goto_c

    .line 679
    :cond_f
    nop

    .local v9, "it\\9":I
    const/4 v7, 0x0

    .line 209
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$5\\9\\209\\4":I
    move-object v7, v8

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$5\\9\\209\\4":I
    .end local v9    # "it\\9":I
    :goto_c
    const-string v9, "debugQmpPath"

    invoke-virtual {v5, v9, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 210
    array-length v7, v0

    const/4 v9, 0x5

    if-ge v9, v7, :cond_10

    move v7, v2

    goto :goto_d

    :cond_10
    move v7, v3

    :goto_d
    if-eqz v7, :cond_11

    aget-object v7, v0, v9

    goto :goto_e

    .line 679
    :cond_11
    nop

    .local v9, "it\\10":I
    const/4 v7, 0x0

    .line 210
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$6\\10\\210\\4":I
    nop

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$6\\10\\210\\4":I
    .end local v9    # "it\\10":I
    const-string v7, "platform"

    :goto_e
    const-string v9, "graphicsProviderChoice"

    invoke-virtual {v5, v9, v7}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 211
    array-length v7, v0

    const/4 v9, 0x6

    if-ge v9, v7, :cond_12

    move v7, v2

    goto :goto_f

    :cond_12
    move v7, v3

    :goto_f
    const-string v10, "0"

    if-eqz v7, :cond_13

    aget-object v7, v0, v9

    goto :goto_10

    .line 679
    :cond_13
    nop

    .local v9, "it\\11":I
    const/4 v7, 0x0

    .line 211
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$7\\11\\211\\4":I
    move-object v7, v10

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$7\\11\\211\\4":I
    .end local v9    # "it\\11":I
    :goto_10
    const-string v9, "1"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const-string v11, "graphicsProviderFixed"

    invoke-virtual {v5, v11, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 212
    array-length v7, v0

    const/4 v11, 0x7

    if-ge v11, v7, :cond_14

    move v7, v2

    goto :goto_11

    :cond_14
    move v7, v3

    :goto_11
    if-eqz v7, :cond_15

    aget-object v7, v0, v11

    goto :goto_12

    .line 679
    :cond_15
    nop

    .local v11, "it\\12":I
    const/4 v7, 0x0

    .line 212
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$8\\12\\212\\4":I
    move-object v7, v10

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$8\\12\\212\\4":I
    .end local v11    # "it\\12":I
    :goto_12
    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const-string v11, "touchTraceConfigured"

    invoke-virtual {v5, v11, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 213
    array-length v7, v0

    const/16 v11, 0xf

    if-ge v11, v7, :cond_16

    move v7, v2

    goto :goto_13

    :cond_16
    move v7, v3

    :goto_13
    if-eqz v7, :cond_17

    aget-object v7, v0, v11

    goto :goto_14

    .line 679
    :cond_17
    nop

    .local v11, "it\\13":I
    const/4 v7, 0x0

    .line 213
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$9\\13\\213\\4":I
    move-object v7, v10

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$9\\13\\213\\4":I
    .end local v11    # "it\\13":I
    :goto_14
    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const-string v11, "vcpuAccountingConfigured"

    invoke-virtual {v5, v11, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 215
    array-length v7, v0

    const/16 v11, 0x10

    if-ge v11, v7, :cond_18

    move v7, v2

    goto :goto_15

    :cond_18
    move v7, v3

    :goto_15
    if-eqz v7, :cond_19

    aget-object v7, v0, v11

    goto :goto_16

    .line 679
    :cond_19
    nop

    .local v11, "it\\14":I
    const/4 v7, 0x0

    .line 215
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$10\\14\\215\\4":I
    move-object v7, v10

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$10\\14\\215\\4":I
    .end local v11    # "it\\14":I
    :goto_16
    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const-string v9, "experimentalTcgIrCacheRequested"

    invoke-virtual {v5, v9, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 216
    array-length v7, v0

    const/16 v9, 0xd

    if-ge v9, v7, :cond_1a

    move v7, v2

    goto :goto_17

    :cond_1a
    move v7, v3

    :goto_17
    if-eqz v7, :cond_1b

    aget-object v7, v0, v9

    goto :goto_18

    .line 679
    :cond_1b
    nop

    .local v9, "it\\15":I
    const/4 v7, 0x0

    .line 216
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$11\\15\\216\\4":I
    move-object v7, v10

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$11\\15\\216\\4":I
    .end local v9    # "it\\15":I
    :goto_18
    invoke-static {v7}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    const-wide/16 v11, 0x0

    if-eqz v7, :cond_1c

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    goto :goto_19

    :cond_1c
    move-wide v13, v11

    :goto_19
    const-string v7, "displayInputGeneration"

    invoke-virtual {v5, v7, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 217
    array-length v7, v0

    const/16 v9, 0x11

    if-ge v9, v7, :cond_1d

    move v7, v2

    goto :goto_1a

    :cond_1d
    move v7, v3

    :goto_1a
    if-eqz v7, :cond_1e

    aget-object v7, v0, v9

    goto :goto_1b

    .line 679
    :cond_1e
    nop

    .local v9, "it\\16":I
    const/4 v7, 0x0

    .line 217
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$12\\16\\217\\4":I
    nop

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$12\\16\\217\\4":I
    .end local v9    # "it\\16":I
    const-string v7, "-1"

    :goto_1b
    invoke-static {v7}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    if-eqz v7, :cond_1f

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    goto :goto_1c

    :cond_1f
    const-wide/16 v13, -0x1

    :goto_1c
    const-string v7, "guestFrames"

    invoke-virtual {v5, v7, v13, v14}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 218
    sget-object v7, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v7}, Lorg/lighttouch/android/Native;->guestFrameBuckets()[I

    move-result-object v7

    const-string v9, "guestFrameBuckets"

    invoke-virtual {v5, v9, v7}, Landroid/os/Bundle;->putIntArray(Ljava/lang/String;[I)V

    .line 219
    array-length v7, v0

    const/16 v9, 0xe

    if-ge v9, v7, :cond_20

    move v7, v2

    goto :goto_1d

    :cond_20
    move v7, v3

    :goto_1d
    if-eqz v7, :cond_21

    aget-object v10, v0, v9

    goto :goto_1e

    .line 679
    :cond_21
    nop

    .local v9, "it\\17":I
    const/4 v7, 0x0

    .line 219
    .local v7, "$i$a$-getOrElse-EngineService$binder$1$status$4$13\\17\\219\\4":I
    nop

    .end local v7    # "$i$a$-getOrElse-EngineService$binder$1$status$4$13\\17\\219\\4":I
    .end local v9    # "it\\17":I
    :goto_1e
    invoke-static {v10}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    if-eqz v7, :cond_22

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    :cond_22
    const-string v7, "displayInputOwner"

    invoke-virtual {v5, v7, v11, v12}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    .line 220
    sget-object v7, Lorg/lighttouch/android/ShutdownNativeSnapshot;->Companion:Lorg/lighttouch/android/ShutdownNativeSnapshot$Companion;

    invoke-virtual {v7, v0}, Lorg/lighttouch/android/ShutdownNativeSnapshot$Companion;->from([Ljava/lang/String;)Lorg/lighttouch/android/ShutdownNativeSnapshot;

    move-result-object v7

    .line 221
    .local v7, "shutdown\\4":Lorg/lighttouch/android/ShutdownNativeSnapshot;
    const-string v9, "nativePollSnapshotValid"

    invoke-virtual {v7}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getValid()Z

    move-result v10

    invoke-virtual {v5, v9, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 222
    const-string v9, "guestShutdownConfirmed"

    invoke-virtual {v7}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getConfirmed()Z

    move-result v10

    invoke-virtual {v5, v9, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 223
    invoke-virtual {v7}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getDirty()Ljava/lang/Boolean;

    move-result-object v9

    if-eqz v9, :cond_23

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    .line 679
    .local v9, "it\\18":Z
    const/4 v10, 0x0

    .line 223
    .local v10, "$i$a$-let-EngineService$binder$1$status$4$14\\18\\223\\4":I
    const-string v11, "nativeStateDirty"

    invoke-virtual {v5, v11, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 224
    .end local v9    # "it\\18":Z
    .end local v10    # "$i$a$-let-EngineService$binder$1$status$4$14\\18\\223\\4":I
    :cond_23
    invoke-virtual {v7}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getStorageFailed()Ljava/lang/Boolean;

    move-result-object v9

    if-eqz v9, :cond_24

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    .line 679
    .local v9, "it\\19":Z
    const/4 v10, 0x0

    .line 224
    .local v10, "$i$a$-let-EngineService$binder$1$status$4$15\\19\\224\\4":I
    const-string v11, "nativeStorageFailed"

    invoke-virtual {v5, v11, v9}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 225
    .end local v9    # "it\\19":Z
    .end local v10    # "$i$a$-let-EngineService$binder$1$status$4$15\\19\\224\\4":I
    :cond_24
    invoke-virtual {v7}, Lorg/lighttouch/android/ShutdownNativeSnapshot;->getEngineExit()Ljava/lang/Integer;

    move-result-object v9

    if-eqz v9, :cond_25

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .line 679
    .local v9, "it\\20":I
    const/4 v10, 0x0

    .line 225
    .local v10, "$i$a$-let-EngineService$binder$1$status$4$16\\20\\225\\4":I
    const-string v11, "nativeEngineExit"

    invoke-virtual {v5, v11, v9}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 226
    .end local v9    # "it\\20":I
    .end local v10    # "$i$a$-let-EngineService$binder$1$status$4$16\\20\\225\\4":I
    :cond_25
    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v9

    check-cast v9, Ljava/lang/CharSequence;

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v10

    if-nez v10, :cond_26

    goto :goto_1f

    :cond_26
    move v2, v3

    :goto_1f
    if-eqz v2, :cond_27

    .line 679
    const/4 v2, 0x0

    .line 226
    .local v2, "$i$a$-ifEmpty-EngineService$binder$1$status$4$17\\21\\226\\4":I
    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getAudioError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v9

    .end local v2    # "$i$a$-ifEmpty-EngineService$binder$1$status$4$17\\21\\226\\4":I
    :cond_27
    check-cast v9, Ljava/lang/String;

    const-string v2, "error"

    invoke-virtual {v5, v2, v9}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 227
    const-string v2, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    invoke-virtual {v5, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 228
    const-string v2, "uid"

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    invoke-virtual {v5, v2, v3}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 229
    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getUsb(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/UsbBridge;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/UsbBridge;->getMuxSocket()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_28

    goto :goto_20

    :cond_28
    move-object v8, v2

    :goto_20
    const-string v2, "usbMuxSocket"

    invoke-virtual {v5, v2, v8}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 230
    const-string v2, "appServicesError"

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getUsbError$p(Lorg/lighttouch/android/EngineService;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v2, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 231
    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$getStarted$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerStartAdmission;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/WorkerStartAdmission;->isConsumed()Z

    move-result v2

    const-string v3, "sessionStarted"

    invoke-virtual {v5, v3, v2}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 232
    const-string v2, "observations"

    invoke-static {v4}, Lorg/lighttouch/android/EngineService;->access$observations(Lorg/lighttouch/android/EngineService;)Landroid/os/Bundle;

    move-result-object v3

    invoke-virtual {v5, v2, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 233
    nop

    .line 204
    .end local v5    # "$this$status_u24lambda_u2446\\4":Landroid/os/Bundle;
    .end local v6    # "$i$a$-apply-EngineService$binder$1$status$4\\4\\204\\0":I
    .end local v7    # "shutdown\\4":Lorg/lighttouch/android/ShutdownNativeSnapshot;
    return-object v1
.end method

.method public stop()V
    .locals 5

    .line 272
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getStopping$p(Lorg/lighttouch/android/EngineService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 273
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getProfileCapture(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ProfileCapture;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v3, 0x0

    const-string v4, "guest-stop"

    invoke-static {v0, v4, v2, v1, v3}, Lorg/lighttouch/android/ProfileCapture;->finish$default(Lorg/lighttouch/android/ProfileCapture;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 274
    iget-object v0, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getShutdownWatchdog$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/ShutdownWatchdog;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/ShutdownWatchdog;->request()Z

    .line 275
    return-void
.end method

.method public touch(J[I[I[FIII)Ljava/lang/String;
    .locals 13
    .param p1, "timestampNanos"    # J
    .param p3, "ids"    # [I
    .param p4, "phases"    # [I
    .param p5, "coordinates"    # [F
    .param p6, "width"    # I
    .param p7, "height"    # I
    .param p8, "rotation"    # I

    const-string v0, "ids"

    move-object/from16 v7, p3

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "phases"

    move-object/from16 v8, p4

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "coordinates"

    move-object/from16 v9, p5

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 282
    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    move-object v1, p0

    move-wide v5, p1

    move/from16 v10, p6

    move/from16 v11, p7

    move/from16 v12, p8

    invoke-direct/range {v1 .. v12}, Lorg/lighttouch/android/EngineService$binder$1;->admitTouch(Ljava/lang/Long;JJ[I[I[FIII)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    move-object v3, v0

    .line 679
    .local v3, "it\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 282
    .local v4, "$i$a$-also-EngineService$binder$1$touch$1\\1\\282\\0":I
    invoke-static {v2}, Lorg/lighttouch/android/EngineService;->access$getDisplayCancellations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/DisplayCancellationHistory;

    move-result-object v2

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/DisplayCancellationHistory;->record(Ljava/lang/String;)Z

    .end local v3    # "it\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-also-EngineService$binder$1$touch$1\\1\\282\\0":I
    return-object v0
.end method

.method public touchDisplay(JJJ[I[I[FIII)Ljava/lang/String;
    .locals 16
    .param p1, "lease"    # J
    .param p3, "inputGeneration"    # J
    .param p5, "timestampNanos"    # J
    .param p7, "ids"    # [I
    .param p8, "phases"    # [I
    .param p9, "coordinates"    # [F
    .param p10, "width"    # I
    .param p11, "height"    # I
    .param p12, "rotation"    # I

    move-object/from16 v2, p0

    const-string v0, "ids"

    move-object/from16 v9, p7

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "phases"

    move-object/from16 v10, p8

    invoke-static {v10, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "coordinates"

    move-object/from16 v11, p9

    invoke-static {v11, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 284
    iget-object v0, v2, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    invoke-static {v0}, Lorg/lighttouch/android/EngineService;->access$getLifecycleAdmission$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/WorkerLifecycleAdmission;

    move-result-object v15

    iget-object v1, v2, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    new-instance v0, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda7;

    move-wide/from16 v3, p1

    move-wide/from16 v5, p3

    move-wide/from16 v7, p5

    move/from16 v12, p10

    move/from16 v13, p11

    move/from16 v14, p12

    invoke-direct/range {v0 .. v14}, Lorg/lighttouch/android/EngineService$binder$1$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/EngineService;Lorg/lighttouch/android/EngineService$binder$1;JJJ[I[I[FIII)V

    invoke-virtual {v15, v0}, Lorg/lighttouch/android/WorkerLifecycleAdmission;->run(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;

    move-result-object v0

    .line 289
    iget-object v1, v2, Lorg/lighttouch/android/EngineService$binder$1;->this$0:Lorg/lighttouch/android/EngineService;

    move-object v3, v0

    check-cast v3, Ljava/lang/String;

    .line 679
    .local v3, "it\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 289
    .local v4, "$i$a$-also-EngineService$binder$1$touchDisplay$2\\1\\289\\0":I
    invoke-static {v1}, Lorg/lighttouch/android/EngineService;->access$getDisplayCancellations$p(Lorg/lighttouch/android/EngineService;)Lorg/lighttouch/android/DisplayCancellationHistory;

    move-result-object v1

    invoke-virtual {v1, v3}, Lorg/lighttouch/android/DisplayCancellationHistory;->record(Ljava/lang/String;)Z

    .end local v3    # "it\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-also-EngineService$binder$1$touchDisplay$2\\1\\289\\0":I
    check-cast v0, Ljava/lang/String;

    return-object v0
.end method

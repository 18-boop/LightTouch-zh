.class public final Lorg/lighttouch/android/DevicesSheetKt;
.super Ljava/lang/Object;
.source "DevicesSheet.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDevicesSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DevicesSheet.kt\norg/lighttouch/android/DevicesSheetKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 5 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n+ 9 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 10 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 11 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 12 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,141:1\n1225#2,6:142\n1225#2,6:148\n1225#2,6:155\n1225#2,6:161\n1225#2,6:167\n1225#2,6:329\n1225#2,6:335\n1225#2,6:350\n1225#2,6:356\n1225#2,6:362\n1225#2,6:368\n1225#2,6:375\n1#3:154\n149#4:173\n149#4:174\n149#4:211\n149#4:251\n149#4:349\n99#5:175\n96#5,6:176\n102#5:210\n106#5:348\n79#6,6:182\n86#6,4:197\n90#6,2:207\n79#6,6:218\n86#6,4:233\n90#6,2:243\n94#6:249\n79#6,6:259\n86#6,4:274\n90#6,2:284\n94#6:290\n79#6,6:300\n86#6,4:315\n90#6,2:325\n94#6:343\n94#6:347\n368#7,9:188\n377#7:209\n368#7,9:224\n377#7:245\n378#7,2:247\n368#7,9:265\n377#7:286\n378#7,2:288\n368#7,9:306\n377#7:327\n378#7,2:341\n378#7,2:345\n4034#8,6:201\n4034#8,6:237\n4034#8,6:278\n4034#8,6:319\n71#9:212\n69#9,5:213\n74#9:246\n78#9:250\n71#9:292\n67#9,7:293\n74#9:328\n78#9:344\n86#10:252\n83#10,6:253\n89#10:287\n93#10:291\n77#11:374\n81#12:381\n107#12,2:382\n81#12:384\n107#12,2:385\n81#12:387\n107#12,2:388\n81#12:390\n107#12,2:391\n*S KotlinDebug\n*F\n+ 1 DevicesSheet.kt\norg/lighttouch/android/DevicesSheetKt\n*L\n41#1:142,6\n42#1:148,6\n74#1:155,6\n76#1:161,6\n87#1:167,6\n103#1:329,6\n104#1:335,6\n119#1:350,6\n120#1:356,6\n121#1:362,6\n122#1:368,6\n136#1:375,6\n88#1:173\n90#1:174\n92#1:211\n95#1:251\n113#1:349\n88#1:175\n88#1:176,6\n88#1:210\n88#1:348\n88#1:182,6\n88#1:197,4\n88#1:207,2\n92#1:218,6\n92#1:233,4\n92#1:243,2\n92#1:249\n96#1:259,6\n96#1:274,4\n96#1:284,2\n96#1:290\n102#1:300,6\n102#1:315,4\n102#1:325,2\n102#1:343\n88#1:347\n88#1:188,9\n88#1:209\n92#1:224,9\n92#1:245\n92#1:247,2\n96#1:265,9\n96#1:286\n96#1:288,2\n102#1:306,9\n102#1:327\n102#1:341,2\n88#1:345,2\n88#1:201,6\n92#1:237,6\n96#1:278,6\n102#1:319,6\n92#1:212\n92#1:213,5\n92#1:246\n92#1:250\n102#1:292\n102#1:293,7\n102#1:328\n102#1:344\n96#1:252\n96#1:253,6\n96#1:287\n96#1:291\n134#1:374\n41#1:381\n41#1:382,2\n42#1:384\n42#1:385,2\n87#1:387\n87#1:388,2\n119#1:390\n119#1:391,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00004\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0008\n\u0002\u0018\u0002\u001a#\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0005H\u0001\u00a2\u0006\u0002\u0010\u0006\u001ae\u0010\u0007\u001a\u00020\u00012\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u000c\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00052\u000c\u0010\u000f\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00052\u000c\u0010\u0010\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00052\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0005H\u0003\u00a2\u0006\u0002\u0010\u0012\u001a7\u0010\u0013\u001a\u00020\u00012\u0006\u0010\u0008\u001a\u00020\t2\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00052\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u00010\u0014H\u0001\u00a2\u0006\u0002\u0010\u0016\u001a\r\u0010\u0017\u001a\u00020\u0001H\u0003\u00a2\u0006\u0002\u0010\u0018\u00a8\u0006\u0019\u00b2\u0006\u000c\u0010\u001a\u001a\u0004\u0018\u00010\tX\u008a\u008e\u0002\u00b2\u0006\u000c\u0010\u001b\u001a\u0004\u0018\u00010\tX\u008a\u008e\u0002\u00b2\u0006\n\u0010\u001c\u001a\u00020\u000bX\u008a\u008e\u0002\u00b2\u0006\n\u0010\u001d\u001a\u00020\u001eX\u008a\u008e\u0002"
    }
    d2 = {
        "DevicesSheet",
        "",
        "host",
        "Lorg/lighttouch/android/GuestHost;",
        "onDismiss",
        "Lkotlin/Function0;",
        "(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "DeviceRow",
        "device",
        "Lorg/lighttouch/android/DeviceSummary;",
        "switchable",
        "",
        "editable",
        "needsRecovery",
        "onSelect",
        "onDetails",
        "onRename",
        "onDelete",
        "(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "RenameDialog",
        "Lkotlin/Function1;",
        "",
        "(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V",
        "SheetSystemBars",
        "(Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "renaming",
        "deleting",
        "menu",
        "name",
        "Landroidx/compose/ui/text/input/TextFieldValue;"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$4qwNTOoVwArDovNZNcljCyIa5O0(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog$lambda$34(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$A9zlBhkrOBdjXPKZWgdIWyhnhRI(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/DevicesSheetKt;->SheetSystemBars$lambda$35(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Nv_k2vPe6kVPcHdcj74WX8tSW_s(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$13$lambda$12$lambda$11(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$W5C5IB_o4R5Hbty_FMmXSFUfLjE(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$14(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$aBbaDWWgJAdgQEPbReqc7h5hTiQ(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$10$lambda$7$lambda$6(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$bzrd-58aWYsuSoJeFkobsH2LofA(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$26(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g1QP1NaOaT1LK003nCir685YUNo(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$25$lambda$24$lambda$23$lambda$22(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g4IwqnmX7Mh6YLuNgAY62lRvF9g(Landroid/view/Window;Z)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->SheetSystemBars$lambda$38$lambda$37(Landroid/view/Window;Z)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qqsOpXsdk4-vq5JeHJJL7U3uOrE(Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog$lambda$33$lambda$32(Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qyPtdrxO3pNUFXcMu-4FRynnHMw(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$25$lambda$24$lambda$21$lambda$20(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vcJUZT5LLOXCf_3yD4vmYmvVLEg(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/DevicesSheetKt;->SheetSystemBars$lambda$39(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wdjTBUZbdv9gBWTKuP909NGnCgk(Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/DeviceSummary;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$10$lambda$9$lambda$8(Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/DeviceSummary;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method private static final DeviceRow(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 91
    .param p0, "device"    # Lorg/lighttouch/android/DeviceSummary;
    .param p1, "switchable"    # Z
    .param p2, "editable"    # Z
    .param p3, "needsRecovery"    # Z
    .param p4, "onSelect"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onDetails"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onRename"    # Lkotlin/jvm/functions/Function0;
    .param p7, "onDelete"    # Lkotlin/jvm/functions/Function0;
    .param p8, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/DeviceSummary;",
            "ZZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 86
    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v4, p3

    move/from16 v9, p9

    const v0, -0x6f961846

    move-object/from16 v3, p8

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p8    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(DeviceRow)P(!1,7!2,6,4,5)86@5514L34,87@5553L2028,112@7586L29:DevicesSheet.kt#o13vsk"

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p9

    .local v3, "$dirty":I
    and-int/lit8 v5, v9, 0x6

    if-nez v5, :cond_1

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v3, v5

    :cond_1
    and-int/lit8 v5, v9, 0x30

    if-nez v5, :cond_3

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v3, v5

    :cond_3
    and-int/lit16 v5, v9, 0x180

    if-nez v5, :cond_5

    move/from16 v15, p2

    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x100

    goto :goto_2

    :cond_4
    const/16 v5, 0x80

    :goto_2
    or-int/2addr v3, v5

    goto :goto_3

    :cond_5
    move/from16 v15, p2

    :goto_3
    and-int/lit16 v5, v9, 0xc00

    if-nez v5, :cond_7

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_6

    const/16 v5, 0x800

    goto :goto_4

    :cond_6
    const/16 v5, 0x400

    :goto_4
    or-int/2addr v3, v5

    :cond_7
    and-int/lit16 v5, v9, 0x6000

    if-nez v5, :cond_9

    move-object/from16 v5, p4

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_8

    const/16 v7, 0x4000

    goto :goto_5

    :cond_8
    const/16 v7, 0x2000

    :goto_5
    or-int/2addr v3, v7

    goto :goto_6

    :cond_9
    move-object/from16 v5, p4

    :goto_6
    const/high16 v7, 0x30000

    and-int/2addr v7, v9

    if-nez v7, :cond_b

    move-object/from16 v12, p5

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_a

    const/high16 v7, 0x20000

    goto :goto_7

    :cond_a
    const/high16 v7, 0x10000

    :goto_7
    or-int/2addr v3, v7

    goto :goto_8

    :cond_b
    move-object/from16 v12, p5

    :goto_8
    const/high16 v7, 0x180000

    and-int/2addr v7, v9

    if-nez v7, :cond_d

    move-object/from16 v7, p6

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_c

    const/high16 v8, 0x100000

    goto :goto_9

    :cond_c
    const/high16 v8, 0x80000

    :goto_9
    or-int/2addr v3, v8

    goto :goto_a

    :cond_d
    move-object/from16 v7, p6

    :goto_a
    const/high16 v8, 0xc00000

    and-int/2addr v8, v9

    if-nez v8, :cond_f

    move-object/from16 v8, p7

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_e

    const/high16 v11, 0x800000

    goto :goto_b

    :cond_e
    const/high16 v11, 0x400000

    :goto_b
    or-int/2addr v3, v11

    goto :goto_c

    :cond_f
    move-object/from16 v8, p7

    :goto_c
    const v11, 0x492493

    and-int/2addr v11, v3

    const v13, 0x492492

    if-ne v11, v13, :cond_11

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v11

    if-nez v11, :cond_10

    goto :goto_d

    .line 113
    :cond_10
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v23, v3

    goto/16 :goto_21

    .line 86
    :cond_11
    :goto_d
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v11

    if-eqz v11, :cond_12

    const/4 v11, -0x1

    const-string v13, "org.lighttouch.android.DeviceRow (DevicesSheet.kt:85)"

    invoke-static {v0, v3, v11, v13}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_12
    const v0, 0x6e3c21fe

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):DevicesSheet.kt#9igjgp"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 87
    const/4 v11, 0x0

    move v13, v11

    .local v13, "invalid\\1":Z
    move-object v14, v10

    .local v14, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 167
    .local v16, "$i$f$cache\\1\\87":I
    move/from16 p8, v11

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 168
    .local v17, "$i$a$-let-ComposerKt$cache$1\\2\\167\\1":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    const/4 v2, 0x0

    if-ne v11, v6, :cond_13

    .line 169
    const/4 v6, 0x0

    .line 87
    .local v6, "$i$a$-cache-DevicesSheetKt$DeviceRow$menu$2\\3\\169\\0":I
    move/from16 v23, v3

    .end local v3    # "$dirty":I
    .local v23, "$dirty":I
    invoke-static/range {p8 .. p8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v4, 0x2

    invoke-static {v3, v2, v4, v2}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    .line 169
    .end local v6    # "$i$a$-cache-DevicesSheetKt$DeviceRow$menu$2\\3\\169\\0":I
    nop

    .line 170
    .local v3, "value\\2":Ljava/lang/Object;
    invoke-interface {v14, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 171
    nop

    .end local v3    # "value\\2":Ljava/lang/Object;
    goto :goto_e

    .line 172
    .end local v23    # "$dirty":I
    .local v3, "$dirty":I
    :cond_13
    move/from16 v23, v3

    .end local v3    # "$dirty":I
    .restart local v23    # "$dirty":I
    move-object v3, v11

    .line 168
    :goto_e
    nop

    .line 167
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\2\\167\\1":I
    nop

    .line 87
    .end local v13    # "invalid\\1":Z
    .end local v14    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$f$cache\\1\\87":I
    check-cast v3, Landroidx/compose/runtime/MutableState;

    .local v3, "menu$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 88
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v11, 0x1

    invoke-static {v4, v6, v11, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v13, 0xc

    .local v13, "$this$dp\\4":I
    const/4 v14, 0x0

    .line 173
    .local v14, "$i$f$getDp\\4\\88":I
    int-to-float v11, v13

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 88
    .end local v13    # "$this$dp\\4":I
    .end local v14    # "$i$f$getDp\\4\\88":I
    const/4 v13, 0x2

    invoke-static {v4, v11, v6, v13, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v4, 0xe

    .local v4, "$this$dp\\5":I
    const/4 v6, 0x0

    .line 173
    .local v6, "$i$f$getDp\\5\\88":I
    int-to-float v11, v4

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 88
    .end local v4    # "$this$dp\\5":I
    .end local v6    # "$i$f$getDp\\5\\88":I
    invoke-static {v4}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v4}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    .line 89
    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getSelected()Z

    move-result v2

    if-eqz v2, :cond_14

    const v2, 0x1d8f1611

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "88@5696L11"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHighest-0d7_KjU()J

    move-result-wide v13

    goto :goto_f

    :cond_14
    const v2, 0x1d8f1ced

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "88@5751L11"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerLow-0d7_KjU()J

    move-result-wide v13

    :goto_f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v17, v13

    const/16 v20, 0x2

    const/16 v21, 0x0

    const/16 v19, 0x0

    invoke-static/range {v16 .. v21}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    .line 90
    if-eqz p1, :cond_15

    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getSelected()Z

    move-result v2

    if-nez v2, :cond_15

    const/16 v17, 0x1

    goto :goto_10

    :cond_15
    move/from16 v17, p8

    :goto_10
    const/16 v21, 0x6

    const/16 v22, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v20, v5

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v25

    const/16 v2, 0xc

    .local v2, "$this$dp\\6":I
    const/4 v4, 0x0

    .line 174
    .local v4, "$i$f$getDp\\6\\90":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v26

    .line 90
    .end local v2    # "$this$dp\\6":I
    .end local v4    # "$i$f$getDp\\6\\90":I
    const/16 v2, 0xa

    .local v2, "$this$dp\\7":I
    const/4 v4, 0x0

    .line 174
    .local v4, "$i$f$getDp\\7\\90":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v27

    .line 90
    .end local v2    # "$this$dp\\7":I
    .end local v4    # "$i$f$getDp\\7\\90":I
    const/16 v2, 0xa

    .local v2, "$this$dp\\8":I
    const/4 v4, 0x0

    .line 174
    .local v4, "$i$f$getDp\\8\\90":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v29

    .line 90
    .end local v2    # "$this$dp\\8":I
    .end local v4    # "$i$f$getDp\\8\\90":I
    const/16 v30, 0x4

    const/16 v31, 0x0

    const/16 v28, 0x0

    invoke-static/range {v25 .. v31}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 91
    const-string v4, "device_row"

    invoke-static {v2, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v4

    .line 88
    const/16 v5, 0x180

    .local v2, "modifier\\9":Landroidx/compose/ui/Modifier;
    .local v4, "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .local v5, "$changed\\9":I
    const/4 v6, 0x0

    .line 175
    .local v6, "$i$f$Row\\9\\88":I
    const v11, 0x2952b718

    const-string v13, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v10, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 176
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    .line 180
    .local v11, "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v13, v5, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v5, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v11, v4, v10, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v5, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 181
    move/from16 v17, v14

    .local v17, "$changed\\10":I
    const/16 v18, 0x0

    .line 182
    .local v18, "$i$f$Layout\\10\\181":I
    const v14, -0x4ee9b9da

    move-object/from16 v19, v4

    .end local v4    # "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .local v19, "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    const-string v4, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 183
    move/from16 v14, p8

    invoke-static {v10, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v20

    .line 184
    .local v20, "compositeKeyHash\\10":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 185
    .local v14, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v21, v5

    .end local v5    # "$changed\\9":I
    .local v21, "$changed\\9":I
    invoke-static {v10, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 187
    .local v5, "materialized\\10":Landroidx/compose/ui/Modifier;
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v22

    move-object/from16 v25, v2

    .end local v2    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .local v25, "modifier\\9":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v17, 0x6

    and-int/lit16 v2, v2, 0x380

    move/from16 v26, v2

    const/4 v2, 0x6

    or-int/lit8 v26, v26, 0x6

    .line 186
    nop

    .local v26, "$changed\\11":I
    move-object/from16 v27, v22

    .local v27, "factory\\11":Lkotlin/jvm/functions/Function0;
    const/16 v22, 0x0

    .line 188
    .local v22, "$i$f$ReusableComposeNode\\11\\186":I
    move/from16 v28, v2

    const v2, -0x2942ffcf

    move/from16 v29, v6

    .end local v6    # "$i$f$Row\\9\\88":I
    .local v29, "$i$f$Row\\9\\88":I
    const-string v6, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 189
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 190
    :cond_16
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 191
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_17

    .line 192
    move-object/from16 v2, v27

    .end local v27    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_11

    .line 194
    .end local v2    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v27    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :cond_17
    move-object/from16 v2, v27

    .end local v27    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 196
    :goto_11
    move-object/from16 v27, v2

    .end local v2    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v27    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 197
    .local v31, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\196\\10":I
    sget-object v32, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v32 .. v32}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v13, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 198
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v14, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 200
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\13":Lkotlin/jvm/functions/Function2;
    const/16 v32, 0x0

    .line 201
    .local v32, "$i$f$set-impl\\13\\200":I
    move-object/from16 v33, v2

    .local v33, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 202
    .local v34, "$i$a$-with-Updater$set$1\\14\\201\\13":I
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v35

    if-nez v35, :cond_19

    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_18

    goto :goto_12

    :cond_18
    move-object/from16 v9, v33

    goto :goto_13

    .line 203
    :cond_19
    :goto_12
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    move-object/from16 v9, v33

    .end local v33    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 204
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v2, v8, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 206
    :goto_13
    nop

    .line 201
    .end local v9    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-with-Updater$set$1\\14\\201\\13":I
    nop

    .line 206
    nop

    .line 207
    .end local v7    # "block\\13":Lkotlin/jvm/functions/Function2;
    .end local v32    # "$i$f$set-impl\\13\\200":I
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v5, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 208
    nop

    .line 196
    .end local v2    # "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\196\\10":I
    nop

    .line 209
    shr-int/lit8 v2, v26, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\15":I
    move-object v7, v10

    .local v7, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 210
    .local v8, "$i$a$-Layout-RowKt$Row$1\\15\\209\\9":I
    const v9, -0x184f2606

    move/from16 v31, v2

    .end local v2    # "$changed\\15":I
    .local v31, "$changed\\15":I
    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v7, v9, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v9, v21, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\16":I
    move-object/from16 v32, v2

    check-cast v32, Landroidx/compose/foundation/layout/RowScope;

    .local v32, "$this$DeviceRow_u24lambda_u2425\\16":Landroidx/compose/foundation/layout/RowScope;
    move-object v2, v7

    .local v2, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 92
    .local v41, "$i$a$-Row-DevicesSheetKt$DeviceRow$1\\16\\210\\0":I
    move-object/from16 v42, v5

    .end local v5    # "materialized\\10":Landroidx/compose/ui/Modifier;
    .local v42, "materialized\\10":Landroidx/compose/ui/Modifier;
    const v5, -0x7b6dd1f3

    move-object/from16 v43, v7

    .end local v7    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\15":Landroidx/compose/runtime/Composer;
    const-string v7, "C91@6057L11,91@6007L249,94@6265L29,95@6303L405,101@6825L750:DevicesSheet.kt#o13vsk"

    invoke-static {v2, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x2c

    .local v7, "$this$dp\\17":I
    const/16 v33, 0x0

    .line 211
    .local v33, "$i$f$getDp\\17\\92":I
    move/from16 v44, v8

    .end local v8    # "$i$a$-Layout-RowKt$Row$1\\15\\209\\9":I
    .local v44, "$i$a$-Layout-RowKt$Row$1\\15\\209\\9":I
    int-to-float v8, v7

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 92
    .end local v7    # "$this$dp\\17":I
    .end local v33    # "$i$f$getDp\\17\\92":I
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v2, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v7

    move/from16 v45, v9

    .end local v9    # "$changed\\16":I
    .local v45, "$changed\\16":I
    const/16 v9, 0xc

    .local v9, "$this$dp\\18":I
    const/16 v33, 0x0

    .line 211
    .local v33, "$i$f$getDp\\18\\92":I
    move-object/from16 v46, v11

    .end local v11    # "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v46, "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 92
    .end local v9    # "$this$dp\\18":I
    .end local v33    # "$i$f$getDp\\18\\92":I
    invoke-static {v9}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v5, v7, v8, v9}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\19":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v7

    .local v7, "contentAlignment\\19":Landroidx/compose/ui/Alignment;
    const/16 v8, 0x30

    .local v8, "$changed\\19":I
    const/4 v9, 0x0

    .line 212
    .local v9, "$i$f$Box\\19\\92":I
    const v11, 0x2bb5b5d7

    move/from16 v33, v8

    .end local v8    # "$changed\\19":I
    .local v33, "$changed\\19":I
    const-string v8, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v2, v11, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 213
    const/4 v11, 0x0

    .line 216
    .local v11, "propagateMinConstraints\\19":Z
    move/from16 v34, v9

    .end local v9    # "$i$f$Box\\19\\92":I
    .local v34, "$i$f$Box\\19\\92":I
    invoke-static {v7, v11}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v35, v33, 0x3

    and-int/lit8 v35, v35, 0x70

    .line 217
    nop

    .local v35, "$changed\\20":I
    const/16 v36, 0x0

    .line 218
    .local v36, "$i$f$Layout\\20\\217":I
    move-object/from16 v37, v7

    const v7, -0x4ee9b9da

    .end local v7    # "contentAlignment\\19":Landroidx/compose/ui/Alignment;
    .local v37, "contentAlignment\\19":Landroidx/compose/ui/Alignment;
    invoke-static {v2, v7, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 219
    const/4 v7, 0x0

    invoke-static {v2, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v38

    .line 220
    .local v38, "compositeKeyHash\\20":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 221
    .local v7, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v39, v11

    .end local v11    # "propagateMinConstraints\\19":Z
    .local v39, "propagateMinConstraints\\19":Z
    invoke-static {v2, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 223
    .local v11, "materialized\\20":Landroidx/compose/ui/Modifier;
    sget-object v40, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v40 .. v40}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v40

    move-object/from16 v48, v5

    .end local v5    # "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v48, "modifier\\19":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v35, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 222
    move-object/from16 v49, v40

    .local v5, "$changed\\21":I
    .local v49, "factory\\21":Lkotlin/jvm/functions/Function0;
    const/16 v40, 0x0

    .line 224
    .local v40, "$i$f$ReusableComposeNode\\21\\222":I
    move/from16 v50, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\21":I
    .local v50, "$changed\\21":I
    invoke-static {v2, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 225
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 226
    :cond_1a
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 227
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_1b

    .line 228
    move-object/from16 v5, v49

    .end local v49    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_14

    .line 230
    .end local v5    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v49    # "factory\\21":Lkotlin/jvm/functions/Function0;
    :cond_1b
    move-object/from16 v5, v49

    .end local v49    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 232
    :goto_14
    move-object/from16 v49, v5

    .end local v5    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v49    # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 233
    .local v51, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\232\\20":I
    sget-object v52, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v52 .. v52}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    invoke-static {v5, v9, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 234
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    invoke-static {v5, v7, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 236
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    .local v12, "block\\23":Lkotlin/jvm/functions/Function2;
    const/16 v52, 0x0

    .line 237
    .local v52, "$i$f$set-impl\\23\\236":I
    move-object/from16 v53, v5

    .local v53, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 238
    .local v54, "$i$a$-with-Updater$set$1\\24\\237\\23":I
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v55

    if-nez v55, :cond_1d

    move-object/from16 v55, v7

    .end local v7    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .local v55, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move-object/from16 v56, v9

    .end local v9    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v56, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1c

    goto :goto_15

    :cond_1c
    move-object/from16 v9, v53

    goto :goto_16

    .end local v55    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v56    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v7    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_1d
    move-object/from16 v55, v7

    move-object/from16 v56, v9

    .line 239
    .end local v7    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v55    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v56    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_15
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v9, v53

    .end local v53    # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 240
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v5, v7, v12}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 242
    :goto_16
    nop

    .line 237
    .end local v9    # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-with-Updater$set$1\\24\\237\\23":I
    nop

    .line 242
    nop

    .line 243
    .end local v12    # "block\\23":Lkotlin/jvm/functions/Function2;
    .end local v52    # "$i$f$set-impl\\23\\236":I
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v11, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 244
    nop

    .line 232
    .end local v5    # "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\232\\20":I
    nop

    .line 245
    shr-int/lit8 v5, v50, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\25":I
    move-object v7, v2

    .local v7, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 246
    .local v9, "$i$a$-Layout-BoxKt$Box$1\\25\\245\\19":I
    const v12, -0x7ff519f7    # -1.000876E-39f

    move/from16 v51, v5

    .end local v5    # "$changed\\25":I
    .local v51, "$changed\\25":I
    const-string v5, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v7, v12, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v52, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v53, v33, 0x6

    and-int/lit8 v53, v53, 0x70

    or-int/lit8 v53, v53, 0x6

    .local v53, "$changed\\26":I
    check-cast v52, Landroidx/compose/foundation/layout/BoxScope;

    .local v52, "$this$DeviceRow_u24lambda_u2425_u24lambda_u2418\\26":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v62, v7

    .local v62, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 93
    .local v54, "$i$a$-Box-DevicesSheetKt$DeviceRow$1$1\\26\\246\\16":I
    const v12, -0x7f4b2819

    move-object/from16 v66, v7

    .end local v7    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\25":Landroidx/compose/runtime/Composer;
    const-string v7, "C92@6217L11,92@6170L76:DevicesSheet.kt#o13vsk"

    move/from16 v67, v9

    move-object/from16 v9, v62

    .end local v62    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v67, "$i$a$-Layout-BoxKt$Box$1\\25\\245\\19":I
    invoke-static {v9, v12, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v7, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v7}, Lorg/lighttouch/android/LtIcons;->getPhone()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v57

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v9, v12}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v60

    const/16 v63, 0x30

    const/16 v64, 0x4

    const/16 v58, 0x0

    const/16 v59, 0x0

    .end local v9    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v62    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v57 .. v64}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .end local v62    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 94
    nop

    .line 246
    .end local v9    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v52    # "$this$DeviceRow_u24lambda_u2425_u24lambda_u2418\\26":Landroidx/compose/foundation/layout/BoxScope;
    .end local v53    # "$changed\\26":I
    .end local v54    # "$i$a$-Box-DevicesSheetKt$DeviceRow$1$1\\26\\246\\16":I
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 245
    .end local v51    # "$changed\\25":I
    .end local v66    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .end local v67    # "$i$a$-Layout-BoxKt$Box$1\\25\\245\\19":I
    nop

    .line 247
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 224
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 248
    nop

    .line 218
    .end local v40    # "$i$f$ReusableComposeNode\\21\\222":I
    .end local v49    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .end local v50    # "$changed\\21":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 249
    nop

    .line 212
    .end local v11    # "materialized\\20":Landroidx/compose/ui/Modifier;
    .end local v35    # "$changed\\20":I
    .end local v36    # "$i$f$Layout\\20\\217":I
    .end local v38    # "compositeKeyHash\\20":I
    .end local v55    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 250
    nop

    .line 95
    .end local v33    # "$changed\\19":I
    .end local v34    # "$i$f$Box\\19\\92":I
    .end local v37    # "contentAlignment\\19":Landroidx/compose/ui/Alignment;
    .end local v39    # "propagateMinConstraints\\19":Z
    .end local v48    # "modifier\\19":Landroidx/compose/ui/Modifier;
    .end local v56    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    const/16 v9, 0x10

    .local v9, "$this$dp\\27":I
    const/4 v11, 0x0

    .line 251
    .local v11, "$i$f$getDp\\27\\95":I
    int-to-float v12, v9

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 95
    .end local v9    # "$this$dp\\27":I
    .end local v11    # "$i$f$getDp\\27\\95":I
    invoke-static {v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v7

    move/from16 v9, v28

    invoke-static {v7, v2, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 96
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v33, v7

    check-cast v33, Landroidx/compose/ui/Modifier;

    const/16 v36, 0x2

    const/16 v37, 0x0

    const/high16 v34, 0x3f800000    # 1.0f

    const/16 v35, 0x0

    invoke-static/range {v32 .. v37}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .local v7, "modifier\\28":Landroidx/compose/ui/Modifier;
    const/4 v9, 0x0

    .local v9, "$changed\\28":I
    const/4 v11, 0x0

    .line 252
    .local v11, "$i$f$Column\\28\\96":I
    const v12, -0x1cd0f17e

    move/from16 v33, v9

    .end local v9    # "$changed\\28":I
    .local v33, "$changed\\28":I
    const-string v9, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v2, v12, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 253
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 254
    .local v9, "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v12

    .line 257
    .local v12, "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v34, v33, 0x3

    and-int/lit8 v34, v34, 0xe

    shr-int/lit8 v35, v33, 0x3

    and-int/lit8 v35, v35, 0x70

    move/from16 v36, v11

    .end local v11    # "$i$f$Column\\28\\96":I
    .local v36, "$i$f$Column\\28\\96":I
    or-int v11, v34, v35

    invoke-static {v9, v12, v2, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v34, v33, 0x3

    and-int/lit8 v34, v34, 0x70

    .line 258
    nop

    .local v34, "$changed\\29":I
    const/16 v35, 0x0

    .line 259
    .local v35, "$i$f$Layout\\29\\258":I
    move-object/from16 v37, v9

    const v9, -0x4ee9b9da

    .end local v9    # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v37, "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v2, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 260
    const/4 v9, 0x0

    invoke-static {v2, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v38

    .line 261
    .local v38, "compositeKeyHash\\29":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 262
    .local v9, "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v39, v12

    .end local v12    # "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    .local v39, "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v2, v7}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 264
    .local v12, "materialized\\29":Landroidx/compose/ui/Modifier;
    sget-object v40, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v40 .. v40}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v40

    move-object/from16 v48, v7

    .end local v7    # "modifier\\28":Landroidx/compose/ui/Modifier;
    .local v48, "modifier\\28":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v7, v34, 0x6

    and-int/lit16 v7, v7, 0x380

    const/16 v28, 0x6

    or-int/lit8 v7, v7, 0x6

    .line 263
    move-object/from16 v49, v40

    .local v7, "$changed\\30":I
    .local v49, "factory\\30":Lkotlin/jvm/functions/Function0;
    const/16 v40, 0x0

    .line 265
    .local v40, "$i$f$ReusableComposeNode\\30\\263":I
    move/from16 v50, v7

    const v7, -0x2942ffcf

    .end local v7    # "$changed\\30":I
    .local v50, "$changed\\30":I
    invoke-static {v2, v7, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 266
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_1e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 267
    :cond_1e
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 268
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_1f

    .line 269
    move-object/from16 v7, v49

    .end local v49    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .local v7, "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_17

    .line 271
    .end local v7    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v49    # "factory\\30":Lkotlin/jvm/functions/Function0;
    :cond_1f
    move-object/from16 v7, v49

    .end local v49    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 273
    :goto_17
    move-object/from16 v49, v7

    .end local v7    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v49    # "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 274
    .local v51, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\31\\273\\29":I
    sget-object v52, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v53, v13

    .end local v13    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v53, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-virtual/range {v52 .. v52}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v7, v11, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 275
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v7, v9, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 277
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\32":Lkotlin/jvm/functions/Function2;
    const/16 v52, 0x0

    .line 278
    .local v52, "$i$f$set-impl\\32\\277":I
    move-object/from16 v54, v7

    .local v54, "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 279
    .local v55, "$i$a$-with-Updater$set$1\\33\\278\\32":I
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v56

    if-nez v56, :cond_21

    move-object/from16 v56, v9

    .end local v9    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .local v56, "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v57, v11

    .end local v11    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v57, "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_20

    goto :goto_18

    :cond_20
    move-object/from16 v11, v54

    goto :goto_19

    .end local v56    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v11    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_21
    move-object/from16 v56, v9

    move-object/from16 v57, v11

    .line 280
    .end local v9    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v11    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v56    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v57    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_18
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v11, v54

    .end local v54    # "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .local v11, "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 281
    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v7, v9, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 283
    :goto_19
    nop

    .line 278
    .end local v11    # "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-with-Updater$set$1\\33\\278\\32":I
    nop

    .line 283
    nop

    .line 284
    .end local v13    # "block\\32":Lkotlin/jvm/functions/Function2;
    .end local v52    # "$i$f$set-impl\\32\\277":I
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v7, v12, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 285
    nop

    .line 273
    .end local v7    # "$this$Layout_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\31\\273\\29":I
    nop

    .line 286
    shr-int/lit8 v7, v50, 0x6

    and-int/lit8 v7, v7, 0xe

    .local v7, "$changed\\34":I
    move-object v9, v2

    .local v9, "$composer\\34":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 287
    .local v11, "$i$a$-Layout-ColumnKt$Column$1\\34\\286\\28":I
    const v13, -0x16ef5699

    move/from16 v51, v7

    .end local v7    # "$changed\\34":I
    .local v51, "$changed\\34":I
    const-string v7, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v9, v13, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v7, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v13, v33, 0x6

    and-int/lit8 v13, v13, 0x70

    const/16 v28, 0x6

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\35":I
    check-cast v7, Landroidx/compose/foundation/layout/ColumnScope;

    .local v7, "$this$DeviceRow_u24lambda_u2425_u24lambda_u2419\\35":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v87, v9

    .local v87, "$composer\\35":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 97
    .local v52, "$i$a$-Column-DevicesSheetKt$DeviceRow$1$2\\35\\287\\16":I
    move-object/from16 v54, v7

    .end local v7    # "$this$DeviceRow_u24lambda_u2425_u24lambda_u2419\\35":Landroidx/compose/foundation/layout/ColumnScope;
    .local v54, "$this$DeviceRow_u24lambda_u2425_u24lambda_u2419\\35":Landroidx/compose/foundation/layout/ColumnScope;
    const v7, -0x16c0aa1e

    move-object/from16 v55, v9

    .end local v9    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\34":Landroidx/compose/runtime/Composer;
    const-string v9, "C96@6385L10,96@6345L110,97@6561L10,98@6621L11,97@6468L230:DevicesSheet.kt#o13vsk"

    move/from16 v58, v11

    move-object/from16 v11, v87

    .end local v87    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v58, "$i$a$-Layout-ColumnKt$Column$1\\34\\286\\28":I
    invoke-static {v11, v7, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v66

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v11, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v86

    sget-object v7, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v81

    const/16 v89, 0xc30

    const v90, 0xd7fe

    const/16 v67, 0x0

    const-wide/16 v68, 0x0

    const-wide/16 v70, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const-wide/16 v75, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const-wide/16 v79, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x1

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v88, 0x0

    .end local v11    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v87    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v66 .. v90}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 98
    .end local v87    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getSubtitle()Ljava/lang/String;

    move-result-object v7

    if-eqz p3, :cond_22

    const-string v9, " \u00b7 \u9700\u8981\u6062\u590d"

    goto :goto_1a

    :cond_22
    const-string v9, ""

    :goto_1a
    move-object/from16 v59, v12

    .end local v12    # "materialized\\29":Landroidx/compose/ui/Modifier;
    .local v59, "materialized\\29":Landroidx/compose/ui/Modifier;
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v66

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v11, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v86

    .line 99
    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v11, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v68

    sget-object v7, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v81

    .line 98
    nop

    .line 99
    nop

    .line 98
    const/16 v89, 0xc30

    const v90, 0xd7fa

    const/16 v67, 0x0

    const-wide/16 v70, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const-wide/16 v75, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const-wide/16 v79, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x1

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v88, 0x0

    move-object/from16 v87, v11

    .end local v11    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v87    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v66 .. v90}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 97
    invoke-static/range {v87 .. v87}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 100
    nop

    .line 287
    .end local v13    # "$changed\\35":I
    .end local v52    # "$i$a$-Column-DevicesSheetKt$DeviceRow$1$2\\35\\287\\16":I
    .end local v54    # "$this$DeviceRow_u24lambda_u2425_u24lambda_u2419\\35":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v87    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 286
    .end local v51    # "$changed\\34":I
    .end local v55    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .end local v58    # "$i$a$-Layout-ColumnKt$Column$1\\34\\286\\28":I
    nop

    .line 288
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 265
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 289
    nop

    .line 259
    .end local v40    # "$i$f$ReusableComposeNode\\30\\263":I
    .end local v49    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .end local v50    # "$changed\\30":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 290
    nop

    .line 252
    .end local v34    # "$changed\\29":I
    .end local v35    # "$i$f$Layout\\29\\258":I
    .end local v38    # "compositeKeyHash\\29":I
    .end local v56    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v59    # "materialized\\29":Landroidx/compose/ui/Modifier;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 291
    nop

    .end local v33    # "$changed\\28":I
    .end local v36    # "$i$f$Column\\28\\96":I
    .end local v37    # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v39    # "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v48    # "modifier\\28":Landroidx/compose/ui/Modifier;
    .end local v57    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    const v7, 0x14cb3bb9

    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "100@6796L11,100@6738L78"

    invoke-static {v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 101
    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getSelected()Z

    move-result v7

    if-eqz v7, :cond_23

    sget-object v7, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v7}, Landroidx/compose/material/icons/filled/CheckKt;->getCheck(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v33

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v2, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v36

    const/16 v39, 0x30

    const/16 v40, 0x4

    const-string v34, "\u5df2\u9009\u62e9"

    const/16 v35, 0x0

    move-object/from16 v38, v2

    .end local v2    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v33 .. v40}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v7, v38

    .end local v38    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\16":Landroidx/compose/runtime/Composer;
    goto :goto_1b

    .end local v7    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :cond_23
    move-object v7, v2

    .end local v2    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :goto_1b
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 102
    const/4 v9, 0x0

    move v2, v9

    .local v2, "$changed\\36":I
    const/4 v9, 0x0

    .line 292
    .local v9, "$i$f$Box\\36\\102":I
    const v11, 0x2bb5b5d7

    invoke-static {v7, v11, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 293
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 294
    .local v8, "modifier\\36":Landroidx/compose/ui/Modifier;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v11

    .line 295
    .local v11, "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    const/4 v12, 0x0

    .line 298
    .local v12, "propagateMinConstraints\\36":Z
    invoke-static {v11, v12}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v33, v2, 0x3

    and-int/lit8 v33, v33, 0x70

    .line 299
    nop

    .local v33, "$changed\\37":I
    const/16 v34, 0x0

    .line 300
    .local v34, "$i$f$Layout\\37\\299":I
    move/from16 v35, v2

    const v2, -0x4ee9b9da

    .end local v2    # "$changed\\36":I
    .local v35, "$changed\\36":I
    invoke-static {v7, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 301
    const/4 v2, 0x0

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v2

    .line 302
    .local v2, "compositeKeyHash\\37":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 303
    .local v4, "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p8, v2

    .end local v2    # "compositeKeyHash\\37":I
    .local p8, "compositeKeyHash\\37":I
    invoke-static {v7, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 305
    .local v2, "materialized\\37":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v36, v8

    .end local v8    # "modifier\\36":Landroidx/compose/ui/Modifier;
    .local v36, "modifier\\36":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v8, v33, 0x6

    and-int/lit16 v8, v8, 0x380

    const/16 v28, 0x6

    or-int/lit8 v8, v8, 0x6

    .line 304
    move-object/from16 v37, v16

    .local v8, "$changed\\38":I
    .local v37, "factory\\38":Lkotlin/jvm/functions/Function0;
    const/16 v38, 0x0

    .line 306
    .local v38, "$i$f$ReusableComposeNode\\38\\304":I
    move/from16 v39, v8

    const v8, -0x2942ffcf

    .end local v8    # "$changed\\38":I
    .local v39, "$changed\\38":I
    invoke-static {v7, v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 307
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_24

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 308
    :cond_24
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 309
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_25

    .line 310
    move-object/from16 v6, v37

    .end local v37    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .local v6, "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1c

    .line 312
    .end local v6    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\38":Lkotlin/jvm/functions/Function0;
    :cond_25
    move-object/from16 v6, v37

    .end local v37    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 314
    :goto_1c
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 315
    .local v16, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\39\\314\\37":I
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v37, v6

    .end local v6    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v8, v13, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 316
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v8, v4, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 318
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\40":Lkotlin/jvm/functions/Function2;
    const/16 v30, 0x0

    .line 319
    .local v30, "$i$f$set-impl\\40\\318":I
    move-object/from16 v40, v8

    .local v40, "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 320
    .local v47, "$i$a$-with-Updater$set$1\\41\\319\\40":I
    invoke-interface/range {v40 .. v40}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v48

    if-nez v48, :cond_27

    move-object/from16 v48, v4

    .end local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .local v48, "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v40 .. v40}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v49, v7

    .end local v7    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_26

    goto :goto_1d

    :cond_26
    move-object/from16 v7, v40

    goto :goto_1e

    .end local v48    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v49    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v7    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :cond_27
    move-object/from16 v48, v4

    move-object/from16 v49, v7

    .line 321
    .end local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v7    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v48    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v49    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :goto_1d
    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v7, v40

    .end local v40    # "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 322
    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v8, v4, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 324
    :goto_1e
    nop

    .line 319
    .end local v7    # "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .end local v47    # "$i$a$-with-Updater$set$1\\41\\319\\40":I
    nop

    .line 324
    nop

    .line 325
    .end local v6    # "block\\40":Lkotlin/jvm/functions/Function2;
    .end local v30    # "$i$f$set-impl\\40\\318":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v2, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 326
    nop

    .line 314
    .end local v8    # "$this$Layout_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\39\\314\\37":I
    nop

    .line 327
    shr-int/lit8 v4, v39, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\42":I
    move-object/from16 v6, v49

    .local v6, "$composer\\42":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 328
    .local v7, "$i$a$-Layout-BoxKt$Box$1\\42\\327\\36":I
    const v8, -0x7ff519f7    # -1.000876E-39f

    invoke-static {v6, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v8, v35, 0x6

    and-int/lit8 v8, v8, 0x70

    const/16 v28, 0x6

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\43":I
    check-cast v5, Landroidx/compose/foundation/layout/BoxScope;

    .local v5, "$this$DeviceRow_u24lambda_u2425_u24lambda_u2424\\43":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v60, v6

    .local v60, "$composer\\43":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 103
    .local v30, "$i$a$-Box-DevicesSheetKt$DeviceRow$1$3\\43\\328\\16":I
    move-object/from16 v40, v2

    .end local v2    # "materialized\\37":Landroidx/compose/ui/Modifier;
    .local v40, "materialized\\37":Landroidx/compose/ui/Modifier;
    const v2, -0x73386da8

    move/from16 v47, v4

    .end local v4    # "$changed\\42":I
    .local v47, "$changed\\42":I
    const-string v4, "C102@6864L15,102@6881L61,102@6843L99,103@6974L16,103@6992L573,103@6955L610:DevicesSheet.kt#o13vsk"

    move-object/from16 v50, v5

    move-object/from16 v5, v60

    .end local v60    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v50, "$this$DeviceRow_u24lambda_u2425_u24lambda_u2424\\43":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, 0x4c5de2

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\44":Z
    move-object/from16 v16, v5

    .local v16, "$this$cache\\44":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 329
    .local v51, "$i$f$cache\\44\\103":I
    invoke-interface/range {v16 .. v16}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\44":Ljava/lang/Object;
    const/16 v54, 0x0

    .line 330
    .local v54, "$i$a$-let-ComposerKt$cache$1\\45\\329\\44":I
    sget-object v55, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v56, v4

    .end local v4    # "invalid\\44":Z
    .local v56, "invalid\\44":Z
    invoke-virtual/range {v55 .. v55}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v2, v4, :cond_28

    .line 331
    const/4 v4, 0x0

    .line 103
    .local v4, "$i$a$-cache-DevicesSheetKt$DeviceRow$1$3$1\\46\\331\\43":I
    move-object/from16 v55, v2

    .end local v2    # "it\\44":Ljava/lang/Object;
    .local v55, "it\\44":Ljava/lang/Object;
    new-instance v2, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda0;

    invoke-direct {v2, v3}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 331
    .end local v4    # "$i$a$-cache-DevicesSheetKt$DeviceRow$1$3$1\\46\\331\\43":I
    nop

    .line 332
    .local v2, "value\\45":Ljava/lang/Object;
    move-object/from16 v4, v16

    .end local v16    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .local v4, "$this$cache\\44":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 333
    nop

    .end local v2    # "value\\45":Ljava/lang/Object;
    goto :goto_1f

    .line 334
    .end local v4    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .end local v55    # "it\\44":Ljava/lang/Object;
    .local v2, "it\\44":Ljava/lang/Object;
    .restart local v16    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    :cond_28
    move-object/from16 v55, v2

    move-object/from16 v4, v16

    .line 330
    .end local v2    # "it\\44":Ljava/lang/Object;
    .end local v16    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .restart local v55    # "it\\44":Ljava/lang/Object;
    :goto_1f
    nop

    .line 329
    .end local v54    # "$i$a$-let-ComposerKt$cache$1\\45\\329\\44":I
    .end local v55    # "it\\44":Ljava/lang/Object;
    nop

    .line 103
    .end local v4    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$f$cache\\44\\103":I
    .end local v56    # "invalid\\44":Z
    move-object/from16 v54, v2

    check-cast v54, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v2, Lorg/lighttouch/android/DevicesSheetKt$DeviceRow$1$3$2;

    invoke-direct {v2, v1}, Lorg/lighttouch/android/DevicesSheetKt$DeviceRow$1$3$2;-><init>(Lorg/lighttouch/android/DeviceSummary;)V

    const/16 v4, 0x36

    const v1, 0x7dcc077c

    move-object/from16 v51, v6

    const/4 v6, 0x1

    .end local v6    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static {v1, v6, v2, v5, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object/from16 v59, v1

    check-cast v59, Lkotlin/jvm/functions/Function2;

    const v61, 0x30006

    const/16 v62, 0x1e

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    move-object/from16 v60, v5

    .end local v5    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static/range {v54 .. v62}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 104
    move-object/from16 v4, v60

    .end local v60    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v54

    const v1, 0x4c5de2

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\47":Z
    move-object v1, v4

    .local v1, "$this$cache\\47":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 335
    .local v2, "$i$f$cache\\47\\104":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\47":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 336
    .local v16, "$i$a$-let-ComposerKt$cache$1\\48\\335\\47":I
    sget-object v24, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v24 .. v24}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v5, v6, :cond_29

    .line 337
    const/4 v6, 0x0

    .line 104
    .local v6, "$i$a$-cache-DevicesSheetKt$DeviceRow$1$3$3\\49\\337\\43":I
    move/from16 v24, v0

    .end local v0    # "invalid\\47":Z
    .local v24, "invalid\\47":Z
    new-instance v0, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda3;

    invoke-direct {v0, v3}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda3;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 337
    .end local v6    # "$i$a$-cache-DevicesSheetKt$DeviceRow$1$3$3\\49\\337\\43":I
    nop

    .line 338
    .local v0, "value\\48":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 339
    nop

    .end local v0    # "value\\48":Ljava/lang/Object;
    goto :goto_20

    .line 340
    .end local v24    # "invalid\\47":Z
    .local v0, "invalid\\47":Z
    :cond_29
    move/from16 v24, v0

    .end local v0    # "invalid\\47":Z
    .restart local v24    # "invalid\\47":Z
    move-object v0, v5

    .line 336
    :goto_20
    nop

    .line 335
    .end local v5    # "it\\47":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\48\\335\\47":I
    nop

    .line 104
    .end local v1    # "$this$cache\\47":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$f$cache\\47\\104":I
    .end local v24    # "invalid\\47":Z
    move-object/from16 v55, v0

    check-cast v55, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v0, v11

    .end local v11    # "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    .local v0, "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    new-instance v11, Lorg/lighttouch/android/DevicesSheetKt$DeviceRow$1$3$4;

    move-object v1, v0

    move-object/from16 v16, v3

    move v2, v12

    move-object v3, v13

    move-object v0, v14

    const/4 v6, 0x1

    move-object/from16 v12, p5

    move-object/from16 v13, p6

    move-object/from16 v14, p7

    .end local v12    # "propagateMinConstraints\\36":Z
    .end local v13    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v14    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v0, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v1, "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    .local v2, "propagateMinConstraints\\36":Z
    .local v3, "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v16, "menu$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct/range {v11 .. v16}, Lorg/lighttouch/android/DevicesSheetKt$DeviceRow$1$3$4;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ZLandroidx/compose/runtime/MutableState;)V

    const/16 v5, 0x36

    const v12, 0x2d116eb4

    invoke-static {v12, v6, v11, v4, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object/from16 v67, v5

    check-cast v67, Lkotlin/jvm/functions/Function3;

    const/16 v70, 0x30

    const/16 v71, 0x7fc

    const/16 v56, 0x0

    const-wide/16 v57, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const-wide/16 v62, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v69, 0x30

    move-object/from16 v68, v4

    .end local v4    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v68, "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static/range {v54 .. v71}, Landroidx/compose/material3/AndroidMenu_androidKt;->DropdownMenu-IlH_yew(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/ScrollState;Landroidx/compose/ui/window/PopupProperties;Landroidx/compose/ui/graphics/Shape;JFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    .line 103
    .end local v68    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 111
    nop

    .line 328
    .end local v4    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .end local v8    # "$changed\\43":I
    .end local v30    # "$i$a$-Box-DevicesSheetKt$DeviceRow$1$3\\43\\328\\16":I
    .end local v50    # "$this$DeviceRow_u24lambda_u2425_u24lambda_u2424\\43":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 327
    .end local v7    # "$i$a$-Layout-BoxKt$Box$1\\42\\327\\36":I
    .end local v47    # "$changed\\42":I
    .end local v51    # "$composer\\42":Landroidx/compose/runtime/Composer;
    nop

    .line 341
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 306
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 342
    nop

    .line 300
    .end local v37    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .end local v38    # "$i$f$ReusableComposeNode\\38\\304":I
    .end local v39    # "$changed\\38":I
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 343
    nop

    .line 292
    .end local v33    # "$changed\\37":I
    .end local v34    # "$i$f$Layout\\37\\299":I
    .end local v40    # "materialized\\37":Landroidx/compose/ui/Modifier;
    .end local v48    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .end local p8    # "compositeKeyHash\\37":I
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 344
    nop

    .line 92
    .end local v1    # "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    .end local v2    # "propagateMinConstraints\\36":Z
    .end local v3    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v9    # "$i$f$Box\\36\\102":I
    .end local v35    # "$changed\\36":I
    .end local v36    # "modifier\\36":Landroidx/compose/ui/Modifier;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 112
    nop

    .line 210
    .end local v32    # "$this$DeviceRow_u24lambda_u2425\\16":Landroidx/compose/foundation/layout/RowScope;
    .end local v41    # "$i$a$-Row-DevicesSheetKt$DeviceRow$1\\16\\210\\0":I
    .end local v45    # "$changed\\16":I
    .end local v49    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 209
    .end local v31    # "$changed\\15":I
    .end local v43    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .end local v44    # "$i$a$-Layout-RowKt$Row$1\\15\\209\\9":I
    nop

    .line 345
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 188
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 346
    nop

    .line 182
    .end local v22    # "$i$f$ReusableComposeNode\\11\\186":I
    .end local v26    # "$changed\\11":I
    .end local v27    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 347
    nop

    .line 175
    .end local v0    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "$changed\\10":I
    .end local v18    # "$i$f$Layout\\10\\181":I
    .end local v20    # "compositeKeyHash\\10":I
    .end local v42    # "materialized\\10":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 348
    nop

    .line 113
    .end local v19    # "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .end local v21    # "$changed\\9":I
    .end local v25    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .end local v29    # "$i$f$Row\\9\\88":I
    .end local v46    # "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v53    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x4

    .local v1, "$this$dp\\50":I
    const/4 v2, 0x0

    .line 349
    .local v2, "$i$f$getDp\\50\\113":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 113
    .end local v1    # "$this$dp\\50":I
    .end local v2    # "$i$f$getDp\\50\\113":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v9, 0x6

    invoke-static {v0, v10, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v16    # "menu$delegate":Landroidx/compose/runtime/MutableState;
    :cond_2a
    :goto_21
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_2b

    new-instance v0, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda4;

    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move/from16 v9, p9

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 114
    :cond_2b
    return-void
.end method

.method private static final DeviceRow$lambda$16(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 87
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 387
    .local v3, "$i$f$getValue\\1\\87":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\87":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 87
    return v0
.end method

.method private static final DeviceRow$lambda$17(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 87
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 388
    .local v4, "$i$f$setValue\\1\\87":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 389
    nop

    .line 87
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\87":I
    return-void
.end method

.method private static final DeviceRow$lambda$25$lambda$24$lambda$21$lambda$20(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 103
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeviceRow$lambda$25$lambda$24$lambda$23$lambda$22(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 104
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeviceRow$lambda$26(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p8, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v10

    move-object v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move-object v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final DevicesSheet(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 31
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "host"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "onDismiss"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    const v2, -0x6d287d78

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(DevicesSheet)40@1759L49,41@1829L49,42@1961L11,43@2015L59,43@2124L2259,42@1883L2500,*75@4581L19,78@4940L241,80@5211L64,76@4689L110,75@4550L726:DevicesSheet.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, p3, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-nez v5, :cond_2

    and-int/lit8 v5, p3, 0x8

    if-nez v5, :cond_0

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    goto :goto_0

    :cond_0
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    :goto_0
    if-eqz v5, :cond_1

    move v5, v6

    goto :goto_1

    :cond_1
    move v5, v7

    :goto_1
    or-int/2addr v4, v5

    :cond_2
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_4

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    const/16 v5, 0x20

    goto :goto_2

    :cond_3
    const/16 v5, 0x10

    :goto_2
    or-int/2addr v4, v5

    :cond_4
    and-int/lit8 v5, v4, 0x13

    const/16 v8, 0x12

    if-ne v5, v8, :cond_6

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_3

    .line 75
    :cond_5
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v17, v3

    move/from16 v25, v4

    goto/16 :goto_e

    .line 40
    :cond_6
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_7

    const/4 v5, -0x1

    const-string v8, "org.lighttouch.android.DevicesSheet (DevicesSheet.kt:39)"

    invoke-static {v2, v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_7
    const v2, 0x6e3c21fe

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "CC(remember):DevicesSheet.kt#9igjgp"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 41
    const/16 v21, 0x0

    move/from16 v8, v21

    .local v8, "invalid\\1":Z
    move-object v9, v3

    .local v9, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 142
    .local v10, "$i$f$cache\\1\\41":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 143
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\142\\1":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    const/4 v14, 0x0

    if-ne v11, v13, :cond_8

    .line 144
    const/4 v13, 0x0

    .line 41
    .local v13, "$i$a$-cache-DevicesSheetKt$DevicesSheet$renaming$2\\3\\144\\0":I
    invoke-static {v14, v14, v7, v14}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v13

    .line 144
    .end local v13    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$renaming$2\\3\\144\\0":I
    nop

    .line 145
    .local v13, "value\\2":Ljava/lang/Object;
    invoke-interface {v9, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 146
    nop

    .end local v13    # "value\\2":Ljava/lang/Object;
    goto :goto_4

    .line 147
    :cond_8
    move-object v13, v11

    .line 143
    :goto_4
    nop

    .line 142
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\142\\1":I
    nop

    .line 41
    .end local v8    # "invalid\\1":Z
    .end local v9    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\1\\41":I
    move-object v8, v13

    check-cast v8, Landroidx/compose/runtime/MutableState;

    .local v8, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 42
    move-object v2, v3

    .local v2, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    move/from16 v9, v21

    .local v9, "invalid\\4":Z
    const/4 v10, 0x0

    .line 148
    .local v10, "$i$f$cache\\4\\42":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\4":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 149
    .local v12, "$i$a$-let-ComposerKt$cache$1\\5\\148\\4":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_9

    .line 150
    const/4 v13, 0x0

    .line 42
    .local v13, "$i$a$-cache-DevicesSheetKt$DevicesSheet$deleting$2\\6\\150\\0":I
    invoke-static {v14, v14, v7, v14}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v13

    .line 150
    .end local v13    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$deleting$2\\6\\150\\0":I
    nop

    .line 151
    .local v13, "value\\5":Ljava/lang/Object;
    invoke-interface {v2, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 152
    nop

    .end local v13    # "value\\5":Ljava/lang/Object;
    goto :goto_5

    .line 153
    :cond_9
    move-object v13, v11

    .line 149
    :goto_5
    nop

    .line 148
    .end local v11    # "it\\4":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\5\\148\\4":I
    nop

    .line 42
    .end local v2    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v9    # "invalid\\4":Z
    .end local v10    # "$i$f$cache\\4\\42":I
    move-object v2, v13

    check-cast v2, Landroidx/compose/runtime/MutableState;

    .local v2, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 43
    sget-object v9, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v9, v3, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v9

    invoke-virtual {v9}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerLow-0d7_KjU()J

    move-result-wide v9

    .line 44
    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-static {v11, v14, v3, v12, v7}, Landroidx/compose/material3/ModalBottomSheetKt;->rememberModalBottomSheetState(ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)Landroidx/compose/material3/SheetState;

    move-result-object v7

    invoke-static {}, Lorg/lighttouch/android/ShellKt;->getDialogTags()Landroidx/compose/ui/Modifier;

    move-result-object v12

    const-string v13, "devices_sheet"

    invoke-static {v12, v13}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 43
    nop

    .line 44
    nop

    .line 43
    nop

    .line 44
    new-instance v13, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;

    invoke-direct {v13, v0, v1, v8, v2}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$1;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v14, -0x2cca751b

    const/16 v15, 0x36

    invoke-static {v14, v11, v13, v3, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v13

    move-object/from16 v16, v13

    check-cast v16, Lkotlin/jvm/functions/Function3;

    shr-int/lit8 v13, v4, 0x3

    and-int/lit8 v13, v13, 0xe

    const/16 v14, 0x30

    or-int/lit8 v18, v13, 0x30

    .line 43
    move v13, v4

    .end local v4    # "$dirty":I
    .local v13, "$dirty":I
    const/4 v4, 0x0

    move-object/from16 v17, v5

    const/4 v5, 0x0

    move/from16 v19, v6

    move-object/from16 v20, v17

    move-object/from16 v17, v3

    move-object v3, v7

    move-wide v6, v9

    move-object v10, v8

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v8    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .local v10, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v8, 0x0

    move-object/from16 v22, v10

    .end local v10    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .local v22, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    const/4 v10, 0x0

    move-object/from16 v23, v2

    move/from16 v24, v11

    move-object v2, v12

    .end local v2    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v23, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v11, 0x0

    move/from16 v25, v13

    .end local v13    # "$dirty":I
    .local v25, "$dirty":I
    const/4 v13, 0x0

    move/from16 v26, v14

    const/4 v14, 0x0

    move/from16 v27, v15

    const/4 v15, 0x0

    move/from16 v28, v19

    const/16 v19, 0x180

    move-object/from16 v29, v20

    const/16 v20, 0xfd8

    move-object/from16 p2, v22

    move-object/from16 v26, v23

    move-object/from16 v0, v29

    .end local v22    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .end local v23    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v26, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local p2, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static/range {v1 .. v20}, Landroidx/compose/material3/ModalBottomSheetKt;->ModalBottomSheet-dYc4hso(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/material3/SheetState;FLandroidx/compose/ui/graphics/Shape;JJFJLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/material3/ModalBottomSheetProperties;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    .line 74
    move-object/from16 v2, v17

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {p2 .. p2}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$1(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/DeviceSummary;

    move-result-object v3

    const v4, 0x3b025c59

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "*73@4435L19,73@4456L53,73@4414L95"

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v4, 0x4c5de2

    if-nez v3, :cond_a

    move-object/from16 v6, p0

    move-object/from16 v13, p2

    goto/16 :goto_b

    .line 154
    .local v3, "device\\7":Lorg/lighttouch/android/DeviceSummary;
    :cond_a
    const/4 v5, 0x0

    .line 74
    .local v5, "$i$a$-let-DevicesSheetKt$DevicesSheet$2\\7\\74\\0":I
    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v6, 0x0

    .local v6, "invalid\\8":Z
    move-object v7, v2

    .local v7, "$this$cache\\8":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 155
    .local v8, "$i$f$cache\\8\\74":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\8":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 156
    .local v10, "$i$a$-let-ComposerKt$cache$1\\9\\155\\8":I
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v9, v11, :cond_b

    .line 157
    const/4 v11, 0x0

    .line 74
    .local v11, "$i$a$-cache-DevicesSheetKt$DevicesSheet$2$1\\10\\157\\7":I
    new-instance v12, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda7;

    move-object/from16 v13, p2

    .end local p2    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .local v13, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct {v12, v13}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda7;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 157
    .end local v11    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$2$1\\10\\157\\7":I
    nop

    .line 158
    .local v12, "value\\9":Ljava/lang/Object;
    invoke-interface {v7, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 159
    nop

    .end local v12    # "value\\9":Ljava/lang/Object;
    goto :goto_6

    .line 160
    .end local v13    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .restart local p2    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    :cond_b
    move-object/from16 v13, p2

    .end local p2    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v13    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    move-object v12, v9

    .line 156
    :goto_6
    nop

    .line 155
    .end local v9    # "it\\8":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\9\\155\\8":I
    nop

    .line 74
    .end local v6    # "invalid\\8":Z
    .end local v7    # "$this$cache\\8":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\8\\74":I
    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v6, -0x6815fd56

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v6, v25, 0xe

    const/4 v7, 0x4

    if-eq v6, v7, :cond_d

    and-int/lit8 v6, v25, 0x8

    if-eqz v6, :cond_c

    move-object/from16 v6, p0

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_e

    goto :goto_7

    :cond_c
    move-object/from16 v6, p0

    goto :goto_8

    :cond_d
    move-object/from16 v6, p0

    :goto_7
    const/16 v21, 0x1

    :cond_e
    :goto_8
    invoke-interface {v2, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    or-int v7, v21, v7

    .local v7, "invalid\\11":Z
    move-object v8, v2

    .local v8, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 155
    .local v9, "$i$f$cache\\11\\74":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\11":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 156
    .local v11, "$i$a$-let-ComposerKt$cache$1\\12\\155\\11":I
    if-nez v7, :cond_10

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v10, v14, :cond_f

    goto :goto_9

    .line 160
    :cond_f
    move-object v15, v10

    goto :goto_a

    .line 157
    :cond_10
    :goto_9
    const/4 v14, 0x0

    .line 74
    .local v14, "$i$a$-cache-DevicesSheetKt$DevicesSheet$2$2\\13\\157\\7":I
    new-instance v15, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda8;

    invoke-direct {v15, v6, v3, v13}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/DeviceSummary;Landroidx/compose/runtime/MutableState;)V

    .line 157
    .end local v14    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$2$2\\13\\157\\7":I
    nop

    .line 158
    .local v15, "value\\12":Ljava/lang/Object;
    invoke-interface {v8, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 159
    nop

    .line 156
    .end local v15    # "value\\12":Ljava/lang/Object;
    :goto_a
    nop

    .line 155
    .end local v10    # "it\\11":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\12\\155\\11":I
    nop

    .line 74
    .end local v7    # "invalid\\11":Z
    .end local v8    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\11\\74":I
    check-cast v15, Lkotlin/jvm/functions/Function1;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v7, 0x30

    invoke-static {v3, v12, v15, v2, v7}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    .end local v3    # "device\\7":Lorg/lighttouch/android/DeviceSummary;
    .end local v5    # "$i$a$-let-DevicesSheetKt$DevicesSheet$2\\7\\74\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_b
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 75
    invoke-static/range {v26 .. v26}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$4(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/DeviceSummary;

    move-result-object v3

    if-nez v3, :cond_11

    move-object/from16 v17, v2

    move-object v0, v6

    move-object/from16 v28, v13

    goto/16 :goto_d

    .local v3, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    :cond_11
    const/16 v27, 0x0

    .line 76
    .local v27, "$i$a$-let-DevicesSheetKt$DevicesSheet$3\\14\\75\\0":I
    invoke-static {}, Lorg/lighttouch/android/ShellKt;->getDialogTags()Landroidx/compose/ui/Modifier;

    move-result-object v5

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\15":Z
    move-object v4, v2

    .local v4, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 161
    .local v7, "$i$f$cache\\15\\76":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\15":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 162
    .local v9, "$i$a$-let-ComposerKt$cache$1\\16\\161\\15":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v8, v10, :cond_12

    .line 163
    const/4 v10, 0x0

    .line 76
    .local v10, "$i$a$-cache-DevicesSheetKt$DevicesSheet$3$1\\17\\163\\14":I
    new-instance v11, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda9;

    move-object/from16 v12, v26

    .end local v26    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v12, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct {v11, v12}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda9;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 163
    .end local v10    # "$i$a$-cache-DevicesSheetKt$DevicesSheet$3$1\\17\\163\\14":I
    nop

    .line 164
    .local v11, "value\\16":Ljava/lang/Object;
    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 165
    nop

    .end local v11    # "value\\16":Ljava/lang/Object;
    goto :goto_c

    .line 166
    .end local v12    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v26    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    :cond_12
    move-object/from16 v12, v26

    .end local v26    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v12    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    move-object v11, v8

    .line 162
    :goto_c
    nop

    .line 161
    .end local v8    # "it\\15":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\16\\161\\15":I
    nop

    .line 76
    .end local v0    # "invalid\\15":Z
    .end local v4    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\15\\76":I
    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 79
    new-instance v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$3$2;

    invoke-direct {v0, v6, v3, v12}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$3$2;-><init>(Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/DeviceSummary;Landroidx/compose/runtime/MutableState;)V

    const v4, -0x2170edbe

    const/16 v7, 0x36

    const/4 v8, 0x1

    invoke-static {v4, v8, v0, v2, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function2;

    .line 76
    nop

    .line 81
    new-instance v0, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$3$3;

    invoke-direct {v0, v12}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$3$3;-><init>(Landroidx/compose/runtime/MutableState;)V

    const v9, -0x7b086380

    invoke-static {v9, v8, v0, v2, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function2;

    sget-object v9, Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;

    invoke-virtual {v9}, Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;->getLambda$1479270815$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .line 77
    new-instance v10, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$3$4;

    invoke-direct {v10, v3}, Lorg/lighttouch/android/DevicesSheetKt$DevicesSheet$3$4;-><init>(Lorg/lighttouch/android/DeviceSummary;)V

    const v14, 0x2b6026be

    invoke-static {v14, v8, v10, v2, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    move-object v8, v7

    check-cast v8, Lkotlin/jvm/functions/Function2;

    sget-object v7, Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;

    invoke-virtual {v7}, Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;->getLambda$-23827491$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .line 76
    const/4 v10, 0x0

    move-object v14, v3

    move-object v3, v11

    move-object/from16 v23, v12

    .end local v3    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .end local v12    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v14, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .restart local v23    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v11, 0x0

    move-object/from16 v22, v13

    move-object v15, v14

    .end local v13    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .end local v14    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .local v15, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .restart local v22    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v13, 0x0

    move-object/from16 v17, v15

    .end local v15    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .local v17, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    const-wide/16 v15, 0x0

    move-object/from16 v19, v17

    .end local v17    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .local v19, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    const-wide/16 v17, 0x0

    move-object/from16 v20, v19

    .end local v19    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .local v20, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    const/16 v19, 0x0

    move-object/from16 v21, v20

    .end local v20    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .local v21, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    const/16 v20, 0x0

    move-object/from16 v24, v22

    .end local v22    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .local v24, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    const v22, 0x1b6db6

    move-object/from16 v26, v23

    .end local v23    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v26    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v23, 0x0

    move-object/from16 v28, v24

    .end local v24    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    .local v28, "renaming$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v24, 0x3f80

    move-object/from16 v30, v6

    move-object v6, v0

    move-object/from16 v0, v30

    move-object/from16 v30, v21

    move-object/from16 v21, v2

    move-object/from16 v2, v30

    move-object/from16 v30, v9

    move-object v9, v7

    move-object/from16 v7, v30

    .local v2, "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .local v21, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v24}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    .line 82
    move-object/from16 v17, v21

    .line 75
    .end local v2    # "device\\14":Lorg/lighttouch/android/DeviceSummary;
    .end local v21    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-let-DevicesSheetKt$DevicesSheet$3\\14\\75\\0":I
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    nop

    :goto_d
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v26    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v28    # "renaming$delegate":Landroidx/compose/runtime/MutableState;
    :cond_13
    :goto_e
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_14

    new-instance v3, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda10;

    move/from16 v4, p3

    invoke-direct {v3, v0, v1, v4}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_f

    :cond_14
    move/from16 v4, p3

    .line 83
    :goto_f
    return-void
.end method

.method private static final DevicesSheet$lambda$1(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/DeviceSummary;
    .locals 4
    .param p0, "$renaming$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;)",
            "Lorg/lighttouch/android/DeviceSummary;"
        }
    .end annotation

    .line 41
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 381
    .local v3, "$i$f$getValue\\1\\41":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\41":I
    check-cast v0, Lorg/lighttouch/android/DeviceSummary;

    .line 41
    return-object v0
.end method

.method private static final DevicesSheet$lambda$10$lambda$7$lambda$6(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$renaming$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 74
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$2(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DevicesSheet$lambda$10$lambda$9$lambda$8(Lorg/lighttouch/android/GuestHost;Lorg/lighttouch/android/DeviceSummary;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "$device"    # Lorg/lighttouch/android/DeviceSummary;
    .param p2, "$renaming$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    invoke-virtual {p1}, Lorg/lighttouch/android/DeviceSummary;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0, p3}, Lorg/lighttouch/android/GuestHost;->renameDevice(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {p2, v0}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$2(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DevicesSheet$lambda$13$lambda$12$lambda$11(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 76
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$5(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DevicesSheet$lambda$14(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DevicesSheet$lambda$2(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V
    .locals 4
    .param p0, "$renaming$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/DeviceSummary;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;",
            "Lorg/lighttouch/android/DeviceSummary;",
            ")V"
        }
    .end annotation

    .line 41
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 382
    .local v3, "$i$f$setValue\\1\\41":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 383
    nop

    .line 41
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\41":I
    return-void
.end method

.method private static final DevicesSheet$lambda$4(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/DeviceSummary;
    .locals 4
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;)",
            "Lorg/lighttouch/android/DeviceSummary;"
        }
    .end annotation

    .line 42
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 384
    .local v3, "$i$f$getValue\\1\\42":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\42":I
    check-cast v0, Lorg/lighttouch/android/DeviceSummary;

    .line 42
    return-object v0
.end method

.method private static final DevicesSheet$lambda$5(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V
    .locals 4
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/DeviceSummary;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;",
            "Lorg/lighttouch/android/DeviceSummary;",
            ")V"
        }
    .end annotation

    .line 42
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 385
    .local v3, "$i$f$setValue\\1\\42":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 386
    nop

    .line 42
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\42":I
    return-void
.end method

.method public static final RenameDialog(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .locals 27
    .param p0, "device"    # Lorg/lighttouch/android/DeviceSummary;
    .param p1, "onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p2, "onRename"    # Lkotlin/jvm/functions/Function1;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/DeviceSummary;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p4

    const-string v4, "device"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onDismiss"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onRename"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    const v4, -0x60a649d9

    move-object/from16 v5, p3

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    const-string v6, "C(RenameDialog)118@7843L90,119@7950L29,120@8005L24,120@7984L45,121@8045L58,126@8636L125,127@8787L54,123@8269L341,122@8108L734:DevicesSheet.kt#o13vsk"

    invoke-static {v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v6, p4

    .local v6, "$dirty":I
    and-int/lit8 v7, v3, 0x6

    const/4 v8, 0x2

    if-nez v7, :cond_1

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    move v7, v8

    :goto_0
    or-int/2addr v6, v7

    :cond_1
    and-int/lit8 v7, v3, 0x30

    if-nez v7, :cond_3

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    const/16 v7, 0x20

    goto :goto_1

    :cond_2
    const/16 v7, 0x10

    :goto_1
    or-int/2addr v6, v7

    :cond_3
    and-int/lit16 v7, v3, 0x180

    if-nez v7, :cond_5

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v7, 0x100

    goto :goto_2

    :cond_4
    const/16 v7, 0x80

    :goto_2
    or-int/2addr v6, v7

    :cond_5
    and-int/lit16 v7, v6, 0x93

    const/16 v10, 0x92

    if-ne v7, v10, :cond_7

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v7

    if-nez v7, :cond_6

    goto :goto_3

    .line 123
    :cond_6
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v19, v5

    move/from16 v24, v6

    goto/16 :goto_a

    .line 117
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_8

    const/4 v7, -0x1

    const-string v10, "org.lighttouch.android.RenameDialog (DevicesSheet.kt:116)"

    invoke-static {v4, v6, v7, v10}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_8
    const v4, 0x6e3c21fe

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "CC(remember):DevicesSheet.kt#9igjgp"

    invoke-static {v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 119
    move-object v10, v5

    .local v10, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    move v12, v11

    .local v12, "invalid\\1":Z
    const/4 v13, 0x0

    .line 350
    .local v13, "$i$f$cache\\1\\119":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\1":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 351
    .local v15, "$i$a$-let-ComposerKt$cache$1\\2\\350\\1":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v14, v9, :cond_9

    .line 352
    const/4 v9, 0x0

    .line 119
    .local v9, "$i$a$-cache-DevicesSheetKt$RenameDialog$name$2\\3\\352\\0":I
    new-instance v17, Landroidx/compose/ui/text/input/TextFieldValue;

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v18

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->length()I

    move-result v4

    invoke-static {v11, v4}, Landroidx/compose/ui/text/TextRangeKt;->TextRange(II)J

    move-result-wide v19

    const/16 v22, 0x4

    const/16 v23, 0x0

    const/16 v21, 0x0

    invoke-direct/range {v17 .. v23}, Landroidx/compose/ui/text/input/TextFieldValue;-><init>(Ljava/lang/String;JLandroidx/compose/ui/text/TextRange;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v4, v17

    move/from16 v17, v11

    const/4 v11, 0x0

    invoke-static {v4, v11, v8, v11}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 352
    .end local v9    # "$i$a$-cache-DevicesSheetKt$RenameDialog$name$2\\3\\352\\0":I
    nop

    .line 353
    .local v4, "value\\2":Ljava/lang/Object;
    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 354
    nop

    .end local v4    # "value\\2":Ljava/lang/Object;
    goto :goto_4

    .line 355
    :cond_9
    move/from16 v17, v11

    move-object v4, v14

    .line 351
    :goto_4
    nop

    .line 350
    .end local v14    # "it\\1":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\2\\350\\1":I
    nop

    .line 119
    .end local v10    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v12    # "invalid\\1":Z
    .end local v13    # "$i$f$cache\\1\\119":I
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .local v4, "name$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v8, 0x6e3c21fe

    invoke-interface {v5, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 120
    move-object v8, v5

    .local v8, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    move/from16 v9, v17

    .local v9, "invalid\\4":Z
    const/4 v10, 0x0

    .line 356
    .local v10, "$i$f$cache\\4\\120":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\4":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 357
    .local v12, "$i$a$-let-ComposerKt$cache$1\\5\\356\\4":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_a

    .line 358
    const/4 v13, 0x0

    .line 120
    .local v13, "$i$a$-cache-DevicesSheetKt$RenameDialog$focus$1\\6\\358\\0":I
    new-instance v14, Landroidx/compose/ui/focus/FocusRequester;

    invoke-direct {v14}, Landroidx/compose/ui/focus/FocusRequester;-><init>()V

    .line 358
    .end local v13    # "$i$a$-cache-DevicesSheetKt$RenameDialog$focus$1\\6\\358\\0":I
    nop

    .line 359
    .local v14, "value\\5":Ljava/lang/Object;
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 360
    nop

    .end local v14    # "value\\5":Ljava/lang/Object;
    goto :goto_5

    .line 361
    :cond_a
    move-object v14, v11

    .line 357
    :goto_5
    nop

    .line 356
    .end local v11    # "it\\4":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\5\\356\\4":I
    nop

    .line 120
    .end local v8    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v9    # "invalid\\4":Z
    .end local v10    # "$i$f$cache\\4\\120":I
    move-object v8, v14

    check-cast v8, Landroidx/compose/ui/focus/FocusRequester;

    .local v8, "focus":Landroidx/compose/ui/focus/FocusRequester;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 121
    sget-object v9, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const v10, 0x4c5de2

    invoke-interface {v5, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v10, 0x0

    .local v10, "invalid\\7":Z
    move-object v11, v5

    .local v11, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 362
    .local v12, "$i$f$cache\\7\\121":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\7":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 363
    .local v14, "$i$a$-let-ComposerKt$cache$1\\8\\362\\7":I
    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_b

    .line 364
    const/4 v15, 0x0

    .line 121
    .local v15, "$i$a$-cache-DevicesSheetKt$RenameDialog$1\\9\\364\\0":I
    new-instance v3, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$1$1;

    move/from16 v16, v10

    const/4 v10, 0x0

    .end local v10    # "invalid\\7":Z
    .local v16, "invalid\\7":Z
    invoke-direct {v3, v8, v10}, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$1$1;-><init>(Landroidx/compose/ui/focus/FocusRequester;Lkotlin/coroutines/Continuation;)V

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 364
    .end local v15    # "$i$a$-cache-DevicesSheetKt$RenameDialog$1\\9\\364\\0":I
    nop

    .line 365
    .local v3, "value\\8":Ljava/lang/Object;
    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 366
    nop

    .end local v3    # "value\\8":Ljava/lang/Object;
    goto :goto_6

    .line 367
    .end local v16    # "invalid\\7":Z
    .restart local v10    # "invalid\\7":Z
    :cond_b
    move/from16 v16, v10

    .end local v10    # "invalid\\7":Z
    .restart local v16    # "invalid\\7":Z
    move-object v3, v13

    .line 363
    :goto_6
    nop

    .line 362
    .end local v13    # "it\\7":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\8\\362\\7":I
    nop

    .line 121
    .end local v11    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\7\\121":I
    .end local v16    # "invalid\\7":Z
    check-cast v3, Lkotlin/jvm/functions/Function2;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v10, 0x6

    invoke-static {v9, v3, v5, v10}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    const v3, -0x615d173a

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v3, v6, 0x380

    const/4 v7, 0x1

    const/16 v9, 0x100

    if-ne v3, v9, :cond_c

    move v11, v7

    goto :goto_7

    :cond_c
    move/from16 v11, v17

    .line 122
    :goto_7
    nop

    .local v11, "invalid\\10":Z
    move-object v3, v5

    .local v3, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 368
    .local v9, "$i$f$cache\\10\\122":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\10":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 369
    .local v12, "$i$a$-let-ComposerKt$cache$1\\11\\368\\10":I
    if-nez v11, :cond_e

    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v10, v13, :cond_d

    goto :goto_8

    .line 373
    :cond_d
    move-object v14, v10

    goto :goto_9

    .line 370
    :cond_e
    :goto_8
    const/4 v13, 0x0

    .line 122
    .local v13, "$i$a$-cache-DevicesSheetKt$RenameDialog$save$1\\12\\370\\0":I
    new-instance v14, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda5;

    invoke-direct {v14, v2, v4}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda5;-><init>(Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;)V

    .line 370
    .end local v13    # "$i$a$-cache-DevicesSheetKt$RenameDialog$save$1\\12\\370\\0":I
    nop

    .line 371
    .local v14, "value\\11":Ljava/lang/Object;
    invoke-interface {v3, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 372
    nop

    .line 369
    .end local v14    # "value\\11":Ljava/lang/Object;
    :goto_9
    nop

    .line 368
    .end local v10    # "it\\10":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\11\\368\\10":I
    nop

    .line 122
    .end local v3    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\10\\122":I
    .end local v11    # "invalid\\10":Z
    move-object v3, v14

    check-cast v3, Lkotlin/jvm/functions/Function0;

    .local v3, "save":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 123
    invoke-static {}, Lorg/lighttouch/android/ShellKt;->getDialogTags()Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 127
    new-instance v10, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$2;

    invoke-direct {v10, v3, v4}, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$2;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    const v11, 0x4ed108df    # 1.7535098E9f

    const/16 v12, 0x36

    invoke-static {v11, v7, v10, v5, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v10

    check-cast v10, Lkotlin/jvm/functions/Function2;

    .line 123
    nop

    .line 128
    new-instance v11, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$3;

    invoke-direct {v11, v1}, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$3;-><init>(Lkotlin/jvm/functions/Function0;)V

    const v13, -0x2b65b8e3

    invoke-static {v13, v7, v11, v5, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v11

    check-cast v11, Lkotlin/jvm/functions/Function2;

    sget-object v13, Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;

    invoke-virtual {v13}, Lorg/lighttouch/android/ComposableSingletons$DevicesSheetKt;->getLambda$1516471643$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .line 124
    new-instance v14, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$4;

    invoke-direct {v14, v3, v8, v4}, Lorg/lighttouch/android/DevicesSheetKt$RenameDialog$4;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/focus/FocusRequester;Landroidx/compose/runtime/MutableState;)V

    const v15, -0x62b7db86

    invoke-static {v15, v7, v14, v5, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function2;

    shr-int/lit8 v12, v6, 0x3

    and-int/lit8 v12, v12, 0xe

    const v14, 0x1b0db0

    or-int v20, v12, v14

    .line 123
    move-object/from16 v19, v5

    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    move-object v12, v8

    .end local v8    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    .local v12, "focus":Landroidx/compose/ui/focus/FocusRequester;
    const/4 v8, 0x0

    move-object v14, v3

    move-object v3, v9

    move-object v2, v10

    .end local v3    # "save":Lkotlin/jvm/functions/Function0;
    .local v14, "save":Lkotlin/jvm/functions/Function0;
    const-wide/16 v9, 0x0

    move-object/from16 v16, v4

    move-object v4, v11

    move-object v15, v12

    .end local v4    # "name$delegate":Landroidx/compose/runtime/MutableState;
    .end local v12    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    .local v15, "focus":Landroidx/compose/ui/focus/FocusRequester;
    .local v16, "name$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v11, 0x0

    move/from16 v18, v6

    move-object v6, v13

    move-object/from16 v17, v14

    .end local v6    # "$dirty":I
    .end local v14    # "save":Lkotlin/jvm/functions/Function0;
    .local v17, "save":Lkotlin/jvm/functions/Function0;
    .local v18, "$dirty":I
    const-wide/16 v13, 0x0

    move-object/from16 v22, v15

    move-object/from16 v21, v16

    .end local v15    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    .end local v16    # "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v21, "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v22, "focus":Landroidx/compose/ui/focus/FocusRequester;
    const-wide/16 v15, 0x0

    move-object/from16 v23, v17

    .end local v17    # "save":Lkotlin/jvm/functions/Function0;
    .local v23, "save":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    move/from16 v24, v18

    .end local v18    # "$dirty":I
    .local v24, "$dirty":I
    const/16 v18, 0x0

    move-object/from16 v25, v21

    .end local v21    # "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v25, "name$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v21, 0x0

    move-object/from16 v26, v22

    .end local v22    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    .local v26, "focus":Landroidx/compose/ui/focus/FocusRequester;
    const/16 v22, 0x3f90

    invoke-static/range {v1 .. v22}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v23    # "save":Lkotlin/jvm/functions/Function0;
    .end local v25    # "name$delegate":Landroidx/compose/runtime/MutableState;
    .end local v26    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    :cond_f
    :goto_a
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_10

    new-instance v3, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda6;

    move-object/from16 v4, p2

    move/from16 v5, p4

    invoke-direct {v3, v0, v1, v4, v5}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_b

    :cond_10
    move-object/from16 v4, p2

    move/from16 v5, p4

    .line 129
    :goto_b
    return-void
.end method

.method private static final RenameDialog$lambda$28(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/text/input/TextFieldValue;
    .locals 4
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/text/input/TextFieldValue;",
            ">;)",
            "Landroidx/compose/ui/text/input/TextFieldValue;"
        }
    .end annotation

    .line 119
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 390
    .local v3, "$i$f$getValue\\1\\119":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\119":I
    check-cast v0, Landroidx/compose/ui/text/input/TextFieldValue;

    .line 119
    return-object v0
.end method

.method private static final RenameDialog$lambda$29(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/text/input/TextFieldValue;)V
    .locals 4
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Landroidx/compose/ui/text/input/TextFieldValue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Landroidx/compose/ui/text/input/TextFieldValue;",
            ">;",
            "Landroidx/compose/ui/text/input/TextFieldValue;",
            ")V"
        }
    .end annotation

    .line 119
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 391
    .local v3, "$i$f$setValue\\1\\119":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 392
    nop

    .line 119
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\119":I
    return-void
.end method

.method private static final RenameDialog$lambda$33$lambda$32(Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$onRename"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$name$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 122
    invoke-static {p1}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog$lambda$28(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/text/input/TextFieldValue;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/ui/text/input/TextFieldValue;->getText()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {p1}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog$lambda$28(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/text/input/TextFieldValue;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/ui/text/input/TextFieldValue;->getText()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final RenameDialog$lambda$34(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog(Lorg/lighttouch/android/DeviceSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SheetSystemBars(Landroidx/compose/runtime/Composer;I)V
    .locals 10
    .param p0, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p1, "$changed"    # I

    .line 133
    const v0, -0x7a3b8e2c

    invoke-interface {p0, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object p0

    const-string v1, "C(SheetSystemBars)133@9026L7,134@9115L11,135@9169L247,135@9158L258:DevicesSheet.kt#o13vsk"

    invoke-static {p0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez p1, :cond_1

    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 136
    :cond_0
    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_5

    .line 133
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SheetSystemBars (DevicesSheet.kt:132)"

    invoke-static {v0, p1, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 134
    :cond_2
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalView()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/CompositionLocal;

    .local v0, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v1, 0x0

    .local v1, "$changed\\1":I
    const/4 v2, 0x0

    .line 374
    .local v2, "$i$f$getCurrent\\1\\134":I
    const v3, 0x789c5f52

    const-string v4, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {p0, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p0, v0}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {p0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 134
    .end local v0    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v1    # "$changed\\1":I
    .end local v2    # "$i$f$getCurrent\\1\\134":I
    check-cast v3, Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroidx/compose/ui/window/DialogWindowProvider;

    if-eqz v1, :cond_3

    check-cast v0, Landroidx/compose/ui/window/DialogWindowProvider;

    goto :goto_1

    :cond_3
    const/4 v0, 0x0

    :goto_1
    if-eqz v0, :cond_a

    invoke-interface {v0}, Landroidx/compose/ui/window/DialogWindowProvider;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-nez v0, :cond_4

    goto/16 :goto_6

    .line 135
    .local v0, "window":Landroid/view/Window;
    :cond_4
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, p0, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v1

    invoke-static {v1, v2}, Lorg/lighttouch/android/HomeScreenKt;->luminance-8_81llA(J)F

    move-result v1

    const/high16 v2, 0x3f000000    # 0.5f

    cmpl-float v1, v1, v2

    const/4 v2, 0x0

    if-lez v1, :cond_5

    const/4 v1, 0x1

    goto :goto_2

    :cond_5
    move v1, v2

    .local v1, "light":Z
    :goto_2
    const v3, -0x615d173a

    invoke-interface {p0, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "CC(remember):DevicesSheet.kt#9igjgp"

    invoke-static {p0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {p0, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {p0, v1}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v4

    or-int/2addr v3, v4

    .line 136
    nop

    .local v3, "invalid\\2":Z
    move-object v4, p0

    .local v4, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 375
    .local v5, "$i$f$cache\\2\\136":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\2":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 376
    .local v7, "$i$a$-let-ComposerKt$cache$1\\3\\375\\2":I
    if-nez v3, :cond_7

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_6

    goto :goto_3

    .line 380
    :cond_6
    move-object v9, v6

    goto :goto_4

    .line 377
    :cond_7
    :goto_3
    const/4 v8, 0x0

    .line 136
    .local v8, "$i$a$-cache-DevicesSheetKt$SheetSystemBars$1\\4\\377\\0":I
    new-instance v9, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda1;

    invoke-direct {v9, v0, v1}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda1;-><init>(Landroid/view/Window;Z)V

    .line 377
    .end local v8    # "$i$a$-cache-DevicesSheetKt$SheetSystemBars$1\\4\\377\\0":I
    nop

    .line 378
    .local v9, "value\\3":Ljava/lang/Object;
    invoke-interface {v4, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 379
    nop

    .line 376
    .end local v9    # "value\\3":Ljava/lang/Object;
    :goto_4
    nop

    .line 375
    .end local v6    # "it\\2":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\3\\375\\2":I
    nop

    .line 136
    .end local v3    # "invalid\\2":Z
    .end local v4    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\2\\136":I
    check-cast v9, Lkotlin/jvm/functions/Function0;

    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v9, p0, v2}, Landroidx/compose/runtime/EffectsKt;->SideEffect(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "window":Landroid/view/Window;
    .end local v1    # "light":Z
    :cond_8
    :goto_5
    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_9

    new-instance v1, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda2;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda2;-><init>(I)V

    invoke-interface {v0, v1}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 140
    :cond_9
    return-void

    .line 134
    :cond_a
    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_b
    invoke-interface {p0}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_c

    new-instance v1, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda11;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/DevicesSheetKt$$ExternalSyntheticLambda11;-><init>(I)V

    invoke-interface {v0, v1}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_c
    return-void
.end method

.method private static final SheetSystemBars$lambda$35(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p1, v0}, Lorg/lighttouch/android/DevicesSheetKt;->SheetSystemBars(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SheetSystemBars$lambda$38$lambda$37(Landroid/view/Window;Z)Lkotlin/Unit;
    .locals 2
    .param p0, "$window"    # Landroid/view/Window;
    .param p1, "$light"    # Z

    .line 137
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/Window;->setNavigationBarContrastEnforced(Z)V

    .line 138
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-static {p0, v0}, Landroidx/core/view/WindowCompat;->getInsetsController(Landroid/view/Window;Landroid/view/View;)Landroidx/core/view/WindowInsetsControllerCompat;

    move-result-object v0

    .line 154
    .local v0, "$this$SheetSystemBars_u24lambda_u2438_u24lambda_u2437_u24lambda_u2436\\1":Landroidx/core/view/WindowInsetsControllerCompat;
    const/4 v1, 0x0

    .line 138
    .local v1, "$i$a$-run-DevicesSheetKt$SheetSystemBars$1$1$1\\1\\138\\0":I
    invoke-virtual {v0, p1}, Landroidx/core/view/WindowInsetsControllerCompat;->setAppearanceLightNavigationBars(Z)V

    invoke-virtual {v0, p1}, Landroidx/core/view/WindowInsetsControllerCompat;->setAppearanceLightStatusBars(Z)V

    .line 139
    .end local v0    # "$this$SheetSystemBars_u24lambda_u2438_u24lambda_u2437_u24lambda_u2436\\1":Landroidx/core/view/WindowInsetsControllerCompat;
    .end local v1    # "$i$a$-run-DevicesSheetKt$SheetSystemBars$1$1$1\\1\\138\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SheetSystemBars$lambda$39(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p1, v0}, Lorg/lighttouch/android/DevicesSheetKt;->SheetSystemBars(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$DeviceRow(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "device"    # Lorg/lighttouch/android/DeviceSummary;
    .param p1, "switchable"    # Z
    .param p2, "editable"    # Z
    .param p3, "needsRecovery"    # Z
    .param p4, "onSelect"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onDetails"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onRename"    # Lkotlin/jvm/functions/Function0;
    .param p7, "onDelete"    # Lkotlin/jvm/functions/Function0;
    .param p8, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p9}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow(Lorg/lighttouch/android/DeviceSummary;ZZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$DeviceRow$lambda$17(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->DeviceRow$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$DevicesSheet$lambda$2(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V
    .locals 0
    .param p0, "$renaming$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/DeviceSummary;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$2(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V

    return-void
.end method

.method public static final synthetic access$DevicesSheet$lambda$5(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V
    .locals 0
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/DeviceSummary;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->DevicesSheet$lambda$5(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/DeviceSummary;)V

    return-void
.end method

.method public static final synthetic access$RenameDialog$lambda$28(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/text/input/TextFieldValue;
    .locals 1
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog$lambda$28(Landroidx/compose/runtime/MutableState;)Landroidx/compose/ui/text/input/TextFieldValue;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$RenameDialog$lambda$29(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/text/input/TextFieldValue;)V
    .locals 0
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Landroidx/compose/ui/text/input/TextFieldValue;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->RenameDialog$lambda$29(Landroidx/compose/runtime/MutableState;Landroidx/compose/ui/text/input/TextFieldValue;)V

    return-void
.end method

.method public static final synthetic access$SheetSystemBars(Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p1, "$changed"    # I

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/DevicesSheetKt;->SheetSystemBars(Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

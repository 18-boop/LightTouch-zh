.class public final Lorg/lighttouch/android/ActiveDisplayOwner;
.super Ljava/lang/Object;
.source "DisplayOwnership.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDisplayOwnership.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DisplayOwnership.kt\norg/lighttouch/android/ActiveDisplayOwner\n+ 2 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,98:1\n384#2,7:99\n384#2,7:106\n1#3:113\n*S KotlinDebug\n*F\n+ 1 DisplayOwnership.kt\norg/lighttouch/android/ActiveDisplayOwner\n*L\n18#1:99,7\n20#1:106,7\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0007\u0008\u0001\u0018\u00002\u00020\u0001:\u0001\u0018B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0001H\u0002J\u0018\u0010\u000c\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u0006H\u0002J\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u000b\u001a\u00020\u0001J\u0016\u0010\u0010\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u0012J\u0016\u0010\u0013\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u0012J\u000e\u0010\u0014\u001a\u00020\u000f2\u0006\u0010\u000b\u001a\u00020\u0001J\u0016\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\n\u001a\u00020\tJ\u0016\u0010\u0016\u001a\u00020\u00122\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\n\u001a\u00020\tJ\u0016\u0010\u0017\u001a\u00020\u00122\u0006\u0010\u000b\u001a\u00020\u00012\u0006\u0010\n\u001a\u00020\tR\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0019"
    }
    d2 = {
        "Lorg/lighttouch/android/ActiveDisplayOwner;",
        "",
        "<init>",
        "()V",
        "visible",
        "Ljava/util/IdentityHashMap;",
        "Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;",
        "owner",
        "generation",
        "",
        "ticket",
        "value",
        "promote",
        "state",
        "started",
        "",
        "resumed",
        "actualFocus",
        "",
        "focusChanged",
        "paused",
        "owns",
        "canClaim",
        "stopped",
        "Visibility",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private generation:J

.field private owner:Ljava/lang/Object;

.field private final visible:Ljava/util/IdentityHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/IdentityHashMap<",
            "Ljava/lang/Object;",
            "Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/ActiveDisplayOwner;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance v0, Ljava/util/IdentityHashMap;

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    .line 6
    return-void
.end method

.method private final promote(Ljava/lang/Object;Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;)J
    .locals 4
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "state"    # Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;

    .line 13
    invoke-virtual {p2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->getStarted()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->getResumed()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->getFocused()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->owner:Ljava/lang/Object;

    if-eq v0, p1, :cond_2

    .line 14
    iget-wide v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->generation:J

    const-wide v2, 0x7fffffffffffffffL

    cmp-long v0, v0, v2

    if-gez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    iget-wide v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->generation:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->generation:J

    iput-object p1, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->owner:Ljava/lang/Object;

    goto :goto_1

    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "\u68c0\u67e5\u5931\u8d25\u3002"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 16
    :cond_2
    :goto_1
    invoke-direct {p0, p1}, Lorg/lighttouch/android/ActiveDisplayOwner;->ticket(Ljava/lang/Object;)J

    move-result-wide v0

    return-wide v0
.end method

.method private final ticket(Ljava/lang/Object;)J
    .locals 2
    .param p1, "value"    # Ljava/lang/Object;

    .line 11
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->owner:Ljava/lang/Object;

    if-ne v0, p1, :cond_0

    iget-wide v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->generation:J

    goto :goto_0

    :cond_0
    const-wide/16 v0, 0x0

    :goto_0
    return-wide v0
.end method


# virtual methods
.method public final declared-synchronized canClaim(Ljava/lang/Object;J)Z
    .locals 3
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "ticket"    # J

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    invoke-virtual {v0, p1}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    monitor-exit p0

    return v1

    .line 33
    .local v0, "state":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    :cond_0
    :try_start_1
    invoke-virtual {p0, p1, p2, p3}, Lorg/lighttouch/android/ActiveDisplayOwner;->owns(Ljava/lang/Object;J)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->getStarted()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->getResumed()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->getFocused()Z

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v2, :cond_1

    const/4 v1, 0x1

    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    :cond_1
    monitor-exit p0

    return v1

    .line 31
    .end local v0    # "state":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    .end local p1    # "value":Ljava/lang/Object;
    .end local p2    # "ticket":J
    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public final declared-synchronized focusChanged(Ljava/lang/Object;Z)J
    .locals 3
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "actualFocus"    # Z

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    invoke-virtual {v0, p1}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    monitor-exit p0

    const-wide/16 v0, 0x0

    return-wide v0

    .line 26
    .local v0, "state":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    :cond_0
    :try_start_1
    invoke-virtual {v0, p2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->setFocused(Z)V

    .line 27
    invoke-direct {p0, p1, v0}, Lorg/lighttouch/android/ActiveDisplayOwner;->promote(Ljava/lang/Object;Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;)J

    move-result-wide v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-wide v1

    .line 24
    .end local v0    # "state":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    .end local p1    # "value":Ljava/lang/Object;
    .end local p2    # "actualFocus":Z
    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public final declared-synchronized owns(Ljava/lang/Object;J)Z
    .locals 2
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "ticket"    # J

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-lez v0, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->owner:Ljava/lang/Object;

    if-ne v0, p1, :cond_0

    iget-wide v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->generation:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    cmp-long v0, p2, v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    :cond_0
    const/4 v0, 0x0

    :goto_0
    monitor-exit p0

    return v0

    .line 30
    .end local p1    # "value":Ljava/lang/Object;
    .end local p2    # "ticket":J
    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized paused(Ljava/lang/Object;)V
    .locals 3
    .param p1, "value"    # Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    invoke-virtual {v0, p1}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;

    if-eqz v0, :cond_0

    .line 113
    .local v0, "it\\1":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    const/4 v1, 0x0

    .line 29
    .local v1, "$i$a$-let-ActiveDisplayOwner$paused$1\\1\\29\\0":I
    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->setResumed(Z)V

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->setFocused(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v0    # "it\\1":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    .end local v1    # "$i$a$-let-ActiveDisplayOwner$paused$1\\1\\29\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    :cond_0
    monitor-exit p0

    return-void

    .line 28
    .end local p1    # "value":Ljava/lang/Object;
    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized resumed(Ljava/lang/Object;Z)J
    .locals 10
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "actualFocus"    # Z

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    check-cast v0, Ljava/util/Map;

    .local v0, "$this$getOrPut\\1":Ljava/util/Map;
    const/4 v1, 0x0

    .line 106
    .local v1, "$i$f$getOrPut\\1\\20":I
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 107
    .local v2, "value\\1":Ljava/lang/Object;
    if-nez v2, :cond_0

    .line 108
    const/4 v3, 0x0

    .line 20
    .local v3, "$i$a$-getOrPut-ActiveDisplayOwner$resumed$state$1\\2\\108\\0":I
    new-instance v4, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v4 .. v9}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;-><init>(ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 108
    .end local v3    # "$i$a$-getOrPut-ActiveDisplayOwner$resumed$state$1\\2\\108\\0":I
    nop

    .line 109
    .local v4, "answer\\1":Ljava/lang/Object;
    invoke-interface {v0, p1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 110
    nop

    .end local v4    # "answer\\1":Ljava/lang/Object;
    goto :goto_0

    .line 112
    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    :cond_0
    move-object v4, v2

    .line 107
    :goto_0
    nop

    .line 20
    .end local v0    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v1    # "$i$f$getOrPut\\1\\20":I
    .end local v2    # "value\\1":Ljava/lang/Object;
    check-cast v4, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;

    .line 21
    .local v4, "state":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    const/4 v0, 0x1

    invoke-virtual {v4, v0}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->setResumed(Z)V

    invoke-virtual {v4, p2}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->setFocused(Z)V

    .line 22
    invoke-direct {p0, p1, v4}, Lorg/lighttouch/android/ActiveDisplayOwner;->promote(Ljava/lang/Object;Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;)J

    move-result-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-wide v0

    .line 19
    .end local v4    # "state":Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;
    .end local p1    # "value":Ljava/lang/Object;
    .end local p2    # "actualFocus":Z
    :catchall_0
    move-exception v0

    move-object p1, v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized started(Ljava/lang/Object;)V
    .locals 10
    .param p1, "value"    # Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    check-cast v0, Ljava/util/Map;

    .local v0, "$this$getOrPut\\1":Ljava/util/Map;
    const/4 v1, 0x0

    .line 99
    .local v1, "$i$f$getOrPut\\1\\18":I
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 100
    .local v2, "value\\1":Ljava/lang/Object;
    if-nez v2, :cond_0

    .line 101
    const/4 v3, 0x0

    .line 18
    .local v3, "$i$a$-getOrPut-ActiveDisplayOwner$started$1\\2\\101\\0":I
    new-instance v4, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v4 .. v9}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;-><init>(ZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 101
    .end local v3    # "$i$a$-getOrPut-ActiveDisplayOwner$started$1\\2\\101\\0":I
    nop

    .line 102
    .local v4, "answer\\1":Ljava/lang/Object;
    invoke-interface {v0, p1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 103
    nop

    .end local v4    # "answer\\1":Ljava/lang/Object;
    goto :goto_0

    .line 105
    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    :cond_0
    move-object v4, v2

    .line 100
    :goto_0
    nop

    .end local v0    # "$this$getOrPut\\1":Ljava/util/Map;
    .end local v1    # "$i$f$getOrPut\\1\\18":I
    .end local v2    # "value\\1":Ljava/lang/Object;
    check-cast v4, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;

    .line 18
    const/4 v0, 0x1

    invoke-virtual {v4, v0}, Lorg/lighttouch/android/ActiveDisplayOwner$Visibility;->setStarted(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    .line 17
    .end local p1    # "value":Ljava/lang/Object;
    :catchall_0
    move-exception v0

    move-object p1, v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized stopped(Ljava/lang/Object;J)Z
    .locals 1
    .param p1, "value"    # Ljava/lang/Object;
    .param p2, "ticket"    # J

    monitor-enter p0

    :try_start_0
    const-string v0, "value"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    iget-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->visible:Ljava/util/IdentityHashMap;

    invoke-virtual {v0, p1}, Ljava/util/IdentityHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    invoke-virtual {p0, p1, p2, p3}, Lorg/lighttouch/android/ActiveDisplayOwner;->owns(Ljava/lang/Object;J)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    monitor-exit p0

    const/4 v0, 0x0

    return v0

    .line 38
    :cond_0
    const/4 v0, 0x0

    :try_start_1
    iput-object v0, p0, Lorg/lighttouch/android/ActiveDisplayOwner;->owner:Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 39
    monitor-exit p0

    const/4 v0, 0x1

    return v0

    .line 35
    .end local p0    # "this":Lorg/lighttouch/android/ActiveDisplayOwner;
    .end local p1    # "value":Ljava/lang/Object;
    .end local p2    # "ticket":J
    :catchall_0
    move-exception p1

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

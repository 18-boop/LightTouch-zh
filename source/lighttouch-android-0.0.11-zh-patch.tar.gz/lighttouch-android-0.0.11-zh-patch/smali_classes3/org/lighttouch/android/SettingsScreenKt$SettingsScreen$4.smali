.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt;->SettingsScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4\n+ 2 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 3 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 4 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 5 Composer.kt\nandroidx/compose/runtime/Updater\n+ 6 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 7 Row.kt\nandroidx/compose/foundation/layout/RowKt\n*L\n1#1,196:1\n86#2:197\n83#2,6:198\n89#2:232\n86#2:275\n83#2,6:276\n89#2:310\n93#2:315\n93#2:319\n79#3,6:204\n86#3,4:219\n90#3,2:229\n79#3,6:241\n86#3,4:256\n90#3,2:266\n94#3:272\n79#3,6:282\n86#3,4:297\n90#3,2:307\n94#3:314\n94#3:318\n368#4,9:210\n377#4:231\n368#4,9:247\n377#4:268\n378#4,2:270\n368#4,9:288\n377#4:309\n378#4,2:312\n378#4,2:316\n4034#5,6:223\n4034#5,6:260\n4034#5,6:301\n149#6:233\n149#6:274\n149#6:311\n99#7:234\n96#7,6:235\n102#7:269\n106#7:273\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4\n*L\n44#1:197\n44#1:198,6\n44#1:232\n49#1:275\n49#1:276,6\n49#1:310\n49#1:315\n44#1:319\n44#1:204,6\n44#1:219,4\n44#1:229,2\n45#1:241,6\n45#1:256,4\n45#1:266,2\n45#1:272\n49#1:282,6\n49#1:297,4\n49#1:307,2\n49#1:314\n44#1:318\n44#1:210,9\n44#1:231\n45#1:247,9\n45#1:268\n45#1:270,2\n49#1:288,9\n49#1:309\n49#1:312,2\n44#1:316,2\n44#1:223,6\n45#1:260,6\n49#1:301,6\n45#1:233\n49#1:274\n111#1:311\n45#1:234\n45#1:235,6\n45#1:269\n45#1:273\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $context:Landroid/content/Context;

.field final synthetic $headphonesInfo$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $onBack:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method constructor <init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/MutableState;Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lorg/lighttouch/android/AppSettings;",
            "Lorg/lighttouch/android/GuestHost;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$onBack:Lkotlin/jvm/functions/Function0;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$s:Lorg/lighttouch/android/AppSettings;

    iput-object p3, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$host:Lorg/lighttouch/android/GuestHost;

    iput-object p4, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$headphonesInfo$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$context:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;

    .line 43
    move-object v0, p1

    check-cast v0, Landroidx/compose/runtime/Composer;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/runtime/Composer;I)V
    .locals 90
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    const-string v3, "C43@2590L11,43@2527L7957:SettingsScreen.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 319
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_a

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.SettingsScreen.<anonymous> (SettingsScreen.kt:43)"

    const v6, -0x7c151837

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 44
    :cond_2
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v3, v5, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v8, Landroidx/compose/foundation/layout/WindowInsets;->Companion:Landroidx/compose/foundation/layout/WindowInsets$Companion;

    const/4 v9, 0x6

    invoke-static {v8, v1, v9}, Landroidx/compose/foundation/layout/WindowInsets_androidKt;->getSafeDrawing(Landroidx/compose/foundation/layout/WindowInsets$Companion;Landroidx/compose/runtime/Composer;I)Landroidx/compose/foundation/layout/WindowInsets;

    move-result-object v8

    invoke-static {v3, v8}, Landroidx/compose/foundation/layout/WindowInsetsPaddingKt;->windowInsetsPadding(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/WindowInsets;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\1":Landroidx/compose/ui/Modifier;
    iget-object v10, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$onBack:Lkotlin/jvm/functions/Function0;

    iget-object v8, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$s:Lorg/lighttouch/android/AppSettings;

    iget-object v11, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$host:Lorg/lighttouch/android/GuestHost;

    iget-object v12, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$headphonesInfo$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v13, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->$context:Landroid/content/Context;

    const/16 v19, 0x0

    .local v19, "$changed\\1":I
    const/16 v20, 0x0

    .line 197
    .local v20, "$i$f$Column\\1\\44":I
    const v14, -0x1cd0f17e

    const-string v15, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v1, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 198
    sget-object v16, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move/from16 v21, v9

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 199
    .local v9, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move-object/from16 v17, v12

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v12

    .line 202
    .local v12, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v19, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v18, v19, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v14, v16, v18

    invoke-static {v9, v12, v1, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v19, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 203
    move/from16 v23, v16

    .local v23, "$changed\\2":I
    const/16 v24, 0x0

    .line 204
    .local v24, "$i$f$Layout\\2\\203":I
    move-object/from16 v16, v12

    .end local v12    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v16, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    const v12, -0x4ee9b9da

    move-object/from16 v18, v13

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 205
    const/4 v12, 0x0

    invoke-static {v1, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v26

    .line 206
    .local v26, "compositeKeyHash\\2":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 207
    .local v12, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 209
    .local v4, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v29

    shl-int/lit8 v5, v23, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 208
    move-object/from16 v31, v29

    .local v5, "$changed\\3":I
    .local v31, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v29, 0x0

    .line 210
    .local v29, "$i$f$ReusableComposeNode\\3\\208":I
    const v6, -0x2942ffcf

    const-string v7, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 211
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 212
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 213
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_4

    .line 214
    move-object/from16 v6, v31

    .end local v31    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v6, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 216
    .end local v6    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v31    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v6, v31

    .end local v31    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 218
    :goto_1
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 219
    .local v31, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\218\\2":I
    sget-object v34, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v34 .. v34}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 220
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 222
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v34, 0x0

    .line 223
    .local v34, "$i$f$set-impl\\5\\222":I
    move-object/from16 v35, v0

    .local v35, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 224
    .local v36, "$i$a$-with-Updater$set$1\\6\\223\\5":I
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v37

    if-nez v37, :cond_6

    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v37, v3

    .end local v3    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v37, "modifier\\1":Landroidx/compose/ui/Modifier;
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v3, v35

    goto :goto_3

    .end local v37    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .restart local v3    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :cond_6
    move-object/from16 v37, v3

    .line 225
    .end local v3    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .restart local v37    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :goto_2
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v35

    .end local v35    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 226
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 228
    :goto_3
    nop

    .line 223
    .end local v3    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-with-Updater$set$1\\6\\223\\5":I
    nop

    .line 228
    nop

    .line 229
    .end local v1    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v34    # "$i$f$set-impl\\5\\222":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v4, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 230
    nop

    .line 218
    .end local v0    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\218\\2":I
    nop

    .line 231
    shr-int/lit8 v0, v5, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object/from16 v1, p1

    .local v1, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 232
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\7\\231\\1":I
    const v3, -0x16ef5699

    move-object/from16 v31, v12

    .end local v12    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v31, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    const-string v12, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v34, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v35, v19, 0x6

    and-int/lit8 v35, v35, 0x70

    or-int/lit8 v35, v35, 0x6

    .local v35, "$changed\\8":I
    check-cast v34, Landroidx/compose/foundation/layout/ColumnScope;

    .local v34, "$this$invoke_u24lambda_u242\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v36, v1

    .local v36, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 45
    .local v38, "$i$a$-Column-SettingsScreenKt$SettingsScreen$4$1\\8\\232\\0":I
    const v3, -0x55047560

    move/from16 v40, v0

    .end local v0    # "$changed\\7":I
    .local v40, "$changed\\7":I
    const-string v0, "C44@2618L356,48@3032L21,48@2987L7487:SettingsScreen.kt#o13vsk"

    move-object/from16 v41, v12

    move-object/from16 v12, v36

    .end local v36    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v12, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v12, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    move/from16 v42, v2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    .end local v1    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$a$-Layout-ColumnKt$Column$1\\7\\231\\1":I
    .local v36, "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v42, "$i$a$-Layout-ColumnKt$Column$1\\7\\231\\1":I
    invoke-static {v0, v1, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x40

    .local v1, "$this$dp\\9":I
    const/4 v2, 0x0

    .line 233
    .local v2, "$i$f$getDp\\9\\45":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 45
    .end local v1    # "$this$dp\\9":I
    .end local v2    # "$i$f$getDp\\9\\45":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x4

    .local v1, "$this$dp\\10":I
    const/4 v2, 0x0

    .line 233
    .local v2, "$i$f$getDp\\10\\45":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 45
    .end local v1    # "$this$dp\\10":I
    .end local v2    # "$i$f$getDp\\10\\45":I
    move-object/from16 v43, v4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    .end local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v43, "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v0, v1, v2, v4, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v1

    .local v1, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v2, 0x186

    .local v2, "$changed\\11":I
    const/4 v3, 0x0

    .line 234
    .local v3, "$i$f$Row\\11\\45":I
    const v4, 0x2952b718

    move/from16 v44, v2

    .end local v2    # "$changed\\11":I
    .local v44, "$changed\\11":I
    const-string v2, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v12, v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 235
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v2

    .line 239
    .local v2, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v4, v44, 0x3

    and-int/lit8 v4, v4, 0xe

    shr-int/lit8 v45, v44, 0x3

    and-int/lit8 v45, v45, 0x70

    or-int v4, v4, v45

    invoke-static {v2, v1, v12, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v45, v44, 0x3

    and-int/lit8 v45, v45, 0x70

    .line 240
    nop

    .local v45, "$changed\\12":I
    const/16 v46, 0x0

    .line 241
    .local v46, "$i$f$Layout\\12\\240":I
    move-object/from16 v47, v1

    const v1, -0x4ee9b9da

    .end local v1    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v47, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v12, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 242
    const/4 v1, 0x0

    invoke-static {v12, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v27

    .line 243
    .local v27, "compositeKeyHash\\12":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 244
    .local v1, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v49, v13

    invoke-static {v12, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 246
    .local v13, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v50, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v50 .. v50}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v50

    move-object/from16 v51, v0

    .end local v0    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v51, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v45, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 245
    nop

    .local v0, "$changed\\13":I
    move-object/from16 v52, v50

    .local v52, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v50, 0x0

    .line 247
    .local v50, "$i$f$ReusableComposeNode\\13\\245":I
    move/from16 v53, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\13":I
    .local v53, "$changed\\13":I
    invoke-static {v12, v0, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 248
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 249
    :cond_7
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 250
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_8

    .line 251
    move-object/from16 v0, v52

    .end local v52    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 253
    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v52    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v0, v52

    .end local v52    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 255
    :goto_4
    move-object/from16 v52, v0

    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v52    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 256
    .local v54, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\255\\12":I
    sget-object v55, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v56, v2

    .end local v2    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v56, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {v55 .. v55}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v4, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 257
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 259
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v55, 0x0

    .line 260
    .local v55, "$i$f$set-impl\\15\\259":I
    move-object/from16 v57, v0

    .local v57, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 261
    .local v58, "$i$a$-with-Updater$set$1\\16\\260\\15":I
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v59

    if-nez v59, :cond_a

    move-object/from16 v59, v1

    .end local v1    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v59, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v60, v3

    .end local v3    # "$i$f$Row\\11\\45":I
    .local v60, "$i$f$Row\\11\\45":I
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    goto :goto_5

    :cond_9
    move-object/from16 v3, v57

    goto :goto_6

    .end local v59    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v60    # "$i$f$Row\\11\\45":I
    .restart local v1    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "$i$f$Row\\11\\45":I
    :cond_a
    move-object/from16 v59, v1

    move/from16 v60, v3

    .line 262
    .end local v1    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "$i$f$Row\\11\\45":I
    .restart local v59    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v60    # "$i$f$Row\\11\\45":I
    :goto_5
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v3, v57

    .end local v57    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 263
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 265
    :goto_6
    nop

    .line 260
    .end local v3    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v58    # "$i$a$-with-Updater$set$1\\16\\260\\15":I
    nop

    .line 265
    nop

    .line 266
    .end local v2    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v55    # "$i$f$set-impl\\15\\259":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 267
    nop

    .line 255
    .end local v0    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\255\\12":I
    nop

    .line 268
    shr-int/lit8 v0, v53, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\17":I
    move-object v1, v12

    .local v1, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 269
    .local v2, "$i$a$-Layout-RowKt$Row$1\\17\\268\\11":I
    const v3, -0x184f2606

    move/from16 v54, v0

    .end local v0    # "$changed\\17":I
    .local v54, "$changed\\17":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v3, v44, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\18":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$invoke_u24lambda_u242_u24lambda_u240\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v82, v1

    .local v82, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 46
    .local v55, "$i$a$-Row-SettingsScreenKt$SettingsScreen$4$1$1\\18\\269\\8":I
    move-object/from16 v57, v0

    .end local v0    # "$this$invoke_u24lambda_u242_u24lambda_u240\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v57, "$this$invoke_u24lambda_u242_u24lambda_u240\\18":Landroidx/compose/foundation/layout/RowScope;
    const v0, 0x58178226

    move-object/from16 v58, v1

    .end local v1    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v58, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v1, "C45@2754L128,46@2938L10,46@2899L61:SettingsScreen.kt#o13vsk"

    move/from16 v86, v2

    move-object/from16 v2, v82

    .end local v82    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v86, "$i$a$-Layout-RowKt$Row$1\\17\\268\\11":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v1, "settings_back"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$SettingsScreenKt;->getLambda$-697468110$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    move-object/from16 v61, v17

    const v17, 0x30030

    move-object/from16 v62, v18

    const/16 v18, 0x1c

    move-object/from16 v63, v12

    .end local v12    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v63, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    move-object/from16 v64, v13

    .end local v13    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .local v64, "materialized\\12":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    move-object/from16 v65, v14

    .end local v14    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v65, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v14, 0x0

    move-object/from16 v22, v11

    move-object v11, v0

    move-object/from16 v0, v22

    move-object/from16 v87, v4

    move/from16 v88, v5

    move-object v4, v15

    move-object/from16 v22, v16

    move-object/from16 v89, v49

    move-object/from16 v48, v64

    move-object/from16 v25, v65

    const/4 v5, 0x0

    move-object v15, v1

    move-object/from16 v16, v2

    move/from16 v49, v3

    move-object/from16 v3, v41

    move-object/from16 v1, v61

    move-object/from16 v2, v62

    move-object/from16 v41, v63

    .end local v2    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v3    # "$changed\\18":I
    .end local v4    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v5    # "$changed\\3":I
    .end local v63    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v64    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v65    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v16, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v22, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v25, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v41, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v48, "materialized\\12":Landroidx/compose/ui/Modifier;
    .local v49, "$changed\\18":I
    .local v87, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v88, "$changed\\3":I
    invoke-static/range {v10 .. v18}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 47
    move-object/from16 v11, v16

    .end local v16    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\18":Landroidx/compose/runtime/Composer;
    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v81

    const/16 v84, 0x0

    const v85, 0xfffe

    const-string v61, "\u8bbe\u7f6e"

    const/16 v62, 0x0

    const-wide/16 v63, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const-wide/16 v70, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const-wide/16 v74, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const/16 v83, 0x6

    move-object/from16 v82, v11

    .end local v11    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v82    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v61 .. v85}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 46
    move-object/from16 v16, v82

    .end local v82    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v16    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 48
    nop

    .line 269
    .end local v16    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v49    # "$changed\\18":I
    .end local v55    # "$i$a$-Row-SettingsScreenKt$SettingsScreen$4$1$1\\18\\269\\8":I
    .end local v57    # "$this$invoke_u24lambda_u242_u24lambda_u240\\18":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 268
    .end local v54    # "$changed\\17":I
    .end local v58    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v86    # "$i$a$-Layout-RowKt$Row$1\\17\\268\\11":I
    nop

    .line 270
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 247
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 271
    nop

    .line 241
    .end local v50    # "$i$f$ReusableComposeNode\\13\\245":I
    .end local v52    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .end local v53    # "$changed\\13":I
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 272
    nop

    .line 234
    .end local v27    # "compositeKeyHash\\12":I
    .end local v45    # "$changed\\12":I
    .end local v46    # "$i$f$Layout\\12\\240":I
    .end local v48    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v59    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 273
    nop

    .line 49
    .end local v44    # "$changed\\11":I
    .end local v47    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v51    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v56    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v60    # "$i$f$Row\\11\\45":I
    .end local v87    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-static {v11, v13, v14, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v44

    move-object/from16 v12, v41

    .end local v41    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v12, v5, v14}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v45

    const/16 v49, 0xe

    const/16 v50, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    invoke-static/range {v44 .. v50}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/16 v13, 0x10

    .local v13, "$this$dp\\19":I
    const/4 v14, 0x0

    .line 274
    .local v14, "$i$f$getDp\\19\\49":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 49
    .end local v13    # "$this$dp\\19":I
    .end local v14    # "$i$f$getDp\\19\\49":I
    const/4 v5, 0x2

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static {v11, v13, v15, v5, v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const-string v11, "settings"

    invoke-static {v5, v11}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\20":Landroidx/compose/ui/Modifier;
    const/4 v11, 0x0

    .local v11, "$changed\\20":I
    const/4 v13, 0x0

    .line 275
    .local v13, "$i$f$Column\\20\\49":I
    const v14, -0x1cd0f17e

    invoke-static {v12, v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 276
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 277
    .local v4, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v14, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v14

    .line 280
    .local v14, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v15, v11, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v16, v11, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v15, v15, v16

    invoke-static {v4, v14, v12, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v11, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 281
    nop

    .local v16, "$changed\\21":I
    const/16 v17, 0x0

    .line 282
    .local v17, "$i$f$Layout\\21\\281":I
    move-object/from16 v18, v4

    move-object/from16 v28, v6

    move-object/from16 v4, v89

    const v6, -0x4ee9b9da

    .end local v4    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v6    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v18, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v28, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static {v12, v6, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 283
    const/4 v4, 0x0

    invoke-static {v12, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v4

    .line 284
    .local v4, "compositeKeyHash\\21":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v6

    .line 285
    .local v6, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v27, v4

    .end local v4    # "compositeKeyHash\\21":I
    .local v27, "compositeKeyHash\\21":I
    invoke-static {v12, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 287
    .local v4, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v30

    move-object/from16 v32, v5

    .end local v5    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v32, "modifier\\20":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v16, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 286
    nop

    .local v5, "$changed\\22":I
    move-object/from16 v41, v30

    .local v41, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v30, 0x0

    .line 288
    .local v30, "$i$f$ReusableComposeNode\\22\\286":I
    move/from16 v44, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\22":I
    .local v44, "$changed\\22":I
    invoke-static {v12, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 289
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 290
    :cond_b
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 291
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_c

    .line 292
    move-object/from16 v5, v41

    .end local v41    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_7

    .line 294
    .end local v5    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v41    # "factory\\22":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v5, v41

    .end local v41    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 296
    :goto_7
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 297
    .local v33, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\296\\21":I
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v45, v5

    .end local v5    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v45, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v7, v15, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 298
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v7, v6, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 300
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v41, 0x0

    .line 301
    .local v41, "$i$f$set-impl\\24\\300":I
    move-object/from16 v46, v7

    .local v46, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 302
    .local v47, "$i$a$-with-Updater$set$1\\25\\301\\24":I
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v48

    if-nez v48, :cond_e

    move-object/from16 v48, v6

    .end local v6    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v48, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v49, v9

    .end local v9    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v49, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v6, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_d

    goto :goto_8

    :cond_d
    move-object/from16 v9, v46

    goto :goto_9

    .end local v48    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v49    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v6    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_e
    move-object/from16 v48, v6

    move-object/from16 v49, v9

    .line 303
    .end local v6    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v48    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v49    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_8
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v9, v46

    .end local v46    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 304
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v7, v6, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 306
    :goto_9
    nop

    .line 301
    .end local v9    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v47    # "$i$a$-with-Updater$set$1\\25\\301\\24":I
    nop

    .line 306
    nop

    .line 307
    .end local v5    # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v41    # "$i$f$set-impl\\24\\300":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v7, v4, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 308
    nop

    .line 296
    .end local v7    # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\296\\21":I
    nop

    .line 309
    shr-int/lit8 v5, v44, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\26":I
    move-object v6, v12

    .local v6, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 310
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\26\\309\\20":I
    const v9, -0x16ef5699

    invoke-static {v6, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v11, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\27":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$invoke_u24lambda_u242_u24lambda_u241\\27":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v33, v6

    .local v33, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 50
    .local v39, "$i$a$-Column-SettingsScreenKt$SettingsScreen$4$1$2\\27\\310\\8":I
    move-object/from16 v41, v3

    .end local v3    # "$this$invoke_u24lambda_u242_u24lambda_u241\\27":Landroidx/compose/foundation/layout/ColumnScope;
    .local v41, "$this$invoke_u24lambda_u242_u24lambda_u241\\27":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, -0x11face24

    move-object/from16 v46, v4

    .end local v4    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v46, "materialized\\21":Landroidx/compose/ui/Modifier;
    const-string v4, "C49@3140L568,49@3122L586,54@3740L758,54@3725L773,60@4532L690,60@4515L707,66@5260L353,66@5239L374,73@6090L1070,73@6061L1099,86@7198L2067,86@7177L2088,97@9298L577,97@9282L593,103@9907L506,103@9892L521,110@10430L30:SettingsScreen.kt#o13vsk"

    move/from16 v47, v5

    move-object/from16 v5, v33

    .end local v33    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v47, "$changed\\26":I
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    new-instance v3, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;

    invoke-direct {v3, v8, v0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$1;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V

    const v4, -0x444dcb26

    .end local v6    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v33, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v6, 0x36

    move/from16 v50, v7

    const/4 v7, 0x1

    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\26\\309\\20":I
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\26\\309\\20":I
    invoke-static {v4, v7, v3, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function3;

    const-string v4, "\u64cd\u4f5c"

    invoke-static {v4, v3, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 55
    new-instance v3, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;

    invoke-direct {v3, v8, v0, v1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$2;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/MutableState;)V

    const v1, -0x102deebd

    invoke-static {v1, v7, v3, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u97f3\u9891"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 61
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;

    invoke-direct {v1, v8, v0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$3;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V

    const v3, 0x35a14b22

    invoke-static {v3, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u663e\u793a"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 67
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$4;

    invoke-direct {v1, v8}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$4;-><init>(Lorg/lighttouch/android/AppSettings;)V

    const v3, 0x7b708501

    invoke-static {v3, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u6027\u80fd"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    const v1, -0x6bee3285

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "69@5671L373,69@5653L391"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 70
    sget-boolean v1, Lorg/lighttouch/android/BuildConfig;->DEBUG:Z

    if-eqz v1, :cond_f

    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;

    invoke-direct {v1, v8}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;-><init>(Lorg/lighttouch/android/AppSettings;)V

    const v3, 0x4d7c2c9f    # 2.6442392E8f

    const/4 v7, 0x1

    invoke-static {v3, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u56fe\u5f62"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    :cond_f
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 74
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;

    invoke-direct {v1, v8, v0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$6;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;)V

    const v3, -0x3ec04120

    const/4 v7, 0x1

    invoke-static {v3, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u6027\u80fd\u6d6e\u5c42"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 87
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;

    invoke-direct {v1, v8, v0, v10}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$7;-><init>(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V

    const v3, 0x70ef8bf

    invoke-static {v3, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u8bca\u65ad"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 98
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;

    invoke-direct {v1, v0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;-><init>(Lorg/lighttouch/android/GuestHost;)V

    const v3, 0x4cde329e    # 1.164956E8f

    invoke-static {v3, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    const-string v3, "\u8bbe\u5907"

    invoke-static {v3, v1, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 104
    new-instance v1, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;

    invoke-direct {v1, v2, v0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;-><init>(Landroid/content/Context;Lorg/lighttouch/android/GuestHost;)V

    const v0, -0x6d529383

    invoke-static {v0, v7, v1, v5, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    const-string v1, "\u5173\u4e8e"

    invoke-static {v1, v0, v5, v6}, Lorg/lighttouch/android/SettingsScreenKt;->access$Group(Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 111
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x18

    .local v1, "$this$dp\\28":I
    const/4 v2, 0x0

    .line 311
    .local v2, "$i$f$getDp\\28\\111":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 111
    .end local v1    # "$this$dp\\28":I
    .end local v2    # "$i$f$getDp\\28\\111":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v21

    invoke-static {v0, v5, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 50
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 112
    nop

    .line 310
    .end local v5    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .end local v9    # "$changed\\27":I
    .end local v39    # "$i$a$-Column-SettingsScreenKt$SettingsScreen$4$1$2\\27\\310\\8":I
    .end local v41    # "$this$invoke_u24lambda_u242_u24lambda_u241\\27":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 309
    .end local v33    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v47    # "$changed\\26":I
    .end local v50    # "$i$a$-Layout-ColumnKt$Column$1\\26\\309\\20":I
    nop

    .line 312
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 288
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 313
    nop

    .line 282
    .end local v30    # "$i$f$ReusableComposeNode\\22\\286":I
    .end local v44    # "$changed\\22":I
    .end local v45    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 314
    nop

    .line 275
    .end local v16    # "$changed\\21":I
    .end local v17    # "$i$f$Layout\\21\\281":I
    .end local v27    # "compositeKeyHash\\21":I
    .end local v46    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v48    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 315
    nop

    .line 45
    .end local v11    # "$changed\\20":I
    .end local v13    # "$i$f$Column\\20\\49":I
    .end local v14    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v15    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v32    # "modifier\\20":Landroidx/compose/ui/Modifier;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 113
    nop

    .line 232
    .end local v12    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v34    # "$this$invoke_u24lambda_u242\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v35    # "$changed\\8":I
    .end local v38    # "$i$a$-Column-SettingsScreenKt$SettingsScreen$4$1\\8\\232\\0":I
    invoke-static/range {v36 .. v36}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 231
    .end local v36    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v40    # "$changed\\7":I
    .end local v42    # "$i$a$-Layout-ColumnKt$Column$1\\7\\231\\1":I
    nop

    .line 316
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 210
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 317
    nop

    .line 204
    .end local v28    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v29    # "$i$f$ReusableComposeNode\\3\\208":I
    .end local v88    # "$changed\\3":I
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 318
    nop

    .line 197
    .end local v23    # "$changed\\2":I
    .end local v24    # "$i$f$Layout\\2\\203":I
    .end local v26    # "compositeKeyHash\\2":I
    .end local v31    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v43    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 319
    nop

    .end local v19    # "$changed\\1":I
    .end local v20    # "$i$f$Column\\1\\44":I
    .end local v22    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v25    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v37    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v49    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 114
    :cond_10
    :goto_a
    return-void
.end method

.class public final Lorg/lighttouch/android/StoreInstaller;
.super Ljava/lang/Object;
.source "StoreInstaller.kt"

# interfaces
.implements Lorg/lighttouch/android/QueueWork;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/StoreInstaller$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lorg/lighttouch/android/QueueWork<",
        "Lorg/lighttouch/android/InstallRequest;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreInstaller.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreInstaller.kt\norg/lighttouch/android/StoreInstaller\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,179:1\n774#2:180\n865#2,2:181\n1788#2,4:183\n230#2,2:187\n230#2,2:189\n295#2,2:191\n1788#2,4:193\n774#2:198\n865#2,2:199\n1#3:197\n*S KotlinDebug\n*F\n+ 1 StoreInstaller.kt\norg/lighttouch/android/StoreInstaller\n*L\n66#1:180\n66#1:181,2\n69#1:183,4\n72#1:187,2\n73#1:189,2\n83#1:191,2\n85#1:193,4\n51#1:198\n51#1:199,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u0008\u0001\u0018\u0000 F2\u0008\u0012\u0004\u0012\u00020\u00020\u0001:\u0001FB\u0011\u0008\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u000e\u00108\u001a\u0008\u0012\u0004\u0012\u00020 0\u001fH\u0002J\n\u00109\u001a\u0004\u0018\u00010\u0014H\u0002J\u0008\u0010:\u001a\u00020!H\u0002J\u0008\u0010;\u001a\u00020!H\u0002J\u0010\u0010<\u001a\u0002072\u0006\u0010\u0013\u001a\u00020\u0014H\u0002J&\u0010=\u001a\u00020>2\u0006\u0010?\u001a\u00020\u00022\u0006\u0010@\u001a\u00020A2\u000c\u0010B\u001a\u0008\u0012\u0004\u0012\u00020\u00100+H\u0016J.\u0010C\u001a\u00020!2\u0006\u0010?\u001a\u00020\u00022\u0006\u0010D\u001a\u00020>2\u0006\u0010@\u001a\u00020A2\u000c\u0010B\u001a\u0008\u0012\u0004\u0012\u00020\u00100+H\u0016J\u0010\u0010E\u001a\u00020!2\u0006\u0010D\u001a\u00020>H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00020\u000c\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\r\u0010\u000eR\u0011\u0010\u000f\u001a\u00020\u00108F\u00a2\u0006\u0006\u001a\u0004\u0008\u0011\u0010\u0012R\u001c\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u0015\u0010\u0016\"\u0004\u0008\u0017\u0010\u0018R\u001a\u0010\u0019\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\u001a\u0010\u0012\"\u0004\u0008\u001b\u0010\u001cR,\u0010\u001d\u001a\u0014\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020 0\u001f\u0012\u0004\u0012\u00020!0\u001eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008\"\u0010#\"\u0004\u0008$\u0010%R,\u0010&\u001a\u0014\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\'0\u001f\u0012\u0004\u0012\u00020!0\u001eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008(\u0010#\"\u0004\u0008)\u0010%R\"\u0010*\u001a\n\u0012\u0004\u0012\u00020!\u0018\u00010+X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\u0008,\u0010-\"\u0004\u0008.\u0010/R\u000e\u00100\u001a\u000201X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00102\u001a\u000203X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00104\u001a\u000203X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u00105\u001a\u0010\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u000207\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006G"
    }
    d2 = {
        "Lorg/lighttouch/android/StoreInstaller;",
        "Lorg/lighttouch/android/QueueWork;",
        "Lorg/lighttouch/android/InstallRequest;",
        "context",
        "Landroid/content/Context;",
        "<init>",
        "(Landroid/content/Context;)V",
        "apps",
        "Lorg/lighttouch/android/GuestApps;",
        "main",
        "Landroid/os/Handler;",
        "queue",
        "Lorg/lighttouch/android/InstallQueue;",
        "getQueue",
        "()Lorg/lighttouch/android/InstallQueue;",
        "available",
        "",
        "getAvailable",
        "()Z",
        "socket",
        "",
        "getSocket",
        "()Ljava/lang/String;",
        "setSocket",
        "(Ljava/lang/String;)V",
        "visible",
        "getVisible",
        "setVisible",
        "(Z)V",
        "onChanged",
        "Lkotlin/Function1;",
        "",
        "Lorg/lighttouch/android/QueueItem;",
        "",
        "getOnChanged",
        "()Lkotlin/jvm/functions/Function1;",
        "setOnChanged",
        "(Lkotlin/jvm/functions/Function1;)V",
        "onInstalled",
        "Lorg/lighttouch/android/InstalledApp;",
        "getOnInstalled",
        "setOnInstalled",
        "onIdle",
        "Lkotlin/Function0;",
        "getOnIdle",
        "()Lkotlin/jvm/functions/Function0;",
        "setOnIdle",
        "(Lkotlin/jvm/functions/Function0;)V",
        "changePosted",
        "Ljava/util/concurrent/atomic/AtomicBoolean;",
        "lastNotified",
        "",
        "batchFirst",
        "exact",
        "Lkotlin/Pair;",
        "Lorg/lighttouch/android/StoreTarget;",
        "batch",
        "summary",
        "notifyProgress",
        "pauseGuest",
        "exactTarget",
        "fetch",
        "Ljava/io/File;",
        "payload",
        "report",
        "Lorg/lighttouch/android/QueueReport;",
        "cancelled",
        "install",
        "file",
        "discard",
        "Companion",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lorg/lighttouch/android/StoreInstaller$Companion;

.field private static volatile instance:Lorg/lighttouch/android/StoreInstaller;


# instance fields
.field private final apps:Lorg/lighttouch/android/GuestApps;

.field private volatile batchFirst:J

.field private final changePosted:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private final context:Landroid/content/Context;

.field private exact:Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/StoreTarget;",
            ">;"
        }
    .end annotation
.end field

.field private lastNotified:J

.field private final main:Landroid/os/Handler;

.field private volatile onChanged:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private volatile onIdle:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private volatile onInstalled:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final queue:Lorg/lighttouch/android/InstallQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lorg/lighttouch/android/InstallQueue<",
            "Lorg/lighttouch/android/InstallRequest;",
            ">;"
        }
    .end annotation
.end field

.field private volatile socket:Ljava/lang/String;

.field private volatile visible:Z


# direct methods
.method public static synthetic $r8$lambda$6OAUnTVZOojUXpZLGCzEik-AEZ8(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstaller;->_init_$lambda$9(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8yA2Y5ot-PafW5oJe71eKo_cBD4(Ljava/util/List;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstaller;->onChanged$lambda$0(Ljava/util/List;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ijwz3DHzMACwomvKlo4INcsi4yY(Lkotlin/jvm/internal/Ref$LongRef;Lorg/lighttouch/android/QueueReport;JLjava/lang/Long;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreInstaller;->fetch$lambda$24(Lkotlin/jvm/internal/Ref$LongRef;Lorg/lighttouch/android/QueueReport;JLjava/lang/Long;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ip-Ra3jFD3L-d_iPPB2FfkuvYBU(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstaller;->_init_$lambda$6(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NCBcPqpmUcU6RCi2oRRrnYjG2eg(Ljava/util/List;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstaller;->onInstalled$lambda$1(Ljava/util/List;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mDD6vdWMQIsfPt3iEFszJcaYob8(Lorg/lighttouch/android/QueueReport;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreInstaller;->install$lambda$29(Lorg/lighttouch/android/QueueReport;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pH7dUcs1WQoEKWT1N7jP97rs4Ns(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstaller;->_init_$lambda$4(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pz530Z1_UfLnCHbvGiBWSs18OCQ(Lorg/lighttouch/android/StoreInstaller;Ljava/util/List;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreInstaller;->install$lambda$32$lambda$31(Lorg/lighttouch/android/StoreInstaller;Ljava/util/List;)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lorg/lighttouch/android/StoreInstaller$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lorg/lighttouch/android/StoreInstaller$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lorg/lighttouch/android/StoreInstaller;->Companion:Lorg/lighttouch/android/StoreInstaller$Companion;

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/StoreInstaller;->$stable:I

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    .line 29
    new-instance v0, Lorg/lighttouch/android/GuestApps;

    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-direct {v0, v1}, Lorg/lighttouch/android/GuestApps;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->apps:Lorg/lighttouch/android/GuestApps;

    .line 30
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->main:Landroid/os/Handler;

    .line 31
    new-instance v0, Lorg/lighttouch/android/InstallQueue;

    move-object v1, p0

    check-cast v1, Lorg/lighttouch/android/QueueWork;

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1, v2, v3, v2}, Lorg/lighttouch/android/InstallQueue;-><init>(Lorg/lighttouch/android/QueueWork;Lkotlin/jvm/functions/Function2;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    .line 39
    new-instance v0, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda5;

    invoke-direct {v0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda5;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onChanged:Lkotlin/jvm/functions/Function1;

    .line 40
    new-instance v0, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda6;

    invoke-direct {v0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda6;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onInstalled:Lkotlin/jvm/functions/Function1;

    .line 44
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->changePosted:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 49
    nop

    .line 50
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    new-instance v1, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/StoreInstaller;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/InstallQueue;->setOnBusy(Lkotlin/jvm/functions/Function0;)V

    .line 54
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    new-instance v1, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/StoreInstaller;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/InstallQueue;->setOnChange(Lkotlin/jvm/functions/Function0;)V

    .line 58
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    new-instance v1, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda9;-><init>(Lorg/lighttouch/android/StoreInstaller;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/InstallQueue;->setOnIdle(Lkotlin/jvm/functions/Function0;)V

    .line 63
    nop

    .line 28
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/StoreInstaller;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method private static final _init_$lambda$4(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;
    .locals 9
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreInstaller;

    .line 51
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstallQueue;->snapshot()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 198
    .local v1, "$i$f$filter\\1\\51":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 199
    .local v4, "$i$f$filterTo\\2\\198":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lorg/lighttouch/android/QueueItem;

    .local v7, "it\\3":Lorg/lighttouch/android/QueueItem;
    const/4 v8, 0x0

    .line 51
    .local v8, "$i$a$-filter-StoreInstaller$1$1\\3\\199\\0":I
    invoke-virtual {v7}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v7

    .line 199
    .end local v7    # "it\\3":Lorg/lighttouch/android/QueueItem;
    .end local v8    # "$i$a$-filter-StoreInstaller$1$1\\3\\199\\0":I
    if-eqz v7, :cond_0

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 200
    .end local v6    # "element\\2":Ljava/lang/Object;
    :cond_1
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo\\2\\198":I
    check-cast v2, Ljava/util/List;

    .line 198
    nop

    .line 51
    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\1\\51":I
    check-cast v2, Ljava/lang/Iterable;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_2

    const/4 v0, 0x0

    goto :goto_2

    :cond_2
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/lighttouch/android/QueueItem;

    .line 197
    .local v1, "it\\4":Lorg/lighttouch/android/QueueItem;
    const/4 v2, 0x0

    .line 51
    .local v2, "$i$a$-minOfOrNull-StoreInstaller$1$2\\4\\51\\0":I
    invoke-virtual {v1}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v1

    .end local v1    # "it\\4":Lorg/lighttouch/android/QueueItem;
    .end local v2    # "$i$a$-minOfOrNull-StoreInstaller$1$2\\4\\51\\0":I
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    check-cast v1, Ljava/lang/Comparable;

    :cond_3
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/QueueItem;

    .line 197
    .local v2, "it\\5":Lorg/lighttouch/android/QueueItem;
    const/4 v3, 0x0

    .line 51
    .local v3, "$i$a$-minOfOrNull-StoreInstaller$1$2\\5\\51\\0":I
    invoke-virtual {v2}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v2

    .end local v2    # "it\\5":Lorg/lighttouch/android/QueueItem;
    .end local v3    # "$i$a$-minOfOrNull-StoreInstaller$1$2\\5\\51\\0":I
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    check-cast v2, Ljava/lang/Comparable;

    invoke-interface {v1, v2}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    move-result v3

    if-lez v3, :cond_3

    move-object v1, v2

    goto :goto_1

    :cond_4
    move-object v0, v1

    :goto_2
    check-cast v0, Ljava/lang/Long;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    goto :goto_3

    :cond_5
    const-wide/16 v0, 0x0

    :goto_3
    iput-wide v0, p0, Lorg/lighttouch/android/StoreInstaller;->batchFirst:J

    .line 52
    sget-object v0, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    const-string v2, "\u6b63\u5728\u5b89\u88c5\u5e94\u7528"

    invoke-virtual {v0, v1, v2}, Lorg/lighttouch/android/DownloadService$Companion;->hold(Landroid/content/Context;Ljava/lang/String;)V

    .line 53
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final _init_$lambda$6(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreInstaller;

    .line 55
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->changePosted:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->main:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/StoreInstaller;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 56
    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/StoreInstaller;->notifyProgress()V

    .line 57
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final _init_$lambda$9(Lorg/lighttouch/android/StoreInstaller;)Lkotlin/Unit;
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreInstaller;

    .line 59
    sget-object v0, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/DownloadService$Companion;->release(Landroid/content/Context;)V

    .line 60
    iget-boolean v0, p0, Lorg/lighttouch/android/StoreInstaller;->visible:Z

    if-nez v0, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/StoreInstaller;->summary()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 197
    .local v0, "it\\1":Ljava/lang/String;
    const/4 v1, 0x0

    .line 60
    .local v1, "$i$a$-let-StoreInstaller$3$1\\1\\60\\0":I
    sget-object v2, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    iget-object v3, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-virtual {v2, v3, v0}, Lorg/lighttouch/android/DownloadService$Companion;->finished(Landroid/content/Context;Ljava/lang/String;)V

    .line 61
    .end local v0    # "it\\1":Ljava/lang/String;
    .end local v1    # "$i$a$-let-StoreInstaller$3$1\\1\\60\\0":I
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->main:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/StoreInstaller;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 62
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$getContext$p(Lorg/lighttouch/android/StoreInstaller;)Landroid/content/Context;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/StoreInstaller;

    .line 28
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    return-object v0
.end method

.method public static final synthetic access$getInstance$cp()Lorg/lighttouch/android/StoreInstaller;
    .locals 1

    .line 28
    sget-object v0, Lorg/lighttouch/android/StoreInstaller;->instance:Lorg/lighttouch/android/StoreInstaller;

    return-object v0
.end method

.method public static final synthetic access$setInstance$cp(Lorg/lighttouch/android/StoreInstaller;)V
    .locals 0
    .param p0, "<set-?>"    # Lorg/lighttouch/android/StoreInstaller;

    .line 28
    sput-object p0, Lorg/lighttouch/android/StoreInstaller;->instance:Lorg/lighttouch/android/StoreInstaller;

    return-void
.end method

.method private final batch()Ljava/util/List;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;"
        }
    .end annotation

    .line 66
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstallQueue;->snapshot()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 180
    .local v1, "$i$f$filter\\1\\66":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 181
    .local v4, "$i$f$filterTo\\2\\180":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Lorg/lighttouch/android/QueueItem;

    .local v7, "it\\3":Lorg/lighttouch/android/QueueItem;
    const/4 v8, 0x0

    .line 66
    .local v8, "$i$a$-filter-StoreInstaller$batch$1\\3\\181\\0":I
    invoke-virtual {v7}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v9

    iget-wide v11, p0, Lorg/lighttouch/android/StoreInstaller;->batchFirst:J

    cmp-long v9, v9, v11

    if-ltz v9, :cond_1

    const/4 v9, 0x1

    goto :goto_1

    :cond_1
    const/4 v9, 0x0

    .line 181
    .end local v7    # "it\\3":Lorg/lighttouch/android/QueueItem;
    .end local v8    # "$i$a$-filter-StoreInstaller$batch$1\\3\\181\\0":I
    :goto_1
    if-eqz v9, :cond_0

    invoke-interface {v2, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 182
    .end local v6    # "element\\2":Ljava/lang/Object;
    :cond_2
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$filterTo\\2\\180":I
    check-cast v2, Ljava/util/List;

    .line 180
    nop

    .line 66
    .end local v0    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\1\\66":I
    return-object v2
.end method

.method private final exactTarget(Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;
    .locals 5
    .param p1, "socket"    # Ljava/lang/String;

    .line 106
    monitor-enter p0

    const/4 v0, 0x0

    .line 107
    .local v0, "$i$a$-synchronized-StoreInstaller$exactTarget$1\\1\\106\\0":I
    :try_start_0
    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->exact:Lkotlin/Pair;

    if-eqz v1, :cond_1

    move-object v2, v1

    .line 197
    .local v2, "it\\2":Lkotlin/Pair;
    const/4 v3, 0x0

    .line 107
    .local v3, "$i$a$-takeIf-StoreInstaller$exactTarget$1$1\\2\\107\\1":I
    invoke-virtual {v2}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .end local v2    # "it\\2":Lkotlin/Pair;
    .end local v3    # "$i$a$-takeIf-StoreInstaller$exactTarget$1$1\\2\\107\\1":I
    if-eqz v4, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/lighttouch/android/StoreTarget;

    if-nez v1, :cond_2

    :cond_1
    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v1, p1}, Lorg/lighttouch/android/GuestApps;->target(Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;

    move-result-object v1

    move-object v2, v1

    .line 197
    .local v2, "it\\3":Lorg/lighttouch/android/StoreTarget;
    const/4 v3, 0x0

    .line 107
    .local v3, "$i$a$-also-StoreInstaller$exactTarget$1$2\\3\\107\\1":I
    invoke-static {p1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    iput-object v4, p0, Lorg/lighttouch/android/StoreInstaller;->exact:Lkotlin/Pair;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 106
    .end local v0    # "$i$a$-synchronized-StoreInstaller$exactTarget$1\\1\\106\\0":I
    .end local v2    # "it\\3":Lorg/lighttouch/android/StoreTarget;
    .end local v3    # "$i$a$-also-StoreInstaller$exactTarget$1$2\\3\\107\\1":I
    :cond_2
    monitor-exit p0

    .line 108
    return-object v1

    .line 106
    :catchall_0
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private static final fetch$lambda$24(Lkotlin/jvm/internal/Ref$LongRef;Lorg/lighttouch/android/QueueReport;JLjava/lang/Long;)Lkotlin/Unit;
    .locals 9
    .param p0, "$reported"    # Lkotlin/jvm/internal/Ref$LongRef;
    .param p1, "$report"    # Lorg/lighttouch/android/QueueReport;
    .param p2, "count"    # J
    .param p4, "total"    # Ljava/lang/Long;

    .line 118
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 119
    .local v0, "now":J
    iget-wide v2, p0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x64

    cmp-long v2, v2, v4

    if-gez v2, :cond_1

    if-nez p4, :cond_0

    goto/16 :goto_1

    :cond_0
    invoke-virtual {p4}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    cmp-long v2, p2, v2

    if-nez v2, :cond_5

    .line 120
    :cond_1
    iput-wide v0, p0, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 121
    invoke-static {p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->byteSize(J)Ljava/lang/String;

    move-result-object v2

    if-eqz p4, :cond_2

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    .line 197
    nop

    .local v3, "it\\1":J
    const/4 v5, 0x0

    .line 121
    .local v5, "$i$a$-let-StoreInstaller$fetch$1$1\\1\\121\\0":I
    invoke-static {v3, v4}, Lorg/lighttouch/android/StoreScreenKt;->byteSize(J)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, " / "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .end local v3    # "it\\1":J
    .end local v5    # "$i$a$-let-StoreInstaller$fetch$1$1\\1\\121\\0":I
    if-nez v3, :cond_3

    :cond_2
    const-string v3, ""

    :cond_3
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u6b63\u5728\u4e0b\u8f7d "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    if-eqz p4, :cond_4

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    .line 197
    nop

    .local v3, "it\\2":J
    const/4 v5, 0x0

    .line 121
    .local v5, "$i$a$-let-StoreInstaller$fetch$1$2\\2\\121\\0":I
    long-to-float v6, p2

    long-to-float v7, v3

    div-float/2addr v6, v7

    .end local v3    # "it\\2":J
    .end local v5    # "$i$a$-let-StoreInstaller$fetch$1$2\\2\\121\\0":I
    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    goto :goto_0

    :cond_4
    const/4 v3, 0x0

    :goto_0
    invoke-interface {p1, v2, v3}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    .line 122
    if-eqz p4, :cond_5

    move-object v2, p4

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .line 197
    .local v2, "it\\3":J
    const/4 v4, 0x0

    .line 122
    .local v4, "$i$a$-let-StoreInstaller$fetch$1$3\\3\\122\\0":I
    sget-object v5, Lorg/lighttouch/android/QueueStages;->INSTANCE:Lorg/lighttouch/android/QueueStages;

    long-to-float v6, p2

    long-to-float v7, v2

    div-float/2addr v6, v7

    invoke-virtual {v5, v6}, Lorg/lighttouch/android/QueueStages;->download(F)F

    move-result v5

    invoke-interface {p1, v5}, Lorg/lighttouch/android/QueueReport;->overall(F)V

    .line 124
    .end local v2    # "it\\3":J
    .end local v4    # "$i$a$-let-StoreInstaller$fetch$1$3\\3\\122\\0":I
    :cond_5
    :goto_1
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method private static final install$lambda$29(Lorg/lighttouch/android/QueueReport;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 10
    .param p0, "$report"    # Lorg/lighttouch/android/QueueReport;
    .param p1, "e"    # Lorg/json/JSONObject;

    const-string v0, "e"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    const-string v0, "phase"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const-string v2, "\u5b89\u88c5\u4e2d"

    const/4 v3, 0x0

    const/high16 v4, 0x42c80000    # 100.0f

    const-string v5, "percent"

    sparse-switch v1, :sswitch_data_0

    goto/16 :goto_1

    :sswitch_0
    const-string v1, "install"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_1

    .line 154
    :cond_0
    invoke-interface {p0}, Lorg/lighttouch/android/QueueReport;->commit()V

    .line 155
    const-string v0, "unpacked_total"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v6

    const-wide/16 v8, 0x0

    cmp-long v1, v6, v8

    if-lez v1, :cond_1

    .line 156
    const-string v1, "unpacked"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v2

    long-to-float v2, v2

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v3

    long-to-float v3, v3

    div-float/2addr v2, v3

    .line 157
    .local v2, "unpacked":F
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v3

    invoke-static {v3, v4}, Lorg/lighttouch/android/StoreScreenKt;->byteSize(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v3

    invoke-static {v3, v4}, Lorg/lighttouch/android/StoreScreenKt;->byteSize(J)Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u6b63\u5728\u89e3\u5305 \u00b7 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " / "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    invoke-interface {p0, v0, v1}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    .line 158
    sget-object v0, Lorg/lighttouch/android/QueueStages;->INSTANCE:Lorg/lighttouch/android/QueueStages;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/QueueStages;->unpack(F)F

    move-result v0

    invoke-interface {p0, v0}, Lorg/lighttouch/android/QueueReport;->overall(F)V

    .end local v2    # "unpacked":F
    goto/16 :goto_1

    .line 160
    :cond_1
    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    goto :goto_0

    :cond_2
    move-object v0, v3

    .line 161
    .local v0, "percent":Ljava/lang/Integer;
    :goto_0
    const-string v1, "status"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "ExtractingPackage"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    const-string v2, "\u6b63\u5728\u89e3\u5305"

    :cond_3
    if-eqz v0, :cond_4

    move-object v3, v0

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 197
    nop

    .local v3, "it\\1":I
    const/4 v5, 0x0

    .line 161
    .local v5, "$i$a$-let-StoreInstaller$install$1$1\\1\\161\\0":I
    int-to-float v7, v3

    div-float/2addr v7, v4

    .end local v3    # "it\\1":I
    .end local v5    # "$i$a$-let-StoreInstaller$install$1$1\\1\\161\\0":I
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    :cond_4
    invoke-interface {p0, v2, v3}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    .line 162
    if-eqz v0, :cond_7

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_7

    sget-object v1, Lorg/lighttouch/android/QueueStages;->INSTANCE:Lorg/lighttouch/android/QueueStages;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/QueueStages;->iosPercent(I)F

    move-result v1

    invoke-interface {p0, v1}, Lorg/lighttouch/android/QueueReport;->overall(F)V

    goto :goto_1

    .line 148
    .end local v0    # "percent":Ljava/lang/Integer;
    :sswitch_1
    const-string v1, "mutation"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_1

    .line 150
    :cond_5
    invoke-interface {p0}, Lorg/lighttouch/android/QueueReport;->commit()V

    invoke-interface {p0, v2, v3}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    goto :goto_1

    .line 148
    :sswitch_2
    const-string v1, "upload"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_1

    .line 149
    :cond_6
    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    int-to-float v0, v0

    div-float/2addr v0, v4

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const-string v1, "\u6b63\u5728\u590d\u5236\u5230\u8bbe\u5907"

    invoke-interface {p0, v1, v0}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    sget-object v0, Lorg/lighttouch/android/QueueStages;->INSTANCE:Lorg/lighttouch/android/QueueStages;

    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v4

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/QueueStages;->copy(F)F

    move-result v0

    invoke-interface {p0, v0}, Lorg/lighttouch/android/QueueReport;->overall(F)V

    .line 166
    :cond_7
    :goto_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x31fbf1ff -> :sswitch_2
        0x339892a9 -> :sswitch_1
        0x74ae259b -> :sswitch_0
    .end sparse-switch
.end method

.method private static final install$lambda$32$lambda$31(Lorg/lighttouch/android/StoreInstaller;Ljava/util/List;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreInstaller;
    .param p1, "$list"    # Ljava/util/List;

    .line 167
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onInstalled:Lkotlin/jvm/functions/Function1;

    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final lambda$6$lambda$5(Lorg/lighttouch/android/StoreInstaller;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreInstaller;

    .line 55
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->changePosted:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onChanged:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    invoke-virtual {v1}, Lorg/lighttouch/android/InstallQueue;->snapshot()Ljava/util/List;

    move-result-object v1

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method static final lambda$9$lambda$8(Lorg/lighttouch/android/StoreInstaller;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreInstaller;

    .line 61
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onIdle:Lkotlin/jvm/functions/Function0;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/StoreInstaller;->pauseGuest()V

    :goto_0
    return-void
.end method

.method private final notifyProgress()V
    .locals 14

    .line 80
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 81
    .local v0, "now":J
    iget-wide v2, p0, Lorg/lighttouch/android/StoreInstaller;->lastNotified:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x1f4

    cmp-long v2, v2, v4

    if-gez v2, :cond_0

    return-void

    .line 82
    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/StoreInstaller;->batch()Ljava/util/List;

    move-result-object v2

    .line 83
    .local v2, "items":Ljava/util/List;
    move-object v3, v2

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 191
    .local v4, "$i$f$firstOrNull\\1\\83":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v6, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\1":Ljava/lang/Object;
    move-object v10, v6

    check-cast v10, Lorg/lighttouch/android/QueueItem;

    .local v10, "it\\2":Lorg/lighttouch/android/QueueItem;
    const/4 v11, 0x0

    .line 83
    .local v11, "$i$a$-firstOrNull-StoreInstaller$notifyProgress$current$1\\2\\191\\0":I
    invoke-virtual {v10}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v12

    sget-object v13, Lorg/lighttouch/android/QueueState;->INSTALLING:Lorg/lighttouch/android/QueueState;

    if-ne v12, v13, :cond_2

    move v10, v9

    goto :goto_0

    :cond_2
    move v10, v8

    .line 191
    .end local v10    # "it\\2":Lorg/lighttouch/android/QueueItem;
    .end local v11    # "$i$a$-firstOrNull-StoreInstaller$notifyProgress$current$1\\2\\191\\0":I
    :goto_0
    if-eqz v10, :cond_1

    goto :goto_1

    .line 192
    .end local v6    # "element\\1":Ljava/lang/Object;
    :cond_3
    move-object v6, v7

    .line 83
    .end local v3    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v4    # "$i$f$firstOrNull\\1\\83":I
    :goto_1
    check-cast v6, Lorg/lighttouch/android/QueueItem;

    if-nez v6, :cond_7

    move-object v3, v2

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$firstOrNull\\3":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 191
    .local v4, "$i$f$firstOrNull\\3\\83":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\3":Ljava/lang/Object;
    move-object v10, v6

    check-cast v10, Lorg/lighttouch/android/QueueItem;

    .local v10, "it\\4":Lorg/lighttouch/android/QueueItem;
    const/4 v11, 0x0

    .line 83
    .local v11, "$i$a$-firstOrNull-StoreInstaller$notifyProgress$current$2\\4\\191\\0":I
    invoke-virtual {v10}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v12

    sget-object v13, Lorg/lighttouch/android/QueueState;->DOWNLOADING:Lorg/lighttouch/android/QueueState;

    if-ne v12, v13, :cond_5

    move v10, v9

    goto :goto_2

    :cond_5
    move v10, v8

    .line 191
    .end local v10    # "it\\4":Lorg/lighttouch/android/QueueItem;
    .end local v11    # "$i$a$-firstOrNull-StoreInstaller$notifyProgress$current$2\\4\\191\\0":I
    :goto_2
    if-eqz v10, :cond_4

    move-object v7, v6

    goto :goto_3

    .line 192
    .end local v6    # "element\\3":Ljava/lang/Object;
    :cond_6
    nop

    .line 83
    .end local v3    # "$this$firstOrNull\\3":Ljava/lang/Iterable;
    .end local v4    # "$i$f$firstOrNull\\3\\83":I
    :goto_3
    move-object v6, v7

    check-cast v6, Lorg/lighttouch/android/QueueItem;

    if-nez v6, :cond_7

    return-void

    .line 84
    .local v6, "current":Lorg/lighttouch/android/QueueItem;
    :cond_7
    iput-wide v0, p0, Lorg/lighttouch/android/StoreInstaller;->lastNotified:J

    .line 85
    move-object v3, v2

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$count\\5":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 193
    .local v4, "$i$f$count\\5\\85":I
    instance-of v5, v3, Ljava/util/Collection;

    if-eqz v5, :cond_8

    move-object v5, v3

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_8

    goto :goto_5

    .line 194
    :cond_8
    const/4 v5, 0x0

    .line 195
    .local v5, "count\\5":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move v8, v5

    .end local v5    # "count\\5":I
    .local v8, "count\\5":I
    :cond_9
    :goto_4
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_a

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\5":Ljava/lang/Object;
    move-object v10, v5

    check-cast v10, Lorg/lighttouch/android/QueueItem;

    .local v10, "it\\6":Lorg/lighttouch/android/QueueItem;
    const/4 v11, 0x0

    .line 85
    .local v11, "$i$a$-count-StoreInstaller$notifyProgress$position$1\\6\\195\\0":I
    invoke-virtual {v10}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v12

    .line 195
    .end local v10    # "it\\6":Lorg/lighttouch/android/QueueItem;
    .end local v11    # "$i$a$-count-StoreInstaller$notifyProgress$position$1\\6\\195\\0":I
    if-nez v12, :cond_9

    add-int/lit8 v8, v8, 0x1

    if-gez v8, :cond_9

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v5    # "element\\5":Ljava/lang/Object;
    goto :goto_4

    .line 196
    :cond_a
    nop

    .line 85
    .end local v3    # "$this$count\\5":Ljava/lang/Iterable;
    .end local v4    # "$i$f$count\\5\\85":I
    .end local v8    # "count\\5":I
    :goto_5
    add-int/2addr v8, v9

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    invoke-static {v8, v3}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v3

    .line 86
    .local v3, "position":I
    sget-object v4, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    iget-object v5, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-virtual {v6}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v7

    sget-object v8, Lorg/lighttouch/android/QueueState;->INSTALLING:Lorg/lighttouch/android/QueueState;

    if-ne v7, v8, :cond_b

    const-string v7, "\u6b63\u5728\u5b89\u88c5 "

    goto :goto_6

    :cond_b
    const-string v7, "\u6b63\u5728\u4e0b\u8f7d "

    :goto_6
    invoke-virtual {v6}, Lorg/lighttouch/android/QueueItem;->getName()Ljava/lang/String;

    move-result-object v8

    .line 87
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v10

    if-le v10, v9, :cond_c

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v9

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, " \u00b7 "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " / "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_7

    :cond_c
    const-string v9, ""

    :goto_7
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6}, Lorg/lighttouch/android/QueueItem;->getOverall()F

    move-result v8

    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v8

    .line 86
    invoke-virtual {v4, v5, v7, v8}, Lorg/lighttouch/android/DownloadService$Companion;->update(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)V

    .line 88
    return-void
.end method

.method private static final onChanged$lambda$0(Ljava/util/List;)Lkotlin/Unit;
    .locals 1
    .param p0, "it"    # Ljava/util/List;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final onInstalled$lambda$1(Ljava/util/List;)Lkotlin/Unit;
    .locals 1
    .param p0, "it"    # Ljava/util/List;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final pauseGuest()V
    .locals 5

    .line 92
    new-instance v0, Lorg/lighttouch/android/StoreInstaller$pauseGuest$connection$1;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/StoreInstaller$pauseGuest$connection$1;-><init>(Lorg/lighttouch/android/StoreInstaller;)V

    .line 102
    .local v0, "connection":Lorg/lighttouch/android/StoreInstaller$pauseGuest$connection$1;
    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    new-instance v2, Landroid/content/Intent;

    iget-object v3, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    const-class v4, Lorg/lighttouch/android/EngineService;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v3, v0

    check-cast v3, Landroid/content/ServiceConnection;

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    move-object v2, v0

    check-cast v2, Landroid/content/ServiceConnection;

    invoke-virtual {v1, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    .line 103
    :cond_0
    return-void
.end method

.method private final summary()Ljava/lang/String;
    .locals 15

    .line 69
    invoke-direct {p0}, Lorg/lighttouch/android/StoreInstaller;->batch()Ljava/util/List;

    move-result-object v0

    .local v0, "items":Ljava/util/List;
    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$count\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 183
    .local v2, "$i$f$count\\1\\69":I
    instance-of v3, v1, Ljava/util/Collection;

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    move v3, v4

    goto :goto_2

    .line 184
    :cond_0
    const/4 v3, 0x0

    .line 185
    .local v3, "count\\1":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1
    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\1":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lorg/lighttouch/android/QueueItem;

    .local v8, "it\\2":Lorg/lighttouch/android/QueueItem;
    const/4 v9, 0x0

    .line 69
    .local v9, "$i$a$-count-StoreInstaller$summary$done$1\\2\\185\\0":I
    invoke-virtual {v8}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v10

    sget-object v11, Lorg/lighttouch/android/QueueState;->DONE:Lorg/lighttouch/android/QueueState;

    if-ne v10, v11, :cond_2

    move v8, v5

    goto :goto_1

    :cond_2
    move v8, v4

    .line 185
    .end local v8    # "it\\2":Lorg/lighttouch/android/QueueItem;
    .end local v9    # "$i$a$-count-StoreInstaller$summary$done$1\\2\\185\\0":I
    :goto_1
    if-eqz v8, :cond_1

    add-int/lit8 v3, v3, 0x1

    if-gez v3, :cond_1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v7    # "element\\1":Ljava/lang/Object;
    goto :goto_0

    .line 186
    :cond_3
    nop

    .line 69
    .end local v1    # "$this$count\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$count\\1\\69":I
    .end local v3    # "count\\1":I
    :goto_2
    nop

    .local v3, "done":I
    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$count\\3":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 183
    .local v2, "$i$f$count\\3\\69":I
    instance-of v6, v1, Ljava/util/Collection;

    if-eqz v6, :cond_4

    move-object v6, v1

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_4

    move v6, v4

    goto :goto_5

    .line 184
    :cond_4
    const/4 v6, 0x0

    .line 185
    .local v6, "count\\3":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_5
    :goto_3
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\3":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/QueueItem;

    .local v9, "it\\4":Lorg/lighttouch/android/QueueItem;
    const/4 v10, 0x0

    .line 69
    .local v10, "$i$a$-count-StoreInstaller$summary$failed$1\\4\\185\\0":I
    invoke-virtual {v9}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v11

    sget-object v12, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    if-ne v11, v12, :cond_6

    move v9, v5

    goto :goto_4

    :cond_6
    move v9, v4

    .line 185
    .end local v9    # "it\\4":Lorg/lighttouch/android/QueueItem;
    .end local v10    # "$i$a$-count-StoreInstaller$summary$failed$1\\4\\185\\0":I
    :goto_4
    if-eqz v9, :cond_5

    add-int/lit8 v6, v6, 0x1

    if-gez v6, :cond_5

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v8    # "element\\3":Ljava/lang/Object;
    goto :goto_3

    .line 186
    :cond_7
    nop

    .line 69
    .end local v1    # "$this$count\\3":Ljava/lang/Iterable;
    .end local v2    # "$i$f$count\\3\\69":I
    .end local v6    # "count\\3":I
    :goto_5
    nop

    .line 70
    .local v6, "failed":I
    nop

    .line 71
    if-nez v3, :cond_8

    if-nez v6, :cond_8

    const/4 v1, 0x0

    goto/16 :goto_a

    .line 72
    :cond_8
    const-string v1, "Collection contains no element matching the predicate."

    const-string v2, " \u4e2a\u5e94\u7528"

    if-nez v6, :cond_d

    const-string v7, "\u5df2\u5b89\u88c5 "

    if-ne v3, v5, :cond_c

    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$first\\5":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 187
    .local v8, "$i$f$first\\5\\72":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_9
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_b

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\5":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/lighttouch/android/QueueItem;

    .local v11, "it\\6":Lorg/lighttouch/android/QueueItem;
    const/4 v12, 0x0

    .line 72
    .local v12, "$i$a$-first-StoreInstaller$summary$1\\6\\187\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v13

    sget-object v14, Lorg/lighttouch/android/QueueState;->DONE:Lorg/lighttouch/android/QueueState;

    if-ne v13, v14, :cond_a

    move v11, v5

    goto :goto_6

    :cond_a
    move v11, v4

    .line 187
    .end local v11    # "it\\6":Lorg/lighttouch/android/QueueItem;
    .end local v12    # "$i$a$-first-StoreInstaller$summary$1\\6\\187\\0":I
    :goto_6
    if-eqz v11, :cond_9

    .line 188
    .end local v2    # "$this$first\\5":Ljava/lang/Iterable;
    .end local v8    # "$i$f$first\\5\\72":I
    .end local v10    # "element\\5":Ljava/lang/Object;
    move-object v1, v10

    check-cast v1, Lorg/lighttouch/android/QueueItem;

    .line 72
    invoke-virtual {v1}, Lorg/lighttouch/android/QueueItem;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    goto :goto_7

    .line 188
    .restart local v2    # "$this$first\\5":Ljava/lang/Iterable;
    .restart local v8    # "$i$f$first\\5\\72":I
    :cond_b
    new-instance v4, Ljava/util/NoSuchElementException;

    invoke-direct {v4, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 72
    .end local v2    # "$this$first\\5":Ljava/lang/Iterable;
    .end local v8    # "$i$f$first\\5\\72":I
    :cond_c
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    :goto_7
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_a

    .line 73
    :cond_d
    if-nez v3, :cond_12

    const-string v7, "Couldn\'t install "

    if-ne v6, v5, :cond_11

    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$first\\7":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 189
    .local v8, "$i$f$first\\7\\73":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_e
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_10

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\7":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/lighttouch/android/QueueItem;

    .local v11, "it\\8":Lorg/lighttouch/android/QueueItem;
    const/4 v12, 0x0

    .line 73
    .local v12, "$i$a$-first-StoreInstaller$summary$2\\8\\189\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v13

    sget-object v14, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    if-ne v13, v14, :cond_f

    move v11, v5

    goto :goto_8

    :cond_f
    move v11, v4

    .line 189
    .end local v11    # "it\\8":Lorg/lighttouch/android/QueueItem;
    .end local v12    # "$i$a$-first-StoreInstaller$summary$2\\8\\189\\0":I
    :goto_8
    if-eqz v11, :cond_e

    .line 190
    .end local v2    # "$this$first\\7":Ljava/lang/Iterable;
    .end local v8    # "$i$f$first\\7\\73":I
    .end local v10    # "element\\7":Ljava/lang/Object;
    move-object v1, v10

    check-cast v1, Lorg/lighttouch/android/QueueItem;

    .line 73
    invoke-virtual {v1}, Lorg/lighttouch/android/QueueItem;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    goto :goto_9

    .line 190
    .restart local v2    # "$this$first\\7":Ljava/lang/Iterable;
    .restart local v8    # "$i$f$first\\7\\73":I
    :cond_10
    new-instance v4, Ljava/util/NoSuchElementException;

    invoke-direct {v4, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 73
    .end local v2    # "$this$first\\7":Ljava/lang/Iterable;
    .end local v8    # "$i$f$first\\7\\73":I
    :cond_11
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    :goto_9
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_a

    .line 74
    :cond_12
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " installed, "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " failed"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 70
    :goto_a
    return-object v1
.end method


# virtual methods
.method public discard(Ljava/io/File;)V
    .locals 1
    .param p1, "file"    # Ljava/io/File;

    const-string v0, "file"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v0}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    :cond_0
    return-void
.end method

.method public bridge synthetic fetch(Ljava/lang/Object;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)Ljava/io/File;
    .locals 1
    .param p1, "payload"    # Ljava/lang/Object;
    .param p2, "report"    # Lorg/lighttouch/android/QueueReport;
    .param p3, "cancelled"    # Lkotlin/jvm/functions/Function0;

    .line 28
    move-object v0, p1

    check-cast v0, Lorg/lighttouch/android/InstallRequest;

    invoke-virtual {p0, v0, p2, p3}, Lorg/lighttouch/android/StoreInstaller;->fetch(Lorg/lighttouch/android/InstallRequest;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)Ljava/io/File;

    move-result-object v0

    return-object v0
.end method

.method public fetch(Lorg/lighttouch/android/InstallRequest;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)Ljava/io/File;
    .locals 16
    .param p1, "payload"    # Lorg/lighttouch/android/InstallRequest;
    .param p2, "report"    # Lorg/lighttouch/android/QueueReport;
    .param p3, "cancelled"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/InstallRequest;",
            "Lorg/lighttouch/android/QueueReport;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/io/File;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const-string v0, "payload"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "report"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cancelled"

    move-object/from16 v9, p3

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 111
    iget-object v0, v1, Lorg/lighttouch/android/StoreInstaller;->socket:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_3

    move-object v10, v0

    .line 112
    .local v10, "socket":Ljava/lang/String;
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const-string v7, "\u51c6\u5907\u4e2d"

    invoke-interface {v3, v7, v0}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    .line 113
    move-object v0, v6

    invoke-direct {v1, v10}, Lorg/lighttouch/android/StoreInstaller;->exactTarget(Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;

    move-result-object v6

    .line 114
    .local v6, "target":Lorg/lighttouch/android/StoreTarget;
    nop

    .line 115
    instance-of v7, v2, Lorg/lighttouch/android/InstallRequest$Catalog;

    if-eqz v7, :cond_0

    .line 116
    new-instance v0, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    .line 117
    .local v0, "reported":Lkotlin/jvm/internal/Ref$LongRef;
    sget-object v4, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    move-object v5, v2

    check-cast v5, Lorg/lighttouch/android/InstallRequest$Catalog;

    invoke-virtual {v5}, Lorg/lighttouch/android/InstallRequest$Catalog;->getApp()Lorg/json/JSONObject;

    move-result-object v5

    new-instance v7, Ljava/io/File;

    iget-object v8, v1, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v8

    const-string v11, "store"

    invoke-direct {v7, v8, v11}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v8, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda4;

    invoke-direct {v8, v0, v3}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda4;-><init>(Lkotlin/jvm/internal/Ref$LongRef;Lorg/lighttouch/android/QueueReport;)V

    .line 124
    nop

    .line 117
    invoke-virtual/range {v4 .. v9}, Lorg/lighttouch/android/LegacyStore;->download(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;Ljava/io/File;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;)Ljava/io/File;

    move-result-object v4

    return-object v4

    .line 126
    .end local v0    # "reported":Lkotlin/jvm/internal/Ref$LongRef;
    :cond_0
    instance-of v7, v2, Lorg/lighttouch/android/InstallRequest$Local;

    if-eqz v7, :cond_2

    .line 127
    new-instance v7, Ljava/io/File;

    iget-object v8, v1, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v8

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v11

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "store/local-"

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v7, v8, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v8, v7

    .line 197
    .local v8, "$this$fetch_u24lambda_u2425\\1":Ljava/io/File;
    const/4 v9, 0x0

    .line 127
    .local v9, "$i$a$-apply-StoreInstaller$fetch$directory$1\\1\\127\\0":I
    invoke-virtual {v8}, Ljava/io/File;->mkdirs()Z

    .line 128
    .end local v8    # "$this$fetch_u24lambda_u2425\\1":Ljava/io/File;
    .end local v9    # "$i$a$-apply-StoreInstaller$fetch$directory$1\\1\\127\\0":I
    .local v7, "directory":Ljava/io/File;
    nop

    .line 129
    :try_start_0
    const-string v8, "\u6b63\u5728\u590d\u5236"

    invoke-interface {v3, v8, v0}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    .line 130
    new-instance v8, Ljava/io/File;

    const-string v9, "Source.ipa"

    invoke-direct {v8, v7, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 131
    .local v8, "copy":Ljava/io/File;
    iget-object v9, v1, Lorg/lighttouch/android/StoreInstaller;->context:Landroid/content/Context;

    invoke-virtual {v9}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v9

    move-object v11, v2

    check-cast v11, Lorg/lighttouch/android/InstallRequest$Local;

    invoke-virtual {v11}, Lorg/lighttouch/android/InstallRequest$Local;->getUri()Landroid/net/Uri;

    move-result-object v11

    invoke-virtual {v9, v11}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v9

    if-eqz v9, :cond_1

    check-cast v9, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    move-object v11, v9

    check-cast v11, Ljava/io/InputStream;

    .line 197
    .local v11, "input\\2":Ljava/io/InputStream;
    const/4 v12, 0x0

    .local v12, "$i$a$-use-StoreInstaller$fetch$2\\2\\131\\0":I
    new-instance v13, Ljava/io/FileOutputStream;

    .line 131
    invoke-direct {v13, v8}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v13, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v14, v13

    check-cast v14, Ljava/io/FileOutputStream;

    .line 197
    .local v14, "it\\3":Ljava/io/FileOutputStream;
    const/4 v15, 0x0

    .line 131
    .local v15, "$i$a$-use-StoreInstaller$fetch$2$1\\3\\131\\2":I
    move-object v0, v14

    check-cast v0, Ljava/io/OutputStream;

    const/4 v1, 0x0

    invoke-static {v11, v0, v5, v4, v1}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v14    # "it\\3":Ljava/io/FileOutputStream;
    .end local v15    # "$i$a$-use-StoreInstaller$fetch$2$1\\3\\131\\2":I
    :try_start_3
    invoke-static {v13, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .end local v11    # "input\\2":Ljava/io/InputStream;
    .end local v12    # "$i$a$-use-StoreInstaller$fetch$2\\2\\131\\0":I
    :try_start_4
    invoke-static {v9, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 133
    return-object v8

    .line 131
    .restart local v11    # "input\\2":Ljava/io/InputStream;
    .restart local v12    # "$i$a$-use-StoreInstaller$fetch$2\\2\\131\\0":I
    :catchall_0
    move-exception v0

    move-object v1, v0

    .end local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v7    # "directory":Ljava/io/File;
    .end local v8    # "copy":Ljava/io/File;
    .end local v10    # "socket":Ljava/lang/String;
    .end local v11    # "input\\2":Ljava/io/InputStream;
    .end local v12    # "$i$a$-use-StoreInstaller$fetch$2\\2\\131\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .end local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .end local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .end local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :try_start_5
    throw v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local v7    # "directory":Ljava/io/File;
    .restart local v8    # "copy":Ljava/io/File;
    .restart local v10    # "socket":Ljava/lang/String;
    .restart local v11    # "input\\2":Ljava/io/InputStream;
    .restart local v12    # "$i$a$-use-StoreInstaller$fetch$2\\2\\131\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .restart local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .restart local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .restart local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_1
    move-exception v0

    :try_start_6
    invoke-static {v13, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v7    # "directory":Ljava/io/File;
    .end local v8    # "copy":Ljava/io/File;
    .end local v10    # "socket":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .end local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .end local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .end local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .end local v11    # "input\\2":Ljava/io/InputStream;
    .end local v12    # "$i$a$-use-StoreInstaller$fetch$2\\2\\131\\0":I
    .restart local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local v7    # "directory":Ljava/io/File;
    .restart local v8    # "copy":Ljava/io/File;
    .restart local v10    # "socket":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .restart local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .restart local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .restart local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_2
    move-exception v0

    move-object v1, v0

    .end local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v7    # "directory":Ljava/io/File;
    .end local v8    # "copy":Ljava/io/File;
    .end local v10    # "socket":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .end local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .end local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .end local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :try_start_7
    throw v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .restart local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local v7    # "directory":Ljava/io/File;
    .restart local v8    # "copy":Ljava/io/File;
    .restart local v10    # "socket":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .restart local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .restart local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .restart local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_3
    move-exception v0

    :try_start_8
    invoke-static {v9, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v7    # "directory":Ljava/io/File;
    .end local v10    # "socket":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .end local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .end local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .end local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0

    .line 132
    .restart local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local v7    # "directory":Ljava/io/File;
    .restart local v10    # "socket":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .restart local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .restart local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .restart local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :cond_1
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u65e0\u6cd5\u8bfb\u53d6\u6240\u9009\u6587\u4ef6\u3002"

    const/4 v9, 0x0

    invoke-direct {v0, v1, v5, v4, v9}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v7    # "directory":Ljava/io/File;
    .end local v10    # "socket":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .end local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .end local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .end local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 134
    .end local v8    # "copy":Ljava/io/File;
    .restart local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local v7    # "directory":Ljava/io/File;
    .restart local v10    # "socket":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/StoreInstaller;
    .restart local p1    # "payload":Lorg/lighttouch/android/InstallRequest;
    .restart local p2    # "report":Lorg/lighttouch/android/QueueReport;
    .restart local p3    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    invoke-static {v7}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    throw v0

    .line 114
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v7    # "directory":Ljava/io/File;
    :cond_2
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    .line 111
    .end local v6    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v10    # "socket":Ljava/lang/String;
    :cond_3
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u542f\u52a8\u5ba2\u6237\u673a\u4ee5\u5b89\u88c5\u5e94\u7528\u3002"

    const/4 v9, 0x0

    invoke-direct {v0, v1, v5, v4, v9}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final getAvailable()Z
    .locals 1

    .line 32
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestApps;->getAvailable()Z

    move-result v0

    return v0
.end method

.method public final getOnChanged()Lkotlin/jvm/functions/Function1;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 39
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onChanged:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getOnIdle()Lkotlin/jvm/functions/Function0;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 42
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onIdle:Lkotlin/jvm/functions/Function0;

    return-object v0
.end method

.method public final getOnInstalled()Lkotlin/jvm/functions/Function1;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 40
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->onInstalled:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public final getQueue()Lorg/lighttouch/android/InstallQueue;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lorg/lighttouch/android/InstallQueue<",
            "Lorg/lighttouch/android/InstallRequest;",
            ">;"
        }
    .end annotation

    .line 31
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->queue:Lorg/lighttouch/android/InstallQueue;

    return-object v0
.end method

.method public final getSocket()Ljava/lang/String;
    .locals 1

    .line 35
    iget-object v0, p0, Lorg/lighttouch/android/StoreInstaller;->socket:Ljava/lang/String;

    return-object v0
.end method

.method public final getVisible()Z
    .locals 1

    .line 37
    iget-boolean v0, p0, Lorg/lighttouch/android/StoreInstaller;->visible:Z

    return v0
.end method

.method public bridge synthetic install(Ljava/lang/Object;Ljava/io/File;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .param p1, "payload"    # Ljava/lang/Object;
    .param p2, "file"    # Ljava/io/File;
    .param p3, "report"    # Lorg/lighttouch/android/QueueReport;
    .param p4, "cancelled"    # Lkotlin/jvm/functions/Function0;

    .line 28
    move-object v0, p1

    check-cast v0, Lorg/lighttouch/android/InstallRequest;

    invoke-virtual {p0, v0, p2, p3, p4}, Lorg/lighttouch/android/StoreInstaller;->install(Lorg/lighttouch/android/InstallRequest;Ljava/io/File;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public install(Lorg/lighttouch/android/InstallRequest;Ljava/io/File;Lorg/lighttouch/android/QueueReport;Lkotlin/jvm/functions/Function0;)V
    .locals 10
    .param p1, "payload"    # Lorg/lighttouch/android/InstallRequest;
    .param p2, "file"    # Ljava/io/File;
    .param p3, "report"    # Lorg/lighttouch/android/QueueReport;
    .param p4, "cancelled"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/InstallRequest;",
            "Ljava/io/File;",
            "Lorg/lighttouch/android/QueueReport;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v0, "payload"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "file"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "report"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cancelled"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    iget-object v2, p0, Lorg/lighttouch/android/StoreInstaller;->socket:Ljava/lang/String;

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x0

    if-eqz v2, :cond_4

    .line 141
    .local v2, "socket":Ljava/lang/String;
    invoke-direct {p0, v2}, Lorg/lighttouch/android/StoreInstaller;->exactTarget(Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;

    move-result-object v8

    .line 142
    .local v8, "target":Lorg/lighttouch/android/StoreTarget;
    const-string v3, "\u6b63\u5728\u6821\u9a8c\u5e94\u7528"

    invoke-interface {p3, v3, v7}, Lorg/lighttouch/android/QueueReport;->update(Ljava/lang/String;Ljava/lang/Float;)V

    .line 143
    new-instance v3, Ljava/io/File;

    invoke-virtual {p2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v4

    const-string v6, "Install.ipa"

    invoke-direct {v3, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 144
    .local v3, "prepared":Ljava/io/File;
    sget-object v4, Lorg/lighttouch/android/IpaPreflight;->INSTANCE:Lorg/lighttouch/android/IpaPreflight;

    invoke-virtual {v4, p2, v3, v8}, Lorg/lighttouch/android/IpaPreflight;->prepare(Ljava/io/File;Ljava/io/File;Lorg/lighttouch/android/StoreTarget;)Lorg/lighttouch/android/IpaInfo;

    move-result-object v9

    .line 145
    .local v9, "info":Lorg/lighttouch/android/IpaInfo;
    instance-of v4, p1, Lorg/lighttouch/android/InstallRequest$Local;

    if-eqz v4, :cond_0

    invoke-virtual {v9}, Lorg/lighttouch/android/IpaInfo;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-interface {p3, v4}, Lorg/lighttouch/android/QueueReport;->rename(Ljava/lang/String;)V

    .line 146
    :cond_0
    invoke-interface {p4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_3

    .line 147
    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v9}, Lorg/lighttouch/android/IpaInfo;->getBundleId()Ljava/lang/String;

    move-result-object v4

    new-instance v6, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda2;

    invoke-direct {v6, p3}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/QueueReport;)V

    move-object v5, p4

    invoke-virtual/range {v1 .. v6}, Lorg/lighttouch/android/GuestApps;->install(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lorg/json/JSONObject;

    .line 167
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/StoreInstaller;

    .line 197
    .local v0, "$this$install_u24lambda_u2430\\1":Lorg/lighttouch/android/StoreInstaller;
    const/4 v1, 0x0

    .line 167
    .local v1, "$i$a$-runCatching-StoreInstaller$install$2\\1\\167\\0":I
    iget-object v4, v0, Lorg/lighttouch/android/StoreInstaller;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v4, v2}, Lorg/lighttouch/android/GuestApps;->installedApps(Ljava/lang/String;)Ljava/util/List;

    move-result-object v4

    .end local v0    # "$this$install_u24lambda_u2430\\1":Lorg/lighttouch/android/StoreInstaller;
    .end local v1    # "$i$a$-runCatching-StoreInstaller$install$2\\1\\167\\0":I
    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    move-object v7, v0

    :goto_1
    check-cast v7, Ljava/util/List;

    if-eqz v7, :cond_2

    .line 197
    .local v7, "list\\2":Ljava/util/List;
    const/4 v0, 0x0

    .line 167
    .local v0, "$i$a$-let-StoreInstaller$install$3\\2\\167\\0":I
    iget-object v1, p0, Lorg/lighttouch/android/StoreInstaller;->main:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda3;

    invoke-direct {v4, p0, v7}, Lorg/lighttouch/android/StoreInstaller$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/StoreInstaller;Ljava/util/List;)V

    invoke-virtual {v1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 168
    .end local v0    # "$i$a$-let-StoreInstaller$install$3\\2\\167\\0":I
    .end local v7    # "list\\2":Ljava/util/List;
    :cond_2
    return-void

    .line 146
    :cond_3
    new-instance v4, Lorg/lighttouch/android/StoreError;

    const-string v5, "\u5df2\u53d6\u6d88"

    invoke-direct {v4, v5, v1, v0, v7}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4

    .line 140
    .end local v2    # "socket":Ljava/lang/String;
    .end local v3    # "prepared":Ljava/io/File;
    .end local v8    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local v9    # "info":Lorg/lighttouch/android/IpaInfo;
    :cond_4
    new-instance v2, Lorg/lighttouch/android/StoreError;

    const-string v3, "The guest stopped. Start it to install apps."

    invoke-direct {v2, v3, v1, v0, v7}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v2
.end method

.method public final setOnChanged(Lkotlin/jvm/functions/Function1;)V
    .locals 1
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    iput-object p1, p0, Lorg/lighttouch/android/StoreInstaller;->onChanged:Lkotlin/jvm/functions/Function1;

    return-void
.end method

.method public final setOnIdle(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 42
    iput-object p1, p0, Lorg/lighttouch/android/StoreInstaller;->onIdle:Lkotlin/jvm/functions/Function0;

    return-void
.end method

.method public final setOnInstalled(Lkotlin/jvm/functions/Function1;)V
    .locals 1
    .param p1, "<set-?>"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    iput-object p1, p0, Lorg/lighttouch/android/StoreInstaller;->onInstalled:Lkotlin/jvm/functions/Function1;

    return-void
.end method

.method public final setSocket(Ljava/lang/String;)V
    .locals 0
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 35
    iput-object p1, p0, Lorg/lighttouch/android/StoreInstaller;->socket:Ljava/lang/String;

    return-void
.end method

.method public final setVisible(Z)V
    .locals 0
    .param p1, "<set-?>"    # Z

    .line 37
    iput-boolean p1, p0, Lorg/lighttouch/android/StoreInstaller;->visible:Z

    return-void
.end method

.class final Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;
.super Ljava/lang/Object;
.source "PrepareScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/PrepareScreenKt;->FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPrepareScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt$FilesStep$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,416:1\n149#2:417\n149#2:430\n149#2:432\n149#2:433\n149#2:475\n1225#3,6:418\n1225#3,6:424\n1#4:431\n99#5:434\n95#5,7:435\n102#5:470\n106#5:474\n79#6,6:442\n86#6,4:457\n90#6,2:467\n94#6:473\n368#7,9:448\n377#7:469\n378#7,2:471\n4034#8,6:461\n*S KotlinDebug\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt$FilesStep$1\n*L\n282#1:417\n289#1:430\n293#1:432\n294#1:433\n301#1:475\n283#1:418,6\n285#1:424,6\n294#1:434\n294#1:435,7\n294#1:470\n294#1:474\n294#1:442,6\n294#1:457,4\n294#1:467,2\n294#1:473\n294#1:448,9\n294#1:469\n294#1:471,2\n294#1:461,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $busy:Z

.field final synthetic $firmware:Lorg/lighttouch/android/CatalogFirmware;

.field final synthetic $onChooseIpsw:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $onDownload:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $state:Lorg/lighttouch/android/PrepareState;


# direct methods
.method public static synthetic $r8$lambda$AxnioVm7o41fjUAQzC2NBtWal-o()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->invoke$lambda$3$lambda$2()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$gzKKnB6YnNr5oLdWv4PcNTaJ2ZE()F
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->invoke$lambda$1$lambda$0()F

    move-result v0

    return v0
.end method

.method constructor <init>(Lorg/lighttouch/android/CatalogFirmware;Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/CatalogFirmware;",
            "Lorg/lighttouch/android/PrepareState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$firmware:Lorg/lighttouch/android/CatalogFirmware;

    iput-object p2, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$state:Lorg/lighttouch/android/PrepareState;

    iput-object p3, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$onChooseIpsw:Lkotlin/jvm/functions/Function0;

    iput-boolean p4, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$busy:Z

    iput-object p5, p0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$onDownload:Lkotlin/jvm/functions/Function0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0()F
    .locals 1

    .line 283
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v0}, Lorg/lighttouch/android/IpswDownload;->getProgress()F

    move-result v0

    return v0
.end method

.method private static final invoke$lambda$3$lambda$2()Lkotlin/Unit;
    .locals 1

    .line 285
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v0}, Lorg/lighttouch/android/IpswDownload;->cancel()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 276
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 41
    .param p1, "$this$Card"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v8, p2

    move/from16 v14, p3

    const-string v1, "$this$Card"

    move-object/from16 v15, p1

    invoke-static {v15, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C:PrepareScreen.kt#o13vsk"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v14, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 291
    :cond_0
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_10

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.FilesStep.<anonymous> (PrepareScreen.kt:276)"

    const v3, 0x13ae2071

    invoke-static {v3, v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 277
    :cond_2
    sget-object v1, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v1}, Lorg/lighttouch/android/IpswDownload;->getRunning()Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_3

    sget-object v1, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v1}, Lorg/lighttouch/android/IpswDownload;->getFirmwareId()Ljava/lang/String;

    move-result-object v1

    iget-object v4, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$firmware:Lorg/lighttouch/android/CatalogFirmware;

    invoke-virtual {v4}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    move v1, v3

    goto :goto_1

    :cond_3
    move v1, v2

    :goto_1
    move/from16 v26, v1

    .line 278
    .local v26, "downloading":Z
    nop

    .line 279
    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v1

    if-eqz v1, :cond_4

    const v1, -0x1f58265b

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "278@17300L84"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$onChooseIpsw:Lkotlin/jvm/functions/Function0;

    iget-boolean v2, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$busy:Z

    xor-int/2addr v3, v2

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$2138285340$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const/high16 v12, 0x30000000

    const/16 v13, 0x1fa

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v11, p2

    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object v8, v11

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_f

    .line 280
    :cond_4
    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v26, :cond_8

    const v6, 0x345545c8

    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "280@17478L10,280@17522L11,280@17430L121,281@17568L29,284@17841L25,284@17820L131"

    invoke-static {v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 281
    sget-object v6, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v6}, Lorg/lighttouch/android/IpswDownload;->getStatus()Ljava/lang/String;

    move-result-object v6

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v8, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v8, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v9

    const/16 v24, 0x0

    const v25, 0xfffa

    move v7, v2

    const/4 v2, 0x0

    move-object v11, v1

    move v12, v5

    move-object v1, v6

    const-wide/16 v5, 0x0

    move v13, v7

    const/4 v7, 0x0

    const/4 v8, 0x0

    move/from16 v16, v3

    move-wide/from16 v39, v9

    move v10, v4

    move-wide/from16 v3, v39

    const/4 v9, 0x0

    move/from16 v18, v10

    move-object/from16 v17, v11

    const-wide/16 v10, 0x0

    move/from16 v19, v12

    const/4 v12, 0x0

    move/from16 v20, v13

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    move/from16 v22, v16

    const/16 v16, 0x0

    move-object/from16 v23, v17

    const/16 v17, 0x0

    move/from16 v27, v18

    const/16 v18, 0x0

    move/from16 v28, v19

    const/16 v19, 0x0

    move/from16 v29, v20

    const/16 v20, 0x0

    move-object/from16 v30, v23

    const/16 v23, 0x0

    move-object/from16 v22, p2

    move/from16 v0, v28

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 282
    move-object/from16 v8, v22

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 417
    .local v3, "$i$f$getDp\\1\\282":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 282
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\282":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v8, v0}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 283
    sget-object v0, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v0}, Lorg/lighttouch/android/IpswDownload;->getProgress()F

    move-result v0

    cmpl-float v0, v0, v27

    const-string v13, "CC(remember):PrepareScreen.kt#9igjgp"

    const v14, 0x6e3c21fe

    if-ltz v0, :cond_6

    const v0, -0x1f57faf9

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "282@17682L25,282@17647L86"

    invoke-static {v8, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\2":Z
    move-object/from16 v1, p2

    .local v1, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 418
    .local v2, "$i$f$cache\\2\\283":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\2":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 419
    .local v4, "$i$a$-let-ComposerKt$cache$1\\3\\418\\2":I
    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_5

    .line 420
    const/4 v5, 0x0

    .local v5, "$i$a$-cache-PrepareScreenKt$FilesStep$1$1\\4\\420\\0":I
    new-instance v6, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1$$ExternalSyntheticLambda0;

    invoke-direct {v6}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1$$ExternalSyntheticLambda0;-><init>()V

    .line 421
    .end local v5    # "$i$a$-cache-PrepareScreenKt$FilesStep$1$1\\4\\420\\0":I
    .local v6, "value\\3":Ljava/lang/Object;
    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 422
    nop

    .end local v6    # "value\\3":Ljava/lang/Object;
    goto :goto_2

    .line 423
    :cond_5
    move-object v6, v3

    .line 419
    :goto_2
    nop

    .line 418
    .end local v3    # "it\\2":Ljava/lang/Object;
    .end local v4    # "$i$a$-let-ComposerKt$cache$1\\3\\418\\2":I
    nop

    .line 283
    .end local v0    # "invalid\\2":Z
    .end local v1    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$f$cache\\2\\283":I
    move-object v1, v6

    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    move/from16 v10, v27

    const/4 v2, 0x1

    const/4 v11, 0x0

    invoke-static {v0, v10, v2, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v11, 0x36

    const/16 v12, 0x7c

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v10, p2

    invoke-static/range {v1 .. v12}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    move-object v8, v10

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_3

    .line 284
    :cond_6
    const/4 v2, 0x1

    const v0, -0x1f57ed9f

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "283@17755L48"

    invoke-static {v8, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v0, v10, v2, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v9, 0x6

    const/16 v10, 0x1e

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v10}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_3
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 285
    move-object/from16 v0, p2

    .local v0, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .local v29, "invalid\\5":Z
    const/4 v1, 0x0

    .line 424
    .local v1, "$i$f$cache\\5\\285":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\5":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 425
    .local v3, "$i$a$-let-ComposerKt$cache$1\\6\\424\\5":I
    sget-object v4, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v4}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v2, v4, :cond_7

    .line 426
    const/4 v4, 0x0

    .local v4, "$i$a$-cache-PrepareScreenKt$FilesStep$1$2\\7\\426\\0":I
    new-instance v5, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1$$ExternalSyntheticLambda1;

    invoke-direct {v5}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1$$ExternalSyntheticLambda1;-><init>()V

    .line 427
    .end local v4    # "$i$a$-cache-PrepareScreenKt$FilesStep$1$2\\7\\426\\0":I
    .local v5, "value\\6":Ljava/lang/Object;
    invoke-interface {v0, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 428
    nop

    .end local v5    # "value\\6":Ljava/lang/Object;
    goto :goto_4

    .line 429
    :cond_7
    move-object v5, v2

    .line 425
    :goto_4
    nop

    .line 424
    .end local v2    # "it\\5":Ljava/lang/Object;
    .end local v3    # "$i$a$-let-ComposerKt$cache$1\\6\\424\\5":I
    nop

    .line 285
    .end local v0    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v1    # "$i$f$cache\\5\\285":I
    .end local v29    # "invalid\\5":Z
    move-object v1, v5

    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v2, "prepare_cancel_download"

    invoke-static {v0, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$1460951763$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const v12, 0x30000036

    const/16 v13, 0x1fc

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v11, p2

    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 280
    move-object v8, v11

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_f

    .line 287
    :cond_8
    move/from16 v29, v2

    move v2, v3

    move v0, v5

    move-object/from16 v1, p0

    iget-object v3, v1, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3}, Lorg/lighttouch/android/PrepareState;->getIpswChecking()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_9

    move v3, v2

    goto :goto_5

    :cond_9
    move/from16 v3, v29

    :goto_5
    if-eqz v3, :cond_a

    const v3, 0x345e39b9

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "287@18078L10,287@18122L11,287@18031L120,288@18168L29,288@18199L48"

    invoke-static {v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 288
    iget-object v3, v1, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3}, Lorg/lighttouch/android/PrepareState;->getIpswChecking()Ljava/lang/String;

    move-result-object v3

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v8, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v8, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v4

    const/16 v24, 0x0

    const v25, 0xfffa

    move/from16 v31, v2

    const/4 v2, 0x0

    move-object v1, v3

    move-wide v3, v4

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 289
    move-object/from16 v8, v22

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\8":I
    const/4 v3, 0x0

    .line 430
    .local v3, "$i$f$getDp\\8\\289":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 289
    .end local v2    # "$this$dp\\8":I
    .end local v3    # "$i$f$getDp\\8\\289":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v8, v0}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v0, v10, v1, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v9, 0x6

    const/16 v10, 0x1e

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v10}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    .line 287
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_f

    .line 291
    :cond_a
    move v1, v2

    const/4 v11, 0x0

    const v2, 0x3462b573

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "293@18602L516,300@19313L10,300@19357L11,299@19135L251"

    invoke-static {v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 292
    move-object/from16 v2, p0

    iget-object v3, v2, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$state:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3}, Lorg/lighttouch/android/PrepareState;->getIpswError()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    iget-object v4, v2, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$firmware:Lorg/lighttouch/android/CatalogFirmware;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-nez v5, :cond_b

    move v5, v1

    goto :goto_6

    :cond_b
    move/from16 v5, v29

    :goto_6
    if-eqz v5, :cond_e

    .line 431
    const/4 v3, 0x0

    .line 292
    .local v3, "$i$a$-ifEmpty-PrepareScreenKt$FilesStep$1$error$1\\9\\292\\0":I
    sget-object v5, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v5}, Lorg/lighttouch/android/IpswDownload;->getStatus()Ljava/lang/String;

    move-result-object v5

    move-object v6, v5

    .line 431
    .local v6, "it\\10":Ljava/lang/String;
    const/4 v7, 0x0

    .line 292
    .local v7, "$i$a$-takeIf-PrepareScreenKt$FilesStep$1$error$1$1\\10\\292\\9":I
    sget-object v9, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v9}, Lorg/lighttouch/android/IpswDownload;->getFirmwareId()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v4

    invoke-static {v9, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .end local v6    # "it\\10":Ljava/lang/String;
    .end local v7    # "$i$a$-takeIf-PrepareScreenKt$FilesStep$1$error$1$1\\10\\292\\9":I
    if-eqz v4, :cond_c

    goto :goto_7

    :cond_c
    move-object v5, v11

    :goto_7
    if-nez v5, :cond_d

    const-string v4, ""

    move-object v3, v4

    goto :goto_8

    :cond_d
    move-object v3, v5

    .end local v3    # "$i$a$-ifEmpty-PrepareScreenKt$FilesStep$1$error$1\\9\\292\\0":I
    :cond_e
    :goto_8
    check-cast v3, Ljava/lang/String;

    .local v3, "error":Ljava/lang/String;
    const v4, -0x1f579896

    invoke-interface {v8, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "292@18523L10,292@18567L11,292@18456L129"

    invoke-static {v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 293
    move-object v4, v3

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_f

    move v4, v1

    goto :goto_9

    :cond_f
    move/from16 v4, v29

    :goto_9
    if-eqz v4, :cond_10

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v9, v4

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\11":I
    const/4 v5, 0x0

    .line 432
    .local v5, "$i$f$getDp\\11\\293":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 293
    .end local v4    # "$this$dp\\11":I
    .end local v5    # "$i$f$getDp\\11\\293":I
    const/4 v14, 0x7

    const/4 v15, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v9 .. v15}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v8, v6}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v8, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v5

    const/16 v24, 0x0

    const v25, 0xfff8

    move/from16 v31, v1

    move-object v1, v3

    move-object v2, v4

    move-wide v3, v5

    .end local v3    # "error":Ljava/lang/String;
    .local v1, "error":Ljava/lang/String;
    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x30

    move-object/from16 v22, p2

    move/from16 v28, v0

    move-object/from16 v0, p0

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v27, v1

    move-object/from16 v8, v22

    .end local v1    # "error":Ljava/lang/String;
    .local v27, "error":Ljava/lang/String;
    goto :goto_a

    .end local v27    # "error":Ljava/lang/String;
    .restart local v3    # "error":Ljava/lang/String;
    :cond_10
    move/from16 v28, v0

    move/from16 v31, v1

    move-object v0, v2

    move-object/from16 v27, v3

    .end local v3    # "error":Ljava/lang/String;
    .restart local v27    # "error":Ljava/lang/String;
    :goto_a
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 294
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v2, 0x8

    .local v2, "$this$dp\\12":I
    const/4 v3, 0x0

    .line 433
    .local v3, "$i$f$getDp\\12\\294":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 294
    .end local v2    # "$this$dp\\12":I
    .end local v3    # "$i$f$getDp\\12\\294":I
    invoke-virtual {v1, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v1, "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-boolean v2, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$busy:Z

    iget-object v9, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$onDownload:Lkotlin/jvm/functions/Function0;

    iget-object v3, v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;->$onChooseIpsw:Lkotlin/jvm/functions/Function0;

    const/16 v4, 0x30

    .local v4, "$changed\\13":I
    const/4 v5, 0x0

    .line 434
    .local v5, "$i$f$Row\\13\\294":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v8, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 435
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 437
    .local v6, "modifier\\13":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 440
    .local v7, "verticalAlignment\\13":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v1, v7, v8, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 441
    move/from16 v23, v11

    .local v23, "$changed\\14":I
    const/16 v24, 0x0

    .line 442
    .local v24, "$i$f$Layout\\14\\441":I
    const v11, -0x4ee9b9da

    const-string v12, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v8, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 443
    move/from16 v13, v29

    invoke-static {v8, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v25

    .line 444
    .local v25, "compositeKeyHash\\14":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 445
    .local v11, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 447
    .local v12, "materialized\\14":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v14

    shl-int/lit8 v15, v23, 0x6

    and-int/lit16 v15, v15, 0x380

    or-int/lit8 v15, v15, 0x6

    .line 446
    move/from16 v29, v15

    .local v14, "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v29, "$changed\\15":I
    const/16 v30, 0x0

    .line 448
    .local v30, "$i$f$ReusableComposeNode\\15\\446":I
    const v15, -0x2942ffcf

    const-string v13, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v8, v15, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 449
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v13

    instance-of v13, v13, Landroidx/compose/runtime/Applier;

    if-nez v13, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 450
    :cond_11
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 451
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v13

    if-eqz v13, :cond_12

    .line 452
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b

    .line 454
    :cond_12
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 456
    :goto_b
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .local v13, "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 457
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\456\\14":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 458
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v11, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 460
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\17":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 461
    .local v16, "$i$f$set-impl\\17\\460":I
    move-object/from16 v17, v13

    .local v17, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 462
    .local v18, "$i$a$-with-Updater$set$1\\18\\461\\17":I
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v19

    if-nez v19, :cond_14

    move-object/from16 v32, v1

    .end local v1    # "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v32, "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v22, v2

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    goto :goto_c

    :cond_13
    move-object/from16 v2, v17

    goto :goto_d

    .end local v32    # "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v1    # "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_14
    move-object/from16 v32, v1

    move/from16 v22, v2

    .line 463
    .end local v1    # "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v32    # "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_c
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v17

    .end local v17    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 464
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v13, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 466
    :goto_d
    nop

    .line 461
    .end local v2    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-with-Updater$set$1\\18\\461\\17":I
    nop

    .line 466
    nop

    .line 467
    .end local v0    # "block\\17":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\17\\460":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 468
    nop

    .line 456
    .end local v13    # "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\456\\14":I
    nop

    .line 469
    shr-int/lit8 v0, v29, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\19":I
    move-object/from16 v1, p2

    .local v1, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 470
    .local v2, "$i$a$-Layout-RowKt$Row$1\\19\\469\\13":I
    const v13, -0x184f2606

    const-string v15, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v13, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v13, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v15, v4, 0x6

    and-int/lit8 v15, v15, 0x70

    or-int/lit8 v28, v15, 0x6

    .local v28, "$changed\\20":I
    check-cast v13, Landroidx/compose/foundation/layout/RowScope;

    .local v13, "$this$invoke_u24lambda_u246\\20":Landroidx/compose/foundation/layout/RowScope;
    move-object v15, v1

    .local v15, "$composer\\20":Landroidx/compose/runtime/Composer;
    move-object/from16 v33, v13

    .end local v13    # "$this$invoke_u24lambda_u246\\20":Landroidx/compose/foundation/layout/RowScope;
    .local v33, "$this$invoke_u24lambda_u246\\20":Landroidx/compose/foundation/layout/RowScope;
    const/16 v34, 0x0

    .line 295
    .local v34, "$i$a$-Row-PrepareScreenKt$FilesStep$1$3\\20\\470\\0":I
    const v13, 0x1e5cf733

    move/from16 v35, v0

    .end local v0    # "$changed\\19":I
    .local v35, "$changed\\19":I
    const-string v0, "C294@18680L266,297@18967L133:PrepareScreen.kt#o13vsk"

    invoke-static {v15, v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    if-nez v22, :cond_15

    sget-object v0, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    invoke-virtual {v0}, Lorg/lighttouch/android/IpswDownload;->getRunning()Z

    move-result v0

    if-nez v0, :cond_15

    move/from16 v20, v31

    goto :goto_e

    :cond_15
    const/16 v20, 0x0

    :goto_e
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v13, "prepare_download"

    invoke-static {v0, v13}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v13, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v13}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-1593412740$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v18

    move-object v13, v11

    move/from16 v11, v20

    .end local v11    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v13, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    const v20, 0x30000030

    const/16 v21, 0x1f8

    move-object/from16 v16, v12

    .end local v12    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .local v16, "materialized\\14":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v17, v13

    .end local v13    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v17, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v13, 0x0

    move-object/from16 v19, v14

    .end local v14    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v19, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/4 v14, 0x0

    move-object/from16 v36, v19

    move-object/from16 v19, v15

    .end local v15    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v36, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/4 v15, 0x0

    move-object/from16 v37, v16

    .end local v16    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .local v37, "materialized\\14":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    move-object/from16 v38, v17

    .end local v17    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v38, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v17, 0x0

    move-object/from16 v39, v10

    move-object v10, v0

    move-object/from16 v0, v39

    .end local v10    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v0, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v9 .. v21}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 298
    xor-int/lit8 v12, v22, 0x1

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const-string v10, "prepare_choose_ipsw"

    invoke-static {v9, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    sget-object v9, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v9}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$1656419770$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const v21, 0x30000030

    const/16 v22, 0x1f8

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object v10, v3

    move-object/from16 v20, v19

    move-object/from16 v19, v9

    .end local v19    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v22}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 295
    move-object/from16 v19, v20

    .end local v20    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v19    # "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static/range {v19 .. v19}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 299
    nop

    .line 470
    .end local v19    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v28    # "$changed\\20":I
    .end local v33    # "$this$invoke_u24lambda_u246\\20":Landroidx/compose/foundation/layout/RowScope;
    .end local v34    # "$i$a$-Row-PrepareScreenKt$FilesStep$1$3\\20\\470\\0":I
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 469
    .end local v1    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$a$-Layout-RowKt$Row$1\\19\\469\\13":I
    .end local v35    # "$changed\\19":I
    nop

    .line 471
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 448
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 472
    nop

    .line 442
    .end local v29    # "$changed\\15":I
    .end local v30    # "$i$f$ReusableComposeNode\\15\\446":I
    .end local v36    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 473
    nop

    .line 434
    .end local v23    # "$changed\\14":I
    .end local v24    # "$i$f$Layout\\14\\441":I
    .end local v25    # "compositeKeyHash\\14":I
    .end local v37    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .end local v38    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 474
    nop

    .line 301
    .end local v0    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "$changed\\13":I
    .end local v5    # "$i$f$Row\\13\\294":I
    .end local v6    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v7    # "verticalAlignment\\13":Landroidx/compose/ui/Alignment$Vertical;
    .end local v32    # "horizontalArrangement\\13":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v1, v0

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v0, 0x8

    .local v0, "$this$dp\\21":I
    const/4 v2, 0x0

    .line 475
    .local v2, "$i$f$getDp\\21\\301":I
    int-to-float v3, v0

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 301
    .end local v0    # "$this$dp\\21":I
    .end local v2    # "$i$f$getDp\\21\\301":I
    const/16 v6, 0xd

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v8, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v8, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    .line 300
    nop

    .line 301
    nop

    .line 300
    const-string v1, "ipsw.me \u6709\u6536\u5f55\u65f6\u4ece Apple \u670d\u52a1\u5668\u4e0b\u8f7d\uff0c\u5426\u5219\u4ece Internet Archive \u4e0b\u8f7d\u3002"

    const-wide/16 v5, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x36

    const/16 v24, 0x0

    const v25, 0xfff8

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 291
    .end local v27    # "error":Ljava/lang/String;
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 304
    .end local v26    # "downloading":Z
    :cond_16
    :goto_10
    return-void
.end method

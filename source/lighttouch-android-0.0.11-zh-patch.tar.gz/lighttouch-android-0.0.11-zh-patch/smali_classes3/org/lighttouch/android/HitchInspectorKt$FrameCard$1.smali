.class final Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;
.super Ljava/lang/Object;
.source "HitchInspector.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/HitchInspectorKt;->FrameCard(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHitchInspector.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/HitchInspectorKt$FrameCard$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 8 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 9 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,342:1\n149#2:343\n149#2:417\n149#2:418\n149#2:423\n149#2:425\n149#2:427\n86#3:344\n83#3,6:345\n89#3:379\n93#3:431\n79#4,6:351\n86#4,4:366\n90#4,2:376\n79#4,6:388\n86#4,4:403\n90#4,2:413\n94#4:421\n94#4:430\n79#4,6:440\n86#4,4:455\n90#4,2:465\n94#4:471\n368#5,9:357\n377#5:378\n368#5,9:394\n377#5:415\n378#5,2:419\n378#5,2:428\n368#5,9:446\n377#5:467\n378#5,2:469\n4034#6,6:370\n4034#6,6:407\n4034#6,6:459\n99#7:380\n95#7,7:381\n102#7:416\n106#7:422\n99#7:432\n95#7,7:433\n102#7:468\n106#7:472\n1#8:424\n1068#9:426\n*S KotlinDebug\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/HitchInspectorKt$FrameCard$1\n*L\n286#1:343\n288#1:417\n289#1:418\n294#1:423\n319#1:425\n323#1:427\n286#1:344\n286#1:345,6\n286#1:379\n286#1:431\n286#1:351,6\n286#1:366,4\n286#1:376,2\n287#1:388,6\n287#1:403,4\n287#1:413,2\n287#1:421\n286#1:430\n295#1:440,6\n295#1:455,4\n295#1:465,2\n295#1:471\n286#1:357,9\n286#1:378\n287#1:394,9\n287#1:415\n287#1:419,2\n286#1:428,2\n295#1:446,9\n295#1:467\n295#1:469,2\n286#1:370,6\n287#1:407,6\n295#1:459,6\n287#1:380\n287#1:381,7\n287#1:416\n287#1:422\n295#1:432\n295#1:433,7\n295#1:468\n295#1:472\n321#1:426\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $b:Lorg/lighttouch/android/FrameBreakdown;

.field final synthetic $data:Lorg/lighttouch/android/HitchData;

.field final synthetic $frame:Lorg/lighttouch/android/HitchFrame;


# direct methods
.method constructor <init>(Lorg/lighttouch/android/HitchFrame;Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/FrameBreakdown;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->$frame:Lorg/lighttouch/android/HitchFrame;

    iput-object p2, p0, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->$data:Lorg/lighttouch/android/HitchData;

    iput-object p3, p0, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->$b:Lorg/lighttouch/android/FrameBreakdown;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 48
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "value"    # Ljava/lang/String;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const v2, -0xd535bf9

    invoke-interface {v0, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "C(line)294@17966L252:HitchInspector.kt#o13vsk"

    invoke-static {v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, -0x1

    const-string v4, "org.lighttouch.android.FrameCard.<anonymous>.<anonymous>.line (HitchInspector.kt:294)"

    invoke-static {v2, v1, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 295
    :cond_0
    const/4 v2, 0x0

    move v3, v2

    .local v3, "$changed\\1":I
    const/4 v4, 0x0

    .line 432
    .local v4, "$i$f$Row\\1\\295":I
    const v5, 0x2952b718

    const-string v6, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v0, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 433
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 434
    .local v5, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 435
    .local v6, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 438
    .local v7, "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v8, v3, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v9, v3, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v8, v9

    invoke-static {v6, v7, v0, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v3, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 439
    nop

    .local v9, "$changed\\2":I
    const/4 v10, 0x0

    .line 440
    .local v10, "$i$f$Layout\\2\\439":I
    const v11, -0x4ee9b9da

    const-string v12, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v0, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 441
    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v2

    .line 442
    .local v2, "compositeKeyHash\\2":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 443
    .local v11, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v0, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 445
    .local v12, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v9, 0x6

    and-int/lit16 v14, v14, 0x380

    or-int/lit8 v14, v14, 0x6

    .line 444
    nop

    .local v13, "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v14, "$changed\\3":I
    const/4 v15, 0x0

    .line 446
    .local v15, "$i$f$ReusableComposeNode\\3\\444":I
    const v1, -0x2942ffcf

    move/from16 v16, v2

    .end local v2    # "compositeKeyHash\\2":I
    .local v16, "compositeKeyHash\\2":I
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 447
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 448
    :cond_1
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 449
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 450
    invoke-interface {v0, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_0

    .line 452
    :cond_2
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 454
    :goto_0
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 455
    .local v2, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 456
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v11, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 458
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 459
    .local v17, "$i$f$set-impl\\5\\458":I
    move-object/from16 v18, v1

    .local v18, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 460
    .local v19, "$i$a$-with-Updater$set$1\\6\\459\\5":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v20

    if-nez v20, :cond_4

    move/from16 v20, v2

    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v21, v3

    .end local v3    # "$changed\\1":I
    .local v21, "$changed\\1":I
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    goto :goto_1

    :cond_3
    move-object/from16 v3, v18

    goto :goto_2

    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    .end local v21    # "$changed\\1":I
    .restart local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    .restart local v3    # "$changed\\1":I
    :cond_4
    move/from16 v20, v2

    move/from16 v21, v3

    .line 461
    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    .end local v3    # "$changed\\1":I
    .restart local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    .restart local v21    # "$changed\\1":I
    :goto_1
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 462
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 464
    :goto_2
    nop

    .line 459
    .end local v3    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-with-Updater$set$1\\6\\459\\5":I
    nop

    .line 464
    nop

    .line 465
    .end local v0    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\5\\458":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 466
    nop

    .line 454
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\454\\2":I
    nop

    .line 467
    shr-int/lit8 v0, v14, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object/from16 v1, p2

    .local v1, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 468
    .local v2, "$i$a$-Layout-RowKt$Row$1\\7\\467\\1":I
    const v3, -0x184f2606

    move/from16 v17, v0

    .end local v0    # "$changed\\7":I
    .local v17, "$changed\\7":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v3, v21, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\8":I
    move-object/from16 v22, v0

    check-cast v22, Landroidx/compose/foundation/layout/RowScope;

    .local v22, "$this$invoke_u24lambda_u244_u24line_u24lambda_u241\\8":Landroidx/compose/foundation/layout/RowScope;
    move-object v0, v1

    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 296
    .local v18, "$i$a$-Row-HitchInspectorKt$FrameCard$1$1$line$1\\8\\468\\0":I
    move-object/from16 v19, v1

    .end local v1    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\7":Landroidx/compose/runtime/Composer;
    const v1, 0x7c3640a0

    move/from16 v20, v2

    .end local v2    # "$i$a$-Layout-RowKt$Row$1\\7\\467\\1":I
    .local v20, "$i$a$-Layout-RowKt$Row$1\\7\\467\\1":I
    const-string v2, "C295@18042L10,295@18086L11,295@17988L127,296@18166L10,296@18132L72:HitchInspector.kt#o13vsk"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v23, v1

    check-cast v23, Landroidx/compose/ui/Modifier;

    const/16 v26, 0x2

    const/16 v27, 0x0

    const/high16 v24, 0x3f800000    # 1.0f

    const/16 v25, 0x0

    invoke-static/range {v22 .. v27}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v24

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v43

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v25

    and-int/lit8 v45, p3, 0xe

    const/16 v46, 0x0

    const v47, 0xfff8

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const-wide/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    move-object/from16 v23, p0

    move-object/from16 v44, v0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v47}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 297
    move-object/from16 v1, v44

    .end local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v1, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v0

    invoke-static {}, Lorg/lighttouch/android/ThemeKt;->getMonoStyle()Landroidx/compose/ui/text/TextStyle;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroidx/compose/ui/text/TextStyle;->merge(Landroidx/compose/ui/text/TextStyle;)Landroidx/compose/ui/text/TextStyle;

    move-result-object v43

    shr-int/lit8 v0, p3, 0x3

    and-int/lit8 v45, v0, 0xe

    const v47, 0xfffe

    const/16 v24, 0x0

    const-wide/16 v25, 0x0

    move-object/from16 v23, p1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v47}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 296
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 298
    nop

    .line 468
    .end local v3    # "$changed\\8":I
    .end local v18    # "$i$a$-Row-HitchInspectorKt$FrameCard$1$1$line$1\\8\\468\\0":I
    .end local v22    # "$this$invoke_u24lambda_u244_u24line_u24lambda_u241\\8":Landroidx/compose/foundation/layout/RowScope;
    .end local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v19 .. v19}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 467
    .end local v17    # "$changed\\7":I
    .end local v19    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-Layout-RowKt$Row$1\\7\\467\\1":I
    nop

    .line 469
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 446
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 470
    nop

    .line 440
    .end local v13    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v14    # "$changed\\3":I
    .end local v15    # "$i$f$ReusableComposeNode\\3\\444":I
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 471
    nop

    .line 432
    .end local v9    # "$changed\\2":I
    .end local v10    # "$i$f$Layout\\2\\439":I
    .end local v11    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v16    # "compositeKeyHash\\2":I
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 472
    nop

    .end local v4    # "$i$f$Row\\1\\295":I
    .end local v5    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v6    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v7    # "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    .end local v8    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v21    # "$changed\\1":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_5
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 298
    return-void
.end method

.method private static final invoke$lambda$4$ms(F)Ljava/lang/String;
    .locals 3
    .param p0, "v"    # F

    .line 299
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.2f ms"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 285
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 83
    .param p1, "$this$Card"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$Card"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C285@17111L3160:HitchInspector.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 431
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_b

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.FrameCard.<anonymous> (HitchInspector.kt:285)"

    const v6, 0x71a10bf9

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 286
    :cond_2
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v5, 0xe

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 343
    .local v6, "$i$f$getDp\\1\\286":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 286
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\286":I
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\2":Landroidx/compose/ui/Modifier;
    iget-object v5, v0, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->$frame:Lorg/lighttouch/android/HitchFrame;

    iget-object v6, v0, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->$data:Lorg/lighttouch/android/HitchData;

    iget-object v7, v0, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->$b:Lorg/lighttouch/android/FrameBreakdown;

    const/4 v8, 0x6

    .local v8, "$changed\\2":I
    const/4 v9, 0x0

    .line 344
    .local v9, "$i$f$Column\\2\\286":I
    const v10, -0x1cd0f17e

    const-string v11, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v1, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 345
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v10

    .line 346
    .local v10, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v11

    .line 349
    .local v11, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v12, v8, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v8, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v10, v11, v1, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v8, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 350
    nop

    .local v13, "$changed\\3":I
    const/4 v14, 0x0

    .line 351
    .local v14, "$i$f$Layout\\3\\350":I
    const v15, -0x4ee9b9da

    const-string v0, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 352
    const/4 v15, 0x0

    invoke-static {v1, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v17

    .line 353
    .local v17, "compositeKeyHash\\3":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 354
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 356
    .local v2, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v19, v3

    .end local v3    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\2":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v13, 0x6

    and-int/lit16 v3, v3, 0x380

    move/from16 v20, v3

    const/4 v3, 0x6

    or-int/lit8 v20, v20, 0x6

    .line 355
    nop

    .local v20, "$changed\\4":I
    move-object/from16 v21, v18

    .local v21, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 357
    .local v18, "$i$f$ReusableComposeNode\\4\\355":I
    move/from16 v22, v3

    const v3, -0x2942ffcf

    const-string v4, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 358
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 359
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 360
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_4

    .line 361
    move-object/from16 v3, v21

    .end local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 363
    .end local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v3, v21

    .end local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 365
    :goto_1
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 366
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v25, v3

    .end local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v25, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 367
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v15, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 369
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 370
    .local v24, "$i$f$set-impl\\6\\369":I
    move-object/from16 v26, v1

    .local v26, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 371
    .local v27, "$i$a$-with-Updater$set$1\\7\\370\\6":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_6

    move-object/from16 v28, v5

    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v29, v7

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v5, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v7, v26

    goto :goto_3

    :cond_6
    move-object/from16 v28, v5

    move-object/from16 v29, v7

    .line 372
    :goto_2
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v7, v26

    .end local v26    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 373
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v5, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 375
    :goto_3
    nop

    .line 370
    .end local v7    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-with-Updater$set$1\\7\\370\\6":I
    nop

    .line 375
    nop

    .line 376
    .end local v3    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\6\\369":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v1, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 377
    nop

    .line 365
    .end local v1    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    nop

    .line 378
    shr-int/lit8 v1, v20, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object/from16 v3, p2

    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 379
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\8\\378\\2":I
    const v7, -0x16ef5699

    move/from16 v21, v1

    .end local v1    # "$changed\\8":I
    .local v21, "$changed\\8":I
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v7, v8, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$invoke_u24lambda_u244\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v51, v3

    .local v51, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 287
    .local v24, "$i$a$-Column-HitchInspectorKt$FrameCard$1$1\\9\\379\\0":I
    move-object/from16 v26, v1

    .end local v1    # "$this$invoke_u24lambda_u244\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v26, "$this$invoke_u24lambda_u244\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, -0x692b982c

    move-object/from16 v27, v2

    .end local v2    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v27, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v2, "C286@17157L537,292@17785L10,292@17830L11,292@17707L152,293@17872L29:HitchInspector.kt#o13vsk"

    move-object/from16 v55, v3

    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v1

    .local v1, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v2, 0x180

    .local v2, "$changed\\10":I
    const/16 v30, 0x0

    .line 380
    .local v30, "$i$f$Row\\10\\287":I
    move/from16 v31, v2

    .end local v2    # "$changed\\10":I
    .local v31, "$changed\\10":I
    const v2, 0x2952b718

    move/from16 v56, v5

    .end local v5    # "$i$a$-Layout-ColumnKt$Column$1\\8\\378\\2":I
    .local v56, "$i$a$-Layout-ColumnKt$Column$1\\8\\378\\2":I
    const-string v5, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v3, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 381
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    .line 382
    .local v2, "modifier\\10":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v5

    .line 386
    .local v5, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v32, v31, 0x3

    and-int/lit8 v32, v32, 0xe

    shr-int/lit8 v33, v31, 0x3

    and-int/lit8 v33, v33, 0x70

    move/from16 v57, v7

    .end local v7    # "$changed\\9":I
    .local v57, "$changed\\9":I
    or-int v7, v32, v33

    invoke-static {v5, v1, v3, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v32, v31, 0x3

    and-int/lit8 v32, v32, 0x70

    .line 387
    nop

    .local v32, "$changed\\11":I
    const/16 v33, 0x0

    .line 388
    .local v33, "$i$f$Layout\\11\\387":I
    move-object/from16 v34, v1

    const v1, -0x4ee9b9da

    .end local v1    # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .local v34, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v3, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 389
    const/4 v0, 0x0

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v1

    .line 390
    .local v1, "compositeKeyHash\\11":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 391
    .local v0, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v16, v1

    .end local v1    # "compositeKeyHash\\11":I
    .local v16, "compositeKeyHash\\11":I
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 393
    .local v1, "materialized\\11":Landroidx/compose/ui/Modifier;
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v35

    move-object/from16 v36, v2

    .end local v2    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v36, "modifier\\10":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v32, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 392
    nop

    .local v2, "$changed\\12":I
    move-object/from16 v37, v35

    .local v37, "factory\\12":Lkotlin/jvm/functions/Function0;
    const/16 v35, 0x0

    .line 394
    .local v35, "$i$f$ReusableComposeNode\\12\\392":I
    move/from16 v38, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\12":I
    .local v38, "$changed\\12":I
    invoke-static {v3, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 395
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 396
    :cond_7
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 397
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_8

    .line 398
    move-object/from16 v2, v37

    .end local v37    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 400
    .end local v2    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v37    # "factory\\12":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v2, v37

    .end local v37    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 402
    :goto_4
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 403
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\402\\11":I
    sget-object v37, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v39, v2

    .end local v2    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v39, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v37 .. v37}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v7, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 404
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 406
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\14":Lkotlin/jvm/functions/Function2;
    const/16 v37, 0x0

    .line 407
    .local v37, "$i$f$set-impl\\14\\406":I
    move-object/from16 v40, v4

    .local v40, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 408
    .local v41, "$i$a$-with-Updater$set$1\\15\\407\\14":I
    invoke-interface/range {v40 .. v40}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v42

    if-nez v42, :cond_a

    move-object/from16 v42, v0

    .end local v0    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .local v42, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v40 .. v40}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v43, v5

    .end local v5    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v43, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_5

    :cond_9
    move-object/from16 v5, v40

    goto :goto_6

    .end local v42    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v43    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v0    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_a
    move-object/from16 v42, v0

    move-object/from16 v43, v5

    .line 409
    .end local v0    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v42    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v43    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_5
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v5, v40

    .end local v40    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 410
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v4, v0, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 412
    :goto_6
    nop

    .line 407
    .end local v5    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v41    # "$i$a$-with-Updater$set$1\\15\\407\\14":I
    nop

    .line 412
    nop

    .line 413
    .end local v2    # "block\\14":Lkotlin/jvm/functions/Function2;
    .end local v37    # "$i$f$set-impl\\14\\406":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 414
    nop

    .line 402
    .end local v4    # "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\402\\11":I
    nop

    .line 415
    shr-int/lit8 v0, v38, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\16":I
    move-object v2, v3

    .local v2, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 416
    .local v4, "$i$a$-Layout-RowKt$Row$1\\16\\415\\10":I
    const v5, -0x184f2606

    move/from16 v23, v0

    .end local v0    # "$changed\\16":I
    .local v23, "$changed\\16":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v31, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\17":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$invoke_u24lambda_u244_u24lambda_u240\\17":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v79, v2

    .local v79, "$composer\\17":Landroidx/compose/runtime/Composer;
    move-object/from16 v44, v0

    .end local v0    # "$this$invoke_u24lambda_u244_u24lambda_u240\\17":Landroidx/compose/foundation/layout/RowScope;
    .local v44, "$this$invoke_u24lambda_u244_u24lambda_u240\\17":Landroidx/compose/foundation/layout/RowScope;
    const/4 v0, 0x0

    .line 288
    .local v0, "$i$a$-Row-HitchInspectorKt$FrameCard$1$1$1\\17\\416\\9":I
    move/from16 v37, v0

    .end local v0    # "$i$a$-Row-HitchInspectorKt$FrameCard$1$1$1\\17\\416\\9":I
    .local v37, "$i$a$-Row-HitchInspectorKt$FrameCard$1$1$1\\17\\416\\9":I
    const v0, -0x66e3f195

    move-object/from16 v40, v1

    .end local v1    # "materialized\\11":Landroidx/compose/ui/Modifier;
    .local v40, "materialized\\11":Landroidx/compose/ui/Modifier;
    const-string v1, "C287@17227L92,288@17336L28,289@17435L10,289@17381L108,290@17590L10,290@17506L174:HitchInspector.kt#o13vsk"

    move-object/from16 v41, v2

    .end local v79    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0xa

    .local v1, "$this$dp\\18":I
    const/16 v45, 0x0

    .line 417
    .local v45, "$i$f$getDp\\18\\288":I
    move/from16 v50, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\16\\415\\10":I
    .local v50, "$i$a$-Layout-RowKt$Row$1\\16\\415\\10":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 288
    .end local v1    # "$this$dp\\18":I
    .end local v45    # "$i$f$getDp\\18\\288":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    move/from16 v51, v5

    .end local v5    # "$changed\\17":I
    .local v51, "$changed\\17":I
    invoke-static {v1}, Lorg/lighttouch/android/HitchInspectorKt;->access$frameColor(F)J

    move-result-wide v4

    const/4 v1, 0x5

    .local v1, "$this$dp\\19":I
    const/16 v45, 0x0

    .line 417
    .local v45, "$i$f$getDp\\19\\288":I
    move-object/from16 v52, v7

    .end local v7    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v52, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    int-to-float v7, v1

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 288
    .end local v1    # "$this$dp\\19":I
    .end local v45    # "$i$f$getDp\\19\\288":I
    invoke-static {v1}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    check-cast v1, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v4, v5, v1}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 289
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\20":I
    const/4 v4, 0x0

    .line 418
    .local v4, "$i$f$getDp\\20\\289":I
    int-to-float v5, v1

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 289
    .end local v1    # "$this$dp\\20":I
    .end local v4    # "$i$f$getDp\\20\\289":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v22

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 290
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getSequence()J

    move-result-wide v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5e27 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v58

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v78

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v45, v0

    check-cast v45, Landroidx/compose/ui/Modifier;

    const/16 v48, 0x2

    const/16 v49, 0x0

    const/high16 v46, 0x3f800000    # 1.0f

    const/16 v47, 0x0

    invoke-static/range {v44 .. v49}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v59

    const/16 v81, 0x0

    const v82, 0xfffc

    const-wide/16 v60, 0x0

    const-wide/16 v62, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const-wide/16 v71, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v80, 0x0

    .end local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v79    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v82}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 291
    .end local v79    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    invoke-static {v1, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v4, "%.1f ms"

    invoke-static {v0, v4, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v78

    sget-object v1, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v65

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    invoke-static {v1}, Lorg/lighttouch/android/HitchInspectorKt;->access$frameColor(F)J

    move-result-wide v60

    const v82, 0xffda

    const/16 v59, 0x0

    const/high16 v80, 0x30000

    move-object/from16 v58, v0

    .end local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v79    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v82}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 288
    invoke-static/range {v79 .. v79}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 292
    nop

    .line 416
    .end local v37    # "$i$a$-Row-HitchInspectorKt$FrameCard$1$1$1\\17\\416\\9":I
    .end local v44    # "$this$invoke_u24lambda_u244_u24lambda_u240\\17":Landroidx/compose/foundation/layout/RowScope;
    .end local v51    # "$changed\\17":I
    .end local v79    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 415
    .end local v23    # "$changed\\16":I
    .end local v41    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-RowKt$Row$1\\16\\415\\10":I
    nop

    .line 419
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 394
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 420
    nop

    .line 388
    .end local v35    # "$i$f$ReusableComposeNode\\12\\392":I
    .end local v38    # "$changed\\12":I
    .end local v39    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 421
    nop

    .line 380
    .end local v16    # "compositeKeyHash\\11":I
    .end local v32    # "$changed\\11":I
    .end local v33    # "$i$f$Layout\\11\\387":I
    .end local v40    # "materialized\\11":Landroidx/compose/ui/Modifier;
    .end local v42    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 422
    nop

    .line 293
    .end local v30    # "$i$f$Row\\10\\287":I
    .end local v31    # "$changed\\10":I
    .end local v34    # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .end local v36    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v43    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v52    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v0

    invoke-virtual {v6}, Lorg/lighttouch/android/HitchData;->getStartNs()J

    move-result-wide v4

    sub-long/2addr v0, v4

    invoke-static {v0, v1}, Lorg/lighttouch/android/HitchInspectorKt;->access$seconds(J)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u4e8e "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v30

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v50

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v32

    const/16 v53, 0x0

    const v54, 0xfffa

    const/16 v31, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v48, 0x0

    const/16 v52, 0x0

    move-object/from16 v51, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v54}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 294
    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\21":I
    const/4 v2, 0x0

    .line 423
    .local v2, "$i$f$getDp\\21\\294":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 294
    .end local v1    # "$this$dp\\21":I
    .end local v2    # "$i$f$getDp\\21\\294":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v3, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 300
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPresentedNs()J

    move-result-wide v0

    const-wide/16 v4, 0x0

    cmp-long v0, v0, v4

    if-lez v0, :cond_b

    const v0, -0x691b393e

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "300@18348L81,301@18446L47"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 301
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPresentedNs()J

    move-result-wide v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v4

    sub-long/2addr v0, v4

    long-to-float v0, v0

    const v1, 0x49742400    # 1000000.0f

    div-float/2addr v0, v1

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v2, "\u7a0d\u540e\u663e\u793a\u5230\u5c4f\u5e55"

    const/4 v4, 0x6

    invoke-static {v2, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 302
    move v0, v1

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getWorkNs()J

    move-result-wide v1

    long-to-float v1, v1

    div-float/2addr v1, v0

    invoke-static {v1}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u5448\u73b0\u5de5\u4f5c"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 300
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_7

    .line 303
    :cond_b
    const v0, -0x55f88853

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "302@18513L62"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v0, "\u5df2\u8df3\u8fc7\uff08\u88ab\u66f4\u65b0\u7684\u5e27\u53d6\u4ee3\uff09"

    const/16 v1, 0x36

    const-string v2, "\u5df2\u663e\u793a\u5230\u5c4f\u5e55"

    invoke-static {v2, v0, v3, v1}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_7
    const v0, -0x55f87a54

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "304@18621L46,305@18684L39,306@18740L48,307@18805L44,308@18866L47,309@18930L37,310@18984L38,*318@19753L10,318@19797L11,318@19692L125"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 304
    if-eqz v29, :cond_11

    .line 305
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getRunMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u5ba2\u6237\u673a\u4ee3\u7801\uff08vCPU \u8fd0\u884c\u4e2d\uff09"

    const/4 v4, 0x6

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 306
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getGlMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "  \u5176\u4e2d GL \u8c03\u7528"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 307
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getGlPresentMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "  \u5176\u4e2d GL \u5448\u73b0"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 308
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getVcpuCpuMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "vCPU \u5728\u5bbf\u4e3b\u6838\u5fc3\u4e0a"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 309
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getOutsideMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "vCPU \u505c\u673a\u6216\u4e0d\u5728\u8ba1\u65f6\u8303\u56f4"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 310
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getBqlMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u9501 (BQL) \u7b49\u5f85"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 311
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getMainCpuMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$ms(F)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u4e3b\u5faa\u73af CPU"

    invoke-static {v1, v0, v3, v4}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;->invoke$lambda$4$line(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 312
    nop

    .line 313
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getRunMs()F

    move-result v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    const v2, 0x3f4ccccd    # 0.8f

    mul-float/2addr v1, v2

    cmpl-float v0, v0, v1

    if-lez v0, :cond_c

    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getVcpuCpuMs()F

    move-result v0

    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getRunMs()F

    move-result v1

    const/high16 v4, 0x3f400000    # 0.75f

    mul-float/2addr v1, v4

    cmpg-float v0, v0, v1

    if-gez v0, :cond_c

    const-string v0, "vCPU \u672c\u53ef\u8fd0\u884c\u5374\u5e38\u88ab\u79fb\u51fa CPU\uff1a\u624b\u673a\u8c03\u5ea6\u4e86\u5176\u4ed6\u4efb\u52a1\uff0c\u6216\u964d\u4f4e\u4e86\u6838\u5fc3\u9891\u7387\u3002"

    goto :goto_8

    .line 314
    :cond_c
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getGlMs()F

    move-result v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    const v4, 0x3ecccccd    # 0.4f

    mul-float/2addr v1, v4

    cmpl-float v0, v0, v1

    if-lez v0, :cond_d

    const-string v0, "\u672c\u5e27\u5927\u90e8\u5206\u65f6\u95f4\u82b1\u5728 GL \u8c03\u7528\uff1a\u5bbf\u4e3b\u9a71\u52a8\u6216\u56de\u8bfb\u5f00\u9500\u3002"

    goto :goto_8

    .line 315
    :cond_d
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getBqlMs()F

    move-result v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    const/high16 v4, 0x3e800000    # 0.25f

    mul-float/2addr v1, v4

    cmpl-float v0, v0, v1

    if-lez v0, :cond_e

    const-string v0, "\u672c\u5e27\u4e2d vCPU \u5927\u91cf\u65f6\u95f4\u5728\u7b49\u5f85\u5f15\u64ce\u9501\u3002"

    goto :goto_8

    .line 316
    :cond_e
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/FrameBreakdown;->getRunMs()F

    move-result v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    mul-float/2addr v1, v2

    cmpl-float v0, v0, v1

    if-lez v0, :cond_f

    const-string v0, "\u6574\u4e2a\u5e27\u5185\u5ba2\u6237\u673a\u90fd\u5728\u5fd9\u788c\uff1a\u5ba2\u6237\u673a\u5de5\u4f5c\u91cf\u9ad8\u4e8e\u5e73\u5e38\u3002"

    goto :goto_8

    .line 317
    :cond_f
    const/4 v0, 0x0

    .line 312
    :goto_8
    nop

    .line 319
    .local v0, "hint\\9":Ljava/lang/String;
    if-nez v0, :cond_10

    goto :goto_9

    :cond_10
    move-object/from16 v30, v0

    .line 424
    .local v30, "it\\22":Ljava/lang/String;
    const/4 v1, 0x0

    .line 319
    .local v1, "$i$a$-let-HitchInspectorKt$FrameCard$1$1$2\\22\\319\\9":I
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v31, v2

    check-cast v31, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\23":I
    const/4 v4, 0x0

    .line 425
    .local v4, "$i$f$getDp\\23\\319":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v33

    .line 319
    .end local v2    # "$this$dp\\23":I
    .end local v4    # "$i$f$getDp\\23\\319":I
    const/16 v36, 0xd

    const/16 v37, 0x0

    const/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-static/range {v31 .. v37}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v50

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v32

    const/16 v53, 0x0

    const v54, 0xfff8

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v52, 0x30

    move-object/from16 v51, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v54}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v1    # "$i$a$-let-HitchInspectorKt$FrameCard$1$1$2\\22\\319\\9":I
    .end local v30    # "it\\22":Ljava/lang/String;
    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .end local v0    # "hint\\9":Ljava/lang/String;
    :cond_11
    :goto_9
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 321
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v0

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v2

    float-to-double v4, v2

    const-wide v29, 0x412e848000000000L    # 1000000.0

    mul-double v4, v4, v29

    double-to-long v4, v4

    sub-long/2addr v0, v4

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v4

    invoke-virtual {v6, v0, v1, v4, v5}, Lorg/lighttouch/android/HitchData;->eventsIn(JJ)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$sortedByDescending\\24":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 426
    .local v1, "$i$f$sortedByDescending\\24\\321":I
    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1$invoke$lambda$4$$inlined$sortedByDescending$1;

    invoke-direct {v2}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1$invoke$lambda$4$$inlined$sortedByDescending$1;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .end local v0    # "$this$sortedByDescending\\24":Ljava/lang/Iterable;
    .end local v1    # "$i$f$sortedByDescending\\24\\321":I
    check-cast v0, Ljava/lang/Iterable;

    .line 321
    const/4 v1, 0x6

    invoke-static {v0, v1}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    .local v0, "overlapping\\9":Ljava/util/List;
    const v1, -0x55f7cd8d

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "322@20049L29,323@20151L10,323@20095L79,*324@20218L29"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 322
    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_12

    .line 323
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\25":I
    const/4 v4, 0x0

    .line 427
    .local v4, "$i$f$getDp\\25\\323":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 323
    .end local v2    # "$this$dp\\25":I
    .end local v4    # "$i$f$getDp\\25\\323":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v4, 0x6

    invoke-static {v1, v3, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 324
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v50

    const/16 v53, 0x0

    const v54, 0xfffe

    const-string v30, "\u6b64\u5e27\u5185\u7684\u6162\u4e8b\u4ef6"

    const/16 v31, 0x0

    const-wide/16 v32, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v52, 0x6

    move-object/from16 v51, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v54}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 325
    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_12

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/SlowEvent;

    .local v2, "event\\9":Lorg/lighttouch/android/SlowEvent;
    invoke-virtual {v6}, Lorg/lighttouch/android/HitchData;->getStartNs()J

    move-result-wide v4

    const/4 v7, 0x0

    invoke-static {v2, v4, v5, v3, v7}, Lorg/lighttouch/android/HitchInspectorKt;->access$EventRow(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V

    .end local v2    # "event\\9":Lorg/lighttouch/android/SlowEvent;
    goto :goto_a

    :cond_12
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 287
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 327
    .end local v0    # "overlapping\\9":Ljava/util/List;
    nop

    .line 379
    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Column-HitchInspectorKt$FrameCard$1$1\\9\\379\\0":I
    .end local v26    # "$this$invoke_u24lambda_u244\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v57    # "$changed\\9":I
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 378
    .end local v21    # "$changed\\8":I
    .end local v55    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v56    # "$i$a$-Layout-ColumnKt$Column$1\\8\\378\\2":I
    nop

    .line 428
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 357
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 429
    nop

    .line 351
    .end local v18    # "$i$f$ReusableComposeNode\\4\\355":I
    .end local v20    # "$changed\\4":I
    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 430
    nop

    .line 344
    .end local v13    # "$changed\\3":I
    .end local v14    # "$i$f$Layout\\3\\350":I
    .end local v15    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "compositeKeyHash\\3":I
    .end local v27    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 431
    nop

    .end local v8    # "$changed\\2":I
    .end local v9    # "$i$f$Column\\2\\286":I
    .end local v10    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v11    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v12    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 328
    :cond_13
    :goto_b
    return-void
.end method

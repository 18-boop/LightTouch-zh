.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5\n*L\n71#1:197,6\n72#1:203,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $s:Lorg/lighttouch/android/AppSettings;


# direct methods
.method public static synthetic $r8$lambda$_ZxIVI_v6LKm3vo0OcPFeFei3kw(Lorg/lighttouch/android/GraphicsProvider;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->invoke$lambda$1$lambda$0(Lorg/lighttouch/android/GraphicsProvider;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$h230VC75XPP3ZhEpD6Ca3BHZCoQ(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GraphicsProvider;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GraphicsProvider;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/AppSettings;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0(Lorg/lighttouch/android/GraphicsProvider;)Ljava/lang/String;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/GraphicsProvider;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    invoke-virtual {p0}, Lorg/lighttouch/android/GraphicsProvider;->getLabel()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Lorg/lighttouch/android/AppSettings;Lorg/lighttouch/android/GraphicsProvider;)Lkotlin/Unit;
    .locals 1
    .param p0, "$s"    # Lorg/lighttouch/android/AppSettings;
    .param p1, "it"    # Lorg/lighttouch/android/GraphicsProvider;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 72
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/AppSettings;->setGraphicsProvider(Lorg/lighttouch/android/GraphicsProvider;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 70
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 12
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$Group"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C70@5777L12,71@5999L27,70@5693L333:SettingsScreen.kt#o13vsk"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    if-ne v0, v1, :cond_1

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 71
    :cond_0
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v9, p2

    goto/16 :goto_4

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, -0x1

    const-string v1, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:70)"

    const v2, 0x4d7c2c9f    # 2.6442392E8f

    invoke-static {v2, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 71
    :cond_2
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getChip()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    invoke-static {}, Lorg/lighttouch/android/GraphicsProvider;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Ljava/util/List;

    iget-object v0, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-virtual {v0}, Lorg/lighttouch/android/AppSettings;->getGraphicsProvider()Lorg/lighttouch/android/GraphicsProvider;

    move-result-object v4

    const v0, 0x6e3c21fe

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\1":Z
    move-object v5, p2

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 197
    .local v6, "$i$f$cache\\1\\71":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\1":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 198
    .local v8, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v7, v9, :cond_3

    .line 199
    const/4 v9, 0x0

    .local v9, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$5$1\\3\\199\\0":I
    new-instance v10, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5$$ExternalSyntheticLambda0;

    invoke-direct {v10}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5$$ExternalSyntheticLambda0;-><init>()V

    .line 200
    .end local v9    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$5$1\\3\\199\\0":I
    .local v10, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .end local v10    # "value\\2":Ljava/lang/Object;
    goto :goto_1

    .line 202
    :cond_3
    move-object v10, v7

    .line 198
    :goto_1
    nop

    .line 197
    .end local v7    # "it\\1":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 71
    .end local v2    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\1\\71":I
    move-object v5, v10

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 72
    const v2, 0x4c5de2

    invoke-interface {p2, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->$s:Lorg/lighttouch/android/AppSettings;

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\4":Z
    iget-object v2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5;->$s:Lorg/lighttouch/android/AppSettings;

    move-object v6, p2

    .local v6, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 203
    .local v7, "$i$f$cache\\4\\72":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\4":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 204
    .local v9, "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    if-nez v0, :cond_5

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v8, v10, :cond_4

    goto :goto_2

    .line 208
    :cond_4
    move-object v11, v8

    goto :goto_3

    .line 205
    :cond_5
    :goto_2
    const/4 v10, 0x0

    .line 72
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$5$2\\6\\205\\0":I
    new-instance v11, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5$$ExternalSyntheticLambda1;

    invoke-direct {v11, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$5$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/AppSettings;)V

    .line 205
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$5$2\\6\\205\\0":I
    nop

    .line 206
    .local v11, "value\\5":Ljava/lang/Object;
    invoke-interface {v6, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 204
    .end local v11    # "value\\5":Ljava/lang/Object;
    :goto_3
    nop

    .line 203
    .end local v8    # "it\\4":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    nop

    .line 72
    .end local v0    # "invalid\\4":Z
    .end local v6    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\4\\72":I
    move-object v8, v11

    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 71
    const-string v2, "GPU \u9a71\u52a8"

    const-string v6, "ANGLE \u4f7f\u7528\u5185\u7f6e\u7684\u56fe\u5f62\u8f6c\u6362\u5c42\u66ff\u4ee3 Android \u7684 GPU \u9a71\u52a8\uff0c\u901f\u5ea6\u53ef\u80fd\u63d0\u5347\u4e5f\u53ef\u80fd\u4e0b\u964d\uff1b\u4e0b\u6b21\u5168\u65b0\u542f\u52a8\u5ba2\u6237\u673a\u65f6\u751f\u6548\u3002"

    const-string v7, "graphics_provider"

    const v10, 0x1b6030

    const/4 v11, 0x0

    move-object v9, p2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SettingsScreenKt;->access$ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/util/List;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 73
    :cond_6
    :goto_4
    return-void
.end method

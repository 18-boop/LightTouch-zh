.class final Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;
.super Ljava/lang/Object;
.source "StoreScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,586:1\n149#2:587\n149#2:588\n99#3:589\n95#3,7:590\n102#3:625\n106#3:635\n79#4,6:597\n86#4,4:612\n90#4,2:622\n94#4:634\n368#5,9:603\n377#5:624\n378#5,2:632\n4034#6,6:616\n1225#7,6:626\n*S KotlinDebug\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1\n*L\n297#1:587\n298#1:588\n299#1:589\n299#1:590,7\n299#1:625\n299#1:635\n299#1:597,6\n299#1:612,4\n299#1:622,2\n299#1:634\n299#1:603,9\n299#1:624\n299#1:632,2\n299#1:616,6\n299#1:626,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $model:Lorg/lighttouch/android/StoreModel;

.field final synthetic $report:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$eUjuAN4JP8EHNDMfcxle7JcTPxo(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;->invoke$lambda$2$lambda$1$lambda$0(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Ljava/lang/String;Lorg/lighttouch/android/StoreModel;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;->$report:Ljava/lang/String;

    iput-object p2, p0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;->$model:Lorg/lighttouch/android/StoreModel;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$2$lambda$1$lambda$0(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;

    .line 299
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setCrash(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 295
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 37
    .param p1, "$this$StoreCard"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$StoreCard"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C295@16277L10,295@16236L63,296@16324L29,297@16468L21,297@16378L113,298@16516L99:StoreScreen.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 635
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_6

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.StoreScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StoreScreen.kt:295)"

    const v6, -0x18f1dda

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 296
    :cond_2
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v1, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0xfffe

    const-string v1, "\u6700\u8fd1\u4e00\u6b21\u5d29\u6e83"

    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x6

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 297
    move-object/from16 v1, v22

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x6

    .local v3, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 587
    .local v4, "$i$f$getDp\\1\\297":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 297
    .end local v3    # "$this$dp\\1":I
    .end local v4    # "$i$f$getDp\\1\\297":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v3, 0x6

    invoke-static {v2, v1, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 298
    invoke-static {}, Lorg/lighttouch/android/ThemeKt;->getMonoStyle()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x104

    .local v4, "$this$dp\\2":I
    const/4 v5, 0x0

    .line 588
    .local v5, "$i$f$getDp\\2\\298":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 298
    .end local v4    # "$this$dp\\2":I
    .end local v5    # "$i$f$getDp\\2\\298":I
    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v2, v6, v4, v7, v5}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/4 v2, 0x0

    invoke-static {v2, v1, v2, v7}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v9

    const/16 v13, 0xe

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    iget-object v1, v0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;->$report:Ljava/lang/String;

    const/high16 v24, 0x180000

    const v25, 0xfffc

    move v5, v2

    move v6, v3

    move-object v2, v4

    const-wide/16 v3, 0x0

    move v7, v5

    move v8, v6

    const-wide/16 v5, 0x0

    move v9, v7

    const/4 v7, 0x0

    move v10, v8

    const/4 v8, 0x0

    move v11, v9

    const/4 v9, 0x0

    move v13, v10

    move v12, v11

    const-wide/16 v10, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    move/from16 v17, v15

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v22, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v26, v23

    const/16 v23, 0x0

    move/from16 v26, v22

    move-object/from16 v22, p2

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 299
    move-object/from16 v1, v22

    iget-object v2, v0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1;->$model:Lorg/lighttouch/android/StoreModel;

    const/4 v3, 0x0

    .local v3, "$changed\\3":I
    const/4 v4, 0x0

    .line 589
    .local v4, "$i$f$Row\\3\\299":I
    const v5, 0x2952b718

    const-string v6, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v1, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 590
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 591
    .local v5, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 592
    .local v6, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 595
    .local v7, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v8, v3, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v9, v3, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v8, v9

    invoke-static {v6, v7, v1, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v3, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 596
    nop

    .local v9, "$changed\\4":I
    const/4 v10, 0x0

    .line 597
    .local v10, "$i$f$Layout\\4\\596":I
    const v11, -0x4ee9b9da

    const-string v12, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 598
    const/4 v12, 0x0

    invoke-static {v1, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v11

    .line 599
    .local v11, "compositeKeyHash\\4":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 600
    .local v13, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 602
    .local v14, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v12, v9, 0x6

    and-int/lit16 v12, v12, 0x380

    or-int/lit8 v12, v12, 0x6

    .line 601
    nop

    .local v12, "$changed\\5":I
    .local v15, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 603
    .local v17, "$i$f$ReusableComposeNode\\5\\601":I
    const v0, -0x2942ffcf

    move/from16 v18, v3

    .end local v3    # "$changed\\3":I
    .local v18, "$changed\\3":I
    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 604
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 605
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 606
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 607
    invoke-interface {v1, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 609
    :cond_4
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 611
    :goto_1
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 612
    .local v3, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v8, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 613
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 615
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 616
    .local v19, "$i$f$set-impl\\7\\615":I
    move-object/from16 v20, v0

    .local v20, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 617
    .local v21, "$i$a$-with-Updater$set$1\\8\\616\\7":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_6

    move/from16 v22, v3

    .end local v3    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v23, v4

    .end local v4    # "$i$f$Row\\3\\299":I
    .local v23, "$i$f$Row\\3\\299":I
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v4, v20

    goto :goto_3

    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    .end local v23    # "$i$f$Row\\3\\299":I
    .restart local v3    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    .restart local v4    # "$i$f$Row\\3\\299":I
    :cond_6
    move/from16 v22, v3

    move/from16 v23, v4

    .line 618
    .end local v3    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    .end local v4    # "$i$f$Row\\3\\299":I
    .restart local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    .restart local v23    # "$i$f$Row\\3\\299":I
    :goto_2
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 619
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 621
    :goto_3
    nop

    .line 616
    .end local v4    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\8\\616\\7":I
    nop

    .line 621
    nop

    .line 622
    .end local v1    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\7\\615":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 623
    nop

    .line 611
    .end local v0    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\611\\4":I
    nop

    .line 624
    shr-int/lit8 v0, v12, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object/from16 v1, p2

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 625
    .local v3, "$i$a$-Layout-RowKt$Row$1\\9\\624\\3":I
    const v4, -0x184f2606

    move/from16 v19, v0

    .end local v0    # "$changed\\9":I
    .local v19, "$changed\\9":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v18, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v34, v1

    .local v34, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v24, v0

    .end local v0    # "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v24, "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    const/4 v0, 0x0

    .line 299
    .local v0, "$i$a$-Row-StoreScreenKt$StoreScreen$3$1$2$1$1$1\\10\\625\\0":I
    move/from16 v20, v0

    .end local v0    # "$i$a$-Row-StoreScreenKt$StoreScreen$3$1$2$1$1$1\\10\\625\\0":I
    .local v20, "$i$a$-Row-StoreScreenKt$StoreScreen$3$1$2$1$1$1\\10\\625\\0":I
    const v0, 0x369502fe

    move-object/from16 v21, v1

    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v1, "C298@16522L27,298@16572L22,298@16551L62:StoreScreen.kt#o13vsk"

    move/from16 v22, v3

    move-object/from16 v3, v34

    .end local v34    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v22, "$i$a$-Layout-RowKt$Row$1\\9\\624\\3":I
    invoke-static {v3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v25, v0

    check-cast v25, Landroidx/compose/ui/Modifier;

    const/16 v28, 0x2

    const/16 v29, 0x0

    const/high16 v26, 0x3f800000    # 1.0f

    const/16 v27, 0x0

    invoke-static/range {v24 .. v29}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object/from16 v16, v24

    const/4 v1, 0x0

    .end local v24    # "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v16, "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static {v0, v3, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    const v0, 0x4c5de2

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\11":Z
    move-object v1, v3

    .local v1, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 626
    .local v24, "$i$f$cache\\11\\299":I
    move/from16 v25, v0

    .end local v0    # "invalid\\11":Z
    .local v25, "invalid\\11":Z
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\11":Ljava/lang/Object;
    const/16 v26, 0x0

    .line 627
    .local v26, "$i$a$-let-ComposerKt$cache$1\\12\\626\\11":I
    if-nez v25, :cond_8

    sget-object v27, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v34, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v34    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v27 .. v27}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v0, v3, :cond_7

    goto :goto_4

    .line 631
    :cond_7
    move-object/from16 v27, v0

    goto :goto_5

    .line 627
    .end local v34    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_8
    move-object/from16 v34, v3

    .line 628
    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v34    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :goto_4
    const/4 v3, 0x0

    .line 299
    .local v3, "$i$a$-cache-StoreScreenKt$StoreScreen$3$1$2$1$1$1$1\\13\\628\\10":I
    move-object/from16 v27, v0

    .end local v0    # "it\\11":Ljava/lang/Object;
    .local v27, "it\\11":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1$$ExternalSyntheticLambda0;

    invoke-direct {v0, v2}, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3$1$2$1$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/StoreModel;)V

    .line 628
    .end local v3    # "$i$a$-cache-StoreScreenKt$StoreScreen$3$1$2$1$1$1$1\\13\\628\\10":I
    nop

    .line 629
    .local v0, "value\\12":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 630
    nop

    .line 627
    .end local v0    # "value\\12":Ljava/lang/Object;
    :goto_5
    nop

    .line 626
    .end local v26    # "$i$a$-let-ComposerKt$cache$1\\12\\626\\11":I
    .end local v27    # "it\\11":Ljava/lang/Object;
    nop

    .line 299
    .end local v1    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$f$cache\\11\\299":I
    .end local v25    # "invalid\\11":Z
    move-object/from16 v24, v0

    check-cast v24, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v34 .. v34}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$-361516857$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v33

    const/high16 v35, 0x30000000

    const/16 v36, 0x1fe

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    invoke-static/range {v24 .. v36}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v34 .. v34}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 625
    .end local v4    # "$changed\\10":I
    .end local v16    # "$this$invoke_u24lambda_u242\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v20    # "$i$a$-Row-StoreScreenKt$StoreScreen$3$1$2$1$1$1\\10\\625\\0":I
    .end local v34    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 624
    .end local v19    # "$changed\\9":I
    .end local v21    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-Layout-RowKt$Row$1\\9\\624\\3":I
    nop

    .line 632
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 603
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 633
    nop

    .line 597
    .end local v12    # "$changed\\5":I
    .end local v15    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v17    # "$i$f$ReusableComposeNode\\5\\601":I
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 634
    nop

    .line 589
    .end local v9    # "$changed\\4":I
    .end local v10    # "$i$f$Layout\\4\\596":I
    .end local v11    # "compositeKeyHash\\4":I
    .end local v13    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 635
    nop

    .end local v5    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v6    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v7    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v8    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "$changed\\3":I
    .end local v23    # "$i$f$Row\\3\\299":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 300
    :cond_9
    :goto_6
    return-void
.end method

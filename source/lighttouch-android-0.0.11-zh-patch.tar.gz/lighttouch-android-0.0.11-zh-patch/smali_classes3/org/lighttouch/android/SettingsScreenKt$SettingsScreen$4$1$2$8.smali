.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,196:1\n1#2:197\n1225#3,6:198\n1225#3,6:204\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8\n*L\n100#1:198,6\n102#1:204,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;


# direct methods
.method public static synthetic $r8$lambda$6oHkERtr9stnI5U8IU8CrT20EFw(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->invoke$lambda$2$lambda$1(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tPhsBdydbajVa1sltQlNgZeWanM(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->invoke$lambda$4$lambda$3(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$2$lambda$1(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 100
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->pickGuestTools()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$4$lambda$3(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 102
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->openPreparation()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 98
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 18
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v7, p2

    move/from16 v10, p3

    const-string v1, "$this$Group"

    move-object/from16 v11, p1

    invoke-static {v11, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C99@9578L25,98@9320L283,101@9831L26,100@9624L233:SettingsScreen.kt#o13vsk"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v10, 0x11

    const/16 v2, 0x10

    if-ne v1, v2, :cond_1

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 101
    :cond_0
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_7

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:98)"

    const v3, 0x4cde329e    # 1.164956E8f

    invoke-static {v3, v10, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 99
    :cond_2
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getPuzzle()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v2

    if-eqz v2, :cond_3

    .line 197
    nop

    .local v2, "it\\1":Lorg/lighttouch/android/DeviceSummary;
    const/4 v3, 0x0

    .line 99
    .local v3, "$i$a$-let-SettingsScreenKt$SettingsScreen$4$1$2$8$1\\1\\99\\0":I
    invoke-virtual {v2}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u5c06\u66f4\u65b0\u7684 .itpack \u5b89\u88c5\u5230 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "\uff1b\u4e0b\u6b21\u542f\u52a8\u65f6\u751f\u6548"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .end local v2    # "it\\1":Lorg/lighttouch/android/DeviceSummary;
    .end local v3    # "$i$a$-let-SettingsScreenKt$SettingsScreen$4$1$2$8$1\\1\\99\\0":I
    if-nez v2, :cond_4

    :cond_3
    const-string v2, "\u8bf7\u5148\u9009\u62e9\u8bbe\u5907"

    :cond_4
    move-object v3, v2

    .line 100
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v2

    if-eqz v2, :cond_5

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-static {v2}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v2

    if-nez v2, :cond_5

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getBusy()Z

    move-result v2

    if-nez v2, :cond_5

    const/4 v4, 0x1

    goto :goto_1

    :cond_5
    const/4 v4, 0x0

    :goto_1
    const v14, 0x4c5de2

    invoke-interface {v7, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v15, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v7, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\2":Z
    iget-object v5, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v6, p2

    .local v6, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 198
    .local v8, "$i$f$cache\\2\\100":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\2":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 199
    .local v16, "$i$a$-let-ComposerKt$cache$1\\3\\198\\2":I
    if-nez v2, :cond_7

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v9, v12, :cond_6

    goto :goto_2

    .line 203
    :cond_6
    move-object v13, v9

    goto :goto_3

    .line 200
    :cond_7
    :goto_2
    const/4 v12, 0x0

    .line 100
    .local v12, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$8$2\\4\\200\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8$$ExternalSyntheticLambda0;

    invoke-direct {v13, v5}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 200
    .end local v12    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$8$2\\4\\200\\0":I
    nop

    .line 201
    .local v13, "value\\3":Ljava/lang/Object;
    invoke-interface {v6, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 202
    nop

    .line 199
    .end local v13    # "value\\3":Ljava/lang/Object;
    :goto_3
    nop

    .line 198
    .end local v9    # "it\\2":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\3\\198\\2":I
    nop

    .line 100
    .end local v2    # "invalid\\2":Z
    .end local v6    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\2\\100":I
    move-object v6, v13

    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 99
    const-string v2, "\u66f4\u65b0\u5ba2\u6237\u673a\u5de5\u5177"

    const/4 v5, 0x0

    const/16 v8, 0x30

    const/16 v9, 0x10

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 101
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getDownload()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    .line 102
    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-static {v2}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v2

    if-nez v2, :cond_8

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v2}, Lorg/lighttouch/android/GuestHost;->getBusy()Z

    move-result v2

    if-nez v2, :cond_8

    const/4 v4, 0x1

    goto :goto_4

    :cond_8
    const/4 v4, 0x0

    :goto_4
    invoke-interface {v7, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v2, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\5":Z
    iget-object v3, v0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8;->$host:Lorg/lighttouch/android/GuestHost;

    move-object/from16 v5, p2

    .local v5, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 204
    .local v6, "$i$f$cache\\5\\102":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\5":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 205
    .local v9, "$i$a$-let-ComposerKt$cache$1\\6\\204\\5":I
    if-nez v2, :cond_a

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v8, v12, :cond_9

    goto :goto_5

    .line 209
    :cond_9
    move-object v13, v8

    goto :goto_6

    .line 206
    :cond_a
    :goto_5
    const/4 v12, 0x0

    .line 102
    .local v12, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$8$3\\7\\206\\0":I
    new-instance v13, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8$$ExternalSyntheticLambda1;

    invoke-direct {v13, v3}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$8$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 206
    .end local v12    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$8$3\\7\\206\\0":I
    nop

    .line 207
    .local v13, "value\\6":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 208
    nop

    .line 205
    .end local v13    # "value\\6":Ljava/lang/Object;
    :goto_6
    nop

    .line 204
    .end local v8    # "it\\5":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\6\\204\\5":I
    nop

    .line 102
    .end local v2    # "invalid\\5":Z
    .end local v5    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\5\\102":I
    move-object v6, v13

    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 101
    const-string v2, "\u4ece IPSW \u51c6\u5907"

    const-string v3, "\u9009\u62e9\u8bbe\u5907\u4e0e iOS \u7248\u672c\uff1bLightTouch \u4f1a\u4e0b\u8f7d Apple \u56fa\u4ef6\u5e76\u5728\u6b64\u6784\u5efa"

    const/4 v5, 0x0

    const/16 v8, 0x1b0

    const/16 v9, 0x10

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 103
    :cond_b
    :goto_7
    return-void
.end method

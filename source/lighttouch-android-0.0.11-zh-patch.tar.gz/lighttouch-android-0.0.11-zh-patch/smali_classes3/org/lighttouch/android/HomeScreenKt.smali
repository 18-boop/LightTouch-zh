.class public final Lorg/lighttouch/android/HomeScreenKt;
.super Ljava/lang/Object;
.source "HomeScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHomeScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 8 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 9 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 10 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,192:1\n1225#2,6:193\n1225#2,6:199\n1225#2,6:313\n1225#2,6:328\n1225#2,6:340\n1225#2,6:420\n1225#2,6:488\n1225#2,6:494\n71#3:205\n68#3,6:206\n74#3:240\n71#3:278\n69#3,5:279\n74#3:312\n78#3:322\n78#3:339\n71#3:383\n68#3,6:384\n74#3:418\n78#3:487\n71#3:505\n68#3,6:506\n74#3:540\n78#3:545\n79#4,6:212\n86#4,4:227\n90#4,2:237\n79#4,6:248\n86#4,4:263\n90#4,2:273\n79#4,6:284\n86#4,4:299\n90#4,2:309\n94#4:321\n94#4:326\n94#4:338\n79#4,6:354\n86#4,4:369\n90#4,2:379\n79#4,6:390\n86#4,4:405\n90#4,2:415\n86#4,6:434\n79#4,6:449\n86#4,4:464\n90#4,2:474\n94#4:480\n94#4:485\n94#4:502\n79#4,6:512\n86#4,4:527\n90#4,2:537\n94#4:544\n79#4,6:554\n86#4,4:569\n90#4,2:579\n94#4:587\n368#5,9:218\n377#5:239\n368#5,9:254\n377#5:275\n368#5,9:290\n377#5:311\n378#5,2:319\n378#5,2:324\n378#5,2:336\n368#5,9:360\n377#5:381\n368#5,9:396\n377#5:417\n368#5,9:455\n377#5:476\n378#5,2:478\n378#5,2:483\n378#5,2:500\n368#5,9:518\n377#5:539\n378#5,2:542\n368#5,9:560\n377#5:581\n378#5,2:585\n4034#6,6:231\n4034#6,6:267\n4034#6,6:303\n4034#6,6:373\n4034#6,6:409\n4034#6,6:468\n4034#6,6:531\n4034#6,6:573\n86#7:241\n83#7,6:242\n89#7:276\n93#7:327\n86#7:442\n83#7,6:443\n89#7:477\n93#7:481\n86#7:546\n82#7,7:547\n89#7:582\n93#7:588\n149#8:277\n149#8:323\n149#8:334\n149#8:335\n149#8:346\n149#8:419\n149#8:426\n149#8:441\n149#8:482\n149#8:504\n149#8:541\n149#8:583\n149#8:584\n149#8:589\n149#8:590\n99#9:347\n96#9,6:348\n102#9:382\n99#9:427\n96#9,6:428\n102#9:440\n106#9:486\n106#9:503\n81#10:591\n107#10,2:592\n*S KotlinDebug\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt\n*L\n41#1:193,6\n43#1:199,6\n50#1:313,6\n59#1:328,6\n64#1:340,6\n71#1:420,6\n82#1:488,6\n83#1:494,6\n43#1:205\n43#1:206,6\n43#1:240\n49#1:278\n49#1:279,5\n49#1:312\n49#1:322\n43#1:339\n71#1:383\n71#1:384,6\n71#1:418\n71#1:487\n103#1:505\n103#1:506,6\n103#1:540\n103#1:545\n43#1:212,6\n43#1:227,4\n43#1:237,2\n47#1:248,6\n47#1:263,4\n47#1:273,2\n49#1:284,6\n49#1:299,4\n49#1:309,2\n49#1:321\n47#1:326\n43#1:338\n69#1:354,6\n69#1:369,4\n69#1:379,2\n71#1:390,6\n71#1:405,4\n71#1:415,2\n71#1:434,6\n75#1:449,6\n75#1:464,4\n75#1:474,2\n75#1:480\n71#1:485\n69#1:502\n103#1:512,6\n103#1:527,4\n103#1:537,2\n103#1:544\n141#1:554,6\n141#1:569,4\n141#1:579,2\n141#1:587\n43#1:218,9\n43#1:239\n47#1:254,9\n47#1:275\n49#1:290,9\n49#1:311\n49#1:319,2\n47#1:324,2\n43#1:336,2\n69#1:360,9\n69#1:381\n71#1:396,9\n71#1:417\n75#1:455,9\n75#1:476\n75#1:478,2\n71#1:483,2\n69#1:500,2\n103#1:518,9\n103#1:539\n103#1:542,2\n141#1:560,9\n141#1:581\n141#1:585,2\n43#1:231,6\n47#1:267,6\n49#1:303,6\n69#1:373,6\n71#1:409,6\n75#1:468,6\n103#1:531,6\n141#1:573,6\n47#1:241\n47#1:242,6\n47#1:276\n47#1:327\n75#1:442\n75#1:443,6\n75#1:477\n75#1:481\n141#1:546\n141#1:547,7\n141#1:582\n141#1:588\n49#1:277\n56#1:323\n60#1:334\n62#1:335\n69#1:346\n71#1:419\n72#1:426\n74#1:441\n80#1:482\n93#1:504\n108#1:541\n142#1:583\n143#1:584\n150#1:589\n151#1:590\n69#1:347\n69#1:348,6\n69#1:382\n71#1:427\n71#1:428,6\n71#1:440\n71#1:486\n69#1:503\n41#1:591\n41#1:592,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000D\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u001a.\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0017\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u0005\u00a2\u0006\u0002\u0008\u0007H\u0001\u00a2\u0006\u0002\u0010\u0008\u001a\u0015\u0010\t\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0003\u00a2\u0006\u0002\u0010\n\u001a\u0015\u0010\u000b\u001a\u00020\u00012\u0006\u0010\u000c\u001a\u00020\rH\u0001\u00a2\u0006\u0002\u0010\u000e\u001aF\u0010\u000f\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0017\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u0005\u00a2\u0006\u0002\u0008\u00072\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0014H\u0001\u00a2\u0006\u0002\u0010\u0015\u001a\u0015\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\rH\u0003\u00a2\u0006\u0002\u0010\u000e\u001a#\u0010\u0018\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u000c\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u001aH\u0003\u00a2\u0006\u0002\u0010\u001b\u001a#\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u000c\u0010\u001d\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u001aH\u0001\u00a2\u0006\u0002\u0010\u001b\u001a\u0013\u0010\u001e\u001a\u00020\u0012*\u00020\u001fH\u0000\u00a2\u0006\u0004\u0008 \u0010!\u00a8\u0006\"\u00b2\u0006\n\u0010#\u001a\u00020\u0014X\u008a\u008e\u0002"
    }
    d2 = {
        "HomeScreen",
        "",
        "host",
        "Lorg/lighttouch/android/GuestHost;",
        "guestSurface",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/Modifier;",
        "Landroidx/compose/runtime/Composable;",
        "(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V",
        "TopBar",
        "(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/Composer;I)V",
        "StatusDot",
        "status",
        "",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "GuestScreen",
        "modifier",
        "overlayScale",
        "",
        "inDeviceView",
        "",
        "(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZLandroidx/compose/runtime/Composer;I)V",
        "Busy",
        "label",
        "Dock",
        "onStop",
        "Lkotlin/Function0;",
        "(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "StopDialog",
        "onDismiss",
        "luminance",
        "Landroidx/compose/ui/graphics/Color;",
        "luminance-8_81llA",
        "(J)F",
        "app_debug",
        "confirmStop"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$1WSvnNyMfZDU1JFOJSn2iW83Dz4(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/HomeScreenKt;->GuestScreen$lambda$26(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$CeLcMsLQs2P_VU5_YB3hBq5G-g4(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt;->TopBar$lambda$22$lambda$21$lambda$20(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$H-Xr6LOoMtVY1Ay7OUL6UAbX9JY(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HomeScreenKt;->Busy$lambda$28(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$K9nGxg8FYNU3QOGeScN-iOgblGk(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/HomeScreenKt;->StopDialog$lambda$30(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KKr8j_h7vfpi9SSKLYnitPZgdoI(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen$lambda$11$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$LdlhH6HJnEHcFS9a1llT7sB4kNY(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/HomeScreenKt;->Dock$lambda$29(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RW8z8OFdyLNfLBtT5Wl5YrE3_Vk(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen$lambda$4$lambda$3(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ui8mJgvymmxOosIRf844K9AGuAA(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen$lambda$12(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$p_WltthzBGVBp8ogcc5E3MR-juM(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HomeScreenKt;->StatusDot$lambda$24(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$sZSWxyE5K3dOwIHGkXuQt6Svmlw(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt;->TopBar$lambda$22$lambda$19$lambda$18(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$sp7Nf1wW2gVlZvwX_RJRSy6w7Xg(Lorg/lighttouch/android/GuestHost;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HomeScreenKt;->TopBar$lambda$23(Lorg/lighttouch/android/GuestHost;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$z5YVEFK6HZeqaDI0jI86sfl_6D8(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt;->TopBar$lambda$22$lambda$17$lambda$14$lambda$13(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method private static final Busy(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 47
    .param p0, "label"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 140
    move-object/from16 v0, p0

    const v1, 0x25d87a81

    move-object/from16 v2, p1

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(Busy)140@8579L319:HomeScreen.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, p2, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 588
    :cond_2
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v38, v2

    move/from16 v40, v3

    goto/16 :goto_4

    .line 140
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.Busy (HomeScreen.kt:139)"

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 141
    :cond_4
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    .local v1, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v4, 0x180

    .local v4, "$changed\\1":I
    move/from16 v25, v4

    .end local v4    # "$changed\\1":I
    .local v25, "$changed\\1":I
    const/16 v26, 0x0

    .line 546
    .local v26, "$i$f$Column\\1\\141":I
    const v4, -0x1cd0f17e

    const-string v5, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v2, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 547
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    .line 548
    .local v4, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v5

    .line 552
    .local v5, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v6, v25, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v7, v25, 0x3

    and-int/lit8 v7, v7, 0x70

    or-int/2addr v6, v7

    invoke-static {v5, v1, v2, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v7, v25, 0x3

    and-int/lit8 v7, v7, 0x70

    .line 553
    move/from16 v27, v7

    .local v27, "$changed\\2":I
    const/16 v28, 0x0

    .line 554
    .local v28, "$i$f$Layout\\2\\553":I
    const v7, -0x4ee9b9da

    const-string v8, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v2, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 555
    const/4 v7, 0x0

    invoke-static {v2, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 556
    .local v29, "compositeKeyHash\\2":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 557
    .local v7, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 559
    .local v8, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v9

    shl-int/lit8 v10, v27, 0x6

    and-int/lit16 v10, v10, 0x380

    const/4 v11, 0x6

    or-int/2addr v10, v11

    .line 558
    nop

    .local v9, "factory\\3":Lkotlin/jvm/functions/Function0;
    move/from16 v30, v10

    .local v30, "$changed\\3":I
    const/16 v31, 0x0

    .line 560
    .local v31, "$i$f$ReusableComposeNode\\3\\558":I
    const v10, -0x2942ffcf

    const-string v12, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v2, v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 561
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v10

    instance-of v10, v10, Landroidx/compose/runtime/Applier;

    if-nez v10, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 562
    :cond_5
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 563
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-eqz v10, :cond_6

    .line 564
    invoke-interface {v2, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_2

    .line 566
    :cond_6
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 568
    :goto_2
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .local v10, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 569
    .local v12, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\568\\2":I
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v10, v6, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 570
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v10, v7, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 572
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\5":Lkotlin/jvm/functions/Function2;
    const/4 v14, 0x0

    .line 573
    .local v14, "$i$f$set-impl\\5\\572":I
    move-object v15, v10

    .local v15, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 574
    .local v16, "$i$a$-with-Updater$set$1\\6\\573\\5":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v17

    if-nez v17, :cond_7

    move/from16 p1, v11

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v11, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_3

    :cond_7
    move/from16 p1, v11

    .line 575
    :goto_3
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 576
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v10, v0, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 578
    :cond_8
    nop

    .line 573
    .end local v15    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-with-Updater$set$1\\6\\573\\5":I
    nop

    .line 578
    nop

    .line 579
    .end local v13    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v14    # "$i$f$set-impl\\5\\572":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v10, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 580
    nop

    .line 568
    .end local v10    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\568\\2":I
    nop

    .line 581
    shr-int/lit8 v0, v30, 0x6

    and-int/lit8 v32, v0, 0xe

    .local v32, "$changed\\7":I
    move-object v0, v2

    .local v0, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 582
    .local v33, "$i$a$-Layout-ColumnKt$Column$1\\7\\581\\1":I
    const v10, -0x16ef5699

    const-string v11, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v0, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v10, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v11, v25, 0x6

    and-int/lit8 v11, v11, 0x70

    or-int/lit8 v34, v11, 0x6

    .local v34, "$changed\\8":I
    move-object/from16 v35, v10

    check-cast v35, Landroidx/compose/foundation/layout/ColumnScope;

    .local v35, "$this$Busy_u24lambda_u2427\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v10, v0

    .local v10, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 142
    .local v36, "$i$a$-Column-HomeScreenKt$Busy$1\\8\\582\\0":I
    const v11, 0x5348ea4

    const-string v12, "C141@8648L99,142@8756L30,143@8870L10,143@8795L97:HomeScreen.kt#o13vsk"

    invoke-static {v10, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v11, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v11

    const/4 v13, 0x3

    .local v13, "$this$dp\\9":I
    const/4 v14, 0x0

    .line 583
    .local v14, "$i$f$getDp\\9\\142":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 142
    .end local v13    # "$this$dp\\9":I
    .end local v14    # "$i$f$getDp\\9\\142":I
    sget-object v14, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v14, Landroidx/compose/ui/Modifier;

    const/16 v15, 0x24

    .local v15, "$this$dp\\10":I
    const/16 v16, 0x0

    .line 583
    .local v16, "$i$f$getDp\\10\\142":I
    move-object/from16 v20, v0

    .end local v0    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\7":Landroidx/compose/runtime/Composer;
    int-to-float v0, v15

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 142
    .end local v15    # "$this$dp\\10":I
    .end local v16    # "$i$f$getDp\\10\\142":I
    invoke-static {v14, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v18, 0x1b6

    const/16 v19, 0x18

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    move-object/from16 v17, v10

    move-object v10, v0

    .end local v10    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v17, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v19}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-LxG7B9w(Landroidx/compose/ui/Modifier;JFJILandroidx/compose/runtime/Composer;II)V

    .line 143
    move-object/from16 v0, v17

    .end local v17    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v10, Landroidx/compose/ui/Modifier;

    const/16 v11, 0xe

    .local v11, "$this$dp\\11":I
    const/4 v12, 0x0

    .line 584
    .local v12, "$i$f$getDp\\11\\143":I
    int-to-float v13, v11

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 143
    .end local v11    # "$this$dp\\11":I
    .end local v12    # "$i$f$getDp\\11\\143":I
    invoke-static {v10, v11}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v10

    move/from16 v11, p1

    invoke-static {v10, v0, v11}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 144
    sget-object v10, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v11

    const/16 v17, 0xe

    const/16 v18, 0x0

    const v13, 0x3f59999a    # 0.85f

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    invoke-static/range {v11 .. v18}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v10

    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v0, v13}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v12

    and-int/lit8 v13, v3, 0xe

    or-int/lit16 v13, v13, 0x180

    const/16 v23, 0x0

    const v24, 0xfffa

    move-object v14, v1

    .end local v1    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v14, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    const/4 v1, 0x0

    move-object v15, v4

    move-object/from16 v16, v5

    .end local v4    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v5    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v15, "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v16, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const-wide/16 v4, 0x0

    move-object/from16 v17, v6

    .end local v6    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v17, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v6, 0x0

    move-object/from16 v18, v7

    .end local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v18, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v7, 0x0

    move-object/from16 v19, v8

    .end local v8    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v19, "materialized\\2":Landroidx/compose/ui/Modifier;
    const/4 v8, 0x0

    move-object/from16 v21, v2

    move/from16 v22, v3

    move-wide v2, v10

    move-object v11, v9

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .end local v9    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v11, "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v21, "$composer":Landroidx/compose/runtime/Composer;
    .local v22, "$dirty":I
    const-wide/16 v9, 0x0

    move-object/from16 v37, v11

    .end local v11    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v37, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/4 v11, 0x0

    move-object/from16 v38, v20

    move-object/from16 v20, v12

    .end local v20    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    move-object/from16 v39, v14

    move/from16 v40, v22

    move/from16 v22, v13

    .end local v14    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v22    # "$dirty":I
    .local v39, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .local v40, "$dirty":I
    const-wide/16 v13, 0x0

    move-object/from16 v41, v15

    .end local v15    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v41, "modifier\\1":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    move-object/from16 v42, v16

    .end local v16    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v42, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v16, 0x0

    move-object/from16 v43, v17

    .end local v17    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v43, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v17, 0x0

    move-object/from16 v44, v18

    .end local v18    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v44, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v18, 0x0

    move-object/from16 v45, v19

    .end local v19    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v45, "materialized\\2":Landroidx/compose/ui/Modifier;
    const/16 v19, 0x0

    move-object/from16 v46, v38

    move-object/from16 v38, v21

    move-object/from16 v21, v0

    move-object/from16 v0, p0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v38, "$composer":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\7":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 142
    move-object/from16 v17, v21

    .end local v21    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v17, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v17 .. v17}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 145
    nop

    .line 582
    .end local v17    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\8":I
    .end local v35    # "$this$Busy_u24lambda_u2427\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v36    # "$i$a$-Column-HomeScreenKt$Busy$1\\8\\582\\0":I
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 581
    .end local v32    # "$changed\\7":I
    .end local v33    # "$i$a$-Layout-ColumnKt$Column$1\\7\\581\\1":I
    .end local v46    # "$composer\\7":Landroidx/compose/runtime/Composer;
    nop

    .line 585
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 560
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 586
    nop

    .line 554
    .end local v30    # "$changed\\3":I
    .end local v31    # "$i$f$ReusableComposeNode\\3\\558":I
    .end local v37    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 587
    nop

    .line 546
    .end local v27    # "$changed\\2":I
    .end local v28    # "$i$f$Layout\\2\\553":I
    .end local v29    # "compositeKeyHash\\2":I
    .end local v44    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v45    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 588
    nop

    .end local v25    # "$changed\\1":I
    .end local v26    # "$i$f$Column\\1\\141":I
    .end local v39    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v41    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v42    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v43    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_9
    :goto_4
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_a

    new-instance v2, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda0;

    move/from16 v3, p2

    invoke-direct {v2, v0, v3}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_5

    :cond_a
    move/from16 v3, p2

    .line 146
    :goto_5
    return-void
.end method

.method private static final Busy$lambda$28(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/HomeScreenKt;->Busy(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Dock(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 18
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "onStop"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 149
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const v3, -0x18ce93d2

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Dock)149@9004L11,150@9198L1100,149@8974L1324:HomeScreen.kt#o13vsk"

    invoke-static {v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, v2, 0x6

    if-nez v5, :cond_2

    and-int/lit8 v5, v2, 0x8

    if-nez v5, :cond_0

    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    goto :goto_0

    :cond_0
    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    :goto_0
    if-eqz v5, :cond_1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    :goto_1
    or-int/2addr v4, v5

    :cond_2
    and-int/lit8 v5, v2, 0x30

    if-nez v5, :cond_4

    invoke-interface {v14, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    const/16 v5, 0x20

    goto :goto_2

    :cond_3
    const/16 v5, 0x10

    :goto_2
    or-int/2addr v4, v5

    :cond_4
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_6

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_3

    .line 150
    :cond_5
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v3, v4

    goto/16 :goto_4

    .line 149
    :cond_6
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_7

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.Dock (HomeScreen.kt:148)"

    invoke-static {v3, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 150
    :cond_7
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v14, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v6

    const/16 v3, 0x18

    .local v3, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 589
    .local v5, "$i$f$getDp\\1\\150":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 150
    .end local v3    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\150":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    const/4 v5, 0x2

    .local v5, "$this$dp\\2":I
    const/4 v8, 0x0

    .line 589
    .local v8, "$i$f$getDp\\2\\150":I
    int-to-float v9, v5

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 150
    .end local v5    # "$this$dp\\2":I
    .end local v8    # "$i$f$getDp\\2\\150":I
    nop

    .line 151
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v11, 0x1

    invoke-static {v5, v8, v11, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/16 v8, 0x10

    .local v8, "$this$dp\\3":I
    const/4 v9, 0x0

    .line 590
    .local v9, "$i$f$getDp\\3\\151":I
    int-to-float v12, v8

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 151
    .end local v8    # "$this$dp\\3":I
    .end local v9    # "$i$f$getDp\\3\\151":I
    const/16 v9, 0xc

    .local v9, "$this$dp\\4":I
    const/4 v12, 0x0

    .line 590
    .local v12, "$i$f$getDp\\4\\151":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 151
    .end local v9    # "$this$dp\\4":I
    .end local v12    # "$i$f$getDp\\4\\151":I
    invoke-static {v5, v8, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const-string v8, "dock"

    invoke-static {v5, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 150
    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    .line 151
    new-instance v8, Lorg/lighttouch/android/HomeScreenKt$Dock$1;

    invoke-direct {v8, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$Dock$1;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V

    const/16 v9, 0x36

    const v12, 0x4d01cb09    # 1.3609794E8f

    invoke-static {v12, v11, v8, v14, v9}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    move-object v13, v8

    check-cast v13, Lkotlin/jvm/functions/Function2;

    .line 150
    const-wide/16 v8, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const v15, 0xc06006

    const/16 v16, 0x68

    move-object/from16 v17, v5

    move-object v5, v3

    move v3, v4

    move-object/from16 v4, v17

    .end local v4    # "$dirty":I
    .local v3, "$dirty":I
    invoke-static/range {v4 .. v16}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_8
    :goto_4
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v4

    if-eqz v4, :cond_9

    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v5, v0, v1, v2}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v4, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 163
    :cond_9
    return-void
.end method

.method private static final Dock$lambda$29(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/HomeScreenKt;->Dock(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final GuestScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZLandroidx/compose/runtime/Composer;I)V
    .locals 46
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "guestSurface"    # Lkotlin/jvm/functions/Function3;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "overlayScale"    # F
    .param p4, "inDeviceView"    # Z
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/ui/Modifier;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "FZ",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v0, p4

    move/from16 v9, p6

    const-string v4, "host"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "guestSurface"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "modifier"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    const v4, -0x6df2554e

    move-object/from16 v5, p5

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(GuestScreen)P(1!1,3,4)102@5994L2531:HomeScreen.kt#o13vsk"

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p6

    .local v5, "$dirty":I
    and-int/lit8 v6, v9, 0x6

    if-nez v6, :cond_2

    and-int/lit8 v6, v9, 0x8

    if-nez v6, :cond_0

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    goto :goto_0

    :cond_0
    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    :goto_0
    if-eqz v6, :cond_1

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    :goto_1
    or-int/2addr v5, v6

    :cond_2
    and-int/lit8 v6, v9, 0x30

    if-nez v6, :cond_4

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    const/16 v6, 0x20

    goto :goto_2

    :cond_3
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v5, v6

    :cond_4
    and-int/lit16 v6, v9, 0x180

    if-nez v6, :cond_6

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    const/16 v6, 0x100

    goto :goto_3

    :cond_5
    const/16 v6, 0x80

    :goto_3
    or-int/2addr v5, v6

    :cond_6
    and-int/lit16 v6, v9, 0xc00

    if-nez v6, :cond_8

    move/from16 v11, p3

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v6

    if-eqz v6, :cond_7

    const/16 v6, 0x800

    goto :goto_4

    :cond_7
    const/16 v6, 0x400

    :goto_4
    or-int/2addr v5, v6

    goto :goto_5

    :cond_8
    move/from16 v11, p3

    :goto_5
    and-int/lit16 v6, v9, 0x6000

    if-nez v6, :cond_a

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_9

    const/16 v6, 0x4000

    goto :goto_6

    :cond_9
    const/16 v6, 0x2000

    :goto_6
    or-int/2addr v5, v6

    :cond_a
    move v12, v5

    .end local v5    # "$dirty":I
    .local v12, "$dirty":I
    and-int/lit16 v5, v12, 0x2493

    const/16 v6, 0x2492

    if-ne v5, v6, :cond_c

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_b

    goto :goto_7

    .line 545
    :cond_b
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v7, v12

    goto/16 :goto_e

    .line 102
    :cond_c
    :goto_7
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_d

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.GuestScreen (HomeScreen.kt:101)"

    invoke-static {v4, v12, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 103
    :cond_d
    sget-object v4, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const-string v3, "guest_screen"

    invoke-static {v4, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\1":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x0

    .local v4, "$changed\\1":I
    const/4 v5, 0x0

    .line 505
    .local v5, "$i$f$Box\\1\\103":I
    const v6, 0x2bb5b5d7

    const-string v7, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v10, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 506
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v6

    .line 507
    .local v6, "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    const/4 v7, 0x0

    .line 510
    .local v7, "propagateMinConstraints\\1":Z
    invoke-static {v6, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v4, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 511
    move/from16 v21, v13

    .local v21, "$changed\\2":I
    const/16 v22, 0x0

    .line 512
    .local v22, "$i$f$Layout\\2\\511":I
    const v13, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 513
    const/4 v13, 0x0

    invoke-static {v10, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v23

    .line 514
    .local v23, "compositeKeyHash\\2":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 515
    .local v13, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 517
    .local v14, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v0, v21, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 516
    nop

    .local v0, "$changed\\3":I
    .local v15, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v24, 0x0

    .line 518
    .local v24, "$i$f$ReusableComposeNode\\3\\516":I
    move/from16 p5, v0

    .end local v0    # "$changed\\3":I
    .local p5, "$changed\\3":I
    const v0, -0x2942ffcf

    move-object/from16 v25, v3

    .end local v3    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v25, "modifier\\1":Landroidx/compose/ui/Modifier;
    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 519
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 520
    :cond_e
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 521
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_f

    .line 522
    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_8

    .line 524
    :cond_f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 526
    :goto_8
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 527
    .local v3, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\526\\2":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v17, v3

    .end local v3    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\526\\2":I
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\526\\2":I
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v0, v8, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 528
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v0, v13, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 530
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 531
    .local v16, "$i$f$set-impl\\5\\530":I
    move-object/from16 v18, v0

    .local v18, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 532
    .local v19, "$i$a$-with-Updater$set$1\\6\\531\\5":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v20

    if-nez v20, :cond_11

    move/from16 v26, v4

    .end local v4    # "$changed\\1":I
    .local v26, "$changed\\1":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v27, v5

    .end local v5    # "$i$f$Box\\1\\103":I
    .local v27, "$i$f$Box\\1\\103":I
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_10

    goto :goto_9

    :cond_10
    move-object/from16 v5, v18

    goto :goto_a

    .end local v26    # "$changed\\1":I
    .end local v27    # "$i$f$Box\\1\\103":I
    .restart local v4    # "$changed\\1":I
    .restart local v5    # "$i$f$Box\\1\\103":I
    :cond_11
    move/from16 v26, v4

    move/from16 v27, v5

    .line 533
    .end local v4    # "$changed\\1":I
    .end local v5    # "$i$f$Box\\1\\103":I
    .restart local v26    # "$changed\\1":I
    .restart local v27    # "$i$f$Box\\1\\103":I
    :goto_9
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 534
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 536
    :goto_a
    nop

    .line 531
    .end local v5    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-with-Updater$set$1\\6\\531\\5":I
    nop

    .line 536
    nop

    .line 537
    .end local v3    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\5\\530":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v0, v14, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 538
    nop

    .line 526
    .end local v0    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\526\\2":I
    nop

    .line 539
    shr-int/lit8 v0, p5, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object v3, v10

    .local v3, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 540
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\7\\539\\1":I
    const v5, -0x7ff519f7    # -1.000876E-39f

    move/from16 v28, v0

    .end local v0    # "$changed\\7":I
    .local v28, "$changed\\7":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v3, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v5, v26, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\8":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$GuestScreen_u24lambda_u2425\\8":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v18, v3

    .local v18, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 104
    .local v39, "$i$a$-Box-HomeScreenKt$GuestScreen$1\\8\\540\\0":I
    move-object/from16 v40, v3

    .end local v3    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v40, "$composer\\7":Landroidx/compose/runtime/Composer;
    const v3, -0x38aff46a

    move/from16 v41, v4

    .end local v4    # "$i$a$-Layout-BoxKt$Box$1\\7\\539\\1":I
    .local v41, "$i$a$-Layout-BoxKt$Box$1\\7\\539\\1":I
    const-string v4, "C103@6066L36,113@6674L1845,113@6600L1919:HomeScreen.kt#o13vsk"

    move/from16 v42, v5

    move-object/from16 v5, v18

    .end local v18    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v42, "$changed\\8":I
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    move-object/from16 v43, v6

    .end local v6    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .local v43, "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    const/4 v6, 0x1

    move/from16 v44, v7

    .end local v7    # "propagateMinConstraints\\1":Z
    .local v44, "propagateMinConstraints\\1":Z
    const/4 v7, 0x0

    invoke-static {v3, v4, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    and-int/lit8 v4, v12, 0x70

    or-int/lit8 v4, v4, 0x6

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v3, v5, v4}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 105
    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v3

    .local v3, "s\\8":Lorg/lighttouch/android/AppSettings;
    const v4, 0x6986b6e1

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "106@6215L191"

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 106
    invoke-static {v1}, Lorg/lighttouch/android/ShellKt;->getRunning(Lorg/lighttouch/android/GuestHost;)Z

    move-result v4

    if-eqz v4, :cond_14

    if-eqz p4, :cond_13

    invoke-virtual {v3}, Lorg/lighttouch/android/AppSettings;->getOverlayInDeviceView()Z

    move-result v4

    if-eqz v4, :cond_12

    goto :goto_b

    :cond_12
    move-object/from16 v45, v3

    move v7, v12

    move-object v2, v13

    move-object v3, v14

    move-object v4, v15

    goto :goto_c

    .line 107
    :cond_13
    :goto_b
    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getPerf()Lorg/lighttouch/android/PerfSnapshot;

    move-result-object v11

    move v4, v12

    .end local v12    # "$dirty":I
    .local v4, "$dirty":I
    invoke-virtual {v3}, Lorg/lighttouch/android/AppSettings;->getOverlay()Lorg/lighttouch/android/OverlayLevel;

    move-result-object v12

    move-object/from16 v16, v13

    .end local v13    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v16, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-virtual {v3}, Lorg/lighttouch/android/AppSettings;->getOverlayGraph()Lorg/lighttouch/android/OverlayGraph;

    move-result-object v13

    move-object/from16 v17, v14

    .end local v14    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v17, "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-virtual {v3}, Lorg/lighttouch/android/AppSettings;->getOverlayOpacity()F

    move-result v14

    move-object/from16 v18, v15

    .end local v15    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v18, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual {v3}, Lorg/lighttouch/android/AppSettings;->getDetailedTiming()Z

    move-result v15

    .line 108
    sget-object v19, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v7, v19

    check-cast v7, Landroidx/compose/ui/Modifier;

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Lorg/lighttouch/android/AppSettings;->getOverlayCorner()Lorg/lighttouch/android/OverlayCorner;

    move-result-object v2

    invoke-static {v6, v2}, Lorg/lighttouch/android/PerformanceOverlayKt;->of(Landroidx/compose/ui/Alignment$Companion;Lorg/lighttouch/android/OverlayCorner;)Landroidx/compose/ui/Alignment;

    move-result-object v2

    invoke-interface {v0, v7, v2}, Landroidx/compose/foundation/layout/BoxScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v6, 0x6

    .local v6, "$this$dp\\9":I
    const/4 v7, 0x0

    .line 541
    .local v7, "$i$f$getDp\\9\\108":I
    move-object/from16 v45, v3

    .end local v3    # "s\\8":Lorg/lighttouch/android/AppSettings;
    .local v45, "s\\8":Lorg/lighttouch/android/AppSettings;
    int-to-float v3, v6

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 108
    .end local v6    # "$this$dp\\9":I
    .end local v7    # "$i$f$getDp\\9\\108":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    shl-int/lit8 v3, v4, 0x9

    const/high16 v6, 0x380000

    and-int v19, v3, v6

    .line 107
    const/16 v20, 0x0

    move-object/from16 v3, v16

    move-object/from16 v16, v2

    move-object v2, v3

    move v7, v4

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    move/from16 v17, p3

    move-object/from16 v18, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v16    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v2, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v4, "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v7, "$dirty":I
    .local v18, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v20}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FLandroidx/compose/runtime/Composer;II)V

    .end local v18    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    goto :goto_c

    .line 106
    .end local v2    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v7    # "$dirty":I
    .end local v45    # "s\\8":Lorg/lighttouch/android/AppSettings;
    .local v3, "s\\8":Lorg/lighttouch/android/AppSettings;
    .restart local v12    # "$dirty":I
    .restart local v13    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v14    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .restart local v15    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_14
    move-object/from16 v45, v3

    move v7, v12

    move-object v2, v13

    move-object v3, v14

    move-object v4, v15

    .line 107
    .end local v12    # "$dirty":I
    .end local v13    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v15    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "materialized\\2":Landroidx/compose/ui/Modifier;
    .restart local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "$dirty":I
    .restart local v45    # "s\\8":Lorg/lighttouch/android/AppSettings;
    :goto_c
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 109
    nop

    .line 110
    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v6

    const-string v11, "running"

    invoke-static {v6, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_15

    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getDisplayAsleep()Z

    move-result v6

    if-eqz v6, :cond_15

    const-string v6, "asleep"

    move-object/from16 v29, v6

    goto :goto_d

    .line 111
    :cond_15
    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_16

    const/16 v29, 0x0

    goto :goto_d

    .line 112
    :cond_16
    invoke-interface {v1}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v6

    move-object/from16 v29, v6

    .line 109
    :goto_d
    nop

    .line 114
    .local v29, "state\\8":Ljava/lang/String;
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    invoke-interface {v0, v6}, Landroidx/compose/foundation/layout/BoxScope;->matchParentSize(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    new-instance v11, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;

    invoke-direct {v11, v1}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;-><init>(Lorg/lighttouch/android/GuestHost;)V

    const/16 v12, 0x36

    const v13, 0x321de762

    const/4 v14, 0x1

    invoke-static {v13, v14, v11, v5, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v11

    move-object/from16 v35, v11

    check-cast v35, Lkotlin/jvm/functions/Function4;

    const v37, 0x186000

    const/16 v38, 0x2c

    const/16 v31, 0x0

    const/16 v32, 0x0

    const-string v33, "guest-state"

    const/16 v34, 0x0

    move-object/from16 v36, v5

    move-object/from16 v30, v6

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v36, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v38}, Landroidx/compose/animation/AnimatedContentKt;->AnimatedContent(Ljava/lang/Object;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Alignment;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;Landroidx/compose/runtime/Composer;II)V

    .line 104
    .end local v36    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 136
    .end local v29    # "state\\8":Ljava/lang/String;
    .end local v45    # "s\\8":Lorg/lighttouch/android/AppSettings;
    nop

    .line 540
    .end local v0    # "$this$GuestScreen_u24lambda_u2425\\8":Landroidx/compose/foundation/layout/BoxScope;
    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v39    # "$i$a$-Box-HomeScreenKt$GuestScreen$1\\8\\540\\0":I
    .end local v42    # "$changed\\8":I
    invoke-static/range {v40 .. v40}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 539
    .end local v28    # "$changed\\7":I
    .end local v40    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v41    # "$i$a$-Layout-BoxKt$Box$1\\7\\539\\1":I
    nop

    .line 542
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 518
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 543
    nop

    .line 512
    .end local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v24    # "$i$f$ReusableComposeNode\\3\\516":I
    .end local p5    # "$changed\\3":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 544
    nop

    .line 505
    .end local v2    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v21    # "$changed\\2":I
    .end local v22    # "$i$f$Layout\\2\\511":I
    .end local v23    # "compositeKeyHash\\2":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 545
    nop

    .end local v8    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v25    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v26    # "$changed\\1":I
    .end local v27    # "$i$f$Box\\1\\103":I
    .end local v43    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .end local v44    # "propagateMinConstraints\\1":Z
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_17
    :goto_e
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_18

    new-instance v0, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda8;

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move v6, v9

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZI)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 137
    :cond_18
    return-void
.end method

.method private static final GuestScreen$lambda$26(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/HomeScreenKt;->GuestScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZLandroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final HomeScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V
    .locals 89
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "guestSurface"    # Lkotlin/jvm/functions/Function3;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/ui/Modifier;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const-string v3, "host"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "guestSurface"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    const v3, -0x65641bfe

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(HomeScreen)P(1)40@1793L34,41@1857L11,42@1955L11,42@1989L31,42@1903L1799,63@3741L23,63@3724L40:HomeScreen.kt#o13vsk"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    const/4 v8, 0x2

    if-nez v6, :cond_2

    and-int/lit8 v6, v2, 0x8

    if-nez v6, :cond_0

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    goto :goto_0

    :cond_0
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    :goto_0
    if-eqz v6, :cond_1

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    move v6, v8

    :goto_1
    or-int/2addr v5, v6

    :cond_2
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_4

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    const/16 v6, 0x20

    goto :goto_2

    :cond_3
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v5, v6

    :cond_4
    and-int/lit8 v6, v5, 0x13

    const/16 v9, 0x12

    if-ne v6, v9, :cond_6

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_5

    goto :goto_3

    .line 64
    :cond_5
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v28, v5

    goto/16 :goto_1b

    .line 40
    :cond_6
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_7

    const/4 v6, -0x1

    const-string v9, "org.lighttouch.android.HomeScreen (HomeScreen.kt:39)"

    invoke-static {v3, v5, v6, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_7
    const v3, 0x6e3c21fe

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "CC(remember):HomeScreen.kt#9igjgp"

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 41
    const/4 v9, 0x0

    move v10, v9

    .local v10, "invalid\\1":Z
    move-object v11, v4

    .local v11, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 193
    .local v12, "$i$f$cache\\1\\41":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\1":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 194
    .local v14, "$i$a$-let-ComposerKt$cache$1\\2\\193\\1":I
    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    const/4 v7, 0x0

    if-ne v13, v15, :cond_8

    .line 195
    const/4 v15, 0x0

    .line 41
    .local v15, "$i$a$-cache-HomeScreenKt$HomeScreen$confirmStop$2\\3\\195\\0":I
    move/from16 v16, v9

    invoke-static/range {v16 .. v16}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    invoke-static {v9, v7, v8, v7}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v9

    .line 195
    .end local v15    # "$i$a$-cache-HomeScreenKt$HomeScreen$confirmStop$2\\3\\195\\0":I
    nop

    .line 196
    .local v9, "value\\2":Ljava/lang/Object;
    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 197
    nop

    .end local v9    # "value\\2":Ljava/lang/Object;
    goto :goto_4

    .line 198
    :cond_8
    move/from16 v16, v9

    move-object v9, v13

    .line 194
    :goto_4
    nop

    .line 193
    .end local v13    # "it\\1":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\2\\193\\1":I
    nop

    .line 41
    .end local v10    # "invalid\\1":Z
    .end local v11    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\1\\41":I
    check-cast v9, Landroidx/compose/runtime/MutableState;

    .local v9, "confirmStop$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 42
    sget-object v10, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v10, v4, v11}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v10

    invoke-static {v10, v11}, Lorg/lighttouch/android/HomeScreenKt;->luminance-8_81llA(J)F

    move-result v10

    const/high16 v11, 0x3f000000    # 0.5f

    cmpg-float v10, v10, v11

    const/4 v11, 0x1

    if-gez v10, :cond_9

    move v10, v11

    goto :goto_5

    :cond_9
    move/from16 v10, v16

    .line 43
    .local v10, "dark":Z
    :goto_5
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/4 v13, 0x0

    invoke-static {v12, v13, v11, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v17

    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v4, v14}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v18

    const/16 v21, 0x2

    const/16 v22, 0x0

    const/16 v20, 0x0

    invoke-static/range {v17 .. v22}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\4":Z
    move-object v14, v4

    .local v14, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 199
    .local v15, "$i$f$cache\\4\\43":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\4":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 200
    .local v18, "$i$a$-let-ComposerKt$cache$1\\5\\199\\4":I
    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v8, v13, :cond_a

    .line 201
    const/4 v13, 0x0

    .local v13, "$i$a$-cache-HomeScreenKt$HomeScreen$1\\6\\201\\0":I
    new-instance v19, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda4;

    invoke-direct/range {v19 .. v19}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda4;-><init>()V

    .end local v13    # "$i$a$-cache-HomeScreenKt$HomeScreen$1\\6\\201\\0":I
    move-object/from16 v13, v19

    .line 202
    .local v13, "value\\5":Ljava/lang/Object;
    invoke-interface {v14, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 203
    nop

    .end local v13    # "value\\5":Ljava/lang/Object;
    goto :goto_6

    .line 204
    :cond_a
    move-object v13, v8

    .line 200
    :goto_6
    nop

    .line 199
    .end local v8    # "it\\4":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\5\\199\\4":I
    nop

    .line 43
    .end local v3    # "invalid\\4":Z
    .end local v14    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\4\\43":I
    check-cast v13, Lkotlin/jvm/functions/Function1;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v3, v16

    invoke-static {v12, v3, v13, v11, v7}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .local v8, "modifier\\7":Landroidx/compose/ui/Modifier;
    const/4 v3, 0x0

    .local v3, "$changed\\7":I
    const/4 v12, 0x0

    .line 205
    .local v12, "$i$f$Box\\7\\43":I
    const v13, 0x2bb5b5d7

    const-string v14, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v4, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 206
    sget-object v14, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v14

    .line 207
    .local v14, "contentAlignment\\7":Landroidx/compose/ui/Alignment;
    const/4 v15, 0x0

    .line 210
    .local v15, "propagateMinConstraints\\7":Z
    invoke-static {v14, v15}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v19, v3, 0x3

    and-int/lit8 v19, v19, 0x70

    .line 211
    nop

    .local v19, "$changed\\8":I
    const/16 v21, 0x0

    .line 212
    .local v21, "$i$f$Layout\\8\\211":I
    const v7, -0x4ee9b9da

    const-string v11, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v4, v7, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 213
    const/4 v7, 0x0

    invoke-static {v4, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v25

    .line 214
    .local v25, "compositeKeyHash\\8":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 215
    .local v7, "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v26, v3

    .end local v3    # "$changed\\7":I
    .local v26, "$changed\\7":I
    invoke-static {v4, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 217
    .local v3, "materialized\\8":Landroidx/compose/ui/Modifier;
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v27

    move/from16 v28, v5

    .end local v5    # "$dirty":I
    .local v28, "$dirty":I
    shl-int/lit8 v5, v19, 0x6

    and-int/lit16 v5, v5, 0x380

    move/from16 v29, v5

    const/4 v5, 0x6

    or-int/lit8 v29, v29, 0x6

    .line 216
    nop

    .local v29, "$changed\\9":I
    move-object/from16 v30, v27

    .local v30, "factory\\9":Lkotlin/jvm/functions/Function0;
    const/16 v27, 0x0

    .line 218
    .local v27, "$i$f$ReusableComposeNode\\9\\216":I
    move/from16 v31, v5

    const v5, -0x2942ffcf

    move-object/from16 v32, v8

    .end local v8    # "modifier\\7":Landroidx/compose/ui/Modifier;
    .local v32, "modifier\\7":Landroidx/compose/ui/Modifier;
    const-string v8, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 219
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 220
    :cond_b
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 221
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_c

    .line 222
    move-object/from16 v5, v30

    .end local v30    # "factory\\9":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\9":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_7

    .line 224
    .end local v5    # "factory\\9":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "factory\\9":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v5, v30

    .end local v30    # "factory\\9":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\9":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 226
    :goto_7
    move-object/from16 v30, v5

    .end local v5    # "factory\\9":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "factory\\9":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 227
    .local v34, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\10\\226\\8":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v36, v10

    .end local v10    # "dark":Z
    .local v36, "dark":Z
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v5, v13, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 228
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v5, v7, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 230
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\11":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 231
    .local v35, "$i$f$set-impl\\11\\230":I
    move-object/from16 v37, v5

    .local v37, "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 232
    .local v38, "$i$a$-with-Updater$set$1\\12\\231\\11":I
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v39

    if-nez v39, :cond_e

    move-object/from16 v39, v7

    .end local v7    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .local v39, "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move/from16 v40, v12

    .end local v12    # "$i$f$Box\\7\\43":I
    .local v40, "$i$f$Box\\7\\43":I
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v7, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_d

    goto :goto_8

    :cond_d
    move-object/from16 v12, v37

    goto :goto_9

    .end local v39    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v40    # "$i$f$Box\\7\\43":I
    .restart local v7    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "$i$f$Box\\7\\43":I
    :cond_e
    move-object/from16 v39, v7

    move/from16 v40, v12

    .line 233
    .end local v7    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "$i$f$Box\\7\\43":I
    .restart local v39    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v40    # "$i$f$Box\\7\\43":I
    :goto_8
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v12, v37

    .end local v37    # "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 234
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v5, v7, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 236
    :goto_9
    nop

    .line 231
    .end local v12    # "$this$set_impl_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    .end local v38    # "$i$a$-with-Updater$set$1\\12\\231\\11":I
    nop

    .line 236
    nop

    .line 237
    .end local v10    # "block\\11":Lkotlin/jvm/functions/Function2;
    .end local v35    # "$i$f$set-impl\\11\\230":I
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v3, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 238
    nop

    .line 226
    .end local v5    # "$this$Layout_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\10\\226\\8":I
    nop

    .line 239
    shr-int/lit8 v5, v29, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\13":I
    move-object v7, v4

    .local v7, "$composer\\13":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 240
    .local v10, "$i$a$-Layout-BoxKt$Box$1\\13\\239\\7":I
    const v12, -0x7ff519f7    # -1.000876E-39f

    move-object/from16 v34, v3

    .end local v3    # "materialized\\8":Landroidx/compose/ui/Modifier;
    .local v34, "materialized\\8":Landroidx/compose/ui/Modifier;
    const-string v3, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v7, v12, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v12, v26, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v12, v12, 0x6

    .local v12, "$changed\\14":I
    check-cast v3, Landroidx/compose/foundation/layout/BoxScope;

    .local v3, "$this$HomeScreen_u24lambda_u249\\14":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v44, v7

    .local v44, "$composer\\14":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 45
    .local v35, "$i$a$-Box-HomeScreenKt$HomeScreen$2\\14\\240\\0":I
    move/from16 v37, v5

    .end local v5    # "$changed\\13":I
    .local v37, "$changed\\13":I
    const v5, -0x6f7d10d6

    move-object/from16 v38, v7

    .end local v7    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\13":Landroidx/compose/runtime/Composer;
    const-string v7, "C45@2172L11,44@2079L176,46@2327L11,46@2264L923,58@3318L18,58@3407L11,58@3294L188,61@3562L134:HomeScreen.kt#o13vsk"

    move/from16 v66, v10

    move-object/from16 v10, v44

    .end local v44    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v66, "$i$a$-Layout-BoxKt$Box$1\\13\\239\\7":I
    invoke-static {v10, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    move/from16 v67, v12

    move-object/from16 v68, v13

    const/4 v7, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    .end local v12    # "$changed\\14":I
    .end local v13    # "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v67, "$changed\\14":I
    .local v68, "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v5, v7, v12, v13}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v41

    sget-object v42, Landroidx/compose/ui/graphics/Brush;->Companion:Landroidx/compose/ui/graphics/Brush$Companion;

    .line 46
    const/4 v5, 0x2

    new-array v5, v5, [Landroidx/compose/ui/graphics/Color;

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v10, v12}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v43

    if-eqz v36, :cond_f

    const v7, 0x3d8f5c29    # 0.07f

    goto :goto_a

    :cond_f
    const v7, 0x3dcccccd    # 0.1f

    :goto_a
    move/from16 v45, v7

    const/16 v49, 0xe

    const/16 v50, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    invoke-static/range {v43 .. v50}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v12

    invoke-static {v12, v13}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v7

    const/16 v16, 0x0

    aput-object v7, v5, v16

    sget-object v7, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v12

    invoke-static {v12, v13}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v7

    const/16 v23, 0x1

    aput-object v7, v5, v23

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v43

    .line 45
    const/16 v48, 0xe

    const/16 v49, 0x0

    const-wide/16 v44, 0x0

    const/16 v47, 0x0

    invoke-static/range {v42 .. v49}, Landroidx/compose/ui/graphics/Brush$Companion;->radialGradient-P_Vx-Ks$default(Landroidx/compose/ui/graphics/Brush$Companion;Ljava/util/List;JFIILjava/lang/Object;)Landroidx/compose/ui/graphics/Brush;

    move-result-object v42

    const/16 v45, 0x6

    const/16 v46, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    invoke-static/range {v41 .. v46}, Landroidx/compose/foundation/BackgroundKt;->background$default(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Brush;Landroidx/compose/ui/graphics/Shape;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v7, 0x0

    invoke-static {v5, v10, v7}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 47
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-static {v5, v7, v12, v13}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    sget-object v7, Landroidx/compose/foundation/layout/WindowInsets;->Companion:Landroidx/compose/foundation/layout/WindowInsets$Companion;

    move/from16 v12, v31

    invoke-static {v7, v10, v12}, Landroidx/compose/foundation/layout/WindowInsets_androidKt;->getSafeDrawing(Landroidx/compose/foundation/layout/WindowInsets$Companion;Landroidx/compose/runtime/Composer;I)Landroidx/compose/foundation/layout/WindowInsets;

    move-result-object v7

    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/WindowInsetsPaddingKt;->windowInsetsPadding(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/WindowInsets;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\15":Landroidx/compose/ui/Modifier;
    const/4 v7, 0x0

    .local v7, "$changed\\15":I
    const/4 v12, 0x0

    .line 241
    .local v12, "$i$f$Column\\15\\47":I
    const v13, -0x1cd0f17e

    move/from16 v17, v7

    .end local v7    # "$changed\\15":I
    .local v17, "$changed\\15":I
    const-string v7, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v13, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 242
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 243
    .local v7, "verticalArrangement\\15":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 246
    .local v13, "horizontalAlignment\\15":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v41, v17, 0x3

    and-int/lit8 v41, v41, 0xe

    shr-int/lit8 v42, v17, 0x3

    and-int/lit8 v42, v42, 0x70

    move/from16 v43, v12

    .end local v12    # "$i$f$Column\\15\\47":I
    .local v43, "$i$f$Column\\15\\47":I
    or-int v12, v41, v42

    invoke-static {v7, v13, v10, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v41, v17, 0x3

    and-int/lit8 v41, v41, 0x70

    .line 247
    nop

    .local v41, "$changed\\16":I
    const/16 v42, 0x0

    .line 248
    .local v42, "$i$f$Layout\\16\\247":I
    move-object/from16 v44, v7

    const v7, -0x4ee9b9da

    .end local v7    # "verticalArrangement\\15":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v44, "verticalArrangement\\15":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v10, v7, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 249
    const/4 v7, 0x0

    invoke-static {v10, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v45

    .line 250
    .local v45, "compositeKeyHash\\16":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 251
    .local v7, "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v46, v13

    .end local v13    # "horizontalAlignment\\15":Landroidx/compose/ui/Alignment$Horizontal;
    .local v46, "horizontalAlignment\\15":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v10, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 253
    .local v13, "materialized\\16":Landroidx/compose/ui/Modifier;
    sget-object v47, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v47 .. v47}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v47

    move-object/from16 v48, v5

    .end local v5    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v48, "modifier\\15":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v41, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v31, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 252
    nop

    .local v5, "$changed\\17":I
    move-object/from16 v49, v47

    .local v49, "factory\\17":Lkotlin/jvm/functions/Function0;
    const/16 v47, 0x0

    .line 254
    .local v47, "$i$f$ReusableComposeNode\\17\\252":I
    move/from16 v50, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\17":I
    .local v50, "$changed\\17":I
    invoke-static {v10, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 255
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 256
    :cond_10
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 257
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_11

    .line 258
    move-object/from16 v5, v49

    .end local v49    # "factory\\17":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\17":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b

    .line 260
    .end local v5    # "factory\\17":Lkotlin/jvm/functions/Function0;
    .restart local v49    # "factory\\17":Lkotlin/jvm/functions/Function0;
    :cond_11
    move-object/from16 v5, v49

    .end local v49    # "factory\\17":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\17":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 262
    :goto_b
    move-object/from16 v49, v5

    .end local v5    # "factory\\17":Lkotlin/jvm/functions/Function0;
    .restart local v49    # "factory\\17":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 263
    .local v51, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\18\\262\\16":I
    sget-object v52, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v69, v14

    .end local v14    # "contentAlignment\\7":Landroidx/compose/ui/Alignment;
    .local v69, "contentAlignment\\7":Landroidx/compose/ui/Alignment;
    invoke-virtual/range {v52 .. v52}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v5, v12, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 264
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v5, v7, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 266
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    .local v14, "block\\19":Lkotlin/jvm/functions/Function2;
    const/16 v52, 0x0

    .line 267
    .local v52, "$i$f$set-impl\\19\\266":I
    move-object/from16 v53, v5

    .local v53, "$this$set_impl_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 268
    .local v54, "$i$a$-with-Updater$set$1\\20\\267\\19":I
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v55

    if-nez v55, :cond_13

    move-object/from16 v55, v7

    .end local v7    # "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    .local v55, "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move-object/from16 v56, v12

    .end local v12    # "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v56, "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v7, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_12

    goto :goto_c

    :cond_12
    move-object/from16 v12, v53

    goto :goto_d

    .end local v55    # "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v56    # "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v7    # "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_13
    move-object/from16 v55, v7

    move-object/from16 v56, v12

    .line 269
    .end local v7    # "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v55    # "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v56    # "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_c
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v12, v53

    .end local v53    # "$this$set_impl_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 270
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v5, v7, v14}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 272
    :goto_d
    nop

    .line 267
    .end local v12    # "$this$set_impl_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-with-Updater$set$1\\20\\267\\19":I
    nop

    .line 272
    nop

    .line 273
    .end local v14    # "block\\19":Lkotlin/jvm/functions/Function2;
    .end local v52    # "$i$f$set-impl\\19\\266":I
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v13, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 274
    nop

    .line 262
    .end local v5    # "$this$Layout_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\18\\262\\16":I
    nop

    .line 275
    shr-int/lit8 v5, v50, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\21":I
    move-object v7, v10

    .local v7, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 276
    .local v12, "$i$a$-Layout-ColumnKt$Column$1\\21\\275\\15":I
    const v14, -0x16ef5699

    move/from16 v51, v5

    .end local v5    # "$changed\\21":I
    .local v51, "$changed\\21":I
    const-string v5, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v7, v14, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v14, v17, 0x6

    and-int/lit8 v14, v14, 0x70

    const/16 v31, 0x6

    or-int/lit8 v14, v14, 0x6

    .local v14, "$changed\\22":I
    check-cast v5, Landroidx/compose/foundation/layout/ColumnScope;

    .local v5, "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v77, v7

    .local v77, "$composer\\22":Landroidx/compose/runtime/Composer;
    move-object/from16 v70, v5

    .end local v5    # "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    .local v70, "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    const/4 v5, 0x0

    .line 48
    .local v5, "$i$a$-Column-HomeScreenKt$HomeScreen$2$1\\22\\276\\14":I
    move/from16 v52, v5

    .end local v5    # "$i$a$-Column-HomeScreenKt$HomeScreen$2$1\\22\\276\\14":I
    .local v52, "$i$a$-Column-HomeScreenKt$HomeScreen$2$1\\22\\276\\14":I
    const v5, -0x1ba78df1

    move-object/from16 v53, v7

    .end local v7    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v53, "$composer\\21":Landroidx/compose/runtime/Composer;
    const-string v7, "C47@2355L12,48@2380L474,54@3079L37,54@2969L147:HomeScreen.kt#o13vsk"

    move/from16 v54, v12

    move-object/from16 v12, v77

    .end local v77    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .local v12, "$composer\\22":Landroidx/compose/runtime/Composer;
    .local v54, "$i$a$-Layout-ColumnKt$Column$1\\21\\275\\15":I
    invoke-static {v12, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v5, v28, 0xe

    invoke-static {v0, v12, v5}, Lorg/lighttouch/android/HomeScreenKt;->TopBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/Composer;I)V

    .line 49
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v58, v5

    check-cast v58, Landroidx/compose/ui/Modifier;

    const/16 v61, 0x2

    const/16 v62, 0x0

    const/high16 v59, 0x3f800000    # 1.0f

    const/16 v60, 0x0

    move-object/from16 v57, v70

    .end local v70    # "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    .local v57, "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v57 .. v62}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    move/from16 v58, v14

    const/4 v7, 0x0

    const/4 v14, 0x0

    move-object/from16 v57, v13

    const/4 v13, 0x1

    .end local v13    # "materialized\\16":Landroidx/compose/ui/Modifier;
    .end local v14    # "$changed\\22":I
    .local v57, "materialized\\16":Landroidx/compose/ui/Modifier;
    .local v58, "$changed\\22":I
    .restart local v70    # "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static {v5, v7, v13, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/16 v7, 0x14

    .local v7, "$this$dp\\23":I
    const/4 v13, 0x0

    .line 277
    .local v13, "$i$f$getDp\\23\\49":I
    int-to-float v14, v7

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 49
    .end local v7    # "$this$dp\\23":I
    .end local v13    # "$i$f$getDp\\23\\49":I
    const/16 v13, 0x8

    .local v13, "$this$dp\\24":I
    const/4 v14, 0x0

    .line 277
    .local v14, "$i$f$getDp\\24\\49":I
    move/from16 v59, v14

    .end local v14    # "$i$f$getDp\\24\\49":I
    .local v59, "$i$f$getDp\\24\\49":I
    int-to-float v14, v13

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 49
    .end local v13    # "$this$dp\\24":I
    .end local v59    # "$i$f$getDp\\24\\49":I
    invoke-static {v5, v7, v13}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\25":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v7

    .local v7, "contentAlignment\\25":Landroidx/compose/ui/Alignment;
    const/16 v13, 0x30

    .local v13, "$changed\\25":I
    const/4 v14, 0x0

    .line 278
    .local v14, "$i$f$Box\\25\\49":I
    move/from16 v59, v13

    .end local v13    # "$changed\\25":I
    .local v59, "$changed\\25":I
    const-string v13, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    move/from16 v60, v14

    const v14, 0x2bb5b5d7

    .end local v14    # "$i$f$Box\\25\\49":I
    .local v60, "$i$f$Box\\25\\49":I
    invoke-static {v12, v14, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 279
    const/4 v13, 0x0

    .line 282
    .local v13, "propagateMinConstraints\\25":Z
    invoke-static {v7, v13}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v18, v59, 0x3

    and-int/lit8 v18, v18, 0x70

    .line 283
    nop

    .local v18, "$changed\\26":I
    const/16 v61, 0x0

    .line 284
    .local v61, "$i$f$Layout\\26\\283":I
    move-object/from16 v62, v7

    const v7, -0x4ee9b9da

    .end local v7    # "contentAlignment\\25":Landroidx/compose/ui/Alignment;
    .local v62, "contentAlignment\\25":Landroidx/compose/ui/Alignment;
    invoke-static {v12, v7, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 285
    const/4 v7, 0x0

    invoke-static {v12, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v11

    .line 286
    .local v11, "compositeKeyHash\\26":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 287
    .local v7, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v24, v11

    .end local v11    # "compositeKeyHash\\26":I
    .local v24, "compositeKeyHash\\26":I
    invoke-static {v12, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 289
    .local v11, "materialized\\26":Landroidx/compose/ui/Modifier;
    sget-object v63, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v63 .. v63}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v63

    move-object/from16 v64, v5

    .end local v5    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .local v64, "modifier\\25":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v18, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v31, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 288
    move-object/from16 v65, v63

    .local v5, "$changed\\27":I
    .local v65, "factory\\27":Lkotlin/jvm/functions/Function0;
    const/16 v63, 0x0

    .line 290
    .local v63, "$i$f$ReusableComposeNode\\27\\288":I
    move/from16 v71, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\27":I
    .local v71, "$changed\\27":I
    invoke-static {v12, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 291
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 292
    :cond_14
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 293
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_15

    .line 294
    move-object/from16 v5, v65

    .end local v65    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_e

    .line 296
    .end local v5    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v65    # "factory\\27":Lkotlin/jvm/functions/Function0;
    :cond_15
    move-object/from16 v5, v65

    .end local v65    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 298
    :goto_e
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 299
    .local v33, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\298\\26":I
    sget-object v65, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v72, v5

    .end local v5    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .local v72, "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v65 .. v65}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v8, v14, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 300
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v8, v7, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 302
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\29":Lkotlin/jvm/functions/Function2;
    const/16 v65, 0x0

    .line 303
    .local v65, "$i$f$set-impl\\29\\302":I
    move-object/from16 v73, v8

    .local v73, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    const/16 v74, 0x0

    .line 304
    .local v74, "$i$a$-with-Updater$set$1\\30\\303\\29":I
    invoke-interface/range {v73 .. v73}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v75

    if-nez v75, :cond_17

    move-object/from16 v75, v7

    .end local v7    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .local v75, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v73 .. v73}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move/from16 v76, v13

    .end local v13    # "propagateMinConstraints\\25":Z
    .local v76, "propagateMinConstraints\\25":Z
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v7, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_16

    goto :goto_f

    :cond_16
    move-object/from16 v13, v73

    goto :goto_10

    .end local v75    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v76    # "propagateMinConstraints\\25":Z
    .restart local v7    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v13    # "propagateMinConstraints\\25":Z
    :cond_17
    move-object/from16 v75, v7

    move/from16 v76, v13

    .line 305
    .end local v7    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v13    # "propagateMinConstraints\\25":Z
    .restart local v75    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v76    # "propagateMinConstraints\\25":Z
    :goto_f
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v13, v73

    .end local v73    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .local v13, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    invoke-interface {v13, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 306
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v8, v7, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 308
    :goto_10
    nop

    .line 303
    .end local v13    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .end local v74    # "$i$a$-with-Updater$set$1\\30\\303\\29":I
    nop

    .line 308
    nop

    .line 309
    .end local v5    # "block\\29":Lkotlin/jvm/functions/Function2;
    .end local v65    # "$i$f$set-impl\\29\\302":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v8, v11, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 310
    nop

    .line 298
    .end local v8    # "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\298\\26":I
    nop

    .line 311
    shr-int/lit8 v5, v71, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\31":I
    move-object v7, v12

    .local v7, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 312
    .local v8, "$i$a$-Layout-BoxKt$Box$1\\31\\311\\25":I
    const v13, -0x7ff519f7    # -1.000876E-39f

    move/from16 v33, v5

    .end local v5    # "$changed\\31":I
    .local v33, "$changed\\31":I
    const-string v5, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v7, v13, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v13, v59, 0x6

    and-int/lit8 v13, v13, 0x70

    const/16 v31, 0x6

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\32":I
    check-cast v5, Landroidx/compose/foundation/layout/BoxScope;

    .local v5, "$this$HomeScreen_u24lambda_u249_u24lambda_u247_u24lambda_u246\\32":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v83, v7

    .local v83, "$composer\\32":Landroidx/compose/runtime/Composer;
    const/16 v65, 0x0

    .line 50
    .local v65, "$i$a$-Box-HomeScreenKt$HomeScreen$2$1$1\\32\\312\\22":I
    move-object/from16 v73, v5

    .end local v5    # "$this$HomeScreen_u24lambda_u249_u24lambda_u247_u24lambda_u246\\32":Landroidx/compose/foundation/layout/BoxScope;
    .local v73, "$this$HomeScreen_u24lambda_u249_u24lambda_u247_u24lambda_u246\\32":Landroidx/compose/foundation/layout/BoxScope;
    const v5, 0x75414fff

    move-object/from16 v74, v7

    .end local v7    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v74, "$composer\\31":Landroidx/compose/runtime/Composer;
    const-string v7, "C49@2608L12,50@2651L100,49@2520L320:HomeScreen.kt#o13vsk"

    move/from16 v86, v8

    move-object/from16 v8, v83

    .end local v83    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v86, "$i$a$-Layout-BoxKt$Box$1\\31\\311\\25":I
    invoke-static {v8, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Lorg/lighttouch/android/DeviceSkin;->Companion:Lorg/lighttouch/android/DeviceSkin$Companion;

    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v7

    if-eqz v7, :cond_18

    invoke-virtual {v7}, Lorg/lighttouch/android/DeviceSummary;->getBoard()Ljava/lang/String;

    move-result-object v7

    goto :goto_11

    :cond_18
    const/4 v7, 0x0

    :goto_11
    invoke-virtual {v5, v7}, Lorg/lighttouch/android/DeviceSkin$Companion;->forBoard(Ljava/lang/String;)Lorg/lighttouch/android/DeviceSkin;

    move-result-object v77

    invoke-static {v0}, Lorg/lighttouch/android/ShellKt;->getRunning(Lorg/lighttouch/android/GuestHost;)Z

    move-result v78

    const v5, 0x4c5de2

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v7, v28, 0xe

    const/4 v5, 0x4

    if-eq v7, v5, :cond_1a

    and-int/lit8 v5, v28, 0x8

    if-eqz v5, :cond_19

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_19

    goto :goto_12

    :cond_19
    const/4 v5, 0x0

    goto :goto_13

    :cond_1a
    :goto_12
    const/4 v5, 0x1

    .local v5, "invalid\\33":Z
    :goto_13
    move-object v7, v8

    .local v7, "$this$cache\\33":Landroidx/compose/runtime/Composer;
    const/16 v79, 0x0

    .line 313
    .local v79, "$i$f$cache\\33\\50":I
    move/from16 v80, v5

    .end local v5    # "invalid\\33":Z
    .local v80, "invalid\\33":Z
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\33":Ljava/lang/Object;
    const/16 v81, 0x0

    .line 314
    .local v81, "$i$a$-let-ComposerKt$cache$1\\34\\313\\33":I
    if-nez v80, :cond_1c

    sget-object v82, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v87, v11

    .end local v11    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .local v87, "materialized\\26":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v82 .. v82}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v5, v11, :cond_1b

    goto :goto_14

    .line 318
    :cond_1b
    move-object/from16 v82, v5

    goto :goto_15

    .line 314
    .end local v87    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .restart local v11    # "materialized\\26":Landroidx/compose/ui/Modifier;
    :cond_1c
    move-object/from16 v87, v11

    .line 315
    .end local v11    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .restart local v87    # "materialized\\26":Landroidx/compose/ui/Modifier;
    :goto_14
    const/4 v11, 0x0

    .line 50
    .local v11, "$i$a$-cache-HomeScreenKt$HomeScreen$2$1$1$1\\35\\315\\32":I
    move-object/from16 v82, v5

    .end local v5    # "it\\33":Ljava/lang/Object;
    .local v82, "it\\33":Ljava/lang/Object;
    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$1$1$1$1;

    invoke-direct {v5, v0}, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$1$1$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v5, Lkotlin/reflect/KFunction;

    .line 315
    .end local v11    # "$i$a$-cache-HomeScreenKt$HomeScreen$2$1$1$1\\35\\315\\32":I
    nop

    .line 316
    .local v5, "value\\34":Ljava/lang/Object;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 317
    nop

    .line 314
    .end local v5    # "value\\34":Ljava/lang/Object;
    :goto_15
    nop

    .line 313
    .end local v81    # "$i$a$-let-ComposerKt$cache$1\\34\\313\\33":I
    .end local v82    # "it\\33":Ljava/lang/Object;
    nop

    .line 50
    .end local v7    # "$this$cache\\33":Landroidx/compose/runtime/Composer;
    .end local v79    # "$i$f$cache\\33\\50":I
    .end local v80    # "invalid\\33":Z
    check-cast v5, Lkotlin/reflect/KFunction;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v79, v5

    check-cast v79, Lkotlin/jvm/functions/Function2;

    .line 51
    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$1$1$2;

    invoke-direct {v5, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$1$1$2;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;)V

    const/16 v7, 0x36

    const v11, -0x54056c9c

    move/from16 v88, v13

    const/4 v13, 0x1

    .end local v13    # "$changed\\32":I
    .local v88, "$changed\\32":I
    invoke-static {v11, v13, v5, v8, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object/from16 v80, v5

    check-cast v80, Lkotlin/jvm/functions/Function3;

    .line 52
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v11, 0x0

    invoke-static {v5, v7, v13, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v81

    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/AppSettings;->getHaptics()Z

    move-result v82

    .line 50
    const/16 v84, 0x6c00

    const/16 v85, 0x0

    move-object/from16 v83, v8

    .end local v8    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v83    # "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static/range {v77 .. v85}, Lorg/lighttouch/android/DeviceFrameKt;->DeviceFrame(Lorg/lighttouch/android/DeviceSkin;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v83 .. v83}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 53
    nop

    .line 312
    .end local v65    # "$i$a$-Box-HomeScreenKt$HomeScreen$2$1$1\\32\\312\\22":I
    .end local v73    # "$this$HomeScreen_u24lambda_u249_u24lambda_u247_u24lambda_u246\\32":Landroidx/compose/foundation/layout/BoxScope;
    .end local v83    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .end local v88    # "$changed\\32":I
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 311
    .end local v33    # "$changed\\31":I
    .end local v74    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local v86    # "$i$a$-Layout-BoxKt$Box$1\\31\\311\\25":I
    nop

    .line 319
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 290
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 320
    nop

    .line 284
    .end local v63    # "$i$f$ReusableComposeNode\\27\\288":I
    .end local v71    # "$changed\\27":I
    .end local v72    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 321
    nop

    .line 278
    .end local v18    # "$changed\\26":I
    .end local v24    # "compositeKeyHash\\26":I
    .end local v61    # "$i$f$Layout\\26\\283":I
    .end local v75    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v87    # "materialized\\26":Landroidx/compose/ui/Modifier;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 322
    nop

    .line 55
    .end local v14    # "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v59    # "$changed\\25":I
    .end local v60    # "$i$f$Box\\25\\49":I
    .end local v62    # "contentAlignment\\25":Landroidx/compose/ui/Alignment;
    .end local v64    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .end local v76    # "propagateMinConstraints\\25":Z
    invoke-static {v0}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v71

    const/16 v63, 0xf

    const/16 v64, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    invoke-static/range {v59 .. v64}, Landroidx/compose/animation/EnterExitTransitionKt;->expandVertically$default(Landroidx/compose/animation/core/FiniteAnimationSpec;Landroidx/compose/ui/Alignment$Vertical;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/animation/EnterTransition;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v13, 0x0

    invoke-static {v13, v8, v7, v13}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeIn$default(Landroidx/compose/animation/core/FiniteAnimationSpec;FILjava/lang/Object;)Landroidx/compose/animation/EnterTransition;

    move-result-object v11

    invoke-virtual {v5, v11}, Landroidx/compose/animation/EnterTransition;->plus(Landroidx/compose/animation/EnterTransition;)Landroidx/compose/animation/EnterTransition;

    move-result-object v73

    invoke-static/range {v59 .. v64}, Landroidx/compose/animation/EnterExitTransitionKt;->shrinkVertically$default(Landroidx/compose/animation/core/FiniteAnimationSpec;Landroidx/compose/ui/Alignment$Vertical;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/animation/ExitTransition;

    move-result-object v5

    invoke-static {v13, v8, v7, v13}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeOut$default(Landroidx/compose/animation/core/FiniteAnimationSpec;FILjava/lang/Object;)Landroidx/compose/animation/ExitTransition;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroidx/compose/animation/ExitTransition;->plus(Landroidx/compose/animation/ExitTransition;)Landroidx/compose/animation/ExitTransition;

    move-result-object v74

    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$1$2;

    invoke-direct {v5, v0, v9}, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$1$2;-><init>(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/MutableState;)V

    const/16 v7, 0x36

    const v8, 0x5e3143d6

    const/4 v13, 0x1

    invoke-static {v8, v13, v5, v12, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object/from16 v76, v5

    check-cast v76, Lkotlin/jvm/functions/Function3;

    and-int/lit8 v5, v58, 0xe

    const v7, 0x186c00

    or-int v78, v5, v7

    const/16 v79, 0x12

    const/16 v72, 0x0

    const/16 v75, 0x0

    move-object/from16 v77, v12

    .end local v12    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .restart local v77    # "$composer\\22":Landroidx/compose/runtime/Composer;
    invoke-static/range {v70 .. v79}, Landroidx/compose/animation/AnimatedVisibilityKt;->AnimatedVisibility(Landroidx/compose/foundation/layout/ColumnScope;ZLandroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransition;Landroidx/compose/animation/ExitTransition;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v77    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer\\22":Landroidx/compose/runtime/Composer;
    const v5, -0x42f485d2

    invoke-interface {v12, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "55@3147L30"

    invoke-static {v12, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 56
    invoke-static {v0}, Lorg/lighttouch/android/ShellKt;->getActive(Lorg/lighttouch/android/GuestHost;)Z

    move-result v5

    if-nez v5, :cond_1d

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x10

    .local v7, "$this$dp\\36":I
    const/4 v8, 0x0

    .line 323
    .local v8, "$i$f$getDp\\36\\56":I
    int-to-float v11, v7

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 56
    .end local v7    # "$this$dp\\36":I
    .end local v8    # "$i$f$getDp\\36\\56":I
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v7, 0x6

    invoke-static {v5, v12, v7}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    :cond_1d
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 48
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 57
    nop

    .line 276
    .end local v12    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-Column-HomeScreenKt$HomeScreen$2$1\\22\\276\\14":I
    .end local v58    # "$changed\\22":I
    .end local v70    # "$this$HomeScreen_u24lambda_u249_u24lambda_u247\\22":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 275
    .end local v51    # "$changed\\21":I
    .end local v53    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-Layout-ColumnKt$Column$1\\21\\275\\15":I
    nop

    .line 324
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 254
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 325
    nop

    .line 248
    .end local v47    # "$i$f$ReusableComposeNode\\17\\252":I
    .end local v49    # "factory\\17":Lkotlin/jvm/functions/Function0;
    .end local v50    # "$changed\\17":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 326
    nop

    .line 241
    .end local v41    # "$changed\\16":I
    .end local v42    # "$i$f$Layout\\16\\247":I
    .end local v45    # "compositeKeyHash\\16":I
    .end local v55    # "localMap\\16":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57    # "materialized\\16":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 327
    nop

    .line 59
    .end local v17    # "$changed\\15":I
    .end local v43    # "$i$f$Column\\15\\47":I
    .end local v44    # "verticalArrangement\\15":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v46    # "horizontalAlignment\\15":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v48    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .end local v56    # "measurePolicy\\15":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getError()Ljava/lang/String;

    move-result-object v41

    const v5, 0x4c5de2

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v5, v28, 0xe

    const/4 v7, 0x4

    if-eq v5, v7, :cond_1f

    and-int/lit8 v5, v28, 0x8

    if-eqz v5, :cond_1e

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1e

    goto :goto_16

    :cond_1e
    const/16 v16, 0x0

    goto :goto_17

    :cond_1f
    :goto_16
    const/16 v16, 0x1

    .local v16, "invalid\\37":Z
    :goto_17
    move-object v5, v10

    .local v5, "$this$cache\\37":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 328
    .local v7, "$i$f$cache\\37\\59":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\37":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 329
    .local v11, "$i$a$-let-ComposerKt$cache$1\\38\\328\\37":I
    if-nez v16, :cond_21

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v8, v12, :cond_20

    goto :goto_18

    .line 333
    :cond_20
    move-object v13, v8

    goto :goto_19

    .line 330
    :cond_21
    :goto_18
    const/4 v12, 0x0

    .line 59
    .local v12, "$i$a$-cache-HomeScreenKt$HomeScreen$2$2\\39\\330\\14":I
    new-instance v13, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$2$1;

    invoke-direct {v13, v0}, Lorg/lighttouch/android/HomeScreenKt$HomeScreen$2$2$1;-><init>(Ljava/lang/Object;)V

    check-cast v13, Lkotlin/reflect/KFunction;

    .line 330
    .end local v12    # "$i$a$-cache-HomeScreenKt$HomeScreen$2$2\\39\\330\\14":I
    nop

    .line 331
    .local v13, "value\\38":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 332
    nop

    .line 329
    .end local v13    # "value\\38":Ljava/lang/Object;
    :goto_19
    nop

    .line 328
    .end local v8    # "it\\37":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\38\\328\\37":I
    nop

    .line 59
    .end local v5    # "$this$cache\\37":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\37\\59":I
    .end local v16    # "invalid\\37":Z
    check-cast v13, Lkotlin/reflect/KFunction;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v42, v13

    check-cast v42, Lkotlin/jvm/functions/Function0;

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTopCenter()Landroidx/compose/ui/Alignment;

    move-result-object v7

    invoke-interface {v3, v5, v7}, Landroidx/compose/foundation/layout/BoxScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    sget-object v7, Landroidx/compose/foundation/layout/WindowInsets;->Companion:Landroidx/compose/foundation/layout/WindowInsets$Companion;

    const/4 v12, 0x6

    invoke-static {v7, v10, v12}, Landroidx/compose/foundation/layout/WindowInsets_androidKt;->getSafeDrawing(Landroidx/compose/foundation/layout/WindowInsets$Companion;Landroidx/compose/runtime/Composer;I)Landroidx/compose/foundation/layout/WindowInsets;

    move-result-object v7

    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/WindowInsetsPaddingKt;->windowInsetsPadding(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/WindowInsets;)Landroidx/compose/ui/Modifier;

    move-result-object v43

    .line 60
    const/16 v5, 0x10

    .local v5, "$this$dp\\40":I
    const/4 v7, 0x0

    .line 334
    .local v7, "$i$f$getDp\\40\\60":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v44

    .line 60
    .end local v5    # "$this$dp\\40":I
    .end local v7    # "$i$f$getDp\\40\\60":I
    const/16 v5, 0x10

    .local v5, "$this$dp\\41":I
    const/4 v7, 0x0

    .line 334
    .local v7, "$i$f$getDp\\41\\60":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v46

    .line 60
    .end local v5    # "$this$dp\\41":I
    .end local v7    # "$i$f$getDp\\41\\60":I
    const/16 v5, 0x40

    .local v5, "$this$dp\\42":I
    const/4 v7, 0x0

    .line 334
    .local v7, "$i$f$getDp\\42\\60":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v45

    .line 60
    .end local v5    # "$this$dp\\42":I
    .end local v7    # "$i$f$getDp\\42\\60":I
    nop

    .line 59
    nop

    .line 60
    const/16 v48, 0x8

    const/16 v49, 0x0

    const/16 v47, 0x0

    invoke-static/range {v43 .. v49}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v43

    .line 59
    const/16 v45, 0x0

    const/16 v46, 0x0

    move-object/from16 v44, v10

    .end local v10    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-static/range {v41 .. v46}, Lorg/lighttouch/android/ShellKt;->ErrorBanner(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    .line 62
    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v41

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v7

    invoke-interface {v3, v5, v7}, Landroidx/compose/foundation/layout/BoxScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v7, 0x1

    .local v7, "$this$dp\\43":I
    const/4 v8, 0x0

    .line 335
    .local v8, "$i$f$getDp\\43\\62":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 62
    .end local v7    # "$this$dp\\43":I
    .end local v8    # "$i$f$getDp\\43\\62":I
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const-string v7, "session_status"

    invoke-static {v5, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v42

    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v7

    const/16 v23, 0x1

    invoke-static/range {v23 .. v23}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v45

    const/16 v64, 0x0

    const v65, 0x1fff0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v50, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const-wide/16 v54, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v63, 0xd80

    move-object/from16 v62, v44

    move-wide/from16 v43, v7

    .end local v44    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-static/range {v41 .. v65}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 45
    move-object/from16 v44, v62

    .end local v62    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .restart local v44    # "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 63
    nop

    .line 240
    .end local v3    # "$this$HomeScreen_u24lambda_u249\\14":Landroidx/compose/foundation/layout/BoxScope;
    .end local v35    # "$i$a$-Box-HomeScreenKt$HomeScreen$2\\14\\240\\0":I
    .end local v44    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local v67    # "$changed\\14":I
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 239
    .end local v37    # "$changed\\13":I
    .end local v38    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local v66    # "$i$a$-Layout-BoxKt$Box$1\\13\\239\\7":I
    nop

    .line 336
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 218
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 337
    nop

    .line 212
    .end local v27    # "$i$f$ReusableComposeNode\\9\\216":I
    .end local v29    # "$changed\\9":I
    .end local v30    # "factory\\9":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 338
    nop

    .line 205
    .end local v19    # "$changed\\8":I
    .end local v21    # "$i$f$Layout\\8\\211":I
    .end local v25    # "compositeKeyHash\\8":I
    .end local v34    # "materialized\\8":Landroidx/compose/ui/Modifier;
    .end local v39    # "localMap\\8":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 339
    nop

    .line 64
    .end local v15    # "propagateMinConstraints\\7":Z
    .end local v26    # "$changed\\7":I
    .end local v32    # "modifier\\7":Landroidx/compose/ui/Modifier;
    .end local v40    # "$i$f$Box\\7\\43":I
    .end local v68    # "measurePolicy\\7":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v69    # "contentAlignment\\7":Landroidx/compose/ui/Alignment;
    invoke-static {v9}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    if-eqz v3, :cond_23

    const v5, 0x4c5de2

    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\44":Z
    move-object v5, v4

    .local v5, "$this$cache\\44":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 340
    .local v6, "$i$f$cache\\44\\64":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\44":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 341
    .local v8, "$i$a$-let-ComposerKt$cache$1\\45\\340\\44":I
    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_22

    .line 342
    const/4 v10, 0x0

    .line 64
    .local v10, "$i$a$-cache-HomeScreenKt$HomeScreen$3\\46\\342\\0":I
    new-instance v11, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v11, v9}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda5;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 342
    .end local v10    # "$i$a$-cache-HomeScreenKt$HomeScreen$3\\46\\342\\0":I
    nop

    .line 343
    .local v11, "value\\45":Ljava/lang/Object;
    invoke-interface {v5, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 344
    nop

    .end local v11    # "value\\45":Ljava/lang/Object;
    goto :goto_1a

    .line 345
    :cond_22
    move-object v11, v7

    .line 341
    :goto_1a
    nop

    .line 340
    .end local v7    # "it\\44":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\45\\340\\44":I
    nop

    .line 64
    .end local v3    # "invalid\\44":Z
    .end local v5    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\44\\64":I
    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v3, v28, 0xe

    or-int/lit8 v3, v3, 0x30

    invoke-static {v0, v11, v4, v3}, Lorg/lighttouch/android/HomeScreenKt;->StopDialog(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    :cond_23
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_24

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v9    # "confirmStop$delegate":Landroidx/compose/runtime/MutableState;
    .end local v36    # "dark":Z
    :cond_24
    :goto_1b
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_25

    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v5, v0, v1, v2}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;I)V

    invoke-interface {v3, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 65
    :cond_25
    return-void
.end method

.method private static final HomeScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$confirmStop$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 41
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 591
    .local v3, "$i$f$getValue\\1\\41":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\41":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 41
    return v0
.end method

.method private static final HomeScreen$lambda$11$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$confirmStop$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 64
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HomeScreen$lambda$12(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HomeScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$confirmStop$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 41
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 592
    .local v4, "$i$f$setValue\\1\\41":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 593
    nop

    .line 41
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\41":I
    return-void
.end method

.method private static final HomeScreen$lambda$4$lambda$3(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    const/4 v0, 0x1

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsProperties_androidKt;->setTestTagsAsResourceId(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final StatusDot(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 7
    .param p0, "status"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    const-string v0, "status"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    const v0, -0x71faf89d

    invoke-interface {p1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object p1

    const-string v1, "C(StatusDot)92@5548L56:HomeScreen.kt#o13vsk"

    invoke-static {p1, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move v1, p2

    .local v1, "$dirty":I
    and-int/lit8 v2, p2, 0x6

    const/4 v3, 0x2

    if-nez v2, :cond_1

    invoke-interface {p1, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    move v2, v3

    :goto_0
    or-int/2addr v1, v2

    :cond_1
    and-int/lit8 v2, v1, 0x3

    if-ne v2, v3, :cond_3

    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_1

    .line 93
    :cond_2
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_5

    .line 88
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_4

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.StatusDot (HomeScreen.kt:87)"

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 89
    :cond_4
    const v0, 0x20e0c417

    invoke-interface {p1, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "90@5518L11"

    invoke-static {p1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    :goto_2
    goto :goto_3

    :sswitch_0
    const-string v0, "stopping"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_2

    :sswitch_1
    const-string v0, "running"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_2

    .line 90
    :cond_5
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getAccent-0d7_KjU()J

    move-result-wide v2

    goto :goto_4

    .line 89
    :sswitch_2
    const-string v0, "starting"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_2

    .line 90
    :cond_6
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v2

    goto :goto_4

    .line 89
    :sswitch_3
    const-string v0, "paused"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_2

    .line 90
    :cond_7
    const-wide v2, 0xff9aa2a6L

    invoke-static {v2, v3}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v2

    goto :goto_4

    .line 89
    :sswitch_4
    const-string v0, "failed"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_2

    .line 91
    :cond_8
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v2

    goto :goto_4

    :goto_3
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, p1, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOutline-0d7_KjU()J

    move-result-wide v2

    .line 89
    :goto_4
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 93
    .local v2, "color":J
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xa

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 504
    .local v5, "$i$f$getDp\\1\\93":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 93
    .end local v4    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\93":I
    invoke-static {v0, v4}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v2, v3, v4}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v4, 0x0

    invoke-static {v0, p1, v4}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "color":J
    :cond_9
    :goto_5
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_a

    new-instance v2, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0, p2}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 94
    :cond_a
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        -0x4c696bc3 -> :sswitch_4
        -0x3b5366d2 -> :sswitch_3
        0x4e7ce040 -> :sswitch_2
        0x5c6f15bf -> :sswitch_1
        0x6642b874 -> :sswitch_0
    .end sparse-switch
.end method

.method private static final StatusDot$lambda$24(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/HomeScreenKt;->StatusDot(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final StopDialog(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 24
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "host"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "onDismiss"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 167
    const v2, -0x6d1962e9

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(StopDialog)177@11175L405,182@11606L267,169@10613L128,170@10758L391,167@10486L1388:HomeScreen.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, p3, 0x6

    if-nez v5, :cond_2

    and-int/lit8 v5, p3, 0x8

    if-nez v5, :cond_0

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    goto :goto_0

    :cond_0
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    :goto_0
    if-eqz v5, :cond_1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    :goto_1
    or-int/2addr v4, v5

    :cond_2
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_4

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    const/16 v5, 0x20

    goto :goto_2

    :cond_3
    const/16 v5, 0x10

    :goto_2
    or-int/2addr v4, v5

    :cond_4
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_6

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_3

    .line 168
    :cond_5
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v19, v3

    move/from16 v23, v4

    goto/16 :goto_4

    .line 167
    :cond_6
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_7

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.StopDialog (HomeScreen.kt:166)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 168
    :cond_7
    invoke-static {}, Lorg/lighttouch/android/ShellKt;->getDialogTags()Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 178
    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$StopDialog$1;

    invoke-direct {v5, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$StopDialog$1;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V

    const v6, 0x290badcf

    const/4 v7, 0x1

    const/16 v8, 0x36

    invoke-static {v6, v7, v5, v3, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    check-cast v5, Lkotlin/jvm/functions/Function2;

    .line 168
    nop

    .line 183
    new-instance v6, Lorg/lighttouch/android/HomeScreenKt$StopDialog$2;

    invoke-direct {v6, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$StopDialog$2;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V

    const v9, 0x7bda9f8d

    invoke-static {v9, v7, v6, v3, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    check-cast v6, Lkotlin/jvm/functions/Function2;

    sget-object v9, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;

    invoke-virtual {v9}, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->getLambda$-1522395028$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .line 170
    new-instance v10, Lorg/lighttouch/android/HomeScreenKt$StopDialog$3;

    invoke-direct {v10, v0}, Lorg/lighttouch/android/HomeScreenKt$StopDialog$3;-><init>(Lorg/lighttouch/android/GuestHost;)V

    const v11, -0x31566eb5

    invoke-static {v11, v7, v10, v3, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v10

    check-cast v10, Lkotlin/jvm/functions/Function2;

    .line 171
    new-instance v11, Lorg/lighttouch/android/HomeScreenKt$StopDialog$4;

    invoke-direct {v11, v0}, Lorg/lighttouch/android/HomeScreenKt$StopDialog$4;-><init>(Lorg/lighttouch/android/GuestHost;)V

    const v12, -0x7eef5d6

    invoke-static {v12, v7, v11, v3, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function2;

    shr-int/lit8 v8, v4, 0x3

    and-int/lit8 v8, v8, 0xe

    const v11, 0x1b6db0

    or-int v20, v8, v11

    .line 168
    const/4 v8, 0x0

    move-object/from16 v19, v3

    move v11, v4

    move-object v4, v6

    move-object v6, v10

    move-object v3, v2

    move-object v2, v5

    move-object v5, v9

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v4    # "$dirty":I
    .local v11, "$dirty":I
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v9, 0x0

    move v13, v11

    .end local v11    # "$dirty":I
    .local v13, "$dirty":I
    const-wide/16 v11, 0x0

    move v15, v13

    .end local v13    # "$dirty":I
    .local v15, "$dirty":I
    const-wide/16 v13, 0x0

    move/from16 v17, v15

    .end local v15    # "$dirty":I
    .local v17, "$dirty":I
    const-wide/16 v15, 0x0

    move/from16 v18, v17

    .end local v17    # "$dirty":I
    .local v18, "$dirty":I
    const/16 v17, 0x0

    move/from16 v21, v18

    .end local v18    # "$dirty":I
    .local v21, "$dirty":I
    const/16 v18, 0x0

    move/from16 v22, v21

    .end local v21    # "$dirty":I
    .local v22, "$dirty":I
    const/16 v21, 0x0

    move/from16 v23, v22

    .end local v22    # "$dirty":I
    .local v23, "$dirty":I
    const/16 v22, 0x3f80

    invoke-static/range {v1 .. v22}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_8
    :goto_4
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_9

    new-instance v3, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda2;

    move/from16 v4, p3

    invoke-direct {v3, v0, v1, v4}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_5

    :cond_9
    move/from16 v4, p3

    .line 189
    :goto_5
    return-void
.end method

.method private static final StopDialog$lambda$30(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/HomeScreenKt;->StopDialog(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TopBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/Composer;I)V
    .locals 120
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 68
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x78223ff1

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(TopBar)68@3822L1436:HomeScreen.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_2

    and-int/lit8 v5, v1, 0x8

    if-nez v5, :cond_0

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    goto :goto_0

    :cond_0
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    :goto_0
    if-eqz v5, :cond_1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    move v5, v6

    :goto_1
    or-int/2addr v4, v5

    :cond_2
    and-int/lit8 v5, v4, 0x3

    if-ne v5, v6, :cond_4

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_3

    goto :goto_2

    .line 503
    :cond_3
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v24, v4

    goto/16 :goto_1c

    .line 68
    :cond_4
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_5

    const/4 v5, -0x1

    const-string v8, "org.lighttouch.android.TopBar (HomeScreen.kt:67)"

    invoke-static {v2, v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 69
    :cond_5
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v2, v5, v8, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v5, 0x40

    .local v5, "$this$dp\\1":I
    const/4 v10, 0x0

    .line 346
    .local v10, "$i$f$getDp\\1\\69":I
    int-to-float v11, v5

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 69
    .end local v5    # "$this$dp\\1":I
    .end local v10    # "$i$f$getDp\\1\\69":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v10

    const/16 v2, 0xc

    .local v2, "$this$dp\\2":I
    const/4 v5, 0x0

    .line 346
    .local v5, "$i$f$getDp\\2\\69":I
    int-to-float v11, v2

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 69
    .end local v2    # "$this$dp\\2":I
    .end local v5    # "$i$f$getDp\\2\\69":I
    const/4 v2, 0x4

    .local v2, "$this$dp\\3":I
    const/4 v5, 0x0

    .line 346
    .local v5, "$i$f$getDp\\3\\69":I
    int-to-float v12, v2

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 69
    .end local v2    # "$this$dp\\3":I
    .end local v5    # "$i$f$getDp\\3\\69":I
    const/16 v15, 0xa

    const/16 v16, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x0

    invoke-static/range {v10 .. v16}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\4":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v10, 0x186

    .local v10, "$changed\\4":I
    const/4 v11, 0x0

    .line 347
    .local v11, "$i$f$Row\\4\\69":I
    const v12, 0x2952b718

    const-string v13, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v3, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 348
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v14

    .line 352
    .local v14, "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v15, v10, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v16, v10, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v15, v15, v16

    invoke-static {v14, v5, v3, v15}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v10, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 353
    nop

    .local v16, "$changed\\5":I
    const/16 v17, 0x0

    .line 354
    .local v17, "$i$f$Layout\\5\\353":I
    move/from16 p1, v8

    const v8, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 355
    const/4 v6, 0x0

    invoke-static {v3, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v19

    .line 356
    .local v19, "compositeKeyHash\\5":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 357
    .local v12, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 359
    .local v7, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    shl-int/lit8 v6, v16, 0x6

    and-int/lit16 v6, v6, 0x380

    const/4 v8, 0x6

    or-int/2addr v6, v8

    .line 358
    move-object/from16 v24, v21

    .local v6, "$changed\\6":I
    .local v24, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v21, 0x0

    .line 360
    .local v21, "$i$f$ReusableComposeNode\\6\\358":I
    move/from16 v25, v8

    const v8, -0x2942ffcf

    move-object/from16 v26, v2

    .end local v2    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v26, "modifier\\4":Landroidx/compose/ui/Modifier;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 361
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_6

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 362
    :cond_6
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 363
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_7

    .line 364
    move-object/from16 v8, v24

    .end local v24    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v8, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v8}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 366
    .end local v8    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :cond_7
    move-object/from16 v8, v24

    .end local v24    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v8    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 368
    :goto_3
    move/from16 v24, v4

    .end local v4    # "$dirty":I
    .local v24, "$dirty":I
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 369
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\368\\5":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v30, v5

    .end local v5    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v30, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v15, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 370
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v12, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 372
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 373
    .local v29, "$i$f$set-impl\\8\\372":I
    move-object/from16 v31, v4

    .local v31, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 374
    .local v32, "$i$a$-with-Updater$set$1\\9\\373\\8":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v33

    if-nez v33, :cond_9

    move/from16 v33, v6

    .end local v6    # "$changed\\6":I
    .local v33, "$changed\\6":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v34, v8

    .end local v8    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v34, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_8

    goto :goto_4

    :cond_8
    move-object/from16 v8, v31

    goto :goto_5

    .end local v33    # "$changed\\6":I
    .end local v34    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "$changed\\6":I
    .restart local v8    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :cond_9
    move/from16 v33, v6

    move-object/from16 v34, v8

    .line 375
    .end local v6    # "$changed\\6":I
    .end local v8    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "$changed\\6":I
    .restart local v34    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :goto_4
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v8, v31

    .end local v31    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 376
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v4, v6, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 378
    :goto_5
    nop

    .line 373
    .end local v8    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-with-Updater$set$1\\9\\373\\8":I
    nop

    .line 378
    nop

    .line 379
    .end local v5    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\8\\372":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v7, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 380
    nop

    .line 368
    .end local v4    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\368\\5":I
    nop

    .line 381
    shr-int/lit8 v4, v33, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\10":I
    move-object v5, v3

    .local v5, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 382
    .local v6, "$i$a$-Layout-RowKt$Row$1\\10\\381\\4":I
    const v8, -0x184f2606

    move/from16 v28, v4

    .end local v4    # "$changed\\10":I
    .local v28, "$changed\\10":I
    const-string v4, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v5, v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v29, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v31, v10, 0x6

    and-int/lit8 v31, v31, 0x70

    or-int/lit8 v31, v31, 0x6

    .local v31, "$changed\\11":I
    move-object/from16 v35, v29

    check-cast v35, Landroidx/compose/foundation/layout/RowScope;

    .local v35, "$this$TopBar_u24lambda_u2422\\11":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v42, v5

    .local v42, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 70
    .local v29, "$i$a$-Row-HomeScreenKt$TopBar$1\\11\\382\\0":I
    const v8, -0x6b636ede

    move-object/from16 v45, v5

    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\10":Landroidx/compose/runtime/Composer;
    const-string v5, "C70@3993L961,81@4984L31,81@4963L134,82@5127L34,82@5106L146:HomeScreen.kt#o13vsk"

    move/from16 v46, v6

    move-object/from16 v6, v42

    .end local v42    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v46, "$i$a$-Layout-RowKt$Row$1\\10\\381\\4":I
    invoke-static {v6, v8, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v5

    .line 71
    .local v5, "device\\11":Lorg/lighttouch/android/DeviceSummary;
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v36, v8

    check-cast v36, Landroidx/compose/ui/Modifier;

    const/16 v39, 0x2

    const/16 v40, 0x0

    const/high16 v37, 0x3f800000    # 1.0f

    const/16 v38, 0x0

    invoke-static/range {v35 .. v40}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .local v8, "modifier\\12":Landroidx/compose/ui/Modifier;
    const/16 v36, 0x0

    .local v36, "$changed\\12":I
    const/16 v37, 0x0

    .line 383
    .local v37, "$i$f$Box\\12\\71":I
    move-object/from16 v47, v5

    .end local v5    # "device\\11":Lorg/lighttouch/android/DeviceSummary;
    .local v47, "device\\11":Lorg/lighttouch/android/DeviceSummary;
    const v5, 0x2bb5b5d7

    move-object/from16 v48, v7

    .end local v7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v48, "materialized\\5":Landroidx/compose/ui/Modifier;
    const-string v7, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v6, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 384
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v5

    .line 385
    .local v5, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    const/4 v7, 0x0

    .line 388
    .local v7, "propagateMinConstraints\\12":Z
    move/from16 v49, v10

    .end local v10    # "$changed\\4":I
    .local v49, "$changed\\4":I
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v38, v36, 0x3

    and-int/lit8 v38, v38, 0x70

    .line 389
    nop

    .local v38, "$changed\\13":I
    const/16 v39, 0x0

    .line 390
    .local v39, "$i$f$Layout\\13\\389":I
    move-object/from16 v40, v5

    const v5, -0x4ee9b9da

    .end local v5    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .local v40, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    invoke-static {v6, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 391
    const/4 v5, 0x0

    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v41

    .line 392
    .local v41, "compositeKeyHash\\13":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 393
    .local v5, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v42, v7

    .end local v7    # "propagateMinConstraints\\12":Z
    .local v42, "propagateMinConstraints\\12":Z
    invoke-static {v6, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 395
    .local v7, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v43

    move-object/from16 v44, v8

    .end local v8    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v44, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v8, v38, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 394
    nop

    .local v8, "$changed\\14":I
    move-object/from16 v50, v43

    .local v50, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v43, 0x0

    .line 396
    .local v43, "$i$f$ReusableComposeNode\\14\\394":I
    move/from16 v51, v8

    const v8, -0x2942ffcf

    .end local v8    # "$changed\\14":I
    .local v51, "$changed\\14":I
    invoke-static {v6, v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 397
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 398
    :cond_a
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 399
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_b

    .line 400
    move-object/from16 v8, v50

    .end local v50    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v8, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v8}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 402
    .end local v8    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v50    # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_b
    move-object/from16 v8, v50

    .end local v50    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v8    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 404
    :goto_6
    move-object/from16 v50, v8

    .end local v8    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v50    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 405
    .local v52, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\404\\13":I
    sget-object v53, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v54, v11

    .end local v11    # "$i$f$Row\\4\\69":I
    .local v54, "$i$f$Row\\4\\69":I
    invoke-virtual/range {v53 .. v53}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v8, v10, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 406
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v8, v5, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 408
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    .local v11, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v53, 0x0

    .line 409
    .local v53, "$i$f$set-impl\\16\\408":I
    move-object/from16 v55, v8

    .local v55, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v56, 0x0

    .line 410
    .local v56, "$i$a$-with-Updater$set$1\\17\\409\\16":I
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v57

    if-nez v57, :cond_d

    move-object/from16 v57, v5

    .end local v5    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v57, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v58, v10

    .end local v10    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v58, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v5, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_c

    goto :goto_7

    :cond_c
    move-object/from16 v10, v55

    goto :goto_8

    .end local v57    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v58    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v5    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_d
    move-object/from16 v57, v5

    move-object/from16 v58, v10

    .line 411
    .end local v5    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v57    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v58    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_7
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v10, v55

    .end local v55    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 412
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v8, v5, v11}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 414
    :goto_8
    nop

    .line 409
    .end local v10    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v56    # "$i$a$-with-Updater$set$1\\17\\409\\16":I
    nop

    .line 414
    nop

    .line 415
    .end local v11    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v53    # "$i$f$set-impl\\16\\408":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v8, v7, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 416
    nop

    .line 404
    .end local v8    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\404\\13":I
    nop

    .line 417
    shr-int/lit8 v5, v51, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\18":I
    move-object v8, v6

    .local v8, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 418
    .local v10, "$i$a$-Layout-BoxKt$Box$1\\18\\417\\12":I
    const v11, -0x7ff519f7    # -1.000876E-39f

    move/from16 v52, v5

    .end local v5    # "$changed\\18":I
    .local v52, "$changed\\18":I
    const-string v5, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v8, v11, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v11, v36, 0x6

    and-int/lit8 v11, v11, 0x70

    or-int/lit8 v11, v11, 0x6

    .local v11, "$changed\\19":I
    check-cast v5, Landroidx/compose/foundation/layout/BoxScope;

    .local v5, "$this$TopBar_u24lambda_u2422_u24lambda_u2417\\19":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v53, v8

    .local v53, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 71
    .local v55, "$i$a$-Box-HomeScreenKt$TopBar$1$1\\19\\418\\11":I
    move-object/from16 v56, v5

    .end local v5    # "$this$TopBar_u24lambda_u2422_u24lambda_u2417\\19":Landroidx/compose/foundation/layout/BoxScope;
    .local v56, "$this$TopBar_u24lambda_u2422_u24lambda_u2417\\19":Landroidx/compose/foundation/layout/BoxScope;
    const v5, -0x4930577a

    move-object/from16 v59, v7

    .end local v7    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v59, "materialized\\13":Landroidx/compose/ui/Modifier;
    const-string v7, "C70@4075L22,70@4020L932:HomeScreen.kt#o13vsk"

    move-object/from16 v60, v8

    .end local v53    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v60, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v8, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v7, 0xc

    .local v7, "$this$dp\\20":I
    const/16 v53, 0x0

    .line 419
    .local v53, "$i$f$getDp\\20\\71":I
    move/from16 v61, v10

    .end local v10    # "$i$a$-Layout-BoxKt$Box$1\\18\\417\\12":I
    .local v61, "$i$a$-Layout-BoxKt$Box$1\\18\\417\\12":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 71
    .end local v7    # "$this$dp\\20":I
    .end local v53    # "$i$f$getDp\\20\\71":I
    invoke-static {v7}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v7

    check-cast v7, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v5, v7}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v62

    const v5, 0x4c5de2

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "CC(remember):HomeScreen.kt#9igjgp"

    invoke-static {v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v10, v24, 0xe

    const/4 v5, 0x4

    if-eq v10, v5, :cond_f

    and-int/lit8 v5, v24, 0x8

    if-eqz v5, :cond_e

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_e

    goto :goto_9

    :cond_e
    const/4 v5, 0x0

    goto :goto_a

    :cond_f
    :goto_9
    move/from16 v5, p1

    .local v5, "invalid\\21":Z
    :goto_a
    move-object v10, v8

    .local v10, "$this$cache\\21":Landroidx/compose/runtime/Composer;
    const/16 v63, 0x0

    .line 420
    .local v63, "$i$f$cache\\21\\71":I
    move/from16 v64, v5

    .end local v5    # "invalid\\21":Z
    .local v64, "invalid\\21":Z
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\21":Ljava/lang/Object;
    const/16 v65, 0x0

    .line 421
    .local v65, "$i$a$-let-ComposerKt$cache$1\\22\\420\\21":I
    if-nez v64, :cond_11

    sget-object v66, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v69, v11

    .end local v11    # "$changed\\19":I
    .local v69, "$changed\\19":I
    invoke-virtual/range {v66 .. v66}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v5, v11, :cond_10

    goto :goto_b

    .line 425
    :cond_10
    move-object/from16 v66, v5

    goto :goto_c

    .line 421
    .end local v69    # "$changed\\19":I
    .restart local v11    # "$changed\\19":I
    :cond_11
    move/from16 v69, v11

    .line 422
    .end local v11    # "$changed\\19":I
    .restart local v69    # "$changed\\19":I
    :goto_b
    const/4 v11, 0x0

    .line 71
    .local v11, "$i$a$-cache-HomeScreenKt$TopBar$1$1$1\\23\\422\\19":I
    move-object/from16 v66, v5

    .end local v5    # "it\\21":Ljava/lang/Object;
    .local v66, "it\\21":Ljava/lang/Object;
    new-instance v5, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda9;

    invoke-direct {v5, v0}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda9;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 422
    .end local v11    # "$i$a$-cache-HomeScreenKt$TopBar$1$1$1\\23\\422\\19":I
    nop

    .line 423
    .local v5, "value\\22":Ljava/lang/Object;
    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 424
    nop

    .line 421
    .end local v5    # "value\\22":Ljava/lang/Object;
    :goto_c
    nop

    .line 420
    .end local v65    # "$i$a$-let-ComposerKt$cache$1\\22\\420\\21":I
    .end local v66    # "it\\21":Ljava/lang/Object;
    nop

    .line 71
    .end local v10    # "$this$cache\\21":Landroidx/compose/runtime/Composer;
    .end local v63    # "$i$f$cache\\21\\71":I
    .end local v64    # "invalid\\21":Z
    move-object/from16 v66, v5

    check-cast v66, Lkotlin/jvm/functions/Function0;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v67, 0x7

    const/16 v68, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    invoke-static/range {v62 .. v68}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 72
    const/16 v10, 0x8

    .local v10, "$this$dp\\24":I
    const/4 v11, 0x0

    .line 426
    .local v11, "$i$f$getDp\\24\\72":I
    move/from16 v62, v11

    .end local v11    # "$i$f$getDp\\24\\72":I
    .local v62, "$i$f$getDp\\24\\72":I
    int-to-float v11, v10

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 72
    .end local v10    # "$this$dp\\24":I
    .end local v62    # "$i$f$getDp\\24\\72":I
    const/4 v11, 0x6

    .local v11, "$this$dp\\25":I
    const/16 v62, 0x0

    .line 426
    .local v62, "$i$f$getDp\\25\\72":I
    move-object/from16 v63, v12

    .end local v12    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v63, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    int-to-float v12, v11

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 72
    .end local v11    # "$this$dp\\25":I
    .end local v62    # "$i$f$getDp\\25\\72":I
    invoke-static {v5, v10, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const-string v10, "device_selector"

    invoke-static {v5, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v10

    .line 71
    nop

    .local v5, "modifier\\26":Landroidx/compose/ui/Modifier;
    .local v10, "verticalAlignment\\26":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v11, 0x180

    .local v11, "$changed\\26":I
    const/4 v12, 0x0

    .line 427
    .local v12, "$i$f$Row\\26\\71":I
    move/from16 v62, v11

    const v11, 0x2952b718

    .end local v11    # "$changed\\26":I
    .local v62, "$changed\\26":I
    invoke-static {v8, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 428
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    .line 432
    .local v11, "horizontalArrangement\\26":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v13, v62, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v20, v62, 0x3

    and-int/lit8 v20, v20, 0x70

    or-int v13, v13, v20

    invoke-static {v11, v10, v8, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\26":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v20, v62, 0x3

    and-int/lit8 v20, v20, 0x70

    .line 433
    nop

    .local v20, "$changed\\27":I
    const/16 v64, 0x0

    .line 390
    .local v64, "$i$f$Layout\\27\\433":I
    move-object/from16 v65, v10

    const v10, -0x4ee9b9da

    .end local v10    # "verticalAlignment\\26":Landroidx/compose/ui/Alignment$Vertical;
    .local v65, "verticalAlignment\\26":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v8, v10, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 391
    const/4 v10, 0x0

    invoke-static {v8, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v66

    .line 392
    .local v66, "compositeKeyHash\\27":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 393
    .local v10, "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v67, v11

    .end local v11    # "horizontalArrangement\\26":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v67, "horizontalArrangement\\26":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v8, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 395
    .local v11, "materialized\\27":Landroidx/compose/ui/Modifier;
    sget-object v68, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v68 .. v68}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v68

    move-object/from16 v70, v5

    .end local v5    # "modifier\\26":Landroidx/compose/ui/Modifier;
    .local v70, "modifier\\26":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v20, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 394
    move-object/from16 v71, v68

    .local v5, "$changed\\28":I
    .local v71, "factory\\28":Lkotlin/jvm/functions/Function0;
    const/16 v68, 0x0

    .line 396
    .local v68, "$i$f$ReusableComposeNode\\28\\394":I
    move/from16 v72, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\28":I
    .local v72, "$changed\\28":I
    invoke-static {v8, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 397
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_12

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 398
    :cond_12
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 399
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_13

    .line 400
    move-object/from16 v5, v71

    .end local v71    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 402
    .end local v5    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .restart local v71    # "factory\\28":Lkotlin/jvm/functions/Function0;
    :cond_13
    move-object/from16 v5, v71

    .end local v71    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 404
    :goto_d
    move-object/from16 v71, v5

    .end local v5    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .restart local v71    # "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    const/16 v73, 0x0

    .line 434
    .local v73, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\29\\404\\27":I
    sget-object v74, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v75, v8

    .end local v8    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v75, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v74 .. v74}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v13, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 435
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 437
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\30":Lkotlin/jvm/functions/Function2;
    const/16 v74, 0x0

    .line 409
    .local v74, "$i$f$set-impl\\30\\437":I
    move-object/from16 v76, v5

    .local v76, "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    const/16 v77, 0x0

    .line 410
    .local v77, "$i$a$-with-Updater$set$1\\31\\409\\30":I
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v78

    if-nez v78, :cond_15

    move-object/from16 v78, v10

    .end local v10    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .local v78, "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    move/from16 v79, v12

    .end local v12    # "$i$f$Row\\26\\71":I
    .local v79, "$i$f$Row\\26\\71":I
    invoke-static/range {v66 .. v66}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v10, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_14

    goto :goto_e

    :cond_14
    move-object/from16 v12, v76

    goto :goto_f

    .end local v78    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v79    # "$i$f$Row\\26\\71":I
    .restart local v10    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "$i$f$Row\\26\\71":I
    :cond_15
    move-object/from16 v78, v10

    move/from16 v79, v12

    .line 411
    .end local v10    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "$i$f$Row\\26\\71":I
    .restart local v78    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v79    # "$i$f$Row\\26\\71":I
    :goto_e
    invoke-static/range {v66 .. v66}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    move-object/from16 v12, v76

    .end local v76    # "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 412
    invoke-static/range {v66 .. v66}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v5, v10, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 414
    :goto_f
    nop

    .line 409
    .end local v12    # "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    .end local v77    # "$i$a$-with-Updater$set$1\\31\\409\\30":I
    nop

    .line 414
    nop

    .line 438
    .end local v8    # "block\\30":Lkotlin/jvm/functions/Function2;
    .end local v74    # "$i$f$set-impl\\30\\437":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v11, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 439
    nop

    .line 404
    .end local v5    # "$this$Layout_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .end local v73    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\29\\404\\27":I
    nop

    .line 417
    shr-int/lit8 v5, v72, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\32":I
    move-object/from16 v8, v75

    .local v8, "$composer\\32":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 440
    .local v10, "$i$a$-Layout-RowKt$Row$1\\32\\417\\26":I
    const v12, -0x184f2606

    invoke-static {v8, v12, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v12, v62, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v12, v12, 0x6

    .local v12, "$changed\\33":I
    check-cast v4, Landroidx/compose/foundation/layout/RowScope;

    .local v4, "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416\\33":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v85, v8

    .local v85, "$composer\\33":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 73
    .local v32, "$i$a$-Row-HomeScreenKt$TopBar$1$1$2\\33\\440\\19":I
    move/from16 v73, v5

    .end local v5    # "$changed\\32":I
    .local v73, "$changed\\32":I
    const v5, 0x18c694ad

    move-object/from16 v74, v8

    .end local v8    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v74, "$composer\\32":Landroidx/compose/runtime/Composer;
    const-string v8, "C72@4245L22,73@4280L29,74@4322L465,79@4913L11,79@4800L142:HomeScreen.kt#o13vsk"

    move/from16 v76, v10

    move-object/from16 v10, v85

    .end local v85    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v76, "$i$a$-Layout-RowKt$Row$1\\32\\417\\26":I
    invoke-static {v10, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x0

    invoke-static {v5, v10, v8}, Lorg/lighttouch/android/HomeScreenKt;->StatusDot(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 74
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v8, 0xa

    .local v8, "$this$dp\\34":I
    const/16 v77, 0x0

    .line 441
    .local v77, "$i$f$getDp\\34\\74":I
    move-object/from16 v88, v11

    .end local v11    # "materialized\\27":Landroidx/compose/ui/Modifier;
    .local v88, "materialized\\27":Landroidx/compose/ui/Modifier;
    int-to-float v11, v8

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 74
    .end local v8    # "$this$dp\\34":I
    .end local v77    # "$i$f$getDp\\34\\74":I
    invoke-static {v5, v8}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    move/from16 v8, v25

    invoke-static {v5, v10, v8}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 75
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v11, 0x0

    invoke-interface {v4, v5, v8, v11}, Landroidx/compose/foundation/layout/RowScope;->weight(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\35":Landroidx/compose/ui/Modifier;
    const/4 v8, 0x0

    .local v8, "$changed\\35":I
    const/4 v11, 0x0

    .line 442
    .local v11, "$i$f$Column\\35\\75":I
    move-object/from16 v77, v4

    .end local v4    # "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416\\33":Landroidx/compose/foundation/layout/RowScope;
    .local v77, "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416\\33":Landroidx/compose/foundation/layout/RowScope;
    const v4, -0x1cd0f17e

    move/from16 v80, v8

    .end local v8    # "$changed\\35":I
    .local v80, "$changed\\35":I
    const-string v8, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v4, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 443
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 444
    .local v4, "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 447
    .local v8, "horizontalAlignment\\35":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v81, v80, 0x3

    and-int/lit8 v81, v81, 0xe

    shr-int/lit8 v82, v80, 0x3

    and-int/lit8 v82, v82, 0x70

    move/from16 v83, v11

    .end local v11    # "$i$f$Column\\35\\75":I
    .local v83, "$i$f$Column\\35\\75":I
    or-int v11, v81, v82

    invoke-static {v4, v8, v10, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\35":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v81, v80, 0x3

    and-int/lit8 v81, v81, 0x70

    .line 448
    nop

    .local v81, "$changed\\36":I
    const/16 v82, 0x0

    .line 449
    .local v82, "$i$f$Layout\\36\\448":I
    move-object/from16 v84, v4

    const v4, -0x4ee9b9da

    .end local v4    # "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v84, "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v10, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 450
    const/4 v4, 0x0

    invoke-static {v10, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v9

    .line 451
    .local v9, "compositeKeyHash\\36":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 452
    .local v4, "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v23, v8

    .end local v8    # "horizontalAlignment\\35":Landroidx/compose/ui/Alignment$Horizontal;
    .local v23, "horizontalAlignment\\35":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v10, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 454
    .local v8, "materialized\\36":Landroidx/compose/ui/Modifier;
    sget-object v85, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v85 .. v85}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v85

    move-object/from16 v86, v5

    .end local v5    # "modifier\\35":Landroidx/compose/ui/Modifier;
    .local v86, "modifier\\35":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v81, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v25, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 453
    nop

    .local v5, "$changed\\37":I
    move-object/from16 v87, v85

    .local v87, "factory\\37":Lkotlin/jvm/functions/Function0;
    const/16 v85, 0x0

    .line 455
    .local v85, "$i$f$ReusableComposeNode\\37\\453":I
    move/from16 v89, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\37":I
    .local v89, "$changed\\37":I
    invoke-static {v10, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 456
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 457
    :cond_16
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 458
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_17

    .line 459
    move-object/from16 v2, v87

    .end local v87    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 461
    .end local v2    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .restart local v87    # "factory\\37":Lkotlin/jvm/functions/Function0;
    :cond_17
    move-object/from16 v2, v87

    .end local v87    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 463
    :goto_10
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 464
    .local v27, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\38\\463\\36":I
    sget-object v87, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v90, v2

    .end local v2    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .local v90, "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v87 .. v87}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v11, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 465
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v4, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 467
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\39":Lkotlin/jvm/functions/Function2;
    const/16 v87, 0x0

    .line 468
    .local v87, "$i$f$set-impl\\39\\467":I
    move-object/from16 v91, v5

    .local v91, "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    const/16 v92, 0x0

    .line 469
    .local v92, "$i$a$-with-Updater$set$1\\40\\468\\39":I
    invoke-interface/range {v91 .. v91}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v93

    if-nez v93, :cond_19

    move-object/from16 v93, v4

    .end local v4    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .local v93, "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v91 .. v91}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v94, v9

    .end local v9    # "compositeKeyHash\\36":I
    .local v94, "compositeKeyHash\\36":I
    invoke-static/range {v94 .. v94}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_18

    goto :goto_11

    :cond_18
    move-object/from16 v9, v91

    goto :goto_12

    .end local v93    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v94    # "compositeKeyHash\\36":I
    .restart local v4    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "compositeKeyHash\\36":I
    :cond_19
    move-object/from16 v93, v4

    move/from16 v94, v9

    .line 470
    .end local v4    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "compositeKeyHash\\36":I
    .restart local v93    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v94    # "compositeKeyHash\\36":I
    :goto_11
    invoke-static/range {v94 .. v94}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v9, v91

    .end local v91    # "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 471
    invoke-static/range {v94 .. v94}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 473
    :goto_12
    nop

    .line 468
    .end local v9    # "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .end local v92    # "$i$a$-with-Updater$set$1\\40\\468\\39":I
    nop

    .line 473
    nop

    .line 474
    .end local v2    # "block\\39":Lkotlin/jvm/functions/Function2;
    .end local v87    # "$i$f$set-impl\\39\\467":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v8, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 475
    nop

    .line 463
    .end local v5    # "$this$Layout_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\38\\463\\36":I
    nop

    .line 476
    shr-int/lit8 v2, v89, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\41":I
    move-object v4, v10

    .local v4, "$composer\\41":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 477
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\41\\476\\35":I
    const v9, -0x16ef5699

    move/from16 v27, v2

    .end local v2    # "$changed\\41":I
    .local v27, "$changed\\41":I
    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v9, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v80, 0x6

    and-int/lit8 v9, v9, 0x70

    const/16 v25, 0x6

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\42":I
    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    .local v2, "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416_u24lambda_u2415\\42":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v116, v4

    .local v116, "$composer\\42":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 76
    .local v25, "$i$a$-Column-HomeScreenKt$TopBar$1$1$2$1\\42\\477\\33":I
    move-object/from16 v87, v2

    .end local v2    # "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416_u24lambda_u2415\\42":Landroidx/compose/foundation/layout/ColumnScope;
    .local v87, "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416_u24lambda_u2415\\42":Landroidx/compose/foundation/layout/ColumnScope;
    const v2, -0xe3c3c17

    move-object/from16 v91, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v91, "$composer\\41":Landroidx/compose/runtime/Composer;
    const-string v4, "C75@4438L10,75@4382L127,76@4632L10,77@4696L11,76@4526L247:HomeScreen.kt#o13vsk"

    move/from16 v92, v5

    move-object/from16 v5, v116

    .end local v116    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\42":Landroidx/compose/runtime/Composer;
    .local v92, "$i$a$-Layout-ColumnKt$Column$1\\41\\476\\35":I
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    if-eqz v47, :cond_1a

    invoke-virtual/range {v47 .. v47}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1b

    :cond_1a
    const-string v2, "\u65e0\u8bbe\u5907"

    :cond_1b
    move-object/from16 v95, v2

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v115

    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v110

    const/16 v118, 0xc30

    const v119, 0xd7fe

    const/16 v96, 0x0

    const-wide/16 v97, 0x0

    const-wide/16 v99, 0x0

    const/16 v101, 0x0

    const/16 v102, 0x0

    const/16 v103, 0x0

    const-wide/16 v104, 0x0

    const/16 v106, 0x0

    const/16 v107, 0x0

    const-wide/16 v108, 0x0

    const/16 v111, 0x0

    const/16 v112, 0x1

    const/16 v113, 0x0

    const/16 v114, 0x0

    const/16 v117, 0x0

    move-object/from16 v116, v5

    .end local v5    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v116    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v95 .. v119}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 77
    .end local v116    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\42":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/String;

    if-eqz v47, :cond_1c

    invoke-virtual/range {v47 .. v47}, Lorg/lighttouch/android/DeviceSummary;->getSubtitle()Ljava/lang/String;

    move-result-object v4

    move-object/from16 v18, v4

    goto :goto_13

    :cond_1c
    const/16 v18, 0x0

    :goto_13
    const/16 v22, 0x0

    aput-object v18, v2, v22

    invoke-interface {v0}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lorg/lighttouch/android/ShellKt;->statusLabel(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v2, p1

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    move-object/from16 v95, v2

    check-cast v95, Ljava/lang/Iterable;

    const-string v2, " \u00b7 "

    move-object/from16 v96, v2

    check-cast v96, Ljava/lang/CharSequence;

    const/16 v102, 0x3e

    const/16 v103, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const/16 v101, 0x0

    invoke-static/range {v95 .. v103}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v95

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v115

    .line 78
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v97

    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v110

    .line 77
    nop

    .line 78
    nop

    .line 77
    const/16 v118, 0xc30

    const v119, 0xd7fa

    const/16 v96, 0x0

    const-wide/16 v99, 0x0

    const/16 v102, 0x0

    const-wide/16 v104, 0x0

    const/16 v106, 0x0

    const/16 v107, 0x0

    const-wide/16 v108, 0x0

    const/16 v111, 0x0

    const/16 v112, 0x1

    const/16 v113, 0x0

    const/16 v114, 0x0

    const/16 v117, 0x0

    move-object/from16 v116, v5

    .end local v5    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v116    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v95 .. v119}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 76
    .end local v116    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 79
    nop

    .line 477
    .end local v5    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .end local v9    # "$changed\\42":I
    .end local v25    # "$i$a$-Column-HomeScreenKt$TopBar$1$1$2$1\\42\\477\\33":I
    .end local v87    # "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416_u24lambda_u2415\\42":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v91 .. v91}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 476
    .end local v27    # "$changed\\41":I
    .end local v91    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v92    # "$i$a$-Layout-ColumnKt$Column$1\\41\\476\\35":I
    nop

    .line 478
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 455
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 479
    nop

    .line 449
    .end local v85    # "$i$f$ReusableComposeNode\\37\\453":I
    .end local v89    # "$changed\\37":I
    .end local v90    # "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 480
    nop

    .line 442
    .end local v8    # "materialized\\36":Landroidx/compose/ui/Modifier;
    .end local v81    # "$changed\\36":I
    .end local v82    # "$i$f$Layout\\36\\448":I
    .end local v93    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v94    # "compositeKeyHash\\36":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 481
    nop

    .line 80
    .end local v11    # "measurePolicy\\35":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "horizontalAlignment\\35":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v80    # "$changed\\35":I
    .end local v83    # "$i$f$Column\\35\\75":I
    .end local v84    # "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v86    # "modifier\\35":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v2}, Landroidx/compose/material/icons/filled/KeyboardArrowDownKt;->getKeyboardArrowDown(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v80

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v81, v2

    check-cast v81, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x4

    .local v2, "$this$dp\\43":I
    const/4 v4, 0x0

    .line 482
    .local v4, "$i$f$getDp\\43\\80":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v82

    .line 80
    .end local v2    # "$this$dp\\43":I
    .end local v4    # "$i$f$getDp\\43\\80":I
    const/16 v86, 0xe

    const/16 v87, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    invoke-static/range {v81 .. v87}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v4, 0x14

    .local v4, "$this$dp\\44":I
    const/4 v5, 0x0

    .line 482
    .local v5, "$i$f$getDp\\44\\80":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 80
    .end local v4    # "$this$dp\\44":I
    .end local v5    # "$i$f$getDp\\44\\80":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v82

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v83

    const/16 v86, 0x1b0

    const/16 v87, 0x0

    const-string v81, "\u8bbe\u5907"

    move-object/from16 v85, v10

    .end local v10    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v85, "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-static/range {v80 .. v87}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 73
    invoke-static/range {v85 .. v85}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 81
    nop

    .line 440
    .end local v12    # "$changed\\33":I
    .end local v32    # "$i$a$-Row-HomeScreenKt$TopBar$1$1$2\\33\\440\\19":I
    .end local v77    # "$this$TopBar_u24lambda_u2422_u24lambda_u2417_u24lambda_u2416\\33":Landroidx/compose/foundation/layout/RowScope;
    .end local v85    # "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 417
    .end local v73    # "$changed\\32":I
    .end local v74    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .end local v76    # "$i$a$-Layout-RowKt$Row$1\\32\\417\\26":I
    nop

    .line 483
    invoke-interface/range {v75 .. v75}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 396
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 484
    nop

    .line 390
    .end local v68    # "$i$f$ReusableComposeNode\\28\\394":I
    .end local v71    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .end local v72    # "$changed\\28":I
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 485
    nop

    .line 427
    .end local v20    # "$changed\\27":I
    .end local v64    # "$i$f$Layout\\27\\433":I
    .end local v66    # "compositeKeyHash\\27":I
    .end local v78    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v88    # "materialized\\27":Landroidx/compose/ui/Modifier;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 486
    nop

    .line 71
    .end local v13    # "measurePolicy\\26":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v62    # "$changed\\26":I
    .end local v65    # "verticalAlignment\\26":Landroidx/compose/ui/Alignment$Vertical;
    .end local v67    # "horizontalArrangement\\26":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v70    # "modifier\\26":Landroidx/compose/ui/Modifier;
    .end local v79    # "$i$f$Row\\26\\71":I
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 81
    nop

    .line 418
    .end local v55    # "$i$a$-Box-HomeScreenKt$TopBar$1$1\\19\\418\\11":I
    .end local v56    # "$this$TopBar_u24lambda_u2422_u24lambda_u2417\\19":Landroidx/compose/foundation/layout/BoxScope;
    .end local v69    # "$changed\\19":I
    .end local v75    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 417
    .end local v52    # "$changed\\18":I
    .end local v60    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v61    # "$i$a$-Layout-BoxKt$Box$1\\18\\417\\12":I
    nop

    .line 483
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 396
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 484
    nop

    .line 390
    .end local v43    # "$i$f$ReusableComposeNode\\14\\394":I
    .end local v50    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .end local v51    # "$changed\\14":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 485
    nop

    .line 383
    .end local v38    # "$changed\\13":I
    .end local v39    # "$i$f$Layout\\13\\389":I
    .end local v41    # "compositeKeyHash\\13":I
    .end local v57    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v59    # "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 487
    const v2, 0x4c5de2

    .end local v36    # "$changed\\12":I
    .end local v37    # "$i$f$Box\\12\\71":I
    .end local v40    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .end local v42    # "propagateMinConstraints\\12":Z
    .end local v44    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v58    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v24, 0xe

    const/4 v5, 0x4

    if-eq v2, v5, :cond_1e

    and-int/lit8 v2, v24, 0x8

    if-eqz v2, :cond_1d

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1d

    goto :goto_14

    :cond_1d
    move/from16 v5, v22

    goto :goto_15

    :cond_1e
    :goto_14
    move/from16 v5, p1

    .line 82
    :goto_15
    move-object v2, v6

    .local v2, "$this$cache\\45":Landroidx/compose/runtime/Composer;
    .local v5, "invalid\\45":Z
    const/4 v4, 0x0

    .line 488
    .local v4, "$i$f$cache\\45\\82":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\45":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 489
    .local v9, "$i$a$-let-ComposerKt$cache$1\\46\\488\\45":I
    if-nez v5, :cond_20

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v8, v10, :cond_1f

    goto :goto_16

    .line 493
    :cond_1f
    move-object v11, v8

    goto :goto_17

    .line 490
    :cond_20
    :goto_16
    const/4 v10, 0x0

    .line 82
    .local v10, "$i$a$-cache-HomeScreenKt$TopBar$1$2\\47\\490\\11":I
    new-instance v11, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v11, v0}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 490
    .end local v10    # "$i$a$-cache-HomeScreenKt$TopBar$1$2\\47\\490\\11":I
    nop

    .line 491
    .local v11, "value\\46":Ljava/lang/Object;
    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 492
    nop

    .line 489
    .end local v11    # "value\\46":Ljava/lang/Object;
    :goto_17
    nop

    .line 488
    .end local v8    # "it\\45":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\46\\488\\45":I
    nop

    .line 82
    .end local v2    # "$this$cache\\45":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\45\\82":I
    .end local v5    # "invalid\\45":Z
    move-object/from16 v36, v11

    check-cast v36, Lkotlin/jvm/functions/Function0;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const-string v4, "open_store"

    invoke-static {v2, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->getLambda$-1675483824$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v41

    const v43, 0x30030

    const/16 v44, 0x1c

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    move-object/from16 v42, v6

    .end local v6    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v44}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    const v2, 0x4c5de2

    .end local v42    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v24, 0xe

    const/4 v5, 0x4

    if-eq v2, v5, :cond_22

    and-int/lit8 v2, v24, 0x8

    if-eqz v2, :cond_21

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_21

    goto :goto_18

    :cond_21
    move/from16 v8, v22

    goto :goto_19

    :cond_22
    :goto_18
    move/from16 v8, p1

    .line 83
    :goto_19
    move-object v2, v6

    .local v2, "$this$cache\\48":Landroidx/compose/runtime/Composer;
    .local v8, "invalid\\48":Z
    const/4 v4, 0x0

    .line 494
    .local v4, "$i$f$cache\\48\\83":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\48":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 495
    .local v7, "$i$a$-let-ComposerKt$cache$1\\49\\494\\48":I
    if-nez v8, :cond_24

    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v5, v9, :cond_23

    goto :goto_1a

    .line 499
    :cond_23
    move-object v10, v5

    goto :goto_1b

    .line 496
    :cond_24
    :goto_1a
    const/4 v9, 0x0

    .line 83
    .local v9, "$i$a$-cache-HomeScreenKt$TopBar$1$3\\50\\496\\11":I
    new-instance v10, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v10, v0}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 496
    .end local v9    # "$i$a$-cache-HomeScreenKt$TopBar$1$3\\50\\496\\11":I
    nop

    .line 497
    .local v10, "value\\49":Ljava/lang/Object;
    invoke-interface {v2, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 498
    nop

    .line 495
    .end local v10    # "value\\49":Ljava/lang/Object;
    :goto_1b
    nop

    .line 494
    .end local v5    # "it\\48":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\49\\494\\48":I
    nop

    .line 83
    .end local v2    # "$this$cache\\48":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\48\\83":I
    .end local v8    # "invalid\\48":Z
    move-object/from16 v36, v10

    check-cast v36, Lkotlin/jvm/functions/Function0;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const-string v4, "open_settings"

    invoke-static {v2, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->getLambda$552045127$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v41

    const v43, 0x30030

    const/16 v44, 0x1c

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    move-object/from16 v42, v6

    .end local v6    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v42    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v44}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 70
    .end local v42    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 84
    .end local v47    # "device\\11":Lorg/lighttouch/android/DeviceSummary;
    nop

    .line 382
    .end local v6    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-Row-HomeScreenKt$TopBar$1\\11\\382\\0":I
    .end local v31    # "$changed\\11":I
    .end local v35    # "$this$TopBar_u24lambda_u2422\\11":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 381
    .end local v28    # "$changed\\10":I
    .end local v45    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v46    # "$i$a$-Layout-RowKt$Row$1\\10\\381\\4":I
    nop

    .line 500
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 360
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 501
    nop

    .line 354
    .end local v21    # "$i$f$ReusableComposeNode\\6\\358":I
    .end local v33    # "$changed\\6":I
    .end local v34    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 502
    nop

    .line 347
    .end local v16    # "$changed\\5":I
    .end local v17    # "$i$f$Layout\\5\\353":I
    .end local v19    # "compositeKeyHash\\5":I
    .end local v48    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v63    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 503
    nop

    .end local v14    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v15    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v26    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v30    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .end local v49    # "$changed\\4":I
    .end local v54    # "$i$f$Row\\4\\69":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_25

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_25
    :goto_1c
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_26

    new-instance v4, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v4, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/GuestHost;I)V

    invoke-interface {v2, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 85
    :cond_26
    return-void
.end method

.method private static final TopBar$lambda$22$lambda$17$lambda$14$lambda$13(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 71
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->openDevices()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TopBar$lambda$22$lambda$19$lambda$18(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 82
    sget-object v0, Lorg/lighttouch/android/Screen;->STORE:Lorg/lighttouch/android/Screen;

    invoke-interface {p0, v0}, Lorg/lighttouch/android/GuestHost;->navigate(Lorg/lighttouch/android/Screen;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TopBar$lambda$22$lambda$21$lambda$20(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 83
    sget-object v0, Lorg/lighttouch/android/Screen;->SETTINGS:Lorg/lighttouch/android/Screen;

    invoke-interface {p0, v0}, Lorg/lighttouch/android/GuestHost;->navigate(Lorg/lighttouch/android/Screen;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TopBar$lambda$23(Lorg/lighttouch/android/GuestHost;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/HomeScreenKt;->TopBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$Busy(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "label"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/HomeScreenKt;->Busy(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$Dock(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "onStop"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HomeScreenKt;->Dock(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$HomeScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$confirmStop$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/HomeScreenKt;->HomeScreen$lambda$2(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final luminance-8_81llA(J)F
    .locals 3
    .param p0, "$this$luminance_u2d8_81llA"    # J

    .line 191
    const v0, 0x3e59b3d0    # 0.2126f

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getRed-impl(J)F

    move-result v1

    mul-float/2addr v1, v0

    const v0, 0x3f371759    # 0.7152f

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getGreen-impl(J)F

    move-result v2

    mul-float/2addr v2, v0

    add-float/2addr v1, v2

    const v0, 0x3d93dd98    # 0.0722f

    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getBlue-impl(J)F

    move-result v2

    mul-float/2addr v2, v0

    add-float/2addr v1, v2

    return v1
.end method

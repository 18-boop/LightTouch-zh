.class final Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;
.super Ljava/lang/Object;
.source "DeviceDetails.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeviceDetails.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeviceDetails.kt\norg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,189:1\n1#2:190\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $device:Lorg/lighttouch/android/DeviceSummary;

.field final synthetic $s:Lorg/lighttouch/android/BoardSpecs;


# direct methods
.method constructor <init>(Lorg/lighttouch/android/BoardSpecs;Lorg/lighttouch/android/DeviceSummary;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$s:Lorg/lighttouch/android/BoardSpecs;

    iput-object p2, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 137
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 17
    .param p1, "$this$Section"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$Section"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C137@8578L20,138@8627L18,139@8674L18,140@8721L24,141@8774L24,142@8827L237:DeviceDetails.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 143
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_3

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.DeviceDetails.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DeviceDetails.kt:137)"

    const v6, -0x17905d59

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 138
    :cond_2
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$s:Lorg/lighttouch/android/BoardSpecs;

    invoke-virtual {v3}, Lorg/lighttouch/android/BoardSpecs;->getChip()Ljava/lang/String;

    move-result-object v3

    const-string v5, "\u82af\u7247"

    const/4 v6, 0x6

    invoke-static {v5, v3, v1, v6}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 139
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$s:Lorg/lighttouch/android/BoardSpecs;

    invoke-virtual {v3}, Lorg/lighttouch/android/BoardSpecs;->getCpu()Ljava/lang/String;

    move-result-object v3

    const-string v5, "CPU"

    invoke-static {v5, v3, v1, v6}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 140
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$s:Lorg/lighttouch/android/BoardSpecs;

    invoke-virtual {v3}, Lorg/lighttouch/android/BoardSpecs;->getGpu()Ljava/lang/String;

    move-result-object v3

    const-string v5, "GPU"

    invoke-static {v5, v3, v1, v6}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 141
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$s:Lorg/lighttouch/android/BoardSpecs;

    invoke-virtual {v3}, Lorg/lighttouch/android/BoardSpecs;->getMemory()Ljava/lang/String;

    move-result-object v3

    const-string v5, "\u5185\u5b58"

    invoke-static {v5, v3, v1, v6}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 142
    iget-object v3, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$s:Lorg/lighttouch/android/BoardSpecs;

    invoke-virtual {v3}, Lorg/lighttouch/android/BoardSpecs;->getScreen()Ljava/lang/String;

    move-result-object v3

    const-string v5, "\u5c4f\u5e55"

    invoke-static {v5, v3, v1, v6}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 143
    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/String;

    iget-object v5, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    .line 190
    const-string v7, "accelerometer"

    move-object v8, v7

    .local v8, "it\\1":Ljava/lang/String;
    const/4 v9, 0x0

    .line 143
    .local v9, "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$1\\1\\143\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/DeviceSummary;->getAccelerometer()Z

    move-result v5

    .end local v8    # "it\\1":Ljava/lang/String;
    .end local v9    # "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$1\\1\\143\\0":I
    const/4 v8, 0x0

    if-eqz v5, :cond_3

    goto :goto_1

    :cond_3
    move-object v7, v8

    :goto_1
    const/4 v5, 0x0

    aput-object v7, v3, v5

    iget-object v7, v0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1;->$device:Lorg/lighttouch/android/DeviceSummary;

    .line 190
    const-string v9, "gyroscope"

    move-object v10, v9

    .local v10, "it\\2":Ljava/lang/String;
    const/4 v11, 0x0

    .line 143
    .local v11, "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$2\\2\\143\\0":I
    invoke-virtual {v7}, Lorg/lighttouch/android/DeviceSummary;->getGyroscope()Z

    move-result v7

    .end local v10    # "it\\2":Ljava/lang/String;
    .end local v11    # "$i$a$-takeIf-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$2\\2\\143\\0":I
    if-eqz v7, :cond_4

    move-object v8, v9

    :cond_4
    const/4 v7, 0x1

    aput-object v8, v3, v7

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    move-object v8, v3

    check-cast v8, Ljava/lang/Iterable;

    .line 144
    const-string v3, " \u548c "

    move-object v9, v3

    check-cast v9, Ljava/lang/CharSequence;

    const/16 v15, 0x3e

    const/16 v16, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v8 .. v16}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    move-object v8, v3

    check-cast v8, Ljava/lang/CharSequence;

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-lez v8, :cond_5

    move v8, v7

    goto :goto_2

    :cond_5
    move v8, v5

    :goto_2
    if-eqz v8, :cond_6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/String;->charAt(I)C

    move-result v9

    .line 190
    nop

    .local v9, "it\\3":C
    const/4 v10, 0x0

    .line 144
    .local v10, "$i$a$-replaceFirstCharWithCharSequence-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$3\\3\\144\\0":I
    invoke-static {v9}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v11

    const-string v12, "null cannot be cast to non-null type java.lang.String"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v11, v12}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "toUpperCase(...)"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v11, Ljava/lang/CharSequence;

    .end local v9    # "it\\3":C
    .end local v10    # "$i$a$-replaceFirstCharWithCharSequence-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$3\\3\\144\\0":I
    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v3, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    const-string v9, "substring(...)"

    invoke-static {v3, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :cond_6
    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-nez v8, :cond_7

    move v5, v7

    :cond_7
    if-eqz v5, :cond_8

    .line 190
    const/4 v3, 0x0

    .line 144
    .local v3, "$i$a$-ifEmpty-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$4\\4\\144\\0":I
    nop

    .end local v3    # "$i$a$-ifEmpty-DeviceDetailsKt$DeviceDetails$4$1$2$1$2$1$4\\4\\144\\0":I
    const-string v3, "None"

    :cond_8
    check-cast v3, Ljava/lang/String;

    .line 143
    const-string v5, "\u8fd0\u52a8\u4f20\u611f\u5668"

    invoke-static {v5, v3, v1, v6}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 145
    :cond_9
    :goto_3
    return-void
.end method

.class public final Lorg/lighttouch/android/GuestTools;
.super Ljava/lang/Object;
.source "GuestTools.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/GuestTools$Pack;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nGuestTools.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GuestTools.kt\norg/lighttouch/android/GuestTools\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 6 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 7 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,109:1\n3829#2:110\n4344#2,2:111\n3829#2:168\n4344#2,2:169\n1617#3,9:113\n1869#3:122\n1870#3:125\n1626#3:126\n1193#3,2:127\n1267#3,4:129\n1563#3:144\n1634#3,3:145\n1761#3,3:153\n295#3:156\n1761#3,3:157\n296#3:160\n295#3,2:161\n295#3:163\n1761#3,3:164\n296#3:167\n1761#3,3:171\n1#4:123\n1#4:124\n490#5,7:133\n126#6:140\n153#6,3:141\n648#7,5:148\n*S KotlinDebug\n*F\n+ 1 GuestTools.kt\norg/lighttouch/android/GuestTools\n*L\n21#1:110\n21#1:111,2\n94#1:168\n94#1:169,2\n21#1:113,9\n21#1:122\n21#1:125\n21#1:126\n40#1:127,2\n40#1:129,4\n48#1:144\n48#1:145,3\n55#1:153,3\n60#1:156\n60#1:157,3\n60#1:160\n70#1:161,2\n82#1:163\n82#1:164,3\n82#1:167\n95#1:171,3\n21#1:124\n44#1:133,7\n44#1:140\n44#1:141,3\n53#1:148,5\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0007\u0008\u00c1\u0002\u0018\u00002\u00020\u0001:\u0001!B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0016\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0008\u001a\u00020\tH\u0002J\u0018\u0010\n\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u001a\u0010\u000f\u001a\u0010\u0012\u000c\u0012\n \u0010*\u0004\u0018\u00010\u000c0\u000c0\u0005*\u00020\u0011H\u0002J \u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cH\u0002J \u0010\u0018\u001a\u0004\u0018\u00010\u00192\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cJ\'\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001c\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\u000c2\u0006\u0010\u0017\u001a\u00020\u000cH\u0002\u00a2\u0006\u0002\u0010\u001dJ\u0018\u0010\u001e\u001a\u0004\u0018\u00010\u00192\u0006\u0010\u0008\u001a\u00020\t2\u0006\u0010\u001f\u001a\u00020\u000cJ\u000e\u0010 \u001a\u00020\u00192\u0006\u0010\u0008\u001a\u00020\tR\u0016\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\""
    }
    d2 = {
        "Lorg/lighttouch/android/GuestTools;",
        "",
        "<init>",
        "()V",
        "cache",
        "",
        "Lorg/lighttouch/android/GuestTools$Pack;",
        "packs",
        "context",
        "Landroid/content/Context;",
        "read",
        "asset",
        "",
        "blob",
        "",
        "strings",
        "kotlin.jvm.PlatformType",
        "Lorg/json/JSONArray;",
        "covers",
        "",
        "family",
        "Lorg/json/JSONObject;",
        "board",
        "build",
        "forDevice",
        "Ljava/io/File;",
        "serial",
        "",
        "pack",
        "(Lorg/lighttouch/android/GuestTools$Pack;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Integer;",
        "newerFor",
        "recordId",
        "firmwareTools",
        "Pack",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final INSTANCE:Lorg/lighttouch/android/GuestTools;

.field private static volatile cache:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lorg/lighttouch/android/GuestTools$Pack;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lorg/lighttouch/android/GuestTools;

    invoke-direct {v0}, Lorg/lighttouch/android/GuestTools;-><init>()V

    sput-object v0, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/GuestTools;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final covers(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 12
    .param p1, "family"    # Lorg/json/JSONObject;
    .param p2, "board"    # Ljava/lang/String;
    .param p3, "build"    # Ljava/lang/String;

    .line 51
    const-string v0, "stub"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 52
    :cond_0
    const-string v0, "requires"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    .line 53
    .local v0, "requires":Lorg/json/JSONObject;
    move-object v2, p3

    .local v2, "$this$takeWhile\\1":Ljava/lang/String;
    const/4 v3, 0x0

    .line 148
    .local v3, "$i$f$takeWhile\\1\\53":I
    const/4 v4, 0x0

    .local v4, "index\\1":I
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5

    :goto_0
    if-ge v4, v5, :cond_2

    .line 149
    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    .local v6, "it\\2":C
    const/4 v7, 0x0

    .line 53
    .local v7, "$i$a$-takeWhile-GuestTools$covers$major$1\\2\\149\\0":I
    invoke-static {v6}, Ljava/lang/Character;->isDigit(C)Z

    move-result v8

    .line 149
    .end local v6    # "it\\2":C
    .end local v7    # "$i$a$-takeWhile-GuestTools$covers$major$1\\2\\149\\0":I
    if-nez v8, :cond_1

    .line 150
    invoke-virtual {v2, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    const-string v6, "substring(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v2, v5

    goto :goto_1

    .line 148
    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 152
    .end local v4    # "index\\1":I
    :cond_2
    nop

    .line 53
    .end local v2    # "$this$takeWhile\\1":Ljava/lang/String;
    .end local v3    # "$i$f$takeWhile\\1\\53":I
    :goto_1
    nop

    .line 54
    .local v2, "major":Ljava/lang/String;
    const-string v3, "boards"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const-string v4, "getJSONArray(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v3}, Lorg/lighttouch/android/GuestTools;->strings(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    .line 55
    const-string v3, "builds"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v3}, Lorg/lighttouch/android/GuestTools;->strings(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$any\\3":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 153
    .local v4, "$i$f$any\\3\\55":I
    instance-of v5, v3, Ljava/util/Collection;

    const/4 v6, 0x1

    if-eqz v5, :cond_3

    move-object v5, v3

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    move v3, v1

    goto :goto_4

    .line 154
    :cond_3
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_7

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\3":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/lang/String;

    .local v8, "it\\4":Ljava/lang/String;
    const/4 v9, 0x0

    .line 55
    .local v9, "$i$a$-any-GuestTools$covers$1\\4\\154\\0":I
    invoke-static {v8, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_6

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "*"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_5

    goto :goto_2

    :cond_5
    move v8, v1

    goto :goto_3

    :cond_6
    :goto_2
    move v8, v6

    .line 154
    .end local v8    # "it\\4":Ljava/lang/String;
    .end local v9    # "$i$a$-any-GuestTools$covers$1\\4\\154\\0":I
    :goto_3
    if-eqz v8, :cond_4

    move v3, v6

    goto :goto_4

    .line 155
    .end local v7    # "element\\3":Ljava/lang/Object;
    :cond_7
    move v3, v1

    .line 55
    .end local v3    # "$this$any\\3":Ljava/lang/Iterable;
    .end local v4    # "$i$f$any\\3\\55":I
    :goto_4
    if-eqz v3, :cond_8

    move v1, v6

    goto :goto_5

    :cond_8
    nop

    .line 54
    :goto_5
    return v1
.end method

.method private final packs(Landroid/content/Context;)Ljava/util/List;
    .locals 20
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/GuestTools$Pack;",
            ">;"
        }
    .end annotation

    .line 20
    sget-object v0, Lorg/lighttouch/android/GuestTools;->cache:Ljava/util/List;

    if-nez v0, :cond_6

    monitor-enter p0

    const/4 v1, 0x0

    .line 21
    .local v1, "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    :try_start_0
    sget-object v0, Lorg/lighttouch/android/GuestTools;->cache:Ljava/util/List;

    if-nez v0, :cond_5

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v2, "guest-tools"

    invoke-virtual {v0, v2}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    new-array v0, v2, [Ljava/lang/String;

    .local v0, "$this$filter\\2":[Ljava/lang/Object;
    :cond_0
    const/4 v3, 0x0

    .line 110
    .local v3, "$i$f$filter\\2\\21":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\3":Ljava/util/Collection;
    move-object v5, v0

    .local v5, "$this$filterTo\\3":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 111
    .local v6, "$i$f$filterTo\\3\\110":I
    array-length v7, v5

    move v8, v2

    :goto_0
    const/4 v9, 0x0

    if-ge v8, v7, :cond_2

    aget-object v10, v5, v8

    .local v10, "element\\3":Ljava/lang/Object;
    move-object v11, v10

    .local v11, "it\\4":Ljava/lang/String;
    const/4 v12, 0x0

    .line 21
    .local v12, "$i$a$-filter-GuestTools$packs$1$1\\4\\111\\1":I
    invoke-static {v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v13, ".itpack"

    const/4 v14, 0x2

    invoke-static {v11, v13, v2, v14, v9}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v9

    .line 111
    .end local v11    # "it\\4":Ljava/lang/String;
    .end local v12    # "$i$a$-filter-GuestTools$packs$1$1\\4\\111\\1":I
    if-eqz v9, :cond_1

    invoke-interface {v4, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v10    # "element\\3":Ljava/lang/Object;
    :cond_1
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 112
    :cond_2
    nop

    .end local v4    # "destination\\3":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\3":[Ljava/lang/Object;
    .end local v6    # "$i$f$filterTo\\3\\110":I
    move-object v2, v4

    check-cast v2, Ljava/util/List;

    .line 110
    nop

    .end local v0    # "$this$filter\\2":[Ljava/lang/Object;
    .end local v3    # "$i$f$filter\\2\\21":I
    check-cast v2, Ljava/lang/Iterable;

    .line 21
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    move-object v2, v0

    .local v2, "$this$mapNotNull\\5":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 113
    .local v3, "$i$f$mapNotNull\\5\\21":I
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination\\6":Ljava/util/Collection;
    move-object v4, v2

    .local v4, "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    move-object v5, v0

    .end local v0    # "destination\\6":Ljava/util/Collection;
    .local v5, "destination\\6":Ljava/util/Collection;
    const/4 v6, 0x0

    .line 121
    .local v6, "$i$f$mapNotNullTo\\6\\113":I
    move-object v7, v4

    .local v7, "$this$forEach\\7":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 122
    .local v8, "$i$f$forEach\\7\\121":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    .local v11, "element\\7":Ljava/lang/Object;
    move-object v12, v11

    .local v12, "element\\8":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 121
    .local v13, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\122\\6":I
    move-object v0, v12

    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    move-object v14, v0

    .local v14, "name\\9":Ljava/lang/String;
    const/4 v15, 0x0

    .line 22
    .local v15, "$i$a$-mapNotNull-GuestTools$packs$1$2\\9\\121\\1":I
    :try_start_1
    sget-object v0, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_5
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move/from16 v16, v1

    .end local v1    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .local v16, "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    :try_start_3
    const-string v1, "guest-tools/"

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v9
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    move-object/from16 v17, v2

    .end local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .local v17, "$this$mapNotNull\\5":Ljava/lang/Iterable;
    :try_start_4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    move/from16 v18, v3

    .end local v3    # "$i$f$mapNotNull\\5\\21":I
    .local v18, "$i$f$mapNotNull\\5\\21":I
    :try_start_5
    const-string v3, "guest-tools/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v2

    check-cast v2, Ljava/io/Closeable;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    move-object v3, v2

    check-cast v3, Ljava/io/InputStream;

    .line 123
    .local v3, "it\\10":Ljava/io/InputStream;
    const/4 v9, 0x0

    .line 22
    .local v9, "$i$a$-use-GuestTools$packs$1$2$1\\10\\22\\10":I
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v19, v3

    .end local v3    # "it\\10":Ljava/io/InputStream;
    .local v19, "it\\10":Ljava/io/InputStream;
    invoke-static/range {v19 .. v19}, Lkotlin/io/ByteStreamsKt;->readBytes(Ljava/io/InputStream;)[B

    move-result-object v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .end local v9    # "$i$a$-use-GuestTools$packs$1$2$1\\10\\22\\10":I
    .end local v19    # "it\\10":Ljava/io/InputStream;
    const/4 v9, 0x0

    :try_start_7
    invoke-static {v2, v9}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    invoke-direct {v0, v1, v3}, Lorg/lighttouch/android/GuestTools;->read(Ljava/lang/String;[B)Lorg/lighttouch/android/GuestTools$Pack;

    move-result-object v0
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    goto :goto_3

    :catch_0
    move-exception v0

    goto :goto_2

    :catchall_0
    move-exception v0

    const/4 v9, 0x0

    move-object v1, v0

    .end local v4    # "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    .end local v5    # "destination\\6":Ljava/util/Collection;
    .end local v6    # "$i$f$mapNotNullTo\\6\\113":I
    .end local v7    # "$this$forEach\\7":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\7\\121":I
    .end local v11    # "element\\7":Ljava/lang/Object;
    .end local v12    # "element\\8":Ljava/lang/Object;
    .end local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\122\\6":I
    .end local v14    # "name\\9":Ljava/lang/String;
    .end local v15    # "$i$a$-mapNotNull-GuestTools$packs$1$2\\9\\121\\1":I
    .end local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .end local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    .end local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .end local p1    # "context":Landroid/content/Context;
    :try_start_8
    throw v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    .restart local v4    # "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    .restart local v5    # "destination\\6":Ljava/util/Collection;
    .restart local v6    # "$i$f$mapNotNullTo\\6\\113":I
    .restart local v7    # "$this$forEach\\7":Ljava/lang/Iterable;
    .restart local v8    # "$i$f$forEach\\7\\121":I
    .restart local v11    # "element\\7":Ljava/lang/Object;
    .restart local v12    # "element\\8":Ljava/lang/Object;
    .restart local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\122\\6":I
    .restart local v14    # "name\\9":Ljava/lang/String;
    .restart local v15    # "$i$a$-mapNotNull-GuestTools$packs$1$2\\9\\121\\1":I
    .restart local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v18    # "$i$f$mapNotNull\\5\\21":I
    .restart local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .restart local p1    # "context":Landroid/content/Context;
    :catchall_1
    move-exception v0

    :try_start_9
    invoke-static {v2, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v4    # "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    .end local v5    # "destination\\6":Ljava/util/Collection;
    .end local v6    # "$i$f$mapNotNullTo\\6\\113":I
    .end local v7    # "$this$forEach\\7":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\7\\121":I
    .end local v11    # "element\\7":Ljava/lang/Object;
    .end local v12    # "element\\8":Ljava/lang/Object;
    .end local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\122\\6":I
    .end local v14    # "name\\9":Ljava/lang/String;
    .end local v15    # "$i$a$-mapNotNull-GuestTools$packs$1$2\\9\\121\\1":I
    .end local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .end local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    .end local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .end local p1    # "context":Landroid/content/Context;
    throw v0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    .restart local v4    # "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    .restart local v5    # "destination\\6":Ljava/util/Collection;
    .restart local v6    # "$i$f$mapNotNullTo\\6\\113":I
    .restart local v7    # "$this$forEach\\7":Ljava/lang/Iterable;
    .restart local v8    # "$i$f$forEach\\7\\121":I
    .restart local v11    # "element\\7":Ljava/lang/Object;
    .restart local v12    # "element\\8":Ljava/lang/Object;
    .restart local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\122\\6":I
    .restart local v14    # "name\\9":Ljava/lang/String;
    .restart local v15    # "$i$a$-mapNotNull-GuestTools$packs$1$2\\9\\121\\1":I
    .restart local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v18    # "$i$f$mapNotNull\\5\\21":I
    .restart local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .restart local p1    # "context":Landroid/content/Context;
    :catch_1
    move-exception v0

    const/4 v9, 0x0

    goto :goto_2

    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    .local v3, "$i$f$mapNotNull\\5\\21":I
    :catch_2
    move-exception v0

    move/from16 v18, v3

    const/4 v9, 0x0

    .end local v3    # "$i$f$mapNotNull\\5\\21":I
    .restart local v18    # "$i$f$mapNotNull\\5\\21":I
    goto :goto_2

    .end local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    .restart local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v3    # "$i$f$mapNotNull\\5\\21":I
    :catch_3
    move-exception v0

    move-object/from16 v17, v2

    move/from16 v18, v3

    const/4 v9, 0x0

    .end local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\5\\21":I
    .restart local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v18    # "$i$f$mapNotNull\\5\\21":I
    goto :goto_2

    .end local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .end local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    .restart local v1    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v3    # "$i$f$mapNotNull\\5\\21":I
    :catch_4
    move-exception v0

    move/from16 v16, v1

    move-object/from16 v17, v2

    move/from16 v18, v3

    const/4 v9, 0x0

    goto :goto_2

    :catch_5
    move-exception v0

    move/from16 v16, v1

    move-object/from16 v17, v2

    move/from16 v18, v3

    .end local v1    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .end local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\5\\21":I
    .restart local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v18    # "$i$f$mapNotNull\\5\\21":I
    :goto_2
    move-object v0, v9

    .line 121
    .end local v14    # "name\\9":Ljava/lang/String;
    .end local v15    # "$i$a$-mapNotNull-GuestTools$packs$1$2\\9\\121\\1":I
    :goto_3
    if-eqz v0, :cond_3

    .line 124
    .local v0, "it\\8":Ljava/lang/Object;
    const/4 v1, 0x0

    .line 121
    .local v1, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\11\\124\\8":I
    :try_start_a
    invoke-interface {v5, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 122
    .end local v0    # "it\\8":Ljava/lang/Object;
    .end local v1    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\11\\124\\8":I
    .end local v12    # "element\\8":Ljava/lang/Object;
    .end local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\8\\122\\6":I
    :cond_3
    move/from16 v1, v16

    move-object/from16 v2, v17

    move/from16 v3, v18

    .end local v11    # "element\\7":Ljava/lang/Object;
    goto/16 :goto_1

    .line 125
    .end local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .end local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    .local v1, "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v3    # "$i$f$mapNotNull\\5\\21":I
    :cond_4
    move/from16 v16, v1

    move-object/from16 v17, v2

    move/from16 v18, v3

    .line 126
    .end local v1    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .end local v2    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\5\\21":I
    .end local v7    # "$this$forEach\\7":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\7\\121":I
    .restart local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .restart local v18    # "$i$f$mapNotNull\\5\\21":I
    nop

    .end local v4    # "$this$mapNotNullTo\\6":Ljava/lang/Iterable;
    .end local v5    # "destination\\6":Ljava/util/Collection;
    .end local v6    # "$i$f$mapNotNullTo\\6\\113":I
    move-object v0, v5

    check-cast v0, Ljava/util/List;

    .line 113
    nop

    .line 23
    .end local v17    # "$this$mapNotNull\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$mapNotNull\\5\\21":I
    move-object v1, v0

    .line 123
    .local v1, "it\\12":Ljava/util/List;
    const/4 v2, 0x0

    .line 23
    .local v2, "$i$a$-also-GuestTools$packs$1$3\\12\\23\\1":I
    sput-object v1, Lorg/lighttouch/android/GuestTools;->cache:Ljava/util/List;
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    .end local v1    # "it\\12":Ljava/util/List;
    .end local v2    # "$i$a$-also-GuestTools$packs$1$3\\12\\23\\1":I
    goto :goto_4

    .line 21
    .end local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .local v1, "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    :cond_5
    move/from16 v16, v1

    .line 23
    .end local v1    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    .restart local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    :goto_4
    nop

    .line 20
    .end local v16    # "$i$a$-synchronized-GuestTools$packs$1\\1\\20\\0":I
    monitor-exit p0

    goto :goto_5

    :catchall_2
    move-exception v0

    monitor-exit p0

    throw v0

    .line 24
    :cond_6
    :goto_5
    return-object v0
.end method

.method private final read(Ljava/lang/String;[B)Lorg/lighttouch/android/GuestTools$Pack;
    .locals 23
    .param p1, "asset"    # Ljava/lang/String;
    .param p2, "blob"    # [B

    .line 28
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    array-length v2, v1

    const/16 v3, 0x8

    const/4 v5, 0x0

    const/16 v6, 0xc

    if-le v2, v6, :cond_0

    new-instance v2, Ljava/lang/String;

    sget-object v7, Lkotlin/text/Charsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v5, v3, v7}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const-string v7, "ITPACK01"

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    move v2, v5

    :goto_0
    if-eqz v2, :cond_e

    .line 29
    aget-byte v2, v1, v3

    and-int/lit16 v2, v2, 0xff

    const/16 v7, 0x9

    aget-byte v7, v1, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v3, v7, 0x8

    or-int/2addr v2, v3

    const/16 v3, 0xa

    aget-byte v7, v1, v3

    and-int/lit16 v7, v7, 0xff

    const/16 v8, 0x10

    shl-int/2addr v7, v8

    or-int/2addr v2, v7

    const/16 v7, 0xb

    aget-byte v7, v1, v7

    and-int/lit16 v7, v7, 0xff

    shl-int/lit8 v7, v7, 0x18

    or-int/2addr v2, v7

    .line 30
    .local v2, "length":I
    new-instance v7, Lorg/json/JSONObject;

    new-instance v9, Ljava/lang/String;

    sget-object v10, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v9, v1, v6, v2, v10}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    invoke-direct {v7, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v9, "entries"

    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v7

    .line 31
    .local v7, "entries":Lorg/json/JSONArray;
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v9

    invoke-static {v5, v9}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    const-wide/16 v10, 0x0

    :goto_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    const-string v13, "size"

    if-eqz v12, :cond_1

    move-object v12, v9

    check-cast v12, Lkotlin/collections/IntIterator;

    invoke-virtual {v12}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v12

    .line 123
    nop

    .local v12, "it\\2":I
    const/4 v14, 0x0

    .line 31
    .local v14, "$i$a$-sumOfLong-GuestTools$read$total$1\\2\\31\\0":I
    invoke-virtual {v7, v12}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v15

    invoke-virtual {v15, v13}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v12

    .end local v12    # "it\\2":I
    .end local v14    # "$i$a$-sumOfLong-GuestTools$read$total$1\\2\\31\\0":I
    add-long/2addr v10, v12

    goto :goto_1

    .line 32
    .local v10, "total":J
    :cond_1
    const-wide/16 v14, 0x1

    cmp-long v9, v14, v10

    if-gtz v9, :cond_2

    const-wide/32 v14, 0x4000001

    cmp-long v9, v10, v14

    if-gez v9, :cond_2

    const/4 v9, 0x1

    goto :goto_2

    :cond_2
    move v9, v5

    :goto_2
    if-eqz v9, :cond_d

    .line 33
    long-to-int v9, v10

    new-array v9, v9, [B

    .line 34
    .local v9, "payload":[B
    new-instance v12, Ljava/util/zip/Inflater;

    invoke-direct {v12}, Ljava/util/zip/Inflater;-><init>()V

    move-object v14, v12

    .line 123
    .local v14, "$this$read_u24lambda_u248\\4":Ljava/util/zip/Inflater;
    const/4 v15, 0x0

    .line 34
    .local v15, "$i$a$-apply-GuestTools$read$3\\4\\34\\0":I
    add-int/lit8 v4, v2, 0xc

    move/from16 v17, v6

    array-length v6, v1

    add-int/lit8 v6, v6, -0xc

    sub-int/2addr v6, v2

    invoke-virtual {v14, v1, v4, v6}, Ljava/util/zip/Inflater;->setInput([BII)V

    .end local v14    # "$this$read_u24lambda_u248\\4":Ljava/util/zip/Inflater;
    .end local v15    # "$i$a$-apply-GuestTools$read$3\\4\\34\\0":I
    .local v12, "$this$read_u24lambda_u2412\\5":Ljava/util/zip/Inflater;
    const/4 v4, 0x0

    .line 35
    .local v4, "$i$a$-run-GuestTools$read$4\\5\\34\\0":I
    const/4 v6, 0x0

    .line 36
    .local v6, "at\\5":I
    :goto_3
    array-length v14, v9

    const-string v15, " is truncated"

    if-ge v6, v14, :cond_6

    invoke-virtual {v12}, Ljava/util/zip/Inflater;->finished()Z

    move-result v14

    if-nez v14, :cond_6

    array-length v14, v9

    sub-int/2addr v14, v6

    invoke-virtual {v12, v9, v6, v14}, Ljava/util/zip/Inflater;->inflate([BII)I

    move-result v14

    .line 123
    move/from16 v17, v14

    .local v17, "it\\6":I
    const/16 v18, 0x0

    .line 36
    .local v18, "$i$a$-also-GuestTools$read$4$1\\6\\36\\5":I
    if-gtz v17, :cond_4

    invoke-virtual {v12}, Ljava/util/zip/Inflater;->needsInput()Z

    move-result v19

    if-nez v19, :cond_3

    goto :goto_4

    :cond_3
    move/from16 v19, v5

    goto :goto_5

    :cond_4
    :goto_4
    const/16 v19, 0x1

    :goto_5
    if-eqz v19, :cond_5

    .end local v17    # "it\\6":I
    .end local v18    # "$i$a$-also-GuestTools$read$4$1\\6\\36\\5":I
    sget-object v15, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    add-int/2addr v6, v14

    goto :goto_3

    .line 123
    .restart local v17    # "it\\6":I
    .restart local v18    # "$i$a$-also-GuestTools$read$4$1\\6\\36\\5":I
    :cond_5
    const/4 v3, 0x0

    .line 36
    .local v3, "$i$a$-require-GuestTools$read$4$1$1\\7\\36\\6":I
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .end local v3    # "$i$a$-require-GuestTools$read$4$1$1\\7\\36\\6":I
    new-instance v5, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v5, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 37
    .end local v17    # "it\\6":I
    .end local v18    # "$i$a$-also-GuestTools$read$4$1\\6\\36\\5":I
    :cond_6
    invoke-virtual {v12}, Ljava/util/zip/Inflater;->end()V

    array-length v14, v9

    if-ne v6, v14, :cond_7

    const/16 v16, 0x1

    goto :goto_6

    :cond_7
    move/from16 v16, v5

    :goto_6
    if-eqz v16, :cond_c

    .line 38
    nop

    .line 34
    .end local v4    # "$i$a$-run-GuestTools$read$4\\5\\34\\0":I
    .end local v6    # "at\\5":I
    .end local v12    # "$this$read_u24lambda_u2412\\5":Ljava/util/zip/Inflater;
    nop

    .line 39
    const/4 v4, 0x0

    .line 40
    .local v4, "offset":I
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v6

    invoke-static {v5, v6}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$associate\\9":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 127
    .local v12, "$i$f$associate\\9\\40":I
    invoke-static {v6, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-static {v3}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v3

    invoke-static {v3, v8}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v3

    .line 128
    .local v3, "capacity\\9":I
    new-instance v8, Ljava/util/LinkedHashMap;

    invoke-direct {v8, v3}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v8, Ljava/util/Map;

    .local v8, "destination\\10":Ljava/util/Map;
    move-object v14, v6

    .local v14, "$this$associateTo\\10":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 129
    .local v15, "$i$f$associateTo\\10\\128":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_7
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_8

    move-object/from16 v17, v16

    check-cast v17, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v17 .. v17}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v17

    .line 130
    .local v17, "element\\10":I
    move/from16 v18, v17

    .local v18, "i\\11":I
    const/16 v19, 0x0

    .line 41
    .local v19, "$i$a$-associate-GuestTools$read$files$1\\11\\130\\0":I
    move/from16 v5, v18

    .end local v18    # "i\\11":I
    .local v5, "i\\11":I
    invoke-virtual {v7, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    .local v1, "entry\\11":Lorg/json/JSONObject;
    invoke-virtual {v1, v13}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v18

    .line 42
    .local v18, "size\\11":I
    move/from16 v20, v2

    .end local v2    # "length":I
    .local v20, "length":I
    const-string v2, "name"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v21, v1

    .end local v1    # "entry\\11":Lorg/json/JSONObject;
    .local v21, "entry\\11":Lorg/json/JSONObject;
    add-int v1, v4, v18

    invoke-static {v9, v4, v1}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object v1

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    move-object v2, v1

    .line 123
    .local v2, "it\\12":Lkotlin/Pair;
    const/16 v22, 0x0

    .line 42
    .local v22, "$i$a$-also-GuestTools$read$files$1$1\\12\\42\\11":I
    add-int v4, v4, v18

    .line 130
    .end local v2    # "it\\12":Lkotlin/Pair;
    .end local v5    # "i\\11":I
    .end local v18    # "size\\11":I
    .end local v19    # "$i$a$-associate-GuestTools$read$files$1\\11\\130\\0":I
    .end local v21    # "entry\\11":Lorg/json/JSONObject;
    .end local v22    # "$i$a$-also-GuestTools$read$files$1$1\\12\\42\\11":I
    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v8, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, p2

    move/from16 v2, v20

    const/4 v5, 0x0

    goto :goto_7

    .line 132
    .end local v17    # "element\\10":I
    .end local v20    # "length":I
    .local v2, "length":I
    :cond_8
    move/from16 v20, v2

    .line 128
    .end local v2    # "length":I
    .end local v8    # "destination\\10":Ljava/util/Map;
    .end local v14    # "$this$associateTo\\10":Ljava/lang/Iterable;
    .end local v15    # "$i$f$associateTo\\10\\128":I
    .restart local v20    # "length":I
    nop

    .line 40
    .end local v3    # "capacity\\9":I
    .end local v6    # "$this$associate\\9":Ljava/lang/Iterable;
    .end local v12    # "$i$f$associate\\9\\40":I
    nop

    .line 44
    .local v8, "files":Ljava/util/Map;
    move-object v1, v8

    .local v1, "$this$filterKeys\\13":Ljava/util/Map;
    const/4 v2, 0x0

    .line 133
    .local v2, "$i$f$filterKeys\\13\\44":I
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 134
    .local v3, "result\\13":Ljava/util/LinkedHashMap;
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_a

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    .line 135
    .local v6, "entry\\13":Ljava/util/Map$Entry;
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .local v12, "it\\14":Ljava/lang/String;
    const/4 v13, 0x0

    .line 44
    .local v13, "$i$a$-filterKeys-GuestTools$read$families$1\\14\\135\\0":I
    invoke-static {v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/4 v14, 0x2

    const/4 v15, 0x0

    move-object/from16 v16, v1

    .end local v1    # "$this$filterKeys\\13":Ljava/util/Map;
    .local v16, "$this$filterKeys\\13":Ljava/util/Map;
    const-string v1, "/manifest.json"

    move/from16 v17, v2

    const/4 v2, 0x0

    .end local v2    # "$i$f$filterKeys\\13\\44":I
    .local v17, "$i$f$filterKeys\\13\\44":I
    invoke-static {v12, v1, v2, v14, v15}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    .line 135
    .end local v12    # "it\\14":Ljava/lang/String;
    .end local v13    # "$i$a$-filterKeys-GuestTools$read$families$1\\14\\135\\0":I
    if-eqz v1, :cond_9

    .line 136
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v12

    invoke-virtual {v3, v1, v12}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, v16

    move/from16 v2, v17

    goto :goto_8

    .line 135
    :cond_9
    move-object/from16 v1, v16

    move/from16 v2, v17

    goto :goto_8

    .line 139
    .end local v6    # "entry\\13":Ljava/util/Map$Entry;
    .end local v16    # "$this$filterKeys\\13":Ljava/util/Map;
    .end local v17    # "$i$f$filterKeys\\13\\44":I
    .restart local v1    # "$this$filterKeys\\13":Ljava/util/Map;
    .restart local v2    # "$i$f$filterKeys\\13\\44":I
    :cond_a
    move-object/from16 v16, v1

    move/from16 v17, v2

    .end local v1    # "$this$filterKeys\\13":Ljava/util/Map;
    .end local v2    # "$i$f$filterKeys\\13\\44":I
    .restart local v16    # "$this$filterKeys\\13":Ljava/util/Map;
    .restart local v17    # "$i$f$filterKeys\\13\\44":I
    move-object v1, v3

    check-cast v1, Ljava/util/Map;

    .line 44
    .end local v3    # "result\\13":Ljava/util/LinkedHashMap;
    .end local v16    # "$this$filterKeys\\13":Ljava/util/Map;
    .end local v17    # "$i$f$filterKeys\\13\\44":I
    nop

    .local v1, "$this$map\\15":Ljava/util/Map;
    const/4 v2, 0x0

    .line 140
    .local v2, "$i$f$map\\15\\44":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\16":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$mapTo\\16":Ljava/util/Map;
    const/4 v6, 0x0

    .line 141
    .local v6, "$i$f$mapTo\\16\\140":I
    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v12

    invoke-interface {v12}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_9
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_b

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/util/Map$Entry;

    .line 142
    .local v13, "item\\16":Ljava/util/Map$Entry;
    move-object v14, v13

    .local v14, "it\\17":Ljava/util/Map$Entry;
    const/4 v15, 0x0

    .line 44
    .local v15, "$i$a$-map-GuestTools$read$families$2\\17\\142\\0":I
    move-object/from16 v16, v1

    .end local v1    # "$this$map\\15":Ljava/util/Map;
    .local v16, "$this$map\\15":Ljava/util/Map;
    new-instance v1, Lorg/json/JSONObject;

    move/from16 v17, v2

    .end local v2    # "$i$f$map\\15\\44":I
    .local v17, "$i$f$map\\15\\44":I
    new-instance v2, Ljava/lang/String;

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v18

    move/from16 v19, v4

    .end local v4    # "offset":I
    .local v19, "offset":I
    move-object/from16 v4, v18

    check-cast v4, [B

    move-object/from16 v18, v5

    .end local v5    # "$this$mapTo\\16":Ljava/util/Map;
    .local v18, "$this$mapTo\\16":Ljava/util/Map;
    sget-object v5, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v4, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 142
    .end local v14    # "it\\17":Ljava/util/Map$Entry;
    .end local v15    # "$i$a$-map-GuestTools$read$families$2\\17\\142\\0":I
    invoke-interface {v3, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, v16

    move/from16 v2, v17

    move-object/from16 v5, v18

    move/from16 v4, v19

    goto :goto_9

    .line 143
    .end local v13    # "item\\16":Ljava/util/Map$Entry;
    .end local v16    # "$this$map\\15":Ljava/util/Map;
    .end local v17    # "$i$f$map\\15\\44":I
    .end local v18    # "$this$mapTo\\16":Ljava/util/Map;
    .end local v19    # "offset":I
    .restart local v1    # "$this$map\\15":Ljava/util/Map;
    .restart local v2    # "$i$f$map\\15\\44":I
    .restart local v4    # "offset":I
    .restart local v5    # "$this$mapTo\\16":Ljava/util/Map;
    :cond_b
    move-object/from16 v16, v1

    move/from16 v17, v2

    .end local v1    # "$this$map\\15":Ljava/util/Map;
    .end local v2    # "$i$f$map\\15\\44":I
    .end local v3    # "destination\\16":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\16":Ljava/util/Map;
    .end local v6    # "$i$f$mapTo\\16\\140":I
    .restart local v16    # "$this$map\\15":Ljava/util/Map;
    .restart local v17    # "$i$f$map\\15\\44":I
    move-object v1, v3

    check-cast v1, Ljava/util/List;

    .line 140
    nop

    .line 44
    .end local v16    # "$this$map\\15":Ljava/util/Map;
    .end local v17    # "$i$f$map\\15\\44":I
    nop

    .line 45
    .local v1, "families":Ljava/util/List;
    new-instance v2, Lorg/lighttouch/android/GuestTools$Pack;

    invoke-direct {v2, v0, v8, v1}, Lorg/lighttouch/android/GuestTools$Pack;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/List;)V

    return-object v2

    .line 123
    .end local v1    # "families":Ljava/util/List;
    .end local v8    # "files":Ljava/util/Map;
    .end local v20    # "length":I
    .local v2, "length":I
    .local v4, "$i$a$-run-GuestTools$read$4\\5\\34\\0":I
    .local v6, "at\\5":I
    .local v12, "$this$read_u24lambda_u2412\\5":Ljava/util/zip/Inflater;
    :cond_c
    move/from16 v20, v2

    .end local v2    # "length":I
    .restart local v20    # "length":I
    const/4 v1, 0x0

    .line 37
    .local v1, "$i$a$-require-GuestTools$read$4$2\\8\\37\\5":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v1    # "$i$a$-require-GuestTools$read$4$2\\8\\37\\5":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 123
    .end local v4    # "$i$a$-run-GuestTools$read$4\\5\\34\\0":I
    .end local v6    # "at\\5":I
    .end local v9    # "payload":[B
    .end local v12    # "$this$read_u24lambda_u2412\\5":Ljava/util/zip/Inflater;
    .end local v20    # "length":I
    .restart local v2    # "length":I
    :cond_d
    move/from16 v20, v2

    .end local v2    # "length":I
    .restart local v20    # "length":I
    const/4 v1, 0x0

    .line 32
    .local v1, "$i$a$-require-GuestTools$read$2\\3\\32\\0":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " exceeds the guest package limit"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v1    # "$i$a$-require-GuestTools$read$2\\3\\32\\0":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 123
    .end local v7    # "entries":Lorg/json/JSONArray;
    .end local v10    # "total":J
    .end local v20    # "length":I
    :cond_e
    const/4 v1, 0x0

    .line 28
    .local v1, "$i$a$-require-GuestTools$read$1\\1\\28\\0":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " is not a guest package"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v1    # "$i$a$-require-GuestTools$read$1\\1\\28\\0":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private final serial(Lorg/lighttouch/android/GuestTools$Pack;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Integer;
    .locals 8
    .param p1, "pack"    # Lorg/lighttouch/android/GuestTools$Pack;
    .param p2, "board"    # Ljava/lang/String;
    .param p3, "build"    # Ljava/lang/String;

    .line 70
    invoke-virtual {p1}, Lorg/lighttouch/android/GuestTools$Pack;->getFamilies()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 161
    .local v1, "$i$f$firstOrNull\\1\\70":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v5, v3

    check-cast v5, Lorg/json/JSONObject;

    .local v5, "it\\2":Lorg/json/JSONObject;
    const/4 v6, 0x0

    .line 70
    .local v6, "$i$a$-firstOrNull-GuestTools$serial$1\\2\\161\\0":I
    sget-object v7, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    invoke-direct {v7, v5, p2, p3}, Lorg/lighttouch/android/GuestTools;->covers(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    .line 161
    .end local v5    # "it\\2":Lorg/json/JSONObject;
    .end local v6    # "$i$a$-firstOrNull-GuestTools$serial$1\\2\\161\\0":I
    if-eqz v5, :cond_0

    goto :goto_0

    .line 162
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_1
    move-object v3, v4

    .line 70
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\70":I
    :goto_0
    check-cast v3, Lorg/json/JSONObject;

    if-eqz v3, :cond_2

    const-string v0, "serial"

    const/4 v1, 0x0

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    :cond_2
    return-object v4
.end method

.method private final strings(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 9
    .param p1, "$this$strings"    # Lorg/json/JSONArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 48
    const/4 v0, 0x0

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 144
    .local v1, "$i$f$map\\1\\48":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 145
    .local v4, "$i$f$mapTo\\2\\144":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    move-object v6, v5

    check-cast v6, Lkotlin/collections/IntIterator;

    invoke-virtual {v6}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v6

    .line 146
    .local v6, "item\\2":I
    move v7, v6

    .local v7, "it\\3":I
    const/4 v8, 0x0

    .line 48
    .local v8, "$i$a$-map-GuestTools$strings$1\\3\\146\\0":I
    invoke-virtual {p1, v7}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 146
    .end local v7    # "it\\3":I
    .end local v8    # "$i$a$-map-GuestTools$strings$1\\3\\146\\0":I
    invoke-interface {v2, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 147
    .end local v6    # "item\\2":I
    :cond_0
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\144":I
    check-cast v2, Ljava/util/List;

    .line 144
    nop

    .line 48
    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\48":I
    return-object v2
.end method


# virtual methods
.method public final firmwareTools(Landroid/content/Context;)Ljava/io/File;
    .locals 16
    .param p1, "context"    # Landroid/content/Context;

    const-string v0, "context"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v2, "guest-tools"

    invoke-virtual {v0, v2}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    new-array v0, v2, [Ljava/lang/String;

    .local v0, "$this$filter\\1":[Ljava/lang/Object;
    :cond_0
    const/4 v3, 0x0

    .line 168
    .local v3, "$i$f$filter\\1\\94":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v0

    .local v5, "$this$filterTo\\2":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 169
    .local v6, "$i$f$filterTo\\2\\168":I
    array-length v7, v5

    move v8, v2

    :goto_0
    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ge v8, v7, :cond_2

    aget-object v11, v5, v8

    .local v11, "element\\2":Ljava/lang/Object;
    move-object v12, v11

    .local v12, "it\\3":Ljava/lang/String;
    const/4 v13, 0x0

    .line 94
    .local v13, "$i$a$-filter-GuestTools$firmwareTools$names$1\\3\\169\\0":I
    invoke-static {v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v14, ".json"

    invoke-static {v12, v14, v2, v9, v10}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v9

    .line 169
    .end local v12    # "it\\3":Ljava/lang/String;
    .end local v13    # "$i$a$-filter-GuestTools$firmwareTools$names$1\\3\\169\\0":I
    if-nez v9, :cond_1

    invoke-interface {v4, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v11    # "element\\2":Ljava/lang/Object;
    :cond_1
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 170
    :cond_2
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\2":[Ljava/lang/Object;
    .end local v6    # "$i$f$filterTo\\2\\168":I
    check-cast v4, Ljava/util/List;

    .line 168
    nop

    .line 94
    .end local v0    # "$this$filter\\1":[Ljava/lang/Object;
    .end local v3    # "$i$f$filter\\1\\94":I
    nop

    .line 95
    .local v4, "names":Ljava/util/List;
    move-object v0, v4

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\4":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 171
    .local v3, "$i$f$any\\4\\95":I
    instance-of v5, v0, Ljava/util/Collection;

    if-eqz v5, :cond_3

    move-object v5, v0

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    move v0, v2

    goto :goto_1

    .line 172
    :cond_3
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_5

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\4":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/lang/String;

    .local v8, "it\\5":Ljava/lang/String;
    const/4 v11, 0x0

    .line 95
    .local v11, "$i$a$-any-GuestTools$firmwareTools$1\\5\\172\\0":I
    const-string v12, "it_seal"

    invoke-static {v8, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    .line 172
    .end local v8    # "it\\5":Ljava/lang/String;
    .end local v11    # "$i$a$-any-GuestTools$firmwareTools$1\\5\\172\\0":I
    if-eqz v8, :cond_4

    const/4 v0, 0x1

    goto :goto_1

    .line 173
    .end local v7    # "element\\4":Ljava/lang/Object;
    :cond_5
    move v0, v2

    .line 95
    .end local v0    # "$this$any\\4":Ljava/lang/Iterable;
    .end local v3    # "$i$f$any\\4\\95":I
    :goto_1
    if-eqz v0, :cond_a

    .line 96
    new-instance v0, Ljava/io/File;

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const-string v5, "firmware-tools"

    invoke-direct {v0, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v3, v0

    .line 97
    .local v3, "root":Ljava/io/File;
    invoke-static {v3}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 98
    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_9

    .line 99
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_6
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 100
    .local v5, "name":Ljava/lang/String;
    new-instance v7, Ljava/io/File;

    invoke-direct {v7, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 101
    .local v7, "target":Ljava/io/File;
    invoke-virtual {v1}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v8

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "guest-tools/"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v8, v11}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v8

    check-cast v8, Ljava/io/Closeable;

    :try_start_0
    move-object v11, v8

    check-cast v11, Ljava/io/InputStream;

    .line 123
    .local v11, "input\\8":Ljava/io/InputStream;
    const/4 v12, 0x0

    .local v12, "$i$a$-use-GuestTools$firmwareTools$4\\8\\101\\0":I
    new-instance v13, Ljava/io/FileOutputStream;

    .line 101
    invoke-direct {v13, v7}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v13, Ljava/io/Closeable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    move-object v14, v13

    check-cast v14, Ljava/io/FileOutputStream;

    .line 123
    .local v14, "it\\9":Ljava/io/FileOutputStream;
    const/4 v15, 0x0

    .line 101
    .local v15, "$i$a$-use-GuestTools$firmwareTools$4$1\\9\\101\\8":I
    invoke-static {v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v6, v14

    check-cast v6, Ljava/io/OutputStream;

    invoke-static {v11, v6, v2, v9, v10}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v14    # "it\\9":Ljava/io/FileOutputStream;
    .end local v15    # "$i$a$-use-GuestTools$firmwareTools$4$1\\9\\101\\8":I
    :try_start_2
    invoke-static {v13, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .end local v11    # "input\\8":Ljava/io/InputStream;
    .end local v12    # "$i$a$-use-GuestTools$firmwareTools$4\\8\\101\\0":I
    invoke-static {v8, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 103
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    const/16 v8, 0x2e

    invoke-static {v6, v8, v2, v9, v10}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    const-string v6, ".dylib"

    invoke-static {v5, v6, v2, v9, v10}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6

    :cond_7
    const/4 v6, 0x1

    invoke-virtual {v7, v6, v2}, Ljava/io/File;->setExecutable(ZZ)Z

    goto :goto_2

    .line 101
    .restart local v11    # "input\\8":Ljava/io/InputStream;
    .restart local v12    # "$i$a$-use-GuestTools$firmwareTools$4\\8\\101\\0":I
    :catchall_0
    move-exception v0

    move-object v2, v0

    .end local v3    # "root":Ljava/io/File;
    .end local v4    # "names":Ljava/util/List;
    .end local v5    # "name":Ljava/lang/String;
    .end local v7    # "target":Ljava/io/File;
    .end local v11    # "input\\8":Ljava/io/InputStream;
    .end local v12    # "$i$a$-use-GuestTools$firmwareTools$4\\8\\101\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .end local p1    # "context":Landroid/content/Context;
    :try_start_3
    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .restart local v3    # "root":Ljava/io/File;
    .restart local v4    # "names":Ljava/util/List;
    .restart local v5    # "name":Ljava/lang/String;
    .restart local v7    # "target":Ljava/io/File;
    .restart local v11    # "input\\8":Ljava/io/InputStream;
    .restart local v12    # "$i$a$-use-GuestTools$firmwareTools$4\\8\\101\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .restart local p1    # "context":Landroid/content/Context;
    :catchall_1
    move-exception v0

    :try_start_4
    invoke-static {v13, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v3    # "root":Ljava/io/File;
    .end local v4    # "names":Ljava/util/List;
    .end local v5    # "name":Ljava/lang/String;
    .end local v7    # "target":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .end local p1    # "context":Landroid/content/Context;
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .end local v11    # "input\\8":Ljava/io/InputStream;
    .end local v12    # "$i$a$-use-GuestTools$firmwareTools$4\\8\\101\\0":I
    .restart local v3    # "root":Ljava/io/File;
    .restart local v4    # "names":Ljava/util/List;
    .restart local v5    # "name":Ljava/lang/String;
    .restart local v7    # "target":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .restart local p1    # "context":Landroid/content/Context;
    :catchall_2
    move-exception v0

    move-object v2, v0

    .end local v3    # "root":Ljava/io/File;
    .end local v4    # "names":Ljava/util/List;
    .end local v5    # "name":Ljava/lang/String;
    .end local v7    # "target":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .end local p1    # "context":Landroid/content/Context;
    :try_start_5
    throw v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .restart local v3    # "root":Ljava/io/File;
    .restart local v4    # "names":Ljava/util/List;
    .restart local v5    # "name":Ljava/lang/String;
    .restart local v7    # "target":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .restart local p1    # "context":Landroid/content/Context;
    :catchall_3
    move-exception v0

    invoke-static {v8, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 105
    .end local v5    # "name":Ljava/lang/String;
    .end local v7    # "target":Ljava/io/File;
    :cond_8
    return-object v3

    .line 123
    :cond_9
    const/4 v0, 0x0

    .line 98
    .local v0, "$i$a$-check-GuestTools$firmwareTools$3\\7\\98\\0":I
    nop

    .end local v0    # "$i$a$-check-GuestTools$firmwareTools$3\\7\\98\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "\u65e0\u6cd5\u521b\u5efa\u51c6\u5907\u5de5\u5177\u76ee\u5f55"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 123
    .end local v3    # "root":Ljava/io/File;
    :cond_a
    const/4 v0, 0x0

    .line 95
    .local v0, "$i$a$-check-GuestTools$firmwareTools$2\\6\\95\\0":I
    nop

    .end local v0    # "$i$a$-check-GuestTools$firmwareTools$2\\6\\95\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "\u6b64\u7248\u672c\u7684 LightTouch \u4e0d\u5305\u542b\u8bbe\u5907\u51c6\u5907\u5de5\u5177"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final forDevice(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 17
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "board"    # Ljava/lang/String;
    .param p3, "build"    # Ljava/lang/String;

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    const-string v0, "context"

    move-object/from16 v3, p1

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "board"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "build"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/GuestTools;->packs(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 156
    .local v4, "$i$f$firstOrNull\\1\\60":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\1":Ljava/lang/Object;
    move-object v8, v6

    check-cast v8, Lorg/lighttouch/android/GuestTools$Pack;

    .local v8, "pack\\2":Lorg/lighttouch/android/GuestTools$Pack;
    const/4 v9, 0x0

    .line 60
    .local v9, "$i$a$-firstOrNull-GuestTools$forDevice$pack$1\\2\\156\\0":I
    invoke-virtual {v8}, Lorg/lighttouch/android/GuestTools$Pack;->getFamilies()Ljava/util/List;

    move-result-object v10

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$any\\3":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 157
    .local v11, "$i$f$any\\3\\60":I
    instance-of v12, v10, Ljava/util/Collection;

    if-eqz v12, :cond_1

    move-object v12, v10

    check-cast v12, Ljava/util/Collection;

    invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_1

    const/4 v13, 0x0

    goto :goto_0

    .line 158
    :cond_1
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_2
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_3

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\3":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Lorg/json/JSONObject;

    .local v15, "it\\4":Lorg/json/JSONObject;
    const/16 v16, 0x0

    .line 60
    .local v16, "$i$a$-any-GuestTools$forDevice$pack$1$1\\4\\158\\2":I
    sget-object v13, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    invoke-direct {v13, v15, v1, v2}, Lorg/lighttouch/android/GuestTools;->covers(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v13

    .line 158
    .end local v15    # "it\\4":Lorg/json/JSONObject;
    .end local v16    # "$i$a$-any-GuestTools$forDevice$pack$1$1\\4\\158\\2":I
    if-eqz v13, :cond_2

    const/4 v13, 0x1

    goto :goto_0

    .line 159
    .end local v14    # "element\\3":Ljava/lang/Object;
    :cond_3
    const/4 v13, 0x0

    .line 60
    .end local v10    # "$this$any\\3":Ljava/lang/Iterable;
    .end local v11    # "$i$f$any\\3\\60":I
    :goto_0
    nop

    .line 156
    .end local v8    # "pack\\2":Lorg/lighttouch/android/GuestTools$Pack;
    .end local v9    # "$i$a$-firstOrNull-GuestTools$forDevice$pack$1\\2\\156\\0":I
    if-eqz v13, :cond_0

    goto :goto_1

    .line 160
    .end local v6    # "element\\1":Ljava/lang/Object;
    :cond_4
    move-object v6, v7

    .line 60
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v4    # "$i$f$firstOrNull\\1\\60":I
    :goto_1
    check-cast v6, Lorg/lighttouch/android/GuestTools$Pack;

    if-nez v6, :cond_5

    return-object v7

    .line 61
    .local v6, "pack":Lorg/lighttouch/android/GuestTools$Pack;
    :cond_5
    new-instance v0, Ljava/io/File;

    invoke-virtual {v3}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v4

    invoke-virtual {v6}, Lorg/lighttouch/android/GuestTools$Pack;->getAsset()Ljava/lang/String;

    move-result-object v5

    const/16 v8, 0x2f

    const/4 v9, 0x2

    invoke-static {v5, v8, v7, v9, v7}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "bundled-"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v4, v0

    .line 62
    .local v4, "target":Ljava/io/File;
    invoke-virtual {v3}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v6}, Lorg/lighttouch/android/GuestTools$Pack;->getAsset()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v5

    check-cast v0, Ljava/io/InputStream;

    .line 123
    .local v0, "it\\5":Ljava/io/InputStream;
    const/4 v8, 0x0

    .line 62
    .local v8, "$i$a$-use-GuestTools$forDevice$bytes$1\\5\\62\\0":I
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->readBytes(Ljava/io/InputStream;)[B

    move-result-object v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v0    # "it\\5":Ljava/io/InputStream;
    .end local v8    # "$i$a$-use-GuestTools$forDevice$bytes$1\\5\\62\\0":I
    invoke-static {v5, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 63
    .local v9, "bytes":[B
    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-static {v4}, Lkotlin/io/FilesKt;->readBytes(Ljava/io/File;)[B

    move-result-object v0

    invoke-static {v0, v9}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v0

    if-nez v0, :cond_7

    .line 64
    :cond_6
    new-instance v0, Ljava/io/File;

    invoke-virtual {v4}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ".partial"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .local v0, "partial":Ljava/io/File;
    invoke-static {v0, v9}, Lkotlin/io/FilesKt;->writeBytes(Ljava/io/File;[B)V

    .line 65
    invoke-virtual {v0, v4}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v5

    if-eqz v5, :cond_8

    .line 67
    .end local v0    # "partial":Ljava/io/File;
    :cond_7
    return-object v4

    .line 123
    .restart local v0    # "partial":Ljava/io/File;
    :cond_8
    const/4 v5, 0x0

    .line 65
    .local v5, "$i$a$-check-GuestTools$forDevice$1\\6\\65\\0":I
    nop

    .end local v5    # "$i$a$-check-GuestTools$forDevice$1\\6\\65\\0":I
    new-instance v5, Ljava/lang/IllegalStateException;

    const-string v7, "\u65e0\u6cd5\u90e8\u7f72\u5185\u7f6e\u5ba2\u6237\u673a\u5de5\u5177"

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v5, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 62
    .end local v0    # "partial":Ljava/io/File;
    .end local v9    # "bytes":[B
    :catchall_0
    move-exception v0

    move-object v7, v0

    .end local v4    # "target":Ljava/io/File;
    .end local v6    # "pack":Lorg/lighttouch/android/GuestTools$Pack;
    .end local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .end local p1    # "context":Landroid/content/Context;
    .end local p2    # "board":Ljava/lang/String;
    .end local p3    # "build":Ljava/lang/String;
    :try_start_1
    throw v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local v4    # "target":Ljava/io/File;
    .restart local v6    # "pack":Lorg/lighttouch/android/GuestTools$Pack;
    .restart local p0    # "this":Lorg/lighttouch/android/GuestTools;
    .restart local p1    # "context":Landroid/content/Context;
    .restart local p2    # "board":Ljava/lang/String;
    .restart local p3    # "build":Ljava/lang/String;
    :catchall_1
    move-exception v0

    invoke-static {v5, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final newerFor(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;
    .locals 21
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "recordId"    # Ljava/lang/String;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const-string v0, "context"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "recordId"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    new-instance v0, Ljava/io/File;

    invoke-virtual {v2}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "library/records/"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v4, v0

    .line 80
    .local v4, "record":Ljava/io/File;
    new-instance v0, Lorg/json/JSONObject;

    new-instance v5, Ljava/io/File;

    const-string v6, "record.json"

    invoke-direct {v5, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v5, v6, v7, v6}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    move-object v5, v0

    .line 81
    .local v5, "metadata":Lorg/json/JSONObject;
    const-string v0, "board"

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .local v8, "board":Ljava/lang/String;
    const-string v0, "build"

    invoke-virtual {v5, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 82
    .local v9, "build":Ljava/lang/String;
    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/GuestTools;->packs(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 163
    .local v10, "$i$f$firstOrNull\\1\\82":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_4

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\1":Ljava/lang/Object;
    move-object v14, v12

    check-cast v14, Lorg/lighttouch/android/GuestTools$Pack;

    .local v14, "pack\\2":Lorg/lighttouch/android/GuestTools$Pack;
    const/4 v15, 0x0

    .line 82
    .local v15, "$i$a$-firstOrNull-GuestTools$newerFor$bundled$1\\2\\163\\0":I
    invoke-virtual {v14}, Lorg/lighttouch/android/GuestTools$Pack;->getFamilies()Ljava/util/List;

    move-result-object v16

    move-object/from16 v17, v6

    move-object/from16 v6, v16

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$any\\3":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 164
    .local v16, "$i$f$any\\3\\82":I
    instance-of v7, v6, Ljava/util/Collection;

    if-eqz v7, :cond_0

    move-object v7, v6

    check-cast v7, Ljava/util/Collection;

    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_0

    move-object/from16 v20, v0

    const/4 v13, 0x0

    goto :goto_2

    .line 165
    :cond_0
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_2

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .local v18, "element\\3":Ljava/lang/Object;
    move-object/from16 v13, v18

    check-cast v13, Lorg/json/JSONObject;

    .local v13, "it\\4":Lorg/json/JSONObject;
    const/16 v19, 0x0

    .line 82
    .local v19, "$i$a$-any-GuestTools$newerFor$bundled$1$1\\4\\165\\2":I
    move-object/from16 v20, v0

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .local v20, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    sget-object v0, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    invoke-static {v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v0, v13, v8, v9}, Lorg/lighttouch/android/GuestTools;->covers(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    .line 165
    .end local v13    # "it\\4":Lorg/json/JSONObject;
    .end local v19    # "$i$a$-any-GuestTools$newerFor$bundled$1$1\\4\\165\\2":I
    if-eqz v0, :cond_1

    const/4 v13, 0x1

    goto :goto_2

    :cond_1
    move-object/from16 v0, v20

    goto :goto_1

    .line 166
    .end local v18    # "element\\3":Ljava/lang/Object;
    .end local v20    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .restart local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    :cond_2
    move-object/from16 v20, v0

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .restart local v20    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 82
    .end local v6    # "$this$any\\3":Ljava/lang/Iterable;
    .end local v16    # "$i$f$any\\3\\82":I
    :goto_2
    nop

    .line 163
    .end local v14    # "pack\\2":Lorg/lighttouch/android/GuestTools$Pack;
    .end local v15    # "$i$a$-firstOrNull-GuestTools$newerFor$bundled$1\\2\\163\\0":I
    if-eqz v13, :cond_3

    goto :goto_3

    :cond_3
    move-object/from16 v6, v17

    move-object/from16 v0, v20

    const/4 v7, 0x1

    goto :goto_0

    .line 167
    .end local v12    # "element\\1":Ljava/lang/Object;
    .end local v20    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .restart local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    :cond_4
    move-object/from16 v20, v0

    move-object/from16 v17, v6

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .restart local v20    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    move-object/from16 v12, v17

    .line 82
    .end local v10    # "$i$f$firstOrNull\\1\\82":I
    .end local v20    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    :goto_3
    check-cast v12, Lorg/lighttouch/android/GuestTools$Pack;

    if-nez v12, :cond_5

    return-object v17

    .line 83
    .local v12, "bundled":Lorg/lighttouch/android/GuestTools$Pack;
    :cond_5
    new-instance v0, Ljava/io/File;

    const-string v6, "assets/guest.itpack"

    invoke-direct {v0, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v0

    .line 84
    .local v6, "installed":Ljava/io/File;
    invoke-virtual {v6}, Ljava/io/File;->isFile()Z

    move-result v0

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_4

    :cond_6
    :try_start_0
    const-string v0, "guest.itpack"

    invoke-static {v6}, Lkotlin/io/FilesKt;->readBytes(Ljava/io/File;)[B

    move-result-object v7

    invoke-direct {v1, v0, v7}, Lorg/lighttouch/android/GuestTools;->read(Ljava/lang/String;[B)Lorg/lighttouch/android/GuestTools$Pack;

    move-result-object v0

    invoke-static {v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, v0, v8, v9}, Lorg/lighttouch/android/GuestTools;->serial(Lorg/lighttouch/android/GuestTools$Pack;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_4

    :cond_7
    const/4 v0, 0x0

    .line 85
    .local v0, "have":I
    :goto_4
    invoke-static {v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {v1, v12, v8, v9}, Lorg/lighttouch/android/GuestTools;->serial(Lorg/lighttouch/android/GuestTools$Pack;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    if-eqz v7, :cond_8

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v13

    goto :goto_5

    :cond_8
    const/4 v13, 0x0

    :goto_5
    if-le v13, v0, :cond_9

    invoke-virtual {v1, v2, v8, v9}, Lorg/lighttouch/android/GuestTools;->forDevice(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object v7

    move-object/from16 v17, v7

    :cond_9
    return-object v17

    .line 84
    .end local v0    # "have":I
    :catch_0
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    return-object v17
.end method

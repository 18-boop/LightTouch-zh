.class public final Lorg/lighttouch/android/SetupWizardKt;
.super Ljava/lang/Object;
.source "SetupWizard.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSetupWizard.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SetupWizard.kt\norg/lighttouch/android/SetupWizardKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 9 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 10 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 11 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 12 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 13 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,247:1\n1225#2,6:248\n1225#2,6:254\n1225#2,6:433\n1225#2,6:482\n1225#2,6:627\n1225#2,6:675\n1225#2,6:682\n1225#2,6:693\n1225#2,6:712\n149#3:260\n149#3:296\n149#3:332\n149#3:337\n149#3:338\n149#3:339\n149#3:340\n149#3:341\n149#3:342\n149#3:343\n149#3:348\n149#3:385\n149#3:386\n149#3:439\n149#3:476\n149#3:477\n149#3:478\n149#3:480\n149#3:481\n149#3:488\n149#3:489\n149#3:490\n149#3:491\n149#3:492\n149#3:497\n149#3:498\n149#3:535\n149#3:536\n149#3,11:577\n149#3:592\n149#3:625\n149#3:626\n149#3:633\n149#3:638\n149#3:671\n149#3:672\n149#3:673\n149#3:674\n149#3:681\n149#3:688\n149#3:718\n149#3:719\n149#3:756\n86#4:261\n84#4,5:262\n89#4:295\n93#4:347\n86#4:387\n82#4,7:388\n89#4:423\n93#4:427\n86#4:440\n83#4,6:441\n89#4:475\n93#4:496\n86#4:537\n83#4,6:538\n89#4:572\n93#4:576\n86#4,3:593\n89#4:624\n93#4:637\n86#4,3:639\n89#4:670\n93#4:692\n86#4:720\n83#4,6:721\n89#4:755\n93#4:800\n79#5,6:267\n86#5,4:282\n90#5,2:292\n79#5,6:303\n86#5,4:318\n90#5,2:328\n94#5:335\n94#5:346\n79#5,6:356\n86#5,4:371\n90#5,2:381\n79#5,6:395\n86#5,4:410\n90#5,2:420\n94#5:426\n94#5:430\n79#5,6:447\n86#5,4:462\n90#5,2:472\n94#5:495\n79#5,6:506\n86#5,4:521\n90#5,2:531\n79#5,6:544\n86#5,4:559\n90#5,2:569\n94#5:575\n94#5:590\n79#5,6:596\n86#5,4:611\n90#5,2:621\n94#5:636\n79#5,6:642\n86#5,4:657\n90#5,2:667\n94#5:691\n79#5,6:727\n86#5,4:742\n90#5,2:752\n79#5,6:764\n86#5,4:779\n90#5,2:789\n94#5:795\n94#5:799\n368#6,9:273\n377#6:294\n368#6,9:309\n377#6:330\n378#6,2:333\n378#6,2:344\n368#6,9:362\n377#6:383\n368#6,9:401\n377#6:422\n378#6,2:424\n378#6,2:428\n368#6,9:453\n377#6:474\n378#6,2:493\n368#6,9:512\n377#6:533\n368#6,9:550\n377#6:571\n378#6,2:573\n378#6,2:588\n368#6,9:602\n377#6:623\n378#6,2:634\n368#6,9:648\n377#6:669\n378#6,2:689\n368#6,9:733\n377#6:754\n368#6,9:770\n377#6:791\n378#6,2:793\n378#6,2:797\n4034#7,6:286\n4034#7,6:322\n4034#7,6:375\n4034#7,6:414\n4034#7,6:466\n4034#7,6:525\n4034#7,6:563\n4034#7,6:615\n4034#7,6:661\n4034#7,6:746\n4034#7,6:783\n71#8:297\n69#8,5:298\n74#8:331\n78#8:336\n99#9:349\n96#9,6:350\n102#9:384\n106#9:431\n99#9:499\n96#9,6:500\n102#9:534\n106#9:591\n99#9:757\n96#9,6:758\n102#9:792\n106#9:796\n77#10:432\n1#11:479\n1#11:709\n1617#12,9:699\n1869#12:708\n1870#12:710\n1626#12:711\n81#13:801\n107#13,2:802\n*S KotlinDebug\n*F\n+ 1 SetupWizard.kt\norg/lighttouch/android/SetupWizardKt\n*L\n68#1:248,6\n76#1:254,6\n136#1:433,6\n163#1:482,6\n204#1:627,6\n222#1:675,6\n225#1:682,6\n233#1:693,6\n235#1:712,6\n96#1:260\n97#1:296\n98#1:332\n100#1:337\n102#1:338\n105#1:339\n107#1:340\n111#1:341\n112#1:342\n115#1:343\n123#1:348\n124#1:385\n125#1:386\n145#1:439\n146#1:476\n148#1:477\n151#1:478\n161#1:480\n162#1:481\n165#1:488\n166#1:489\n167#1:490\n168#1:491\n173#1:492\n180#1:497\n181#1:498\n183#1:535\n184#1:536\n191#1:577,11\n197#1:592\n199#1:625\n203#1:626\n206#1:633\n214#1:638\n215#1:671\n216#1:672\n218#1:673\n221#1:674\n222#1:681\n225#1:688\n235#1:718\n238#1:719\n240#1:756\n96#1:261\n96#1:262,5\n96#1:295\n96#1:347\n126#1:387\n126#1:388,7\n126#1:423\n126#1:427\n145#1:440\n145#1:441,6\n145#1:475\n145#1:496\n185#1:537\n185#1:538,6\n185#1:572\n185#1:576\n197#1:593,3\n197#1:624\n197#1:637\n214#1:639,3\n214#1:670\n214#1:692\n238#1:720\n238#1:721,6\n238#1:755\n238#1:800\n96#1:267,6\n96#1:282,4\n96#1:292,2\n97#1:303,6\n97#1:318,4\n97#1:328,2\n97#1:335\n96#1:346\n123#1:356,6\n123#1:371,4\n123#1:381,2\n126#1:395,6\n126#1:410,4\n126#1:420,2\n126#1:426\n123#1:430\n145#1:447,6\n145#1:462,4\n145#1:472,2\n145#1:495\n180#1:506,6\n180#1:521,4\n180#1:531,2\n185#1:544,6\n185#1:559,4\n185#1:569,2\n185#1:575\n180#1:590\n197#1:596,6\n197#1:611,4\n197#1:621,2\n197#1:636\n214#1:642,6\n214#1:657,4\n214#1:667,2\n214#1:691\n238#1:727,6\n238#1:742,4\n238#1:752,2\n240#1:764,6\n240#1:779,4\n240#1:789,2\n240#1:795\n238#1:799\n96#1:273,9\n96#1:294\n97#1:309,9\n97#1:330\n97#1:333,2\n96#1:344,2\n123#1:362,9\n123#1:383\n126#1:401,9\n126#1:422\n126#1:424,2\n123#1:428,2\n145#1:453,9\n145#1:474\n145#1:493,2\n180#1:512,9\n180#1:533\n185#1:550,9\n185#1:571\n185#1:573,2\n180#1:588,2\n197#1:602,9\n197#1:623\n197#1:634,2\n214#1:648,9\n214#1:669\n214#1:689,2\n238#1:733,9\n238#1:754\n240#1:770,9\n240#1:791\n240#1:793,2\n238#1:797,2\n96#1:286,6\n97#1:322,6\n123#1:375,6\n126#1:414,6\n145#1:466,6\n180#1:525,6\n185#1:563,6\n197#1:615,6\n214#1:661,6\n238#1:746,6\n240#1:783,6\n97#1:297\n97#1:298,5\n97#1:331\n97#1:336\n123#1:349\n123#1:350,6\n123#1:384\n123#1:431\n180#1:499\n180#1:500,6\n180#1:534\n180#1:591\n240#1:757\n240#1:758,6\n240#1:792\n240#1:796\n135#1:432\n234#1:709\n234#1:699,9\n234#1:708\n234#1:710\n234#1:711\n233#1:801\n233#1:802,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000N\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u0007\n\u0002\u0008\u0008\u001a\u0094\u0001\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\n\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072!\u0010\u000c\u001a\u001d\u0012\u0013\u0012\u00110\u0005\u00a2\u0006\u000c\u0008\u000e\u0012\u0008\u0008\u000f\u0012\u0004\u0008\u0008(\u0010\u0012\u0004\u0012\u00020\u00010\r2\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0007H\u0001\u00a2\u0006\u0002\u0010\u0012\u001a)\u0010\u0013\u001a\u00020\u00012\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u0014\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0007H\u0003\u00a2\u0006\u0002\u0010\u0015\u001a%\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001aH\u0003\u00a2\u0006\u0002\u0010\u001c\u001a\u0017\u0010\u001d\u001a\u00020\u00012\u0008\u0008\u0002\u0010\u001e\u001a\u00020\u001fH\u0003\u00a2\u0006\u0002\u0010 \u001a[\u0010!\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\n\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0007H\u0003\u00a2\u0006\u0002\u0010\"\u001aO\u0010#\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010$\u001a\u00020\u001a2\u0008\u0010%\u001a\u0004\u0018\u00010&2\u000c\u0010\'\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u0006\u0010(\u001a\u00020\u001a2\u0008\u0008\u0002\u0010)\u001a\u00020\u0005H\u0003\u00a2\u0006\u0002\u0010*\u001a\u001d\u0010+\u001a\u00020\u00012\u0006\u0010,\u001a\u00020\u001a2\u0006\u0010-\u001a\u00020.H\u0003\u00a2\u0006\u0002\u0010/\u001a1\u00100\u001a\u00020\u00012\u0006\u0010\u000f\u001a\u00020\u001a2\u0006\u00101\u001a\u00020\u001a2\u0012\u0010\u000c\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00010\rH\u0003\u00a2\u0006\u0002\u00102\u001a\u0015\u00103\u001a\u00020\u00012\u0006\u00101\u001a\u00020\u001aH\u0003\u00a2\u0006\u0002\u00104\u00a8\u00065\u00b2\u0006\n\u00106\u001a\u00020\u0005X\u008a\u008e\u0002"
    }
    d2 = {
        "SetupWizard",
        "",
        "state",
        "Lorg/lighttouch/android/SetupState;",
        "canCancel",
        "",
        "onPickFolder",
        "Lkotlin/Function0;",
        "onPickSystem",
        "onPickRom",
        "onCreate",
        "onPrepare",
        "onFinish",
        "Lkotlin/Function1;",
        "Lkotlin/ParameterName;",
        "name",
        "start",
        "onCancel",
        "(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "Welcome",
        "onFiles",
        "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "Need",
        "icon",
        "Landroidx/compose/ui/graphics/vector/ImageVector;",
        "title",
        "",
        "detail",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "GuideLink",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V",
        "Files",
        "(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "FileRow",
        "hint",
        "picked",
        "Lorg/lighttouch/android/PickedFile;",
        "onPick",
        "tag",
        "action",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "Creating",
        "phase",
        "progress",
        "",
        "(Ljava/lang/String;FLandroidx/compose/runtime/Composer;I)V",
        "Done",
        "timings",
        "(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V",
        "StageTimes",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "open"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$-Bf8PEeKwHd6W8yUjjUcFNVUToo(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/SetupWizardKt;->Welcome$lambda$7(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7-Kzy3VcZ810p4eRYdpWnYJNgJs(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p8}, Lorg/lighttouch/android/SetupWizardKt;->Files$lambda$18(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FpJbYy8sznHRkBLXqqHgk82JvMo(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes$lambda$44(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$GZR5G1s4mD1SH-Y2khltsYMq1F8(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p11}, Lorg/lighttouch/android/SetupWizardKt;->SetupWizard$lambda$4(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$QnIICqctW8IEpTjO8eUu2F2sJGk(Lorg/lighttouch/android/SetupState;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/SetupWizardKt;->Files$lambda$17$lambda$16$lambda$15(Lorg/lighttouch/android/SetupState;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Su63QIi4sKMzsPmGN-zPShkQmg8(Ljava/lang/String;FILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/SetupWizardKt;->Creating$lambda$26(Ljava/lang/String;FILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TZK4707EBg_B18M76qdPkoDoNGI(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes$lambda$40$lambda$39(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$WWGYBWU3KnOiNJLH8zKNsU0JOFA(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/SetupWizardKt;->FileRow$lambda$21(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$X9QncE50LQcOwxffFbh1af1SrGo(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/SetupWizardKt;->GuideLink$lambda$13(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$gcHE80ejyOoIs5l0t4OU33R9-VI(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->Done$lambda$31$lambda$28$lambda$27(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$hRaDb4BASlfpT8pi7qpEkMFHKY8(Landroid/content/Context;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->GuideLink$lambda$12$lambda$11(Landroid/content/Context;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jhpTexoLuTsjfUtFhgHKSeNexpw(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/SetupWizardKt;->SetupWizard$lambda$1$lambda$0(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$llpw4bkQX3Oj4Nl549V0qLq7FUA(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->SetupWizard$lambda$3$lambda$2(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ofHWh6IhXazwlgVdKwmaIKivpEM(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/SetupWizardKt;->Done$lambda$32(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qHXimiGWBpJ3EEkoz77Gk4ITVl4(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/SetupWizardKt;->Need$lambda$10(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rqxELfpDZ4UN7OEOzrOoe8VHztk(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->Done$lambda$31$lambda$30$lambda$29(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$xvzR31gVX1MxTjg5nk2fQ6QDztk(F)F
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->Creating$lambda$25$lambda$24$lambda$23(F)F

    move-result p0

    return p0
.end method

.method private static final Creating(Ljava/lang/String;FLandroidx/compose/runtime/Composer;I)V
    .locals 58
    .param p0, "phase"    # Ljava/lang/String;
    .param p1, "progress"    # F
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 196
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p3

    const v3, -0x6b09c6b6

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(Creating)196@12068L1013:SetupWizard.kt#o13vsk"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    if-nez v6, :cond_1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v5, v6

    :cond_1
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_3

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_1

    :cond_2
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v5, v6

    :cond_3
    and-int/lit8 v6, v5, 0x13

    const/16 v8, 0x12

    if-ne v6, v8, :cond_5

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_4

    goto :goto_2

    .line 637
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v28, v4

    move/from16 v23, v5

    goto/16 :goto_c

    .line 196
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, -0x1

    const-string v8, "org.lighttouch.android.Creating (SetupWizard.kt:195)"

    invoke-static {v3, v5, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 197
    :cond_6
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v3, v6, v8, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v10, 0x20

    .local v10, "$this$dp\\1":I
    const/4 v11, 0x0

    .line 592
    .local v11, "$i$f$getDp\\1\\197":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 197
    .end local v10    # "$this$dp\\1":I
    .end local v11    # "$i$f$getDp\\1\\197":I
    invoke-static {v3, v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getCenter()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v10

    check-cast v10, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v10, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v11

    .local v11, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v12, 0x1b6

    .local v12, "$changed\\2":I
    const/4 v13, 0x0

    .line 593
    .local v13, "$i$f$Column\\2\\197":I
    const v14, -0x1cd0f17e

    const-string v15, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v4, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 594
    shr-int/lit8 v14, v12, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v15, v12, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v14, v15

    invoke-static {v10, v11, v4, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v12, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 595
    nop

    .local v15, "$changed\\3":I
    const/16 v16, 0x0

    .line 596
    .local v16, "$i$f$Layout\\3\\595":I
    move/from16 p2, v6

    const v6, -0x4ee9b9da

    const-string v8, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v4, v6, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 597
    const/4 v6, 0x0

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v8

    .line 598
    .local v8, "compositeKeyHash\\3":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v6

    .line 599
    .local v6, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 601
    .local v9, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v7, v15, 0x6

    and-int/lit16 v7, v7, 0x380

    move-object/from16 v20, v3

    .end local v3    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v3, 0x6

    or-int/2addr v7, v3

    .line 600
    move-object/from16 v21, v18

    .local v7, "$changed\\4":I
    .local v21, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 602
    .local v18, "$i$f$ReusableComposeNode\\4\\600":I
    move/from16 v22, v3

    const v3, -0x2942ffcf

    move/from16 v23, v5

    .end local v5    # "$dirty":I
    .local v23, "$dirty":I
    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 603
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 604
    :cond_7
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 605
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_8

    .line 606
    move-object/from16 v3, v21

    .end local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 608
    .end local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v3, v21

    .end local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 610
    :goto_3
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 611
    .local v21, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\610\\3":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v25, v3

    .end local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v25, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v14, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 612
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 614
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 615
    .local v24, "$i$f$set-impl\\6\\614":I
    move-object/from16 v26, v5

    .local v26, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 616
    .local v27, "$i$a$-with-Updater$set$1\\7\\615\\6":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_a

    move-object/from16 v28, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v28, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v29, v6

    .end local v6    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v29, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v6, v26

    goto :goto_5

    .end local v28    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v29    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_a
    move-object/from16 v28, v4

    move-object/from16 v29, v6

    .line 617
    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v6    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v28    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v29    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_4
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v6, v26

    .end local v26    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 618
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 620
    :goto_5
    nop

    .line 615
    .end local v6    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-with-Updater$set$1\\7\\615\\6":I
    nop

    .line 620
    nop

    .line 621
    .end local v3    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\6\\614":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v5, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 622
    nop

    .line 610
    .end local v5    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\610\\3":I
    nop

    .line 623
    shr-int/lit8 v3, v7, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\8":I
    move-object/from16 v4, v28

    .local v4, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 624
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\8\\623\\2":I
    const v6, -0x16ef5699

    move/from16 v21, v3

    .end local v3    # "$changed\\8":I
    .local v21, "$changed\\8":I
    const-string v3, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v6, v12, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\9":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$Creating_u24lambda_u2425\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v51, v4

    .local v51, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 198
    .local v24, "$i$a$-Column-SetupWizardKt$Creating$1\\9\\624\\0":I
    move-object/from16 v26, v3

    .end local v3    # "$this$Creating_u24lambda_u2425\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v26, "$this$Creating_u24lambda_u2425\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, 0x4f5f32ca    # 3.7446477E9f

    move-object/from16 v27, v4

    .end local v4    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v4, "C197@12269L10,197@12218L73,198@12300L29,200@12507L10,200@12552L11,199@12338L285,202@12632L30,205@12851L30,206@12960L10,207@13016L11,206@12890L185:SetupWizard.kt#o13vsk"

    move/from16 v55, v5

    move-object/from16 v5, v51

    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v55, "$i$a$-Layout-ColumnKt$Column$1\\8\\623\\2":I
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v50

    const/16 v53, 0x0

    const v54, 0xfffe

    const-string v30, "\u6b63\u5728\u521b\u5efa\u8bbe\u5907"

    const/16 v31, 0x0

    const-wide/16 v32, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v52, 0x6

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v54}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 199
    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\10":I
    const/16 v30, 0x0

    .line 625
    .local v30, "$i$f$getDp\\10\\199":I
    move/from16 v56, v6

    .end local v6    # "$changed\\9":I
    .local v56, "$changed\\9":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 199
    .end local v4    # "$this$dp\\10":I
    .end local v30    # "$i$f$getDp\\10\\199":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v4, v22

    invoke-static {v3, v5, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 200
    move-object v3, v0

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_b

    const/4 v4, 0x1

    goto :goto_6

    :cond_b
    const/4 v4, 0x0

    :goto_6
    if-eqz v4, :cond_c

    .line 479
    const/4 v3, 0x0

    .line 200
    .local v3, "$i$a$-ifEmpty-SetupWizardKt$Creating$1$1\\11\\200\\9":I
    nop

    .end local v3    # "$i$a$-ifEmpty-SetupWizardKt$Creating$1$1\\11\\200\\9":I
    const-string v3, "\u6b63\u5728\u590d\u5236\u6587\u4ef6\u2026"

    :cond_c
    cmpl-float v4, v1, p2

    if-ltz v4, :cond_d

    const/16 v4, 0x64

    int-to-float v4, v4

    mul-float/2addr v4, v1

    float-to-int v4, v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v57, v7

    .end local v7    # "$changed\\4":I
    .local v57, "$changed\\4":I
    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, "%"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    .end local v57    # "$changed\\4":I
    .restart local v7    # "$changed\\4":I
    :cond_d
    move/from16 v57, v7

    .end local v7    # "$changed\\4":I
    .restart local v57    # "$changed\\4":I
    const-string v4, ""

    :goto_7
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v30

    .line 201
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const-string v4, "setup_phase"

    invoke-static {v3, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v50

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v32

    .line 202
    sget-object v3, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v3

    .line 200
    nop

    .line 201
    nop

    .line 202
    invoke-static {v3}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v42

    .line 201
    nop

    .line 200
    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v52, 0x30

    const/16 v53, 0x0

    const v54, 0xfdf8

    move-object/from16 v51, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v54}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 203
    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x18

    .local v4, "$this$dp\\12":I
    const/4 v6, 0x0

    .line 626
    .local v6, "$i$f$getDp\\12\\203":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 203
    .end local v4    # "$this$dp\\12":I
    .end local v6    # "$i$f$getDp\\12\\203":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v4, 0x6

    invoke-static {v3, v5, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 204
    cmpl-float v3, v1, p2

    if-ltz v3, :cond_11

    const v3, 0x341c105a

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "203@12725L29,203@12690L90"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v3, 0x4c5de2

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v23, 0x70

    const/16 v4, 0x20

    if-ne v3, v4, :cond_e

    const/16 v17, 0x1

    goto :goto_8

    :cond_e
    const/16 v17, 0x0

    .local v17, "invalid\\13":Z
    :goto_8
    move-object v3, v5

    .local v3, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 627
    .local v4, "$i$f$cache\\13\\204":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\13":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 628
    .local v7, "$i$a$-let-ComposerKt$cache$1\\14\\627\\13":I
    if-nez v17, :cond_10

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v30, v4

    .end local v4    # "$i$f$cache\\13\\204":I
    .local v30, "$i$f$cache\\13\\204":I
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v6, v4, :cond_f

    goto :goto_9

    .line 632
    :cond_f
    move-object v4, v6

    goto :goto_a

    .line 628
    .end local v30    # "$i$f$cache\\13\\204":I
    .restart local v4    # "$i$f$cache\\13\\204":I
    :cond_10
    move/from16 v30, v4

    .line 629
    .end local v4    # "$i$f$cache\\13\\204":I
    .restart local v30    # "$i$f$cache\\13\\204":I
    :goto_9
    const/4 v4, 0x0

    .line 204
    .local v4, "$i$a$-cache-SetupWizardKt$Creating$1$2\\15\\629\\9":I
    move/from16 v19, v4

    .end local v4    # "$i$a$-cache-SetupWizardKt$Creating$1$2\\15\\629\\9":I
    .local v19, "$i$a$-cache-SetupWizardKt$Creating$1$2\\15\\629\\9":I
    new-instance v4, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda11;

    invoke-direct {v4, v1}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda11;-><init>(F)V

    .line 629
    .end local v19    # "$i$a$-cache-SetupWizardKt$Creating$1$2\\15\\629\\9":I
    nop

    .line 630
    .local v4, "value\\14":Ljava/lang/Object;
    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 631
    nop

    .line 628
    .end local v4    # "value\\14":Ljava/lang/Object;
    :goto_a
    nop

    .line 627
    .end local v6    # "it\\13":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\14\\627\\13":I
    nop

    .line 204
    .end local v3    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v17    # "invalid\\13":Z
    .end local v30    # "$i$f$cache\\13\\204":I
    move-object/from16 v30, v4

    check-cast v30, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    move/from16 v7, p2

    const/4 v4, 0x0

    const/4 v6, 0x1

    invoke-static {v3, v7, v6, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    const/16 v40, 0x30

    const/16 v41, 0x7c

    const-wide/16 v32, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    move-object/from16 v39, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v39, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v41}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .end local v39    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_b

    .line 205
    :cond_11
    const v3, 0x341c1d30

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "204@12794L48"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v3, v7, v6, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v30

    const/16 v38, 0x6

    const/16 v39, 0x1e

    const-wide/16 v31, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    move-object/from16 v37, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v37, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v39}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    .end local v37    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 206
    :goto_b
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xc

    .local v4, "$this$dp\\16":I
    const/4 v6, 0x0

    .line 633
    .local v6, "$i$f$getDp\\16\\206":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 206
    .end local v4    # "$this$dp\\16":I
    .end local v6    # "$i$f$getDp\\16\\206":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v4, 0x6

    invoke-static {v3, v5, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 207
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v50

    .line 208
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v32

    sget-object v3, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v3

    .line 207
    nop

    .line 208
    invoke-static {v3}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v42

    .line 207
    const/16 v53, 0x0

    const v54, 0xfdfa

    const-string v30, "\u5b8c\u6210\u524d\u8bf7\u4fdd\u6301 LightTouch \u5904\u4e8e\u6253\u5f00\u72b6\u6001\u3002"

    const/16 v31, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v52, 0x6

    move-object/from16 v51, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v54}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 198
    .end local v51    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 209
    nop

    .line 624
    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Column-SetupWizardKt$Creating$1\\9\\624\\0":I
    .end local v26    # "$this$Creating_u24lambda_u2425\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v56    # "$changed\\9":I
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 623
    .end local v21    # "$changed\\8":I
    .end local v27    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-Layout-ColumnKt$Column$1\\8\\623\\2":I
    nop

    .line 634
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 602
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 635
    nop

    .line 596
    .end local v18    # "$i$f$ReusableComposeNode\\4\\600":I
    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v57    # "$changed\\4":I
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 636
    nop

    .line 593
    .end local v8    # "compositeKeyHash\\3":I
    .end local v9    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v15    # "$changed\\3":I
    .end local v16    # "$i$f$Layout\\3\\595":I
    .end local v29    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 637
    nop

    .end local v10    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v11    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v12    # "$changed\\2":I
    .end local v13    # "$i$f$Column\\2\\197":I
    .end local v14    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20    # "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_12

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_12
    :goto_c
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_13

    new-instance v4, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda12;

    invoke-direct {v4, v0, v1, v2}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda12;-><init>(Ljava/lang/String;FI)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 210
    :cond_13
    return-void
.end method

.method private static final Creating$lambda$25$lambda$24$lambda$23(F)F
    .locals 2
    .param p0, "$progress"    # F

    .line 204
    const/4 v0, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {p0, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    return v0
.end method

.method private static final Creating$lambda$26(Ljava/lang/String;FILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/SetupWizardKt;->Creating(Ljava/lang/String;FLandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Done(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .locals 58
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "timings"    # Ljava/lang/String;
    .param p2, "onFinish"    # Lkotlin/jvm/functions/Function1;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 213
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p4

    const v4, 0x7ef68049

    move-object/from16 v5, p3

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    const-string v6, "C(Done)P(!1,2)213@13180L1200:SetupWizard.kt#o13vsk"

    invoke-static {v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v6, p4

    .local v6, "$dirty":I
    and-int/lit8 v7, v3, 0x6

    const/4 v8, 0x2

    if-nez v7, :cond_1

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    move v7, v8

    :goto_0
    or-int/2addr v6, v7

    :cond_1
    and-int/lit8 v7, v3, 0x30

    if-nez v7, :cond_3

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    const/16 v7, 0x20

    goto :goto_1

    :cond_2
    const/16 v7, 0x10

    :goto_1
    or-int/2addr v6, v7

    :cond_3
    and-int/lit16 v7, v3, 0x180

    if-nez v7, :cond_5

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v7, 0x100

    goto :goto_2

    :cond_4
    const/16 v7, 0x80

    :goto_2
    or-int/2addr v6, v7

    :cond_5
    and-int/lit16 v7, v6, 0x93

    const/16 v10, 0x92

    if-ne v7, v10, :cond_7

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v7

    if-nez v7, :cond_6

    goto :goto_3

    .line 692
    :cond_6
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v29, v5

    move/from16 v44, v6

    goto/16 :goto_e

    .line 213
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_8

    const/4 v7, -0x1

    const-string v10, "org.lighttouch.android.Done (SetupWizard.kt:212)"

    invoke-static {v4, v6, v7, v10}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 214
    :cond_8
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {v4, v7, v10, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v12, 0x1c

    .local v12, "$this$dp\\1":I
    const/4 v13, 0x0

    .line 638
    .local v13, "$i$f$getDp\\1\\214":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 214
    .end local v12    # "$this$dp\\1":I
    .end local v13    # "$i$f$getDp\\1\\214":I
    invoke-static {v4, v12, v7, v8, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .local v4, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getCenter()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v7

    check-cast v7, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v7, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .local v8, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v11, 0x1b6

    .local v11, "$changed\\2":I
    const/4 v12, 0x0

    .line 639
    .local v12, "$i$f$Column\\2\\214":I
    const v13, -0x1cd0f17e

    const-string v14, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v5, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 640
    shr-int/lit8 v13, v11, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v11, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v7, v8, v5, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v11, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 641
    nop

    .local v14, "$changed\\3":I
    const/4 v15, 0x0

    .line 642
    .local v15, "$i$f$Layout\\3\\641":I
    const v10, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v5, v10, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 643
    const/4 v9, 0x0

    invoke-static {v5, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v10

    .line 644
    .local v10, "compositeKeyHash\\3":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 645
    .local v9, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v18, v7

    .end local v7    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v18, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 647
    .local v7, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v19

    move-object/from16 v20, v4

    .end local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\2":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v14, 0x6

    and-int/lit16 v4, v4, 0x380

    move/from16 v21, v4

    const/4 v4, 0x6

    or-int/lit8 v21, v21, 0x6

    .line 646
    move-object/from16 v22, v19

    .local v21, "$changed\\4":I
    .local v22, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v19, 0x0

    .line 648
    .local v19, "$i$f$ReusableComposeNode\\4\\646":I
    move/from16 v23, v4

    const v4, -0x2942ffcf

    move-object/from16 v24, v8

    .end local v8    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v24, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const-string v8, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v5, v4, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 649
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 650
    :cond_9
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 651
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_a

    .line 652
    move-object/from16 v4, v22

    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 654
    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_a
    move-object/from16 v4, v22

    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 656
    :goto_4
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 657
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\656\\3":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v26, v4

    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v26, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v13, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 658
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v9, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 660
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 661
    .local v25, "$i$f$set-impl\\6\\660":I
    move-object/from16 v27, v8

    .local v27, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 662
    .local v28, "$i$a$-with-Updater$set$1\\7\\661\\6":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v29

    if-nez v29, :cond_c

    move-object/from16 v29, v5

    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v29, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v30, v9

    .end local v9    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v30, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v5, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_b

    goto :goto_5

    :cond_b
    move-object/from16 v9, v27

    goto :goto_6

    .end local v29    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v30    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v9    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_c
    move-object/from16 v29, v5

    move-object/from16 v30, v9

    .line 663
    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v9    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v29    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v30    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_5
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v9, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 664
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v8, v5, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 666
    :goto_6
    nop

    .line 661
    .end local v9    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-with-Updater$set$1\\7\\661\\6":I
    nop

    .line 666
    nop

    .line 667
    .end local v4    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v25    # "$i$f$set-impl\\6\\660":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 668
    nop

    .line 656
    .end local v8    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\656\\3":I
    nop

    .line 669
    shr-int/lit8 v4, v21, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\8":I
    move-object/from16 v5, v29

    .local v5, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 670
    .local v8, "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    const v9, -0x16ef5699

    move/from16 v22, v4

    .end local v4    # "$changed\\8":I
    .local v22, "$changed\\8":I
    const-string v4, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v5, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v11, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\9":I
    check-cast v4, Landroidx/compose/foundation/layout/ColumnScope;

    .local v4, "$this$Done_u24lambda_u2431\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v36, v5

    .local v36, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 215
    .local v25, "$i$a$-Column-SetupWizardKt$Done$1\\9\\670\\0":I
    move-object/from16 v27, v4

    .end local v4    # "$this$Done_u24lambda_u2431\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v27, "$this$Done_u24lambda_u2431\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v4, 0x428c1a9

    move-object/from16 v28, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v28, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v5, "C214@13423L11,214@13343L100,215@13452L30,216@13536L10,216@13491L97,217@13597L29,218@13720L10,219@13777L11,218@13635L201,220@13845L30,221@13901L18,221@13884L325,224@14239L19,224@14218L102:SetupWizard.kt#o13vsk"

    move-object/from16 v56, v7

    move-object/from16 v7, v36

    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v56, "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v7, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v4}, Landroidx/compose/material/icons/filled/CheckCircleKt;->getCheckCircle(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v31

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x48

    .local v5, "$this$dp\\10":I
    const/16 v32, 0x0

    .line 671
    .local v32, "$i$f$getDp\\10\\215":I
    move/from16 v57, v8

    .end local v8    # "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    .local v57, "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 215
    .end local v5    # "$this$dp\\10":I
    .end local v32    # "$i$f$getDp\\10\\215":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v33

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v34

    const/16 v37, 0x1b0

    const/16 v38, 0x0

    const/16 v32, 0x0

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v38}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 216
    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x18

    .local v5, "$this$dp\\11":I
    const/4 v8, 0x0

    .line 672
    .local v8, "$i$f$getDp\\11\\216":I
    move/from16 v31, v8

    .end local v8    # "$i$f$getDp\\11\\216":I
    .local v31, "$i$f$getDp\\11\\216":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 216
    .end local v5    # "$this$dp\\11":I
    .end local v31    # "$i$f$getDp\\11\\216":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    move/from16 v5, v23

    invoke-static {v4, v7, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 217
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " \u5df2\u5c31\u7eea"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v31

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v51

    sget-object v4, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v4

    invoke-static {v4}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v43

    const/16 v54, 0x0

    const v55, 0xfdfe

    const-wide/16 v33, 0x0

    const-wide/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const-wide/16 v44, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v53, 0x0

    move-object/from16 v52, v7

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v52, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v55}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 218
    .end local v52    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x8

    .local v5, "$this$dp\\12":I
    const/4 v8, 0x0

    .line 673
    .local v8, "$i$f$getDp\\12\\218":I
    move/from16 v31, v8

    .end local v8    # "$i$f$getDp\\12\\218":I
    .local v31, "$i$f$getDp\\12\\218":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 218
    .end local v5    # "$this$dp\\12":I
    .end local v31    # "$i$f$getDp\\12\\218":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v5, 0x6

    invoke-static {v4, v7, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 219
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v51

    .line 220
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v33

    sget-object v4, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v4

    .line 219
    nop

    .line 220
    invoke-static {v4}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v43

    .line 219
    const v55, 0xfdfa

    const-string v31, "\u9996\u6b21\u542f\u52a8\u65f6 iOS \u9700\u8981\u81ea\u884c\u521d\u59cb\u5316\uff0c\u8017\u65f6\u66f4\u957f\u3002"

    const/16 v53, 0x6

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v52    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v55}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 221
    .end local v52    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x24

    .local v5, "$this$dp\\13":I
    const/4 v8, 0x0

    .line 674
    .local v8, "$i$f$getDp\\13\\221":I
    move/from16 v31, v8

    .end local v8    # "$i$f$getDp\\13\\221":I
    .local v31, "$i$f$getDp\\13\\221":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 221
    .end local v5    # "$this$dp\\13":I
    .end local v31    # "$i$f$getDp\\13\\221":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v5, 0x6

    invoke-static {v4, v7, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    const v4, 0x4c5de2

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v8, v6, 0x380

    const/16 v4, 0x100

    if-ne v8, v4, :cond_d

    const/4 v4, 0x1

    goto :goto_7

    :cond_d
    const/4 v4, 0x0

    .line 222
    :goto_7
    nop

    .local v4, "invalid\\14":Z
    move-object v8, v7

    .local v8, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 675
    .local v31, "$i$f$cache\\14\\222":I
    move/from16 v32, v4

    .end local v4    # "invalid\\14":Z
    .local v32, "invalid\\14":Z
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\14":Ljava/lang/Object;
    const/16 v33, 0x0

    .line 676
    .local v33, "$i$a$-let-ComposerKt$cache$1\\15\\675\\14":I
    if-nez v32, :cond_f

    sget-object v34, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v36, v7

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v34 .. v34}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_e

    goto :goto_8

    .line 680
    :cond_e
    move-object/from16 v34, v4

    goto :goto_9

    .line 676
    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :cond_f
    move-object/from16 v36, v7

    .line 677
    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :goto_8
    const/4 v7, 0x0

    .line 222
    .local v7, "$i$a$-cache-SetupWizardKt$Done$1$1\\16\\677\\9":I
    move-object/from16 v34, v4

    .end local v4    # "it\\14":Ljava/lang/Object;
    .local v34, "it\\14":Ljava/lang/Object;
    new-instance v4, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda2;

    invoke-direct {v4, v2}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/functions/Function1;)V

    .line 677
    .end local v7    # "$i$a$-cache-SetupWizardKt$Done$1$1\\16\\677\\9":I
    nop

    .line 678
    .local v4, "value\\15":Ljava/lang/Object;
    invoke-interface {v8, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 679
    nop

    .line 676
    .end local v4    # "value\\15":Ljava/lang/Object;
    :goto_9
    nop

    .line 675
    .end local v33    # "$i$a$-let-ComposerKt$cache$1\\15\\675\\14":I
    .end local v34    # "it\\14":Ljava/lang/Object;
    nop

    .line 222
    .end local v8    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$f$cache\\14\\222":I
    .end local v32    # "invalid\\14":Z
    move-object/from16 v31, v4

    check-cast v31, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v36 .. v36}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x34

    .local v7, "$this$dp\\17":I
    const/4 v8, 0x0

    .line 681
    .local v8, "$i$f$getDp\\17\\222":I
    move/from16 v32, v8

    .end local v8    # "$i$f$getDp\\17\\222":I
    .local v32, "$i$f$getDp\\17\\222":I
    int-to-float v8, v7

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 222
    .end local v7    # "$this$dp\\17":I
    .end local v32    # "$i$f$getDp\\17\\222":I
    invoke-static {v4, v7}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const-string v7, "setup_launch"

    invoke-static {v4, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v32

    const/16 v4, 0x18

    .local v4, "$this$dp\\18":I
    const/4 v7, 0x0

    .line 681
    .local v7, "$i$f$getDp\\18\\222":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v37

    .line 222
    .end local v4    # "$this$dp\\18":I
    .end local v7    # "$i$f$getDp\\18\\222":I
    const/16 v4, 0x20

    .local v4, "$this$dp\\19":I
    const/4 v7, 0x0

    .line 681
    .local v7, "$i$f$getDp\\19\\222":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v39

    .line 222
    .end local v4    # "$this$dp\\19":I
    .end local v7    # "$i$f$getDp\\19\\222":I
    const/16 v41, 0xa

    const/16 v42, 0x0

    const/16 v38, 0x0

    const/16 v40, 0x0

    invoke-static/range {v37 .. v42}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4$default(FFFFILjava/lang/Object;)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v38

    sget-object v4, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v4}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$-1408057565$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v40

    const v42, 0x30c00030

    const/16 v43, 0x17c

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    move-object/from16 v7, v36

    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v39, 0x0

    move-object/from16 v41, v7

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v43}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    const v4, 0x4c5de2

    .end local v41    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v4, v6, 0x380

    const/16 v5, 0x100

    if-ne v4, v5, :cond_10

    const/4 v4, 0x1

    goto :goto_a

    :cond_10
    const/4 v4, 0x0

    .line 225
    :goto_a
    nop

    .local v4, "invalid\\20":Z
    move-object v5, v7

    .local v5, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 682
    .local v8, "$i$f$cache\\20\\225":I
    move/from16 v16, v4

    .end local v4    # "invalid\\20":Z
    .local v16, "invalid\\20":Z
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\20":Ljava/lang/Object;
    const/16 v23, 0x0

    .line 683
    .local v23, "$i$a$-let-ComposerKt$cache$1\\21\\682\\20":I
    if-nez v16, :cond_12

    sget-object v31, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v44, v6

    .end local v6    # "$dirty":I
    .local v44, "$dirty":I
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_11

    goto :goto_b

    .line 687
    :cond_11
    move-object/from16 v31, v4

    goto :goto_c

    .line 683
    .end local v44    # "$dirty":I
    .restart local v6    # "$dirty":I
    :cond_12
    move/from16 v44, v6

    .line 684
    .end local v6    # "$dirty":I
    .restart local v44    # "$dirty":I
    :goto_b
    const/4 v6, 0x0

    .line 225
    .local v6, "$i$a$-cache-SetupWizardKt$Done$1$2\\22\\684\\9":I
    move-object/from16 v31, v4

    .end local v4    # "it\\20":Ljava/lang/Object;
    .local v31, "it\\20":Ljava/lang/Object;
    new-instance v4, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda3;

    invoke-direct {v4, v2}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function1;)V

    .line 684
    .end local v6    # "$i$a$-cache-SetupWizardKt$Done$1$2\\22\\684\\9":I
    nop

    .line 685
    .local v4, "value\\21":Ljava/lang/Object;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 686
    nop

    .line 683
    .end local v4    # "value\\21":Ljava/lang/Object;
    :goto_c
    nop

    .line 682
    .end local v23    # "$i$a$-let-ComposerKt$cache$1\\21\\682\\20":I
    .end local v31    # "it\\20":Ljava/lang/Object;
    nop

    .line 225
    .end local v5    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\20\\225":I
    .end local v16    # "invalid\\20":Z
    move-object/from16 v31, v4

    check-cast v31, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v4

    check-cast v32, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\23":I
    const/4 v5, 0x0

    .line 688
    .local v5, "$i$f$getDp\\23\\225":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v34

    .line 225
    .end local v4    # "$this$dp\\23":I
    .end local v5    # "$i$f$getDp\\23\\225":I
    const/16 v37, 0xd

    const/16 v38, 0x0

    const/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    invoke-static/range {v32 .. v38}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v32

    sget-object v4, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v4}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$224805046$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v40

    const v42, 0x30000030

    const/16 v43, 0x1fc

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v39, 0x0

    move-object/from16 v41, v7

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v41    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v43}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v41    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    const v4, -0x737a1700

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "225@14355L19"

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 226
    move-object v4, v1

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_13

    const/16 v17, 0x1

    goto :goto_d

    :cond_13
    const/16 v17, 0x0

    :goto_d
    if-eqz v17, :cond_14

    shr-int/lit8 v4, v44, 0x3

    and-int/lit8 v4, v4, 0xe

    invoke-static {v1, v7, v4}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    :cond_14
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 215
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 227
    nop

    .line 670
    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v9    # "$changed\\9":I
    .end local v25    # "$i$a$-Column-SetupWizardKt$Done$1\\9\\670\\0":I
    .end local v27    # "$this$Done_u24lambda_u2431\\9":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 669
    .end local v22    # "$changed\\8":I
    .end local v28    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v57    # "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    nop

    .line 689
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 648
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 690
    nop

    .line 642
    .end local v19    # "$i$f$ReusableComposeNode\\4\\646":I
    .end local v21    # "$changed\\4":I
    .end local v26    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 691
    nop

    .line 639
    .end local v10    # "compositeKeyHash\\3":I
    .end local v14    # "$changed\\3":I
    .end local v15    # "$i$f$Layout\\3\\641":I
    .end local v30    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v56    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 692
    nop

    .end local v11    # "$changed\\2":I
    .end local v12    # "$i$f$Column\\2\\214":I
    .end local v13    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v20    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v24    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_15
    :goto_e
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v4

    if-eqz v4, :cond_16

    new-instance v5, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda4;

    invoke-direct {v5, v0, v1, v2, v3}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;I)V

    invoke-interface {v4, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 228
    :cond_16
    return-void
.end method

.method private static final Done$lambda$31$lambda$28$lambda$27(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .locals 1
    .param p0, "$onFinish"    # Lkotlin/jvm/functions/Function1;

    .line 222
    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Done$lambda$31$lambda$30$lambda$29(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .locals 1
    .param p0, "$onFinish"    # Lkotlin/jvm/functions/Function1;

    .line 225
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Done$lambda$32(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/SetupWizardKt;->Done(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final FileRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .locals 94
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "hint"    # Ljava/lang/String;
    .param p3, "picked"    # Lorg/lighttouch/android/PickedFile;
    .param p4, "onPick"    # Lkotlin/jvm/functions/Function0;
    .param p5, "tag"    # Ljava/lang/String;
    .param p6, "action"    # Z
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/PickedFile;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Z",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    .line 179
    move-object/from16 v4, p3

    move-object/from16 v6, p5

    move/from16 v8, p8

    const v0, -0x1eb9b0ad

    move-object/from16 v1, p7

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(FileRow)P(2,6,1,4,3,5)180@11045L11,179@10926L1067:SetupWizard.kt#o13vsk"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p8

    .local v1, "$dirty":I
    and-int/lit8 v2, p9, 0x1

    if-eqz v2, :cond_0

    or-int/lit8 v1, v1, 0x6

    move-object/from16 v11, p0

    goto :goto_1

    :cond_0
    and-int/lit8 v2, v8, 0x6

    if-nez v2, :cond_2

    move-object/from16 v11, p0

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v1, v2

    goto :goto_1

    :cond_2
    move-object/from16 v11, p0

    :goto_1
    and-int/lit8 v2, p9, 0x2

    if-eqz v2, :cond_3

    or-int/lit8 v1, v1, 0x30

    move-object/from16 v2, p1

    goto :goto_3

    :cond_3
    and-int/lit8 v2, v8, 0x30

    if-nez v2, :cond_5

    move-object/from16 v2, p1

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x20

    goto :goto_2

    :cond_4
    const/16 v3, 0x10

    :goto_2
    or-int/2addr v1, v3

    goto :goto_3

    :cond_5
    move-object/from16 v2, p1

    :goto_3
    and-int/lit8 v3, p9, 0x4

    if-eqz v3, :cond_6

    or-int/lit16 v1, v1, 0x180

    move-object/from16 v3, p2

    goto :goto_5

    :cond_6
    and-int/lit16 v3, v8, 0x180

    if-nez v3, :cond_8

    move-object/from16 v3, p2

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_7

    const/16 v5, 0x100

    goto :goto_4

    :cond_7
    const/16 v5, 0x80

    :goto_4
    or-int/2addr v1, v5

    goto :goto_5

    :cond_8
    move-object/from16 v3, p2

    :goto_5
    and-int/lit8 v5, p9, 0x8

    if-eqz v5, :cond_9

    or-int/lit16 v1, v1, 0xc00

    goto :goto_7

    :cond_9
    and-int/lit16 v5, v8, 0xc00

    if-nez v5, :cond_b

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_a

    const/16 v5, 0x800

    goto :goto_6

    :cond_a
    const/16 v5, 0x400

    :goto_6
    or-int/2addr v1, v5

    :cond_b
    :goto_7
    and-int/lit8 v5, p9, 0x10

    if-eqz v5, :cond_c

    or-int/lit16 v1, v1, 0x6000

    move-object/from16 v5, p4

    goto :goto_9

    :cond_c
    and-int/lit16 v5, v8, 0x6000

    if-nez v5, :cond_e

    move-object/from16 v5, p4

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_d

    const/16 v7, 0x4000

    goto :goto_8

    :cond_d
    const/16 v7, 0x2000

    :goto_8
    or-int/2addr v1, v7

    goto :goto_9

    :cond_e
    move-object/from16 v5, p4

    :goto_9
    and-int/lit8 v7, p9, 0x20

    const/high16 v9, 0x30000

    if-eqz v7, :cond_f

    or-int/2addr v1, v9

    goto :goto_b

    :cond_f
    and-int v7, v8, v9

    if-nez v7, :cond_11

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_10

    const/high16 v7, 0x20000

    goto :goto_a

    :cond_10
    const/high16 v7, 0x10000

    :goto_a
    or-int/2addr v1, v7

    :cond_11
    :goto_b
    and-int/lit8 v7, p9, 0x40

    const/high16 v9, 0x180000

    if-eqz v7, :cond_12

    or-int/2addr v1, v9

    move/from16 v9, p6

    goto :goto_d

    :cond_12
    and-int/2addr v9, v8

    if-nez v9, :cond_14

    move/from16 v9, p6

    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v12

    if-eqz v12, :cond_13

    const/high16 v12, 0x100000

    goto :goto_c

    :cond_13
    const/high16 v12, 0x80000

    :goto_c
    or-int/2addr v1, v12

    goto :goto_d

    :cond_14
    move/from16 v9, p6

    :goto_d
    const v12, 0x92493

    and-int/2addr v12, v1

    const v13, 0x92492

    if-ne v12, v13, :cond_16

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v12

    if-nez v12, :cond_15

    goto :goto_e

    .line 591
    :cond_15
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v40, v1

    move v7, v9

    goto/16 :goto_1c

    .line 179
    :cond_16
    :goto_e
    if-eqz v7, :cond_17

    const/4 v7, 0x0

    .end local p6    # "action":Z
    .local v7, "action":Z
    goto :goto_f

    .end local v7    # "action":Z
    .restart local p6    # "action":Z
    :cond_17
    move v7, v9

    .end local p6    # "action":Z
    .restart local v7    # "action":Z
    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v9

    if-eqz v9, :cond_18

    const/4 v9, -0x1

    const-string v12, "org.lighttouch.android.FileRow (SetupWizard.kt:178)"

    invoke-static {v0, v1, v9, v12}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 180
    :cond_18
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v9, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-static {v0, v9, v12, v13}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v14, 0x4

    .local v14, "$this$dp\\1":I
    const/4 v15, 0x0

    .line 497
    .local v15, "$i$f$getDp\\1\\180":I
    int-to-float v9, v14

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 180
    .end local v14    # "$this$dp\\1":I
    .end local v15    # "$i$f$getDp\\1\\180":I
    const/4 v14, 0x0

    invoke-static {v0, v14, v9, v12, v13}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v9, 0x10

    .local v9, "$this$dp\\2":I
    const/4 v12, 0x0

    .line 497
    .local v12, "$i$f$getDp\\2\\180":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 180
    .end local v9    # "$this$dp\\2":I
    .end local v12    # "$i$f$getDp\\2\\180":I
    invoke-static {v9}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v9}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 181
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v10, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v13

    const/16 v16, 0x2

    const/16 v17, 0x0

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    const/16 v17, 0x7

    const/16 v18, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    move-object/from16 v16, v5

    invoke-static/range {v12 .. v18}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v5, 0x10

    .local v5, "$this$dp\\3":I
    const/4 v9, 0x0

    .line 498
    .local v9, "$i$f$getDp\\3\\181":I
    int-to-float v12, v5

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 181
    .end local v5    # "$this$dp\\3":I
    .end local v9    # "$i$f$getDp\\3\\181":I
    invoke-static {v0, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {v0, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 182
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 180
    const/16 v9, 0x180

    .local v0, "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v5, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v9, "$changed\\4":I
    const/16 v36, 0x0

    .line 499
    .local v36, "$i$f$Row\\4\\180":I
    const v12, 0x2952b718

    const-string v13, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v10, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 500
    sget-object v12, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v12}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v12

    .line 504
    .local v12, "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v9, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v12, v5, v10, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v9, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 505
    move/from16 v37, v14

    .local v37, "$changed\\5":I
    const/16 v38, 0x0

    .line 506
    .local v38, "$i$f$Layout\\5\\505":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 507
    move-object/from16 p6, v12

    .end local v12    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local p6, "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/4 v12, 0x0

    invoke-static {v10, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v39

    .line 508
    .local v39, "compositeKeyHash\\5":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 509
    .local v12, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v40, v1

    .end local v1    # "$dirty":I
    .local v40, "$dirty":I
    invoke-static {v10, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 511
    .local v1, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v14, v37, 0x6

    and-int/lit16 v14, v14, 0x380

    move-object/from16 v41, v0

    .end local v0    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v41, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v0, 0x6

    or-int/2addr v14, v0

    .line 510
    move/from16 v42, v14

    .local v42, "$changed\\6":I
    move-object/from16 v14, v16

    .local v14, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v43, 0x0

    .line 512
    .local v43, "$i$f$ReusableComposeNode\\6\\510":I
    move/from16 v19, v0

    const v0, -0x2942ffcf

    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 513
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 514
    :cond_19
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 515
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_1a

    .line 516
    invoke-interface {v10, v14}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 518
    :cond_1a
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 520
    :goto_10
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 521
    .local v2, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\520\\5":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v18, v2

    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\520\\5":I
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\520\\5":I
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v13, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 522
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v12, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 524
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 525
    .local v16, "$i$f$set-impl\\8\\524":I
    move-object/from16 v20, v0

    .local v20, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 526
    .local v21, "$i$a$-with-Updater$set$1\\9\\525\\8":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_1c

    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1b

    goto :goto_11

    :cond_1b
    move-object/from16 v4, v20

    goto :goto_12

    .line 527
    :cond_1c
    :goto_11
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 528
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 530
    :goto_12
    nop

    .line 525
    .end local v4    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\9\\525\\8":I
    nop

    .line 530
    nop

    .line 531
    .end local v2    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\8\\524":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 532
    nop

    .line 520
    .end local v0    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\520\\5":I
    nop

    .line 533
    shr-int/lit8 v0, v42, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\10":I
    move-object v2, v10

    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 534
    .local v3, "$i$a$-Layout-RowKt$Row$1\\10\\533\\4":I
    const v4, -0x184f2606

    move/from16 v44, v0

    .end local v0    # "$changed\\10":I
    .local v44, "$changed\\10":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v9, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\11":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$FileRow_u24lambda_u2420\\11":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v16, v2

    .local v16, "$composer\\11":Landroidx/compose/runtime/Composer;
    move-object/from16 v20, v0

    .end local v0    # "$this$FileRow_u24lambda_u2420\\11":Landroidx/compose/foundation/layout/RowScope;
    .local v20, "$this$FileRow_u24lambda_u2420\\11":Landroidx/compose/foundation/layout/RowScope;
    const/4 v0, 0x0

    .line 183
    .local v0, "$i$a$-Row-SetupWizardKt$FileRow$1\\11\\534\\0":I
    move/from16 v45, v0

    .end local v0    # "$i$a$-Row-SetupWizardKt$FileRow$1\\11\\534\\0":I
    .local v45, "$i$a$-Row-SetupWizardKt$FileRow$1\\11\\534\\0":I
    const v0, -0x44575ec9

    move-object/from16 v46, v1

    .end local v1    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v46, "materialized\\5":Landroidx/compose/ui/Modifier;
    const-string v1, "C182@11198L148,183@11355L29,184@11393L368:SetupWizard.kt#o13vsk"

    move-object/from16 v47, v2

    .end local v16    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v47, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x18

    .local v1, "$this$dp\\12":I
    const/16 v16, 0x0

    .line 535
    .local v16, "$i$f$getDp\\12\\183":I
    move/from16 v48, v3

    .end local v3    # "$i$a$-Layout-RowKt$Row$1\\10\\533\\4":I
    .local v48, "$i$a$-Layout-RowKt$Row$1\\10\\533\\4":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 183
    .end local v1    # "$this$dp\\12":I
    .end local v16    # "$i$f$getDp\\12\\183":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    if-eqz p3, :cond_1d

    const v1, 0x60e470be

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "182@11278L11"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v21

    goto :goto_13

    :cond_1d
    const v1, 0x60e475a7

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "182@11317L11"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v21

    :goto_13
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v1, v40, 0xe

    or-int/lit16 v1, v1, 0x1b0

    const/16 v18, 0x0

    move-object v3, v12

    .end local v12    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v12, 0x0

    move/from16 v17, v1

    move-object/from16 v16, v2

    move-object/from16 p7, v13

    move-object v2, v14

    const v1, -0x4ee9b9da

    move-object v13, v0

    move-object v0, v15

    move-wide/from16 v14, v21

    .end local v13    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v14    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v16, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local p7, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v11 .. v18}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 184
    move-object/from16 v11, v16

    .end local v16    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\11":Landroidx/compose/runtime/Composer;
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/16 v13, 0x10

    .local v13, "$this$dp\\13":I
    const/4 v14, 0x0

    .line 536
    .local v14, "$i$f$getDp\\13\\184":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 184
    .end local v13    # "$this$dp\\13":I
    .end local v14    # "$i$f$getDp\\13\\184":I
    invoke-static {v12, v13}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v12

    move/from16 v13, v19

    invoke-static {v12, v11, v13}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 185
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v21, v12

    check-cast v21, Landroidx/compose/ui/Modifier;

    const/16 v24, 0x2

    const/16 v25, 0x0

    const/high16 v22, 0x3f800000    # 1.0f

    const/16 v23, 0x0

    invoke-static/range {v20 .. v25}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    move-object/from16 v49, v20

    .end local v20    # "$this$FileRow_u24lambda_u2420\\11":Landroidx/compose/foundation/layout/RowScope;
    .local v12, "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v49, "$this$FileRow_u24lambda_u2420\\11":Landroidx/compose/foundation/layout/RowScope;
    const/4 v13, 0x0

    .local v13, "$changed\\14":I
    move/from16 v50, v13

    .end local v13    # "$changed\\14":I
    .local v50, "$changed\\14":I
    const/16 v51, 0x0

    .line 537
    .local v51, "$i$f$Column\\14\\185":I
    const v13, -0x1cd0f17e

    const-string v14, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v11, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 538
    sget-object v13, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v13}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v13

    .line 539
    .local v13, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v14, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v14

    .line 542
    .local v14, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v15, v50, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v16, v50, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v15, v15, v16

    invoke-static {v13, v14, v11, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v50, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 543
    move/from16 v52, v16

    .local v52, "$changed\\15":I
    const/16 v53, 0x0

    .line 544
    .local v53, "$i$f$Layout\\15\\543":I
    invoke-static {v11, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 545
    const/4 v0, 0x0

    invoke-static {v11, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v1

    .line 546
    .local v1, "compositeKeyHash\\15":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 547
    .local v0, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v16, v13

    .end local v13    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v16, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v11, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 549
    .local v13, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move/from16 v54, v1

    .end local v1    # "compositeKeyHash\\15":I
    .local v54, "compositeKeyHash\\15":I
    shl-int/lit8 v1, v52, 0x6

    and-int/lit16 v1, v1, 0x380

    const/16 v19, 0x6

    or-int/lit8 v1, v1, 0x6

    .line 548
    move-object/from16 v55, v17

    .local v1, "$changed\\16":I
    .local v55, "factory\\16":Lkotlin/jvm/functions/Function0;
    const/16 v56, 0x0

    .line 550
    .local v56, "$i$f$ReusableComposeNode\\16\\548":I
    move/from16 v57, v1

    .end local v1    # "$changed\\16":I
    .local v57, "$changed\\16":I
    const v1, -0x2942ffcf

    move-object/from16 v58, v2

    .end local v2    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v58, "factory\\6":Lkotlin/jvm/functions/Function0;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v11, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 551
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_1e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 552
    :cond_1e
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 553
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_1f

    .line 554
    move-object/from16 v1, v55

    .end local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_14

    .line 556
    .end local v1    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :cond_1f
    move-object/from16 v1, v55

    .end local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 558
    :goto_14
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 559
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\558\\15":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v55, v1

    .end local v1    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v15, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 560
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 562
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 563
    .local v18, "$i$f$set-impl\\18\\562":I
    move-object/from16 v20, v2

    .local v20, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 564
    .local v21, "$i$a$-with-Updater$set$1\\19\\563\\18":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_21

    move-object/from16 v59, v0

    .end local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .local v59, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v60, v3

    .end local v3    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v60, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_20

    goto :goto_15

    :cond_20
    move-object/from16 v3, v20

    goto :goto_16

    .end local v59    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v60    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_21
    move-object/from16 v59, v0

    move-object/from16 v60, v3

    .line 565
    .end local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v59    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v60    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_15
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v3, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 566
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v2, v0, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 568
    :goto_16
    nop

    .line 563
    .end local v3    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\19\\563\\18":I
    nop

    .line 568
    nop

    .line 569
    .end local v1    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\18\\562":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v2, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 570
    nop

    .line 558
    .end local v2    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\558\\15":I
    nop

    .line 571
    shr-int/lit8 v0, v57, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\20":I
    move-object v1, v11

    .local v1, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 572
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\20\\571\\14":I
    const v3, -0x16ef5699

    move/from16 v61, v0

    .end local v0    # "$changed\\20":I
    .local v61, "$changed\\20":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v50, 0x6

    and-int/lit8 v3, v3, 0x70

    const/16 v19, 0x6

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\21":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$FileRow_u24lambda_u2420_u24lambda_u2419\\21":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v32, v1

    .local v32, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/16 v87, 0x0

    .line 186
    .local v87, "$i$a$-Column-SetupWizardKt$FileRow$1$1\\21\\572\\11":I
    move-object/from16 v88, v0

    .end local v0    # "$this$FileRow_u24lambda_u2420_u24lambda_u2419\\21":Landroidx/compose/foundation/layout/ColumnScope;
    .local v88, "$this$FileRow_u24lambda_u2420_u24lambda_u2419\\21":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x47d743ba

    move-object/from16 v89, v1

    .end local v1    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v89, "$composer\\20":Landroidx/compose/runtime/Composer;
    const-string v1, "C185@11469L10,185@11435L56,186@11553L10,186@11504L247:SetupWizard.kt#o13vsk"

    move/from16 v90, v2

    move-object/from16 v2, v32

    .end local v32    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v90, "$i$a$-Layout-ColumnKt$Column$1\\20\\571\\14":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v31

    shr-int/lit8 v0, v40, 0x3

    and-int/lit8 v33, v0, 0xe

    const/16 v34, 0x0

    const v35, 0xfffe

    move-object v0, v12

    .end local v12    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v0, "modifier\\14":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v17, v13

    move-object v1, v14

    .end local v13    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v14    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .local v1, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .local v17, "materialized\\15":Landroidx/compose/ui/Modifier;
    const-wide/16 v13, 0x0

    move-object/from16 v19, v15

    move-object/from16 v18, v16

    .end local v15    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v16    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v18, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v19, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    const-wide/16 v15, 0x0

    move-object/from16 v20, v17

    .end local v17    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v20, "materialized\\15":Landroidx/compose/ui/Modifier;
    const/16 v17, 0x0

    move-object/from16 v21, v18

    .end local v18    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v21, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v18, 0x0

    move-object/from16 v22, v19

    .end local v19    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v22, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v19, 0x0

    move-object/from16 v24, v20

    move-object/from16 v23, v21

    .end local v20    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v21    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v23, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v24, "materialized\\15":Landroidx/compose/ui/Modifier;
    const-wide/16 v20, 0x0

    move-object/from16 v25, v22

    .end local v22    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v25, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v22, 0x0

    move-object/from16 v26, v23

    .end local v23    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v26, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v23, 0x0

    move-object/from16 v28, v24

    move-object/from16 v27, v25

    .end local v24    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v25    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v27, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v28, "materialized\\15":Landroidx/compose/ui/Modifier;
    const-wide/16 v24, 0x0

    move-object/from16 v29, v26

    .end local v26    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v29, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v26, 0x0

    move-object/from16 v30, v27

    .end local v27    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v30, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v27, 0x0

    move-object/from16 v32, v28

    .end local v28    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v32, "materialized\\15":Landroidx/compose/ui/Modifier;
    const/16 v28, 0x0

    move-object/from16 v62, v29

    .end local v29    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v62, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v29, 0x0

    move-object/from16 v63, v30

    .end local v30    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v63, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v30, 0x0

    move-object/from16 v91, v1

    move-object/from16 v93, v32

    move-object/from16 v1, v62

    move-object/from16 v92, v63

    move-object/from16 v32, v2

    move-object v2, v11

    move-object/from16 v11, p1

    .end local v11    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v62    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v63    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v1, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v32, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v91, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .local v92, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v93, "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static/range {v11 .. v35}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 187
    move-object/from16 v11, v32

    .end local v32    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\21":Landroidx/compose/runtime/Composer;
    if-eqz p3, :cond_23

    invoke-virtual/range {p3 .. p3}, Lorg/lighttouch/android/PickedFile;->getName()Ljava/lang/String;

    move-result-object v12

    if-nez v12, :cond_22

    goto :goto_17

    :cond_22
    move-object/from16 v62, v12

    goto :goto_18

    :cond_23
    :goto_17
    move-object/from16 v62, p2

    :goto_18
    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v82

    sget-object v12, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v77

    .line 188
    if-eqz p3, :cond_24

    const v12, 0x54e60876

    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "187@11681L11"

    invoke-static {v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v12

    goto :goto_19

    :cond_24
    const v12, 0x54e60d9d

    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "187@11722L11"

    invoke-static {v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v12

    :goto_19
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v64, v12

    .line 187
    nop

    .line 188
    nop

    .line 187
    const/16 v85, 0xc30

    const v86, 0xd7fa

    const/16 v63, 0x0

    const-wide/16 v66, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const-wide/16 v71, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const-wide/16 v75, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x1

    const/16 v80, 0x0

    const/16 v81, 0x0

    const/16 v84, 0x0

    move-object/from16 v83, v11

    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v83, "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v62 .. v86}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 186
    .end local v83    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 189
    nop

    .line 572
    .end local v3    # "$changed\\21":I
    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v87    # "$i$a$-Column-SetupWizardKt$FileRow$1$1\\21\\572\\11":I
    .end local v88    # "$this$FileRow_u24lambda_u2420_u24lambda_u2419\\21":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v89 .. v89}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 571
    .end local v61    # "$changed\\20":I
    .end local v89    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v90    # "$i$a$-Layout-ColumnKt$Column$1\\20\\571\\14":I
    nop

    .line 573
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 550
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 574
    nop

    .line 544
    .end local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v56    # "$i$f$ReusableComposeNode\\16\\548":I
    .end local v57    # "$changed\\16":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 575
    nop

    .line 537
    .end local v52    # "$changed\\15":I
    .end local v53    # "$i$f$Layout\\15\\543":I
    .end local v54    # "compositeKeyHash\\15":I
    .end local v59    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v93    # "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 576
    nop

    .line 190
    .end local v0    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .end local v1    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v50    # "$changed\\14":I
    .end local v51    # "$i$f$Column\\14\\185":I
    .end local v91    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v92    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    if-eqz p3, :cond_25

    const v0, 0x60e4af89

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "189@11852L11,189@11790L82"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v0}, Landroidx/compose/material/icons/filled/CheckCircleKt;->getCheckCircle(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v20

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v23

    const/16 v26, 0x30

    const/16 v27, 0x4

    const-string v21, "\u5df2\u9009\u62e9"

    const/16 v22, 0x0

    move-object/from16 v25, v2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v27}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .end local v25    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_1b

    .line 191
    :cond_25
    if-nez v7, :cond_26

    const v0, 0x60e4bd2f

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "190@11953L11,190@11899L88"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x16

    .local v1, "$this$dp\\22":I
    const/4 v3, 0x0

    .line 577
    .local v3, "$i$f$getDp\\22\\191":I
    int-to-float v11, v1

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 191
    .end local v1    # "$this$dp\\22":I
    .end local v3    # "$i$f$getDp\\22\\191":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-wide/high16 v11, 0x3ff8000000000000L    # 1.5

    .local v11, "$this$dp\\23":D
    const/4 v1, 0x0

    .line 587
    .local v1, "$i$f$getDp\\23\\191":I
    double-to-float v3, v11

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 191
    .end local v1    # "$i$f$getDp\\23\\191":I
    .end local v11    # "$this$dp\\23":D
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v2, v11}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOutline-0d7_KjU()J

    move-result-wide v11

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v1, v11, v12, v3}, Landroidx/compose/foundation/BorderKt;->border-xT4_qwU(Landroidx/compose/ui/Modifier;FJLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    goto :goto_1a

    :cond_26
    const v0, -0x444bccf5

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_1a
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 183
    :goto_1b
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 192
    nop

    .line 534
    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v4    # "$changed\\11":I
    .end local v45    # "$i$a$-Row-SetupWizardKt$FileRow$1\\11\\534\\0":I
    .end local v49    # "$this$FileRow_u24lambda_u2420\\11":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 533
    .end local v44    # "$changed\\10":I
    .end local v47    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v48    # "$i$a$-Layout-RowKt$Row$1\\10\\533\\4":I
    nop

    .line 588
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 512
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 589
    nop

    .line 506
    .end local v42    # "$changed\\6":I
    .end local v43    # "$i$f$ReusableComposeNode\\6\\510":I
    .end local v58    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 590
    nop

    .line 499
    .end local v37    # "$changed\\5":I
    .end local v38    # "$i$f$Layout\\5\\505":I
    .end local v39    # "compositeKeyHash\\5":I
    .end local v46    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v60    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 591
    nop

    .end local v5    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .end local v9    # "$changed\\4":I
    .end local v36    # "$i$f$Row\\4\\180":I
    .end local v41    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local p6    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local p7    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_27

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_27
    :goto_1c
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_28

    new-instance v0, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda5;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v9, p9

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda5;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZII)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 193
    :cond_28
    return-void
.end method

.method private static final FileRow$lambda$21(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object/from16 v6, p5

    move/from16 v7, p6

    move/from16 v10, p8

    move-object/from16 v8, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/SetupWizardKt;->FileRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Files(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 71
    .param p0, "state"    # Lorg/lighttouch/android/SetupState;
    .param p1, "onPickFolder"    # Lkotlin/jvm/functions/Function0;
    .param p2, "onPickSystem"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onPickRom"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onCreate"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p6, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p7, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/SetupState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 144
    move-object/from16 v1, p0

    move/from16 v7, p7

    const v0, -0x51540429

    move-object/from16 v2, p6

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .end local p6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(Files)P(5,1,3,2)144@7987L21,144@7942L2717:SetupWizard.kt#o13vsk"

    invoke-static {v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p7

    .local v2, "$dirty":I
    and-int/lit8 v3, v7, 0x6

    const/4 v5, 0x2

    if-nez v3, :cond_1

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    move v3, v5

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v7, 0x30

    if-nez v3, :cond_3

    move-object/from16 v13, p1

    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    goto :goto_2

    :cond_3
    move-object/from16 v13, p1

    :goto_2
    and-int/lit16 v3, v7, 0x180

    if-nez v3, :cond_5

    move-object/from16 v3, p2

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    const/16 v6, 0x100

    goto :goto_3

    :cond_4
    const/16 v6, 0x80

    :goto_3
    or-int/2addr v2, v6

    goto :goto_4

    :cond_5
    move-object/from16 v3, p2

    :goto_4
    and-int/lit16 v6, v7, 0xc00

    if-nez v6, :cond_7

    move-object/from16 v6, p3

    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_6

    const/16 v9, 0x800

    goto :goto_5

    :cond_6
    const/16 v9, 0x400

    :goto_5
    or-int/2addr v2, v9

    goto :goto_6

    :cond_7
    move-object/from16 v6, p3

    :goto_6
    and-int/lit16 v9, v7, 0x6000

    if-nez v9, :cond_9

    move-object/from16 v9, p4

    invoke-interface {v8, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_8

    const/16 v10, 0x4000

    goto :goto_7

    :cond_8
    const/16 v10, 0x2000

    :goto_7
    or-int/2addr v2, v10

    goto :goto_8

    :cond_9
    move-object/from16 v9, p4

    :goto_8
    const/high16 v10, 0x30000

    and-int/2addr v10, v7

    if-nez v10, :cond_b

    move-object/from16 v10, p5

    invoke-interface {v8, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_a

    const/high16 v11, 0x20000

    goto :goto_9

    :cond_a
    const/high16 v11, 0x10000

    :goto_9
    or-int/2addr v2, v11

    goto :goto_a

    :cond_b
    move-object/from16 v10, p5

    :goto_a
    const v11, 0x12493

    and-int/2addr v11, v2

    const v12, 0x12492

    if-ne v11, v12, :cond_d

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v11

    if-nez v11, :cond_c

    goto :goto_b

    .line 496
    :cond_c
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v28, v2

    goto/16 :goto_17

    .line 144
    :cond_d
    :goto_b
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v11

    if-eqz v11, :cond_e

    const/4 v11, -0x1

    const-string v12, "org.lighttouch.android.Files (SetupWizard.kt:143)"

    invoke-static {v0, v2, v11, v12}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 145
    :cond_e
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/4 v14, 0x0

    invoke-static {v0, v11, v12, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    const/4 v0, 0x0

    invoke-static {v0, v8, v0, v12}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v16

    const/16 v20, 0xe

    const/16 v21, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v15 .. v21}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    const/16 v12, 0x18

    .local v12, "$this$dp\\1":I
    const/16 v16, 0x0

    .line 439
    .local v16, "$i$f$getDp\\1\\145":I
    int-to-float v4, v12

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 145
    .end local v12    # "$this$dp\\1":I
    .end local v16    # "$i$f$getDp\\1\\145":I
    invoke-static {v15, v4, v11, v5, v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .local v4, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/16 v24, 0x0

    .local v24, "$changed\\2":I
    const/16 v25, 0x0

    .line 440
    .local v25, "$i$f$Column\\2\\145":I
    const v12, -0x1cd0f17e

    const-string v15, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v8, v12, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 441
    sget-object v12, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v12}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v12

    .line 442
    .local v12, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v15, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v15

    .line 445
    .local v15, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v24, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v17, v24, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v11, v16, v17

    invoke-static {v12, v15, v8, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v24, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 446
    move/from16 v26, v16

    .local v26, "$changed\\3":I
    const/16 v27, 0x0

    .line 447
    .local v27, "$i$f$Layout\\3\\446":I
    const v14, -0x4ee9b9da

    const-string v5, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v8, v14, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 448
    invoke-static {v8, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v5

    .line 449
    .local v5, "compositeKeyHash\\3":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 450
    .local v14, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 452
    .local v0, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move/from16 v28, v2

    .end local v2    # "$dirty":I
    .local v28, "$dirty":I
    shl-int/lit8 v2, v26, 0x6

    and-int/lit16 v2, v2, 0x380

    move-object/from16 v21, v12

    .end local v12    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v21, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v12, 0x6

    or-int/2addr v2, v12

    .line 451
    nop

    .local v2, "$changed\\4":I
    move-object/from16 v29, v17

    .local v29, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v30, 0x0

    .line 453
    .local v30, "$i$f$ReusableComposeNode\\4\\451":I
    move/from16 v17, v12

    const v12, -0x2942ffcf

    move/from16 v31, v2

    .end local v2    # "$changed\\4":I
    .local v31, "$changed\\4":I
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v8, v12, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 454
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 455
    :cond_f
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 456
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_10

    .line 457
    move-object/from16 v2, v29

    .end local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 459
    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v2, v29

    .end local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 461
    :goto_c
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .local v12, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 462
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\461\\3":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v32, v2

    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v32, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v12, v11, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 463
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v12, v14, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 465
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 466
    .local v29, "$i$f$set-impl\\6\\465":I
    move-object/from16 v33, v12

    .local v33, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 467
    .local v34, "$i$a$-with-Updater$set$1\\7\\466\\6":I
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v35

    if-nez v35, :cond_12

    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v35, v4

    .end local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v35, "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_11

    goto :goto_d

    :cond_11
    move-object/from16 v4, v33

    goto :goto_e

    .end local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .restart local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    :cond_12
    move-object/from16 v35, v4

    .line 468
    .end local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .restart local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    :goto_d
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v33

    .end local v33    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 469
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v12, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 471
    :goto_e
    nop

    .line 466
    .end local v4    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-with-Updater$set$1\\7\\466\\6":I
    nop

    .line 471
    nop

    .line 472
    .end local v2    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\6\\465":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v12, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 473
    nop

    .line 461
    .end local v12    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\461\\3":I
    nop

    .line 474
    shr-int/lit8 v2, v31, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\8":I
    move-object v3, v8

    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 475
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\8\\474\\2":I
    const v12, -0x16ef5699

    move-object/from16 v29, v0

    .end local v0    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v29, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v12, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v12, v24, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v33, v12, 0x6

    .local v33, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$Files_u24lambda_u2417\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v12, v3

    .local v12, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 146
    .local v34, "$i$a$-Column-SetupWizardKt$Files$1\\9\\475\\0":I
    move/from16 v64, v2

    .end local v2    # "$changed\\8":I
    .local v64, "$changed\\8":I
    const v2, -0x4c1636aa

    move-object/from16 v65, v3

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v65, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v3, "C145@8049L30,146@8135L10,146@8088L73,147@8170L29,149@8405L10,149@8450L11,148@8208L271,150@8488L30,151@8527L146,152@8682L103,161@9565L30,162@9634L43,162@9604L254,165@10039L30,166@10078L289,168@10376L55,169@10440L174,172@10623L30:SetupWizard.kt#o13vsk"

    invoke-static {v12, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x18

    .local v3, "$this$dp\\10":I
    const/16 v22, 0x0

    .line 476
    .local v22, "$i$f$getDp\\10\\146":I
    move/from16 v66, v4

    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\8\\474\\2":I
    .local v66, "$i$a$-Layout-ColumnKt$Column$1\\8\\474\\2":I
    int-to-float v4, v3

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 146
    .end local v3    # "$this$dp\\10":I
    .end local v22    # "$i$f$getDp\\10\\146":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    move/from16 v3, v17

    invoke-static {v2, v12, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 147
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v12, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getHeadlineMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v56

    const/16 v59, 0x0

    const v60, 0xfffe

    const-string v36, "\u6dfb\u52a0\u8bbe\u5907\u6587\u4ef6"

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v58, 0x6

    move-object/from16 v57, v12

    .end local v12    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v57, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v60}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 148
    move-object/from16 v3, v57

    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\11":I
    const/4 v12, 0x0

    .line 477
    .local v12, "$i$f$getDp\\11\\148":I
    move/from16 v67, v5

    .end local v5    # "compositeKeyHash\\3":I
    .local v67, "compositeKeyHash\\3":I
    int-to-float v5, v4

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 148
    .end local v4    # "$this$dp\\11":I
    .end local v12    # "$i$f$getDp\\11\\148":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v4, 0x6

    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 150
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v56

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v38

    .line 149
    nop

    .line 150
    nop

    .line 149
    const-string v36, "\u7528\u4e8e\u5728\u522b\u5904\uff08\u4f8b\u5982\u7535\u8111\u4e0a\uff09\u51c6\u5907\u597d\u7684\u8bbe\u5907\uff1aiOS \u7cfb\u7edf\uff08.itbase\uff09\uff0c\u4ee5\u53ca iPod touch 1G/2G \u548c\u521d\u4ee3 iPhone \u6240\u9700\u7684\u5f15\u5bfc\u6587\u4ef6\u3002"

    const v60, 0xfffa

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v60}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 151
    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x14

    .local v4, "$this$dp\\12":I
    const/4 v5, 0x0

    .line 478
    .local v5, "$i$f$getDp\\12\\151":I
    int-to-float v12, v4

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 151
    .end local v4    # "$this$dp\\12":I
    .end local v5    # "$i$f$getDp\\12\\151":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v4, 0x6

    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 152
    sget-object v2, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtIcons;->getFolder()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v2

    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getScanned()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_13

    const-string v5, "LightTouch \u4f1a\u5728\u5176\u4e2d\u81ea\u52a8\u67e5\u627e\u6240\u9700\u6587\u4ef6"

    :cond_13
    shl-int/lit8 v12, v28, 0x9

    const v22, 0xe000

    and-int v12, v12, v22

    const v17, 0x1b0c30

    or-int v17, v12, v17

    const/4 v12, 0x0

    const/16 v18, 0x0

    const-string v10, "\u9009\u62e9\u6587\u4ef6\u5939"

    move/from16 v36, v12

    const/4 v12, 0x0

    move-object/from16 v37, v14

    .end local v14    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v37, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const-string v14, "setup_folder"

    move-object/from16 v38, v15

    .end local v15    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v38, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/4 v15, 0x1

    move-object/from16 p6, v11

    move-object v11, v5

    move-object/from16 v5, p6

    move-object v9, v2

    move-object/from16 v16, v3

    move v2, v4

    move-object/from16 p6, v21

    move/from16 v4, v36

    move-object/from16 v68, v37

    move-object/from16 v69, v38

    const/4 v3, 0x0

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v11    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v21    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v37    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v38    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v5, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v16, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v68, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v69, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local p6, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v9 .. v18}, Lorg/lighttouch/android/SetupWizardKt;->FileRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 153
    move-object/from16 v57, v16

    .end local v16    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v9, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v9}, Lorg/lighttouch/android/LtIcons;->getLayers()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v9

    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getSystem()Lorg/lighttouch/android/PickedFile;

    move-result-object v12

    shl-int/lit8 v10, v28, 0x6

    and-int v10, v10, v22

    const v11, 0x301b0

    or-int v17, v10, v11

    const/16 v18, 0x40

    const-string v10, "iOS \u7cfb\u7edf"

    const-string v11, "\u5fc5\u9700 \u00b7 .itbase"

    const-string v14, "setup_system"

    const/4 v15, 0x0

    move-object/from16 v13, p2

    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v16    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v9 .. v18}, Lorg/lighttouch/android/SetupWizardKt;->FileRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 156
    move-object/from16 v9, v16

    .end local v16    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getSystem()Lorg/lighttouch/android/PickedFile;

    move-result-object v10

    if-eqz v10, :cond_14

    invoke-virtual {v10}, Lorg/lighttouch/android/PickedFile;->getBoard()Ljava/lang/String;

    move-result-object v10

    if-nez v10, :cond_15

    :cond_14
    const-string v10, ""

    .line 157
    .local v10, "board\\9":Ljava/lang/String;
    :cond_15
    sget-object v11, Lorg/lighttouch/android/Bootrom;->Companion:Lorg/lighttouch/android/Bootrom$Companion;

    invoke-virtual {v11, v10}, Lorg/lighttouch/android/Bootrom$Companion;->forBoard(Ljava/lang/String;)Lorg/lighttouch/android/Bootrom;

    move-result-object v70

    .local v70, "rom\\9":Lorg/lighttouch/android/Bootrom;
    const v11, 0x47deb1f8

    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "157@9068L211"

    invoke-static {v9, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 158
    move-object v11, v10

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-nez v11, :cond_16

    const/4 v12, 0x1

    goto :goto_f

    :cond_16
    const/4 v12, 0x0

    :goto_f
    if-nez v12, :cond_18

    if-eqz v70, :cond_17

    goto :goto_10

    :cond_17
    move-object v3, v10

    goto :goto_11

    :cond_18
    :goto_10
    sget-object v11, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v11}, Lorg/lighttouch/android/LtIcons;->getChip()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v11

    .line 159
    if-eqz v70, :cond_19

    .line 479
    move-object/from16 v12, v70

    .local v12, "it\\13":Lorg/lighttouch/android/Bootrom;
    const/4 v13, 0x0

    .line 159
    .local v13, "$i$a$-let-SetupWizardKt$Files$1$1\\13\\159\\9":I
    invoke-virtual {v12}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u5fc5\u9700 \u00b7 "

    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v14, " boot ROM"

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .end local v12    # "it\\13":Lorg/lighttouch/android/Bootrom;
    .end local v13    # "$i$a$-let-SetupWizardKt$Files$1$1\\13\\159\\9":I
    if-nez v3, :cond_1a

    :cond_19
    const-string v3, "iPod touch 1G/2G \u4e0e\u521d\u4ee3 iPhone \u5fc5\u9700 \u00b7 bootrom.bin"

    :cond_1a
    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getRom()Lorg/lighttouch/android/PickedFile;

    move-result-object v12

    shl-int/lit8 v13, v28, 0x3

    and-int v13, v13, v22

    const v14, 0x30030

    or-int v17, v13, v14

    .line 158
    move-object v13, v10

    .end local v10    # "board\\9":Ljava/lang/String;
    .local v13, "board\\9":Ljava/lang/String;
    const-string v10, "\u5f15\u5bfc\u6587\u4ef6"

    const-string v14, "setup_rom"

    const/4 v15, 0x0

    const/16 v18, 0x40

    move-object/from16 v16, v9

    move-object v9, v11

    move-object v11, v3

    move-object v3, v13

    move-object v13, v6

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v13    # "board\\9":Ljava/lang/String;
    .local v3, "board\\9":Ljava/lang/String;
    .restart local v16    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v9 .. v18}, Lorg/lighttouch/android/SetupWizardKt;->FileRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/PickedFile;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v9, v16

    .end local v16    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :goto_11
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v6, 0x47ded20d

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "160@9468L10,159@9350L206"

    invoke-static {v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 160
    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getSystem()Lorg/lighttouch/android/PickedFile;

    move-result-object v6

    if-eqz v6, :cond_1b

    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getRom()Lorg/lighttouch/android/PickedFile;

    move-result-object v6

    if-nez v6, :cond_1b

    if-eqz v70, :cond_1b

    .line 161
    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v9, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v56

    sget-object v6, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v6}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v38

    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v10, v6

    check-cast v10, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x4

    .local v6, "$this$dp\\14":I
    const/4 v11, 0x0

    .line 480
    .local v11, "$i$f$getDp\\14\\161":I
    int-to-float v12, v6

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 161
    .end local v6    # "$this$dp\\14":I
    .end local v11    # "$i$f$getDp\\14\\161":I
    const/16 v15, 0xd

    const/16 v16, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v10 .. v16}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    .line 160
    nop

    .line 161
    nop

    .line 160
    const-string v36, "\u7f3a\u5c11\u5f15\u5bfc\u6587\u4ef6\u8be5\u8bbe\u5907\u65e0\u6cd5\u542f\u52a8\uff1b\u4e5f\u53ef\u4ee5\u7a0d\u540e\u518d\u6dfb\u52a0\u3002"

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v58, 0x1b6

    const/16 v59, 0x0

    const v60, 0xfff8

    move-object/from16 v57, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v60}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :cond_1b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 162
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x10

    .local v10, "$this$dp\\15":I
    const/4 v11, 0x0

    .line 481
    .local v11, "$i$f$getDp\\15\\162":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 162
    .end local v10    # "$this$dp\\15":I
    .end local v11    # "$i$f$getDp\\15\\162":I
    invoke-static {v6, v10}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v6

    invoke-static {v6, v9, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 163
    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getName()Ljava/lang/String;

    move-result-object v36

    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v6, v4, v11, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const-string v10, "setup_name"

    invoke-static {v6, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v38

    const v6, 0x4c5de2

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v6, v28, 0xe

    const/4 v10, 0x4

    if-ne v6, v10, :cond_1c

    move v12, v11

    goto :goto_12

    :cond_1c
    const/4 v12, 0x0

    .local v12, "invalid\\16":Z
    :goto_12
    move-object v6, v9

    .local v6, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 482
    .local v10, "$i$f$cache\\16\\163":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\16":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 483
    .local v14, "$i$a$-let-ComposerKt$cache$1\\17\\482\\16":I
    if-nez v12, :cond_1e

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_1d

    goto :goto_13

    .line 487
    :cond_1d
    move-object v11, v13

    goto :goto_14

    .line 484
    :cond_1e
    :goto_13
    const/4 v15, 0x0

    .line 163
    .local v15, "$i$a$-cache-SetupWizardKt$Files$1$2\\18\\484\\9":I
    new-instance v11, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda13;

    invoke-direct {v11, v1}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda13;-><init>(Lorg/lighttouch/android/SetupState;)V

    .line 484
    .end local v15    # "$i$a$-cache-SetupWizardKt$Files$1$2\\18\\484\\9":I
    nop

    .line 485
    .local v11, "value\\17":Ljava/lang/Object;
    invoke-interface {v6, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 486
    nop

    .line 483
    .end local v11    # "value\\17":Ljava/lang/Object;
    :goto_14
    nop

    .line 482
    .end local v13    # "it\\16":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\17\\482\\16":I
    nop

    .line 163
    .end local v6    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\16\\163":I
    .end local v12    # "invalid\\16":Z
    move-object/from16 v37, v11

    check-cast v37, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v6, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v6}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$660915015$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v42

    sget-object v6, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v6}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$-1344575864$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v43

    const/16 v62, 0x0

    const v63, 0x7dff38

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x1

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const v60, 0xd80180

    const/high16 v61, 0xc00000

    move-object/from16 v59, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v59, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v63}, Landroidx/compose/material3/OutlinedTextFieldKt;->OutlinedTextField(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/text/TextStyle;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLandroidx/compose/ui/text/input/VisualTransformation;Landroidx/compose/foundation/text/KeyboardOptions;Landroidx/compose/foundation/text/KeyboardActions;ZIILandroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/TextFieldColors;Landroidx/compose/runtime/Composer;IIII)V

    .end local v59    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    const v6, 0x47df1a04

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "164@9968L10,164@10012L11,164@9897L133"

    invoke-static {v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 165
    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getError()Ljava/lang/String;

    move-result-object v6

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-lez v6, :cond_1f

    const/4 v12, 0x1

    goto :goto_15

    :cond_1f
    const/4 v12, 0x0

    :goto_15
    if-eqz v12, :cond_20

    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getError()Ljava/lang/String;

    move-result-object v36

    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v10, v6

    check-cast v10, Landroidx/compose/ui/Modifier;

    const/16 v6, 0xc

    .local v6, "$this$dp\\19":I
    const/4 v11, 0x0

    .line 488
    .local v11, "$i$f$getDp\\19\\165":I
    int-to-float v12, v6

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 165
    .end local v6    # "$this$dp\\19":I
    .end local v11    # "$i$f$getDp\\19\\165":I
    const/16 v15, 0xd

    const/16 v16, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v10 .. v16}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v9, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v56

    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v9, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v38

    const/16 v59, 0x0

    const v60, 0xfff8

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v58, 0x30

    move-object/from16 v57, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v60}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :cond_20
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 166
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x14

    .local v10, "$this$dp\\20":I
    const/4 v11, 0x0

    .line 489
    .local v11, "$i$f$getDp\\20\\166":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 166
    .end local v10    # "$this$dp\\20":I
    .end local v11    # "$i$f$getDp\\20\\166":I
    invoke-static {v6, v10}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v6

    invoke-static {v6, v9, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 167
    invoke-virtual {v1}, Lorg/lighttouch/android/SetupState;->getSystem()Lorg/lighttouch/android/PickedFile;

    move-result-object v6

    if-eqz v6, :cond_21

    const/4 v12, 0x1

    goto :goto_16

    :cond_21
    const/4 v12, 0x0

    :goto_16
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    invoke-interface {v0, v6, v10}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v10, 0x34

    .local v10, "$this$dp\\21":I
    const/4 v11, 0x0

    .line 490
    .local v11, "$i$f$getDp\\21\\167":I
    int-to-float v13, v10

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 167
    .end local v10    # "$this$dp\\21":I
    .end local v11    # "$i$f$getDp\\21\\167":I
    invoke-static {v6, v10}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const-string v10, "setup_create"

    invoke-static {v6, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 168
    const/16 v6, 0x20

    .local v6, "$this$dp\\22":I
    const/4 v10, 0x0

    .line 491
    .local v10, "$i$f$getDp\\22\\168":I
    int-to-float v13, v6

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 168
    .end local v6    # "$this$dp\\22":I
    .end local v10    # "$i$f$getDp\\22\\168":I
    const/4 v10, 0x2

    const/4 v13, 0x0

    invoke-static {v6, v4, v10, v13}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA$default(FFILjava/lang/Object;)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v17

    .line 167
    nop

    .line 168
    sget-object v4, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v4}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$-1921235151$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v19

    shr-int/lit8 v4, v28, 0xc

    and-int/lit8 v4, v4, 0xe

    const/high16 v6, 0x30c00000

    or-int v21, v4, v6

    .line 167
    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v18, 0x0

    const/16 v22, 0x178

    move-object/from16 v10, p4

    move-object/from16 v20, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v22}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 169
    .end local v20    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    invoke-interface {v0, v4, v6}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v6, 0x0

    invoke-static {v4, v9, v6, v6}, Lorg/lighttouch/android/SetupWizardKt;->GuideLink(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    .line 170
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    invoke-interface {v0, v4, v6}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const-string v6, "setup_prepare"

    invoke-static {v4, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    sget-object v4, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v4}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$1085604484$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v20

    shr-int/lit8 v4, v28, 0xf

    and-int/lit8 v4, v4, 0xe

    const/high16 v6, 0x30000000

    or-int v22, v4, v6

    const/16 v23, 0x1fc

    const/4 v13, 0x0

    const/16 v17, 0x0

    const/16 v19, 0x0

    move-object/from16 v11, p5

    move-object/from16 v21, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v23}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 173
    .end local v21    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v6, 0x10

    .local v6, "$this$dp\\23":I
    const/4 v10, 0x0

    .line 492
    .local v10, "$i$f$getDp\\23\\173":I
    int-to-float v11, v6

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 173
    .end local v6    # "$this$dp\\23":I
    .end local v10    # "$i$f$getDp\\23\\173":I
    invoke-static {v4, v6}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    invoke-static {v4, v9, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 146
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 174
    .end local v3    # "board\\9":Ljava/lang/String;
    .end local v70    # "rom\\9":Lorg/lighttouch/android/Bootrom;
    nop

    .line 475
    .end local v0    # "$this$Files_u24lambda_u2417\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v33    # "$changed\\9":I
    .end local v34    # "$i$a$-Column-SetupWizardKt$Files$1\\9\\475\\0":I
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 474
    .end local v64    # "$changed\\8":I
    .end local v65    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v66    # "$i$a$-Layout-ColumnKt$Column$1\\8\\474\\2":I
    nop

    .line 493
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 453
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 494
    nop

    .line 447
    .end local v30    # "$i$f$ReusableComposeNode\\4\\451":I
    .end local v31    # "$changed\\4":I
    .end local v32    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 495
    nop

    .line 440
    .end local v26    # "$changed\\3":I
    .end local v27    # "$i$f$Layout\\3\\446":I
    .end local v29    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v67    # "compositeKeyHash\\3":I
    .end local v68    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 496
    nop

    .end local v5    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "$changed\\2":I
    .end local v25    # "$i$f$Column\\2\\145":I
    .end local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v69    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local p6    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_22
    :goto_17
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_23

    new-instance v0, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda14;

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    invoke-direct/range {v0 .. v7}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda14;-><init>(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 175
    :cond_23
    return-void
.end method

.method private static final Files$lambda$17$lambda$16$lambda$15(Lorg/lighttouch/android/SetupState;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$state"    # Lorg/lighttouch/android/SetupState;
    .param p1, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    invoke-static {p1}, Lorg/lighttouch/android/DevicesKt;->fitsDeviceName(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Lorg/lighttouch/android/SetupState;->setName(Ljava/lang/String;)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Files$lambda$18(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 9

    or-int/lit8 v0, p6, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v8

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move-object/from16 v7, p7

    invoke-static/range {v1 .. v8}, Lorg/lighttouch/android/SetupWizardKt;->Files(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final GuideLink(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V
    .locals 17
    .param p0, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 134
    move/from16 v0, p2

    move/from16 v1, p3

    const v2, 0x57f3899f

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(GuideLink)134@7502L7,135@7535L142,135@7514L231:SetupWizard.kt#o13vsk"

    invoke-static {v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x1

    const/4 v5, 0x2

    if-eqz v4, :cond_0

    or-int/lit8 v3, v3, 0x6

    move-object/from16 v6, p0

    goto :goto_1

    :cond_0
    and-int/lit8 v6, v0, 0x6

    if-nez v6, :cond_2

    move-object/from16 v6, p0

    invoke-interface {v13, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    move v7, v5

    :goto_0
    or-int/2addr v3, v7

    goto :goto_1

    :cond_2
    move-object/from16 v6, p0

    :goto_1
    and-int/lit8 v7, v3, 0x3

    if-ne v7, v5, :cond_4

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_3

    goto :goto_2

    .line 136
    :cond_3
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v16, v3

    move-object v4, v6

    goto/16 :goto_6

    .line 134
    :cond_4
    :goto_2
    if-eqz v4, :cond_5

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_3

    .end local v4    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p0    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_5
    move-object v4, v6

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v4    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.GuideLink (SetupWizard.kt:133)"

    invoke-static {v2, v3, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 135
    :cond_6
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    .local v2, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v5, 0x0

    .local v5, "$changed\\1":I
    const/4 v6, 0x0

    .line 432
    .local v6, "$i$f$getCurrent\\1\\135":I
    const v7, 0x789c5f52

    const-string v8, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v13, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 135
    .end local v2    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v5    # "$changed\\1":I
    .end local v6    # "$i$f$getCurrent\\1\\135":I
    move-object v2, v7

    check-cast v2, Landroid/content/Context;

    .local v2, "context":Landroid/content/Context;
    const v5, 0x4c5de2

    invoke-interface {v13, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v13, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    .line 136
    nop

    .local v5, "invalid\\2":Z
    move-object v6, v13

    .local v6, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 433
    .local v7, "$i$f$cache\\2\\136":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\2":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 434
    .local v9, "$i$a$-let-ComposerKt$cache$1\\3\\433\\2":I
    if-nez v5, :cond_8

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v8, v10, :cond_7

    goto :goto_4

    .line 438
    :cond_7
    move-object v11, v8

    goto :goto_5

    .line 435
    :cond_8
    :goto_4
    const/4 v10, 0x0

    .line 136
    .local v10, "$i$a$-cache-SetupWizardKt$GuideLink$1\\4\\435\\0":I
    new-instance v11, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda6;

    invoke-direct {v11, v2}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda6;-><init>(Landroid/content/Context;)V

    .line 435
    .end local v10    # "$i$a$-cache-SetupWizardKt$GuideLink$1\\4\\435\\0":I
    nop

    .line 436
    .local v11, "value\\3":Ljava/lang/Object;
    invoke-interface {v6, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 437
    nop

    .line 434
    .end local v11    # "value\\3":Ljava/lang/Object;
    :goto_5
    nop

    .line 433
    .end local v8    # "it\\2":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\3\\433\\2":I
    nop

    .line 136
    .end local v5    # "invalid\\2":Z
    .end local v6    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\2\\136":I
    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 137
    sget-object v5, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v5}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$-1825595262$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v12

    shl-int/lit8 v5, v3, 0x3

    and-int/lit8 v5, v5, 0x70

    const/high16 v6, 0x30000000

    or-int v14, v5, v6

    .line 136
    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move v15, v3

    move-object v3, v11

    .end local v3    # "$dirty":I
    .local v15, "$dirty":I
    const/4 v11, 0x0

    move/from16 v16, v15

    .end local v15    # "$dirty":I
    .local v16, "$dirty":I
    const/16 v15, 0x1fc

    invoke-static/range {v3 .. v15}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "context":Landroid/content/Context;
    :cond_9
    :goto_6
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_a

    new-instance v3, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda7;

    invoke-direct {v3, v4, v0, v1}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda7;-><init>(Landroidx/compose/ui/Modifier;II)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 140
    :cond_a
    return-void
.end method

.method private static final GuideLink$lambda$12$lambda$11(Landroid/content/Context;)Lkotlin/Unit;
    .locals 3
    .param p0, "$context"    # Landroid/content/Context;

    .line 136
    new-instance v0, Landroid/content/Intent;

    .line 137
    const-string v1, "https://github.com/blake-lucas/LightTouch/blob/main/docs/ASSETS.md"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 136
    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 137
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final GuideLink$lambda$13(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p3, v0, p2}, Lorg/lighttouch/android/SetupWizardKt;->GuideLink(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Need(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 68
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "detail"    # Ljava/lang/String;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    .line 122
    move-object/from16 v0, p0

    move-object/from16 v8, p1

    move-object/from16 v9, p2

    move/from16 v10, p4

    const v1, -0x6a94887e

    move-object/from16 v2, p3

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(Need)P(1,2)122@6962L438:SetupWizard.kt#o13vsk"

    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p4

    .local v2, "$dirty":I
    and-int/lit8 v3, v10, 0x6

    if-nez v3, :cond_1

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v10, 0x30

    if-nez v3, :cond_3

    invoke-interface {v11, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    and-int/lit16 v3, v10, 0x180

    if-nez v3, :cond_5

    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x100

    goto :goto_2

    :cond_4
    const/16 v3, 0x80

    :goto_2
    or-int/2addr v2, v3

    :cond_5
    move v12, v2

    .end local v2    # "$dirty":I
    .local v12, "$dirty":I
    and-int/lit16 v2, v12, 0x93

    const/16 v3, 0x92

    if-ne v2, v3, :cond_7

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_6

    goto :goto_3

    .line 431
    :cond_6
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v0, v9

    move-object/from16 v58, v11

    move/from16 v59, v12

    goto/16 :goto_a

    .line 122
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.Need (SetupWizard.kt:121)"

    invoke-static {v1, v12, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 123
    :cond_8
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x6

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 348
    .local v3, "$i$f$getDp\\1\\123":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 123
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\123":I
    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1, v5, v2, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .local v13, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v14

    .local v14, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v1, 0x186

    .local v1, "$changed\\2":I
    move/from16 v25, v1

    .end local v1    # "$changed\\2":I
    .local v25, "$changed\\2":I
    const/16 v26, 0x0

    .line 349
    .local v26, "$i$f$Row\\2\\123":I
    const v1, 0x2952b718

    const-string v2, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v11, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 350
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v1}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v15

    .line 354
    .local v15, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v1, v25, 0x3

    and-int/lit8 v1, v1, 0xe

    shr-int/lit8 v2, v25, 0x3

    and-int/lit8 v2, v2, 0x70

    or-int/2addr v1, v2

    invoke-static {v15, v14, v11, v1}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v1

    .local v1, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v2, v25, 0x3

    and-int/lit8 v2, v2, 0x70

    .line 355
    move/from16 v27, v2

    .local v27, "$changed\\3":I
    const/16 v28, 0x0

    .line 356
    .local v28, "$i$f$Layout\\3\\355":I
    const v2, -0x4ee9b9da

    const-string v3, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v11, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 357
    const/4 v4, 0x0

    invoke-static {v11, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 358
    .local v29, "compositeKeyHash\\3":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 359
    .local v5, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v11, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 361
    .local v6, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v7

    shl-int/lit8 v2, v27, 0x6

    and-int/lit16 v2, v2, 0x380

    move-object/from16 v16, v7

    const/4 v7, 0x6

    or-int/2addr v2, v7

    .line 360
    move-object/from16 v30, v16

    .local v30, "factory\\4":Lkotlin/jvm/functions/Function0;
    move/from16 v31, v2

    .local v31, "$changed\\4":I
    const/16 v32, 0x0

    .line 362
    .local v32, "$i$f$ReusableComposeNode\\4\\360":I
    const v2, -0x2942ffcf

    move/from16 v16, v7

    const-string v7, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v11, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 363
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 364
    :cond_9
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 365
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_a

    .line 366
    move-object/from16 v2, v30

    .end local v30    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4

    .line 368
    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_a
    move-object/from16 v2, v30

    .end local v30    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 370
    :goto_4
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 371
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\370\\3":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 372
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v5, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 374
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 375
    .local v20, "$i$f$set-impl\\6\\374":I
    move-object/from16 v21, v4

    .local v21, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 376
    .local v22, "$i$a$-with-Updater$set$1\\7\\375\\6":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_c

    move-object/from16 v23, v1

    .end local v1    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v23, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v24, v2

    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v24, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    goto :goto_5

    :cond_b
    move-object/from16 v2, v21

    goto :goto_6

    .end local v23    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v23, v1

    move-object/from16 v24, v2

    .line 377
    .end local v1    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v23    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :goto_5
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 378
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v4, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 380
    :goto_6
    nop

    .line 375
    .end local v2    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\7\\375\\6":I
    nop

    .line 380
    nop

    .line 381
    .end local v0    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v20    # "$i$f$set-impl\\6\\374":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 382
    nop

    .line 370
    .end local v4    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\370\\3":I
    nop

    .line 383
    shr-int/lit8 v0, v31, 0x6

    and-int/lit8 v30, v0, 0xe

    .local v30, "$changed\\8":I
    move-object v0, v11

    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 384
    .local v33, "$i$a$-Layout-RowKt$Row$1\\8\\383\\2":I
    const v1, -0x184f2606

    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v2, v25, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v34, v2, 0x6

    .local v34, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    move-object v2, v5

    .end local v5    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v1, "$this$Need_u24lambda_u249\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v2, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move-object v5, v0

    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    move-object/from16 v35, v1

    .end local v1    # "$this$Need_u24lambda_u249\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v35, "$this$Need_u24lambda_u249\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v36, 0x0

    .line 124
    .local v36, "$i$a$-Row-SetupWizardKt$Need$1\\9\\384\\0":I
    const v1, -0x5b9d670a

    const-string v4, "C123@7119L11,123@7059L80,124@7148L29,125@7186L208:SetupWizard.kt#o13vsk"

    invoke-static {v5, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x16

    .local v4, "$this$dp\\10":I
    const/16 v19, 0x0

    .line 385
    .local v19, "$i$f$getDp\\10\\124":I
    move-object/from16 v20, v0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\8":Landroidx/compose/runtime/Composer;
    int-to-float v0, v4

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 124
    .end local v4    # "$this$dp\\10":I
    .end local v19    # "$i$f$getDp\\10\\124":I
    invoke-static {v1, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v21

    and-int/lit8 v1, v12, 0xe

    or-int/lit16 v1, v1, 0x1b0

    move-object v4, v7

    const/4 v7, 0x0

    move-object/from16 v19, v6

    move v6, v1

    .end local v6    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v19, "materialized\\3":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x0

    move-object/from16 v38, v2

    move-object v9, v3

    move-object v8, v4

    move/from16 v10, v16

    move-object/from16 v39, v19

    move-object/from16 v41, v20

    move-wide/from16 v3, v21

    move-object/from16 v37, v23

    move-object/from16 v40, v24

    const/16 v18, 0x0

    move-object v2, v0

    move-object/from16 v0, p0

    .end local v2    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v19    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v20    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v23    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v37, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v38, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v39, "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v40, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v41, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v7}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 125
    move-object v0, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xe

    .local v2, "$this$dp\\11":I
    const/4 v3, 0x0

    .line 386
    .local v3, "$i$f$getDp\\11\\125":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 125
    .end local v2    # "$this$dp\\11":I
    .end local v3    # "$i$f$getDp\\11\\125":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v0, v10}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 126
    move/from16 v42, v18

    .local v42, "$changed\\12":I
    const/16 v43, 0x0

    .line 387
    .local v43, "$i$f$Column\\12\\126":I
    const v1, -0x1cd0f17e

    const-string v2, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 388
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    .line 389
    .local v1, "modifier\\12":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v2

    .line 390
    .local v2, "verticalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v3

    .line 393
    .local v3, "horizontalAlignment\\12":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v4, v42, 0x3

    and-int/lit8 v4, v4, 0xe

    shr-int/lit8 v5, v42, 0x3

    and-int/lit8 v5, v5, 0x70

    or-int/2addr v4, v5

    invoke-static {v2, v3, v0, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v5, v42, 0x3

    and-int/lit8 v5, v5, 0x70

    .line 394
    move/from16 v44, v5

    .local v44, "$changed\\13":I
    const/16 v45, 0x0

    .line 395
    .local v45, "$i$f$Layout\\13\\394":I
    const v5, -0x4ee9b9da

    invoke-static {v0, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 396
    move/from16 v5, v18

    invoke-static {v0, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v46

    .line 397
    .local v46, "compositeKeyHash\\13":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 398
    .local v5, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v0, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 400
    .local v6, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v7

    shl-int/lit8 v9, v44, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/2addr v9, v10

    .line 399
    nop

    .local v7, "factory\\14":Lkotlin/jvm/functions/Function0;
    move/from16 v47, v9

    .local v47, "$changed\\14":I
    const/16 v48, 0x0

    .line 401
    .local v48, "$i$f$ReusableComposeNode\\14\\399":I
    const v9, -0x2942ffcf

    invoke-static {v0, v9, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 402
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 403
    :cond_d
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 404
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_e

    .line 405
    invoke-interface {v0, v7}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_7

    .line 407
    :cond_e
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 409
    :goto_7
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 410
    .local v9, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\409\\13":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v17, v10

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v8, v4, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 411
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v8, v5, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 413
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 414
    .local v16, "$i$f$set-impl\\16\\413":I
    move-object/from16 p3, v8

    .local p3, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 415
    .local v18, "$i$a$-with-Updater$set$1\\17\\414\\16":I
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v19

    if-nez v19, :cond_10

    move-object/from16 v19, v0

    .end local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v20, v1

    .end local v1    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\12":Landroidx/compose/ui/Modifier;
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    goto :goto_8

    :cond_f
    move-object/from16 v1, p3

    goto :goto_9

    .end local v19    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v20    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .restart local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v1    # "modifier\\12":Landroidx/compose/ui/Modifier;
    :cond_10
    move-object/from16 v19, v0

    move-object/from16 v20, v1

    .line 416
    .end local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v1    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .restart local v19    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v20    # "modifier\\12":Landroidx/compose/ui/Modifier;
    :goto_8
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, p3

    .end local p3    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v1, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 417
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v8, v0, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 419
    :goto_9
    nop

    .line 414
    .end local v1    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-with-Updater$set$1\\17\\414\\16":I
    nop

    .line 419
    nop

    .line 420
    .end local v10    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\16\\413":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v8, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 421
    nop

    .line 409
    .end local v8    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\409\\13":I
    nop

    .line 422
    shr-int/lit8 v0, v47, 0x6

    and-int/lit8 v49, v0, 0xe

    .local v49, "$changed\\18":I
    move-object/from16 v0, v19

    .local v0, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v50, 0x0

    .line 423
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\18\\422\\12":I
    const v1, -0x16ef5699

    const-string v8, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v0, v1, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v8, v42, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v51, v8, 0x6

    .local v51, "$changed\\19":I
    move-object/from16 v52, v1

    check-cast v52, Landroidx/compose/foundation/layout/ColumnScope;

    .local v52, "$this$Need_u24lambda_u249_u24lambda_u248\\19":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v1, v0

    .local v1, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 127
    .local v53, "$i$a$-Column-SetupWizardKt$Need$1$1\\19\\423\\9":I
    const v8, 0x5956004a

    const-string v9, "C126@7241L10,126@7207L56,127@7311L10,127@7355L11,127@7276L108:SetupWizard.kt#o13vsk"

    invoke-static {v1, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v1, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v8

    shr-int/lit8 v9, v12, 0x3

    and-int/lit8 v22, v9, 0xe

    const/16 v23, 0x0

    const v24, 0xfffe

    move-object/from16 v21, v1

    .end local v1    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    move-object v9, v2

    move-object v10, v3

    .end local v2    # "verticalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v3    # "horizontalAlignment\\12":Landroidx/compose/ui/Alignment$Horizontal;
    .local v9, "verticalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v10, "horizontalAlignment\\12":Landroidx/compose/ui/Alignment$Horizontal;
    const-wide/16 v2, 0x0

    move-object/from16 v16, v4

    move-object/from16 v17, v5

    .end local v4    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v5    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v16, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v17, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    const-wide/16 v4, 0x0

    move-object/from16 v18, v6

    .end local v6    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\13":Landroidx/compose/ui/Modifier;
    const/4 v6, 0x0

    move-object/from16 v54, v7

    .end local v7    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v54, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/4 v7, 0x0

    move-object/from16 v55, v20

    move-object/from16 v20, v8

    .end local v20    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v55, "modifier\\12":Landroidx/compose/ui/Modifier;
    const/4 v8, 0x0

    move-object/from16 v56, v9

    move-object/from16 v57, v10

    .end local v9    # "verticalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v10    # "horizontalAlignment\\12":Landroidx/compose/ui/Alignment$Horizontal;
    .local v56, "verticalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v57, "horizontalAlignment\\12":Landroidx/compose/ui/Alignment$Horizontal;
    const-wide/16 v9, 0x0

    move-object/from16 v58, v11

    .end local v11    # "$composer":Landroidx/compose/runtime/Composer;
    .local v58, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    move/from16 v59, v12

    .end local v12    # "$dirty":I
    .local v59, "$dirty":I
    const/4 v12, 0x0

    move-object/from16 v60, v13

    move-object/from16 v61, v14

    .end local v13    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v14    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v60, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v61, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    const-wide/16 v13, 0x0

    move-object/from16 v62, v15

    .end local v15    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v62, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/4 v15, 0x0

    move-object/from16 v63, v16

    .end local v16    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v63, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v16, 0x0

    move-object/from16 v64, v17

    .end local v17    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v64, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v17, 0x0

    move-object/from16 v65, v18

    .end local v18    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v65, "materialized\\13":Landroidx/compose/ui/Modifier;
    const/16 v18, 0x0

    move-object/from16 v66, v19

    .end local v19    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    move-object/from16 v67, v0

    move-object/from16 v0, p1

    .end local v0    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v67, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 128
    move-object/from16 v0, v21

    .end local v21    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\19":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v2

    shr-int/lit8 v1, v59, 0x6

    and-int/lit8 v22, v1, 0xe

    const v24, 0xfffa

    const/4 v1, 0x0

    move-object/from16 v0, p2

    .end local v0    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 127
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 129
    nop

    .line 423
    .end local v21    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v51    # "$changed\\19":I
    .end local v52    # "$this$Need_u24lambda_u249_u24lambda_u248\\19":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v53    # "$i$a$-Column-SetupWizardKt$Need$1$1\\19\\423\\9":I
    invoke-static/range {v67 .. v67}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 422
    .end local v49    # "$changed\\18":I
    .end local v50    # "$i$a$-Layout-ColumnKt$Column$1\\18\\422\\12":I
    .end local v67    # "$composer\\18":Landroidx/compose/runtime/Composer;
    nop

    .line 424
    invoke-interface/range {v66 .. v66}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 401
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 425
    nop

    .line 395
    .end local v47    # "$changed\\14":I
    .end local v48    # "$i$f$ReusableComposeNode\\14\\399":I
    .end local v54    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 426
    nop

    .line 387
    .end local v44    # "$changed\\13":I
    .end local v45    # "$i$f$Layout\\13\\394":I
    .end local v46    # "compositeKeyHash\\13":I
    .end local v64    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v65    # "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 427
    nop

    .line 124
    .end local v42    # "$changed\\12":I
    .end local v43    # "$i$f$Column\\12\\126":I
    .end local v55    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v56    # "verticalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v57    # "horizontalAlignment\\12":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v63    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 130
    nop

    .line 384
    .end local v34    # "$changed\\9":I
    .end local v35    # "$this$Need_u24lambda_u249\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v36    # "$i$a$-Row-SetupWizardKt$Need$1\\9\\384\\0":I
    .end local v66    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v41 .. v41}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 383
    .end local v30    # "$changed\\8":I
    .end local v33    # "$i$a$-Layout-RowKt$Row$1\\8\\383\\2":I
    .end local v41    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 428
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 362
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 429
    nop

    .line 356
    .end local v31    # "$changed\\4":I
    .end local v32    # "$i$f$ReusableComposeNode\\4\\360":I
    .end local v40    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 430
    nop

    .line 349
    .end local v27    # "$changed\\3":I
    .end local v28    # "$i$f$Layout\\3\\355":I
    .end local v29    # "compositeKeyHash\\3":I
    .end local v38    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v39    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 431
    nop

    .end local v25    # "$changed\\2":I
    .end local v26    # "$i$f$Row\\2\\123":I
    .end local v37    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v60    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v61    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v62    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_11
    :goto_a
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_12

    new-instance v2, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda1;

    move-object/from16 v3, p0

    move-object/from16 v8, p1

    move/from16 v10, p4

    invoke-direct {v2, v3, v8, v0, v10}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_b

    :cond_12
    move-object/from16 v3, p0

    move-object/from16 v8, p1

    move/from16 v10, p4

    .line 131
    :goto_b
    return-void
.end method

.method private static final Need$lambda$10(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/SetupWizardKt;->Need(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final SetupWizard(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 25
    .param p0, "state"    # Lorg/lighttouch/android/SetupState;
    .param p1, "canCancel"    # Z
    .param p2, "onPickFolder"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onPickSystem"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onPickRom"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onCreate"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p7, "onFinish"    # Lkotlin/jvm/functions/Function1;
    .param p8, "onCancel"    # Lkotlin/jvm/functions/Function0;
    .param p9, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p10, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/SetupState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/Boolean;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v6, p2

    move-object/from16 v7, p3

    move-object/from16 v5, p4

    move-object/from16 v9, p5

    move-object/from16 v0, p6

    move-object/from16 v8, p7

    move-object/from16 v4, p8

    move/from16 v10, p10

    const-string v3, "state"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onPickFolder"

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onPickSystem"

    invoke-static {v7, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onPickRom"

    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onCreate"

    invoke-static {v9, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onPrepare"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onFinish"

    invoke-static {v8, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onCancel"

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    const v3, -0x14e8f9a5

    move-object/from16 v11, p9

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v12, "C(SetupWizard)P(8!1,4,6,5,2,7,3)67@3404L382,67@3392L394,75@3832L31,75@3904L11,75@3928L1065,75@3791L1202:SetupWizard.kt#o13vsk"

    invoke-static {v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v12, p10

    .local v12, "$dirty":I
    and-int/lit8 v13, v10, 0x6

    const/4 v14, 0x4

    if-nez v13, :cond_1

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_0

    move v13, v14

    goto :goto_0

    :cond_0
    const/4 v13, 0x2

    :goto_0
    or-int/2addr v12, v13

    :cond_1
    and-int/lit8 v13, v10, 0x30

    if-nez v13, :cond_3

    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v13

    if-eqz v13, :cond_2

    const/16 v13, 0x20

    goto :goto_1

    :cond_2
    const/16 v13, 0x10

    :goto_1
    or-int/2addr v12, v13

    :cond_3
    and-int/lit16 v13, v10, 0x180

    if-nez v13, :cond_5

    invoke-interface {v11, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_4

    const/16 v13, 0x100

    goto :goto_2

    :cond_4
    const/16 v13, 0x80

    :goto_2
    or-int/2addr v12, v13

    :cond_5
    and-int/lit16 v13, v10, 0xc00

    if-nez v13, :cond_7

    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_6

    const/16 v13, 0x800

    goto :goto_3

    :cond_6
    const/16 v13, 0x400

    :goto_3
    or-int/2addr v12, v13

    :cond_7
    and-int/lit16 v13, v10, 0x6000

    if-nez v13, :cond_9

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_8

    const/16 v13, 0x4000

    goto :goto_4

    :cond_8
    const/16 v13, 0x2000

    :goto_4
    or-int/2addr v12, v13

    :cond_9
    const/high16 v13, 0x30000

    and-int/2addr v13, v10

    if-nez v13, :cond_b

    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_a

    const/high16 v13, 0x20000

    goto :goto_5

    :cond_a
    const/high16 v13, 0x10000

    :goto_5
    or-int/2addr v12, v13

    :cond_b
    const/high16 v13, 0x180000

    and-int/2addr v13, v10

    if-nez v13, :cond_d

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_c

    const/high16 v13, 0x100000

    goto :goto_6

    :cond_c
    const/high16 v13, 0x80000

    :goto_6
    or-int/2addr v12, v13

    :cond_d
    const/high16 v13, 0xc00000

    and-int/2addr v13, v10

    if-nez v13, :cond_f

    invoke-interface {v11, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_e

    const/high16 v13, 0x800000

    goto :goto_7

    :cond_e
    const/high16 v13, 0x400000

    :goto_7
    or-int/2addr v12, v13

    :cond_f
    const/high16 v13, 0x6000000

    and-int/2addr v13, v10

    if-nez v13, :cond_11

    invoke-interface {v11, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_10

    const/high16 v13, 0x4000000

    goto :goto_8

    :cond_10
    const/high16 v13, 0x2000000

    :goto_8
    or-int/2addr v12, v13

    :cond_11
    const v13, 0x2492493

    and-int/2addr v13, v12

    const v15, 0x2492492

    if-ne v13, v15, :cond_13

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v13

    if-nez v13, :cond_12

    goto :goto_9

    .line 76
    :cond_12
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v21, v11

    move/from16 v24, v12

    goto/16 :goto_11

    .line 67
    :cond_13
    :goto_9
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v13

    if-eqz v13, :cond_14

    const/4 v13, -0x1

    const-string v15, "org.lighttouch.android.SetupWizard (SetupWizard.kt:66)"

    invoke-static {v3, v12, v13, v15}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_14
    const v3, -0x48fade91

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v13, v12, 0xe

    if-ne v13, v14, :cond_15

    const/4 v13, 0x1

    goto :goto_a

    :cond_15
    const/4 v13, 0x0

    :goto_a
    and-int/lit8 v14, v12, 0x70

    const/16 v15, 0x20

    if-ne v14, v15, :cond_16

    const/4 v14, 0x1

    goto :goto_b

    :cond_16
    const/4 v14, 0x0

    :goto_b
    or-int/2addr v13, v14

    const/high16 v14, 0xe000000

    and-int/2addr v14, v12

    const/high16 v15, 0x4000000

    if-ne v14, v15, :cond_17

    const/4 v14, 0x1

    goto :goto_c

    :cond_17
    const/4 v14, 0x0

    :goto_c
    or-int/2addr v13, v14

    const/high16 v14, 0x1c00000

    and-int/2addr v14, v12

    const/high16 v15, 0x800000

    if-ne v14, v15, :cond_18

    const/4 v14, 0x1

    goto :goto_d

    :cond_18
    const/4 v14, 0x0

    :goto_d
    or-int/2addr v13, v14

    .line 68
    nop

    .local v13, "invalid\\1":Z
    move-object v14, v11

    .local v14, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 248
    .local v15, "$i$f$cache\\1\\68":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\1":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 249
    .local v16, "$i$a$-let-ComposerKt$cache$1\\2\\248\\1":I
    if-nez v13, :cond_1a

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v0, v5, :cond_19

    goto :goto_e

    .line 253
    :cond_19
    move-object/from16 p9, v0

    goto :goto_f

    .line 250
    :cond_1a
    :goto_e
    const/4 v5, 0x0

    .line 68
    .local v5, "$i$a$-cache-SetupWizardKt$SetupWizard$1\\3\\250\\0":I
    move-object/from16 p9, v0

    .end local v0    # "it\\1":Ljava/lang/Object;
    .local p9, "it\\1":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda8;

    invoke-direct {v0, v1, v2, v4, v8}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V

    .line 250
    .end local v5    # "$i$a$-cache-SetupWizardKt$SetupWizard$1\\3\\250\\0":I
    nop

    .line 251
    .local v0, "value\\2":Ljava/lang/Object;
    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 252
    nop

    .line 249
    .end local v0    # "value\\2":Ljava/lang/Object;
    :goto_f
    nop

    .line 248
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\2\\248\\1":I
    .end local p9    # "it\\1":Ljava/lang/Object;
    nop

    .line 68
    .end local v13    # "invalid\\1":Z
    .end local v14    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\1\\68":I
    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v5, 0x0

    const/4 v13, 0x1

    invoke-static {v5, v0, v11, v5, v13}, Landroidx/activity/compose/BackHandlerKt;->BackHandler(ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 76
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v14, 0x0

    invoke-static {v0, v5, v13, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v5, 0x6e3c21fe

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\4":Z
    move-object v5, v11

    .local v5, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 254
    .local v13, "$i$f$cache\\4\\76":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 255
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\254\\4":I
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v15, v14, :cond_1b

    .line 256
    const/4 v14, 0x0

    .local v14, "$i$a$-cache-SetupWizardKt$SetupWizard$2\\6\\256\\0":I
    new-instance v17, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda9;

    invoke-direct/range {v17 .. v17}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda9;-><init>()V

    .end local v14    # "$i$a$-cache-SetupWizardKt$SetupWizard$2\\6\\256\\0":I
    move-object/from16 v14, v17

    .line 257
    .local v14, "value\\5":Ljava/lang/Object;
    invoke-interface {v5, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 258
    nop

    .end local v14    # "value\\5":Ljava/lang/Object;
    goto :goto_10

    .line 259
    :cond_1b
    move-object v14, v15

    .line 255
    :goto_10
    nop

    .line 254
    .end local v15    # "it\\4":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\5\\254\\4":I
    nop

    .line 76
    .end local v3    # "invalid\\4":Z
    .end local v5    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$cache\\4\\76":I
    check-cast v14, Lkotlin/jvm/functions/Function1;

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v13, 0x1

    invoke-static {v0, v5, v14, v13, v3}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v3, "setup"

    invoke-static {v0, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v11, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v15

    new-instance v0, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3;

    move v3, v2

    move-object v2, v1

    move v1, v3

    move-object/from16 v5, p6

    move-object v3, v8

    move-object/from16 v8, p4

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/SetupWizardKt$SetupWizard$3;-><init>(ZLorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    const/16 v1, 0x36

    const v2, -0x289fc4a0

    invoke-static {v2, v13, v0, v11, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v20, v0

    check-cast v20, Lkotlin/jvm/functions/Function2;

    const/high16 v22, 0xc00000

    const/16 v23, 0x7a

    move v0, v12

    .end local v12    # "$dirty":I
    .local v0, "$dirty":I
    const/4 v12, 0x0

    move-object/from16 v21, v11

    move-object v11, v14

    move-wide v13, v15

    .end local v11    # "$composer":Landroidx/compose/runtime/Composer;
    .local v21, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move/from16 v24, v0

    .end local v0    # "$dirty":I
    .local v24, "$dirty":I
    invoke-static/range {v11 .. v23}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1c
    :goto_11
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_1d

    new-instance v0, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda10;

    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    invoke-direct/range {v0 .. v10}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 92
    :cond_1d
    return-void
.end method

.method private static final SetupWizard$lambda$1$lambda$0(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .locals 2
    .param p0, "$state"    # Lorg/lighttouch/android/SetupState;
    .param p1, "$canCancel"    # Z
    .param p2, "$onCancel"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$onFinish"    # Lkotlin/jvm/functions/Function1;

    .line 69
    nop

    .line 70
    invoke-virtual {p0}, Lorg/lighttouch/android/SetupState;->getStep()Lorg/lighttouch/android/SetupStep;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/SetupStep;->CREATING:Lorg/lighttouch/android/SetupStep;

    if-eq v0, v1, :cond_2

    .line 71
    invoke-virtual {p0}, Lorg/lighttouch/android/SetupState;->getStep()Lorg/lighttouch/android/SetupStep;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/SetupStep;->FILES:Lorg/lighttouch/android/SetupStep;

    if-ne v0, v1, :cond_0

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/SetupState;->getSystem()Lorg/lighttouch/android/PickedFile;

    move-result-object v0

    if-nez v0, :cond_0

    sget-object v0, Lorg/lighttouch/android/SetupStep;->WELCOME:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    goto :goto_0

    .line 72
    :cond_0
    if-eqz p1, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/SetupState;->getStep()Lorg/lighttouch/android/SetupStep;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/SetupStep;->DONE:Lorg/lighttouch/android/SetupStep;

    if-eq v0, v1, :cond_1

    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    goto :goto_0

    .line 73
    :cond_1
    invoke-virtual {p0}, Lorg/lighttouch/android/SetupState;->getStep()Lorg/lighttouch/android/SetupStep;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/SetupStep;->DONE:Lorg/lighttouch/android/SetupStep;

    if-ne v0, v1, :cond_2

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-interface {p3, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    :cond_2
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SetupWizard$lambda$3$lambda$2(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    const/4 v0, 0x1

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsProperties_androidKt;->setTestTagsAsResourceId(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SetupWizard$lambda$4(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 12

    or-int/lit8 v0, p9, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v11

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move-object/from16 v10, p10

    invoke-static/range {v1 .. v11}, Lorg/lighttouch/android/SetupWizardKt;->SetupWizard(Lorg/lighttouch/android/SetupState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StageTimes(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 104
    .param p0, "timings"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 232
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, 0x3caaf2b

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(StageTimes)232@14561L34,234@14740L16,234@14825L61,234@14719L167,237@14901L547:SetupWizard.kt#o13vsk"

    invoke-static {v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 800
    :cond_2
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v17, v3

    goto/16 :goto_11

    .line 232
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v6, "org.lighttouch.android.StageTimes (SetupWizard.kt:231)"

    invoke-static {v2, v3, v4, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_4
    const v2, 0x6e3c21fe

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):SetupWizard.kt#9igjgp"

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 233
    move-object v4, v13

    .local v4, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    move v7, v6

    .local v7, "invalid\\1":Z
    const/4 v8, 0x0

    .line 693
    .local v8, "$i$f$cache\\1\\233":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\1":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 694
    .local v10, "$i$a$-let-ComposerKt$cache$1\\2\\693\\1":I
    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    const/4 v12, 0x0

    if-ne v9, v11, :cond_5

    .line 695
    const/4 v11, 0x0

    .line 233
    .local v11, "$i$a$-cache-SetupWizardKt$StageTimes$open$2\\3\\695\\0":I
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    invoke-static {v14, v12, v5, v12}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v11

    .line 695
    .end local v11    # "$i$a$-cache-SetupWizardKt$StageTimes$open$2\\3\\695\\0":I
    nop

    .line 696
    .local v11, "value\\2":Ljava/lang/Object;
    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 697
    nop

    .end local v11    # "value\\2":Ljava/lang/Object;
    goto :goto_2

    .line 698
    :cond_5
    move-object v11, v9

    .line 694
    :goto_2
    nop

    .line 693
    .end local v9    # "it\\1":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\2\\693\\1":I
    nop

    .line 233
    .end local v4    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v7    # "invalid\\1":Z
    .end local v8    # "$i$f$cache\\1\\233":I
    move-object v4, v11

    check-cast v4, Landroidx/compose/runtime/MutableState;

    .local v4, "open$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 234
    move-object v7, v0

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Lkotlin/text/StringsKt;->lines(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v7

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$mapNotNull\\4":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 699
    .local v8, "$i$f$mapNotNull\\4\\234":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\5":Ljava/util/Collection;
    move-object v10, v7

    .local v10, "$this$mapNotNullTo\\5":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 707
    .local v11, "$i$f$mapNotNullTo\\5\\699":I
    move-object v14, v10

    .local v14, "$this$forEach\\6":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 708
    .local v15, "$i$f$forEach\\6\\707":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_3
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    move-object/from16 p1, v7

    .end local v7    # "$this$mapNotNull\\4":Ljava/lang/Iterable;
    .local p1, "$this$mapNotNull\\4":Ljava/lang/Iterable;
    const/4 v7, 0x1

    if-eqz v17, :cond_a

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "element\\6":Ljava/lang/Object;
    move-object/from16 v18, v17

    .local v18, "element\\7":Ljava/lang/Object;
    const/16 v19, 0x0

    .line 707
    .local v19, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\7\\708\\5":I
    move-object/from16 v20, v18

    check-cast v20, Ljava/lang/String;

    .local v20, "line\\9":Ljava/lang/String;
    const/16 v21, 0x0

    .line 234
    .local v21, "$i$a$-mapNotNull-SetupWizardKt$StageTimes$rows$1\\9\\707\\0":I
    move-object/from16 v22, v20

    check-cast v22, Ljava/lang/CharSequence;

    new-array v12, v7, [C

    const/16 v23, 0x9

    aput-char v23, v12, v6

    const/16 v26, 0x6

    const/16 v27, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    move-object/from16 v23, v12

    invoke-static/range {v22 .. v27}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v12

    move-object/from16 v22, v12

    .line 479
    .local v22, "it\\10":Ljava/util/List;
    const/16 v23, 0x0

    .line 234
    .local v23, "$i$a$-takeIf-SetupWizardKt$StageTimes$rows$1$1\\10\\234\\9":I
    invoke-interface/range {v22 .. v22}, Ljava/util/List;->size()I

    move-result v7

    if-ne v7, v5, :cond_6

    const/4 v7, 0x1

    goto :goto_4

    :cond_6
    move v7, v6

    .end local v22    # "it\\10":Ljava/util/List;
    .end local v23    # "$i$a$-takeIf-SetupWizardKt$StageTimes$rows$1$1\\10\\234\\9":I
    :goto_4
    if-eqz v7, :cond_7

    goto :goto_5

    :cond_7
    const/4 v12, 0x0

    :goto_5
    if-eqz v12, :cond_8

    .line 479
    .local v12, "it\\11":Ljava/util/List;
    const/4 v7, 0x0

    .line 234
    .local v7, "$i$a$-let-SetupWizardKt$StageTimes$rows$1$2\\11\\234\\9":I
    invoke-interface {v12, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    move/from16 v23, v6

    const/4 v6, 0x1

    invoke-interface {v12, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v5

    .end local v7    # "$i$a$-let-SetupWizardKt$StageTimes$rows$1$2\\11\\234\\9":I
    .end local v12    # "it\\11":Ljava/util/List;
    goto :goto_6

    :cond_8
    move/from16 v23, v6

    const/4 v5, 0x0

    .line 707
    .end local v20    # "line\\9":Ljava/lang/String;
    .end local v21    # "$i$a$-mapNotNull-SetupWizardKt$StageTimes$rows$1\\9\\707\\0":I
    :goto_6
    if-eqz v5, :cond_9

    .line 709
    .local v5, "it\\7":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 707
    .local v6, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\8\\709\\7":I
    invoke-interface {v9, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 708
    .end local v5    # "it\\7":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\8\\709\\7":I
    .end local v18    # "element\\7":Ljava/lang/Object;
    .end local v19    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\7\\708\\5":I
    :cond_9
    move-object/from16 v7, p1

    move/from16 v6, v23

    const/4 v5, 0x2

    const/4 v12, 0x0

    .end local v17    # "element\\6":Ljava/lang/Object;
    goto :goto_3

    .line 710
    :cond_a
    move/from16 v23, v6

    .line 711
    .end local v14    # "$this$forEach\\6":Ljava/lang/Iterable;
    .end local v15    # "$i$f$forEach\\6\\707":I
    nop

    .end local v9    # "destination\\5":Ljava/util/Collection;
    .end local v10    # "$this$mapNotNullTo\\5":Ljava/lang/Iterable;
    .end local v11    # "$i$f$mapNotNullTo\\5\\699":I
    move-object v5, v9

    check-cast v5, Ljava/util/List;

    .line 699
    nop

    .line 234
    .end local v8    # "$i$f$mapNotNull\\4\\234":I
    .end local p1    # "$this$mapNotNull\\4":Ljava/lang/Iterable;
    move-object/from16 v16, v5

    .local v16, "rows":Ljava/util/List;
    const v5, 0x4c5de2

    invoke-interface {v13, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 235
    move/from16 v2, v23

    .local v2, "invalid\\12":Z
    move-object v5, v13

    .local v5, "$this$cache\\12":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 712
    .local v6, "$i$f$cache\\12\\235":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\12":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 713
    .local v8, "$i$a$-let-ComposerKt$cache$1\\13\\712\\12":I
    sget-object v9, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v9}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v7, v9, :cond_b

    .line 714
    const/4 v9, 0x0

    .line 235
    .local v9, "$i$a$-cache-SetupWizardKt$StageTimes$1\\14\\714\\0":I
    new-instance v10, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda15;

    invoke-direct {v10, v4}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda15;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 714
    .end local v9    # "$i$a$-cache-SetupWizardKt$StageTimes$1\\14\\714\\0":I
    nop

    .line 715
    .local v10, "value\\13":Ljava/lang/Object;
    invoke-interface {v5, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 716
    nop

    .end local v10    # "value\\13":Ljava/lang/Object;
    goto :goto_7

    .line 717
    :cond_b
    move-object v10, v7

    .line 713
    :goto_7
    nop

    .line 712
    .end local v7    # "it\\12":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\13\\712\\12":I
    nop

    .line 235
    .end local v2    # "invalid\\12":Z
    .end local v5    # "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\12\\235":I
    check-cast v10, Lkotlin/jvm/functions/Function0;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v2

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x18

    .local v2, "$this$dp\\15":I
    const/4 v5, 0x0

    .line 718
    .local v5, "$i$f$getDp\\15\\235":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v31

    .line 235
    .end local v2    # "$this$dp\\15":I
    .end local v5    # "$i$f$getDp\\15\\235":I
    const/16 v34, 0xd

    const/16 v35, 0x0

    const/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v29 .. v35}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const-string v5, "setup_details"

    invoke-static {v2, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    new-instance v5, Lorg/lighttouch/android/SetupWizardKt$StageTimes$2;

    invoke-direct {v5, v4}, Lorg/lighttouch/android/SetupWizardKt$StageTimes$2;-><init>(Landroidx/compose/runtime/MutableState;)V

    const/16 v6, 0x36

    const v7, 0x710eafe8

    const/4 v8, 0x1

    invoke-static {v7, v8, v5, v13, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object v12, v5

    check-cast v12, Lkotlin/jvm/functions/Function3;

    const v14, 0x30000036

    const/16 v15, 0x1fc

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move/from16 v24, v8

    const/4 v8, 0x0

    const/4 v9, 0x0

    move v11, v3

    move-object v3, v10

    .end local v3    # "$dirty":I
    .local v11, "$dirty":I
    const/4 v10, 0x0

    move/from16 v17, v11

    .end local v11    # "$dirty":I
    .local v17, "$dirty":I
    const/4 v11, 0x0

    move-object/from16 p1, v4

    move/from16 v0, v24

    move-object v4, v2

    const/4 v2, 0x0

    .end local v4    # "open$delegate":Landroidx/compose/runtime/MutableState;
    .local p1, "open$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static/range {v3 .. v15}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 238
    invoke-static/range {p1 .. p1}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes$lambda$34(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    if-eqz v3, :cond_17

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    invoke-static {v3, v4, v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v3, 0x4

    .local v3, "$this$dp\\16":I
    const/4 v6, 0x0

    .line 719
    .local v6, "$i$f$getDp\\16\\238":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 238
    .end local v3    # "$this$dp\\16":I
    .end local v6    # "$i$f$getDp\\16\\238":I
    const/16 v10, 0xd

    const/4 v11, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v5 .. v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\17":Landroidx/compose/ui/Modifier;
    const/4 v5, 0x6

    .local v5, "$changed\\17":I
    const/4 v6, 0x0

    .line 720
    .local v6, "$i$f$Column\\17\\238":I
    const v7, -0x1cd0f17e

    const-string v8, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v13, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 721
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 722
    .local v7, "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 725
    .local v8, "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v9, v5, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v7, v8, v13, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\17":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 726
    nop

    .local v10, "$changed\\18":I
    const/4 v11, 0x0

    .line 727
    .local v11, "$i$f$Layout\\18\\726":I
    const v12, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v13, v12, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 728
    const/4 v15, 0x0

    invoke-static {v13, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v18

    .line 729
    .local v18, "compositeKeyHash\\18":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 730
    .local v15, "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v13, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 732
    .local v12, "materialized\\18":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    shl-int/lit8 v2, v10, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 731
    move-object/from16 v21, v20

    .local v2, "$changed\\19":I
    .local v21, "factory\\19":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 733
    .local v20, "$i$f$ReusableComposeNode\\19\\731":I
    const v4, -0x2942ffcf

    const-string v0, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v13, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 734
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 735
    :cond_c
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 736
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_d

    .line 737
    move-object/from16 v4, v21

    .end local v21    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-interface {v13, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_8

    .line 739
    .end local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .restart local v21    # "factory\\19":Lkotlin/jvm/functions/Function0;
    :cond_d
    move-object/from16 v4, v21

    .end local v21    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 741
    :goto_8
    move/from16 v21, v2

    .end local v2    # "$changed\\19":I
    .local v21, "$changed\\19":I
    invoke-static {v13}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 742
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\20\\741\\18":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v29, v3

    .end local v3    # "modifier\\17":Landroidx/compose/ui/Modifier;
    .local v29, "modifier\\17":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 743
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v15, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 745
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\21":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 746
    .local v27, "$i$f$set-impl\\21\\745":I
    move-object/from16 v30, v2

    .local v30, "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 747
    .local v31, "$i$a$-with-Updater$set$1\\22\\746\\21":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v32

    if-nez v32, :cond_f

    move-object/from16 v32, v4

    .end local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .local v32, "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v33, v5

    .end local v5    # "$changed\\17":I
    .local v33, "$changed\\17":I
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_e

    goto :goto_9

    :cond_e
    move-object/from16 v5, v30

    goto :goto_a

    .end local v32    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .end local v33    # "$changed\\17":I
    .restart local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "$changed\\17":I
    :cond_f
    move-object/from16 v32, v4

    move/from16 v33, v5

    .line 748
    .end local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .end local v5    # "$changed\\17":I
    .restart local v32    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "$changed\\17":I
    :goto_9
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v30

    .end local v30    # "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 749
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 751
    :goto_a
    nop

    .line 746
    .end local v5    # "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-with-Updater$set$1\\22\\746\\21":I
    nop

    .line 751
    nop

    .line 752
    .end local v3    # "block\\21":Lkotlin/jvm/functions/Function2;
    .end local v27    # "$i$f$set-impl\\21\\745":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 753
    nop

    .line 741
    .end local v2    # "$this$Layout_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\20\\741\\18":I
    nop

    .line 754
    shr-int/lit8 v2, v21, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\23":I
    move-object v3, v13

    .local v3, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 755
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\23\\754\\17":I
    const v5, -0x16ef5699

    move/from16 v26, v2

    .end local v2    # "$changed\\23":I
    .local v26, "$changed\\23":I
    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v33, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\24":I
    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    .local v2, "$this$StageTimes_u24lambda_u2443\\24":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v27, v3

    .local v27, "$composer\\24":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 239
    .local v30, "$i$a$-Column-SetupWizardKt$StageTimes$3\\24\\755\\0":I
    move-object/from16 v31, v2

    .end local v2    # "$this$StageTimes_u24lambda_u2443\\24":Landroidx/compose/foundation/layout/ColumnScope;
    .local v31, "$this$StageTimes_u24lambda_u2443\\24":Landroidx/compose/foundation/layout/ColumnScope;
    const v2, 0xa8e8948

    move-object/from16 v34, v3

    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v34, "$composer\\23":Landroidx/compose/runtime/Composer;
    const-string v3, "C:SetupWizard.kt#o13vsk"

    move/from16 v35, v4

    move-object/from16 v4, v27

    .end local v27    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v35, "$i$a$-Layout-ColumnKt$Column$1\\23\\754\\17":I
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, -0x397745e5

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*239@15087L345"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object/from16 v2, v16

    check-cast v2, Ljava/util/Collection;

    move-object/from16 v3, v16

    check-cast v3, Ljava/lang/Iterable;

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const-wide/16 v36, 0x0

    move-wide/from16 v38, v36

    :goto_b
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v27

    if-eqz v27, :cond_11

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27

    check-cast v27, Lkotlin/Pair;

    .line 479
    nop

    .local v27, "it\\25":Lkotlin/Pair;
    const/16 v40, 0x0

    .line 239
    .local v40, "$i$a$-sumOfDouble-SetupWizardKt$StageTimes$3$1\\25\\239\\24":I
    invoke-virtual/range {v27 .. v27}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v41

    check-cast v41, Ljava/lang/String;

    invoke-static/range {v41 .. v41}, Lkotlin/text/StringsKt;->toDoubleOrNull(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v41

    if-eqz v41, :cond_10

    invoke-virtual/range {v41 .. v41}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v41

    goto :goto_c

    :cond_10
    move-wide/from16 v41, v36

    .end local v27    # "it\\25":Lkotlin/Pair;
    .end local v40    # "$i$a$-sumOfDouble-SetupWizardKt$StageTimes$3$1\\25\\239\\24":I
    :goto_c
    add-double v38, v38, v41

    goto :goto_b

    :cond_11
    invoke-static/range {v38 .. v39}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    move/from16 v27, v5

    const/4 v5, 0x1

    .end local v5    # "$changed\\24":I
    .local v27, "$changed\\24":I
    invoke-static {v3, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%.1f"

    invoke-static {v5, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v5, "format(...)"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "\u603b\u8ba1"

    invoke-static {v5, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_16

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lkotlin/Pair;

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v36, v5

    check-cast v36, Ljava/lang/String;

    .local v36, "stage\\24":Ljava/lang/String;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 240
    .local v3, "seconds\\24":Ljava/lang/String;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    move-object/from16 v61, v2

    move/from16 v22, v6

    move-object/from16 v24, v7

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    .end local v6    # "$i$f$Column\\17\\238":I
    .end local v7    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v22, "$i$f$Column\\17\\238":I
    .local v24, "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v2, v7, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v2, 0x2

    .local v2, "$this$dp\\26":I
    const/16 v37, 0x0

    .line 756
    .local v37, "$i$f$getDp\\26\\240":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 240
    .end local v2    # "$this$dp\\26":I
    .end local v37    # "$i$f$getDp\\26\\240":I
    move-object/from16 v28, v8

    const/4 v6, 0x0

    const/4 v8, 0x0

    .end local v8    # "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    .local v28, "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v5, v6, v2, v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\27":Landroidx/compose/ui/Modifier;
    const/4 v5, 0x6

    .local v5, "$changed\\27":I
    const/16 v62, 0x0

    .line 757
    .local v62, "$i$f$Row\\27\\240":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v4, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 758
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 759
    .local v6, "horizontalArrangement\\27":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 762
    .local v7, "verticalAlignment\\27":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v37, v5, 0x3

    and-int/lit8 v37, v37, 0xe

    shr-int/lit8 v38, v5, 0x3

    and-int/lit8 v38, v38, 0x70

    or-int v8, v37, v38

    invoke-static {v6, v7, v4, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\27":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v37, v5, 0x3

    and-int/lit8 v37, v37, 0x70

    .line 763
    move/from16 v63, v37

    .local v63, "$changed\\28":I
    const/16 v64, 0x0

    .line 764
    .local v64, "$i$f$Layout\\28\\763":I
    move/from16 v65, v5

    const v5, -0x4ee9b9da

    .end local v5    # "$changed\\27":I
    .local v65, "$changed\\27":I
    invoke-static {v4, v5, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 765
    const/4 v5, 0x0

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v23

    .line 766
    .local v23, "compositeKeyHash\\28":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 767
    .local v5, "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v66, v6

    .end local v6    # "horizontalArrangement\\27":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v66, "horizontalArrangement\\27":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v4, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 769
    .local v6, "materialized\\28":Landroidx/compose/ui/Modifier;
    sget-object v37, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v37 .. v37}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v37

    move-object/from16 v67, v2

    .end local v2    # "modifier\\27":Landroidx/compose/ui/Modifier;
    .local v67, "modifier\\27":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v63, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 768
    move-object/from16 v68, v37

    .local v2, "$changed\\29":I
    .local v68, "factory\\29":Lkotlin/jvm/functions/Function0;
    const/16 v69, 0x0

    .line 770
    .local v69, "$i$f$ReusableComposeNode\\29\\768":I
    move/from16 v70, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\29":I
    .local v70, "$changed\\29":I
    invoke-static {v4, v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 771
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_12

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 772
    :cond_12
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 773
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_13

    .line 774
    move-object/from16 v2, v68

    .end local v68    # "factory\\29":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\29":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_e

    .line 776
    .end local v2    # "factory\\29":Lkotlin/jvm/functions/Function0;
    .restart local v68    # "factory\\29":Lkotlin/jvm/functions/Function0;
    :cond_13
    move-object/from16 v2, v68

    .end local v68    # "factory\\29":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\29":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 778
    :goto_e
    move-object/from16 v68, v0

    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    const/16 v37, 0x0

    .line 779
    .local v37, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\30\\778\\28":I
    sget-object v38, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v71, v2

    .end local v2    # "factory\\29":Lkotlin/jvm/functions/Function0;
    .local v71, "factory\\29":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v38 .. v38}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v8, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 780
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 782
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\31":Lkotlin/jvm/functions/Function2;
    const/16 v38, 0x0

    .line 783
    .local v38, "$i$f$set-impl\\31\\782":I
    move-object/from16 v39, v0

    .local v39, "$this$set_impl_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    const/16 v40, 0x0

    .line 784
    .local v40, "$i$a$-with-Updater$set$1\\32\\783\\31":I
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v41

    if-nez v41, :cond_15

    move-object/from16 v72, v4

    .end local v4    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v72, "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v73, v5

    .end local v5    # "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    .local v73, "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_14

    goto :goto_f

    :cond_14
    move-object/from16 v5, v39

    goto :goto_10

    .end local v72    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .end local v73    # "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v5    # "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_15
    move-object/from16 v72, v4

    move-object/from16 v73, v5

    .line 785
    .end local v4    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .end local v5    # "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v72    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v73    # "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_f
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v39

    .end local v39    # "$this$set_impl_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 786
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 788
    :goto_10
    nop

    .line 783
    .end local v5    # "$this$set_impl_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    .end local v40    # "$i$a$-with-Updater$set$1\\32\\783\\31":I
    nop

    .line 788
    nop

    .line 789
    .end local v2    # "block\\31":Lkotlin/jvm/functions/Function2;
    .end local v38    # "$i$f$set-impl\\31\\782":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 790
    nop

    .line 778
    .end local v0    # "$this$Layout_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    .end local v37    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\30\\778\\28":I
    nop

    .line 791
    shr-int/lit8 v0, v70, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\33":I
    move-object/from16 v2, v72

    .local v2, "$composer\\33":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 792
    .local v4, "$i$a$-Layout-RowKt$Row$1\\33\\791\\27":I
    const v5, -0x184f2606

    move/from16 v74, v0

    .end local v0    # "$changed\\33":I
    .local v74, "$changed\\33":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v65, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\34":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v57, v2

    .local v57, "$composer\\34":Landroidx/compose/runtime/Composer;
    move-object/from16 v37, v0

    .end local v0    # "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    .local v37, "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    const/4 v0, 0x0

    .line 241
    .local v0, "$i$a$-Row-SetupWizardKt$StageTimes$3$2\\34\\792\\24":I
    move/from16 v100, v0

    .end local v0    # "$i$a$-Row-SetupWizardKt$StageTimes$3$2\\34\\792\\24":I
    .local v100, "$i$a$-Row-SetupWizardKt$StageTimes$3$2\\34\\792\\24":I
    const v0, 0x103580de

    move-object/from16 v101, v2

    .end local v2    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v101, "$composer\\33":Landroidx/compose/runtime/Composer;
    const-string v2, "C240@15214L10,240@15258L11,240@15159L128,241@15345L10,241@15389L11,241@15304L114:SetupWizard.kt#o13vsk"

    move/from16 v102, v4

    move-object/from16 v4, v57

    .end local v57    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\34":Landroidx/compose/runtime/Composer;
    .local v102, "$i$a$-Layout-RowKt$Row$1\\33\\791\\27":I
    invoke-static {v4, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v38, v0

    check-cast v38, Landroidx/compose/ui/Modifier;

    const/16 v41, 0x2

    const/16 v42, 0x0

    const/high16 v39, 0x3f800000    # 1.0f

    const/16 v40, 0x0

    invoke-static/range {v37 .. v42}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object/from16 v2, v37

    move-object/from16 v37, v0

    .end local v37    # "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    .local v2, "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v103, v2

    .end local v2    # "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    .local v103, "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v56

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v38

    const/16 v59, 0x0

    const v60, 0xfff8

    const-wide/16 v40, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v58, 0x0

    .end local v4    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\34":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v60}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 242
    .end local v57    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\34":Landroidx/compose/runtime/Composer;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " s"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v75

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v95

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v77

    const/16 v98, 0x0

    const v99, 0xfffa

    const/16 v76, 0x0

    const-wide/16 v79, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const-wide/16 v84, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const-wide/16 v88, 0x0

    const/16 v90, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v97, 0x0

    move-object/from16 v96, v4

    .end local v4    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .local v96, "$composer\\34":Landroidx/compose/runtime/Composer;
    invoke-static/range {v75 .. v99}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 241
    .end local v96    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\34":Landroidx/compose/runtime/Composer;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 243
    nop

    .line 792
    .end local v4    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .end local v5    # "$changed\\34":I
    .end local v100    # "$i$a$-Row-SetupWizardKt$StageTimes$3$2\\34\\792\\24":I
    .end local v103    # "$this$StageTimes_u24lambda_u2443_u24lambda_u2442\\34":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v101 .. v101}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 791
    .end local v74    # "$changed\\33":I
    .end local v101    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .end local v102    # "$i$a$-Layout-RowKt$Row$1\\33\\791\\27":I
    nop

    .line 793
    invoke-interface/range {v72 .. v72}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 770
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 794
    nop

    .line 764
    .end local v69    # "$i$f$ReusableComposeNode\\29\\768":I
    .end local v70    # "$changed\\29":I
    .end local v71    # "factory\\29":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 795
    nop

    .line 757
    .end local v6    # "materialized\\28":Landroidx/compose/ui/Modifier;
    .end local v23    # "compositeKeyHash\\28":I
    .end local v63    # "$changed\\28":I
    .end local v64    # "$i$f$Layout\\28\\763":I
    .end local v73    # "localMap\\28":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 796
    move/from16 v6, v22

    move-object/from16 v7, v24

    move-object/from16 v8, v28

    move-object/from16 v2, v61

    move-object/from16 v0, v68

    move-object/from16 v4, v72

    .end local v3    # "seconds\\24":Ljava/lang/String;
    .end local v7    # "verticalAlignment\\27":Landroidx/compose/ui/Alignment$Vertical;
    .end local v8    # "measurePolicy\\27":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v36    # "stage\\24":Ljava/lang/String;
    .end local v62    # "$i$f$Row\\27\\240":I
    .end local v65    # "$changed\\27":I
    .end local v66    # "horizontalArrangement\\27":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v67    # "modifier\\27":Landroidx/compose/ui/Modifier;
    goto/16 :goto_d

    .end local v22    # "$i$f$Column\\17\\238":I
    .end local v24    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v28    # "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v72    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v6, "$i$f$Column\\17\\238":I
    .local v7, "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v8, "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_16
    move-object/from16 v72, v4

    move/from16 v22, v6

    move-object/from16 v24, v7

    move-object/from16 v28, v8

    .end local v4    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$Column\\17\\238":I
    .end local v7    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v8    # "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v22    # "$i$f$Column\\17\\238":I
    .restart local v24    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v28    # "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v72    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v72 .. v72}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 239
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 245
    nop

    .line 755
    .end local v27    # "$changed\\24":I
    .end local v30    # "$i$a$-Column-SetupWizardKt$StageTimes$3\\24\\755\\0":I
    .end local v31    # "$this$StageTimes_u24lambda_u2443\\24":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v72    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v34}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 754
    .end local v26    # "$changed\\23":I
    .end local v34    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v35    # "$i$a$-Layout-ColumnKt$Column$1\\23\\754\\17":I
    nop

    .line 797
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 733
    invoke-static {v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 798
    nop

    .line 727
    .end local v20    # "$i$f$ReusableComposeNode\\19\\731":I
    .end local v21    # "$changed\\19":I
    .end local v32    # "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-static {v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 799
    nop

    .line 720
    .end local v10    # "$changed\\18":I
    .end local v11    # "$i$f$Layout\\18\\726":I
    .end local v12    # "materialized\\18":Landroidx/compose/ui/Modifier;
    .end local v15    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v18    # "compositeKeyHash\\18":I
    invoke-static {v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 800
    nop

    .end local v9    # "measurePolicy\\17":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22    # "$i$f$Column\\17\\238":I
    .end local v24    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v28    # "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v29    # "modifier\\17":Landroidx/compose/ui/Modifier;
    .end local v33    # "$changed\\17":I
    :cond_17
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v16    # "rows":Ljava/util/List;
    .end local p1    # "open$delegate":Landroidx/compose/runtime/MutableState;
    :cond_18
    :goto_11
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_19

    new-instance v2, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda16;

    move-object/from16 v3, p0

    invoke-direct {v2, v3, v1}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda16;-><init>(Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_12

    :cond_19
    move-object/from16 v3, p0

    .line 246
    :goto_12
    return-void
.end method

.method private static final StageTimes$lambda$34(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 233
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 801
    .local v3, "$i$f$getValue\\1\\233":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\233":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 233
    return v0
.end method

.method private static final StageTimes$lambda$35(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 233
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 802
    .local v4, "$i$f$setValue\\1\\233":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 803
    nop

    .line 233
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\233":I
    return-void
.end method

.method private static final StageTimes$lambda$40$lambda$39(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 235
    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes$lambda$34(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes$lambda$35(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StageTimes$lambda$44(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Welcome(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 63
    .param p0, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p1, "onFiles"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 95
    move-object/from16 v0, p0

    move-object/from16 v13, p1

    move/from16 v14, p3

    const v1, -0x69a84348

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(Welcome)P(1)95@5079L1794:SetupWizard.kt#o13vsk"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v3, v14, 0x6

    const/4 v4, 0x2

    if-nez v3, :cond_1

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    move v3, v4

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v14, 0x30

    if-nez v3, :cond_3

    invoke-interface {v15, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    and-int/lit8 v3, v2, 0x13

    const/16 v5, 0x12

    if-ne v3, v5, :cond_5

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    .line 347
    :cond_4
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v22, v13

    move-object v13, v0

    move-object/from16 v0, v22

    move/from16 v22, v2

    goto/16 :goto_9

    .line 95
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_6

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.Welcome (SetupWizard.kt:94)"

    invoke-static {v1, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 96
    :cond_6
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v5, v3, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v3, 0x1c

    .local v3, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 260
    .local v7, "$i$f$getDp\\1\\96":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 96
    .end local v3    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\96":I
    invoke-static {v1, v3, v5, v4, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getCenter()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v3, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v7, 0x36

    .local v7, "$changed\\2":I
    move/from16 v16, v7

    .end local v7    # "$changed\\2":I
    .local v16, "$changed\\2":I
    const/16 v17, 0x0

    .line 261
    .local v17, "$i$f$Column\\2\\96":I
    const v7, -0x1cd0f17e

    const-string v8, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v15, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 262
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    .line 265
    .local v7, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v8, v16, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v9, v16, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v8, v9

    invoke-static {v3, v7, v15, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v16, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 266
    move/from16 v18, v9

    .local v18, "$changed\\3":I
    const/16 v19, 0x0

    .line 267
    .local v19, "$i$f$Layout\\3\\266":I
    const v9, -0x4ee9b9da

    const-string v10, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v15, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 268
    const/4 v11, 0x0

    invoke-static {v15, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v20

    .line 269
    .local v20, "compositeKeyHash\\3":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 270
    .local v12, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p2, v2

    .end local v2    # "$dirty":I
    .local p2, "$dirty":I
    invoke-static {v15, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 272
    .local v2, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    shl-int/lit8 v4, v18, 0x6

    and-int/lit16 v4, v4, 0x380

    const/4 v5, 0x6

    or-int/2addr v4, v5

    .line 271
    move-object/from16 v24, v21

    .local v24, "factory\\4":Lkotlin/jvm/functions/Function0;
    move/from16 v21, v4

    .local v21, "$changed\\4":I
    const/16 v25, 0x0

    .line 273
    .local v25, "$i$f$ReusableComposeNode\\4\\271":I
    const v4, -0x2942ffcf

    const-string v6, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v15, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 274
    move/from16 v27, v5

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 275
    :cond_7
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 276
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_8

    .line 277
    move-object/from16 v5, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 279
    .end local v5    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v5, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 281
    :goto_3
    invoke-static {v15}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 282
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\281\\3":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v4, v8, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 283
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v4, v12, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 285
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    .local v11, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 286
    .local v29, "$i$f$set-impl\\6\\285":I
    move-object/from16 v31, v4

    .local v31, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 287
    .local v32, "$i$a$-with-Updater$set$1\\7\\286\\6":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v33

    if-nez v33, :cond_a

    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v9, v31

    goto :goto_5

    .line 288
    :cond_a
    :goto_4
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v9, v31

    .end local v31    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 289
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v4, v0, v11}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 291
    :goto_5
    nop

    .line 286
    .end local v9    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-with-Updater$set$1\\7\\286\\6":I
    nop

    .line 291
    nop

    .line 292
    .end local v11    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\6\\285":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 293
    nop

    .line 281
    .end local v4    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\281\\3":I
    nop

    .line 294
    shr-int/lit8 v0, v21, 0x6

    and-int/lit8 v28, v0, 0xe

    .local v28, "$changed\\8":I
    move-object v0, v15

    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 295
    .local v29, "$i$a$-Layout-ColumnKt$Column$1\\8\\294\\2":I
    const v4, -0x16ef5699

    const-string v9, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v0, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v16, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v31, v9, 0x6

    .local v31, "$changed\\9":I
    check-cast v4, Landroidx/compose/foundation/layout/ColumnScope;

    .local v4, "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v9, v0

    .local v9, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 97
    .local v32, "$i$a$-Column-SetupWizardKt$Welcome$1\\9\\295\\0":I
    const v11, 0x7d413468

    move-object/from16 v59, v0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v59, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v0, "C96@5240L11,96@5190L269,99@5468L30,100@5548L10,100@5507L66,101@5582L29,102@5713L10,103@5771L11,102@5620L180,104@5809L30,105@5936L10,105@5848L110,106@5967L30,107@6006L118,108@6133L126,109@6268L83,110@6360L30,111@6399L263,114@6671L196:SetupWizard.kt#o13vsk"

    invoke-static {v9, v11, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v11, 0x48

    .local v11, "$this$dp\\10":I
    const/16 v34, 0x0

    .line 296
    .local v34, "$i$f$getDp\\10\\97":I
    move-object/from16 v60, v1

    .end local v1    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v60, "modifier\\2":Landroidx/compose/ui/Modifier;
    int-to-float v1, v11

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 97
    .end local v11    # "$this$dp\\10":I
    .end local v34    # "$i$f$getDp\\10\\97":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v9, v11}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    move-object v11, v2

    .end local v2    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v11, "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v1

    move-object/from16 v61, v3

    .end local v3    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v61, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v3, 0x14

    .local v3, "$this$dp\\11":I
    const/16 v34, 0x0

    .line 296
    .local v34, "$i$f$getDp\\11\\97":I
    move-object/from16 v62, v5

    .end local v5    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v62, "factory\\4":Lkotlin/jvm/functions/Function0;
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 97
    .end local v3    # "$this$dp\\11":I
    .end local v34    # "$i$f$getDp\\11\\97":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\12":Landroidx/compose/ui/Modifier;
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v1

    .local v1, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    const/16 v2, 0x30

    .local v2, "$changed\\12":I
    const/4 v3, 0x0

    .line 297
    .local v3, "$i$f$Box\\12\\97":I
    const v5, 0x2bb5b5d7

    move/from16 v34, v2

    .end local v2    # "$changed\\12":I
    .local v34, "$changed\\12":I
    const-string v2, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v9, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 298
    const/4 v2, 0x0

    .line 301
    .local v2, "propagateMinConstraints\\12":Z
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .local v5, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v35, v34, 0x3

    and-int/lit8 v35, v35, 0x70

    .line 302
    nop

    .local v35, "$changed\\13":I
    const/16 v36, 0x0

    .line 303
    .local v36, "$i$f$Layout\\13\\302":I
    move-object/from16 v37, v1

    const v1, -0x4ee9b9da

    .end local v1    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .local v37, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    invoke-static {v9, v1, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 304
    const/4 v1, 0x0

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v1

    .line 305
    .local v1, "compositeKeyHash\\13":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 306
    .local v10, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v30, v1

    .end local v1    # "compositeKeyHash\\13":I
    .local v30, "compositeKeyHash\\13":I
    invoke-static {v9, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 308
    .local v1, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v33, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v33 .. v33}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v33

    move-object/from16 v38, v0

    .end local v0    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v38, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v35, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 307
    nop

    .local v0, "$changed\\14":I
    move-object/from16 v39, v33

    .local v39, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v33, 0x0

    .line 309
    .local v33, "$i$f$ReusableComposeNode\\14\\307":I
    move/from16 v40, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\14":I
    .local v40, "$changed\\14":I
    invoke-static {v9, v0, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 310
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 311
    :cond_b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 312
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_c

    .line 313
    move-object/from16 v0, v39

    .end local v39    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 315
    .end local v0    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v39    # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v0, v39

    .end local v39    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 317
    :goto_6
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .local v6, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 318
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\317\\13":I
    sget-object v39, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v41, v0

    .end local v0    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v41, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v6, v5, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 319
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v6, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 321
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v39, 0x0

    .line 322
    .local v39, "$i$f$set-impl\\16\\321":I
    move-object/from16 v42, v6

    .local v42, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 323
    .local v43, "$i$a$-with-Updater$set$1\\17\\322\\16":I
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_e

    move/from16 v44, v2

    .end local v2    # "propagateMinConstraints\\12":Z
    .local v44, "propagateMinConstraints\\12":Z
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v45, v3

    .end local v3    # "$i$f$Box\\12\\97":I
    .local v45, "$i$f$Box\\12\\97":I
    invoke-static/range {v30 .. v30}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_d

    goto :goto_7

    :cond_d
    move-object/from16 v3, v42

    goto :goto_8

    .end local v44    # "propagateMinConstraints\\12":Z
    .end local v45    # "$i$f$Box\\12\\97":I
    .restart local v2    # "propagateMinConstraints\\12":Z
    .restart local v3    # "$i$f$Box\\12\\97":I
    :cond_e
    move/from16 v44, v2

    move/from16 v45, v3

    .line 324
    .end local v2    # "propagateMinConstraints\\12":Z
    .end local v3    # "$i$f$Box\\12\\97":I
    .restart local v44    # "propagateMinConstraints\\12":Z
    .restart local v45    # "$i$f$Box\\12\\97":I
    :goto_7
    invoke-static/range {v30 .. v30}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v42

    .end local v42    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 325
    invoke-static/range {v30 .. v30}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v6, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 327
    :goto_8
    nop

    .line 322
    .end local v3    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\17\\322\\16":I
    nop

    .line 327
    nop

    .line 328
    .end local v0    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v39    # "$i$f$set-impl\\16\\321":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v6, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 329
    nop

    .line 317
    .end local v6    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\317\\13":I
    nop

    .line 330
    shr-int/lit8 v0, v40, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\18":I
    move-object v2, v9

    .local v2, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 331
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\18\\330\\12":I
    const v6, -0x7ff519f7    # -1.000876E-39f

    move/from16 v24, v0

    .end local v0    # "$changed\\18":I
    .local v24, "$changed\\18":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v2, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v6, v34, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\19":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$Welcome_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v51, v2

    .local v51, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 98
    .local v39, "$i$a$-Box-SetupWizardKt$Welcome$1$1\\19\\331\\9":I
    move-object/from16 v42, v0

    .end local v0    # "$this$Welcome_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/BoxScope;
    .local v42, "$this$Welcome_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/BoxScope;
    const v0, 0x6ab98cab

    move-object/from16 v43, v1

    .end local v1    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v43, "materialized\\13":Landroidx/compose/ui/Modifier;
    const-string v1, "C97@5418L11,97@5349L100:SetupWizard.kt#o13vsk"

    move-object/from16 v54, v2

    .end local v51    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getPhone()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v46

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x26

    .local v1, "$this$dp\\20":I
    const/16 v47, 0x0

    .line 332
    .local v47, "$i$f$getDp\\20\\98":I
    move/from16 v55, v3

    .end local v3    # "$i$a$-Layout-BoxKt$Box$1\\18\\330\\12":I
    .local v55, "$i$a$-Layout-BoxKt$Box$1\\18\\330\\12":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 98
    .end local v1    # "$this$dp\\20":I
    .end local v47    # "$i$f$getDp\\20\\98":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v48

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnPrimaryContainer-0d7_KjU()J

    move-result-wide v49

    const/16 v52, 0x1b0

    const/16 v53, 0x0

    const/16 v47, 0x0

    .end local v2    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v53}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .end local v51    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 99
    nop

    .line 331
    .end local v2    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v6    # "$changed\\19":I
    .end local v39    # "$i$a$-Box-SetupWizardKt$Welcome$1$1\\19\\331\\9":I
    .end local v42    # "$this$Welcome_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 330
    .end local v24    # "$changed\\18":I
    .end local v54    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-Layout-BoxKt$Box$1\\18\\330\\12":I
    nop

    .line 333
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 309
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 334
    nop

    .line 303
    .end local v33    # "$i$f$ReusableComposeNode\\14\\307":I
    .end local v40    # "$changed\\14":I
    .end local v41    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 335
    nop

    .line 297
    .end local v10    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v30    # "compositeKeyHash\\13":I
    .end local v35    # "$changed\\13":I
    .end local v36    # "$i$f$Layout\\13\\302":I
    .end local v43    # "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 336
    nop

    .line 100
    .end local v5    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v34    # "$changed\\12":I
    .end local v37    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .end local v38    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v44    # "propagateMinConstraints\\12":Z
    .end local v45    # "$i$f$Box\\12\\97":I
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x1c

    .local v1, "$this$dp\\21":I
    const/4 v2, 0x0

    .line 337
    .local v2, "$i$f$getDp\\21\\100":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 100
    .end local v1    # "$this$dp\\21":I
    .end local v2    # "$i$f$getDp\\21\\100":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v27

    invoke-static {v0, v9, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 101
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v9, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getHeadlineLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v54

    const/16 v57, 0x0

    const v58, 0xfffe

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const-wide/16 v47, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v56, 0x6

    const-string v34, "LightTouch"

    move-object/from16 v55, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v58}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 102
    move-object/from16 v10, v55

    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\22":I
    const/4 v2, 0x0

    .line 338
    .local v2, "$i$f$getDp\\22\\102":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 102
    .end local v1    # "$this$dp\\22":I
    .end local v2    # "$i$f$getDp\\22\\102":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v10, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 103
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v10, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v54

    .line 104
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v10, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v36

    .line 103
    nop

    .line 104
    nop

    .line 103
    const v58, 0xfffa

    const-string v34, "\u5728\u624b\u673a\u4e0a\u8fd0\u884c\u7684\u7ecf\u5178 iPod touch \u4e0e iPhone \u8f6f\u4ef6\u3002"

    .end local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v58}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 105
    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x24

    .local v1, "$this$dp\\23":I
    const/4 v2, 0x0

    .line 339
    .local v2, "$i$f$getDp\\23\\105":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 105
    .end local v1    # "$this$dp\\23":I
    .end local v2    # "$i$f$getDp\\23\\105":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v10, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 106
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v10, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v54

    const v58, 0xfffe

    const-wide/16 v36, 0x0

    const-string v34, "LightTouch \u4f1a\u76f4\u63a5\u5728\u8fd9\u53f0\u624b\u673a\u4e0a\u4e3a\u4f60\u8bbe\u7f6e\u4e00\u53f0\u8bbe\u5907\uff1a"

    .end local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v58}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 107
    .end local v55    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x10

    .local v1, "$this$dp\\24":I
    const/4 v2, 0x0

    .line 340
    .local v2, "$i$f$getDp\\24\\107":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 107
    .end local v1    # "$this$dp\\24":I
    .end local v2    # "$i$f$getDp\\24\\107":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v10, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 108
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getPhone()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const-string v1, "\u9009\u62e9\u8bbe\u5907\u4e0e iOS \u7248\u672c"

    const-string v2, "\u4ece iPod touch 2G + iOS 3.1.3 \u5f00\u59cb\u6700\u7701\u4e8b"

    const/16 v3, 0x1b0

    invoke-static {v0, v1, v2, v10, v3}, Lorg/lighttouch/android/SetupWizardKt;->Need(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 109
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getDownload()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const-string v1, "LightTouch \u8d1f\u8d23\u4e0b\u8f7d"

    const-string v2, "iOS \u56fa\u4ef6\u6765\u81ea Apple\uff0cApple \u4e0d\u518d\u63d0\u4f9b\u65f6\u6765\u81ea Internet Archive"

    invoke-static {v0, v1, v2, v10, v3}, Lorg/lighttouch/android/SetupWizardKt;->Need(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 110
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getLayers()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const-string v1, "\u63a5\u7740\u5b8c\u6210\u51c6\u5907"

    const-string v2, "\u9700\u8981\u4e00\u4e24\u5206\u949f\u5230\u51e0\u5206\u949f\uff0c\u5e76\u9884\u7559 1.5\u20135 GB \u7a7a\u95f4"

    invoke-static {v0, v1, v2, v10, v3}, Lorg/lighttouch/android/SetupWizardKt;->Need(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 111
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x28

    .local v1, "$this$dp\\25":I
    const/4 v2, 0x0

    .line 341
    .local v2, "$i$f$getDp\\25\\111":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 111
    .end local v1    # "$this$dp\\25":I
    .end local v2    # "$i$f$getDp\\25\\111":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v10, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 112
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    invoke-interface {v4, v0, v1}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x34

    .local v1, "$this$dp\\26":I
    const/4 v2, 0x0

    .line 342
    .local v2, "$i$f$getDp\\26\\112":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 112
    .end local v1    # "$this$dp\\26":I
    .end local v2    # "$i$f$getDp\\26\\112":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "setup_start"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v0, 0x20

    .local v0, "$this$dp\\27":I
    const/4 v2, 0x0

    .line 342
    .local v2, "$i$f$getDp\\27\\112":I
    int-to-float v3, v0

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 112
    .end local v0    # "$this$dp\\27":I
    .end local v2    # "$i$f$getDp\\27\\112":I
    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x2

    invoke-static {v0, v3, v5, v2}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA$default(FFILjava/lang/Object;)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v0

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$329988766$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    and-int/lit8 v2, p2, 0xe

    const/high16 v3, 0x30c00000

    or-int/2addr v2, v3

    move-object v3, v12

    .end local v12    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v12, 0x17c

    move-object v5, v11

    move v11, v2

    .end local v11    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v5, "materialized\\3":Landroidx/compose/ui/Modifier;
    const/4 v2, 0x0

    move-object v6, v3

    .end local v3    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v6, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v3, 0x0

    move-object/from16 v22, v4

    .end local v4    # "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v22, "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const/4 v4, 0x0

    move-object/from16 v23, v5

    .end local v5    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v23, "materialized\\3":Landroidx/compose/ui/Modifier;
    const/4 v5, 0x0

    move-object/from16 v24, v6

    .end local v6    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v24, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v6, 0x0

    move-object/from16 v26, v8

    .end local v8    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v26, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v8, 0x0

    move-object/from16 v13, v22

    move-object/from16 v27, v23

    move-object/from16 v55, v59

    move/from16 v22, p2

    move-object/from16 v23, v7

    move-object v7, v0

    move-object/from16 v0, p0

    .end local v7    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v59    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local p2    # "$dirty":I
    .local v13, "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v22, "$dirty":I
    .local v23, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v27, "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v55, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 115
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    invoke-interface {v13, v0, v1}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v0, 0x8

    .local v0, "$this$dp\\28":I
    const/4 v1, 0x0

    .line 343
    .local v1, "$i$f$getDp\\28\\115":I
    int-to-float v3, v0

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 115
    .end local v0    # "$this$dp\\28":I
    .end local v1    # "$i$f$getDp\\28\\115":I
    const/16 v7, 0xd

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v2 .. v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "setup_advanced"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$SetupWizardKt;->getLambda$2045229739$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    shr-int/lit8 v0, v22, 0x3

    and-int/lit8 v0, v0, 0xe

    const/high16 v2, 0x30000000

    or-int v11, v0, v2

    const/16 v12, 0x1fc

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object/from16 v0, p1

    move-object/from16 v30, v13

    move-object/from16 v13, p0

    .end local v13    # "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v30, "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 97
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 118
    nop

    .line 295
    .end local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v30    # "$this$Welcome_u24lambda_u246\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v31    # "$changed\\9":I
    .end local v32    # "$i$a$-Column-SetupWizardKt$Welcome$1\\9\\295\\0":I
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 294
    .end local v28    # "$changed\\8":I
    .end local v29    # "$i$a$-Layout-ColumnKt$Column$1\\8\\294\\2":I
    .end local v55    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 344
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 273
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 345
    nop

    .line 267
    .end local v21    # "$changed\\4":I
    .end local v25    # "$i$f$ReusableComposeNode\\4\\271":I
    .end local v62    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 346
    nop

    .line 261
    .end local v18    # "$changed\\3":I
    .end local v19    # "$i$f$Layout\\3\\266":I
    .end local v20    # "compositeKeyHash\\3":I
    .end local v24    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v27    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 347
    nop

    .end local v16    # "$changed\\2":I
    .end local v17    # "$i$f$Column\\2\\96":I
    .end local v23    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v26    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v60    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v61    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_f
    :goto_9
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_10

    new-instance v2, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda0;

    invoke-direct {v2, v13, v0, v14}, Lorg/lighttouch/android/SetupWizardKt$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 119
    :cond_10
    return-void
.end method

.method private static final Welcome$lambda$7(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/SetupWizardKt;->Welcome(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$Creating(Ljava/lang/String;FLandroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "phase"    # Ljava/lang/String;
    .param p1, "progress"    # F
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/SetupWizardKt;->Creating(Ljava/lang/String;FLandroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$Done(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "name"    # Ljava/lang/String;
    .param p1, "timings"    # Ljava/lang/String;
    .param p2, "onFinish"    # Lkotlin/jvm/functions/Function1;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/SetupWizardKt;->Done(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$Files(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "state"    # Lorg/lighttouch/android/SetupState;
    .param p1, "onPickFolder"    # Lkotlin/jvm/functions/Function0;
    .param p2, "onPickSystem"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onPickRom"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onCreate"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p6, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p7, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/SetupWizardKt;->Files(Lorg/lighttouch/android/SetupState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$StageTimes$lambda$34(Landroidx/compose/runtime/MutableState;)Z
    .locals 1
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/SetupWizardKt;->StageTimes$lambda$34(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$Welcome(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p1, "onFiles"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/SetupWizardKt;->Welcome(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.class final Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;
.super Ljava/lang/Object;
.source "HomeScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/HomeScreenKt;->GuestScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/ui/Modifier;FZLandroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function4<",
        "Landroidx/compose/animation/AnimatedContentScope;",
        "Ljava/lang/String;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHomeScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt$GuestScreen$1$1\n+ 2 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 3 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 4 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 5 Composer.kt\nandroidx/compose/runtime/Updater\n+ 6 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 7 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 8 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n*L\n1#1,192:1\n71#2:193\n69#2,5:194\n74#2:227\n78#2:317\n79#3,6:199\n86#3,4:214\n90#3,2:224\n79#3,6:248\n86#3,4:263\n90#3,2:273\n94#3:294\n94#3:316\n368#4,9:205\n377#4:226\n368#4,9:254\n377#4:275\n378#4,2:292\n378#4,2:314\n4034#5,6:218\n4034#5,6:267\n1225#6,6:228\n1225#6,6:234\n1225#6,6:280\n1225#6,6:286\n1225#6,6:296\n1225#6,6:302\n1225#6,6:308\n149#7:240\n149#7:277\n149#7:278\n149#7:279\n86#8:241\n83#8,6:242\n89#8:276\n93#8:295\n*S KotlinDebug\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt$GuestScreen$1$1\n*L\n115#1:193\n115#1:194,5\n115#1:227\n115#1:317\n115#1:199,6\n115#1:214,4\n115#1:224,2\n122#1:248,6\n122#1:263,4\n122#1:273,2\n122#1:294\n115#1:316\n115#1:205,9\n115#1:226\n122#1:254,9\n122#1:275\n122#1:292,2\n115#1:314,2\n115#1:218,6\n122#1:267,6\n120#1:228,6\n121#1:234,6\n127#1:280,6\n128#1:286,6\n130#1:296,6\n131#1:302,6\n132#1:308,6\n122#1:240\n123#1:277\n124#1:278\n126#1:279\n122#1:241\n122#1:242,6\n122#1:276\n122#1:295\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;


# direct methods
.method public static synthetic $r8$lambda$IobYGiWzrr-_uTXN5-6D3ZtSlNk(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->invoke$lambda$12$lambda$3$lambda$2(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KClJ9cnuxFQvlutTipkyy2OS1fo(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->invoke$lambda$12$lambda$11$lambda$10(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$i0ut0SNsOP74CkHBN4jNRKzey3Q(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->invoke$lambda$12$lambda$9$lambda$8(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tjFs8KHch3U9pkFXE968N_mSeYY(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->invoke$lambda$12$lambda$1$lambda$0(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$12$lambda$1$lambda$0(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 120
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Lorg/lighttouch/android/GuestHost;->setPaused(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$12$lambda$11$lambda$10(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 132
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getBusy()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->start()V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$12$lambda$3$lambda$2(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 121
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Lorg/lighttouch/android/GuestHost;->pulse(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$12$lambda$9$lambda$8(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 131
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getBusy()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->recover()V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;
    .param p4, "p4"    # Ljava/lang/Object;

    .line 114
    move-object v0, p1

    check-cast v0, Landroidx/compose/animation/AnimatedContentScope;

    move-object v1, p2

    check-cast v1, Ljava/lang/String;

    move-object v2, p3

    check-cast v2, Landroidx/compose/runtime/Composer;

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->invoke(Landroidx/compose/animation/AnimatedContentScope;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/animation/AnimatedContentScope;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 73
    .param p1, "$this$AnimatedContent"    # Landroidx/compose/animation/AnimatedContentScope;
    .param p2, "shown"    # Ljava/lang/String;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    const-string v2, "$this$AnimatedContent"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C114@6716L1793:HomeScreen.kt#o13vsk"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, -0x1

    const-string v4, "org.lighttouch.android.GuestScreen.<anonymous>.<anonymous> (HomeScreen.kt:114)"

    const v5, 0x321de762

    move/from16 v6, p4

    invoke-static {v5, v6, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    goto :goto_0

    :cond_0
    move/from16 v6, p4

    .line 115
    :goto_0
    if-eqz v0, :cond_21

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x1

    invoke-static {v2, v4, v7, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    sget-object v2, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v9

    const-string v2, "asleep"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    const v4, 0x3eb33333    # 0.35f

    goto :goto_1

    :cond_1
    const v4, 0x3f333333    # 0.7f

    :goto_1
    move v11, v4

    const/16 v15, 0xe

    const/16 v16, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v9 .. v16}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v9

    const/4 v12, 0x2

    const/4 v13, 0x0

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 116
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v5

    .line 115
    move-object/from16 v8, p0

    iget-object v9, v8, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1;->$host:Lorg/lighttouch/android/GuestHost;

    const/16 v10, 0x30

    .local v4, "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v5, "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .local v10, "$changed\\1":I
    const/4 v11, 0x0

    .line 193
    .local v11, "$i$f$Box\\1\\115":I
    const v12, 0x2bb5b5d7

    const-string v13, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 194
    const/4 v12, 0x0

    .line 197
    .local v12, "propagateMinConstraints\\1":Z
    invoke-static {v5, v12}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v10, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 198
    nop

    .local v14, "$changed\\2":I
    const/4 v15, 0x0

    .line 199
    .local v15, "$i$f$Layout\\2\\198":I
    const v7, -0x4ee9b9da

    const-string v3, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 200
    const/4 v7, 0x0

    invoke-static {v1, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v18

    .line 201
    .local v18, "compositeKeyHash\\2":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 202
    .local v7, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v20, v5

    .end local v5    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .local v20, "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    invoke-static {v1, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 204
    .local v5, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    move-object/from16 v22, v4

    .end local v4    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\1":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v14, 0x6

    and-int/lit16 v4, v4, 0x380

    move/from16 v23, v4

    const/4 v4, 0x6

    or-int/lit8 v23, v23, 0x6

    .line 203
    move-object/from16 v24, v21

    .local v23, "$changed\\3":I
    .local v24, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v21, 0x0

    .line 205
    .local v21, "$i$f$ReusableComposeNode\\3\\203":I
    move/from16 v25, v4

    const v4, -0x2942ffcf

    const-string v6, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 206
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_2

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 207
    :cond_2
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 208
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_3

    .line 209
    move-object/from16 v4, v24

    .end local v24    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_2

    .line 211
    .end local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_3
    move-object/from16 v4, v24

    .end local v24    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 213
    :goto_2
    invoke-static/range {p3 .. p3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 214
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\213\\2":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v28, v4

    .end local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v28, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v1, v13, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 215
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v1, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 217
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 218
    .local v27, "$i$f$set-impl\\5\\217":I
    move-object/from16 v29, v1

    .local v29, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 219
    .local v30, "$i$a$-with-Updater$set$1\\6\\218\\5":I
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v31

    if-nez v31, :cond_5

    move-object/from16 v31, v7

    .end local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v31, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_4

    goto :goto_3

    :cond_4
    move-object/from16 v8, v29

    goto :goto_4

    .end local v31    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_5
    move-object/from16 v31, v7

    .line 220
    .end local v7    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v31    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_3
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v8, v29

    .end local v29    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 221
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v1, v7, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 223
    :goto_4
    nop

    .line 218
    .end local v8    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-with-Updater$set$1\\6\\218\\5":I
    nop

    .line 223
    nop

    .line 224
    .end local v4    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v27    # "$i$f$set-impl\\5\\217":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v1, v5, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 225
    nop

    .line 213
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\213\\2":I
    nop

    .line 226
    shr-int/lit8 v1, v23, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\7":I
    move-object/from16 v4, p3

    .local v4, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 227
    .local v7, "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    const v8, -0x7ff519f7    # -1.000876E-39f

    move/from16 v24, v1

    .end local v1    # "$changed\\7":I
    .local v24, "$changed\\7":I
    const-string v1, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v4, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v8, v10, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\8":I
    check-cast v1, Landroidx/compose/foundation/layout/BoxScope;

    .local v1, "$this$invoke_u24lambda_u2412\\8":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v37, v4

    .local v37, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 117
    .local v27, "$i$a$-Box-HomeScreenKt$GuestScreen$1$1$1\\8\\227\\0":I
    move-object/from16 v29, v1

    .end local v1    # "$this$invoke_u24lambda_u2412\\8":Landroidx/compose/foundation/layout/BoxScope;
    .local v29, "$this$invoke_u24lambda_u2412\\8":Landroidx/compose/foundation/layout/BoxScope;
    const v1, -0x1a60ebc3

    move-object/from16 v30, v4

    .end local v4    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v4, "C:HomeScreen.kt#o13vsk"

    move-object/from16 v40, v5

    move-object/from16 v5, v37

    .end local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v40, "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v5, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const-string v4, "CC(remember):HomeScreen.kt#9igjgp"

    move/from16 v32, v1

    const v1, 0x4c5de2

    sparse-switch v32, :sswitch_data_0

    move/from16 v41, v7

    move/from16 v42, v8

    const/4 v3, 0x0

    .end local v7    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .end local v8    # "$changed\\8":I
    .local v41, "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .local v42, "$changed\\8":I
    goto/16 :goto_12

    .end local v41    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .end local v42    # "$changed\\8":I
    .restart local v7    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .restart local v8    # "$changed\\8":I
    :sswitch_0
    const-string v2, "stopping"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    goto :goto_5

    .line 119
    :cond_6
    const v1, 0x28708379

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "118@6997L22"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v1, "\u6b63\u5728\u5173\u673a\u2026"

    move/from16 v2, v25

    invoke-static {v1, v5, v2}, Lorg/lighttouch/android/HomeScreenKt;->access$Busy(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    move/from16 v41, v7

    move/from16 v42, v8

    goto/16 :goto_1b

    .line 117
    :sswitch_1
    const-string v2, "starting"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    .line 118
    const v1, 0x28707c78

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "117@6941L21"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v1, "\u6b63\u5728\u542f\u52a8 iOS\u2026"

    const/4 v2, 0x6

    invoke-static {v1, v5, v2}, Lorg/lighttouch/android/HomeScreenKt;->access$Busy(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    move/from16 v41, v7

    move/from16 v42, v8

    goto/16 :goto_1b

    .line 117
    :cond_7
    :goto_5
    move/from16 v41, v7

    move/from16 v42, v8

    const/4 v3, 0x0

    goto/16 :goto_12

    :sswitch_2
    const-string v2, "paused"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8

    goto :goto_5

    .line 120
    :cond_8
    const v2, 0x28708aaa

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "119@7105L25,119@7052L103"

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtIcons;->getPlay()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v32

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\9":Z
    move-object v2, v5

    .local v2, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 228
    .local v3, "$i$f$cache\\9\\120":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\9":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 229
    .local v6, "$i$a$-let-ComposerKt$cache$1\\10\\228\\9":I
    if-nez v1, :cond_a

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v17, v1

    .end local v1    # "invalid\\9":Z
    .local v17, "invalid\\9":Z
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v4, v1, :cond_9

    goto :goto_6

    .line 233
    :cond_9
    move-object v1, v4

    goto :goto_7

    .line 229
    .end local v17    # "invalid\\9":Z
    .restart local v1    # "invalid\\9":Z
    :cond_a
    move/from16 v17, v1

    .line 230
    .end local v1    # "invalid\\9":Z
    .restart local v17    # "invalid\\9":Z
    :goto_6
    const/4 v1, 0x0

    .line 120
    .local v1, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$1\\11\\230\\8":I
    move/from16 v16, v1

    .end local v1    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$1\\11\\230\\8":I
    .local v16, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$1\\11\\230\\8":I
    new-instance v1, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda0;

    invoke-direct {v1, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 230
    .end local v16    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$1\\11\\230\\8":I
    nop

    .line 231
    .local v1, "value\\10":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 232
    nop

    .line 229
    .end local v1    # "value\\10":Ljava/lang/Object;
    :goto_7
    nop

    .line 228
    .end local v4    # "it\\9":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\10\\228\\9":I
    nop

    .line 120
    .end local v2    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\9\\120":I
    .end local v17    # "invalid\\9":Z
    move-object/from16 v34, v1

    check-cast v34, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v38, 0x6030

    const/16 v39, 0x8

    const-string v33, "\u5df2\u6682\u505c \u00b7 \u8f7b\u6309\u7ee7\u7eed"

    const/16 v35, 0x0

    const-string v36, "resume_overlay"

    move-object/from16 v37, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v39}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    move/from16 v41, v7

    move/from16 v42, v8

    goto/16 :goto_1b

    .line 117
    :sswitch_3
    const-string v2, "failed"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_b

    goto :goto_5

    .line 122
    :cond_b
    const v2, -0x1a5a93e6

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "121@7339L709"

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v2

    sget-object v16, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v1, v16

    check-cast v1, Landroidx/compose/ui/Modifier;

    move/from16 v41, v7

    .end local v7    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .restart local v41    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    const/16 v7, 0x10

    .local v7, "$this$dp\\15":I
    const/16 v16, 0x0

    .line 240
    .local v16, "$i$f$getDp\\15\\122":I
    move/from16 v42, v8

    .end local v8    # "$changed\\8":I
    .restart local v42    # "$changed\\8":I
    int-to-float v8, v7

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 122
    .end local v7    # "$this$dp\\15":I
    .end local v16    # "$i$f$getDp\\15\\122":I
    invoke-static {v1, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v7, 0x186

    .local v7, "$changed\\16":I
    const/4 v8, 0x0

    .line 241
    .local v8, "$i$f$Column\\16\\122":I
    move/from16 v16, v7

    .end local v7    # "$changed\\16":I
    .local v16, "$changed\\16":I
    const v7, -0x1cd0f17e

    move/from16 v33, v8

    .end local v8    # "$i$f$Column\\16\\122":I
    .local v33, "$i$f$Column\\16\\122":I
    const-string v8, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v5, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 242
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 246
    .local v7, "verticalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v8, v16, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v34, v16, 0x3

    and-int/lit8 v34, v34, 0x70

    or-int v8, v8, v34

    invoke-static {v7, v2, v5, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v2

    .local v2, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v16, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 247
    nop

    .local v8, "$changed\\17":I
    const/16 v34, 0x0

    .line 248
    .local v34, "$i$f$Layout\\17\\247":I
    move-object/from16 v35, v7

    const v7, -0x4ee9b9da

    .end local v7    # "verticalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v35, "verticalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 249
    const/4 v3, 0x0

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 250
    .local v3, "compositeKeyHash\\17":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 251
    .local v7, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v5, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 253
    .local v1, "materialized\\17":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move/from16 v19, v3

    .end local v3    # "compositeKeyHash\\17":I
    .local v19, "compositeKeyHash\\17":I
    shl-int/lit8 v3, v8, 0x6

    and-int/lit16 v3, v3, 0x380

    const/16 v25, 0x6

    or-int/lit8 v3, v3, 0x6

    .line 252
    nop

    .local v3, "$changed\\18":I
    move-object/from16 v36, v17

    .local v36, "factory\\18":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 254
    .local v17, "$i$f$ReusableComposeNode\\18\\252":I
    move/from16 v37, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\18":I
    .local v37, "$changed\\18":I
    invoke-static {v5, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 255
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 256
    :cond_c
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 257
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_d

    .line 258
    move-object/from16 v3, v36

    .end local v36    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_8

    .line 260
    .end local v3    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v36    # "factory\\18":Lkotlin/jvm/functions/Function0;
    :cond_d
    move-object/from16 v3, v36

    .end local v36    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 262
    :goto_8
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .local v6, "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 263
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\262\\17":I
    sget-object v36, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v38, v3

    .end local v3    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v38, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 264
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v6, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 266
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\20":Lkotlin/jvm/functions/Function2;
    const/16 v36, 0x0

    .line 267
    .local v36, "$i$f$set-impl\\20\\266":I
    move-object/from16 v39, v6

    .local v39, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 268
    .local v43, "$i$a$-with-Updater$set$1\\21\\267\\20":I
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_f

    move-object/from16 v44, v2

    .end local v2    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v44, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v45, v7

    .end local v7    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .local v45, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_e

    goto :goto_9

    :cond_e
    move-object/from16 v7, v39

    goto :goto_a

    .end local v44    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v45    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v2    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v7    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_f
    move-object/from16 v44, v2

    move-object/from16 v45, v7

    .line 269
    .end local v2    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v7    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v44    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v45    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_9
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v7, v39

    .end local v39    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 270
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v6, v2, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 272
    :goto_a
    nop

    .line 267
    .end local v7    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\21\\267\\20":I
    nop

    .line 272
    nop

    .line 273
    .end local v3    # "block\\20":Lkotlin/jvm/functions/Function2;
    .end local v36    # "$i$f$set-impl\\20\\266":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v6, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 274
    nop

    .line 262
    .end local v6    # "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\262\\17":I
    nop

    .line 275
    shr-int/lit8 v2, v37, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\22":I
    move-object v3, v5

    .local v3, "$composer\\22":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 276
    .local v6, "$i$a$-Layout-ColumnKt$Column$1\\22\\275\\16":I
    const v7, -0x16ef5699

    move-object/from16 v26, v1

    .end local v1    # "materialized\\17":Landroidx/compose/ui/Modifier;
    .local v26, "materialized\\17":Landroidx/compose/ui/Modifier;
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v7, v16, 0x6

    and-int/lit8 v7, v7, 0x70

    const/16 v25, 0x6

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\23":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$invoke_u24lambda_u2412_u24lambda_u246\\23":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v51, v3

    .local v51, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 123
    .local v36, "$i$a$-Column-HomeScreenKt$GuestScreen$1$1$1$3\\23\\276\\8":I
    move-object/from16 v39, v1

    .end local v1    # "$this$invoke_u24lambda_u2412_u24lambda_u246\\23":Landroidx/compose/foundation/layout/ColumnScope;
    .local v39, "$this$invoke_u24lambda_u2412_u24lambda_u246\\23":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x24d200b6

    move/from16 v43, v2

    .end local v2    # "$changed\\22":I
    .local v43, "$changed\\22":I
    const-string v2, "C122@7460L90,123@7575L29,124@7705L10,124@7629L128,125@7782L30:HomeScreen.kt#o13vsk"

    move-object/from16 v71, v3

    .end local v51    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\22":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v1}, Landroidx/compose/material/icons/filled/WarningKt;->getWarning(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v46

    sget-object v1, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v49

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x20

    .local v2, "$this$dp\\24":I
    const/16 v47, 0x0

    .line 277
    .local v47, "$i$f$getDp\\24\\123":I
    nop

    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\23":Landroidx/compose/runtime/Composer;
    int-to-float v3, v2

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 123
    .end local v2    # "$this$dp\\24":I
    .end local v47    # "$i$f$getDp\\24\\123":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v48

    const/16 v52, 0xdb0

    const/16 v53, 0x0

    const/16 v47, 0x0

    invoke-static/range {v46 .. v53}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 124
    move-object/from16 v3, v51

    .end local v51    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\25":I
    const/16 v46, 0x0

    .line 278
    .local v46, "$i$f$getDp\\25\\124":I
    move/from16 v72, v6

    .end local v6    # "$i$a$-Layout-ColumnKt$Column$1\\22\\275\\16":I
    .local v72, "$i$a$-Layout-ColumnKt$Column$1\\22\\275\\16":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 124
    .end local v2    # "$this$dp\\25":I
    .end local v46    # "$i$f$getDp\\25\\124":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v3, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 125
    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v48

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v66

    sget-object v1, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v1

    invoke-static {v1}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v58

    const/16 v69, 0x0

    const v70, 0xfdfa

    const-string v46, "iOS \u610f\u5916\u505c\u6b62"

    const-wide/16 v50, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const-wide/16 v55, 0x0

    const/16 v57, 0x0

    const-wide/16 v59, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v68, 0x186

    move-object/from16 v67, v3

    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v67, "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v70}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 126
    .end local v67    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xc

    .local v2, "$this$dp\\26":I
    const/4 v6, 0x0

    .line 279
    .local v6, "$i$f$getDp\\26\\126":I
    move/from16 v46, v6

    .end local v6    # "$i$f$getDp\\26\\126":I
    .local v46, "$i$f$getDp\\26\\126":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 126
    .end local v2    # "$this$dp\\26":I
    .end local v46    # "$i$f$getDp\\26\\126":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v3, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 127
    invoke-interface {v9}, Lorg/lighttouch/android/GuestHost;->getSessionOwned()Z

    move-result v1

    if-eqz v1, :cond_12

    const v1, -0x389e330f

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "126@7881L10,126@7860L58"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v1, 0x4c5de2

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\27":Z
    move-object v2, v3

    .local v2, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 280
    .local v4, "$i$f$cache\\27\\127":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\27":Ljava/lang/Object;
    const/16 v25, 0x0

    .line 281
    .local v25, "$i$a$-let-ComposerKt$cache$1\\28\\280\\27":I
    if-nez v1, :cond_11

    sget-object v32, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v46, v1

    .end local v1    # "invalid\\27":Z
    .local v46, "invalid\\27":Z
    invoke-virtual/range {v32 .. v32}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v6, v1, :cond_10

    goto :goto_b

    .line 285
    :cond_10
    move-object v1, v6

    goto :goto_c

    .line 281
    .end local v46    # "invalid\\27":Z
    .restart local v1    # "invalid\\27":Z
    :cond_11
    move/from16 v46, v1

    .line 282
    .end local v1    # "invalid\\27":Z
    .restart local v46    # "invalid\\27":Z
    :goto_b
    const/4 v1, 0x0

    .line 127
    .local v1, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$1\\29\\282\\23":I
    move/from16 v32, v1

    .end local v1    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$1\\29\\282\\23":I
    .local v32, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$1\\29\\282\\23":I
    new-instance v1, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$1$3$1$1;

    invoke-direct {v1, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$1$3$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v1, Lkotlin/reflect/KFunction;

    .line 282
    .end local v32    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$1\\29\\282\\23":I
    nop

    .line 283
    .local v1, "value\\28":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 284
    nop

    .line 281
    .end local v1    # "value\\28":Ljava/lang/Object;
    :goto_c
    nop

    .line 280
    .end local v6    # "it\\27":Ljava/lang/Object;
    .end local v25    # "$i$a$-let-ComposerKt$cache$1\\28\\280\\27":I
    nop

    .line 127
    .end local v2    # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\27\\127":I
    .end local v46    # "invalid\\27":Z
    check-cast v1, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v46, v1

    check-cast v46, Lkotlin/jvm/functions/Function0;

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$HomeScreenKt;->getLambda$580184207$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v55

    const/high16 v57, 0x30000000

    const/16 v58, 0x1fe

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    move-object/from16 v56, v3

    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .local v56, "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v58}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v56    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_f

    .line 128
    :cond_12
    const v1, -0x389e27fb

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "127@7989L13,127@7948L78"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getHistory()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v46

    const v1, 0x4c5de2

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\30":Z
    move-object v2, v3

    .local v2, "$this$cache\\30":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 286
    .local v4, "$i$f$cache\\30\\128":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\30":Ljava/lang/Object;
    const/16 v25, 0x0

    .line 287
    .local v25, "$i$a$-let-ComposerKt$cache$1\\31\\286\\30":I
    if-nez v1, :cond_14

    sget-object v32, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v47, v1

    .end local v1    # "invalid\\30":Z
    .local v47, "invalid\\30":Z
    invoke-virtual/range {v32 .. v32}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v6, v1, :cond_13

    goto :goto_d

    .line 291
    :cond_13
    move-object v1, v6

    goto :goto_e

    .line 287
    .end local v47    # "invalid\\30":Z
    .restart local v1    # "invalid\\30":Z
    :cond_14
    move/from16 v47, v1

    .line 288
    .end local v1    # "invalid\\30":Z
    .restart local v47    # "invalid\\30":Z
    :goto_d
    const/4 v1, 0x0

    .line 128
    .local v1, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$2\\32\\288\\23":I
    move/from16 v32, v1

    .end local v1    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$2\\32\\288\\23":I
    .local v32, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$2\\32\\288\\23":I
    new-instance v1, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$1$3$2$1;

    invoke-direct {v1, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$1$3$2$1;-><init>(Ljava/lang/Object;)V

    check-cast v1, Lkotlin/reflect/KFunction;

    .line 288
    .end local v32    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$3$2\\32\\288\\23":I
    nop

    .line 289
    .local v1, "value\\31":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 290
    nop

    .line 287
    .end local v1    # "value\\31":Ljava/lang/Object;
    :goto_e
    nop

    .line 286
    .end local v6    # "it\\30":Ljava/lang/Object;
    .end local v25    # "$i$a$-let-ComposerKt$cache$1\\31\\286\\30":I
    nop

    .line 128
    .end local v2    # "$this$cache\\30":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\30\\128":I
    .end local v47    # "invalid\\30":Z
    check-cast v1, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v48, v1

    check-cast v48, Lkotlin/jvm/functions/Function0;

    const/16 v52, 0x6030

    const/16 v53, 0x8

    const-string v47, "\u6062\u590d"

    const/16 v49, 0x0

    const-string v50, "recover_guest"

    move-object/from16 v51, v3

    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v53}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v51    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 123
    :goto_f
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 129
    nop

    .line 276
    .end local v3    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v7    # "$changed\\23":I
    .end local v36    # "$i$a$-Column-HomeScreenKt$GuestScreen$1$1$1$3\\23\\276\\8":I
    .end local v39    # "$this$invoke_u24lambda_u2412_u24lambda_u246\\23":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 275
    .end local v43    # "$changed\\22":I
    .end local v71    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .end local v72    # "$i$a$-Layout-ColumnKt$Column$1\\22\\275\\16":I
    nop

    .line 292
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 254
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 293
    nop

    .line 248
    .end local v17    # "$i$f$ReusableComposeNode\\18\\252":I
    .end local v37    # "$changed\\18":I
    .end local v38    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 294
    nop

    .line 241
    .end local v8    # "$changed\\17":I
    .end local v19    # "compositeKeyHash\\17":I
    .end local v26    # "materialized\\17":Landroidx/compose/ui/Modifier;
    .end local v34    # "$i$f$Layout\\17\\247":I
    .end local v45    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 295
    nop

    .line 122
    .end local v16    # "$changed\\16":I
    .end local v33    # "$i$f$Column\\16\\122":I
    .end local v35    # "verticalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v44    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto/16 :goto_1b

    .line 117
    .end local v41    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .end local v42    # "$changed\\8":I
    .local v7, "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .local v8, "$changed\\8":I
    :sswitch_4
    move/from16 v41, v7

    move/from16 v42, v8

    const/4 v3, 0x0

    .end local v7    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .end local v8    # "$changed\\8":I
    .restart local v41    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    .restart local v42    # "$changed\\8":I
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_15

    goto :goto_12

    .line 121
    :cond_15
    const v1, 0x28709bb9

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "120@7244L32,120@7188L118"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getPower()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    const v2, 0x4c5de2

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\12":Z
    move-object v3, v5

    .local v3, "$this$cache\\12":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 234
    .local v4, "$i$f$cache\\12\\121":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\12":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 235
    .local v7, "$i$a$-let-ComposerKt$cache$1\\13\\234\\12":I
    if-nez v2, :cond_17

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_16

    goto :goto_10

    .line 239
    :cond_16
    move-object v0, v6

    goto :goto_11

    .line 236
    :cond_17
    :goto_10
    const/4 v8, 0x0

    .line 121
    .local v8, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$2\\14\\236\\8":I
    new-instance v0, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda1;

    invoke-direct {v0, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 236
    .end local v8    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$2\\14\\236\\8":I
    nop

    .line 237
    .local v0, "value\\13":Ljava/lang/Object;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 238
    nop

    .line 235
    .end local v0    # "value\\13":Ljava/lang/Object;
    :goto_11
    nop

    .line 234
    .end local v6    # "it\\12":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\13\\234\\12":I
    nop

    .line 121
    .end local v2    # "invalid\\12":Z
    .end local v3    # "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\12\\121":I
    move-object/from16 v34, v0

    check-cast v34, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v38, 0x6030

    const/16 v39, 0x8

    const-string v33, "\u5c4f\u5e55\u5df2\u5173\u95ed \u00b7 \u8f7b\u6309\u5524\u9192"

    const/16 v35, 0x0

    const-string v36, "guest_screen_asleep"

    move-object/from16 v32, v1

    move-object/from16 v37, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v37, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v39}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto/16 :goto_1b

    .line 130
    :goto_12
    const v0, 0x28710bf3

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, ""

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v9}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v0

    if-nez v0, :cond_1a

    const v0, 0x28710e13

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "129@8148L15,129@8104L80"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getPhone()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const v1, 0x4c5de2

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\33":Z
    move-object v2, v5

    .local v2, "$this$cache\\33":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 296
    .local v3, "$i$f$cache\\33\\130":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\33":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 297
    .local v6, "$i$a$-let-ComposerKt$cache$1\\34\\296\\33":I
    if-nez v1, :cond_19

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_18

    goto :goto_13

    .line 301
    :cond_18
    move-object v8, v4

    goto :goto_14

    .line 298
    :cond_19
    :goto_13
    const/4 v7, 0x0

    .line 130
    .local v7, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$4\\35\\298\\8":I
    new-instance v8, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$1$4$1;

    invoke-direct {v8, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$1$4$1;-><init>(Ljava/lang/Object;)V

    check-cast v8, Lkotlin/reflect/KFunction;

    .line 298
    .end local v7    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$4\\35\\298\\8":I
    nop

    .line 299
    .local v8, "value\\34":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 300
    nop

    .line 297
    .end local v8    # "value\\34":Ljava/lang/Object;
    :goto_14
    nop

    .line 296
    .end local v4    # "it\\33":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\34\\296\\33":I
    nop

    .line 130
    .end local v1    # "invalid\\33":Z
    .end local v2    # "$this$cache\\33":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\33\\130":I
    check-cast v8, Lkotlin/reflect/KFunction;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v34, v8

    check-cast v34, Lkotlin/jvm/functions/Function0;

    const/16 v38, 0x6030

    const/16 v39, 0x8

    const-string v33, "\u6dfb\u52a0\u8bbe\u5907"

    const/16 v35, 0x0

    const-string v36, "add_device"

    move-object/from16 v32, v0

    move-object/from16 v37, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v39}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_1a

    .line 131
    :cond_1a
    invoke-interface {v9}, Lorg/lighttouch/android/GuestHost;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v0

    if-eqz v0, :cond_1b

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceSummary;->getDirty()Z

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1b

    move v7, v1

    goto :goto_15

    :cond_1b
    move v7, v3

    :goto_15
    if-eqz v7, :cond_1e

    const v0, 0x28712030

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "130@8299L34,130@8248L109"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getHistory()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const v1, 0x4c5de2

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\36":Z
    move-object v2, v5

    .local v2, "$this$cache\\36":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 302
    .local v3, "$i$f$cache\\36\\131":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\36":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 303
    .local v6, "$i$a$-let-ComposerKt$cache$1\\37\\302\\36":I
    if-nez v1, :cond_1d

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_1c

    goto :goto_16

    .line 307
    :cond_1c
    move-object v8, v4

    goto :goto_17

    .line 304
    :cond_1d
    :goto_16
    const/4 v7, 0x0

    .line 131
    .local v7, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$5\\38\\304\\8":I
    new-instance v8, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda2;

    invoke-direct {v8, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 304
    .end local v7    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$5\\38\\304\\8":I
    nop

    .line 305
    .local v8, "value\\37":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 306
    nop

    .line 303
    .end local v8    # "value\\37":Ljava/lang/Object;
    :goto_17
    nop

    .line 302
    .end local v4    # "it\\36":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\37\\302\\36":I
    nop

    .line 131
    .end local v1    # "invalid\\36":Z
    .end local v2    # "$this$cache\\36":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\36\\131":I
    move-object/from16 v34, v8

    check-cast v34, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v38, 0x6030

    const/16 v39, 0x8

    const-string v33, "\u6062\u590d\u5e76\u542f\u52a8"

    const/16 v35, 0x0

    const-string v36, "recover_guest"

    move-object/from16 v32, v0

    move-object/from16 v37, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v39}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_1a

    .line 132
    :cond_1e
    const v0, 0x2871317d

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "131@8423L32,131@8387L90"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getPlay()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const v1, 0x4c5de2

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\39":Z
    move-object v2, v5

    .local v2, "$this$cache\\39":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 308
    .local v3, "$i$f$cache\\39\\132":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\39":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 309
    .local v6, "$i$a$-let-ComposerKt$cache$1\\40\\308\\39":I
    if-nez v1, :cond_20

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_1f

    goto :goto_18

    .line 313
    :cond_1f
    move-object v8, v4

    goto :goto_19

    .line 310
    :cond_20
    :goto_18
    const/4 v7, 0x0

    .line 132
    .local v7, "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$6\\41\\310\\8":I
    new-instance v8, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda3;

    invoke-direct {v8, v9}, Lorg/lighttouch/android/HomeScreenKt$GuestScreen$1$1$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 310
    .end local v7    # "$i$a$-cache-HomeScreenKt$GuestScreen$1$1$1$6\\41\\310\\8":I
    nop

    .line 311
    .local v8, "value\\40":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 312
    nop

    .line 309
    .end local v8    # "value\\40":Ljava/lang/Object;
    :goto_19
    nop

    .line 308
    .end local v4    # "it\\39":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\40\\308\\39":I
    nop

    .line 132
    .end local v1    # "invalid\\39":Z
    .end local v2    # "$this$cache\\39":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\39\\132":I
    move-object/from16 v34, v8

    check-cast v34, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v38, 0x6030

    const/16 v39, 0x8

    const-string v33, "\u542f\u52a8"

    const/16 v35, 0x0

    const-string v36, "start_guest"

    move-object/from16 v32, v0

    move-object/from16 v37, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v39}, Lorg/lighttouch/android/ShellKt;->ScreenAction(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v37    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 130
    :goto_1a
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 117
    :goto_1b
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 134
    nop

    .line 227
    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-Box-HomeScreenKt$GuestScreen$1$1$1\\8\\227\\0":I
    .end local v29    # "$this$invoke_u24lambda_u2412\\8":Landroidx/compose/foundation/layout/BoxScope;
    .end local v42    # "$changed\\8":I
    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 226
    .end local v24    # "$changed\\7":I
    .end local v30    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v41    # "$i$a$-Layout-BoxKt$Box$1\\7\\226\\1":I
    nop

    .line 314
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 205
    invoke-static/range {p3 .. p3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 315
    nop

    .line 199
    .end local v21    # "$i$f$ReusableComposeNode\\3\\203":I
    .end local v23    # "$changed\\3":I
    .end local v28    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p3 .. p3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 316
    nop

    .line 193
    .end local v14    # "$changed\\2":I
    .end local v15    # "$i$f$Layout\\2\\198":I
    .end local v18    # "compositeKeyHash\\2":I
    .end local v31    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v40    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {p3 .. p3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 317
    nop

    .end local v10    # "$changed\\1":I
    .end local v11    # "$i$f$Box\\1\\115":I
    .end local v12    # "propagateMinConstraints\\1":Z
    .end local v13    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .end local v22    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :cond_21
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 135
    :cond_22
    return-void

    :sswitch_data_0
    .sparse-switch
        -0x53f2bcea -> :sswitch_4
        -0x4c696bc3 -> :sswitch_3
        -0x3b5366d2 -> :sswitch_2
        0x4e7ce040 -> :sswitch_1
        0x6642b874 -> :sswitch_0
    .end sparse-switch
.end method

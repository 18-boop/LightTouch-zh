.class final Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;
.super Ljava/lang/Object;
.source "DeviceDetails.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeviceDetails.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeviceDetails.kt\norg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,189:1\n1#2:190\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $device:Lorg/lighttouch/android/DeviceSummary;

.field final synthetic $f:Lorg/lighttouch/android/DeviceFacts;


# direct methods
.method constructor <init>(Lorg/lighttouch/android/DeviceFacts;Lorg/lighttouch/android/DeviceSummary;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$f:Lorg/lighttouch/android/DeviceFacts;

    iput-object p2, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 157
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 9
    .param p1, "$this$Section"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$Section"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C162@10368L25,163@10436L69:DeviceDetails.kt#o13vsk"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move v0, p3

    .local v0, "$dirty":I
    and-int/lit8 v1, p3, 0x6

    if-nez v1, :cond_1

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    :goto_0
    or-int/2addr v0, v1

    :cond_1
    and-int/lit8 v1, v0, 0x13

    const/16 v2, 0x12

    if-ne v1, v2, :cond_3

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_1

    .line 164
    :cond_2
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_7

    .line 0
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.DeviceDetails.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DeviceDetails.kt:157)"

    const v3, -0x4e3b087e

    invoke-static {v3, v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 158
    :cond_4
    iget-object v1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$f:Lorg/lighttouch/android/DeviceFacts;

    const/4 v2, 0x0

    if-eqz v1, :cond_5

    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceFacts;->getToolsSerial()Ljava/lang/Integer;

    move-result-object v1

    goto :goto_2

    :cond_5
    move-object v1, v2

    :goto_2
    const v3, 0x546524aa

    invoke-interface {p2, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*157@9929L96"

    invoke-static {p2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x6

    if-nez v1, :cond_6

    goto :goto_4

    :cond_6
    iget-object v4, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$f:Lorg/lighttouch/android/DeviceFacts;

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    .line 190
    .local v1, "it\\1":I
    const/4 v5, 0x0

    .line 158
    .local v5, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$4$1\\1\\158\\0":I
    invoke-virtual {v4}, Lorg/lighttouch/android/DeviceFacts;->getToolsVerdict()Ljava/lang/String;

    move-result-object v6

    const-string v7, "good"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    const-string v4, ""

    goto :goto_3

    :cond_7
    invoke-virtual {v4}, Lorg/lighttouch/android/DeviceFacts;->getToolsVerdict()Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, ")"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_3
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u5e8f\u5217\u53f7 "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v6, "\u5ba2\u6237\u673a\u5de5\u5177"

    invoke-static {v6, v4, p2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .end local v1    # "it\\1":I
    .end local v5    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$4$1\\1\\158\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_4
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 159
    iget-object v1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$f:Lorg/lighttouch/android/DeviceFacts;

    if-eqz v1, :cond_8

    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceFacts;->getCreated()Ljava/lang/String;

    move-result-object v2

    :cond_8
    const v1, 0x546536f9

    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "*159@10109L208"

    invoke-static {p2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v2, :cond_9

    goto :goto_6

    .local v2, "created\\2":Ljava/lang/String;
    :cond_9
    const/4 v1, 0x0

    .line 160
    .local v1, "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$4$2\\2\\159\\0":I
    :try_start_0
    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v4, p1

    .line 190
    .local v4, "$this$invoke_u24lambda_u242_u24lambda_u241\\3":Landroidx/compose/foundation/layout/ColumnScope;
    const/4 v5, 0x0

    .line 160
    .local v5, "$i$a$-runCatching-DeviceDetailsKt$DeviceDetails$4$1$2$1$4$2$1\\3\\160\\2":I
    sget-object v6, Ljava/time/format/FormatStyle;->MEDIUM:Ljava/time/format/FormatStyle;

    invoke-static {v6}, Ljava/time/format/DateTimeFormatter;->ofLocalizedDateTime(Ljava/time/format/FormatStyle;)Ljava/time/format/DateTimeFormatter;

    move-result-object v6

    .line 161
    move-object v7, v2

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Ljava/time/Instant;->parse(Ljava/lang/CharSequence;)Ljava/time/Instant;

    move-result-object v7

    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    move-result-object v7

    check-cast v7, Ljava/time/temporal/TemporalAccessor;

    invoke-virtual {v6, v7}, Ljava/time/format/DateTimeFormatter;->format(Ljava/time/temporal/TemporalAccessor;)Ljava/lang/String;

    move-result-object v6

    .line 160
    .end local v4    # "$this$invoke_u24lambda_u242_u24lambda_u241\\3":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v5    # "$i$a$-runCatching-DeviceDetailsKt$DeviceDetails$4$1$2$1$4$2$1\\3\\160\\2":I
    invoke-static {v6}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_5

    :catchall_0
    move-exception v4

    sget-object v5, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v4}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .line 161
    :goto_5
    invoke-static {v4}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_a

    move-object v4, v2

    :cond_a
    const-string v5, "getOrDefault(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/String;

    .line 160
    const-string v5, "\u5df2\u51c6\u5907"

    invoke-static {v5, v4, p2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 162
    nop

    .line 159
    .end local v1    # "$i$a$-let-DeviceDetailsKt$DeviceDetails$4$1$2$1$4$2\\2\\159\\0":I
    .end local v2    # "created\\2":Ljava/lang/String;
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_6
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 163
    iget-object v1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getId()Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u8bb0\u5f55"

    invoke-static {v2, v1, p2, v3}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 164
    iget-object v1, p0, Lorg/lighttouch/android/DeviceDetailsKt$DeviceDetails$4$1$2$1$4;->$device:Lorg/lighttouch/android/DeviceSummary;

    invoke-virtual {v1}, Lorg/lighttouch/android/DeviceSummary;->getDirty()Z

    move-result v1

    if-eqz v1, :cond_b

    const-string v1, "\u672a\u6b63\u5e38\u5173\u673a\uff1b\u4e0b\u6b21\u542f\u52a8\u65f6\u4f1a\u81ea\u52a8\u6062\u590d"

    const/16 v2, 0x36

    const-string v3, "\u72b6\u6001"

    invoke-static {v3, v1, p2, v2}, Lorg/lighttouch/android/DeviceDetailsKt;->access$Fact(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    :cond_b
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 165
    :cond_c
    :goto_7
    return-void
.end method

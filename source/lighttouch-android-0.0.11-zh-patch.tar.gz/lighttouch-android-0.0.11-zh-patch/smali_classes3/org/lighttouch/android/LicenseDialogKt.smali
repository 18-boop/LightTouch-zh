.class public final Lorg/lighttouch/android/LicenseDialogKt;
.super Ljava/lang/Object;
.source "LicenseDialog.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLicenseDialog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LicenseDialog.kt\norg/lighttouch/android/LicenseDialogKt\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,85:1\n1740#2,3:86\n77#3:89\n1225#4,6:90\n1225#4,6:96\n1225#4,6:102\n1225#4,6:108\n1225#4,6:114\n1225#4,6:120\n81#5:126\n107#5,2:127\n81#5:129\n107#5,2:130\n81#5:132\n107#5,2:133\n81#5:135\n107#5,2:136\n*S KotlinDebug\n*F\n+ 1 LicenseDialog.kt\norg/lighttouch/android/LicenseDialogKt\n*L\n20#1:86,3\n26#1:89\n27#1:90,6\n28#1:96,6\n29#1:102,6\n30#1:108,6\n31#1:114,6\n50#1:120,6\n27#1:126\n27#1:127,2\n28#1:129\n28#1:130,2\n29#1:132\n29#1:133,2\n30#1:135\n30#1:136,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000>\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u001a\u0010\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0000\u001a\u001b\u0010\u0004\u001a\u00020\u00052\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0007H\u0001\u00a2\u0006\u0002\u0010\u0008\u001a,\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\u00032\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00050\u000eH\u0002\u00a8\u0006\u000f\u00b2\u0006\u0010\u0010\u0010\u001a\u0008\u0012\u0004\u0012\u00020\u00120\u0011X\u008a\u008e\u0002\u00b2\u0006$\u0010\u0013\u001a\u001c\u0012\u0004\u0012\u00020\u0012\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u0014\u0018\u00010\u0014X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u0015\u001a\u00020\u0003X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u0016\u001a\u00020\u0003X\u008a\u008e\u0002"
    }
    d2 = {
        "checkedNoticePath",
        "",
        "path",
        "",
        "LicenseDialog",
        "",
        "onClose",
        "Lkotlin/Function0;",
        "(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "openSource",
        "context",
        "Landroid/content/Context;",
        "reference",
        "fail",
        "Lkotlin/Function1;",
        "app_debug",
        "groups",
        "",
        "Lorg/lighttouch/android/NoticeGroup;",
        "selected",
        "Lkotlin/Pair;",
        "text",
        "failure"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$WyxsaBCa2YGhPSYDP1ofihcTdjc(Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$15(Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final LicenseDialog(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 28
    .param p0, "onClose"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    const-string v1, "onClose"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    const v1, 0x5b1125b2

    move-object/from16 v2, p1

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(LicenseDialog)25@924L7,26@950L59,27@1030L75,28@1122L31,29@1173L31,30@1230L1110,30@1209L1131,49@2370L656,49@2345L681,74@4191L51,75@4268L106,61@3079L59,62@3155L1010,61@3031L1344:LicenseDialog.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, p2, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 62
    :cond_2
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v18, v2

    move/from16 v27, v3

    goto/16 :goto_a

    .line 25
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v6, "org.lighttouch.android.LicenseDialog (LicenseDialog.kt:24)"

    invoke-static {v1, v3, v4, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 26
    :cond_4
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v1

    check-cast v1, Landroidx/compose/runtime/CompositionLocal;

    .local v1, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v4, 0x0

    .local v4, "$changed\\1":I
    const/4 v6, 0x0

    .line 89
    .local v6, "$i$f$getCurrent\\1\\26":I
    const v7, 0x789c5f52

    const-string v8, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v2, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 26
    .end local v1    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v4    # "$changed\\1":I
    .end local v6    # "$i$f$getCurrent\\1\\26":I
    move-object v9, v7

    check-cast v9, Landroid/content/Context;

    .local v9, "context":Landroid/content/Context;
    const v1, 0x6e3c21fe

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "CC(remember):LicenseDialog.kt#9igjgp"

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 27
    const/4 v6, 0x0

    move v7, v6

    .local v7, "invalid\\2":Z
    move-object v8, v2

    .local v8, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 90
    .local v10, "$i$f$cache\\2\\27":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\2":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 91
    .local v12, "$i$a$-let-ComposerKt$cache$1\\3\\90\\2":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    const/4 v14, 0x0

    if-ne v11, v13, :cond_5

    .line 92
    const/4 v13, 0x0

    .line 27
    .local v13, "$i$a$-cache-LicenseDialogKt$LicenseDialog$groups$2\\4\\92\\0":I
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v15

    invoke-static {v15, v14, v5, v14}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v13

    .line 92
    .end local v13    # "$i$a$-cache-LicenseDialogKt$LicenseDialog$groups$2\\4\\92\\0":I
    nop

    .line 93
    .local v13, "value\\3":Ljava/lang/Object;
    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 94
    nop

    .end local v13    # "value\\3":Ljava/lang/Object;
    goto :goto_2

    .line 95
    :cond_5
    move-object v13, v11

    .line 91
    :goto_2
    nop

    .line 90
    .end local v11    # "it\\2":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\3\\90\\2":I
    nop

    .line 27
    .end local v7    # "invalid\\2":Z
    .end local v8    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\2\\27":I
    move-object v7, v13

    check-cast v7, Landroidx/compose/runtime/MutableState;

    .local v7, "groups$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 28
    move-object v8, v2

    .local v8, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    move v10, v6

    .local v10, "invalid\\5":Z
    const/4 v11, 0x0

    .line 96
    .local v11, "$i$f$cache\\5\\28":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\5":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 97
    .local v13, "$i$a$-let-ComposerKt$cache$1\\6\\96\\5":I
    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v12, v15, :cond_6

    .line 98
    const/4 v15, 0x0

    .line 28
    .local v15, "$i$a$-cache-LicenseDialogKt$LicenseDialog$selected$2\\7\\98\\0":I
    invoke-static {v14, v14, v5, v14}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v15

    .line 98
    .end local v15    # "$i$a$-cache-LicenseDialogKt$LicenseDialog$selected$2\\7\\98\\0":I
    nop

    .line 99
    .local v15, "value\\6":Ljava/lang/Object;
    invoke-interface {v8, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 100
    nop

    .end local v15    # "value\\6":Ljava/lang/Object;
    goto :goto_3

    .line 101
    :cond_6
    move-object v15, v12

    .line 97
    :goto_3
    nop

    .line 96
    .end local v12    # "it\\5":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\6\\96\\5":I
    nop

    .line 28
    .end local v8    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v10    # "invalid\\5":Z
    .end local v11    # "$i$f$cache\\5\\28":I
    move-object v10, v15

    check-cast v10, Landroidx/compose/runtime/MutableState;

    .local v10, "selected$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 29
    move-object v8, v2

    .local v8, "$this$cache\\8":Landroidx/compose/runtime/Composer;
    move v11, v6

    .local v11, "invalid\\8":Z
    const/4 v12, 0x0

    .line 102
    .local v12, "$i$f$cache\\8\\29":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\8":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 103
    .local v15, "$i$a$-let-ComposerKt$cache$1\\9\\102\\8":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p1, v6

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    const-string v1, ""

    if-ne v13, v6, :cond_7

    .line 104
    const/4 v6, 0x0

    .line 29
    .local v6, "$i$a$-cache-LicenseDialogKt$LicenseDialog$text$2\\10\\104\\0":I
    invoke-static {v1, v14, v5, v14}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v6

    .line 104
    .end local v6    # "$i$a$-cache-LicenseDialogKt$LicenseDialog$text$2\\10\\104\\0":I
    nop

    .line 105
    .local v6, "value\\9":Ljava/lang/Object;
    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 106
    nop

    .end local v6    # "value\\9":Ljava/lang/Object;
    goto :goto_4

    .line 107
    :cond_7
    move-object v6, v13

    .line 103
    :goto_4
    nop

    .line 102
    .end local v13    # "it\\8":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\9\\102\\8":I
    nop

    .line 29
    .end local v8    # "$this$cache\\8":Landroidx/compose/runtime/Composer;
    .end local v11    # "invalid\\8":Z
    .end local v12    # "$i$f$cache\\8\\29":I
    move-object v13, v6

    check-cast v13, Landroidx/compose/runtime/MutableState;

    .local v13, "text$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v6, 0x6e3c21fe

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 30
    move/from16 v6, p1

    .local v6, "invalid\\11":Z
    move-object v8, v2

    .local v8, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 108
    .local v11, "$i$f$cache\\11\\30":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\11":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 109
    .local v15, "$i$a$-let-ComposerKt$cache$1\\12\\108\\11":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v12, v5, :cond_8

    .line 110
    const/4 v5, 0x0

    .line 30
    .local v5, "$i$a$-cache-LicenseDialogKt$LicenseDialog$failure$2\\13\\110\\0":I
    move/from16 v16, v3

    const/4 v3, 0x2

    .end local v3    # "$dirty":I
    .local v16, "$dirty":I
    invoke-static {v1, v14, v3, v14}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v1

    .line 110
    .end local v5    # "$i$a$-cache-LicenseDialogKt$LicenseDialog$failure$2\\13\\110\\0":I
    nop

    .line 111
    .local v1, "value\\12":Ljava/lang/Object;
    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 112
    nop

    .end local v1    # "value\\12":Ljava/lang/Object;
    goto :goto_5

    .line 113
    .end local v16    # "$dirty":I
    .restart local v3    # "$dirty":I
    :cond_8
    move/from16 v16, v3

    .end local v3    # "$dirty":I
    .restart local v16    # "$dirty":I
    move-object v1, v12

    .line 109
    :goto_5
    nop

    .line 108
    .end local v12    # "it\\11":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\12\\108\\11":I
    nop

    .line 30
    .end local v6    # "invalid\\11":Z
    .end local v8    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\11\\30":I
    move-object v12, v1

    check-cast v12, Landroidx/compose/runtime/MutableState;

    .local v12, "failure$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 31
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const v3, -0x6815fd56

    invoke-interface {v2, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v2, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\14":Z
    move-object v5, v2

    .local v5, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 114
    .local v6, "$i$f$cache\\14\\31":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\14":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 115
    .local v11, "$i$a$-let-ComposerKt$cache$1\\15\\114\\14":I
    if-nez v3, :cond_a

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v8, v15, :cond_9

    goto :goto_6

    .line 119
    :cond_9
    move/from16 v17, v3

    move-object v3, v8

    goto :goto_7

    .line 116
    :cond_a
    :goto_6
    const/4 v15, 0x0

    .line 31
    .local v15, "$i$a$-cache-LicenseDialogKt$LicenseDialog$1\\16\\116\\0":I
    move/from16 v17, v3

    .end local v3    # "invalid\\14":Z
    .local v17, "invalid\\14":Z
    new-instance v3, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1;

    invoke-direct {v3, v9, v7, v12, v14}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$1$1;-><init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 116
    .end local v15    # "$i$a$-cache-LicenseDialogKt$LicenseDialog$1\\16\\116\\0":I
    nop

    .line 117
    .local v3, "value\\15":Ljava/lang/Object;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    nop

    .line 115
    .end local v3    # "value\\15":Ljava/lang/Object;
    :goto_7
    nop

    .line 114
    .end local v8    # "it\\14":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\15\\114\\14":I
    nop

    .line 31
    .end local v5    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\14\\31":I
    .end local v17    # "invalid\\14":Z
    check-cast v3, Lkotlin/jvm/functions/Function2;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v5, 0x6

    invoke-static {v1, v3, v2, v5}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 50
    invoke-static {v10}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$5(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v1

    const v3, -0x48fade91

    invoke-interface {v2, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v2, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\17":Z
    move-object v4, v2

    .local v4, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 120
    .local v5, "$i$f$cache\\17\\50":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\17":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 121
    .local v14, "$i$a$-let-ComposerKt$cache$1\\18\\120\\17":I
    if-nez v3, :cond_c

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_b

    goto :goto_8

    .line 125
    :cond_b
    move-object v8, v6

    move-object v11, v9

    move-object v9, v13

    goto :goto_9

    .line 122
    :cond_c
    :goto_8
    const/4 v15, 0x0

    .line 50
    .local v15, "$i$a$-cache-LicenseDialogKt$LicenseDialog$2\\19\\122\\0":I
    new-instance v8, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$2$1;

    move-object v11, v9

    move-object v9, v13

    .end local v13    # "text$delegate":Landroidx/compose/runtime/MutableState;
    .local v9, "text$delegate":Landroidx/compose/runtime/MutableState;
    .local v11, "context":Landroid/content/Context;
    const/4 v13, 0x0

    invoke-direct/range {v8 .. v13}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$2$1;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroid/content/Context;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v8, Lkotlin/jvm/functions/Function2;

    .line 122
    .end local v15    # "$i$a$-cache-LicenseDialogKt$LicenseDialog$2\\19\\122\\0":I
    nop

    .line 123
    .local v8, "value\\18":Ljava/lang/Object;
    invoke-interface {v4, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 124
    nop

    .line 121
    .end local v8    # "value\\18":Ljava/lang/Object;
    :goto_9
    nop

    .line 120
    .end local v6    # "it\\17":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\18\\120\\17":I
    nop

    .line 50
    .end local v3    # "invalid\\17":Z
    .end local v4    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\17\\50":I
    check-cast v8, Lkotlin/jvm/functions/Function2;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v3, p1

    invoke-static {v1, v8, v2, v3}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 62
    nop

    .line 75
    new-instance v1, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$3;

    invoke-direct {v1, v0}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$3;-><init>(Lkotlin/jvm/functions/Function0;)V

    const v3, -0x77f4ad96

    const/4 v4, 0x1

    const/16 v5, 0x36

    invoke-static {v3, v4, v1, v2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function2;

    .line 76
    new-instance v3, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$4;

    invoke-direct {v3, v10, v12}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$4;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v6, -0x6db2cd8

    invoke-static {v6, v4, v3, v2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 62
    new-instance v6, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$5;

    invoke-direct {v6, v10}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$5;-><init>(Landroidx/compose/runtime/MutableState;)V

    const v8, 0x6a3e53e6

    invoke-static {v8, v4, v6, v2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    check-cast v6, Lkotlin/jvm/functions/Function2;

    .line 63
    new-instance v8, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$6;

    move-object v13, v9

    move-object v9, v11

    move-object v11, v10

    move-object v10, v12

    move-object v12, v7

    .end local v7    # "groups$delegate":Landroidx/compose/runtime/MutableState;
    .local v9, "context":Landroid/content/Context;
    .local v10, "failure$delegate":Landroidx/compose/runtime/MutableState;
    .local v11, "selected$delegate":Landroidx/compose/runtime/MutableState;
    .local v12, "groups$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v13    # "text$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct/range {v8 .. v13}, Lorg/lighttouch/android/LicenseDialogKt$LicenseDialog$6;-><init>(Landroid/content/Context;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    move-object/from16 v22, v9

    move-object/from16 v26, v10

    move-object/from16 v24, v11

    move-object/from16 v23, v12

    move-object/from16 v25, v13

    .end local v9    # "context":Landroid/content/Context;
    .end local v10    # "failure$delegate":Landroidx/compose/runtime/MutableState;
    .end local v11    # "selected$delegate":Landroidx/compose/runtime/MutableState;
    .end local v12    # "groups$delegate":Landroidx/compose/runtime/MutableState;
    .end local v13    # "text$delegate":Landroidx/compose/runtime/MutableState;
    .local v22, "context":Landroid/content/Context;
    .local v23, "groups$delegate":Landroidx/compose/runtime/MutableState;
    .local v24, "selected$delegate":Landroidx/compose/runtime/MutableState;
    .local v25, "text$delegate":Landroidx/compose/runtime/MutableState;
    .local v26, "failure$delegate":Landroidx/compose/runtime/MutableState;
    const v7, 0x22cb1445

    invoke-static {v7, v4, v8, v2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    check-cast v4, Lkotlin/jvm/functions/Function2;

    and-int/lit8 v5, v16, 0xe

    const v7, 0x1b0c30

    or-int v19, v5, v7

    .line 62
    move-object/from16 v18, v2

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v18, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    move-object v5, v6

    move-object v6, v4

    const/4 v4, 0x0

    const/4 v7, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v14, 0x0

    move/from16 v17, v16

    .end local v16    # "$dirty":I
    .local v17, "$dirty":I
    const/16 v16, 0x0

    move/from16 v20, v17

    .end local v17    # "$dirty":I
    .local v20, "$dirty":I
    const/16 v17, 0x0

    move/from16 v21, v20

    .end local v20    # "$dirty":I
    .local v21, "$dirty":I
    const/16 v20, 0x0

    move/from16 v27, v21

    .end local v21    # "$dirty":I
    .local v27, "$dirty":I
    const/16 v21, 0x3f94

    invoke-static/range {v0 .. v21}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v22    # "context":Landroid/content/Context;
    .end local v23    # "groups$delegate":Landroidx/compose/runtime/MutableState;
    .end local v24    # "selected$delegate":Landroidx/compose/runtime/MutableState;
    .end local v25    # "text$delegate":Landroidx/compose/runtime/MutableState;
    .end local v26    # "failure$delegate":Landroidx/compose/runtime/MutableState;
    :cond_d
    :goto_a
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_e

    new-instance v2, Lorg/lighttouch/android/LicenseDialogKt$$ExternalSyntheticLambda0;

    move/from16 v3, p2

    invoke-direct {v2, v0, v3}, Lorg/lighttouch/android/LicenseDialogKt$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_b

    :cond_e
    move/from16 v3, p2

    .line 77
    :goto_b
    return-void
.end method

.method private static final LicenseDialog$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 4
    .param p0, "$failure$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 30
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 135
    .local v3, "$i$f$getValue\\1\\30":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\30":I
    check-cast v0, Ljava/lang/String;

    .line 30
    return-object v0
.end method

.method private static final LicenseDialog$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 4
    .param p0, "$failure$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 30
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 136
    .local v3, "$i$f$setValue\\1\\30":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 137
    nop

    .line 30
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\30":I
    return-void
.end method

.method private static final LicenseDialog$lambda$15(Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final LicenseDialog$lambda$2(Landroidx/compose/runtime/MutableState;)Ljava/util/List;
    .locals 4
    .param p0, "$groups$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/NoticeGroup;",
            ">;>;)",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/NoticeGroup;",
            ">;"
        }
    .end annotation

    .line 27
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 126
    .local v3, "$i$f$getValue\\1\\27":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\27":I
    check-cast v0, Ljava/util/List;

    .line 27
    return-object v0
.end method

.method private static final LicenseDialog$lambda$3(Landroidx/compose/runtime/MutableState;Ljava/util/List;)V
    .locals 4
    .param p0, "$groups$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/NoticeGroup;",
            ">;>;",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/NoticeGroup;",
            ">;)V"
        }
    .end annotation

    .line 27
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 127
    .local v3, "$i$f$setValue\\1\\27":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 128
    nop

    .line 27
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\27":I
    return-void
.end method

.method private static final LicenseDialog$lambda$5(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;
    .locals 4
    .param p0, "$selected$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lkotlin/Pair<",
            "Lorg/lighttouch/android/NoticeGroup;",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;>;)",
            "Lkotlin/Pair<",
            "Lorg/lighttouch/android/NoticeGroup;",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .line 28
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 129
    .local v3, "$i$f$getValue\\1\\28":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\28":I
    check-cast v0, Lkotlin/Pair;

    .line 28
    return-object v0
.end method

.method private static final LicenseDialog$lambda$6(Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)V
    .locals 4
    .param p0, "$selected$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lkotlin/Pair<",
            "Lorg/lighttouch/android/NoticeGroup;",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;>;",
            "Lkotlin/Pair<",
            "Lorg/lighttouch/android/NoticeGroup;",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .line 28
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 130
    .local v3, "$i$f$setValue\\1\\28":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 131
    nop

    .line 28
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\28":I
    return-void
.end method

.method private static final LicenseDialog$lambda$8(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 4
    .param p0, "$text$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 29
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 132
    .local v3, "$i$f$getValue\\1\\29":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\29":I
    check-cast v0, Ljava/lang/String;

    .line 29
    return-object v0
.end method

.method private static final LicenseDialog$lambda$9(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 4
    .param p0, "$text$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 29
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 133
    .local v3, "$i$f$setValue\\1\\29":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 134
    nop

    .line 29
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\29":I
    return-void
.end method

.method public static final synthetic access$LicenseDialog$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 1
    .param p0, "$failure$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$11(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$LicenseDialog$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 0
    .param p0, "$failure$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$12(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$LicenseDialog$lambda$2(Landroidx/compose/runtime/MutableState;)Ljava/util/List;
    .locals 1
    .param p0, "$groups$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$2(Landroidx/compose/runtime/MutableState;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$LicenseDialog$lambda$3(Landroidx/compose/runtime/MutableState;Ljava/util/List;)V
    .locals 0
    .param p0, "$groups$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/util/List;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$3(Landroidx/compose/runtime/MutableState;Ljava/util/List;)V

    return-void
.end method

.method public static final synthetic access$LicenseDialog$lambda$5(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;
    .locals 1
    .param p0, "$selected$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$5(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$LicenseDialog$lambda$6(Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)V
    .locals 0
    .param p0, "$selected$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lkotlin/Pair;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$6(Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)V

    return-void
.end method

.method public static final synthetic access$LicenseDialog$lambda$8(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .locals 1
    .param p0, "$text$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$8(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$LicenseDialog$lambda$9(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .locals 0
    .param p0, "$text$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/LicenseDialogKt;->LicenseDialog$lambda$9(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$openSource(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .locals 0
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "reference"    # Ljava/lang/String;
    .param p2, "fail"    # Lkotlin/jvm/functions/Function1;

    .line 1
    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/LicenseDialogKt;->openSource(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method public static final checkedNoticePath(Ljava/lang/String;)Z
    .locals 11
    .param p0, "path"    # Ljava/lang/String;

    const-string v0, "path"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    move-object v1, p0

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v0, 0x1

    new-array v2, v0, [C

    const/4 v7, 0x0

    const/16 v3, 0x2f

    aput-char v3, v2, v7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$all\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 86
    .local v2, "$i$f$all\\1\\20":I
    instance-of v3, v1, Ljava/util/Collection;

    if-eqz v3, :cond_0

    move-object v3, v1

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    goto :goto_2

    .line 87
    :cond_0
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\1":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ljava/lang/String;

    .local v5, "it\\2":Ljava/lang/String;
    const/4 v6, 0x0

    .line 21
    .local v6, "$i$a$-all-LicenseDialogKt$checkedNoticePath$1\\2\\87\\0":I
    move-object v8, v5

    check-cast v8, Ljava/lang/CharSequence;

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-lez v8, :cond_2

    move v8, v0

    goto :goto_0

    :cond_2
    move v8, v7

    :goto_0
    if-eqz v8, :cond_3

    const-string v8, "."

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_3

    const-string v8, ".."

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_3

    move-object v8, v5

    check-cast v8, Ljava/lang/CharSequence;

    new-instance v9, Lkotlin/text/Regex;

    const-string v10, "[A-Za-z0-9._-]+"

    invoke-direct {v9, v10}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v8}, Lkotlin/text/Regex;->matches(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_3

    move v5, v0

    goto :goto_1

    :cond_3
    move v5, v7

    .line 87
    .end local v5    # "it\\2":Ljava/lang/String;
    .end local v6    # "$i$a$-all-LicenseDialogKt$checkedNoticePath$1\\2\\87\\0":I
    :goto_1
    if-nez v5, :cond_1

    move v0, v7

    goto :goto_2

    .line 88
    .end local v4    # "element\\1":Ljava/lang/Object;
    :cond_4
    nop

    .line 22
    .end local v1    # "$this$all\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$all\\1\\20":I
    :goto_2
    return v0
.end method

.method private static final openSource(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .locals 4
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "reference"    # Ljava/lang/String;
    .param p2, "fail"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 79
    nop

    .line 80
    :try_start_0
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    .line 81
    .local v0, "uri":Landroid/net/Uri;
    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v1

    const-string v2, "https"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v2

    goto :goto_1

    :cond_1
    :goto_0
    move v1, v3

    :goto_1
    if-nez v1, :cond_2

    invoke-virtual {v0}, Landroid/net/Uri;->getUserInfo()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_2

    move v2, v3

    :cond_2
    if-eqz v2, :cond_3

    .line 82
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .end local v0    # "uri":Landroid/net/Uri;
    goto :goto_2

    .line 81
    .restart local v0    # "uri":Landroid/net/Uri;
    :cond_3
    const-string v1, "\u65ad\u8a00\u5931\u8d25\u3002"

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "reference":Ljava/lang/String;
    .end local p2    # "fail":Lkotlin/jvm/functions/Function1;
    throw v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 83
    .end local v0    # "uri":Landroid/net/Uri;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "reference":Ljava/lang/String;
    .restart local p2    # "fail":Lkotlin/jvm/functions/Function1;
    :catch_0
    move-exception v0

    .local v0, "error":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_4

    const-string v1, "\u6ca1\u6709\u53ef\u7528\u7684\u6d4f\u89c8\u5668"

    :cond_4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u65e0\u6cd5\u6253\u5f00\u6765\u6e90\u9875\u9762\uff1a"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_2
    return-void
.end method

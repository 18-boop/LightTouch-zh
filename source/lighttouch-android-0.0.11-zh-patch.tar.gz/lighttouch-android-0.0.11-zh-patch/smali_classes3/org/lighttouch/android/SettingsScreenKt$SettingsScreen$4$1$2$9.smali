.class final Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4;->invoke(Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,196:1\n1225#2,6:197\n1225#2,6:203\n1225#2,6:209\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\norg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9\n*L\n105#1:197,6\n106#1:203,6\n109#1:209,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $context:Landroid/content/Context;

.field final synthetic $host:Lorg/lighttouch/android/GuestHost;


# direct methods
.method public static synthetic $r8$lambda$KUCDZSWEUXgfKLs-mPLl52M1we0()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->invoke$lambda$1$lambda$0()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$LNU8hoSsRQF3PghrCzU-Tj8jPeE(Landroid/content/Context;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->invoke$lambda$3$lambda$2(Landroid/content/Context;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$sm7d_xKBcEIVVm6QyVB_GRBdIxU(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->invoke$lambda$5$lambda$4(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Landroid/content/Context;Lorg/lighttouch/android/GuestHost;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->$context:Landroid/content/Context;

    iput-object p2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$1$lambda$0()Lkotlin/Unit;
    .locals 1

    .line 105
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$3$lambda$2(Landroid/content/Context;)Lkotlin/Unit;
    .locals 3
    .param p0, "$context"    # Landroid/content/Context;

    .line 107
    new-instance v0, Landroid/content/Intent;

    const-string v1, "https://github.com/blake-lucas/LightTouch"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 108
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$5$lambda$4(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 109
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->openLicenses()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 104
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 13
    .param p1, "$this$Group"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move/from16 v9, p3

    const-string v0, "$this$Group"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C104@10022L2,104@9929L95,105@10121L153,105@10045L229,108@10372L23,108@10295L100:SettingsScreen.kt#o13vsk"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v9, 0x11

    const/16 v1, 0x10

    if-ne v0, v1, :cond_1

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 109
    :cond_0
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_6

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v0, -0x1

    const-string v1, "org.lighttouch.android.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:104)"

    const v2, -0x6d529383

    invoke-static {v2, v9, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 105
    :cond_2
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getInfo()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const v1, 0x6e3c21fe

    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {p2, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v1, 0x0

    .local v1, "invalid\\1":Z
    move-object v2, p2

    .local v2, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 197
    .local v3, "$i$f$cache\\1\\105":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 198
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_3

    .line 199
    const/4 v7, 0x0

    .local v7, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$9$1\\3\\199\\0":I
    new-instance v8, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9$$ExternalSyntheticLambda0;

    invoke-direct {v8}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9$$ExternalSyntheticLambda0;-><init>()V

    .line 200
    .end local v7    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$9$1\\3\\199\\0":I
    .local v8, "value\\2":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 201
    nop

    .end local v8    # "value\\2":Ljava/lang/Object;
    goto :goto_1

    .line 202
    :cond_3
    move-object v8, v4

    .line 198
    :goto_1
    nop

    .line 197
    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\197\\1":I
    nop

    .line 105
    .end local v1    # "invalid\\1":Z
    .end local v2    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\1\\105":I
    move-object v5, v8

    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v7, 0x30180

    const/16 v8, 0x18

    const-string v1, "LightTouch 0.0.11"

    const-string v2, "Android \u4e0a\u7684\u7ecf\u5178 iOS"

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v6, p2

    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 106
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getCode()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    const v11, 0x4c5de2

    invoke-interface {p2, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {p2, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->$context:Landroid/content/Context;

    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\4":Z
    iget-object v2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->$context:Landroid/content/Context;

    move-object v3, p2

    .local v3, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 203
    .local v4, "$i$f$cache\\4\\106":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\4":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 204
    .local v7, "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    if-nez v1, :cond_5

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v5, v8, :cond_4

    goto :goto_2

    .line 208
    :cond_4
    move-object v12, v5

    goto :goto_3

    .line 205
    :cond_5
    :goto_2
    const/4 v8, 0x0

    .line 106
    .local v8, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$9$2\\6\\205\\0":I
    new-instance v12, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9$$ExternalSyntheticLambda1;

    invoke-direct {v12, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9$$ExternalSyntheticLambda1;-><init>(Landroid/content/Context;)V

    .line 205
    .end local v8    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$9$2\\6\\205\\0":I
    nop

    .line 206
    .local v12, "value\\5":Ljava/lang/Object;
    invoke-interface {v3, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 204
    .end local v12    # "value\\5":Ljava/lang/Object;
    :goto_3
    nop

    .line 203
    .end local v5    # "it\\4":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\5\\203\\4":I
    nop

    .line 106
    .end local v1    # "invalid\\4":Z
    .end local v3    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\4\\106":I
    move-object v5, v12

    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v7, 0x1b0

    const/16 v8, 0x18

    const-string v1, "\u6e90\u4ee3\u7801"

    const-string v2, "github.com/blake-lucas/LightTouch"

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v6, p2

    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 109
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getFile()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    invoke-interface {p2, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {p2, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->$host:Lorg/lighttouch/android/GuestHost;

    invoke-interface {p2, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\7":Z
    iget-object v2, p0, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9;->$host:Lorg/lighttouch/android/GuestHost;

    move-object v3, p2

    .local v3, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 209
    .local v4, "$i$f$cache\\7\\109":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\7":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 210
    .local v7, "$i$a$-let-ComposerKt$cache$1\\8\\209\\7":I
    if-nez v1, :cond_7

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v5, v8, :cond_6

    goto :goto_4

    .line 214
    :cond_6
    move-object v10, v5

    goto :goto_5

    .line 211
    :cond_7
    :goto_4
    const/4 v8, 0x0

    .line 109
    .local v8, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$9$3\\9\\211\\0":I
    new-instance v10, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9$$ExternalSyntheticLambda2;

    invoke-direct {v10, v2}, Lorg/lighttouch/android/SettingsScreenKt$SettingsScreen$4$1$2$9$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 211
    .end local v8    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1$2$9$3\\9\\211\\0":I
    nop

    .line 212
    .local v10, "value\\8":Ljava/lang/Object;
    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    nop

    .line 210
    .end local v10    # "value\\8":Ljava/lang/Object;
    :goto_5
    nop

    .line 209
    .end local v5    # "it\\7":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\8\\209\\7":I
    nop

    .line 109
    .end local v1    # "invalid\\7":Z
    .end local v3    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\7\\109":I
    move-object v5, v10

    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v7, 0x61b0

    const/16 v8, 0x8

    const-string v1, "\u5f00\u6e90\u8bb8\u53ef"

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v4, "open_licenses"

    move-object v6, p2

    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/SettingsScreenKt;->access$ActionRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 110
    :cond_8
    :goto_6
    return-void
.end method

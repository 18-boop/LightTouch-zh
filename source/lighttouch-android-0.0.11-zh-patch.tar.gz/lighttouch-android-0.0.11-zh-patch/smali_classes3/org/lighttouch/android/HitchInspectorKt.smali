.class public final Lorg/lighttouch/android/HitchInspectorKt;
.super Ljava/lang/Object;
.source "HitchInspector.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHitchInspector.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/HitchInspectorKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 8 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 9 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 10 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 11 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 12 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,342:1\n149#2:343\n149#2:376\n149#2:443\n149#2:480\n149#2:487\n149#2:528\n149#2:529\n149#2:536\n149#2:537\n149#2:579\n149#2:580\n149#2:588\n149#2:601\n149#2:602\n149#2:646\n149#2:651\n149#2:652\n149#2:657\n149#2:658\n149#2:739\n149#2:812\n149#2:813\n149#2:822\n149#2:897\n149#2:898\n149#2:935\n149#2:940\n149#2:950\n149#2:987\n149#2:1055\n149#2:1056\n149#2:1057\n149#2:1058\n149#2:1064\n86#3,3:344\n89#3:375\n93#3:380\n86#3:444\n83#3,6:445\n89#3:479\n93#3:656\n86#3:659\n83#3,6:660\n89#3:694\n93#3:698\n86#3:823\n84#3,5:824\n89#3:857\n93#3:949\n86#3:988\n83#3,6:989\n89#3:1023\n93#3:1027\n79#4,6:347\n86#4,4:362\n90#4,2:372\n94#4:379\n79#4,6:451\n86#4,4:466\n90#4,2:476\n79#4,6:495\n86#4,4:510\n90#4,2:520\n94#4:526\n79#4,6:546\n86#4,4:561\n90#4,2:571\n94#4:577\n79#4,6:611\n86#4,4:626\n90#4,2:636\n94#4:649\n94#4:655\n79#4,6:666\n86#4,4:681\n90#4,2:691\n94#4:697\n79#4,6:746\n86#4,4:761\n90#4,2:771\n79#4,6:783\n86#4,4:798\n90#4,2:808\n94#4:816\n94#4:820\n79#4,6:829\n86#4,4:844\n90#4,2:854\n79#4,6:868\n86#4,4:883\n90#4,2:893\n79#4,6:906\n86#4,4:921\n90#4,2:931\n94#4:938\n94#4:943\n94#4:948\n79#4,6:958\n86#4,4:973\n90#4,2:983\n79#4,6:995\n86#4,4:1010\n90#4,2:1020\n94#4:1026\n94#4:1030\n368#5,9:353\n377#5:374\n378#5,2:377\n368#5,9:457\n377#5:478\n368#5,9:501\n377#5:522\n378#5,2:524\n368#5,9:552\n377#5:573\n378#5,2:575\n368#5,9:617\n377#5:638\n378#5,2:647\n378#5,2:653\n368#5,9:672\n377#5:693\n378#5,2:695\n368#5,9:752\n377#5:773\n368#5,9:789\n377#5:810\n378#5,2:814\n378#5,2:818\n368#5,9:835\n377#5:856\n368#5,9:874\n377#5:895\n368#5,9:912\n377#5:933\n378#5,2:936\n378#5,2:941\n378#5,2:946\n368#5,9:964\n377#5:985\n368#5,9:1001\n377#5:1022\n378#5,2:1024\n378#5,2:1028\n4034#6,6:366\n4034#6,6:470\n4034#6,6:514\n4034#6,6:565\n4034#6,6:630\n4034#6,6:685\n4034#6,6:765\n4034#6,6:802\n4034#6,6:848\n4034#6,6:887\n4034#6,6:925\n4034#6,6:977\n4034#6,6:1014\n1225#7,3:381\n1228#7,3:402\n1225#7,6:405\n1225#7,3:411\n1228#7,3:428\n1225#7,6:431\n1225#7,6:437\n1225#7,6:481\n1225#7,6:530\n1225#7,3:581\n1228#7,3:585\n1225#7,6:589\n1225#7,6:595\n1225#7,6:640\n1225#7,6:699\n1225#7,6:705\n1225#7,6:711\n1225#7,3:717\n1228#7,3:724\n1225#7,6:727\n1225#7,6:733\n774#8:384\n865#8,2:385\n1969#8,14:388\n1999#8,14:414\n1068#8:584\n1563#8:720\n1634#8,3:721\n1878#8,2:858\n1880#8:945\n1999#8,14:1038\n774#8:1059\n865#8,2:1060\n1878#8,2:1062\n1880#8:1065\n1#9:387\n99#10:488\n96#10,6:489\n102#10:523\n106#10:527\n99#10:538\n95#10,7:539\n102#10:574\n106#10:578\n99#10:603\n95#10,7:604\n102#10:639\n106#10:650\n99#10:740\n97#10,5:741\n102#10:774\n99#10:775\n95#10,7:776\n102#10:811\n106#10:817\n106#10:821\n99#10:860\n95#10,7:861\n102#10:896\n106#10:944\n99#10:951\n96#10,6:952\n102#10:986\n106#10:1031\n71#11:899\n68#11,6:900\n74#11:934\n78#11:939\n81#12:1032\n107#12,2:1033\n81#12:1035\n107#12,2:1036\n81#12:1052\n107#12,2:1053\n*S KotlinDebug\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/HitchInspectorKt\n*L\n69#1:343\n71#1:376\n91#1:443\n93#1:480\n94#1:487\n101#1:528\n102#1:529\n104#1:536\n105#1:537\n111#1:579\n114#1:580\n117#1:588\n124#1:601\n134#1:602\n140#1:646\n144#1:651\n145#1:652\n152#1:657\n157#1:658\n253#1:739\n256#1:812\n257#1:813\n268#1:822\n271#1:897\n272#1:898\n273#1:935\n275#1:940\n333#1:950\n334#1:987\n185#1:1055\n195#1:1056\n196#1:1057\n217#1:1058\n245#1:1064\n69#1:344,3\n69#1:375\n69#1:380\n91#1:444\n91#1:445,6\n91#1:479\n91#1:656\n157#1:659\n157#1:660,6\n157#1:694\n157#1:698\n268#1:823\n268#1:824,5\n268#1:857\n268#1:949\n336#1:988\n336#1:989,6\n336#1:1023\n336#1:1027\n69#1:347,6\n69#1:362,4\n69#1:372,2\n69#1:379\n91#1:451,6\n91#1:466,4\n91#1:476,2\n94#1:495,6\n94#1:510,4\n94#1:520,2\n94#1:526\n105#1:546,6\n105#1:561,4\n105#1:571,2\n105#1:577\n135#1:611,6\n135#1:626,4\n135#1:636,2\n135#1:649\n91#1:655\n157#1:666,6\n157#1:681,4\n157#1:691,2\n157#1:697\n253#1:746,6\n253#1:761,4\n253#1:771,2\n255#1:783,6\n255#1:798,4\n255#1:808,2\n255#1:816\n253#1:820\n268#1:829,6\n268#1:844,4\n268#1:854,2\n270#1:868,6\n270#1:883,4\n270#1:893,2\n272#1:906,6\n272#1:921,4\n272#1:931,2\n272#1:938\n270#1:943\n268#1:948\n333#1:958,6\n333#1:973,4\n333#1:983,2\n336#1:995,6\n336#1:1010,4\n336#1:1020,2\n336#1:1026\n333#1:1030\n69#1:353,9\n69#1:374\n69#1:377,2\n91#1:457,9\n91#1:478\n94#1:501,9\n94#1:522\n94#1:524,2\n105#1:552,9\n105#1:573\n105#1:575,2\n135#1:617,9\n135#1:638\n135#1:647,2\n91#1:653,2\n157#1:672,9\n157#1:693\n157#1:695,2\n253#1:752,9\n253#1:773\n255#1:789,9\n255#1:810\n255#1:814,2\n253#1:818,2\n268#1:835,9\n268#1:856\n270#1:874,9\n270#1:895\n272#1:912,9\n272#1:933\n272#1:936,2\n270#1:941,2\n268#1:946,2\n333#1:964,9\n333#1:985\n336#1:1001,9\n336#1:1022\n336#1:1024,2\n333#1:1028,2\n69#1:366,6\n91#1:470,6\n94#1:514,6\n105#1:565,6\n135#1:630,6\n157#1:685,6\n253#1:765,6\n255#1:802,6\n268#1:848,6\n270#1:887,6\n272#1:925,6\n333#1:977,6\n336#1:1014,6\n81#1:381,3\n81#1:402,3\n86#1:405,6\n87#1:411,3\n87#1:428,3\n88#1:431,6\n89#1:437,6\n93#1:481,6\n102#1:530,6\n115#1:581,3\n115#1:585,3\n120#1:589,6\n122#1:595,6\n136#1:640,6\n171#1:699,6\n179#1:705,6\n184#1:711,6\n209#1:717,3\n209#1:724,3\n211#1:727,6\n215#1:733,6\n82#1:384\n82#1:385,2\n83#1:388,14\n87#1:414,14\n115#1:584\n209#1:720\n209#1:721,3\n269#1:858,2\n269#1:945\n93#1:1038,14\n222#1:1059\n222#1:1060,2\n229#1:1062,2\n229#1:1065\n94#1:488\n94#1:489,6\n94#1:523\n94#1:527\n105#1:538\n105#1:539,7\n105#1:574\n105#1:578\n135#1:603\n135#1:604,7\n135#1:639\n135#1:650\n253#1:740\n253#1:741,5\n253#1:774\n255#1:775\n255#1:776,7\n255#1:811\n255#1:817\n253#1:821\n270#1:860\n270#1:861,7\n270#1:896\n270#1:944\n333#1:951\n333#1:952,6\n333#1:986\n333#1:1031\n272#1:899\n272#1:900,6\n272#1:934\n272#1:939\n86#1:1032\n86#1:1033,2\n87#1:1035\n87#1:1036,2\n120#1:1052\n120#1:1053,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000l\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0012\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002\u00a2\u0006\u0002\u0010\u0004\u001ak\u0010\u0005\u001a\u00020\u00062\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u00082\u0008\u0010\t\u001a\u0004\u0018\u00010\n2\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u000c2\u0018\u0010\r\u001a\u0014\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00060\u000e2\u0006\u0010\u0010\u001a\u00020\u00112\u0008\u0010\u0012\u001a\u0004\u0018\u00010\n2\u000e\u0010\u0013\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u000cH\u0001\u00a2\u0006\u0002\u0010\u0014\u001a\u001d\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\n2\u0006\u0010\u0017\u001a\u00020\nH\u0003\u00a2\u0006\u0002\u0010\u0018\u001aQ\u0010\u0019\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00082\u0018\u0010\r\u001a\u0014\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00060\u000e2\u0006\u0010\u0010\u001a\u00020\u00112\u0008\u0010\u0012\u001a\u0004\u0018\u00010\n2\u000e\u0010\u0013\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u000cH\u0003\u00a2\u0006\u0002\u0010\u001a\u001a\u0010\u0010\u001b\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00020\u000fH\u0002\u001a\u0015\u0010\u001d\u001a\u00020\u00062\u0006\u0010\u001e\u001a\u00020\nH\u0003\u00a2\u0006\u0002\u0010\u001f\u001a3\u0010 \u001a\u00020\u00062\u0006\u0010!\u001a\u00020\n2\u0006\u0010\"\u001a\u00020\n2\u0006\u0010#\u001a\u00020$2\n\u0008\u0002\u0010%\u001a\u0004\u0018\u00010\u0001H\u0003\u00a2\u0006\u0004\u0008&\u0010\'\u001aQ\u0010(\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00082\u0012\u0010)\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0*2\u0006\u0010#\u001a\u00020$2\u001e\u0010+\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0*\u0012\u0004\u0012\u00020\u00060,H\u0003\u00a2\u0006\u0002\u0010-\u001aI\u0010.\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00082\u000c\u0010/\u001a\u0008\u0012\u0004\u0012\u000201002\u0008\u00102\u001a\u0004\u0018\u0001012\u0006\u0010#\u001a\u00020$2\u0012\u00103\u001a\u000e\u0012\u0004\u0012\u000201\u0012\u0004\u0012\u00020\u00060,H\u0003\u00a2\u0006\u0002\u00104\u001a\r\u00105\u001a\u00020\u0006H\u0003\u00a2\u0006\u0002\u00106\u001a\u0015\u00107\u001a\u00020\u00062\u0006\u00108\u001a\u000209H\u0003\u00a2\u0006\u0002\u0010:\u001a\u001d\u0010;\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010<\u001a\u000201H\u0003\u00a2\u0006\u0002\u0010=\u001a\u001d\u0010>\u001a\u00020\u00062\u0006\u0010?\u001a\u00020@2\u0006\u0010A\u001a\u00020\u000fH\u0003\u00a2\u0006\u0002\u0010B\u00a8\u0006C\u00b2\u0006\u0016\u0010)\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u000f0*X\u008a\u008e\u0002\u00b2\u0006\u000c\u00102\u001a\u0004\u0018\u000101X\u008a\u008e\u0002\u00b2\u0006\n\u0010D\u001a\u00020\u0011X\u008a\u008e\u0002"
    }
    d2 = {
        "frameColor",
        "Landroidx/compose/ui/graphics/Color;",
        "ms",
        "",
        "(F)J",
        "HitchInspector",
        "",
        "data",
        "Lorg/lighttouch/android/HitchData;",
        "loadError",
        "",
        "onResume",
        "Lkotlin/Function0;",
        "onSave",
        "Lkotlin/Function2;",
        "",
        "saving",
        "",
        "savedNotice",
        "onShare",
        "(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "Message",
        "title",
        "body",
        "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "InspectorBody",
        "(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "seconds",
        "ns",
        "SectionLabel",
        "text",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "Stat",
        "label",
        "value",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "color",
        "Stat-xqIIw2o",
        "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V",
        "Overview",
        "range",
        "Lkotlin/Pair;",
        "onRange",
        "Lkotlin/Function1;",
        "(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V",
        "Detail",
        "frames",
        "",
        "Lorg/lighttouch/android/HitchFrame;",
        "picked",
        "onPick",
        "(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V",
        "Legend",
        "(Landroidx/compose/runtime/Composer;I)V",
        "Histogram",
        "stats",
        "Lorg/lighttouch/android/RangeStats;",
        "(Lorg/lighttouch/android/RangeStats;Landroidx/compose/runtime/Composer;I)V",
        "FrameCard",
        "frame",
        "(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/runtime/Composer;I)V",
        "EventRow",
        "event",
        "Lorg/lighttouch/android/SlowEvent;",
        "start",
        "(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "all"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$5-M4KdEXBFGShxKrOGvnbHKzJnc(Lorg/lighttouch/android/HitchData;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$20$lambda$19(Lorg/lighttouch/android/HitchData;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6KHiayu0vkYmGgcQ_KZUDW6LLEk(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/HitchInspectorKt;->FrameCard$lambda$65(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$CEUwXB0LM6zjn915psXKssKlj8A(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/HitchInspectorKt;->Stat_xqIIw2o$lambda$41(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$DRqUBljeFfl-S_VAshkNLqwm2cQ(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$38(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$HJOxI2xaKcCz9NmZPCQyeFY2wyg(JLjava/util/List;JFLjava/util/List;Lorg/lighttouch/android/HitchFrame;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54(JLjava/util/List;JFLjava/util/List;Lorg/lighttouch/android/HitchFrame;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KB-Pxbl86vJUqeAO-kpMeChiz8s(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/HitchFrame;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$23$lambda$22(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/HitchFrame;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KcAhBt_AeTnp35Rjr1-tpM231bM(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/HitchInspectorKt;->Legend$lambda$59(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$MsLdMdts4cJKNCVU-Oe2LBEQYRs(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$32$lambda$31(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Q54-BokKGZcF1aocTiTe5oW78J0(JLorg/lighttouch/android/HitchData;Lkotlin/Pair;JJJLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44(JLorg/lighttouch/android/HitchData;Lkotlin/Pair;JJJLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TCV5u--Oi_qNwzuwcJ9Yj6fxD6o(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$56(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UJ4kn8K2tVkj_7o1F64VhDR-p3M(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$46(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Uj0J0OW3siyH1RcM4R5IzHoncbQ(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/HitchInspectorKt;->Message$lambda$2(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZASBc-XMHcKwxrsDgh3u8OhO_lY(Lorg/lighttouch/android/SlowEvent;JILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/HitchInspectorKt;->EventRow$lambda$68(Lorg/lighttouch/android/SlowEvent;JILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$hxe4shga7vvK0LgUMHMHEUOGA2M(Lorg/lighttouch/android/RangeStats;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HitchInspectorKt;->Histogram$lambda$64(Lorg/lighttouch/android/RangeStats;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$krksGiqfCOhX4yXlsfoOj1aiHtM(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p9}, Lorg/lighttouch/android/HitchInspectorKt;->HitchInspector$lambda$0(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qJnqTpovk2rhsGIFJBWzfID4Fzo(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HitchInspectorKt;->SectionLabel$lambda$39(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$yAehPMbljhYzOfHZSqfhqN-nY5s(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$35$lambda$34$lambda$33(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method private static final Detail(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .locals 29
    .param p0, "data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "frames"    # Ljava/util/List;
    .param p2, "picked"    # Lorg/lighttouch/android/HitchFrame;
    .param p3, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p4, "onPick"    # Lkotlin/jvm/functions/Function1;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/HitchData;",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/HitchFrame;",
            ">;",
            "Lorg/lighttouch/android/HitchFrame;",
            "Landroidx/compose/ui/Modifier;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lorg/lighttouch/android/HitchFrame;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 205
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v0, p3

    move-object/from16 v13, p4

    move/from16 v14, p6

    const v3, -0x5d350721

    move-object/from16 v4, p5

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Detail)P(!2,4)205@12388L11,206@12445L11,207@12508L11,208@12550L57,210@12746L183,214@12931L2123,210@12709L2345:HitchInspector.kt#o13vsk"

    invoke-static {v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p6

    .local v4, "$dirty":I
    and-int/lit8 v5, v14, 0x6

    if-nez v5, :cond_1

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v14, 0x30

    if-nez v5, :cond_3

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit16 v5, v14, 0x180

    if-nez v5, :cond_5

    move-object/from16 v10, p2

    invoke-interface {v15, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x100

    goto :goto_2

    :cond_4
    const/16 v5, 0x80

    :goto_2
    or-int/2addr v4, v5

    goto :goto_3

    :cond_5
    move-object/from16 v10, p2

    :goto_3
    and-int/lit16 v5, v14, 0xc00

    if-nez v5, :cond_7

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6

    const/16 v5, 0x800

    goto :goto_4

    :cond_6
    const/16 v5, 0x400

    :goto_4
    or-int/2addr v4, v5

    :cond_7
    and-int/lit16 v5, v14, 0x6000

    if-nez v5, :cond_9

    invoke-interface {v15, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_8

    const/16 v5, 0x4000

    goto :goto_5

    :cond_8
    const/16 v5, 0x2000

    :goto_5
    or-int/2addr v4, v5

    :cond_9
    and-int/lit16 v5, v4, 0x2493

    const/16 v8, 0x2492

    if-ne v5, v8, :cond_b

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_a

    goto :goto_6

    .line 211
    :cond_a
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v19, v4

    goto/16 :goto_13

    .line 205
    :cond_b
    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_c

    const/4 v5, -0x1

    const-string v8, "org.lighttouch.android.Detail (HitchInspector.kt:204)"

    invoke-static {v3, v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 206
    :cond_c
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v15, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v8

    .line 207
    .local v8, "guide":J
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v15, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v11

    .line 208
    .local v11, "label":J
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v15, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v6

    .local v6, "highlight":J
    const v3, 0x4c5de2

    invoke-interface {v15, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "CC(remember):HitchInspector.kt#9igjgp"

    invoke-static {v15, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 209
    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v16

    .local v16, "invalid\\1":Z
    move-object/from16 v17, v15

    .local v17, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 717
    .local v18, "$i$f$cache\\1\\209":I
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\1":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 718
    .local v20, "$i$a$-let-ComposerKt$cache$1\\2\\717\\1":I
    if-nez v16, :cond_e

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v5, v10, :cond_d

    goto :goto_7

    .line 726
    :cond_d
    move-object/from16 v21, v5

    move-object/from16 v10, v17

    goto :goto_9

    .line 719
    :cond_e
    :goto_7
    const/4 v10, 0x0

    .line 209
    .local v10, "$i$a$-cache-HitchInspectorKt$Detail$breakdown$1\\3\\719\\0":I
    move-object/from16 v21, v5

    .end local v5    # "it\\1":Ljava/lang/Object;
    .local v21, "it\\1":Ljava/lang/Object;
    move-object v5, v2

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$map\\4":Ljava/lang/Iterable;
    const/16 v22, 0x0

    .line 720
    .local v22, "$i$f$map\\4\\209":I
    move/from16 v23, v10

    .end local v10    # "$i$a$-cache-HitchInspectorKt$Detail$breakdown$1\\3\\719\\0":I
    .local v23, "$i$a$-cache-HitchInspectorKt$Detail$breakdown$1\\3\\719\\0":I
    new-instance v10, Ljava/util/ArrayList;

    const/16 v14, 0xa

    invoke-static {v5, v14}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v14

    invoke-direct {v10, v14}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v10, Ljava/util/Collection;

    .local v10, "destination\\5":Ljava/util/Collection;
    move-object v14, v5

    .local v14, "$this$mapTo\\5":Ljava/lang/Iterable;
    const/16 v24, 0x0

    .line 721
    .local v24, "$i$f$mapTo\\5\\720":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v25

    :goto_8
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->hasNext()Z

    move-result v26

    if-eqz v26, :cond_f

    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v26

    .line 722
    .local v26, "item\\5":Ljava/lang/Object;
    move-object/from16 v27, v5

    .end local v5    # "$this$map\\4":Ljava/lang/Iterable;
    .local v27, "$this$map\\4":Ljava/lang/Iterable;
    move-object/from16 v5, v26

    check-cast v5, Lorg/lighttouch/android/HitchFrame;

    .local v5, "it\\6":Lorg/lighttouch/android/HitchFrame;
    const/16 v28, 0x0

    .line 209
    .local v28, "$i$a$-map-HitchInspectorKt$Detail$breakdown$1$1\\6\\722\\3":I
    invoke-virtual {v1, v5}, Lorg/lighttouch/android/HitchData;->breakdownFor(Lorg/lighttouch/android/HitchFrame;)Lorg/lighttouch/android/FrameBreakdown;

    move-result-object v5

    .line 722
    .end local v5    # "it\\6":Lorg/lighttouch/android/HitchFrame;
    .end local v28    # "$i$a$-map-HitchInspectorKt$Detail$breakdown$1$1\\6\\722\\3":I
    invoke-interface {v10, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v5, v27

    goto :goto_8

    .line 723
    .end local v26    # "item\\5":Ljava/lang/Object;
    .end local v27    # "$this$map\\4":Ljava/lang/Iterable;
    .local v5, "$this$map\\4":Ljava/lang/Iterable;
    :cond_f
    move-object/from16 v27, v5

    .end local v5    # "$this$map\\4":Ljava/lang/Iterable;
    .end local v10    # "destination\\5":Ljava/util/Collection;
    .end local v14    # "$this$mapTo\\5":Ljava/lang/Iterable;
    .end local v24    # "$i$f$mapTo\\5\\720":I
    .restart local v27    # "$this$map\\4":Ljava/lang/Iterable;
    move-object v5, v10

    check-cast v5, Ljava/util/List;

    .line 720
    nop

    .line 209
    .end local v22    # "$i$f$map\\4\\209":I
    .end local v27    # "$this$map\\4":Ljava/lang/Iterable;
    nop

    .line 719
    .end local v23    # "$i$a$-cache-HitchInspectorKt$Detail$breakdown$1\\3\\719\\0":I
    nop

    .line 724
    .local v5, "value\\2":Ljava/lang/Object;
    move-object/from16 v10, v17

    .end local v17    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .local v10, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 725
    nop

    .line 718
    .end local v5    # "value\\2":Ljava/lang/Object;
    :goto_9
    nop

    .line 717
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\2\\717\\1":I
    .end local v21    # "it\\1":Ljava/lang/Object;
    nop

    .line 209
    .end local v10    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\1":Z
    .end local v18    # "$i$f$cache\\1\\209":I
    check-cast v5, Ljava/util/List;

    .local v5, "breakdown":Ljava/util/List;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 210
    move-object v10, v2

    check-cast v10, Ljava/lang/Iterable;

    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-nez v14, :cond_10

    const/4 v1, 0x0

    goto :goto_b

    :cond_10
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lorg/lighttouch/android/HitchFrame;

    .line 387
    .local v14, "it\\7":Lorg/lighttouch/android/HitchFrame;
    const/16 v16, 0x0

    .line 210
    .local v16, "$i$a$-maxOfOrNull-HitchInspectorKt$Detail$top$1\\7\\210\\0":I
    invoke-virtual {v14}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v14

    .end local v14    # "it\\7":Lorg/lighttouch/android/HitchFrame;
    .end local v16    # "$i$a$-maxOfOrNull-HitchInspectorKt$Detail$top$1\\7\\210\\0":I
    :goto_a
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_11

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Lorg/lighttouch/android/HitchFrame;

    .line 387
    .local v16, "it\\8":Lorg/lighttouch/android/HitchFrame;
    const/16 v17, 0x0

    .line 210
    .local v17, "$i$a$-maxOfOrNull-HitchInspectorKt$Detail$top$1\\8\\210\\0":I
    invoke-virtual/range {v16 .. v16}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    .end local v16    # "it\\8":Lorg/lighttouch/android/HitchFrame;
    .end local v17    # "$i$a$-maxOfOrNull-HitchInspectorKt$Detail$top$1\\8\\210\\0":I
    invoke-static {v14, v1}, Ljava/lang/Math;->max(FF)F

    move-result v14

    goto :goto_a

    :cond_11
    invoke-static {v14}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    :goto_b
    if-eqz v1, :cond_12

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    goto :goto_c

    :cond_12
    const/4 v1, 0x0

    :goto_c
    const v10, 0x3f8ccccd    # 1.1f

    mul-float/2addr v1, v10

    const/high16 v10, 0x42200000    # 40.0f

    invoke-static {v10, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    const/high16 v10, 0x437a0000    # 250.0f

    invoke-static {v1, v10}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v1

    .line 211
    .local v1, "top":F
    const v10, -0x615d173a

    invoke-interface {v15, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    const v14, 0xe000

    and-int/2addr v14, v4

    const/16 v16, 0x1

    move/from16 v17, v10

    const/16 v10, 0x4000

    if-ne v14, v10, :cond_13

    move/from16 v10, v16

    goto :goto_d

    :cond_13
    const/4 v10, 0x0

    :goto_d
    or-int v10, v17, v10

    .local v10, "invalid\\9":Z
    move-object v14, v15

    .local v14, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 727
    .local v17, "$i$f$cache\\9\\211":I
    move/from16 v19, v10

    .end local v10    # "invalid\\9":Z
    .local v19, "invalid\\9":Z
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\9":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 728
    .local v21, "$i$a$-let-ComposerKt$cache$1\\10\\727\\9":I
    if-nez v19, :cond_15

    sget-object v22, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-wide/from16 v23, v6

    .end local v6    # "highlight":J
    .local v23, "highlight":J
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v10, v6, :cond_14

    goto :goto_e

    .line 732
    :cond_14
    move-object v7, v10

    goto :goto_f

    .line 728
    .end local v23    # "highlight":J
    .restart local v6    # "highlight":J
    :cond_15
    move-wide/from16 v23, v6

    .line 729
    .end local v6    # "highlight":J
    .restart local v23    # "highlight":J
    :goto_e
    const/4 v6, 0x0

    .line 211
    .local v6, "$i$a$-cache-HitchInspectorKt$Detail$1\\11\\729\\0":I
    new-instance v7, Lorg/lighttouch/android/HitchInspectorKt$Detail$1$1;

    move/from16 v22, v6

    const/4 v6, 0x0

    .end local v6    # "$i$a$-cache-HitchInspectorKt$Detail$1\\11\\729\\0":I
    .local v22, "$i$a$-cache-HitchInspectorKt$Detail$1\\11\\729\\0":I
    invoke-direct {v7, v2, v13, v6}, Lorg/lighttouch/android/HitchInspectorKt$Detail$1$1;-><init>(Ljava/util/List;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V

    check-cast v7, Lkotlin/jvm/functions/Function2;

    .line 729
    .end local v22    # "$i$a$-cache-HitchInspectorKt$Detail$1\\11\\729\\0":I
    nop

    .line 730
    .local v7, "value\\10":Ljava/lang/Object;
    invoke-interface {v14, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 731
    nop

    .line 728
    .end local v7    # "value\\10":Ljava/lang/Object;
    :goto_f
    nop

    .line 727
    .end local v10    # "it\\9":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\10\\727\\9":I
    nop

    .line 211
    .end local v14    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$f$cache\\9\\211":I
    .end local v19    # "invalid\\9":Z
    check-cast v7, Lkotlin/jvm/functions/Function2;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v0, v2, v7}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    const v6, -0x48fade91

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v11, v12}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v3

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v6

    or-int/2addr v3, v6

    invoke-interface {v15, v8, v9}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    or-int/2addr v3, v6

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v3, v6

    invoke-interface {v15, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v3, v6

    and-int/lit16 v6, v4, 0x380

    const/16 v7, 0x100

    if-ne v6, v7, :cond_16

    goto :goto_10

    :cond_16
    const/16 v16, 0x0

    :goto_10
    or-int v3, v3, v16

    move-wide/from16 v6, v23

    .end local v23    # "highlight":J
    .local v6, "highlight":J
    invoke-interface {v15, v6, v7}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v10

    or-int/2addr v3, v10

    .line 215
    move-object v10, v15

    .local v10, "$this$cache\\12":Landroidx/compose/runtime/Composer;
    move/from16 v16, v3

    .local v16, "invalid\\12":Z
    const/16 v17, 0x0

    .line 733
    .local v17, "$i$f$cache\\12\\215":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\12":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 734
    .local v18, "$i$a$-let-ComposerKt$cache$1\\13\\733\\12":I
    if-nez v16, :cond_18

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v3, v0, :cond_17

    goto :goto_11

    .line 738
    :cond_17
    move-wide/from16 v19, v11

    move-wide v11, v6

    move-wide/from16 v6, v19

    move-object v2, v3

    move-object/from16 v20, v2

    move/from16 v19, v4

    move-wide v3, v8

    const/4 v0, 0x0

    move v8, v1

    move-object v9, v5

    move-object v1, v10

    goto :goto_12

    .line 735
    :cond_18
    :goto_11
    const/4 v0, 0x0

    .line 215
    .local v0, "$i$a$-cache-HitchInspectorKt$Detail$2\\14\\735\\0":I
    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda0;

    move-wide/from16 v19, v11

    move-wide v11, v6

    move-wide/from16 v6, v19

    move/from16 p5, v0

    move-object/from16 v20, v3

    move/from16 v19, v4

    move-wide v3, v8

    const/4 v0, 0x0

    move v8, v1

    move-object v9, v5

    move-object v1, v10

    move-object/from16 v5, p1

    move-object/from16 v10, p2

    .end local v0    # "$i$a$-cache-HitchInspectorKt$Detail$2\\14\\735\\0":I
    .end local v4    # "$dirty":I
    .end local v5    # "breakdown":Ljava/util/List;
    .end local v10    # "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .local v1, "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .local v3, "guide":J
    .local v6, "label":J
    .local v8, "top":F
    .local v9, "breakdown":Ljava/util/List;
    .local v11, "highlight":J
    .local v19, "$dirty":I
    .local v20, "it\\12":Ljava/lang/Object;
    .local p5, "$i$a$-cache-HitchInspectorKt$Detail$2\\14\\735\\0":I
    invoke-direct/range {v2 .. v12}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda0;-><init>(JLjava/util/List;JFLjava/util/List;Lorg/lighttouch/android/HitchFrame;J)V

    .line 735
    .end local p5    # "$i$a$-cache-HitchInspectorKt$Detail$2\\14\\735\\0":I
    nop

    .line 736
    .local v2, "value\\13":Ljava/lang/Object;
    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 737
    nop

    .line 734
    .end local v2    # "value\\13":Ljava/lang/Object;
    :goto_12
    nop

    .line 733
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\13\\733\\12":I
    .end local v20    # "it\\12":Ljava/lang/Object;
    nop

    .line 215
    .end local v1    # "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\12":Z
    .end local v17    # "$i$f$cache\\12\\215":I
    check-cast v2, Lkotlin/jvm/functions/Function1;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 211
    invoke-static {v14, v2, v15, v0}, Landroidx/compose/foundation/CanvasKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v3    # "guide":J
    .end local v6    # "label":J
    .end local v8    # "top":F
    .end local v9    # "breakdown":Ljava/util/List;
    .end local v11    # "highlight":J
    :cond_19
    :goto_13
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_1a

    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda8;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v6, p6

    move-object v5, v13

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 249
    :cond_1a
    return-void
.end method

.method private static final Detail$lambda$55$lambda$54(JLjava/util/List;JFLjava/util/List;Lorg/lighttouch/android/HitchFrame;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .locals 32
    .param p0, "$guide"    # J
    .param p2, "$frames"    # Ljava/util/List;
    .param p3, "$label"    # J
    .param p5, "$top"    # F
    .param p6, "$breakdown"    # Ljava/util/List;
    .param p7, "$picked"    # Lorg/lighttouch/android/HitchFrame;
    .param p8, "$highlight"    # J
    .param p10, "$this$Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;

    move/from16 v0, p5

    move-object/from16 v1, p10

    const-string v2, "$this$Canvas"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 216
    new-instance v2, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    move-object v4, v2

    .local v4, "$this$Detail_u24lambda_u2455_u24lambda_u2454_u24lambda_u2451\\1":Landroid/graphics/Paint;
    const/4 v5, 0x0

    .line 217
    .local v5, "$i$a$-apply-HitchInspectorKt$Detail$2$1$labelPaint$1\\1\\216\\0":I
    const/16 v6, 0xa

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 1058
    .local v7, "$i$f$getDp\\2\\217":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 217
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\217":I
    invoke-interface {v1, v6}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object v6, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 218
    invoke-static/range {p3 .. p4}, Landroidx/compose/ui/graphics/Color;->getRed-impl(J)F

    move-result v6

    const/16 v7, 0xff

    int-to-float v7, v7

    mul-float/2addr v6, v7

    float-to-int v6, v6

    invoke-static/range {p3 .. p4}, Landroidx/compose/ui/graphics/Color;->getGreen-impl(J)F

    move-result v8

    mul-float/2addr v8, v7

    float-to-int v8, v8

    invoke-static/range {p3 .. p4}, Landroidx/compose/ui/graphics/Color;->getBlue-impl(J)F

    move-result v9

    mul-float/2addr v9, v7

    float-to-int v7, v9

    const/16 v9, 0xe6

    invoke-static {v9, v6, v8, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 219
    const/high16 v6, -0x1000000

    const/high16 v7, 0x40800000    # 4.0f

    const/4 v8, 0x0

    invoke-virtual {v4, v7, v8, v8, v6}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 220
    nop

    .line 216
    .end local v4    # "$this$Detail_u24lambda_u2455_u24lambda_u2454_u24lambda_u2451\\1":Landroid/graphics/Paint;
    .end local v5    # "$i$a$-apply-HitchInspectorKt$Detail$2$1$labelPaint$1\\1\\216\\0":I
    nop

    .line 222
    .local v2, "labelPaint":Landroid/graphics/Paint;
    const/4 v4, 0x5

    new-array v4, v4, [Ljava/lang/Float;

    const v5, 0x4185999a    # 16.7f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const/4 v6, 0x0

    aput-object v5, v4, v6

    const v5, 0x42053333    # 33.3f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    aput-object v5, v4, v3

    const/high16 v5, 0x42480000    # 50.0f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const/4 v9, 0x2

    aput-object v5, v4, v9

    const/high16 v5, 0x42c80000    # 100.0f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const/4 v9, 0x3

    aput-object v5, v4, v9

    const/high16 v5, 0x43480000    # 200.0f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const/4 v9, 0x4

    aput-object v5, v4, v9

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\3":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1059
    .local v5, "$i$f$filter\\3\\222":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\4":Ljava/util/Collection;
    move-object v10, v4

    .local v10, "$this$filterTo\\4":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 1060
    .local v11, "$i$f$filterTo\\4\\1059":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_0
    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_2

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\4":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Ljava/lang/Number;

    invoke-virtual {v14}, Ljava/lang/Number;->floatValue()F

    move-result v14

    .local v14, "it\\5":F
    const/4 v15, 0x0

    .line 222
    .local v15, "$i$a$-filter-HitchInspectorKt$Detail$2$1$guides$1\\5\\1060\\0":I
    cmpg-float v16, v14, v0

    if-gez v16, :cond_1

    move v14, v3

    goto :goto_1

    :cond_1
    move v14, v6

    .line 1060
    .end local v14    # "it\\5":F
    .end local v15    # "$i$a$-filter-HitchInspectorKt$Detail$2$1$guides$1\\5\\1060\\0":I
    :goto_1
    if-eqz v14, :cond_0

    invoke-interface {v9, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1061
    .end local v13    # "element\\4":Ljava/lang/Object;
    :cond_2
    nop

    .end local v9    # "destination\\4":Ljava/util/Collection;
    .end local v10    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filterTo\\4\\1059":I
    move-object v3, v9

    check-cast v3, Ljava/util/List;

    .line 1059
    nop

    .line 222
    .end local v4    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\3\\222":I
    nop

    .line 223
    .local v3, "guides":Ljava/util/List;
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    .local v4, "g":F
    invoke-static {v1, v0, v4}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v5

    invoke-static {v8, v5}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v5

    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v9

    invoke-static {v9, v10}, Landroidx/compose/ui/geometry/Size;->getWidth-impl(J)F

    move-result v9

    invoke-static {v1, v0, v4}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v10

    invoke-static {v9, v10}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v9

    const/16 v14, 0x1f0

    const/4 v15, 0x0

    move v11, v8

    const/high16 v8, 0x3f800000    # 1.0f

    move v12, v7

    move-wide/from16 v30, v9

    move v10, v4

    move-wide v4, v5

    move-wide/from16 v6, v30

    .end local v4    # "g":F
    .local v10, "g":F
    const/4 v9, 0x0

    move v13, v10

    .end local v10    # "g":F
    .local v13, "g":F
    const/4 v10, 0x0

    move/from16 v17, v11

    const/4 v11, 0x0

    move/from16 v18, v12

    const/4 v12, 0x0

    move/from16 v19, v13

    .end local v13    # "g":F
    .local v19, "g":F
    const/4 v13, 0x0

    move-object/from16 v21, v2

    move-object/from16 v22, v3

    move-wide/from16 v2, p0

    .end local v2    # "labelPaint":Landroid/graphics/Paint;
    .end local v3    # "guides":Ljava/util/List;
    .local v21, "labelPaint":Landroid/graphics/Paint;
    .local v22, "guides":Ljava/util/List;
    invoke-static/range {v1 .. v15}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawLine-NGM6Ib0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFILandroidx/compose/ui/graphics/PathEffect;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    move/from16 v7, v18

    move-object/from16 v2, v21

    move-object/from16 v3, v22

    const/4 v8, 0x0

    .end local v19    # "g":F
    goto :goto_2

    .line 224
    .end local v21    # "labelPaint":Landroid/graphics/Paint;
    .end local v22    # "guides":Ljava/util/List;
    .restart local v2    # "labelPaint":Landroid/graphics/Paint;
    .restart local v3    # "guides":Ljava/util/List;
    :cond_3
    move-object/from16 v21, v2

    move-object/from16 v22, v3

    move/from16 v18, v7

    .end local v2    # "labelPaint":Landroid/graphics/Paint;
    .end local v3    # "guides":Ljava/util/List;
    .restart local v21    # "labelPaint":Landroid/graphics/Paint;
    .restart local v22    # "guides":Ljava/util/List;
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getDrawContext()Landroidx/compose/ui/graphics/drawscope/DrawContext;

    move-result-object v2

    invoke-interface {v2}, Landroidx/compose/ui/graphics/drawscope/DrawContext;->getCanvas()Landroidx/compose/ui/graphics/Canvas;

    move-result-object v2

    invoke-static {v2}, Landroidx/compose/ui/graphics/AndroidCanvas_androidKt;->getNativeCanvas(Landroidx/compose/ui/graphics/Canvas;)Landroid/graphics/Canvas;

    move-result-object v13

    .line 226
    .local v13, "canvas":Landroid/graphics/Canvas;
    invoke-interface/range {p2 .. p2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_4

    move-object/from16 v14, v21

    move-object/from16 v15, v22

    .end local v21    # "labelPaint":Landroid/graphics/Paint;
    .end local v22    # "guides":Ljava/util/List;
    .local v14, "labelPaint":Landroid/graphics/Paint;
    .local v15, "guides":Ljava/util/List;
    invoke-static {v15, v13, v1, v14, v0}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$labels(Ljava/util/List;Landroid/graphics/Canvas;Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroid/graphics/Paint;F)V

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2

    .line 227
    .end local v14    # "labelPaint":Landroid/graphics/Paint;
    .end local v15    # "guides":Ljava/util/List;
    .restart local v21    # "labelPaint":Landroid/graphics/Paint;
    .restart local v22    # "guides":Ljava/util/List;
    :cond_4
    move-object/from16 v14, v21

    move-object/from16 v15, v22

    .end local v21    # "labelPaint":Landroid/graphics/Paint;
    .end local v22    # "guides":Ljava/util/List;
    .restart local v14    # "labelPaint":Landroid/graphics/Paint;
    .restart local v15    # "guides":Ljava/util/List;
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getWidth-impl(J)F

    move-result v2

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->size()I

    move-result v3

    int-to-float v3, v3

    div-float v5, v2, v3

    .line 228
    .local v5, "w":F
    cmpl-float v2, v5, v18

    if-lez v2, :cond_5

    const/high16 v8, 0x3f800000    # 1.0f

    move v6, v8

    goto :goto_3

    :cond_5
    const/4 v6, 0x0

    .line 229
    .local v6, "gap":F
    :goto_3
    move-object/from16 v16, p2

    check-cast v16, Ljava/lang/Iterable;

    .local v16, "$this$forEachIndexed\\6":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 1062
    .local v17, "$i$f$forEachIndexed\\6\\229":I
    const/4 v2, 0x0

    .line 1063
    .local v2, "index\\6":I
    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_4
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_9

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    .local v19, "item\\6":Ljava/lang/Object;
    add-int/lit8 v21, v2, 0x1

    .end local v2    # "index\\6":I
    .local v21, "index\\6":I
    if-gez v2, :cond_6

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_6
    move-object/from16 v3, v19

    check-cast v3, Lorg/lighttouch/android/HitchFrame;

    .local v3, "f\\7":Lorg/lighttouch/android/HitchFrame;
    move v10, v2

    .local v10, "i\\7":I
    const/16 v22, 0x0

    .line 230
    .local v22, "$i$a$-forEachIndexed-HitchInspectorKt$Detail$2$1$1\\7\\1063\\0":I
    int-to-float v2, v10

    mul-float v4, v2, v5

    .line 231
    .local v4, "left\\7":F
    move-object/from16 v11, p6

    invoke-interface {v11, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v23, v2

    check-cast v23, Lorg/lighttouch/android/FrameBreakdown;

    .line 232
    .local v23, "b\\7":Lorg/lighttouch/android/FrameBreakdown;
    if-eqz v23, :cond_7

    .line 234
    new-instance v2, Lkotlin/jvm/internal/Ref$FloatRef;

    invoke-direct {v2}, Lkotlin/jvm/internal/Ref$FloatRef;-><init>()V

    .local v2, "base\\7":Lkotlin/jvm/internal/Ref$FloatRef;
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v7

    invoke-static {v7, v8}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v7

    iput v7, v2, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    .line 241
    invoke-virtual/range {v23 .. v23}, Lorg/lighttouch/android/FrameBreakdown;->getGlMs()F

    move-result v7

    sget-object v8, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v8}, Lorg/lighttouch/android/LtColors;->getOverlayGpu-0d7_KjU()J

    move-result-wide v8

    invoke-static/range {v0 .. v9}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$lambda$53$seg(FLandroidx/compose/ui/graphics/drawscope/DrawScope;Lkotlin/jvm/internal/Ref$FloatRef;Lorg/lighttouch/android/HitchFrame;FFFFJ)V

    invoke-virtual/range {v23 .. v23}, Lorg/lighttouch/android/FrameBreakdown;->getBqlMs()F

    move-result v7

    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v8

    move/from16 v0, p5

    move-object/from16 v1, p10

    invoke-static/range {v0 .. v9}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$lambda$53$seg(FLandroidx/compose/ui/graphics/drawscope/DrawScope;Lkotlin/jvm/internal/Ref$FloatRef;Lorg/lighttouch/android/HitchFrame;FFFFJ)V

    .line 242
    invoke-virtual/range {v23 .. v23}, Lorg/lighttouch/android/FrameBreakdown;->getRunMs()F

    move-result v0

    invoke-virtual/range {v23 .. v23}, Lorg/lighttouch/android/FrameBreakdown;->getGlMs()F

    move-result v1

    sub-float/2addr v0, v1

    const/4 v12, 0x0

    invoke-static {v0, v12}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v7

    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayCpu-0d7_KjU()J

    move-result-wide v8

    move/from16 v0, p5

    move-object/from16 v1, p10

    invoke-static/range {v0 .. v9}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$lambda$53$seg(FLandroidx/compose/ui/graphics/drawscope/DrawScope;Lkotlin/jvm/internal/Ref$FloatRef;Lorg/lighttouch/android/HitchFrame;FFFFJ)V

    .line 243
    invoke-virtual {v3}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v7

    const-wide v0, 0xff5a6366L

    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v8

    move/from16 v0, p5

    move-object/from16 v1, p10

    invoke-static/range {v0 .. v9}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$lambda$53$seg(FLandroidx/compose/ui/graphics/drawscope/DrawScope;Lkotlin/jvm/internal/Ref$FloatRef;Lorg/lighttouch/android/HitchFrame;FFFFJ)V

    move/from16 v20, v5

    move/from16 v24, v6

    move/from16 v28, v10

    move/from16 v27, v12

    move-object/from16 v29, v13

    move-object/from16 v25, v14

    move-object/from16 v26, v15

    move v13, v0

    move-object v14, v3

    move v15, v4

    .end local v4    # "left\\7":F
    .end local v5    # "w":F
    .end local v6    # "gap":F
    .local v2, "left\\7":F
    .local v20, "w":F
    .local v24, "gap":F
    goto/16 :goto_5

    .line 244
    .end local v2    # "left\\7":F
    .end local v20    # "w":F
    .end local v24    # "gap":F
    .restart local v4    # "left\\7":F
    .restart local v5    # "w":F
    .restart local v6    # "gap":F
    :cond_7
    move v2, v4

    move/from16 v20, v5

    move/from16 v24, v6

    const/4 v12, 0x0

    .end local v4    # "left\\7":F
    .end local v5    # "w":F
    .end local v6    # "gap":F
    .restart local v2    # "left\\7":F
    .restart local v20    # "w":F
    .restart local v24    # "gap":F
    invoke-virtual {v3}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v4

    invoke-static {v4}, Lorg/lighttouch/android/HitchInspectorKt;->frameColor(F)J

    move-result-wide v4

    invoke-virtual {v3}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v6

    invoke-static {v1, v0, v6}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v6

    invoke-static {v2, v6}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v6

    sub-float v8, v20, v24

    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v25

    invoke-static/range {v25 .. v26}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v9

    invoke-virtual {v3}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v12

    invoke-static {v1, v0, v12}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v12

    sub-float/2addr v9, v12

    invoke-static {v8, v9}, Landroidx/compose/ui/geometry/SizeKt;->Size(FF)J

    move-result-wide v8

    const/16 v11, 0x78

    const/4 v12, 0x0

    move-wide/from16 v30, v6

    move v6, v2

    move-wide v1, v4

    move-object v5, v3

    move-wide/from16 v3, v30

    .end local v2    # "left\\7":F
    .end local v3    # "f\\7":Lorg/lighttouch/android/HitchFrame;
    .local v5, "f\\7":Lorg/lighttouch/android/HitchFrame;
    .local v6, "left\\7":F
    const/4 v7, 0x0

    move/from16 v26, v6

    move-wide/from16 v30, v8

    move-object v9, v5

    move-wide/from16 v5, v30

    .end local v5    # "f\\7":Lorg/lighttouch/android/HitchFrame;
    .end local v6    # "left\\7":F
    .local v9, "f\\7":Lorg/lighttouch/android/HitchFrame;
    .local v26, "left\\7":F
    const/4 v8, 0x0

    move-object/from16 v27, v9

    .end local v9    # "f\\7":Lorg/lighttouch/android/HitchFrame;
    .local v27, "f\\7":Lorg/lighttouch/android/HitchFrame;
    const/4 v9, 0x0

    move/from16 v28, v10

    .end local v10    # "i\\7":I
    .local v28, "i\\7":I
    const/4 v10, 0x0

    move/from16 v25, v26

    move-object/from16 v26, v15

    move/from16 v15, v25

    move-object/from16 v29, v13

    move-object/from16 v25, v14

    move-object/from16 v14, v27

    const/16 v27, 0x0

    move v13, v0

    move-object/from16 v0, p10

    .end local v13    # "canvas":Landroid/graphics/Canvas;
    .end local v27    # "f\\7":Lorg/lighttouch/android/HitchFrame;
    .local v14, "f\\7":Lorg/lighttouch/android/HitchFrame;
    .local v15, "left\\7":F
    .local v25, "labelPaint":Landroid/graphics/Paint;
    .local v26, "guides":Ljava/util/List;
    .local v29, "canvas":Landroid/graphics/Canvas;
    invoke-static/range {v0 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    move-object v1, v0

    .line 245
    :goto_5
    move-object/from16 v0, p7

    invoke-static {v14, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-virtual {v14}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v2

    invoke-static {v1, v13, v2}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v2

    const/4 v3, 0x3

    .local v3, "$this$dp\\8":I
    const/4 v4, 0x0

    .line 1064
    .local v4, "$i$f$getDp\\8\\245":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 245
    .end local v3    # "$this$dp\\8":I
    .end local v4    # "$i$f$getDp\\8\\245":I
    invoke-interface {v1, v3}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v3

    sub-float/2addr v2, v3

    invoke-static {v15, v2}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v3

    sub-float v5, v20, v24

    const/high16 v2, 0x40000000    # 2.0f

    invoke-static {v5, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v2

    const/4 v5, 0x2

    .local v5, "$this$dp\\9":I
    const/4 v6, 0x0

    .line 1064
    .local v6, "$i$f$getDp\\9\\245":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 245
    .end local v5    # "$this$dp\\9":I
    .end local v6    # "$i$f$getDp\\9\\245":I
    invoke-interface {v1, v5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v5

    invoke-static {v2, v5}, Landroidx/compose/ui/geometry/SizeKt;->Size(FF)J

    move-result-wide v5

    const/16 v11, 0x78

    const/4 v12, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v0, v1

    move-wide/from16 v1, p8

    invoke-static/range {v0 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    move-object v1, v0

    .line 246
    :cond_8
    nop

    .line 1063
    .end local v14    # "f\\7":Lorg/lighttouch/android/HitchFrame;
    .end local v15    # "left\\7":F
    .end local v22    # "$i$a$-forEachIndexed-HitchInspectorKt$Detail$2$1$1\\7\\1063\\0":I
    .end local v23    # "b\\7":Lorg/lighttouch/android/FrameBreakdown;
    .end local v28    # "i\\7":I
    move v0, v13

    move/from16 v5, v20

    move/from16 v2, v21

    move/from16 v6, v24

    move-object/from16 v14, v25

    move-object/from16 v15, v26

    move-object/from16 v13, v29

    .end local v19    # "item\\6":Ljava/lang/Object;
    goto/16 :goto_4

    .line 1065
    .end local v20    # "w":F
    .end local v21    # "index\\6":I
    .end local v24    # "gap":F
    .end local v25    # "labelPaint":Landroid/graphics/Paint;
    .end local v26    # "guides":Ljava/util/List;
    .end local v29    # "canvas":Landroid/graphics/Canvas;
    .local v2, "index\\6":I
    .local v5, "w":F
    .local v6, "gap":F
    .restart local v13    # "canvas":Landroid/graphics/Canvas;
    .local v14, "labelPaint":Landroid/graphics/Paint;
    .local v15, "guides":Ljava/util/List;
    :cond_9
    move-object/from16 v29, v13

    move v13, v0

    .line 247
    .end local v2    # "index\\6":I
    .end local v13    # "canvas":Landroid/graphics/Canvas;
    .end local v16    # "$this$forEachIndexed\\6":Ljava/lang/Iterable;
    .end local v17    # "$i$f$forEachIndexed\\6\\229":I
    .restart local v29    # "canvas":Landroid/graphics/Canvas;
    move-object/from16 v0, v29

    .end local v29    # "canvas":Landroid/graphics/Canvas;
    .local v0, "canvas":Landroid/graphics/Canvas;
    invoke-static {v15, v0, v1, v14, v13}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$labels(Ljava/util/List;Landroid/graphics/Canvas;Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroid/graphics/Paint;F)V

    .line 248
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method private static final Detail$lambda$55$lambda$54$labels(Ljava/util/List;Landroid/graphics/Canvas;Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroid/graphics/Paint;F)V
    .locals 6
    .param p0, "guides"    # Ljava/util/List;
    .param p1, "canvas"    # Landroid/graphics/Canvas;
    .param p2, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p3, "labelPaint"    # Landroid/graphics/Paint;
    .param p4, "top"    # F
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;",
            "Landroid/graphics/Canvas;",
            "Landroidx/compose/ui/graphics/drawscope/DrawScope;",
            "Landroid/graphics/Paint;",
            "F)V"
        }
    .end annotation

    .line 225
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->floatValue()F

    move-result v1

    .local v1, "g":F
    sget-object v2, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x1

    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%.0f ms"

    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "format(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p2}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v3

    invoke-static {v3, v4}, Landroidx/compose/ui/geometry/Size;->getWidth-impl(J)F

    move-result v3

    const/high16 v4, 0x40800000    # 4.0f

    sub-float/2addr v3, v4

    invoke-static {p2, p4, v1}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v5

    sub-float/2addr v5, v4

    invoke-virtual {p1, v2, v3, v5, p3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .end local v1    # "g":F
    goto :goto_0

    :cond_0
    return-void
.end method

.method private static final Detail$lambda$55$lambda$54$lambda$53$seg(FLandroidx/compose/ui/graphics/drawscope/DrawScope;Lkotlin/jvm/internal/Ref$FloatRef;Lorg/lighttouch/android/HitchFrame;FFFFJ)V
    .locals 19
    .param p0, "top"    # F
    .param p1, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p2, "base"    # Lkotlin/jvm/internal/Ref$FloatRef;
    .param p3, "$f"    # Lorg/lighttouch/android/HitchFrame;
    .param p4, "left"    # F
    .param p5, "w"    # F
    .param p6, "gap"    # F
    .param p7, "ms"    # F
    .param p8, "color"    # J

    .line 236
    move/from16 v0, p0

    move-object/from16 v1, p2

    const/4 v2, 0x0

    move/from16 v3, p7

    invoke-static {v3, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v2

    div-float/2addr v2, v0

    invoke-interface/range {p1 .. p1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v4

    invoke-static {v4, v5}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v4

    mul-float/2addr v2, v4

    .line 237
    .local v2, "h":F
    iget v4, v1, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    sub-float/2addr v4, v2

    invoke-virtual/range {p3 .. p3}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v5

    move-object/from16 v6, p1

    invoke-static {v6, v0, v5}, Lorg/lighttouch/android/HitchInspectorKt;->Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v5

    invoke-static {v4, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(FF)F

    move-result v4

    .line 238
    .local v4, "segTop":F
    iget v5, v1, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    cmpl-float v5, v5, v4

    if-lez v5, :cond_0

    move/from16 v5, p4

    invoke-static {v5, v4}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v9

    sub-float v7, p5, p6

    iget v8, v1, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    sub-float/2addr v8, v4

    invoke-static {v7, v8}, Landroidx/compose/ui/geometry/SizeKt;->Size(FF)J

    move-result-wide v11

    const/16 v17, 0x78

    const/16 v18, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    move-wide/from16 v7, p8

    invoke-static/range {v6 .. v18}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    goto :goto_0

    :cond_0
    move/from16 v5, p4

    .line 239
    :goto_0
    iput v4, v1, Lkotlin/jvm/internal/Ref$FloatRef;->element:F

    .line 240
    return-void
.end method

.method private static final Detail$lambda$55$lambda$54$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F
    .locals 4
    .param p0, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p1, "top"    # F
    .param p2, "ms"    # F

    .line 221
    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    invoke-static {p2, p1}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v1

    div-float/2addr v1, p1

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v2

    mul-float/2addr v1, v2

    sub-float/2addr v0, v1

    return v0
.end method

.method private static final Detail$lambda$56(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/HitchInspectorKt;->Detail(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final EventRow(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V
    .locals 85
    .param p0, "event"    # Lorg/lighttouch/android/SlowEvent;
    .param p1, "start"    # J
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    .line 332
    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    move/from16 v3, p4

    const v4, 0x63b71db6

    move-object/from16 v5, p3

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    const-string v6, "C(EventRow)332@20351L662:HitchInspector.kt#o13vsk"

    invoke-static {v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v6, p4

    .local v6, "$dirty":I
    and-int/lit8 v7, v3, 0x6

    if-nez v7, :cond_1

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    :goto_0
    or-int/2addr v6, v7

    :cond_1
    and-int/lit8 v7, v3, 0x30

    if-nez v7, :cond_3

    invoke-interface {v5, v1, v2}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v7

    if-eqz v7, :cond_2

    const/16 v7, 0x20

    goto :goto_1

    :cond_2
    const/16 v7, 0x10

    :goto_1
    or-int/2addr v6, v7

    :cond_3
    and-int/lit8 v7, v6, 0x13

    const/16 v8, 0x12

    if-ne v7, v8, :cond_5

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v7

    if-nez v7, :cond_4

    goto :goto_2

    .line 1031
    :cond_4
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v28, v5

    move/from16 v19, v6

    goto/16 :goto_a

    .line 332
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_6

    const/4 v7, -0x1

    const-string v8, "org.lighttouch.android.EventRow (HitchInspector.kt:331)"

    invoke-static {v4, v6, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 333
    :cond_6
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v4, v7, v8, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v10, 0x3

    .local v10, "$this$dp\\1":I
    const/4 v11, 0x0

    .line 950
    .local v11, "$i$f$getDp\\1\\333":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 333
    .end local v10    # "$this$dp\\1":I
    .end local v11    # "$i$f$getDp\\1\\333":I
    invoke-static {v4, v7, v10, v8, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .local v4, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .local v7, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v9, 0x186

    .local v9, "$changed\\2":I
    const/4 v10, 0x0

    .line 951
    .local v10, "$i$f$Row\\2\\333":I
    const v11, 0x2952b718

    const-string v12, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v5, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 952
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    .line 956
    .local v11, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v12, v9, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v11, v7, v5, v12}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 957
    nop

    .local v13, "$changed\\3":I
    const/4 v14, 0x0

    .line 958
    .local v14, "$i$f$Layout\\3\\957":I
    const v15, -0x4ee9b9da

    const-string v8, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v5, v15, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 959
    const/4 v15, 0x0

    invoke-static {v5, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v17

    .line 960
    .local v17, "compositeKeyHash\\3":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 961
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v19, v6

    .end local v6    # "$dirty":I
    .local v19, "$dirty":I
    invoke-static {v5, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 963
    .local v6, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move-object/from16 v21, v4

    .end local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v21, "modifier\\2":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v13, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 962
    move-object/from16 v22, v20

    .local v4, "$changed\\4":I
    .local v22, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 964
    .local v20, "$i$f$ReusableComposeNode\\4\\962":I
    move/from16 v23, v4

    .end local v4    # "$changed\\4":I
    .local v23, "$changed\\4":I
    const v4, -0x2942ffcf

    move-object/from16 v24, v7

    .end local v7    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v24, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    const-string v7, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 965
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 966
    :cond_7
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 967
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_8

    .line 968
    move-object/from16 v4, v22

    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 970
    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v4, v22

    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 972
    :goto_3
    move-object/from16 v22, v4

    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 973
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\972\\3":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v28, v5

    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v28, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v12, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 974
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v15, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 976
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 977
    .local v27, "$i$f$set-impl\\6\\976":I
    move-object/from16 v29, v4

    .local v29, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 978
    .local v30, "$i$a$-with-Updater$set$1\\7\\977\\6":I
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v31

    if-nez v31, :cond_a

    move/from16 v31, v9

    .end local v9    # "$changed\\2":I
    .local v31, "$changed\\2":I
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move/from16 v32, v10

    .end local v10    # "$i$f$Row\\2\\333":I
    .local v32, "$i$f$Row\\2\\333":I
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v10, v29

    goto :goto_5

    .end local v31    # "$changed\\2":I
    .end local v32    # "$i$f$Row\\2\\333":I
    .restart local v9    # "$changed\\2":I
    .restart local v10    # "$i$f$Row\\2\\333":I
    :cond_a
    move/from16 v31, v9

    move/from16 v32, v10

    .line 979
    .end local v9    # "$changed\\2":I
    .end local v10    # "$i$f$Row\\2\\333":I
    .restart local v31    # "$changed\\2":I
    .restart local v32    # "$i$f$Row\\2\\333":I
    :goto_4
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v29

    .end local v29    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 980
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v4, v9, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 982
    :goto_5
    nop

    .line 977
    .end local v10    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-with-Updater$set$1\\7\\977\\6":I
    nop

    .line 982
    nop

    .line 983
    .end local v5    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v27    # "$i$f$set-impl\\6\\976":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v6, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 984
    nop

    .line 972
    .end local v4    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\972\\3":I
    nop

    .line 985
    shr-int/lit8 v4, v23, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\8":I
    move-object/from16 v5, v28

    .local v5, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 986
    .local v9, "$i$a$-Layout-RowKt$Row$1\\8\\985\\2":I
    const v10, -0x184f2606

    move/from16 v26, v4

    .end local v4    # "$changed\\8":I
    .local v26, "$changed\\8":I
    const-string v4, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v5, v10, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v31, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\9":I
    check-cast v4, Landroidx/compose/foundation/layout/RowScope;

    .local v4, "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v54, v5

    .local v54, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 334
    .local v27, "$i$a$-Row-HitchInspectorKt$EventRow$1\\9\\986\\0":I
    move-object/from16 v29, v4

    .end local v4    # "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v29, "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    const v4, -0x593f3e6f

    move-object/from16 v30, v5

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v5, "C333@20563L10,333@20463L235,335@20707L300:HitchInspector.kt#o13vsk"

    move-object/from16 v58, v6

    move-object/from16 v6, v54

    .end local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v58, "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0}, Lorg/lighttouch/android/SlowEvent;->getMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    move/from16 v59, v9

    const/4 v9, 0x1

    .end local v9    # "$i$a$-Layout-RowKt$Row$1\\8\\985\\2":I
    .local v59, "$i$a$-Layout-RowKt$Row$1\\8\\985\\2":I
    invoke-static {v5, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v5

    const-string v9, "%6.2f ms"

    invoke-static {v4, v9, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "format(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v9, 0x48

    .local v9, "$this$dp\\10":I
    const/16 v33, 0x0

    .line 987
    .local v33, "$i$f$getDp\\10\\334":I
    move-object/from16 p3, v4

    int-to-float v4, v9

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 334
    .end local v9    # "$this$dp\\10":I
    .end local v33    # "$i$f$getDp\\10\\334":I
    invoke-static {v5, v4}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v34

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v4

    invoke-static {}, Lorg/lighttouch/android/ThemeKt;->getMonoStyle()Landroidx/compose/ui/text/TextStyle;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroidx/compose/ui/text/TextStyle;->merge(Landroidx/compose/ui/text/TextStyle;)Landroidx/compose/ui/text/TextStyle;

    move-result-object v53

    const v4, 0x6879e6bd

    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "334@20676L11"

    invoke-static {v6, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 335
    invoke-virtual {v0}, Lorg/lighttouch/android/SlowEvent;->getMs()F

    move-result v4

    const/high16 v5, 0x41000000    # 8.0f

    cmpl-float v4, v4, v5

    if-lez v4, :cond_b

    sget-object v4, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v4}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v4

    goto :goto_6

    :cond_b
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v4

    :goto_6
    move-wide/from16 v35, v4

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 334
    nop

    .line 335
    nop

    .line 334
    const/16 v56, 0x0

    const v57, 0xfff8

    const-wide/16 v37, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const-wide/16 v46, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v55, 0x30

    move-object/from16 v33, p3

    move-object/from16 v54, v6

    .end local v6    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v33 .. v57}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 336
    .end local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v34, v4

    check-cast v34, Landroidx/compose/ui/Modifier;

    const/16 v37, 0x2

    const/16 v38, 0x0

    const/high16 v35, 0x3f800000    # 1.0f

    const/16 v36, 0x0

    move-object/from16 v33, v29

    .end local v29    # "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v33, "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v33 .. v38}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .end local v33    # "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v4, "modifier\\11":Landroidx/compose/ui/Modifier;
    .restart local v29    # "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    const/4 v5, 0x0

    .local v5, "$changed\\11":I
    const/4 v9, 0x0

    .line 988
    .local v9, "$i$f$Column\\11\\336":I
    move/from16 p3, v5

    .end local v5    # "$changed\\11":I
    .local p3, "$changed\\11":I
    const v5, -0x1cd0f17e

    move/from16 v33, v9

    .end local v9    # "$i$f$Column\\11\\336":I
    .local v33, "$i$f$Column\\11\\336":I
    const-string v9, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v6, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 989
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v5

    .line 990
    .local v5, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 993
    .local v9, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v34, p3, 0x3

    and-int/lit8 v34, v34, 0xe

    shr-int/lit8 v35, p3, 0x3

    and-int/lit8 v35, v35, 0x70

    move/from16 v36, v10

    .end local v10    # "$changed\\9":I
    .local v36, "$changed\\9":I
    or-int v10, v34, v35

    invoke-static {v5, v9, v6, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v34, p3, 0x3

    and-int/lit8 v34, v34, 0x70

    .line 994
    nop

    .local v34, "$changed\\12":I
    const/16 v35, 0x0

    .line 995
    .local v35, "$i$f$Layout\\12\\994":I
    move-object/from16 v37, v5

    const v5, -0x4ee9b9da

    .end local v5    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v37, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v6, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 996
    const/4 v5, 0x0

    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v5

    .line 997
    .local v5, "compositeKeyHash\\12":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 998
    .local v8, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v16, v5

    .end local v5    # "compositeKeyHash\\12":I
    .local v16, "compositeKeyHash\\12":I
    invoke-static {v6, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 1000
    .local v5, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v38, v4

    .end local v4    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v38, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v34, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 999
    nop

    .local v4, "$changed\\13":I
    move-object/from16 v39, v18

    .local v39, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 1001
    .local v18, "$i$f$ReusableComposeNode\\13\\999":I
    move/from16 v40, v4

    const v4, -0x2942ffcf

    .end local v4    # "$changed\\13":I
    .local v40, "$changed\\13":I
    invoke-static {v6, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1002
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1003
    :cond_c
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1004
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_d

    .line 1005
    move-object/from16 v4, v39

    .end local v39    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_7

    .line 1007
    .end local v4    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v39    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_d
    move-object/from16 v4, v39

    .end local v39    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1009
    :goto_7
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 1010
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1009\\12":I
    sget-object v39, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v41, v4

    .end local v4    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v41, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v7, v10, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1011
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v7, v8, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1013
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v39, 0x0

    .line 1014
    .local v39, "$i$f$set-impl\\15\\1013":I
    move-object/from16 v42, v7

    .local v42, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 1015
    .local v43, "$i$a$-with-Updater$set$1\\16\\1014\\15":I
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_f

    move-object/from16 v54, v6

    .end local v6    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v44, v8

    .end local v8    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v44, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_e

    goto :goto_8

    :cond_e
    move-object/from16 v8, v42

    goto :goto_9

    .end local v44    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v8    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_f
    move-object/from16 v54, v6

    move-object/from16 v44, v8

    .line 1016
    .end local v6    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v8    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v44    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :goto_8
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v8, v42

    .end local v42    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1017
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v7, v6, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1019
    :goto_9
    nop

    .line 1014
    .end local v8    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\16\\1014\\15":I
    nop

    .line 1019
    nop

    .line 1020
    .end local v4    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v39    # "$i$f$set-impl\\15\\1013":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v7, v5, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1021
    nop

    .line 1009
    .end local v7    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1009\\12":I
    nop

    .line 1022
    shr-int/lit8 v4, v40, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\17":I
    move-object/from16 v6, v54

    .local v6, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1023
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\17\\1022\\11":I
    const v8, -0x16ef5699

    move/from16 v25, v4

    .end local v4    # "$changed\\17":I
    .local v25, "$changed\\17":I
    const-string v4, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v6, v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v8, p3, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\18":I
    check-cast v4, Landroidx/compose/foundation/layout/ColumnScope;

    .local v4, "$this$EventRow_u24lambda_u2467_u24lambda_u2466\\18":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v81, v6

    .local v81, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 337
    .local v39, "$i$a$-Column-HitchInspectorKt$EventRow$1$1\\18\\1023\\9":I
    move-object/from16 v42, v4

    .end local v4    # "$this$EventRow_u24lambda_u2467_u24lambda_u2466\\18":Landroidx/compose/foundation/layout/ColumnScope;
    .local v42, "$this$EventRow_u24lambda_u2467_u24lambda_u2466\\18":Landroidx/compose/foundation/layout/ColumnScope;
    const v4, -0x5a23fcd1

    move-object/from16 v43, v5

    .end local v5    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .local v43, "materialized\\12":Landroidx/compose/ui/Modifier;
    const-string v5, "C336@20789L10,336@20749L75,337@20923L10,337@20968L11,337@20837L160:HitchInspector.kt#o13vsk"

    move-object/from16 v45, v6

    .end local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/SlowEvent;->getLabel()Ljava/lang/String;

    move-result-object v60

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v80

    const/16 v83, 0xc00

    const v84, 0xdffe

    const/16 v61, 0x0

    const-wide/16 v62, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const/16 v71, 0x0

    const/16 v72, 0x0

    const-wide/16 v73, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x1

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v82, 0x0

    .end local v6    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v84}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 338
    .end local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-virtual {v0}, Lorg/lighttouch/android/SlowEvent;->getKind()Lorg/lighttouch/android/EventKind;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/EventKind;->getLabel()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lorg/lighttouch/android/SlowEvent;->getStartNs()J

    move-result-wide v46

    sub-long v46, v46, v1

    invoke-static/range {v46 .. v47}, Lorg/lighttouch/android/HitchInspectorKt;->seconds(J)Ljava/lang/String;

    move-result-object v5

    move/from16 v46, v7

    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\17\\1022\\11":I
    .local v46, "$i$a$-Layout-ColumnKt$Column$1\\17\\1022\\11":I
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v7, " \u00b7 "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v60

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v80

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v6, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v62

    const/16 v83, 0x0

    const v84, 0xfffa

    const/16 v77, 0x0

    .end local v6    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v84}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 337
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 339
    nop

    .line 1023
    .end local v8    # "$changed\\18":I
    .end local v39    # "$i$a$-Column-HitchInspectorKt$EventRow$1$1\\18\\1023\\9":I
    .end local v42    # "$this$EventRow_u24lambda_u2467_u24lambda_u2466\\18":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1022
    .end local v25    # "$changed\\17":I
    .end local v45    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v46    # "$i$a$-Layout-ColumnKt$Column$1\\17\\1022\\11":I
    nop

    .line 1024
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1001
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1025
    nop

    .line 995
    .end local v18    # "$i$f$ReusableComposeNode\\13\\999":I
    .end local v40    # "$changed\\13":I
    .end local v41    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1026
    nop

    .line 988
    .end local v16    # "compositeKeyHash\\12":I
    .end local v34    # "$changed\\12":I
    .end local v35    # "$i$f$Layout\\12\\994":I
    .end local v43    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v44    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1027
    nop

    .line 334
    .end local v9    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v33    # "$i$f$Column\\11\\336":I
    .end local v37    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v38    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local p3    # "$changed\\11":I
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 340
    nop

    .line 986
    .end local v27    # "$i$a$-Row-HitchInspectorKt$EventRow$1\\9\\986\\0":I
    .end local v29    # "$this$EventRow_u24lambda_u2467\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v36    # "$changed\\9":I
    .end local v54    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 985
    .end local v26    # "$changed\\8":I
    .end local v30    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v59    # "$i$a$-Layout-RowKt$Row$1\\8\\985\\2":I
    nop

    .line 1028
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 964
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1029
    nop

    .line 958
    .end local v20    # "$i$f$ReusableComposeNode\\4\\962":I
    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v23    # "$changed\\4":I
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1030
    nop

    .line 951
    .end local v13    # "$changed\\3":I
    .end local v14    # "$i$f$Layout\\3\\957":I
    .end local v15    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "compositeKeyHash\\3":I
    .end local v58    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1031
    nop

    .end local v11    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v12    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v21    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v24    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v31    # "$changed\\2":I
    .end local v32    # "$i$f$Row\\2\\333":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_10
    :goto_a
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v4

    if-eqz v4, :cond_11

    new-instance v5, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda1;

    invoke-direct {v5, v0, v1, v2, v3}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/SlowEvent;JI)V

    invoke-interface {v4, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 341
    :cond_11
    return-void
.end method

.method private static final EventRow$lambda$68(Lorg/lighttouch/android/SlowEvent;JILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/HitchInspectorKt;->EventRow(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final FrameCard(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/runtime/Composer;I)V
    .locals 17
    .param p0, "data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "frame"    # Lorg/lighttouch/android/HitchFrame;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 283
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const v3, 0x4acb887

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(FrameCard)284@17007L11,284@16965L75,284@17101L3176,284@16938L3339:HitchInspector.kt#o13vsk"

    invoke-static {v13, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, v2, 0x6

    if-nez v5, :cond_1

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v2, 0x30

    if-nez v5, :cond_3

    invoke-interface {v13, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_5

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_2

    .line 285
    :cond_4
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v16, v4

    goto :goto_3

    .line 283
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.FrameCard (HitchInspector.kt:282)"

    invoke-static {v3, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 284
    :cond_6
    invoke-virtual/range {p0 .. p1}, Lorg/lighttouch/android/HitchData;->breakdownFor(Lorg/lighttouch/android/HitchFrame;)Lorg/lighttouch/android/FrameBreakdown;

    move-result-object v3

    .line 285
    .local v3, "b":Lorg/lighttouch/android/FrameBreakdown;
    move v5, v4

    .end local v4    # "$dirty":I
    .local v5, "$dirty":I
    sget-object v4, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v13, v7}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v6

    sget v8, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v14, v8, 0xc

    const/16 v15, 0xe

    move v9, v5

    move-wide v5, v6

    .end local v5    # "$dirty":I
    .local v9, "$dirty":I
    const-wide/16 v7, 0x0

    move v11, v9

    .end local v9    # "$dirty":I
    .local v11, "$dirty":I
    const-wide/16 v9, 0x0

    move/from16 v16, v11

    .end local v11    # "$dirty":I
    .local v16, "$dirty":I
    const-wide/16 v11, 0x0

    invoke-virtual/range {v4 .. v15}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v6

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v4, v5, v8, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const-string v5, "hitch_frame"

    invoke-static {v4, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    new-instance v5, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;

    invoke-direct {v5, v1, v0, v3}, Lorg/lighttouch/android/HitchInspectorKt$FrameCard$1;-><init>(Lorg/lighttouch/android/HitchFrame;Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/FrameBreakdown;)V

    const/16 v7, 0x36

    const v9, 0x71a10bf9

    invoke-static {v9, v8, v5, v13, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object v9, v5

    check-cast v9, Lkotlin/jvm/functions/Function3;

    const v11, 0x30006

    const/16 v12, 0x1a

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v10, v13

    .end local v13    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v4 .. v12}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v13    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v3    # "b":Lorg/lighttouch/android/FrameBreakdown;
    :cond_7
    :goto_3
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_8

    new-instance v4, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda16;

    invoke-direct {v4, v0, v1, v2}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda16;-><init>(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;I)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 329
    :cond_8
    return-void
.end method

.method private static final FrameCard$lambda$65(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/HitchInspectorKt;->FrameCard(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Histogram(Lorg/lighttouch/android/RangeStats;Landroidx/compose/runtime/Composer;I)V
    .locals 110
    .param p0, "stats"    # Lorg/lighttouch/android/RangeStats;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 265
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x24d4abd5

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Histogram)267@15976L845:HitchInspector.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    move v5, v6

    goto :goto_0

    :cond_0
    move v5, v7

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v4, 0x3

    if-ne v5, v7, :cond_3

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_1

    .line 949
    :cond_2
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v20, v3

    move/from16 v19, v4

    goto/16 :goto_d

    .line 265
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_4

    const/4 v5, -0x1

    const-string v8, "org.lighttouch.android.Histogram (HitchInspector.kt:264)"

    invoke-static {v2, v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 266
    :cond_4
    invoke-virtual {v0}, Lorg/lighttouch/android/RangeStats;->getBuckets()[I

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/ArraysKt;->maxOrNull([I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x0

    if-eqz v2, :cond_5

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    goto :goto_2

    :cond_5
    move v2, v5

    :goto_2
    const/4 v8, 0x1

    invoke-static {v2, v8}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    .line 267
    .local v2, "most":I
    const/4 v9, 0x7

    new-array v9, v9, [Landroidx/compose/ui/graphics/Color;

    sget-object v10, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v10}, Lorg/lighttouch/android/LtColors;->getAccent-0d7_KjU()J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v10

    aput-object v10, v9, v5

    sget-object v10, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v10}, Lorg/lighttouch/android/LtColors;->getAccent-0d7_KjU()J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v10

    aput-object v10, v9, v8

    sget-object v10, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v10}, Lorg/lighttouch/android/LtColors;->getAccent-0d7_KjU()J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v10

    aput-object v10, v9, v7

    sget-object v7, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v7}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v7

    const/4 v10, 0x3

    aput-object v7, v9, v10

    sget-object v7, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v7}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v10

    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v7

    aput-object v7, v9, v6

    sget-object v6, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v6}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v6

    invoke-static {v6, v7}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v6

    const/4 v7, 0x5

    aput-object v6, v9, v7

    sget-object v6, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v6}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v6

    invoke-static {v6, v7}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v6

    const/4 v7, 0x6

    aput-object v6, v9, v7

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 268
    .local v6, "colors":Ljava/util/List;
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const-string v10, "hitch_histogram"

    invoke-static {v9, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/4 v11, 0x4

    .local v11, "$this$dp\\1":I
    const/4 v12, 0x0

    .line 822
    .local v12, "$i$f$getDp\\1\\268":I
    int-to-float v13, v11

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 268
    .end local v11    # "$this$dp\\1":I
    .end local v12    # "$i$f$getDp\\1\\268":I
    invoke-virtual {v10, v11}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v10

    check-cast v10, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v10, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v11, 0x36

    .local v9, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v11, "$changed\\2":I
    const/4 v12, 0x0

    .line 823
    .local v12, "$i$f$Column\\2\\268":I
    const v13, -0x1cd0f17e

    const-string v14, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v3, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 824
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 827
    .local v13, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v14, v11, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v15, v11, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v14, v15

    invoke-static {v10, v13, v3, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v11, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 828
    nop

    .local v15, "$changed\\3":I
    const/16 v16, 0x0

    .line 829
    .local v16, "$i$f$Layout\\3\\828":I
    move/from16 p1, v7

    const v7, -0x4ee9b9da

    const-string v8, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 830
    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v17

    .line 831
    .local v17, "compositeKeyHash\\3":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 832
    .local v5, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 834
    .local v7, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move/from16 v19, v4

    .end local v4    # "$dirty":I
    .local v19, "$dirty":I
    shl-int/lit8 v4, v15, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 833
    move-object/from16 v20, v18

    .local v4, "$changed\\4":I
    .local v20, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 835
    .local v18, "$i$f$ReusableComposeNode\\4\\833":I
    move/from16 v21, v4

    .end local v4    # "$changed\\4":I
    .local v21, "$changed\\4":I
    const v4, -0x2942ffcf

    move-object/from16 v22, v9

    .end local v9    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-string v9, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 836
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_6

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 837
    :cond_6
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 838
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_7

    .line 839
    move-object/from16 v4, v20

    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 841
    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_7
    move-object/from16 v4, v20

    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 843
    :goto_3
    move-object/from16 v20, v3

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v20, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 844
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\843\\3":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v25, v4

    .end local v4    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v25, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v14, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 845
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v5, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 847
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 848
    .local v24, "$i$f$set-impl\\6\\847":I
    move-object/from16 v26, v3

    .local v26, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 849
    .local v27, "$i$a$-with-Updater$set$1\\7\\848\\6":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_9

    move-object/from16 v28, v5

    .end local v5    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v28, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v29, v10

    .end local v10    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v29, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v5, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_8

    goto :goto_4

    :cond_8
    move-object/from16 v10, v26

    goto :goto_5

    .end local v28    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v29    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v5    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_9
    move-object/from16 v28, v5

    move-object/from16 v29, v10

    .line 850
    .end local v5    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v28    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v29    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_4
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v10, v26

    .end local v26    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 851
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v3, v5, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 853
    :goto_5
    nop

    .line 848
    .end local v10    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-with-Updater$set$1\\7\\848\\6":I
    nop

    .line 853
    nop

    .line 854
    .end local v4    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\6\\847":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 855
    nop

    .line 843
    .end local v3    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\843\\3":I
    nop

    .line 856
    shr-int/lit8 v3, v21, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\8":I
    move-object/from16 v4, v20

    .local v4, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 857
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\8\\856\\2":I
    const v10, -0x16ef5699

    move/from16 v23, v3

    .end local v3    # "$changed\\8":I
    .local v23, "$changed\\8":I
    const-string v3, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v10, v11, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\9":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$Histogram_u24lambda_u2463\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v24, v4

    .local v24, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 269
    .local v26, "$i$a$-Column-HitchInspectorKt$Histogram$1\\9\\857\\0":I
    move-object/from16 v27, v3

    .end local v3    # "$this$Histogram_u24lambda_u2463\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v27, "$this$Histogram_u24lambda_u2463\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, 0x1232c703

    move-object/from16 v30, v4

    .end local v4    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v4, "C:HitchInspector.kt#o13vsk"

    move/from16 v31, v5

    move-object/from16 v5, v24

    .end local v24    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v31, "$i$a$-Layout-ColumnKt$Column$1\\8\\856\\2":I
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v3, 0x8d85be8

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*269@16145L660"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Lorg/lighttouch/android/RangeStats;->Companion:Lorg/lighttouch/android/RangeStats$Companion;

    invoke-virtual {v3}, Lorg/lighttouch/android/RangeStats$Companion;->getBucketLabels()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$forEachIndexed\\10":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 858
    .local v4, "$i$f$forEachIndexed\\10\\269":I
    const/16 v24, 0x0

    .line 859
    .local v24, "index\\10":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v32

    :goto_6
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    move-result v33

    if-eqz v33, :cond_13

    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v33

    .local v33, "item\\10":Ljava/lang/Object;
    add-int/lit8 v34, v24, 0x1

    .end local v24    # "index\\10":I
    .local v34, "index\\10":I
    if-gez v24, :cond_a

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_a
    move-object/from16 v35, v33

    check-cast v35, Ljava/lang/String;

    .local v24, "i\\11":I
    .local v35, "label\\11":Ljava/lang/String;
    move/from16 v60, v24

    .end local v24    # "i\\11":I
    .local v60, "i\\11":I
    const/16 v24, 0x0

    .line 270
    .local v24, "$i$a$-forEachIndexed-HitchInspectorKt$Histogram$1$1\\11\\859\\9":I
    sget-object v36, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move-object/from16 v61, v3

    .end local v3    # "$this$forEachIndexed\\10":Ljava/lang/Iterable;
    .local v61, "$this$forEachIndexed\\10":Ljava/lang/Iterable;
    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .local v3, "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v36, 0x180

    .local v36, "$changed\\12":I
    move/from16 v62, v36

    .end local v36    # "$changed\\12":I
    .local v62, "$changed\\12":I
    const/16 v63, 0x0

    .line 860
    .local v63, "$i$f$Row\\12\\270":I
    move/from16 v64, v4

    .end local v4    # "$i$f$forEachIndexed\\10\\269":I
    .local v64, "$i$f$forEachIndexed\\10\\269":I
    const v4, 0x2952b718

    move-object/from16 v65, v7

    .end local v7    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v65, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 861
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    .line 862
    .local v4, "modifier\\12":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    .line 866
    .local v7, "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v36, v62, 0x3

    and-int/lit8 v36, v36, 0xe

    shr-int/lit8 v37, v62, 0x3

    and-int/lit8 v37, v37, 0x70

    move/from16 v66, v10

    .end local v10    # "$changed\\9":I
    .local v66, "$changed\\9":I
    or-int v10, v36, v37

    invoke-static {v7, v3, v5, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v36, v62, 0x3

    and-int/lit8 v36, v36, 0x70

    .line 867
    move/from16 v67, v36

    .local v67, "$changed\\13":I
    const/16 v68, 0x0

    .line 868
    .local v68, "$i$f$Layout\\13\\867":I
    move-object/from16 v69, v3

    const v3, -0x4ee9b9da

    .end local v3    # "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    .local v69, "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v5, v3, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 869
    const/4 v3, 0x0

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v70

    .line 870
    .local v70, "compositeKeyHash\\13":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 871
    .local v3, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v71, v7

    .end local v7    # "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v71, "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v5, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 873
    .local v7, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v36, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v36

    move-object/from16 v72, v4

    .end local v4    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v72, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v67, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 872
    nop

    .local v4, "$changed\\14":I
    move-object/from16 v73, v36

    .local v73, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v74, 0x0

    .line 874
    .local v74, "$i$f$ReusableComposeNode\\14\\872":I
    move/from16 v75, v4

    const v4, -0x2942ffcf

    .end local v4    # "$changed\\14":I
    .local v75, "$changed\\14":I
    invoke-static {v5, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 875
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 876
    :cond_b
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 877
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_c

    .line 878
    move-object/from16 v4, v73

    .end local v73    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_7

    .line 880
    .end local v4    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v73    # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v4, v73

    .end local v73    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 882
    :goto_7
    move-object/from16 v73, v4

    .end local v4    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v73    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 883
    .local v36, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\882\\13":I
    sget-object v37, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v76, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v76, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v37 .. v37}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v10, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 884
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 886
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v37, 0x0

    .line 887
    .local v37, "$i$f$set-impl\\16\\886":I
    move-object/from16 v38, v4

    .local v38, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 888
    .local v39, "$i$a$-with-Updater$set$1\\17\\887\\16":I
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v40

    if-nez v40, :cond_e

    move-object/from16 v77, v3

    .end local v3    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v77, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v78, v10

    .end local v10    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v78, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v70 .. v70}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v3, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_d

    goto :goto_8

    :cond_d
    move-object/from16 v10, v38

    goto :goto_9

    .end local v77    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v78    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_e
    move-object/from16 v77, v3

    move-object/from16 v78, v10

    .line 889
    .end local v3    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v77    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v78    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_8
    invoke-static/range {v70 .. v70}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v10, v38

    .end local v38    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 890
    invoke-static/range {v70 .. v70}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v4, v3, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 892
    :goto_9
    nop

    .line 887
    .end local v10    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v39    # "$i$a$-with-Updater$set$1\\17\\887\\16":I
    nop

    .line 892
    nop

    .line 893
    .end local v5    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v37    # "$i$f$set-impl\\16\\886":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 894
    nop

    .line 882
    .end local v4    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\882\\13":I
    nop

    .line 895
    shr-int/lit8 v3, v75, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\18":I
    move-object/from16 v4, v76

    .local v4, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 896
    .local v5, "$i$a$-Layout-RowKt$Row$1\\18\\895\\12":I
    const v10, -0x184f2606

    move/from16 v79, v3

    .end local v3    # "$changed\\18":I
    .local v79, "$changed\\18":I
    const-string v3, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v4, v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v62, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\19":I
    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    .local v3, "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461\\19":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v56, v4

    .local v56, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v105, 0x0

    .line 271
    .local v105, "$i$a$-Row-HitchInspectorKt$Histogram$1$1$1\\19\\896\\11":I
    move-object/from16 v80, v3

    .end local v3    # "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v80, "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461\\19":Landroidx/compose/foundation/layout/RowScope;
    const v3, 0x7f852638

    move-object/from16 v106, v4

    .end local v4    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v106, "$composer\\18":Landroidx/compose/runtime/Composer;
    const-string v4, "C270@16272L10,270@16317L11,270@16215L131,271@16363L224,274@16677L10,274@16604L187:HitchInspector.kt#o13vsk"

    move/from16 v107, v5

    move-object/from16 v5, v56

    .end local v56    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v107, "$i$a$-Layout-RowKt$Row$1\\18\\895\\12":I
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x48

    .local v4, "$this$dp\\20":I
    const/16 v36, 0x0

    .line 897
    .local v36, "$i$f$getDp\\20\\271":I
    move-object/from16 v108, v7

    .end local v7    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v108, "materialized\\13":Landroidx/compose/ui/Modifier;
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 271
    .end local v4    # "$this$dp\\20":I
    .end local v36    # "$i$f$getDp\\20\\271":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v36

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v55

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v37

    const/16 v58, 0x0

    const v59, 0xfff8

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const-wide/16 v44, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v57, 0x30

    .end local v5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v56    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v35 .. v59}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 272
    .end local v56    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v37, v3

    check-cast v37, Landroidx/compose/ui/Modifier;

    const/16 v40, 0x2

    const/high16 v38, 0x3f800000    # 1.0f

    const/16 v39, 0x0

    move-object/from16 v36, v80

    .end local v80    # "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v36, "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461\\19":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v36 .. v41}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v4, 0xe

    .local v4, "$this$dp\\21":I
    const/4 v7, 0x0

    .line 898
    .local v7, "$i$f$getDp\\21\\272":I
    move/from16 v37, v7

    .end local v7    # "$i$f$getDp\\21\\272":I
    .local v37, "$i$f$getDp\\21\\272":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 272
    .end local v4    # "$this$dp\\21":I
    .end local v37    # "$i$f$getDp\\21\\272":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\22":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x0

    .local v4, "$changed\\22":I
    const/4 v7, 0x0

    .line 899
    .local v7, "$i$f$Box\\22\\272":I
    move/from16 v37, v4

    .end local v4    # "$changed\\22":I
    .local v37, "$changed\\22":I
    const v4, 0x2bb5b5d7

    move/from16 v38, v7

    .end local v7    # "$i$f$Box\\22\\272":I
    .local v38, "$i$f$Box\\22\\272":I
    const-string v7, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 900
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 901
    .local v4, "contentAlignment\\22":Landroidx/compose/ui/Alignment;
    const/4 v7, 0x0

    .line 904
    .local v7, "propagateMinConstraints\\22":Z
    move/from16 v39, v10

    .end local v10    # "$changed\\19":I
    .local v39, "$changed\\19":I
    invoke-static {v4, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v40, v37, 0x3

    and-int/lit8 v40, v40, 0x70

    .line 905
    nop

    .local v40, "$changed\\23":I
    const/16 v41, 0x0

    .line 906
    .local v41, "$i$f$Layout\\23\\905":I
    move-object/from16 v42, v4

    const v4, -0x4ee9b9da

    .end local v4    # "contentAlignment\\22":Landroidx/compose/ui/Alignment;
    .local v42, "contentAlignment\\22":Landroidx/compose/ui/Alignment;
    invoke-static {v5, v4, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 907
    const/4 v4, 0x0

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v43

    .line 908
    .local v43, "compositeKeyHash\\23":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 909
    .local v4, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v44, v7

    .end local v7    # "propagateMinConstraints\\22":Z
    .local v44, "propagateMinConstraints\\22":Z
    invoke-static {v5, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 911
    .local v7, "materialized\\23":Landroidx/compose/ui/Modifier;
    sget-object v45, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v45 .. v45}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v45

    move-object/from16 v46, v3

    .end local v3    # "modifier\\22":Landroidx/compose/ui/Modifier;
    .local v46, "modifier\\22":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v40, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 910
    nop

    .local v3, "$changed\\24":I
    move-object/from16 v47, v45

    .local v47, "factory\\24":Lkotlin/jvm/functions/Function0;
    const/16 v45, 0x0

    .line 912
    .local v45, "$i$f$ReusableComposeNode\\24\\910":I
    move/from16 v48, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\24":I
    .local v48, "$changed\\24":I
    invoke-static {v5, v3, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 913
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 914
    :cond_f
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 915
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_10

    .line 916
    move-object/from16 v3, v47

    .end local v47    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\24":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 918
    .end local v3    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .restart local v47    # "factory\\24":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v3, v47

    .end local v47    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\24":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 920
    :goto_a
    move-object/from16 v47, v3

    .end local v3    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .restart local v47    # "factory\\24":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    const/16 v49, 0x0

    .line 921
    .local v49, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\25\\920\\23":I
    sget-object v50, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v51, v8

    invoke-virtual/range {v50 .. v50}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v3, v10, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 922
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v3, v4, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 924
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\26":Lkotlin/jvm/functions/Function2;
    const/16 v50, 0x0

    .line 925
    .local v50, "$i$f$set-impl\\26\\924":I
    move-object/from16 v52, v3

    .local v52, "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 926
    .local v53, "$i$a$-with-Updater$set$1\\27\\925\\26":I
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v54

    if-nez v54, :cond_12

    move-object/from16 v54, v4

    .end local v4    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .local v54, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v55, v9

    invoke-static/range {v43 .. v43}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_11

    goto :goto_b

    :cond_11
    move-object/from16 v9, v52

    goto :goto_c

    .end local v54    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_12
    move-object/from16 v54, v4

    move-object/from16 v55, v9

    .line 927
    .end local v4    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v54    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_b
    invoke-static/range {v43 .. v43}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v9, v52

    .end local v52    # "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 928
    invoke-static/range {v43 .. v43}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 930
    :goto_c
    nop

    .line 925
    .end local v9    # "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$a$-with-Updater$set$1\\27\\925\\26":I
    nop

    .line 930
    nop

    .line 931
    .end local v8    # "block\\26":Lkotlin/jvm/functions/Function2;
    .end local v50    # "$i$f$set-impl\\26\\924":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 932
    nop

    .line 920
    .end local v3    # "$this$Layout_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    .end local v49    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\25\\920\\23":I
    nop

    .line 933
    shr-int/lit8 v3, v48, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\28":I
    move-object v4, v5

    .local v4, "$composer\\28":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 934
    .local v8, "$i$a$-Layout-BoxKt$Box$1\\28\\933\\22":I
    const v9, -0x7ff519f7    # -1.000876E-39f

    move/from16 v49, v3

    .end local v3    # "$changed\\28":I
    .local v49, "$changed\\28":I
    const-string v3, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v4, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v9, v37, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\29":I
    check-cast v3, Landroidx/compose/foundation/layout/BoxScope;

    .local v3, "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461_u24lambda_u2460\\29":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v50, v4

    .local v50, "$composer\\29":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 273
    .local v52, "$i$a$-Box-HitchInspectorKt$Histogram$1$1$1$1\\29\\934\\19":I
    move-object/from16 v53, v3

    .end local v3    # "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461_u24lambda_u2460\\29":Landroidx/compose/foundation/layout/BoxScope;
    .local v53, "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461_u24lambda_u2460\\29":Landroidx/compose/foundation/layout/BoxScope;
    const v3, -0x623c9bbf

    move-object/from16 v56, v4

    .end local v4    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v56, "$composer\\28":Landroidx/compose/runtime/Composer;
    const-string v4, "C272@16424L145:HitchInspector.kt#o13vsk"

    move-object/from16 v57, v7

    move-object/from16 v7, v50

    .end local v50    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\29":Landroidx/compose/runtime/Composer;
    .local v57, "materialized\\23":Landroidx/compose/ui/Modifier;
    invoke-static {v7, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    move/from16 v50, v8

    .end local v8    # "$i$a$-Layout-BoxKt$Box$1\\28\\933\\22":I
    .local v50, "$i$a$-Layout-BoxKt$Box$1\\28\\933\\22":I
    const/4 v8, 0x0

    move/from16 v58, v9

    const/4 v9, 0x1

    .end local v9    # "$changed\\29":I
    .local v58, "$changed\\29":I
    invoke-static {v3, v4, v9, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxHeight$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-virtual {v0}, Lorg/lighttouch/android/RangeStats;->getBuckets()[I

    move-result-object v4

    aget v4, v4, v60

    int-to-float v4, v4

    int-to-float v8, v2

    div-float/2addr v4, v8

    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v4, v60

    .end local v60    # "i\\11":I
    .local v4, "i\\11":I
    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/compose/ui/graphics/Color;

    invoke-virtual {v8}, Landroidx/compose/ui/graphics/Color;->unbox-impl()J

    move-result-wide v80

    const/16 v86, 0xe

    const/16 v87, 0x0

    const v82, 0x3f59999a    # 0.85f

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    move-object v8, v10

    .end local v10    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v8, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v80 .. v87}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v9

    move/from16 v59, v2

    .end local v2    # "most":I
    .local v59, "most":I
    const/4 v2, 0x3

    .local v2, "$this$dp\\30":I
    const/16 v60, 0x0

    .line 935
    .local v60, "$i$f$getDp\\30\\273":I
    move/from16 v109, v4

    .end local v4    # "i\\11":I
    .local v109, "i\\11":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 273
    .end local v2    # "$this$dp\\30":I
    .end local v60    # "$i$f$getDp\\30\\273":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    check-cast v2, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v9, v10, v2}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v2, v7, v3}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 274
    nop

    .line 934
    .end local v7    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-Box-HitchInspectorKt$Histogram$1$1$1$1\\29\\934\\19":I
    .end local v53    # "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461_u24lambda_u2460\\29":Landroidx/compose/foundation/layout/BoxScope;
    .end local v58    # "$changed\\29":I
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 933
    .end local v49    # "$changed\\28":I
    .end local v50    # "$i$a$-Layout-BoxKt$Box$1\\28\\933\\22":I
    .end local v56    # "$composer\\28":Landroidx/compose/runtime/Composer;
    nop

    .line 936
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 912
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 937
    nop

    .line 906
    .end local v45    # "$i$f$ReusableComposeNode\\24\\910":I
    .end local v47    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .end local v48    # "$changed\\24":I
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 938
    nop

    .line 899
    .end local v40    # "$changed\\23":I
    .end local v41    # "$i$f$Layout\\23\\905":I
    .end local v43    # "compositeKeyHash\\23":I
    .end local v54    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57    # "materialized\\23":Landroidx/compose/ui/Modifier;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 939
    nop

    .line 275
    .end local v8    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v37    # "$changed\\22":I
    .end local v38    # "$i$f$Box\\22\\272":I
    .end local v42    # "contentAlignment\\22":Landroidx/compose/ui/Alignment;
    .end local v44    # "propagateMinConstraints\\22":Z
    .end local v46    # "modifier\\22":Landroidx/compose/ui/Modifier;
    invoke-virtual {v0}, Lorg/lighttouch/android/RangeStats;->getBuckets()[I

    move-result-object v2

    aget v2, v2, v109

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v80

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x2c

    .local v4, "$this$dp\\31":I
    const/4 v7, 0x0

    .line 940
    .local v7, "$i$f$getDp\\31\\275":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 275
    .end local v4    # "$this$dp\\31":I
    .end local v7    # "$i$f$getDp\\31\\275":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v81

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v100

    .line 276
    sget-object v2, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getEnd-e0LSkKk()I

    move-result v2

    .line 275
    nop

    .line 276
    invoke-static {v2}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v92

    .line 275
    const/16 v103, 0xc00

    const v104, 0xddfc

    const-wide/16 v82, 0x0

    const-wide/16 v84, 0x0

    const/16 v86, 0x0

    const/16 v88, 0x0

    const-wide/16 v89, 0x0

    const/16 v91, 0x0

    const-wide/16 v93, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x1

    const/16 v98, 0x0

    const/16 v99, 0x0

    const/16 v102, 0x30

    move-object/from16 v101, v5

    .end local v5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v101, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v80 .. v104}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 271
    .end local v101    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 277
    nop

    .line 896
    .end local v5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v36    # "$this$Histogram_u24lambda_u2463_u24lambda_u2462_u24lambda_u2461\\19":Landroidx/compose/foundation/layout/RowScope;
    .end local v39    # "$changed\\19":I
    .end local v105    # "$i$a$-Row-HitchInspectorKt$Histogram$1$1$1\\19\\896\\11":I
    invoke-static/range {v106 .. v106}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 895
    .end local v79    # "$changed\\18":I
    .end local v106    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v107    # "$i$a$-Layout-RowKt$Row$1\\18\\895\\12":I
    nop

    .line 941
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 874
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 942
    nop

    .line 868
    .end local v73    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .end local v74    # "$i$f$ReusableComposeNode\\14\\872":I
    .end local v75    # "$changed\\14":I
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 943
    nop

    .line 860
    .end local v67    # "$changed\\13":I
    .end local v68    # "$i$f$Layout\\13\\867":I
    .end local v70    # "compositeKeyHash\\13":I
    .end local v77    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v108    # "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 944
    nop

    .line 278
    .end local v62    # "$changed\\12":I
    .end local v63    # "$i$f$Row\\12\\270":I
    .end local v69    # "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    .end local v71    # "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v72    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v78    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    nop

    .line 859
    .end local v24    # "$i$a$-forEachIndexed-HitchInspectorKt$Histogram$1$1\\11\\859\\9":I
    .end local v35    # "label\\11":Ljava/lang/String;
    .end local v109    # "i\\11":I
    move/from16 v24, v34

    move-object/from16 v8, v51

    move-object/from16 v9, v55

    move/from16 v2, v59

    move-object/from16 v3, v61

    move/from16 v4, v64

    move-object/from16 v7, v65

    move/from16 v10, v66

    move-object/from16 v5, v76

    .end local v33    # "item\\10":Ljava/lang/Object;
    goto/16 :goto_6

    .line 945
    .end local v34    # "index\\10":I
    .end local v59    # "most":I
    .end local v61    # "$this$forEachIndexed\\10":Ljava/lang/Iterable;
    .end local v64    # "$i$f$forEachIndexed\\10\\269":I
    .end local v65    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v66    # "$changed\\9":I
    .end local v76    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "most":I
    .local v3, "$this$forEachIndexed\\10":Ljava/lang/Iterable;
    .local v4, "$i$f$forEachIndexed\\10\\269":I
    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v7, "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v10, "$changed\\9":I
    .local v24, "index\\10":I
    :cond_13
    move/from16 v59, v2

    move-object/from16 v61, v3

    move/from16 v64, v4

    move-object/from16 v76, v5

    move-object/from16 v65, v7

    move/from16 v66, v10

    .end local v2    # "most":I
    .end local v3    # "$this$forEachIndexed\\10":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEachIndexed\\10\\269":I
    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v7    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v10    # "$changed\\9":I
    .end local v24    # "index\\10":I
    .restart local v59    # "most":I
    .restart local v65    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .restart local v66    # "$changed\\9":I
    .restart local v76    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 269
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 279
    nop

    .line 857
    .end local v26    # "$i$a$-Column-HitchInspectorKt$Histogram$1\\9\\857\\0":I
    .end local v27    # "$this$Histogram_u24lambda_u2463\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v66    # "$changed\\9":I
    .end local v76    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 856
    .end local v23    # "$changed\\8":I
    .end local v30    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-Layout-ColumnKt$Column$1\\8\\856\\2":I
    nop

    .line 946
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 835
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 947
    nop

    .line 829
    .end local v18    # "$i$f$ReusableComposeNode\\4\\833":I
    .end local v21    # "$changed\\4":I
    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 948
    nop

    .line 823
    .end local v15    # "$changed\\3":I
    .end local v16    # "$i$f$Layout\\3\\828":I
    .end local v17    # "compositeKeyHash\\3":I
    .end local v28    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v65    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 949
    nop

    .end local v11    # "$changed\\2":I
    .end local v12    # "$i$f$Column\\2\\268":I
    .end local v13    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v14    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v29    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v6    # "colors":Ljava/util/List;
    .end local v59    # "most":I
    :cond_14
    :goto_d
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_15

    new-instance v3, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda3;

    invoke-direct {v3, v0, v1}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/RangeStats;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 280
    :cond_15
    return-void
.end method

.method private static final Histogram$lambda$64(Lorg/lighttouch/android/RangeStats;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/HitchInspectorKt;->Histogram(Lorg/lighttouch/android/RangeStats;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final HitchInspector(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 23
    .param p0, "data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "loadError"    # Ljava/lang/String;
    .param p2, "onResume"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onSave"    # Lkotlin/jvm/functions/Function2;
    .param p4, "saving"    # Z
    .param p5, "savedNotice"    # Ljava/lang/String;
    .param p6, "onShare"    # Lkotlin/jvm/functions/Function0;
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/HitchData;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v7, p2

    move-object/from16 v3, p3

    move/from16 v8, p8

    const-string v0, "onResume"

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onSave"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 42
    const v0, -0x5645b0fe

    move-object/from16 v1, p7

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(HitchInspector)P(!4,6,5)42@1805L30,43@1916L1537,43@1840L1613:HitchInspector.kt#o13vsk"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p8

    .local v1, "$dirty":I
    and-int/lit8 v2, v8, 0x6

    if-nez v2, :cond_1

    move-object/from16 v2, p0

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v1, v4

    goto :goto_1

    :cond_1
    move-object/from16 v2, p0

    :goto_1
    and-int/lit8 v4, v8, 0x30

    if-nez v4, :cond_3

    move-object/from16 v4, p1

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_2

    :cond_2
    const/16 v5, 0x10

    :goto_2
    or-int/2addr v1, v5

    goto :goto_3

    :cond_3
    move-object/from16 v4, p1

    :goto_3
    and-int/lit16 v5, v8, 0x180

    if-nez v5, :cond_5

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x100

    goto :goto_4

    :cond_4
    const/16 v5, 0x80

    :goto_4
    or-int/2addr v1, v5

    :cond_5
    and-int/lit16 v5, v8, 0xc00

    if-nez v5, :cond_7

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6

    const/16 v5, 0x800

    goto :goto_5

    :cond_6
    const/16 v5, 0x400

    :goto_5
    or-int/2addr v1, v5

    :cond_7
    and-int/lit16 v5, v8, 0x6000

    if-nez v5, :cond_9

    move/from16 v5, p4

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_8

    const/16 v6, 0x4000

    goto :goto_6

    :cond_8
    const/16 v6, 0x2000

    :goto_6
    or-int/2addr v1, v6

    goto :goto_7

    :cond_9
    move/from16 v5, p4

    :goto_7
    const/high16 v6, 0x30000

    and-int/2addr v6, v8

    if-nez v6, :cond_b

    move-object/from16 v6, p5

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_a

    const/high16 v10, 0x20000

    goto :goto_8

    :cond_a
    const/high16 v10, 0x10000

    :goto_8
    or-int/2addr v1, v10

    goto :goto_9

    :cond_b
    move-object/from16 v6, p5

    :goto_9
    const/high16 v10, 0x180000

    and-int/2addr v10, v8

    if-nez v10, :cond_d

    move-object/from16 v10, p6

    invoke-interface {v9, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_c

    const/high16 v11, 0x100000

    goto :goto_a

    :cond_c
    const/high16 v11, 0x80000

    :goto_a
    or-int/2addr v1, v11

    goto :goto_b

    :cond_d
    move-object/from16 v10, p6

    :goto_b
    move v11, v1

    .end local v1    # "$dirty":I
    .local v11, "$dirty":I
    const v1, 0x92493

    and-int/2addr v1, v11

    const v12, 0x92492

    if-ne v1, v12, :cond_f

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_e

    goto :goto_c

    .line 44
    :cond_e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v19, v9

    move/from16 v22, v11

    goto :goto_d

    .line 42
    :cond_f
    :goto_c
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_10

    const/4 v1, -0x1

    const-string v12, "org.lighttouch.android.HitchInspector (HitchInspector.kt:41)"

    invoke-static {v0, v11, v1, v12}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 43
    :cond_10
    shr-int/lit8 v0, v11, 0x3

    and-int/lit8 v0, v0, 0x70

    const/4 v1, 0x0

    const/4 v12, 0x1

    invoke-static {v1, v7, v9, v0, v12}, Landroidx/activity/compose/BackHandlerKt;->BackHandler(ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 44
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v13, 0x0

    invoke-static {v0, v1, v12, v13}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {}, Lorg/lighttouch/android/ShellKt;->getDialogTags()Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-interface {v0, v1}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "hitch_inspector"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;

    move-object v1, v4

    move v4, v5

    move-object v5, v6

    move-object v6, v10

    invoke-direct/range {v0 .. v7}, Lorg/lighttouch/android/HitchInspectorKt$HitchInspector$1;-><init>(Ljava/lang/String;Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    const/16 v1, 0x36

    const v2, -0x1f839f23

    invoke-static {v2, v12, v0, v9, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v18, v0

    check-cast v18, Lkotlin/jvm/functions/Function2;

    const/high16 v20, 0xc00000

    const/16 v21, 0x7e

    const/4 v10, 0x0

    move v1, v11

    .end local v11    # "$dirty":I
    .restart local v1    # "$dirty":I
    const-wide/16 v11, 0x0

    move-object/from16 v19, v9

    move-object v9, v13

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move/from16 v22, v1

    .end local v1    # "$dirty":I
    .local v22, "$dirty":I
    invoke-static/range {v9 .. v21}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_11
    :goto_d
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_12

    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda15;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    invoke-direct/range {v0 .. v8}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda15;-><init>(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 65
    :cond_12
    return-void
.end method

.method private static final HitchInspector$lambda$0(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 10

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    move-object v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p8

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/HitchInspectorKt;->HitchInspector(Lorg/lighttouch/android/HitchData;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InspectorBody(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 106
    .param p0, "data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "onSave"    # Lkotlin/jvm/functions/Function2;
    .param p2, "saving"    # Z
    .param p3, "savedNotice"    # Ljava/lang/String;
    .param p4, "onShare"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/HitchData;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 77
    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move/from16 v8, p2

    move-object/from16 v9, p3

    move-object/from16 v10, p4

    move/from16 v11, p6

    const v1, 0x31ab245

    move-object/from16 v2, p5

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(InspectorBody)P(!2,4,3)80@4223L360,85@4601L42,86@4662L122,87@4804L66,88@4887L46,90@4984L21,90@4939L4164:HitchInspector.kt#o13vsk"

    invoke-static {v12, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p6

    .local v1, "$dirty":I
    and-int/lit8 v2, v11, 0x6

    if-nez v2, :cond_1

    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v1, v2

    :cond_1
    and-int/lit8 v2, v11, 0x30

    if-nez v2, :cond_3

    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0x20

    goto :goto_1

    :cond_2
    const/16 v2, 0x10

    :goto_1
    or-int/2addr v1, v2

    :cond_3
    and-int/lit16 v2, v11, 0x180

    if-nez v2, :cond_5

    invoke-interface {v12, v8}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v2

    if-eqz v2, :cond_4

    const/16 v2, 0x100

    goto :goto_2

    :cond_4
    const/16 v2, 0x80

    :goto_2
    or-int/2addr v1, v2

    :cond_5
    and-int/lit16 v2, v11, 0xc00

    if-nez v2, :cond_7

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    const/16 v2, 0x800

    goto :goto_3

    :cond_6
    const/16 v2, 0x400

    :goto_3
    or-int/2addr v1, v2

    :cond_7
    and-int/lit16 v2, v11, 0x6000

    if-nez v2, :cond_9

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    const/16 v2, 0x4000

    goto :goto_4

    :cond_8
    const/16 v2, 0x2000

    :goto_4
    or-int/2addr v1, v2

    :cond_9
    move v14, v1

    .end local v1    # "$dirty":I
    .local v14, "$dirty":I
    and-int/lit16 v1, v14, 0x2493

    const/16 v2, 0x2492

    if-ne v1, v2, :cond_b

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_a

    goto :goto_5

    .line 656
    :cond_a
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v75, v12

    move/from16 v38, v14

    goto/16 :goto_37

    .line 77
    :cond_b
    :goto_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_c

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.InspectorBody (HitchInspector.kt:76)"

    const v3, 0x31ab245

    invoke-static {v3, v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 78
    :cond_c
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getStartNs()J

    move-result-wide v1

    .line 79
    .local v1, "start":J
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/lighttouch/android/HitchFrame;

    invoke-virtual {v3}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v3

    .local v3, "end":J
    const v15, 0x4c5de2

    invoke-interface {v12, v15}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "CC(remember):HitchInspector.kt#9igjgp"

    invoke-static {v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 81
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    .local v5, "invalid\\1":Z
    move-object/from16 p5, v12

    .local p5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 381
    .local v16, "$i$f$cache\\1\\81":I
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\1":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 382
    .local v18, "$i$a$-let-ComposerKt$cache$1\\2\\381\\1":I
    if-nez v5, :cond_e

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_d

    goto :goto_6

    .line 404
    :cond_d
    move-wide/from16 v29, v1

    move/from16 v25, v5

    move-object v1, v13

    move-object/from16 v2, p5

    goto/16 :goto_c

    .line 383
    :cond_e
    :goto_6
    const/4 v15, 0x0

    .line 82
    .local v15, "$i$a$-cache-HitchInspectorKt$InspectorBody$initial$1\\3\\383\\0":I
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v21

    check-cast v21, Ljava/lang/Iterable;

    .local v21, "$this$filter\\4":Ljava/lang/Iterable;
    const/16 v23, 0x0

    .line 384
    .local v23, "$i$f$filter\\4\\82":I
    new-instance v24, Ljava/util/ArrayList;

    invoke-direct/range {v24 .. v24}, Ljava/util/ArrayList;-><init>()V

    move/from16 v25, v5

    .end local v5    # "invalid\\1":Z
    .local v25, "invalid\\1":Z
    move-object/from16 v5, v24

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\5":Ljava/util/Collection;
    move-object/from16 v24, v21

    .local v24, "$this$filterTo\\5":Ljava/lang/Iterable;
    const/16 v26, 0x0

    .line 385
    .local v26, "$i$f$filterTo\\5\\384":I
    invoke-interface/range {v24 .. v24}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v27

    :goto_7
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->hasNext()Z

    move-result v28

    if-eqz v28, :cond_11

    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\5":Ljava/lang/Object;
    move-object/from16 v28, v9

    check-cast v28, Lorg/lighttouch/android/HitchFrame;

    .local v28, "it\\6":Lorg/lighttouch/android/HitchFrame;
    const/16 v29, 0x0

    .line 82
    .local v29, "$i$a$-filter-HitchInspectorKt$InspectorBody$initial$1$recent$1\\6\\385\\3":I
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIdle()Z

    move-result v30

    if-nez v30, :cond_f

    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v30

    sub-long v30, v3, v30

    const-wide v32, 0x2540be400L

    cmp-long v30, v30, v32

    if-gez v30, :cond_f

    const/16 v28, 0x1

    goto :goto_8

    :cond_f
    const/16 v28, 0x0

    .line 385
    .end local v28    # "it\\6":Lorg/lighttouch/android/HitchFrame;
    .end local v29    # "$i$a$-filter-HitchInspectorKt$InspectorBody$initial$1$recent$1\\6\\385\\3":I
    :goto_8
    if-eqz v28, :cond_10

    invoke-interface {v5, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_10
    move-object/from16 v9, p3

    goto :goto_7

    .line 386
    .end local v9    # "element\\5":Ljava/lang/Object;
    :cond_11
    nop

    .end local v5    # "destination\\5":Ljava/util/Collection;
    .end local v24    # "$this$filterTo\\5":Ljava/lang/Iterable;
    .end local v26    # "$i$f$filterTo\\5\\384":I
    check-cast v5, Ljava/util/List;

    .line 384
    nop

    .end local v21    # "$this$filter\\4":Ljava/lang/Iterable;
    .end local v23    # "$i$f$filter\\4\\82":I
    check-cast v5, Ljava/util/Collection;

    .line 82
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_14

    .line 387
    const/4 v5, 0x0

    .line 82
    .local v5, "$i$a$-ifEmpty-HitchInspectorKt$InspectorBody$initial$1$recent$2\\7\\82\\3":I
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$filter\\8":Ljava/lang/Iterable;
    const/16 v21, 0x0

    .line 384
    .local v21, "$i$f$filter\\8\\82":I
    new-instance v23, Ljava/util/ArrayList;

    invoke-direct/range {v23 .. v23}, Ljava/util/ArrayList;-><init>()V

    move/from16 v24, v5

    .end local v5    # "$i$a$-ifEmpty-HitchInspectorKt$InspectorBody$initial$1$recent$2\\7\\82\\3":I
    .local v24, "$i$a$-ifEmpty-HitchInspectorKt$InspectorBody$initial$1$recent$2\\7\\82\\3":I
    move-object/from16 v5, v23

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\9":Ljava/util/Collection;
    move-object/from16 v23, v9

    .local v23, "$this$filterTo\\9":Ljava/lang/Iterable;
    const/16 v26, 0x0

    .line 385
    .local v26, "$i$f$filterTo\\9\\384":I
    invoke-interface/range {v23 .. v23}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v27

    :goto_9
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->hasNext()Z

    move-result v28

    if-eqz v28, :cond_13

    move-object/from16 v28, v9

    .end local v9    # "$this$filter\\8":Ljava/lang/Iterable;
    .local v28, "$this$filter\\8":Ljava/lang/Iterable;
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\9":Ljava/lang/Object;
    move-object/from16 v29, v9

    check-cast v29, Lorg/lighttouch/android/HitchFrame;

    .local v29, "it\\10":Lorg/lighttouch/android/HitchFrame;
    const/16 v30, 0x0

    .line 82
    .local v30, "$i$a$-filter-HitchInspectorKt$InspectorBody$initial$1$recent$2$1\\10\\385\\7":I
    invoke-virtual/range {v29 .. v29}, Lorg/lighttouch/android/HitchFrame;->getIdle()Z

    move-result v31

    .line 385
    .end local v29    # "it\\10":Lorg/lighttouch/android/HitchFrame;
    .end local v30    # "$i$a$-filter-HitchInspectorKt$InspectorBody$initial$1$recent$2$1\\10\\385\\7":I
    if-nez v31, :cond_12

    invoke-interface {v5, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_12
    move-object/from16 v9, v28

    goto :goto_9

    .line 386
    .end local v28    # "$this$filter\\8":Ljava/lang/Iterable;
    .local v9, "$this$filter\\8":Ljava/lang/Iterable;
    :cond_13
    move-object/from16 v28, v9

    .end local v5    # "destination\\9":Ljava/util/Collection;
    .end local v9    # "$this$filter\\8":Ljava/lang/Iterable;
    .end local v23    # "$this$filterTo\\9":Ljava/lang/Iterable;
    .end local v26    # "$i$f$filterTo\\9\\384":I
    .restart local v28    # "$this$filter\\8":Ljava/lang/Iterable;
    check-cast v5, Ljava/util/List;

    .line 384
    nop

    .line 82
    .end local v21    # "$i$f$filter\\8\\82":I
    .end local v28    # "$this$filter\\8":Ljava/lang/Iterable;
    nop

    .end local v24    # "$i$a$-ifEmpty-HitchInspectorKt$InspectorBody$initial$1$recent$2\\7\\82\\3":I
    :cond_14
    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_15

    .line 387
    const/4 v5, 0x0

    .line 82
    .local v5, "$i$a$-ifEmpty-HitchInspectorKt$InspectorBody$initial$1$recent$3\\11\\82\\3":I
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v5

    .end local v5    # "$i$a$-ifEmpty-HitchInspectorKt$InspectorBody$initial$1$recent$3\\11\\82\\3":I
    :cond_15
    check-cast v5, Ljava/util/List;

    .line 83
    .local v5, "recent\\3":Ljava/util/List;
    move-object v9, v5

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$maxBy\\12":Ljava/lang/Iterable;
    const/16 v21, 0x0

    .line 388
    .local v21, "$i$f$maxByOrThrow\\12\\83":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v23

    .line 389
    .local v23, "iterator\\12":Ljava/util/Iterator;
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v24

    if-eqz v24, :cond_4e

    .line 390
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v24

    .line 391
    .local v24, "maxElem\\12":Ljava/lang/Object;
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v26

    if-nez v26, :cond_16

    move-object/from16 v26, v5

    goto :goto_b

    .line 392
    :cond_16
    move-object/from16 v26, v24

    check-cast v26, Lorg/lighttouch/android/HitchFrame;

    .local v26, "it\\13":Lorg/lighttouch/android/HitchFrame;
    const/16 v27, 0x0

    .line 83
    .local v27, "$i$a$-maxByOrThrow-HitchInspectorKt$InspectorBody$initial$1$worst$1\\13\\392\\3":I
    invoke-virtual/range {v26 .. v26}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v26

    .line 392
    .end local v26    # "it\\13":Lorg/lighttouch/android/HitchFrame;
    .end local v27    # "$i$a$-maxByOrThrow-HitchInspectorKt$InspectorBody$initial$1$worst$1\\13\\392\\3":I
    move/from16 v105, v26

    move-object/from16 v26, v5

    move/from16 v5, v105

    .line 394
    .local v5, "maxValue\\12":F
    .local v26, "recent\\3":Ljava/util/List;
    :goto_a
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27

    .line 395
    .local v27, "e\\12":Ljava/lang/Object;
    move-object/from16 v28, v27

    check-cast v28, Lorg/lighttouch/android/HitchFrame;

    .local v28, "it\\14":Lorg/lighttouch/android/HitchFrame;
    const/16 v29, 0x0

    .line 83
    .local v29, "$i$a$-maxByOrThrow-HitchInspectorKt$InspectorBody$initial$1$worst$1\\14\\395\\3":I
    invoke-virtual/range {v28 .. v28}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v28

    .line 395
    .end local v28    # "it\\14":Lorg/lighttouch/android/HitchFrame;
    .end local v29    # "$i$a$-maxByOrThrow-HitchInspectorKt$InspectorBody$initial$1$worst$1\\14\\395\\3":I
    move/from16 v29, v28

    .line 396
    .local v29, "v\\12":F
    move-object/from16 v28, v9

    move/from16 v9, v29

    .end local v29    # "v\\12":F
    .local v9, "v\\12":F
    .local v28, "$this$maxBy\\12":Ljava/lang/Iterable;
    invoke-static {v5, v9}, Ljava/lang/Float;->compare(FF)I

    move-result v29

    if-gez v29, :cond_17

    .line 397
    move-object/from16 v24, v27

    .line 398
    move v5, v9

    .line 400
    .end local v9    # "v\\12":F
    .end local v27    # "e\\12":Ljava/lang/Object;
    :cond_17
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-nez v9, :cond_4d

    .line 401
    nop

    .line 83
    .end local v5    # "maxValue\\12":F
    .end local v21    # "$i$f$maxByOrThrow\\12\\83":I
    .end local v23    # "iterator\\12":Ljava/util/Iterator;
    .end local v24    # "maxElem\\12":Ljava/lang/Object;
    .end local v28    # "$this$maxBy\\12":Ljava/lang/Iterable;
    :goto_b
    move-object/from16 v5, v24

    check-cast v5, Lorg/lighttouch/android/HitchFrame;

    .line 84
    .local v5, "worst\\3":Lorg/lighttouch/android/HitchFrame;
    invoke-virtual {v5}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v23

    const-wide/32 v27, 0x3b9aca00

    sub-long v9, v23, v27

    invoke-static {v9, v10, v1, v2}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-virtual {v5}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v23

    move-wide/from16 v29, v1

    .end local v1    # "start":J
    .local v29, "start":J
    add-long v1, v23, v27

    invoke-static {v1, v2, v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtMost(JJ)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-static {v9, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    .line 383
    .end local v5    # "worst\\3":Lorg/lighttouch/android/HitchFrame;
    .end local v15    # "$i$a$-cache-HitchInspectorKt$InspectorBody$initial$1\\3\\383\\0":I
    .end local v26    # "recent\\3":Ljava/util/List;
    nop

    .line 402
    .local v1, "value\\2":Ljava/lang/Object;
    move-object/from16 v2, p5

    .end local p5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .local v2, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 403
    nop

    .line 382
    .end local v1    # "value\\2":Ljava/lang/Object;
    :goto_c
    nop

    .line 381
    .end local v13    # "it\\1":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\2\\381\\1":I
    nop

    .line 81
    .end local v2    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$f$cache\\1\\81":I
    .end local v25    # "invalid\\1":Z
    move-object v9, v1

    check-cast v9, Lkotlin/Pair;

    .local v9, "initial":Lkotlin/Pair;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v1, 0x4c5de2

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 86
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\15":Z
    move-object v2, v12

    .local v2, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 405
    .local v5, "$i$f$cache\\15\\86":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\15":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 406
    .local v13, "$i$a$-let-ComposerKt$cache$1\\16\\405\\15":I
    if-nez v1, :cond_19

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v10, v15, :cond_18

    goto :goto_d

    .line 410
    :cond_18
    move/from16 v16, v1

    move-wide/from16 v31, v3

    move-object v4, v10

    goto :goto_e

    .line 407
    :cond_19
    :goto_d
    const/4 v15, 0x0

    .line 86
    .local v15, "$i$a$-cache-HitchInspectorKt$InspectorBody$range$2\\17\\407\\0":I
    move/from16 v16, v1

    move-wide/from16 v31, v3

    const/4 v1, 0x2

    const/4 v3, 0x0

    .end local v1    # "invalid\\15":Z
    .end local v3    # "end":J
    .local v16, "invalid\\15":Z
    .local v31, "end":J
    invoke-static {v9, v3, v1, v3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 407
    .end local v15    # "$i$a$-cache-HitchInspectorKt$InspectorBody$range$2\\17\\407\\0":I
    nop

    .line 408
    .local v4, "value\\16":Ljava/lang/Object;
    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 409
    nop

    .line 406
    .end local v4    # "value\\16":Ljava/lang/Object;
    :goto_e
    nop

    .line 405
    .end local v10    # "it\\15":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\16\\405\\15":I
    nop

    .line 86
    .end local v2    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\15\\86":I
    .end local v16    # "invalid\\15":Z
    move-object v10, v4

    check-cast v10, Landroidx/compose/runtime/MutableState;

    .local v10, "range$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v1, 0x4c5de2

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 87
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\18":Z
    move-object v3, v12

    .local v3, "$this$cache\\18":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 411
    .local v4, "$i$f$cache\\18\\87":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\18":Ljava/lang/Object;
    const/16 v27, 0x0

    .line 412
    .local v27, "$i$a$-let-ComposerKt$cache$1\\19\\411\\18":I
    if-nez v1, :cond_1b

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v2, v5, :cond_1a

    goto :goto_f

    .line 430
    :cond_1a
    move/from16 v34, v1

    move-object v13, v2

    move/from16 v35, v4

    goto/16 :goto_12

    .line 413
    :cond_1b
    :goto_f
    const/16 v33, 0x0

    .line 87
    .local v33, "$i$a$-cache-HitchInspectorKt$InspectorBody$picked$2\\20\\413\\0":I
    invoke-virtual {v9}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    move/from16 v34, v1

    move-object v13, v2

    .end local v1    # "invalid\\18":Z
    .end local v2    # "it\\18":Ljava/lang/Object;
    .local v13, "it\\18":Ljava/lang/Object;
    .local v34, "invalid\\18":Z
    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    invoke-virtual {v9}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    move/from16 v35, v4

    .end local v4    # "$i$f$cache\\18\\87":I
    .local v35, "$i$f$cache\\18\\87":I
    invoke-virtual {v5}, Ljava/lang/Number;->longValue()J

    move-result-wide v4

    invoke-virtual {v0, v1, v2, v4, v5}, Lorg/lighttouch/android/HitchData;->framesIn(JJ)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$maxByOrNull\\21":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 414
    .local v4, "$i$f$maxByOrNull\\21\\87":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v36

    .line 415
    .local v36, "iterator\\21":Ljava/util/Iterator;
    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_1c

    const/4 v2, 0x0

    goto :goto_11

    .line 416
    :cond_1c
    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 417
    .local v2, "maxElem\\21":Ljava/lang/Object;
    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-nez v5, :cond_1d

    goto :goto_11

    .line 418
    :cond_1d
    move-object v5, v2

    check-cast v5, Lorg/lighttouch/android/HitchFrame;

    .local v5, "it\\22":Lorg/lighttouch/android/HitchFrame;
    const/4 v15, 0x0

    .line 87
    .local v15, "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$picked$2$1\\22\\418\\20":I
    invoke-virtual {v5}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v5

    .line 418
    .end local v5    # "it\\22":Lorg/lighttouch/android/HitchFrame;
    .end local v15    # "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$picked$2$1\\22\\418\\20":I
    nop

    .line 420
    .local v5, "maxValue\\21":F
    :goto_10
    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .line 421
    .local v15, "e\\21":Ljava/lang/Object;
    move-object/from16 v16, v15

    check-cast v16, Lorg/lighttouch/android/HitchFrame;

    .local v16, "it\\23":Lorg/lighttouch/android/HitchFrame;
    const/16 v18, 0x0

    .line 87
    .local v18, "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$picked$2$1\\23\\421\\20":I
    invoke-virtual/range {v16 .. v16}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v16

    .line 421
    .end local v16    # "it\\23":Lorg/lighttouch/android/HitchFrame;
    .end local v18    # "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$picked$2$1\\23\\421\\20":I
    move/from16 v18, v16

    .line 422
    .local v18, "v\\21":F
    move-object/from16 v37, v1

    move/from16 v1, v18

    .end local v18    # "v\\21":F
    .local v1, "v\\21":F
    .local v37, "$this$maxByOrNull\\21":Ljava/lang/Iterable;
    invoke-static {v5, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v16

    if-gez v16, :cond_1e

    .line 423
    move-object v2, v15

    .line 424
    move v5, v1

    .line 426
    .end local v1    # "v\\21":F
    .end local v15    # "e\\21":Ljava/lang/Object;
    :cond_1e
    invoke-interface/range {v36 .. v36}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_4c

    .line 427
    nop

    .line 87
    .end local v2    # "maxElem\\21":Ljava/lang/Object;
    .end local v4    # "$i$f$maxByOrNull\\21\\87":I
    .end local v5    # "maxValue\\21":F
    .end local v36    # "iterator\\21":Ljava/util/Iterator;
    .end local v37    # "$this$maxByOrNull\\21":Ljava/lang/Iterable;
    :goto_11
    const/4 v1, 0x2

    const/4 v4, 0x0

    invoke-static {v2, v4, v1, v4}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    .line 413
    .end local v33    # "$i$a$-cache-HitchInspectorKt$InspectorBody$picked$2\\20\\413\\0":I
    nop

    .line 428
    .local v2, "value\\19":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 429
    nop

    .line 412
    .end local v2    # "value\\19":Ljava/lang/Object;
    :goto_12
    nop

    .line 411
    .end local v13    # "it\\18":Ljava/lang/Object;
    .end local v27    # "$i$a$-let-ComposerKt$cache$1\\19\\411\\18":I
    nop

    .line 87
    .end local v3    # "$this$cache\\18":Landroidx/compose/runtime/Composer;
    .end local v34    # "invalid\\18":Z
    .end local v35    # "$i$f$cache\\18\\87":I
    move-object v13, v2

    check-cast v13, Landroidx/compose/runtime/MutableState;

    .local v13, "picked$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 88
    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v1

    const v15, -0x615d173a

    invoke-interface {v12, v15}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v1, v2

    .local v1, "invalid\\24":Z
    move-object v2, v12

    .local v2, "$this$cache\\24":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 431
    .local v3, "$i$f$cache\\24\\88":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\24":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 432
    .local v5, "$i$a$-let-ComposerKt$cache$1\\25\\431\\24":I
    if-nez v1, :cond_20

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v4, v15, :cond_1f

    goto :goto_13

    .line 436
    :cond_1f
    move/from16 v21, v3

    move-object v3, v4

    move-object/from16 v23, v3

    move/from16 v38, v14

    goto :goto_14

    .line 433
    :cond_20
    :goto_13
    const/4 v15, 0x0

    .line 88
    .local v15, "$i$a$-cache-HitchInspectorKt$InspectorBody$selected$1\\26\\433\\0":I
    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/Number;

    move/from16 v21, v3

    move-object/from16 v23, v4

    .end local v3    # "$i$f$cache\\24\\88":I
    .end local v4    # "it\\24":Ljava/lang/Object;
    .local v21, "$i$f$cache\\24\\88":I
    .local v23, "it\\24":Ljava/lang/Object;
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/Number;

    move/from16 v38, v14

    move/from16 v24, v15

    .end local v14    # "$dirty":I
    .end local v15    # "$i$a$-cache-HitchInspectorKt$InspectorBody$selected$1\\26\\433\\0":I
    .local v24, "$i$a$-cache-HitchInspectorKt$InspectorBody$selected$1\\26\\433\\0":I
    .local v38, "$dirty":I
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J

    move-result-wide v14

    invoke-virtual {v0, v3, v4, v14, v15}, Lorg/lighttouch/android/HitchData;->framesIn(JJ)Ljava/util/List;

    move-result-object v3

    .line 433
    .end local v24    # "$i$a$-cache-HitchInspectorKt$InspectorBody$selected$1\\26\\433\\0":I
    nop

    .line 434
    .local v3, "value\\25":Ljava/lang/Object;
    invoke-interface {v2, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 435
    nop

    .line 432
    .end local v3    # "value\\25":Ljava/lang/Object;
    :goto_14
    nop

    .line 431
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\25\\431\\24":I
    .end local v23    # "it\\24":Ljava/lang/Object;
    nop

    .line 88
    .end local v1    # "invalid\\24":Z
    .end local v2    # "$this$cache\\24":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$f$cache\\24\\88":I
    move-object v14, v3

    check-cast v14, Ljava/util/List;

    .local v14, "selected":Ljava/util/List;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v1, 0x4c5de2

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 89
    invoke-interface {v12, v14}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\27":Z
    move-object v2, v12

    .local v2, "$this$cache\\27":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 437
    .local v3, "$i$f$cache\\27\\89":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\27":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 438
    .local v5, "$i$a$-let-ComposerKt$cache$1\\28\\437\\27":I
    if-nez v1, :cond_22

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v4, v15, :cond_21

    goto :goto_15

    .line 442
    :cond_21
    move/from16 v16, v1

    move-object v1, v4

    goto :goto_16

    .line 439
    :cond_22
    :goto_15
    const/4 v15, 0x0

    .line 89
    .local v15, "$i$a$-cache-HitchInspectorKt$InspectorBody$stats$1\\29\\439\\0":I
    move/from16 v16, v1

    .end local v1    # "invalid\\27":Z
    .local v16, "invalid\\27":Z
    sget-object v1, Lorg/lighttouch/android/RangeStats;->Companion:Lorg/lighttouch/android/RangeStats$Companion;

    invoke-virtual {v1, v14}, Lorg/lighttouch/android/RangeStats$Companion;->of(Ljava/util/List;)Lorg/lighttouch/android/RangeStats;

    move-result-object v1

    .line 439
    .end local v15    # "$i$a$-cache-HitchInspectorKt$InspectorBody$stats$1\\29\\439\\0":I
    nop

    .line 440
    .local v1, "value\\28":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 441
    nop

    .line 438
    .end local v1    # "value\\28":Ljava/lang/Object;
    :goto_16
    nop

    .line 437
    .end local v4    # "it\\27":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\28\\437\\27":I
    nop

    .line 89
    .end local v2    # "$this$cache\\27":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\27\\89":I
    .end local v16    # "invalid\\27":Z
    move-object v15, v1

    check-cast v15, Lorg/lighttouch/android/RangeStats;

    .local v15, "stats":Lorg/lighttouch/android/RangeStats;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 91
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v2, v4, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v39

    const/4 v1, 0x0

    invoke-static {v1, v12, v1, v4}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v40

    const/16 v44, 0xe

    const/16 v45, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    invoke-static/range {v39 .. v45}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v3, 0x10

    .local v3, "$this$dp\\30":I
    const/4 v4, 0x0

    .line 443
    .local v4, "$i$f$getDp\\30\\91":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 91
    .end local v3    # "$this$dp\\30":I
    .end local v4    # "$i$f$getDp\\30\\91":I
    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1, v3, v2, v4, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\31":Landroidx/compose/ui/Modifier;
    const/4 v3, 0x0

    .local v3, "$changed\\31":I
    move/from16 v23, v3

    .end local v3    # "$changed\\31":I
    .local v23, "$changed\\31":I
    const/16 v24, 0x0

    .line 444
    .local v24, "$i$f$Column\\31\\91":I
    const v3, -0x1cd0f17e

    const-string v4, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v12, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 445
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v3

    .line 446
    .local v3, "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 449
    .local v4, "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v5, v23, 0x3

    and-int/lit8 v5, v5, 0xe

    shr-int/lit8 v16, v23, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v5, v5, v16

    invoke-static {v3, v4, v12, v5}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .local v5, "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v23, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 450
    move/from16 v25, v16

    .local v25, "$changed\\32":I
    const/16 v26, 0x0

    .line 451
    .local v26, "$i$f$Layout\\32\\450":I
    const v2, -0x4ee9b9da

    move-object/from16 v39, v9

    .end local v9    # "initial":Lkotlin/Pair;
    .local v39, "initial":Lkotlin/Pair;
    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v12, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 452
    const/4 v2, 0x0

    invoke-static {v12, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v27

    .line 453
    .local v27, "compositeKeyHash\\32":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 454
    .local v2, "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v12, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 456
    .local v11, "materialized\\32":Landroidx/compose/ui/Modifier;
    sget-object v28, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v28 .. v28}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v28

    move-object/from16 v33, v1

    .end local v1    # "modifier\\31":Landroidx/compose/ui/Modifier;
    .local v33, "modifier\\31":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v25, 0x6

    and-int/lit16 v1, v1, 0x380

    move-object/from16 v34, v14

    .end local v14    # "selected":Ljava/util/List;
    .local v34, "selected":Ljava/util/List;
    const/4 v14, 0x6

    or-int/2addr v1, v14

    .line 455
    move/from16 v35, v1

    .local v35, "$changed\\33":I
    move-object/from16 v1, v28

    .local v1, "factory\\33":Lkotlin/jvm/functions/Function0;
    const/16 v28, 0x0

    .line 457
    .local v28, "$i$f$ReusableComposeNode\\33\\455":I
    move/from16 v36, v14

    const v14, -0x2942ffcf

    const-string v8, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v12, v14, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 458
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 459
    :cond_23
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 460
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_24

    .line 461
    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_17

    .line 463
    :cond_24
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 465
    :goto_17
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    const/16 v40, 0x0

    .line 466
    .local v40, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\34\\465\\32":I
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v42, v1

    .end local v1    # "factory\\33":Lkotlin/jvm/functions/Function0;
    .local v42, "factory\\33":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v14, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 467
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v14, v2, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 469
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\35":Lkotlin/jvm/functions/Function2;
    const/16 v41, 0x0

    .line 470
    .local v41, "$i$f$set-impl\\35\\469":I
    move-object/from16 v43, v14

    .local v43, "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    const/16 v44, 0x0

    .line 471
    .local v44, "$i$a$-with-Updater$set$1\\36\\470\\35":I
    invoke-interface/range {v43 .. v43}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v45

    if-nez v45, :cond_26

    move-object/from16 v45, v2

    .end local v2    # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .local v45, "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v43 .. v43}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v46, v3

    .end local v3    # "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v46, "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_25

    goto :goto_18

    :cond_25
    move-object/from16 v3, v43

    goto :goto_19

    .end local v45    # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v46    # "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v2    # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_26
    move-object/from16 v45, v2

    move-object/from16 v46, v3

    .line 472
    .end local v2    # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v45    # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v46    # "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_18
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v43

    .end local v43    # "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 473
    invoke-static/range {v27 .. v27}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v14, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 475
    :goto_19
    nop

    .line 470
    .end local v3    # "$this$set_impl_u24lambda_u240\\35":Landroidx/compose/runtime/Composer;
    .end local v44    # "$i$a$-with-Updater$set$1\\36\\470\\35":I
    nop

    .line 475
    nop

    .line 476
    .end local v1    # "block\\35":Lkotlin/jvm/functions/Function2;
    .end local v41    # "$i$f$set-impl\\35\\469":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v14, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 477
    nop

    .line 465
    .end local v14    # "$this$Layout_u24lambda_u240\\34":Landroidx/compose/runtime/Composer;
    .end local v40    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\34\\465\\32":I
    nop

    .line 478
    shr-int/lit8 v1, v35, 0x6

    and-int/lit8 v40, v1, 0xe

    .local v40, "$changed\\37":I
    move-object v1, v12

    .local v1, "$composer\\37":Landroidx/compose/runtime/Composer;
    move-object v14, v1

    .end local v1    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .local v14, "$composer\\37":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 479
    .local v41, "$i$a$-Layout-ColumnKt$Column$1\\37\\478\\31":I
    const v1, -0x16ef5699

    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v2, v23, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v43, v2, 0x6

    .local v43, "$changed\\38":I
    move-object/from16 v44, v1

    check-cast v44, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, v4

    .end local v4    # "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .local v1, "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .local v44, "$this$InspectorBody_u24lambda_u2437\\38":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v4, v14

    .local v4, "$composer\\38":Landroidx/compose/runtime/Composer;
    const/16 v72, 0x0

    .line 92
    .local v72, "$i$a$-Column-HitchInspectorKt$InspectorBody$1\\38\\479\\0":I
    const v2, -0xc6fbb4b

    const-string v3, "C91@5046L119,92@5261L93,92@5174L180,93@5363L579,100@5951L30,101@6085L15,101@5990L110,103@6145L30,104@6184L484,110@6677L30,111@6716L52,112@6777L16,114@6901L104,133@8259L30,134@8298L596,144@9067L30:HitchInspector.kt#o13vsk"

    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    move-object/from16 v74, v14

    move-object/from16 v73, v15

    .end local v14    # "$composer\\37":Landroidx/compose/runtime/Composer;
    .end local v15    # "stats":Lorg/lighttouch/android/RangeStats;
    .local v73, "stats":Lorg/lighttouch/android/RangeStats;
    .local v74, "$composer\\37":Landroidx/compose/runtime/Composer;
    sub-long v14, v31, v29

    long-to-double v14, v14

    const-wide v47, 0x41cdcd6500000000L    # 1.0E9

    div-double v14, v14, v47

    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v14, 0x1

    invoke-static {v3, v14}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v14, "%.0f"

    invoke-static {v2, v14, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v14, "format(...)"

    invoke-static {v2, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "\u6700\u8fd1 "

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u79d2 \u00b7 \u62d6\u52a8\u9009\u62e9\u8303\u56f4\uff0c\u8f7b\u6309\u8df3\u8f6c"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v2, v4, v3}, Lorg/lighttouch/android/HitchInspectorKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 93
    move-object v2, v1

    .end local v1    # "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .local v2, "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v1

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    move-object/from16 v16, v1

    move-object/from16 v47, v2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v15, 0x0

    .end local v2    # "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .local v47, "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v3, v15, v2, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v1, 0x48

    .local v1, "$this$dp\\39":I
    const/4 v2, 0x0

    .line 480
    .local v2, "$i$f$getDp\\39\\93":I
    int-to-float v15, v1

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 93
    .end local v1    # "$this$dp\\39":I
    .end local v2    # "$i$f$getDp\\39\\93":I
    invoke-static {v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "hitch_overview"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const v1, -0x6815fd56

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v12, v13}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    .local v1, "invalid\\40":Z
    move-object v3, v4

    .local v3, "$this$cache\\40":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 481
    .local v15, "$i$f$cache\\40\\93":I
    move/from16 v49, v1

    .end local v1    # "invalid\\40":Z
    .local v49, "invalid\\40":Z
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\40":Ljava/lang/Object;
    const/16 v50, 0x0

    .line 482
    .local v50, "$i$a$-let-ComposerKt$cache$1\\41\\481\\40":I
    if-nez v49, :cond_28

    sget-object v51, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v52, v2

    invoke-virtual/range {v51 .. v51}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_27

    goto :goto_1a

    .line 486
    :cond_27
    move-object/from16 v51, v1

    goto :goto_1b

    .line 482
    :cond_28
    move-object/from16 v52, v2

    .line 483
    :goto_1a
    const/4 v2, 0x0

    .line 93
    .local v2, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$1\\42\\483\\38":I
    move-object/from16 v51, v1

    .end local v1    # "it\\40":Ljava/lang/Object;
    .local v51, "it\\40":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda10;

    invoke-direct {v1, v0, v10, v13}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/HitchData;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 483
    .end local v2    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$1\\42\\483\\38":I
    nop

    .line 484
    .local v1, "value\\41":Ljava/lang/Object;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 485
    nop

    .line 482
    .end local v1    # "value\\41":Ljava/lang/Object;
    :goto_1b
    nop

    .line 481
    .end local v50    # "$i$a$-let-ComposerKt$cache$1\\41\\481\\40":I
    .end local v51    # "it\\40":Ljava/lang/Object;
    nop

    .line 93
    .end local v3    # "$this$cache\\40":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\40\\93":I
    .end local v49    # "invalid\\40":Z
    move-object v3, v1

    check-cast v3, Lkotlin/jvm/functions/Function1;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v1, v38, 0xe

    or-int/lit16 v1, v1, 0x180

    move-object/from16 v75, v12

    move-object/from16 v2, v52

    const/4 v15, 0x0

    move-object/from16 v105, v5

    move v5, v1

    move-object/from16 v1, v16

    move-object/from16 v16, v11

    move-wide/from16 v11, v29

    move-object/from16 v29, v47

    move-object/from16 v30, v105

    .end local v5    # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v47    # "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .local v11, "start":J
    .local v16, "materialized\\32":Landroidx/compose/ui/Modifier;
    .local v29, "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .local v30, "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v75, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v5}, Lorg/lighttouch/android/HitchInspectorKt;->Overview(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    .line 94
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v15, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v47

    const/4 v0, 0x4

    .local v0, "$this$dp\\43":I
    const/4 v1, 0x0

    .line 487
    .local v1, "$i$f$getDp\\43\\94":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v49

    .line 94
    .end local v0    # "$this$dp\\43":I
    .end local v1    # "$i$f$getDp\\43\\94":I
    const/16 v52, 0xd

    const/16 v53, 0x0

    const/16 v48, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    invoke-static/range {v47 .. v53}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\44":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x6

    .local v1, "$changed\\44":I
    const/4 v2, 0x0

    .line 488
    .local v2, "$i$f$Row\\44\\94":I
    const v3, 0x2952b718

    const-string v5, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 489
    sget-object v47, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual/range {v47 .. v47}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v3

    .line 490
    .local v3, "horizontalArrangement\\44":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v47, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v47 .. v47}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v15

    .line 493
    .local v15, "verticalAlignment\\44":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v47, v1, 0x3

    and-int/lit8 v47, v47, 0xe

    shr-int/lit8 v50, v1, 0x3

    and-int/lit8 v50, v50, 0x70

    move/from16 v51, v1

    .end local v1    # "$changed\\44":I
    .local v51, "$changed\\44":I
    or-int v1, v47, v50

    invoke-static {v3, v15, v4, v1}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v1

    .local v1, "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v47, v51, 0x3

    and-int/lit8 v47, v47, 0x70

    .line 494
    nop

    .local v47, "$changed\\45":I
    const/16 v50, 0x0

    .line 495
    .local v50, "$i$f$Layout\\45\\494":I
    move/from16 v52, v2

    const v2, -0x4ee9b9da

    .end local v2    # "$i$f$Row\\44\\94":I
    .local v52, "$i$f$Row\\44\\94":I
    invoke-static {v4, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 496
    const/4 v2, 0x0

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v53

    .line 497
    .local v53, "compositeKeyHash\\45":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 498
    .local v2, "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v54, v3

    .end local v3    # "horizontalArrangement\\44":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v54, "horizontalArrangement\\44":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v4, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 500
    .local v3, "materialized\\45":Landroidx/compose/ui/Modifier;
    sget-object v55, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v55 .. v55}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v55

    move-object/from16 v56, v0

    .end local v0    # "modifier\\44":Landroidx/compose/ui/Modifier;
    .local v56, "modifier\\44":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v47, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 499
    move-object/from16 v57, v55

    .local v0, "$changed\\46":I
    .local v57, "factory\\46":Lkotlin/jvm/functions/Function0;
    const/16 v55, 0x0

    .line 501
    .local v55, "$i$f$ReusableComposeNode\\46\\499":I
    move/from16 v58, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\46":I
    .local v58, "$changed\\46":I
    invoke-static {v4, v0, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 502
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_29

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 503
    :cond_29
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 504
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_2a

    .line 505
    move-object/from16 v0, v57

    .end local v57    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1c

    .line 507
    .end local v0    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .restart local v57    # "factory\\46":Lkotlin/jvm/functions/Function0;
    :cond_2a
    move-object/from16 v0, v57

    .end local v57    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 509
    :goto_1c
    move-object/from16 v57, v0

    .end local v0    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .restart local v57    # "factory\\46":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x0

    .line 510
    .local v59, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\47\\509\\45":I
    sget-object v60, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v61, v5

    invoke-virtual/range {v60 .. v60}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v0, v1, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 511
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v0, v2, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 513
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\48":Lkotlin/jvm/functions/Function2;
    const/16 v60, 0x0

    .line 514
    .local v60, "$i$f$set-impl\\48\\513":I
    move-object/from16 v62, v0

    .local v62, "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    const/16 v63, 0x0

    .line 515
    .local v63, "$i$a$-with-Updater$set$1\\49\\514\\48":I
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v64

    if-nez v64, :cond_2c

    move-object/from16 v64, v1

    .end local v1    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v64, "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v65, v2

    .end local v2    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .local v65, "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b

    goto :goto_1d

    :cond_2b
    move-object/from16 v2, v62

    goto :goto_1e

    .end local v64    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v65    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v1    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_2c
    move-object/from16 v64, v1

    move-object/from16 v65, v2

    .line 516
    .end local v1    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v2    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v64    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v65    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_1d
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v62

    .end local v62    # "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 517
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 519
    :goto_1e
    nop

    .line 514
    .end local v2    # "$this$set_impl_u24lambda_u240\\48":Landroidx/compose/runtime/Composer;
    .end local v63    # "$i$a$-with-Updater$set$1\\49\\514\\48":I
    nop

    .line 519
    nop

    .line 520
    .end local v5    # "block\\48":Lkotlin/jvm/functions/Function2;
    .end local v60    # "$i$f$set-impl\\48\\513":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 521
    nop

    .line 509
    .end local v0    # "$this$Layout_u24lambda_u240\\47":Landroidx/compose/runtime/Composer;
    .end local v59    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\47\\509\\45":I
    nop

    .line 522
    shr-int/lit8 v0, v58, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\50":I
    move-object v1, v4

    .local v1, "$composer\\50":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 523
    .local v2, "$i$a$-Layout-RowKt$Row$1\\50\\522\\44":I
    const v5, -0x184f2606

    move-object/from16 v59, v15

    .end local v15    # "verticalAlignment\\44":Landroidx/compose/ui/Alignment$Vertical;
    .local v59, "verticalAlignment\\44":Landroidx/compose/ui/Alignment$Vertical;
    const-string v15, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v5, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v60, v51, 0x6

    and-int/lit8 v60, v60, 0x70

    or-int/lit8 v60, v60, 0x6

    .local v60, "$changed\\51":I
    check-cast v5, Landroidx/compose/foundation/layout/RowScope;

    .local v5, "$this$InspectorBody_u24lambda_u2437_u24lambda_u2421\\51":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v97, v1

    .local v97, "$composer\\51":Landroidx/compose/runtime/Composer;
    move-object/from16 v66, v5

    .end local v5    # "$this$InspectorBody_u24lambda_u2437_u24lambda_u2421\\51":Landroidx/compose/foundation/layout/RowScope;
    .local v66, "$this$InspectorBody_u24lambda_u2437_u24lambda_u2421\\51":Landroidx/compose/foundation/layout/RowScope;
    const/4 v5, 0x0

    .line 95
    .local v5, "$i$a$-Row-HitchInspectorKt$InspectorBody$1$2\\51\\523\\38":I
    move/from16 v62, v0

    .end local v0    # "$changed\\50":I
    .local v62, "$changed\\50":I
    const v0, 0x5ca87c0a

    move-object/from16 v63, v1

    .end local v1    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .local v63, "$composer\\50":Landroidx/compose/runtime/Composer;
    const-string v1, "C94@5483L10,94@5528L11,94@5426L131,95@5570L27,96@5725L10,96@5610L137,97@5760L27,98@5858L10,98@5903L11,98@5800L132:HitchInspector.kt#o13vsk"

    move/from16 v101, v2

    move-object/from16 v2, v97

    .end local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\51":Landroidx/compose/runtime/Composer;
    .local v101, "$i$a$-Layout-RowKt$Row$1\\50\\522\\44":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    sub-long/2addr v0, v11

    invoke-static {v0, v1}, Lorg/lighttouch/android/HitchInspectorKt;->seconds(J)Ljava/lang/String;

    move-result-object v76

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v96

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v78

    const/16 v99, 0x0

    const v100, 0xfffa

    const/16 v77, 0x0

    const-wide/16 v80, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const-wide/16 v85, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const-wide/16 v89, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v98, 0x0

    .end local v2    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    invoke-static/range {v76 .. v100}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 96
    .end local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\51":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v67, v0

    check-cast v67, Landroidx/compose/ui/Modifier;

    const/16 v70, 0x2

    const/16 v71, 0x0

    const/high16 v68, 0x3f800000    # 1.0f

    const/16 v69, 0x0

    invoke-static/range {v66 .. v71}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 97
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v67

    invoke-static {v10}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v69

    move-object/from16 v102, v10

    move-wide/from16 v103, v11

    .end local v10    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .end local v11    # "start":J
    .local v102, "range$delegate":Landroidx/compose/runtime/MutableState;
    .local v103, "start":J
    sub-long v10, v67, v69

    long-to-double v10, v10

    const-wide v67, 0x41cdcd6500000000L    # 1.0E9

    div-double v10, v10, v67

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x1

    invoke-static {v1, v10}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v10, "%.2f"

    invoke-static {v0, v10, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u79d2\u5df2\u9009\u4e2d"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v76

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v96

    const v100, 0xfffe

    const-wide/16 v78, 0x0

    .end local v2    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    invoke-static/range {v76 .. v100}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 98
    .end local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\51":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v67, v0

    check-cast v67, Landroidx/compose/ui/Modifier;

    const/16 v70, 0x2

    const/high16 v68, 0x3f800000    # 1.0f

    const/16 v69, 0x0

    invoke-static/range {v66 .. v71}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 99
    invoke-static/range {v102 .. v102}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    sub-long v0, v0, v103

    invoke-static {v0, v1}, Lorg/lighttouch/android/HitchInspectorKt;->seconds(J)Ljava/lang/String;

    move-result-object v76

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v96

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v78

    const v100, 0xfffa

    .end local v2    # "$composer\\51":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    invoke-static/range {v76 .. v100}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 95
    invoke-static/range {v97 .. v97}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 100
    nop

    .line 523
    .end local v5    # "$i$a$-Row-HitchInspectorKt$InspectorBody$1$2\\51\\523\\38":I
    .end local v60    # "$changed\\51":I
    .end local v66    # "$this$InspectorBody_u24lambda_u2437_u24lambda_u2421\\51":Landroidx/compose/foundation/layout/RowScope;
    .end local v97    # "$composer\\51":Landroidx/compose/runtime/Composer;
    invoke-static/range {v63 .. v63}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 522
    .end local v62    # "$changed\\50":I
    .end local v63    # "$composer\\50":Landroidx/compose/runtime/Composer;
    .end local v101    # "$i$a$-Layout-RowKt$Row$1\\50\\522\\44":I
    nop

    .line 524
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 501
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 525
    nop

    .line 495
    .end local v55    # "$i$f$ReusableComposeNode\\46\\499":I
    .end local v57    # "factory\\46":Lkotlin/jvm/functions/Function0;
    .end local v58    # "$changed\\46":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 526
    nop

    .line 488
    .end local v3    # "materialized\\45":Landroidx/compose/ui/Modifier;
    .end local v47    # "$changed\\45":I
    .end local v50    # "$i$f$Layout\\45\\494":I
    .end local v53    # "compositeKeyHash\\45":I
    .end local v65    # "localMap\\45":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 527
    nop

    .line 101
    .end local v51    # "$changed\\44":I
    .end local v52    # "$i$f$Row\\44\\94":I
    .end local v54    # "horizontalArrangement\\44":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v56    # "modifier\\44":Landroidx/compose/ui/Modifier;
    .end local v59    # "verticalAlignment\\44":Landroidx/compose/ui/Alignment$Vertical;
    .end local v64    # "measurePolicy\\44":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x10

    .local v1, "$this$dp\\52":I
    const/4 v2, 0x0

    .line 528
    .local v2, "$i$f$getDp\\52\\101":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 101
    .end local v1    # "$this$dp\\52":I
    .end local v2    # "$i$f$getDp\\52\\101":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v36

    invoke-static {v0, v4, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 102
    invoke-static {v13}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$14(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/HitchFrame;

    move-result-object v2

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v10, 0x1

    invoke-static {v0, v1, v10, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0xb4

    .local v1, "$this$dp\\53":I
    const/4 v3, 0x0

    .line 529
    .local v3, "$i$f$getDp\\53\\102":I
    int-to-float v5, v1

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 102
    .end local v1    # "$this$dp\\53":I
    .end local v3    # "$i$f$getDp\\53\\102":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "hitch_detail"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const v1, 0x4c5de2

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v13}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\54":Z
    move-object v1, v4

    .local v1, "$this$cache\\54":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 530
    .local v5, "$i$f$cache\\54\\102":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\54":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 531
    .local v11, "$i$a$-let-ComposerKt$cache$1\\55\\530\\54":I
    if-nez v0, :cond_2e

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v10, v12, :cond_2d

    goto :goto_1f

    .line 535
    :cond_2d
    move/from16 v47, v0

    move-object v0, v10

    goto :goto_20

    .line 532
    :cond_2e
    :goto_1f
    const/4 v12, 0x0

    .line 102
    .local v12, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$3\\56\\532\\38":I
    move/from16 v47, v0

    .end local v0    # "invalid\\54":Z
    .local v47, "invalid\\54":Z
    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda11;

    invoke-direct {v0, v13}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 532
    .end local v12    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$3\\56\\532\\38":I
    nop

    .line 533
    .local v0, "value\\55":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 534
    nop

    .line 531
    .end local v0    # "value\\55":Ljava/lang/Object;
    :goto_20
    nop

    .line 530
    .end local v10    # "it\\54":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\55\\530\\54":I
    nop

    .line 102
    .end local v1    # "$this$cache\\54":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\54\\102":I
    .end local v47    # "invalid\\54":Z
    check-cast v0, Lkotlin/jvm/functions/Function1;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v1, v38, 0xe

    or-int/lit16 v1, v1, 0xc00

    move-object v5, v4

    move-object v12, v6

    move-object/from16 v10, v61

    const v11, 0x2952b718

    move-object v4, v0

    move v6, v1

    move-object/from16 v1, v34

    move-object/from16 v0, p0

    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .end local v34    # "selected":Ljava/util/List;
    .local v1, "selected":Ljava/util/List;
    .local v5, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Detail(Lorg/lighttouch/android/HitchData;Ljava/util/List;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    move-object v4, v5

    .end local v5    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    const v2, 0x7dbd236

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "102@6128L8"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 103
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getDetailed()Z

    move-result v2

    if-eqz v2, :cond_2f

    const/4 v2, 0x0

    invoke-static {v4, v2}, Lorg/lighttouch/android/HitchInspectorKt;->Legend(Landroidx/compose/runtime/Composer;I)V

    :cond_2f
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 104
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x10

    .local v3, "$this$dp\\57":I
    const/4 v5, 0x0

    .line 536
    .local v5, "$i$f$getDp\\57\\104":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 104
    .end local v3    # "$this$dp\\57":I
    .end local v5    # "$i$f$getDp\\57\\104":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v3, 0x6

    invoke-static {v2, v4, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 105
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v3, 0x8

    .local v3, "$this$dp\\58":I
    const/4 v5, 0x0

    .line 537
    .local v5, "$i$f$getDp\\58\\105":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 105
    .end local v3    # "$this$dp\\58":I
    .end local v5    # "$i$f$getDp\\58\\105":I
    invoke-virtual {v2, v3}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v2, "horizontalArrangement\\59":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v3, 0x30

    .local v3, "$changed\\59":I
    const/4 v5, 0x0

    .line 538
    .local v5, "$i$f$Row\\59\\105":I
    invoke-static {v4, v11, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 539
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 541
    .local v6, "modifier\\59":Landroidx/compose/ui/Modifier;
    sget-object v34, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v34 .. v34}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v11

    .line 544
    .local v11, "verticalAlignment\\59":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v34, v3, 0x3

    and-int/lit8 v34, v34, 0xe

    shr-int/lit8 v47, v3, 0x3

    and-int/lit8 v47, v47, 0x70

    move-object/from16 v77, v1

    .end local v1    # "selected":Ljava/util/List;
    .local v77, "selected":Ljava/util/List;
    or-int v1, v34, v47

    invoke-static {v2, v11, v4, v1}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v1

    .local v1, "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v34, v3, 0x3

    and-int/lit8 v34, v34, 0x70

    .line 545
    nop

    .local v34, "$changed\\60":I
    const/16 v47, 0x0

    .line 546
    .local v47, "$i$f$Layout\\60\\545":I
    move-object/from16 v48, v2

    const v2, -0x4ee9b9da

    .end local v2    # "horizontalArrangement\\59":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v48, "horizontalArrangement\\59":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v4, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 547
    const/4 v2, 0x0

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v49

    .line 548
    .local v49, "compositeKeyHash\\60":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 549
    .local v2, "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v50, v3

    .end local v3    # "$changed\\59":I
    .local v50, "$changed\\59":I
    invoke-static {v4, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 551
    .local v3, "materialized\\60":Landroidx/compose/ui/Modifier;
    sget-object v51, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v51 .. v51}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v51

    move/from16 v52, v5

    .end local v5    # "$i$f$Row\\59\\105":I
    .local v52, "$i$f$Row\\59\\105":I
    shl-int/lit8 v5, v34, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v36, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 550
    move-object/from16 v53, v51

    .local v5, "$changed\\61":I
    .local v53, "factory\\61":Lkotlin/jvm/functions/Function0;
    const/16 v51, 0x0

    .line 552
    .local v51, "$i$f$ReusableComposeNode\\61\\550":I
    move/from16 v54, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\61":I
    .local v54, "$changed\\61":I
    invoke-static {v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 553
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_30

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 554
    :cond_30
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 555
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_31

    .line 556
    move-object/from16 v5, v53

    .end local v53    # "factory\\61":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\61":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_21

    .line 558
    .end local v5    # "factory\\61":Lkotlin/jvm/functions/Function0;
    .restart local v53    # "factory\\61":Lkotlin/jvm/functions/Function0;
    :cond_31
    move-object/from16 v5, v53

    .end local v53    # "factory\\61":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\61":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 560
    :goto_21
    move-object/from16 v53, v5

    .end local v5    # "factory\\61":Lkotlin/jvm/functions/Function0;
    .restart local v53    # "factory\\61":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\62":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 561
    .local v55, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\62\\560\\60":I
    sget-object v56, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v57, v6

    .end local v6    # "modifier\\59":Landroidx/compose/ui/Modifier;
    .local v57, "modifier\\59":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v5, v1, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 562
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v5, v2, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 564
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\63":Lkotlin/jvm/functions/Function2;
    const/16 v56, 0x0

    .line 565
    .local v56, "$i$f$set-impl\\63\\564":I
    move-object/from16 v58, v5

    .local v58, "$this$set_impl_u24lambda_u240\\63":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x0

    .line 566
    .local v59, "$i$a$-with-Updater$set$1\\64\\565\\63":I
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v60

    if-nez v60, :cond_33

    move-object/from16 v60, v1

    .end local v1    # "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v60, "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v61, v2

    .end local v2    # "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    .local v61, "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v49 .. v49}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_32

    goto :goto_22

    :cond_32
    move-object/from16 v2, v58

    goto :goto_23

    .end local v60    # "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v61    # "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v1    # "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_33
    move-object/from16 v60, v1

    move-object/from16 v61, v2

    .line 567
    .end local v1    # "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v2    # "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v60    # "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v61    # "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_22
    invoke-static/range {v49 .. v49}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v58

    .end local v58    # "$this$set_impl_u24lambda_u240\\63":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\63":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 568
    invoke-static/range {v49 .. v49}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v5, v1, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 570
    :goto_23
    nop

    .line 565
    .end local v2    # "$this$set_impl_u24lambda_u240\\63":Landroidx/compose/runtime/Composer;
    .end local v59    # "$i$a$-with-Updater$set$1\\64\\565\\63":I
    nop

    .line 570
    nop

    .line 571
    .end local v6    # "block\\63":Lkotlin/jvm/functions/Function2;
    .end local v56    # "$i$f$set-impl\\63\\564":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v5, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 572
    nop

    .line 560
    .end local v5    # "$this$Layout_u24lambda_u240\\62":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\62\\560\\60":I
    nop

    .line 573
    shr-int/lit8 v1, v54, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\65":I
    move-object v2, v4

    .local v2, "$composer\\65":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 574
    .local v5, "$i$a$-Layout-RowKt$Row$1\\65\\573\\59":I
    const v6, -0x184f2606

    invoke-static {v2, v6, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v55, v50, 0x6

    and-int/lit8 v55, v55, 0x70

    const/16 v36, 0x6

    or-int/lit8 v55, v55, 0x6

    .local v55, "$changed\\66":I
    check-cast v6, Landroidx/compose/foundation/layout/RowScope;

    .local v6, "$this$InspectorBody_u24lambda_u2437_u24lambda_u2424\\66":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v66, v2

    .local v66, "$composer\\66":Landroidx/compose/runtime/Composer;
    move-object/from16 v78, v6

    .end local v6    # "$this$InspectorBody_u24lambda_u2437_u24lambda_u2424\\66":Landroidx/compose/foundation/layout/RowScope;
    .local v78, "$this$InspectorBody_u24lambda_u2437_u24lambda_u2424\\66":Landroidx/compose/foundation/layout/RowScope;
    const/4 v6, 0x0

    .line 106
    .local v6, "$i$a$-Row-HitchInspectorKt$InspectorBody$1$4\\66\\574\\38":I
    move/from16 v56, v1

    .end local v1    # "$changed\\65":I
    .local v56, "$changed\\65":I
    const v1, -0x565a8167

    move-object/from16 v58, v2

    .end local v2    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v58, "$composer\\65":Landroidx/compose/runtime/Composer;
    const-string v2, "C105@6254L86,106@6353L85,107@6451L88,108@6552L106:HitchInspector.kt#o13vsk"

    move-object/from16 v59, v3

    move-object/from16 v3, v66

    .end local v66    # "$composer\\66":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\66":Landroidx/compose/runtime/Composer;
    .local v59, "materialized\\60":Landroidx/compose/ui/Modifier;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual/range {v73 .. v73}, Lorg/lighttouch/android/RangeStats;->getAvgFps()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x1

    .end local v3    # "$composer\\66":Landroidx/compose/runtime/Composer;
    .restart local v66    # "$composer\\66":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%.1f"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v79, v2

    check-cast v79, Landroidx/compose/ui/Modifier;

    const/16 v82, 0x2

    const/16 v83, 0x0

    const/high16 v80, 0x3f800000    # 1.0f

    const/16 v81, 0x0

    invoke-static/range {v78 .. v83}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v64

    const/16 v67, 0x6

    const/16 v68, 0x8

    const-string v62, "\u5e73\u5747 FPS"

    const/16 v65, 0x0

    move-object/from16 v63, v1

    invoke-static/range {v62 .. v68}, Lorg/lighttouch/android/HitchInspectorKt;->Stat-xqIIw2o(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V

    .line 107
    sget-object v1, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual/range {v73 .. v73}, Lorg/lighttouch/android/RangeStats;->getLowFps()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v2, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%.1f"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v79, v2

    check-cast v79, Landroidx/compose/ui/Modifier;

    invoke-static/range {v78 .. v83}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v64

    const-string v62, "1% \u4f4e\u5e27"

    move-object/from16 v63, v1

    invoke-static/range {v62 .. v68}, Lorg/lighttouch/android/HitchInspectorKt;->Stat-xqIIw2o(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V

    .line 108
    sget-object v1, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual/range {v73 .. v73}, Lorg/lighttouch/android/RangeStats;->getWorstMs()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v2, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%.0f ms"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v79, v2

    check-cast v79, Landroidx/compose/ui/Modifier;

    invoke-static/range {v78 .. v83}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v64

    const-string v62, "\u6700\u5dee"

    move-object/from16 v63, v1

    invoke-static/range {v62 .. v68}, Lorg/lighttouch/android/HitchInspectorKt;->Stat-xqIIw2o(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V

    .line 109
    invoke-virtual/range {v73 .. v73}, Lorg/lighttouch/android/RangeStats;->getHitches()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v63

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v79, v1

    check-cast v79, Landroidx/compose/ui/Modifier;

    invoke-static/range {v78 .. v83}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v64

    invoke-virtual/range {v73 .. v73}, Lorg/lighttouch/android/RangeStats;->getHitches()I

    move-result v1

    if-lez v1, :cond_34

    sget-object v1, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v3

    move-object/from16 v65, v3

    goto :goto_24

    :cond_34
    const/16 v65, 0x0

    :goto_24
    const/16 v67, 0x6

    const/16 v68, 0x0

    const-string v62, "\u5361\u987f"

    invoke-static/range {v62 .. v68}, Lorg/lighttouch/android/HitchInspectorKt;->Stat-xqIIw2o(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V

    .line 106
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 110
    nop

    .line 574
    .end local v6    # "$i$a$-Row-HitchInspectorKt$InspectorBody$1$4\\66\\574\\38":I
    .end local v55    # "$changed\\66":I
    .end local v66    # "$composer\\66":Landroidx/compose/runtime/Composer;
    .end local v78    # "$this$InspectorBody_u24lambda_u2437_u24lambda_u2424\\66":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 573
    .end local v5    # "$i$a$-Layout-RowKt$Row$1\\65\\573\\59":I
    .end local v56    # "$changed\\65":I
    .end local v58    # "$composer\\65":Landroidx/compose/runtime/Composer;
    nop

    .line 575
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 552
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 576
    nop

    .line 546
    .end local v51    # "$i$f$ReusableComposeNode\\61\\550":I
    .end local v53    # "factory\\61":Lkotlin/jvm/functions/Function0;
    .end local v54    # "$changed\\61":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 577
    nop

    .line 538
    .end local v34    # "$changed\\60":I
    .end local v47    # "$i$f$Layout\\60\\545":I
    .end local v49    # "compositeKeyHash\\60":I
    .end local v59    # "materialized\\60":Landroidx/compose/ui/Modifier;
    .end local v61    # "localMap\\60":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 578
    nop

    .line 111
    .end local v11    # "verticalAlignment\\59":Landroidx/compose/ui/Alignment$Vertical;
    .end local v48    # "horizontalArrangement\\59":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v50    # "$changed\\59":I
    .end local v52    # "$i$f$Row\\59\\105":I
    .end local v57    # "modifier\\59":Landroidx/compose/ui/Modifier;
    .end local v60    # "measurePolicy\\59":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x10

    .local v2, "$this$dp\\67":I
    const/4 v3, 0x0

    .line 579
    .local v3, "$i$f$getDp\\67\\111":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 111
    .end local v2    # "$this$dp\\67":I
    .end local v3    # "$i$f$getDp\\67\\111":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v3, 0x6

    invoke-static {v1, v4, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 112
    invoke-virtual/range {v73 .. v73}, Lorg/lighttouch/android/RangeStats;->getFrames()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u5e27\u65f6\u95f4 \u00b7 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5e27"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v1, v4, v2}, Lorg/lighttouch/android/HitchInspectorKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 113
    move-object/from16 v1, v73

    .end local v73    # "stats":Lorg/lighttouch/android/RangeStats;
    .local v1, "stats":Lorg/lighttouch/android/RangeStats;
    invoke-static {v1, v4, v2}, Lorg/lighttouch/android/HitchInspectorKt;->Histogram(Lorg/lighttouch/android/RangeStats;Landroidx/compose/runtime/Composer;I)V

    .line 114
    invoke-static {v13}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$14(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/HitchFrame;

    move-result-object v2

    const v3, 0x7dc2a02

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*113@6825L30,113@6857L22"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v2, :cond_35

    goto :goto_25

    .line 387
    .local v2, "frame\\68":Lorg/lighttouch/android/HitchFrame;
    :cond_35
    const/4 v3, 0x0

    .line 114
    .local v3, "$i$a$-let-HitchInspectorKt$InspectorBody$1$5\\68\\114\\38":I
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v6, 0x10

    .local v6, "$this$dp\\69":I
    const/4 v11, 0x0

    .line 580
    .local v11, "$i$f$getDp\\69\\114":I
    int-to-float v14, v6

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 114
    .end local v6    # "$this$dp\\69":I
    .end local v11    # "$i$f$getDp\\69\\114":I
    invoke-static {v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v6, 0x6

    invoke-static {v5, v4, v6}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    and-int/lit8 v5, v38, 0xe

    invoke-static {v0, v2, v4, v5}, Lorg/lighttouch/android/HitchInspectorKt;->FrameCard(Lorg/lighttouch/android/HitchData;Lorg/lighttouch/android/HitchFrame;Landroidx/compose/runtime/Composer;I)V

    .end local v2    # "frame\\68":Lorg/lighttouch/android/HitchFrame;
    .end local v3    # "$i$a$-let-HitchInspectorKt$InspectorBody$1$5\\68\\114\\38":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_25
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 115
    invoke-static/range {v102 .. v102}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v2

    const v3, -0x615d173a

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object/from16 v3, v75

    .end local v75    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v2, v5

    .local v2, "invalid\\70":Z
    move-object v5, v4

    .local v5, "$this$cache\\70":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 581
    .local v6, "$i$f$cache\\70\\115":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\70":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 582
    .local v14, "$i$a$-let-ComposerKt$cache$1\\71\\581\\70":I
    if-nez v2, :cond_37

    sget-object v34, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v73, v1

    .end local v1    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v73    # "stats":Lorg/lighttouch/android/RangeStats;
    invoke-virtual/range {v34 .. v34}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v11, v1, :cond_36

    goto :goto_26

    .line 587
    :cond_36
    move/from16 v47, v2

    move-object v1, v11

    move-object/from16 v75, v13

    move/from16 v49, v14

    goto :goto_27

    .line 582
    .end local v73    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v1    # "stats":Lorg/lighttouch/android/RangeStats;
    :cond_37
    move-object/from16 v73, v1

    .line 583
    .end local v1    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v73    # "stats":Lorg/lighttouch/android/RangeStats;
    :goto_26
    const/4 v1, 0x0

    .line 115
    .local v1, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$slow$1\\72\\583\\38":I
    invoke-static/range {v102 .. v102}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v34

    invoke-virtual/range {v34 .. v34}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v34

    check-cast v34, Ljava/lang/Number;

    move/from16 v48, v1

    move/from16 v47, v2

    .end local v1    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$slow$1\\72\\583\\38":I
    .end local v2    # "invalid\\70":Z
    .local v47, "invalid\\70":Z
    .local v48, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$slow$1\\72\\583\\38":I
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    invoke-static/range {v102 .. v102}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v34

    invoke-virtual/range {v34 .. v34}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v34

    check-cast v34, Ljava/lang/Number;

    move-object/from16 v75, v13

    move/from16 v49, v14

    .end local v13    # "picked$delegate":Landroidx/compose/runtime/MutableState;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\71\\581\\70":I
    .local v49, "$i$a$-let-ComposerKt$cache$1\\71\\581\\70":I
    .local v75, "picked$delegate":Landroidx/compose/runtime/MutableState;
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Number;->longValue()J

    move-result-wide v13

    invoke-virtual {v0, v1, v2, v13, v14}, Lorg/lighttouch/android/HitchData;->eventsIn(JJ)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$sortedByDescending\\73":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 584
    .local v2, "$i$f$sortedByDescending\\73\\115":I
    new-instance v13, Lorg/lighttouch/android/HitchInspectorKt$InspectorBody$lambda$37$lambda$27$$inlined$sortedByDescending$1;

    invoke-direct {v13}, Lorg/lighttouch/android/HitchInspectorKt$InspectorBody$lambda$37$lambda$27$$inlined$sortedByDescending$1;-><init>()V

    check-cast v13, Ljava/util/Comparator;

    invoke-static {v1, v13}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v1

    .end local v1    # "$this$sortedByDescending\\73":Ljava/lang/Iterable;
    .end local v2    # "$i$f$sortedByDescending\\73\\115":I
    check-cast v1, Ljava/lang/Iterable;

    .line 115
    const/16 v2, 0x1e

    invoke-static {v1, v2}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v1

    .line 583
    .end local v48    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$slow$1\\72\\583\\38":I
    nop

    .line 585
    .local v1, "value\\71":Ljava/lang/Object;
    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 586
    nop

    .line 582
    .end local v1    # "value\\71":Ljava/lang/Object;
    :goto_27
    nop

    .line 581
    .end local v11    # "it\\70":Ljava/lang/Object;
    .end local v49    # "$i$a$-let-ComposerKt$cache$1\\71\\581\\70":I
    nop

    .line 115
    .end local v5    # "$this$cache\\70":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\70\\115":I
    .end local v47    # "invalid\\70":Z
    check-cast v1, Ljava/util/List;

    .local v1, "slow\\38":Ljava/util/List;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 116
    invoke-virtual {v0}, Lorg/lighttouch/android/HitchData;->getDetailed()Z

    move-result v2

    if-eqz v2, :cond_40

    const v2, -0xc5350d5

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "116@7047L30,117@7090L43,119@7311L41,121@7487L14,121@7503L60,121@7466L97"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 117
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x10

    .local v5, "$this$dp\\74":I
    const/4 v6, 0x0

    .line 588
    .local v6, "$i$f$getDp\\74\\117":I
    int-to-float v11, v5

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 117
    .end local v5    # "$this$dp\\74":I
    .end local v6    # "$i$f$getDp\\74\\117":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v6, 0x6

    invoke-static {v2, v4, v6}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 118
    const-string v2, "\u533a\u95f4\u5185\u7684\u6162\u5f15\u64ce\u4e8b\u4ef6"

    invoke-static {v2, v4, v6}, Lorg/lighttouch/android/HitchInspectorKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    const v2, 0x7dc5448

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "118@7214L10,118@7258L11,118@7166L121"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 119
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_38

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v67

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v49

    const/16 v70, 0x0

    const v71, 0xfffa

    const-string v47, "\u6ca1\u6709\u8d85\u8fc7 0.5 \u6beb\u79d2\u7684\u4e8b\u4ef6\u3002"

    const/16 v48, 0x0

    const-wide/16 v51, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v69, 0x6

    move-object/from16 v68, v4

    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v68, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v71}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v68    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    :cond_38
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 120
    invoke-static/range {v102 .. v102}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v2

    const v5, 0x4c5de2

    invoke-interface {v4, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\75":Z
    move-object v5, v4

    .local v5, "$this$cache\\75":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 589
    .local v6, "$i$f$cache\\75\\120":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\75":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 590
    .local v13, "$i$a$-let-ComposerKt$cache$1\\76\\589\\75":I
    if-nez v2, :cond_3a

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v11, v14, :cond_39

    goto :goto_28

    .line 594
    :cond_39
    move/from16 v34, v2

    move/from16 p5, v6

    move-object v0, v11

    goto :goto_29

    .line 591
    :cond_3a
    :goto_28
    const/4 v14, 0x0

    .line 120
    .local v14, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$all$2\\77\\591\\38":I
    const/16 v22, 0x0

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    move/from16 v34, v2

    move/from16 p5, v6

    const/4 v2, 0x2

    const/4 v6, 0x0

    .end local v2    # "invalid\\75":Z
    .end local v6    # "$i$f$cache\\75\\120":I
    .local v34, "invalid\\75":Z
    .local p5, "$i$f$cache\\75\\120":I
    invoke-static {v0, v6, v2, v6}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 591
    .end local v14    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$all$2\\77\\591\\38":I
    nop

    .line 592
    .local v0, "value\\76":Ljava/lang/Object;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 593
    nop

    .line 590
    .end local v0    # "value\\76":Ljava/lang/Object;
    :goto_29
    nop

    .line 589
    .end local v11    # "it\\75":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\76\\589\\75":I
    nop

    .line 120
    .end local v5    # "$this$cache\\75":Landroidx/compose/runtime/Composer;
    .end local v34    # "invalid\\75":Z
    .end local p5    # "$i$f$cache\\75\\120":I
    check-cast v0, Landroidx/compose/runtime/MutableState;

    .local v0, "all$delegate\\38":Landroidx/compose/runtime/MutableState;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x7dc6f60

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*120@7412L22"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 121
    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$29(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    if-eqz v2, :cond_3b

    move-object v2, v1

    goto :goto_2a

    :cond_3b
    move-object v2, v1

    check-cast v2, Ljava/lang/Iterable;

    const/16 v5, 0x8

    invoke-static {v2, v5}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v2

    :goto_2a
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lorg/lighttouch/android/SlowEvent;

    move-wide/from16 v13, v103

    const/4 v6, 0x0

    .end local v103    # "start":J
    .local v5, "event\\38":Lorg/lighttouch/android/SlowEvent;
    .local v13, "start":J
    invoke-static {v5, v13, v14, v4, v6}, Lorg/lighttouch/android/HitchInspectorKt;->EventRow(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V

    .end local v5    # "event\\38":Lorg/lighttouch/android/SlowEvent;
    goto :goto_2b

    .end local v13    # "start":J
    .restart local v103    # "start":J
    :cond_3c
    move-wide/from16 v13, v103

    .end local v103    # "start":J
    .restart local v13    # "start":J
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 122
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    const/16 v5, 0x8

    if-le v2, v5, :cond_3f

    const v11, 0x4c5de2

    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\78":Z
    move-object v5, v4

    .local v5, "$this$cache\\78":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 595
    .local v6, "$i$f$cache\\78\\122":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\78":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 596
    .local v17, "$i$a$-let-ComposerKt$cache$1\\79\\595\\78":I
    if-nez v2, :cond_3e

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p5, v2

    .end local v2    # "invalid\\78":Z
    .local p5, "invalid\\78":Z
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v11, v2, :cond_3d

    goto :goto_2c

    .line 600
    :cond_3d
    move-object v2, v11

    goto :goto_2d

    .line 596
    .end local p5    # "invalid\\78":Z
    .restart local v2    # "invalid\\78":Z
    :cond_3e
    move/from16 p5, v2

    .line 597
    .end local v2    # "invalid\\78":Z
    .restart local p5    # "invalid\\78":Z
    :goto_2c
    const/4 v2, 0x0

    .line 122
    .local v2, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$6\\80\\597\\38":I
    move/from16 v19, v2

    .end local v2    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$6\\80\\597\\38":I
    .local v19, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$6\\80\\597\\38":I
    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda12;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 597
    .end local v19    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$6\\80\\597\\38":I
    nop

    .line 598
    .local v2, "value\\79":Ljava/lang/Object;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 599
    nop

    .line 596
    .end local v2    # "value\\79":Ljava/lang/Object;
    :goto_2d
    nop

    .line 595
    .end local v11    # "it\\78":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\79\\595\\78":I
    nop

    .line 122
    .end local v5    # "$this$cache\\78":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\78\\122":I
    .end local p5    # "invalid\\78":Z
    move-object/from16 v47, v2

    check-cast v47, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$InspectorBody$1$7;

    invoke-direct {v2, v1, v0}, Lorg/lighttouch/android/HitchInspectorKt$InspectorBody$1$7;-><init>(Ljava/util/List;Landroidx/compose/runtime/MutableState;)V

    const/16 v5, 0x36

    const v6, 0x58ed931c

    const/4 v11, 0x1

    invoke-static {v6, v11, v2, v4, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object/from16 v56, v2

    check-cast v56, Lkotlin/jvm/functions/Function3;

    const/high16 v58, 0x30000000

    const/16 v59, 0x1fe

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    move-object/from16 v57, v4

    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v57, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v59}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 116
    .end local v0    # "all$delegate\\38":Landroidx/compose/runtime/MutableState;
    .end local v57    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    :cond_3f
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_2e

    .line 123
    .end local v13    # "start":J
    .restart local v103    # "start":J
    :cond_40
    move-wide/from16 v13, v103

    .end local v103    # "start":J
    .restart local v13    # "start":J
    const v0, -0xc4afd38

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "123@7593L30,124@7705L11,124@7663L75,124@7636L604"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 124
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x10

    .local v2, "$this$dp\\81":I
    const/4 v5, 0x0

    .line 601
    .local v5, "$i$f$getDp\\81\\124":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 124
    .end local v2    # "$this$dp\\81":I
    .end local v5    # "$i$f$getDp\\81\\124":I
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v6, 0x6

    invoke-static {v0, v4, v6}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 125
    sget-object v47, Landroidx/compose/material3/CardDefaults;->INSTANCE:Landroidx/compose/material3/CardDefaults;

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v48

    sget v0, Landroidx/compose/material3/CardDefaults;->$stable:I

    shl-int/lit8 v57, v0, 0xc

    const/16 v58, 0xe

    const-wide/16 v50, 0x0

    const-wide/16 v52, 0x0

    const-wide/16 v54, 0x0

    move-object/from16 v56, v4

    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v56, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v47 .. v58}, Landroidx/compose/material3/CardDefaults;->cardColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/CardColors;

    move-result-object v49

    .end local v56    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->getLambda$-1721490424$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v52

    const/high16 v54, 0x30000

    const/16 v55, 0x1b

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    move-object/from16 v53, v4

    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v53, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v55}, Landroidx/compose/material3/CardKt;->Card(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/CardColors;Landroidx/compose/material3/CardElevation;Landroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 123
    .end local v53    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 134
    :goto_2e
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x10

    .local v2, "$this$dp\\82":I
    const/4 v5, 0x0

    .line 602
    .local v5, "$i$f$getDp\\82\\134":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 134
    .end local v2    # "$this$dp\\82":I
    .end local v5    # "$i$f$getDp\\82\\134":I
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v6, 0x6

    invoke-static {v0, v4, v6}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 135
    sget-object v0, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v0

    .local v0, "verticalAlignment\\83":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v2, 0x180

    .local v2, "$changed\\83":I
    const/4 v5, 0x0

    .line 603
    .local v5, "$i$f$Row\\83\\135":I
    const v11, 0x2952b718

    invoke-static {v4, v11, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 604
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 605
    .local v6, "modifier\\83":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v10

    .line 609
    .local v10, "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v11, v2, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v17, v2, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v11, v11, v17

    invoke-static {v10, v0, v4, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v2, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 610
    move/from16 v34, v17

    .local v34, "$changed\\84":I
    const/16 v47, 0x0

    .line 611
    .local v47, "$i$f$Layout\\84\\610":I
    move-object/from16 p5, v0

    const v0, -0x4ee9b9da

    .end local v0    # "verticalAlignment\\83":Landroidx/compose/ui/Alignment$Vertical;
    .local p5, "verticalAlignment\\83":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v4, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 612
    const/4 v0, 0x0

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v9

    .line 613
    .local v9, "compositeKeyHash\\84":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 614
    .local v0, "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    move-wide/from16 v103, v13

    .end local v13    # "start":J
    .restart local v103    # "start":J
    invoke-static {v4, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 616
    .local v13, "materialized\\84":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v14

    move-object/from16 v76, v1

    .end local v1    # "slow\\38":Ljava/util/List;
    .local v76, "slow\\38":Ljava/util/List;
    shl-int/lit8 v1, v34, 0x6

    and-int/lit16 v1, v1, 0x380

    const/16 v36, 0x6

    or-int/lit8 v1, v1, 0x6

    .line 615
    nop

    .local v1, "$changed\\85":I
    .local v14, "factory\\85":Lkotlin/jvm/functions/Function0;
    const/16 v48, 0x0

    .line 617
    .local v48, "$i$f$ReusableComposeNode\\85\\615":I
    move/from16 v49, v1

    const v1, -0x2942ffcf

    .end local v1    # "$changed\\85":I
    .local v49, "$changed\\85":I
    invoke-static {v4, v1, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 618
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_41

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 619
    :cond_41
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 620
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_42

    .line 621
    invoke-interface {v4, v14}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_2f

    .line 623
    :cond_42
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 625
    :goto_2f
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\86":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 626
    .local v8, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\86\\625\\84":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v37, v2

    .end local v2    # "$changed\\83":I
    .local v37, "$changed\\83":I
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v11, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 627
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 629
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\87":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 630
    .local v17, "$i$f$set-impl\\87\\629":I
    move-object/from16 v19, v1

    .local v19, "$this$set_impl_u24lambda_u240\\87":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 631
    .local v21, "$i$a$-with-Updater$set$1\\88\\630\\87":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v50

    if-nez v50, :cond_44

    move-object/from16 v50, v0

    .end local v0    # "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    .local v50, "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move/from16 v51, v5

    .end local v5    # "$i$f$Row\\83\\135":I
    .local v51, "$i$f$Row\\83\\135":I
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43

    goto :goto_30

    :cond_43
    move-object/from16 v5, v19

    goto :goto_31

    .end local v50    # "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v51    # "$i$f$Row\\83\\135":I
    .restart local v0    # "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "$i$f$Row\\83\\135":I
    :cond_44
    move-object/from16 v50, v0

    move/from16 v51, v5

    .line 632
    .end local v0    # "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "$i$f$Row\\83\\135":I
    .restart local v50    # "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v51    # "$i$f$Row\\83\\135":I
    :goto_30
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v5, v19

    .end local v19    # "$this$set_impl_u24lambda_u240\\87":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\87":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 633
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v0, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 635
    :goto_31
    nop

    .line 630
    .end local v5    # "$this$set_impl_u24lambda_u240\\87":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\88\\630\\87":I
    nop

    .line 635
    nop

    .line 636
    .end local v2    # "block\\87":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\87\\629":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 637
    nop

    .line 625
    .end local v1    # "$this$Layout_u24lambda_u240\\86":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\86\\625\\84":I
    nop

    .line 638
    shr-int/lit8 v0, v49, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\89":I
    move-object v1, v4

    .local v1, "$composer\\89":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 639
    .local v2, "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    const v5, -0x184f2606

    invoke-static {v1, v5, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v8, v37, 0x6

    and-int/lit8 v8, v8, 0x70

    const/16 v36, 0x6

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\90":I
    check-cast v5, Landroidx/compose/foundation/layout/RowScope;

    .local v5, "$this$InspectorBody_u24lambda_u2437_u24lambda_u2435\\90":Landroidx/compose/foundation/layout/RowScope;
    move-object v15, v1

    .local v15, "$composer\\90":Landroidx/compose/runtime/Composer;
    const/16 v65, 0x0

    .line 136
    .local v65, "$i$a$-Row-HitchInspectorKt$InspectorBody$1$8\\90\\639\\38":I
    move/from16 v66, v0

    .end local v0    # "$changed\\89":I
    .local v66, "$changed\\89":I
    const v0, -0x6f1bd5bc    # -8.9995264E-29f

    move-object/from16 v67, v1

    .end local v1    # "$composer\\89":Landroidx/compose/runtime/Composer;
    .local v67, "$composer\\89":Landroidx/compose/runtime/Composer;
    const-string v1, "C135@8381L37,135@8482L156,135@8364L274:HitchInspector.kt#o13vsk"

    invoke-static {v15, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    xor-int/lit8 v54, p2, 0x1

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v1, "hitch_save"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v53

    const v0, -0x615d173a

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v38, 0x70

    const/16 v1, 0x20

    if-ne v0, v1, :cond_45

    const/16 v22, 0x1

    goto :goto_32

    :cond_45
    const/16 v22, 0x0

    :goto_32
    move-object/from16 v0, v102

    .end local v102    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .local v0, "range$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    or-int v1, v22, v1

    .local v1, "invalid\\91":Z
    move-object v12, v15

    .local v12, "$this$cache\\91":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 640
    .local v17, "$i$f$cache\\91\\136":I
    move/from16 v18, v1

    .end local v1    # "invalid\\91":Z
    .local v18, "invalid\\91":Z
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\91":Ljava/lang/Object;
    const/16 v19, 0x0

    .line 641
    .local v19, "$i$a$-let-ComposerKt$cache$1\\92\\640\\91":I
    if-nez v18, :cond_47

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v68, v2

    .end local v2    # "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    .local v68, "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_46

    goto :goto_33

    .line 645
    :cond_46
    move-object/from16 v21, v1

    goto :goto_34

    .line 641
    .end local v68    # "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    .restart local v2    # "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    :cond_47
    move/from16 v68, v2

    .line 642
    .end local v2    # "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    .restart local v68    # "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    :goto_33
    const/4 v2, 0x0

    .line 136
    .local v2, "$i$a$-cache-HitchInspectorKt$InspectorBody$1$8$1\\93\\642\\90":I
    move-object/from16 v21, v1

    .end local v1    # "it\\91":Ljava/lang/Object;
    .local v21, "it\\91":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda13;

    invoke-direct {v1, v7, v0}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda13;-><init>(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/MutableState;)V

    .line 642
    .end local v2    # "$i$a$-cache-HitchInspectorKt$InspectorBody$1$8$1\\93\\642\\90":I
    nop

    .line 643
    .local v1, "value\\92":Ljava/lang/Object;
    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 644
    nop

    .line 641
    .end local v1    # "value\\92":Ljava/lang/Object;
    :goto_34
    nop

    .line 640
    .end local v19    # "$i$a$-let-ComposerKt$cache$1\\92\\640\\91":I
    .end local v21    # "it\\91":Ljava/lang/Object;
    nop

    .line 136
    .end local v12    # "$this$cache\\91":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$f$cache\\91\\136":I
    .end local v18    # "invalid\\91":Z
    move-object/from16 v52, v1

    check-cast v52, Lkotlin/jvm/functions/Function0;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v1, Lorg/lighttouch/android/HitchInspectorKt$InspectorBody$1$8$2;

    move/from16 v2, p2

    invoke-direct {v1, v2}, Lorg/lighttouch/android/HitchInspectorKt$InspectorBody$1$8$2;-><init>(Z)V

    const/16 v12, 0x36

    move-object/from16 v102, v0

    .end local v0    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v102    # "range$delegate":Landroidx/compose/runtime/MutableState;
    const v0, -0x75ffe879

    const/4 v2, 0x1

    invoke-static {v0, v2, v1, v15, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v61, v0

    check-cast v61, Lkotlin/jvm/functions/Function3;

    const v63, 0x30000030

    const/16 v64, 0x1f8

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    move-object/from16 v62, v15

    .end local v15    # "$composer\\90":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\90":Landroidx/compose/runtime/Composer;
    invoke-static/range {v52 .. v64}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v1, v62

    .end local v62    # "$composer\\90":Landroidx/compose/runtime/Composer;
    .local v1, "$composer\\90":Landroidx/compose/runtime/Composer;
    const v0, 0x46bd2c60    # 24214.188f

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "139@8690L28,140@8735L135"

    invoke-static {v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 139
    if-eqz p4, :cond_48

    .line 140
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\94":I
    const/4 v12, 0x0

    .line 646
    .local v12, "$i$f$getDp\\94\\140":I
    int-to-float v15, v2

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 140
    .end local v2    # "$this$dp\\94":I
    .end local v12    # "$i$f$getDp\\94\\140":I
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v2, 0x6

    invoke-static {v0, v1, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 141
    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;->getLambda$2013288292$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v19

    shr-int/lit8 v0, v38, 0xc

    and-int/lit8 v0, v0, 0xe

    const/high16 v12, 0x30000000

    or-int v21, v0, v12

    const/16 v22, 0x1fe

    move-object v0, v11

    .end local v11    # "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v0, "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v11, 0x0

    const/4 v12, 0x0

    move-object v15, v13

    .end local v13    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .local v15, "materialized\\84":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    move-object/from16 v17, v14

    .end local v14    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .local v17, "factory\\85":Lkotlin/jvm/functions/Function0;
    const/4 v14, 0x0

    move-object/from16 v18, v15

    .end local v15    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\84":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    move-object/from16 v20, v16

    .end local v16    # "materialized\\32":Landroidx/compose/ui/Modifier;
    .local v20, "materialized\\32":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    move-object/from16 v36, v17

    .end local v17    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .local v36, "factory\\85":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    move-object/from16 v52, v18

    .end local v18    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .local v52, "materialized\\84":Landroidx/compose/ui/Modifier;
    const/16 v18, 0x0

    move-object/from16 v78, v20

    move-object/from16 v20, v1

    move-object/from16 v1, v78

    move-object/from16 v78, v75

    move-object/from16 v75, v3

    move-object v3, v0

    move v0, v2

    move-object v2, v10

    move-object/from16 v10, p4

    .end local v0    # "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v10    # "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v1, "materialized\\32":Landroidx/compose/ui/Modifier;
    .local v2, "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v3, "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v20, "$composer\\90":Landroidx/compose/runtime/Composer;
    .local v75, "$composer":Landroidx/compose/runtime/Composer;
    .local v78, "picked$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static/range {v10 .. v22}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v62, v20

    .end local v20    # "$composer\\90":Landroidx/compose/runtime/Composer;
    .restart local v62    # "$composer\\90":Landroidx/compose/runtime/Composer;
    goto :goto_35

    .line 139
    .end local v2    # "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v36    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .end local v52    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .end local v62    # "$composer\\90":Landroidx/compose/runtime/Composer;
    .end local v78    # "picked$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "$composer\\90":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v11    # "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v13    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .restart local v14    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .restart local v16    # "materialized\\32":Landroidx/compose/ui/Modifier;
    .local v75, "picked$delegate":Landroidx/compose/runtime/MutableState;
    :cond_48
    move-object/from16 v62, v1

    move-object v2, v10

    move-object/from16 v52, v13

    move-object/from16 v36, v14

    move-object/from16 v1, v16

    move-object/from16 v78, v75

    const/4 v0, 0x6

    move-object/from16 v75, v3

    move-object v3, v11

    .line 141
    .end local v10    # "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v11    # "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v13    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .end local v14    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .end local v16    # "materialized\\32":Landroidx/compose/ui/Modifier;
    .local v1, "materialized\\32":Landroidx/compose/ui/Modifier;
    .restart local v2    # "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v3, "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v36    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .restart local v52    # "materialized\\84":Landroidx/compose/ui/Modifier;
    .restart local v62    # "$composer\\90":Landroidx/compose/runtime/Composer;
    .local v75, "$composer":Landroidx/compose/runtime/Composer;
    .restart local v78    # "picked$delegate":Landroidx/compose/runtime/MutableState;
    :goto_35
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 136
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 143
    nop

    .line 639
    .end local v5    # "$this$InspectorBody_u24lambda_u2437_u24lambda_u2435\\90":Landroidx/compose/foundation/layout/RowScope;
    .end local v8    # "$changed\\90":I
    .end local v62    # "$composer\\90":Landroidx/compose/runtime/Composer;
    .end local v65    # "$i$a$-Row-HitchInspectorKt$InspectorBody$1$8\\90\\639\\38":I
    invoke-static/range {v67 .. v67}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 638
    .end local v66    # "$changed\\89":I
    .end local v67    # "$composer\\89":Landroidx/compose/runtime/Composer;
    .end local v68    # "$i$a$-Layout-RowKt$Row$1\\89\\638\\83":I
    nop

    .line 647
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 617
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 648
    nop

    .line 611
    .end local v36    # "factory\\85":Lkotlin/jvm/functions/Function0;
    .end local v48    # "$i$f$ReusableComposeNode\\85\\615":I
    .end local v49    # "$changed\\85":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 649
    nop

    .line 603
    .end local v9    # "compositeKeyHash\\84":I
    .end local v34    # "$changed\\84":I
    .end local v47    # "$i$f$Layout\\84\\610":I
    .end local v50    # "localMap\\84":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v52    # "materialized\\84":Landroidx/compose/ui/Modifier;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 650
    nop

    .end local v2    # "horizontalArrangement\\83":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v3    # "measurePolicy\\83":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v6    # "modifier\\83":Landroidx/compose/ui/Modifier;
    .end local v37    # "$changed\\83":I
    .end local v51    # "$i$f$Row\\83\\135":I
    .end local p5    # "verticalAlignment\\83":Landroidx/compose/ui/Alignment$Vertical;
    const v2, 0x7dd3189

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*143@8983L10,143@9027L11,143@8922L134"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 144
    if-nez p3, :cond_49

    goto :goto_36

    :cond_49
    move-object/from16 v47, p3

    .line 387
    .local v47, "it\\95":Ljava/lang/String;
    const/4 v2, 0x0

    .line 144
    .local v2, "$i$a$-let-HitchInspectorKt$InspectorBody$1$9\\95\\144\\38":I
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v8, v3

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x8

    .local v3, "$this$dp\\96":I
    const/4 v5, 0x0

    .line 651
    .local v5, "$i$f$getDp\\96\\144":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 144
    .end local v3    # "$this$dp\\96":I
    .end local v5    # "$i$f$getDp\\96\\144":I
    const/16 v13, 0xd

    const/4 v14, 0x0

    const/4 v9, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v48

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v67

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v49

    const/16 v70, 0x0

    const v71, 0xfff8

    const-wide/16 v51, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v69, 0x30

    move-object/from16 v68, v4

    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .local v68, "$composer\\38":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v71}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v2    # "$i$a$-let-HitchInspectorKt$InspectorBody$1$9\\95\\144\\38":I
    .end local v47    # "it\\95":Ljava/lang/String;
    .end local v68    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_36
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 145
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x20

    .local v3, "$this$dp\\97":I
    const/4 v5, 0x0

    .line 652
    .local v5, "$i$f$getDp\\97\\145":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 145
    .end local v3    # "$this$dp\\97":I
    .end local v5    # "$i$f$getDp\\97\\145":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    invoke-static {v2, v4, v0}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 92
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 146
    .end local v76    # "slow\\38":Ljava/util/List;
    nop

    .line 479
    .end local v4    # "$composer\\38":Landroidx/compose/runtime/Composer;
    .end local v43    # "$changed\\38":I
    .end local v44    # "$this$InspectorBody_u24lambda_u2437\\38":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v72    # "$i$a$-Column-HitchInspectorKt$InspectorBody$1\\38\\479\\0":I
    invoke-static/range {v74 .. v74}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 478
    .end local v40    # "$changed\\37":I
    .end local v41    # "$i$a$-Layout-ColumnKt$Column$1\\37\\478\\31":I
    .end local v74    # "$composer\\37":Landroidx/compose/runtime/Composer;
    nop

    .line 653
    invoke-interface/range {v75 .. v75}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 457
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 654
    nop

    .line 451
    .end local v28    # "$i$f$ReusableComposeNode\\33\\455":I
    .end local v35    # "$changed\\33":I
    .end local v42    # "factory\\33":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 655
    nop

    .line 444
    .end local v1    # "materialized\\32":Landroidx/compose/ui/Modifier;
    .end local v25    # "$changed\\32":I
    .end local v26    # "$i$f$Layout\\32\\450":I
    .end local v27    # "compositeKeyHash\\32":I
    .end local v45    # "localMap\\32":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 656
    nop

    .end local v23    # "$changed\\31":I
    .end local v24    # "$i$f$Column\\31\\91":I
    .end local v29    # "horizontalAlignment\\31":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v30    # "measurePolicy\\31":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v33    # "modifier\\31":Landroidx/compose/ui/Modifier;
    .end local v46    # "verticalArrangement\\31":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_4a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v31    # "end":J
    .end local v39    # "initial":Lkotlin/Pair;
    .end local v73    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v77    # "selected":Ljava/util/List;
    .end local v78    # "picked$delegate":Landroidx/compose/runtime/MutableState;
    .end local v102    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .end local v103    # "start":J
    :cond_4a
    :goto_37
    invoke-interface/range {v75 .. v75}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_4b

    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda14;

    move-object/from16 v1, p0

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    move-object v2, v7

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda14;-><init>(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 147
    :cond_4b
    return-void

    .line 426
    .end local v38    # "$dirty":I
    .end local v75    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "maxElem\\21":Ljava/lang/Object;
    .local v3, "$this$cache\\18":Landroidx/compose/runtime/Composer;
    .local v4, "$i$f$maxByOrNull\\21\\87":I
    .local v5, "maxValue\\21":F
    .local v9, "initial":Lkotlin/Pair;
    .local v10, "range$delegate":Landroidx/compose/runtime/MutableState;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "it\\18":Ljava/lang/Object;
    .local v14, "$dirty":I
    .local v27, "$i$a$-let-ComposerKt$cache$1\\19\\411\\18":I
    .local v29, "start":J
    .restart local v31    # "end":J
    .local v33, "$i$a$-cache-HitchInspectorKt$InspectorBody$picked$2\\20\\413\\0":I
    .local v34, "invalid\\18":Z
    .local v35, "$i$f$cache\\18\\87":I
    .local v36, "iterator\\21":Ljava/util/Iterator;
    .local v37, "$this$maxByOrNull\\21":Ljava/lang/Iterable;
    :cond_4c
    move-object v0, v2

    move-object/from16 v39, v9

    move-object/from16 v102, v10

    move-object/from16 v75, v12

    move/from16 v38, v14

    move-wide/from16 v103, v29

    const/4 v2, 0x1

    const v11, 0x4c5de2

    const/16 v17, 0x2

    move-object v12, v6

    const/4 v6, 0x0

    .end local v2    # "maxElem\\21":Ljava/lang/Object;
    .end local v9    # "initial":Lkotlin/Pair;
    .end local v10    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v14    # "$dirty":I
    .end local v29    # "start":J
    .local v0, "maxElem\\21":Ljava/lang/Object;
    .restart local v38    # "$dirty":I
    .restart local v39    # "initial":Lkotlin/Pair;
    .restart local v75    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v102    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v103    # "start":J
    move-object/from16 v7, p1

    move/from16 v8, p2

    move/from16 v11, p6

    move-object v2, v0

    move-object v6, v12

    move-object/from16 v1, v37

    move-object/from16 v12, v75

    move-object/from16 v0, p0

    goto/16 :goto_10

    .line 400
    .end local v0    # "maxElem\\21":Ljava/lang/Object;
    .end local v4    # "$i$f$maxByOrNull\\21\\87":I
    .end local v27    # "$i$a$-let-ComposerKt$cache$1\\19\\411\\18":I
    .end local v31    # "end":J
    .end local v33    # "$i$a$-cache-HitchInspectorKt$InspectorBody$picked$2\\20\\413\\0":I
    .end local v34    # "invalid\\18":Z
    .end local v35    # "$i$f$cache\\18\\87":I
    .end local v36    # "iterator\\21":Ljava/util/Iterator;
    .end local v37    # "$this$maxByOrNull\\21":Ljava/lang/Iterable;
    .end local v38    # "$dirty":I
    .end local v39    # "initial":Lkotlin/Pair;
    .end local v75    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v102    # "range$delegate":Landroidx/compose/runtime/MutableState;
    .end local v103    # "start":J
    .local v1, "start":J
    .local v3, "end":J
    .local v5, "maxValue\\12":F
    .restart local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "it\\1":Ljava/lang/Object;
    .restart local v14    # "$dirty":I
    .local v15, "$i$a$-cache-HitchInspectorKt$InspectorBody$initial$1\\3\\383\\0":I
    .local v16, "$i$f$cache\\1\\81":I
    .local v18, "$i$a$-let-ComposerKt$cache$1\\2\\381\\1":I
    .local v21, "$i$f$maxByOrThrow\\12\\83":I
    .local v23, "iterator\\12":Ljava/util/Iterator;
    .local v24, "maxElem\\12":Ljava/lang/Object;
    .local v25, "invalid\\1":Z
    .local v26, "recent\\3":Ljava/util/List;
    .local v28, "$this$maxBy\\12":Ljava/lang/Iterable;
    .local p5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    :cond_4d
    move-object/from16 v0, p5

    move-wide/from16 v103, v1

    move-wide/from16 v31, v3

    move-object/from16 v75, v12

    move/from16 v38, v14

    const/4 v2, 0x1

    const v11, 0x4c5de2

    const/16 v17, 0x2

    move-object v12, v6

    .end local v1    # "start":J
    .end local v3    # "end":J
    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v14    # "$dirty":I
    .end local p5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .local v0, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .restart local v31    # "end":J
    .restart local v38    # "$dirty":I
    .restart local v75    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v103    # "start":J
    move-object/from16 v7, p1

    move/from16 v8, p2

    move-object/from16 v10, p4

    move/from16 v11, p6

    move-object/from16 v9, v28

    move-object/from16 v12, v75

    move-wide/from16 v1, v103

    move-object/from16 v0, p0

    goto/16 :goto_a

    .line 389
    .end local v0    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v24    # "maxElem\\12":Ljava/lang/Object;
    .end local v26    # "recent\\3":Ljava/util/List;
    .end local v28    # "$this$maxBy\\12":Ljava/lang/Iterable;
    .end local v31    # "end":J
    .end local v38    # "$dirty":I
    .end local v75    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v103    # "start":J
    .restart local v1    # "start":J
    .restart local v3    # "end":J
    .local v5, "recent\\3":Ljava/util/List;
    .local v9, "$this$maxBy\\12":Ljava/lang/Iterable;
    .restart local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v14    # "$dirty":I
    .restart local p5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    :cond_4e
    move-wide/from16 v103, v1

    .end local v1    # "start":J
    .restart local v103    # "start":J
    new-instance v1, Ljava/util/NoSuchElementException;

    invoke-direct {v1}, Ljava/util/NoSuchElementException;-><init>()V

    throw v1
.end method

.method private static final InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;
    .locals 4
    .param p0, "$range$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;>;)",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .line 86
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 1032
    .local v3, "$i$f$getValue\\1\\86":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\86":I
    check-cast v0, Lkotlin/Pair;

    .line 86
    return-object v0
.end method

.method private static final InspectorBody$lambda$11(Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)V
    .locals 4
    .param p0, "$range$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;>;",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .line 86
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 1033
    .local v3, "$i$f$setValue\\1\\86":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1034
    nop

    .line 86
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\86":I
    return-void
.end method

.method private static final InspectorBody$lambda$14(Landroidx/compose/runtime/MutableState;)Lorg/lighttouch/android/HitchFrame;
    .locals 4
    .param p0, "$picked$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/HitchFrame;",
            ">;)",
            "Lorg/lighttouch/android/HitchFrame;"
        }
    .end annotation

    .line 87
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 1035
    .local v3, "$i$f$getValue\\1\\87":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\87":I
    check-cast v0, Lorg/lighttouch/android/HitchFrame;

    .line 87
    return-object v0
.end method

.method private static final InspectorBody$lambda$15(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/HitchFrame;)V
    .locals 4
    .param p0, "$picked$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/HitchFrame;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Lorg/lighttouch/android/HitchFrame;",
            ">;",
            "Lorg/lighttouch/android/HitchFrame;",
            ")V"
        }
    .end annotation

    .line 87
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    .line 1036
    .local v3, "$i$f$setValue\\1\\87":I
    invoke-interface {v2, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1037
    nop

    .line 87
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v3    # "$i$f$setValue\\1\\87":I
    return-void
.end method

.method private static final InspectorBody$lambda$37$lambda$20$lambda$19(Lorg/lighttouch/android/HitchData;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)Lkotlin/Unit;
    .locals 8
    .param p0, "$data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "$range$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$picked$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "it"    # Lkotlin/Pair;

    const-string v0, "it"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    invoke-static {p1, p3}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$11(Landroidx/compose/runtime/MutableState;Lkotlin/Pair;)V

    invoke-virtual {p3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    invoke-virtual {p3}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    invoke-virtual {p0, v0, v1, v2, v3}, Lorg/lighttouch/android/HitchData;->framesIn(JJ)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$maxByOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1038
    .local v1, "$i$f$maxByOrNull\\1\\93":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    .line 1039
    .local v2, "iterator\\1":Ljava/util/Iterator;
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_0

    const/4 v3, 0x0

    goto :goto_0

    .line 1040
    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .line 1041
    .local v3, "maxElem\\1":Ljava/lang/Object;
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_1

    goto :goto_0

    .line 1042
    :cond_1
    move-object v4, v3

    check-cast v4, Lorg/lighttouch/android/HitchFrame;

    .local v4, "f\\2":Lorg/lighttouch/android/HitchFrame;
    const/4 v5, 0x0

    .line 93
    .local v5, "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$1$1$1$1\\2\\1042\\0":I
    invoke-virtual {v4}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v4

    .line 1042
    .end local v4    # "f\\2":Lorg/lighttouch/android/HitchFrame;
    .end local v5    # "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$1$1$1$1\\2\\1042\\0":I
    nop

    .line 1044
    .local v4, "maxValue\\1":F
    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .line 1045
    .local v5, "e\\1":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lorg/lighttouch/android/HitchFrame;

    .local v6, "f\\3":Lorg/lighttouch/android/HitchFrame;
    const/4 v7, 0x0

    .line 93
    .local v7, "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$1$1$1$1\\3\\1045\\0":I
    invoke-virtual {v6}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v6

    .line 1045
    .end local v6    # "f\\3":Lorg/lighttouch/android/HitchFrame;
    .end local v7    # "$i$a$-maxByOrNull-HitchInspectorKt$InspectorBody$1$1$1$1\\3\\1045\\0":I
    nop

    .line 1046
    .local v6, "v\\1":F
    invoke-static {v4, v6}, Ljava/lang/Float;->compare(FF)I

    move-result v7

    if-gez v7, :cond_3

    .line 1047
    move-object v3, v5

    .line 1048
    move v4, v6

    .line 1050
    .end local v5    # "e\\1":Ljava/lang/Object;
    .end local v6    # "v\\1":F
    :cond_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-nez v5, :cond_2

    .line 1051
    nop

    .end local v0    # "$this$maxByOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$maxByOrNull\\1\\93":I
    .end local v2    # "iterator\\1":Ljava/util/Iterator;
    .end local v3    # "maxElem\\1":Ljava/lang/Object;
    .end local v4    # "maxValue\\1":F
    :goto_0
    check-cast v3, Lorg/lighttouch/android/HitchFrame;

    .line 93
    invoke-static {p2, v3}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$15(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/HitchFrame;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InspectorBody$lambda$37$lambda$23$lambda$22(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/HitchFrame;)Lkotlin/Unit;
    .locals 1
    .param p0, "$picked$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "it"    # Lorg/lighttouch/android/HitchFrame;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    invoke-static {p0, p1}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$15(Landroidx/compose/runtime/MutableState;Lorg/lighttouch/android/HitchFrame;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InspectorBody$lambda$37$lambda$29(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$all$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 120
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 1052
    .local v3, "$i$f$getValue\\1\\120":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\120":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 120
    return v0
.end method

.method private static final InspectorBody$lambda$37$lambda$30(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$all$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 120
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 1053
    .local v4, "$i$f$setValue\\1\\120":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1054
    nop

    .line 120
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\120":I
    return-void
.end method

.method private static final InspectorBody$lambda$37$lambda$32$lambda$31(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$all$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 122
    invoke-static {p0}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$29(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$30(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InspectorBody$lambda$37$lambda$35$lambda$34$lambda$33(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 2
    .param p0, "$onSave"    # Lkotlin/jvm/functions/Function2;
    .param p1, "$range$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 136
    invoke-static {p1}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v0

    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    invoke-static {p1}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$10(Landroidx/compose/runtime/MutableState;)Lkotlin/Pair;

    move-result-object v1

    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {p0, v0, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InspectorBody$lambda$38(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final Legend(Landroidx/compose/runtime/Composer;I)V
    .locals 81
    .param p0, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p1, "$changed"    # I

    .line 252
    move/from16 v0, p1

    const v1, 0x52763c32

    move-object/from16 v2, p0

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p0    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(Legend)252@15097L606:HitchInspector.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v0, :cond_1

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 821
    :cond_0
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v24, v2

    goto/16 :goto_8

    .line 252
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v4, "org.lighttouch.android.Legend (HitchInspector.kt:251)"

    invoke-static {v1, v0, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 253
    :cond_2
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v3, v1

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x6

    .local v1, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 739
    .local v4, "$i$f$getDp\\1\\253":I
    int-to-float v5, v1

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 253
    .end local v1    # "$this$dp\\1":I
    .end local v4    # "$i$f$getDp\\1\\253":I
    const/16 v8, 0xd

    const/4 v9, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v3 .. v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v4, 0xc

    .local v4, "$this$dp\\2":I
    const/4 v5, 0x0

    .line 739
    .local v5, "$i$f$getDp\\2\\253":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 253
    .end local v4    # "$this$dp\\2":I
    .end local v5    # "$i$f$getDp\\2\\253":I
    invoke-virtual {v3, v4}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v3, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v4, 0x36

    .local v1, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v4, "$changed\\3":I
    const/4 v5, 0x0

    .line 740
    .local v5, "$i$f$Row\\3\\253":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v2, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 741
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v8

    .line 744
    .local v8, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v9, v4, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v3, v8, v2, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 745
    nop

    .local v10, "$changed\\4":I
    const/4 v11, 0x0

    .line 746
    .local v11, "$i$f$Layout\\4\\745":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v2, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 747
    const/4 v14, 0x0

    invoke-static {v2, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v15

    .line 748
    .local v15, "compositeKeyHash\\4":I
    move/from16 p0, v14

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 749
    .local v14, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 751
    .local v12, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v6, v10, 0x6

    and-int/lit16 v6, v6, 0x380

    move-object/from16 v18, v1

    .end local v1    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x6

    or-int/2addr v6, v1

    .line 750
    nop

    .local v6, "$changed\\5":I
    move-object/from16 v19, v16

    .local v19, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 752
    .local v16, "$i$f$ReusableComposeNode\\5\\750":I
    move/from16 v20, v1

    const v1, -0x2942ffcf

    move-object/from16 v21, v3

    .end local v3    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v21, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v2, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 753
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 754
    :cond_3
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 755
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_4

    .line 756
    move-object/from16 v1, v19

    .end local v19    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 758
    .end local v1    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v1, v19

    .end local v19    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 760
    :goto_1
    move-object/from16 v19, v1

    .end local v1    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 761
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\760\\4":I
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v24, v2

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v24, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v9, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 762
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v14, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 764
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v23, 0x0

    .line 765
    .local v23, "$i$f$set-impl\\7\\764":I
    move-object/from16 v25, v1

    .local v25, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 766
    .local v26, "$i$a$-with-Updater$set$1\\8\\765\\7":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_6

    move/from16 v27, v4

    .end local v4    # "$changed\\3":I
    .local v27, "$changed\\3":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v28, v5

    .end local v5    # "$i$f$Row\\3\\253":I
    .local v28, "$i$f$Row\\3\\253":I
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v5, v25

    goto :goto_3

    .end local v27    # "$changed\\3":I
    .end local v28    # "$i$f$Row\\3\\253":I
    .restart local v4    # "$changed\\3":I
    .restart local v5    # "$i$f$Row\\3\\253":I
    :cond_6
    move/from16 v27, v4

    move/from16 v28, v5

    .line 767
    .end local v4    # "$changed\\3":I
    .end local v5    # "$i$f$Row\\3\\253":I
    .restart local v27    # "$changed\\3":I
    .restart local v28    # "$i$f$Row\\3\\253":I
    :goto_2
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v25

    .end local v25    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 768
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 770
    :goto_3
    nop

    .line 765
    .end local v5    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\8\\765\\7":I
    nop

    .line 770
    nop

    .line 771
    .end local v2    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v23    # "$i$f$set-impl\\7\\764":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v12, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 772
    nop

    .line 760
    .end local v1    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\760\\4":I
    nop

    .line 773
    shr-int/lit8 v1, v6, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\9":I
    move-object/from16 v2, v24

    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 774
    .local v4, "$i$a$-Layout-RowKt$Row$1\\9\\773\\3":I
    const v5, -0x184f2606

    move/from16 v22, v1

    .end local v1    # "$changed\\9":I
    .local v22, "$changed\\9":I
    const-string v1, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v23, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v25, v27, 0x6

    and-int/lit8 v25, v25, 0x70

    or-int/lit8 v25, v25, 0x6

    .local v25, "$changed\\10":I
    check-cast v23, Landroidx/compose/foundation/layout/RowScope;

    .local v23, "$this$Legend_u24lambda_u2458\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v26, v2

    .local v26, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 254
    .local v29, "$i$a$-Row-HitchInspectorKt$Legend$1\\10\\774\\0":I
    const v5, -0x5a597b62

    move-object/from16 v31, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v31, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v2, "C:HitchInspector.kt#o13vsk"

    move/from16 v32, v4

    move-object/from16 v4, v26

    .end local v26    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v32, "$i$a$-Layout-RowKt$Row$1\\9\\773\\3":I
    invoke-static {v4, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, -0x768703fb

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*254@15366L321"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x4

    new-array v2, v2, [Lkotlin/Pair;

    sget-object v5, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v5}, Lorg/lighttouch/android/LtColors;->getOverlayGpu-0d7_KjU()J

    move-result-wide v33

    invoke-static/range {v33 .. v34}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v5

    move-object/from16 v26, v2

    const-string v2, "GL"

    invoke-static {v5, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    aput-object v2, v26, p0

    sget-object v2, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v33

    invoke-static/range {v33 .. v34}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v2

    const-string v5, "\u9501\u7b49\u5f85"

    invoke-static {v2, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v5, 0x1

    aput-object v2, v26, v5

    sget-object v2, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtColors;->getOverlayCpu-0d7_KjU()J

    move-result-wide v33

    invoke-static/range {v33 .. v34}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v2

    const-string v5, "\u5ba2\u6237\u673a CPU"

    invoke-static {v2, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v5, 0x2

    aput-object v2, v26, v5

    const-wide v33, 0xff5a6366L

    invoke-static/range {v33 .. v34}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    move-result-wide v33

    invoke-static/range {v33 .. v34}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v2

    const-string v5, "\u5176\u4ed6"

    invoke-static {v2, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v5, 0x3

    aput-object v2, v26, v5

    invoke-static/range {v26 .. v26}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lkotlin/Pair;

    invoke-virtual {v5}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v26

    check-cast v26, Landroidx/compose/ui/graphics/Color;

    move-object/from16 v34, v5

    move/from16 v33, v6

    .end local v6    # "$changed\\5":I
    .local v33, "$changed\\5":I
    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/graphics/Color;->unbox-impl()J

    move-result-wide v5

    .local v5, "color\\10":J
    invoke-virtual/range {v34 .. v34}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v26

    move-object/from16 v34, v26

    check-cast v34, Ljava/lang/String;

    .line 255
    .local v34, "name\\10":Ljava/lang/String;
    sget-object v26, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move-object/from16 v59, v2

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v2

    .local v2, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v26, 0x180

    .local v26, "$changed\\11":I
    const/16 v60, 0x0

    .line 775
    .local v60, "$i$f$Row\\11\\255":I
    move-object/from16 v61, v8

    const v8, 0x2952b718

    .end local v8    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v61, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v4, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 776
    sget-object v17, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v8, v17

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 777
    .local v8, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move-object/from16 v62, v7

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    .line 781
    .local v7, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v17, v26, 0x3

    and-int/lit8 v17, v17, 0xe

    shr-int/lit8 v35, v26, 0x3

    and-int/lit8 v35, v35, 0x70

    move-object/from16 v63, v9

    .end local v9    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v63, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    or-int v9, v17, v35

    invoke-static {v7, v2, v4, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v26, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 782
    nop

    .local v17, "$changed\\12":I
    const/16 v64, 0x0

    .line 783
    .local v64, "$i$f$Layout\\12\\782":I
    move-object/from16 v65, v2

    const v2, -0x4ee9b9da

    .end local v2    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v65, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v4, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 784
    move/from16 v2, p0

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v66

    .line 785
    .local v66, "compositeKeyHash\\12":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 786
    .local v2, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v67, v7

    .end local v7    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v67, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v4, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 788
    .local v7, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v35

    move-object/from16 v68, v8

    .end local v8    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v68, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v8, v17, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 787
    nop

    .local v8, "$changed\\13":I
    move-object/from16 v69, v35

    .local v69, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v70, 0x0

    .line 789
    .local v70, "$i$f$ReusableComposeNode\\13\\787":I
    move/from16 v71, v8

    const v8, -0x2942ffcf

    .end local v8    # "$changed\\13":I
    .local v71, "$changed\\13":I
    invoke-static {v4, v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 790
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 791
    :cond_7
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 792
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_8

    .line 793
    move-object/from16 v8, v69

    .end local v69    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v8, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v8}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_5

    .line 795
    .end local v8    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v69    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v8, v69

    .end local v69    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v8    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 797
    :goto_5
    move-object/from16 v69, v3

    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 798
    .local v35, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\797\\12":I
    sget-object v36, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v72, v4

    .end local v4    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v72, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v9, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 799
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v2, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 801
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v36, 0x0

    .line 802
    .local v36, "$i$f$set-impl\\15\\801":I
    move-object/from16 v37, v3

    .local v37, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 803
    .local v38, "$i$a$-with-Updater$set$1\\16\\802\\15":I
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v39

    if-nez v39, :cond_a

    move-object/from16 v73, v2

    .end local v2    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v73, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v74, v8

    .end local v8    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v74, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v66 .. v66}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v2, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_9

    goto :goto_6

    :cond_9
    move-object/from16 v8, v37

    goto :goto_7

    .end local v73    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v74    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_a
    move-object/from16 v73, v2

    move-object/from16 v74, v8

    .line 804
    .end local v2    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v73    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v74    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :goto_6
    invoke-static/range {v66 .. v66}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v8, v37

    .end local v37    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 805
    invoke-static/range {v66 .. v66}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v3, v2, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 807
    :goto_7
    nop

    .line 802
    .end local v8    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v38    # "$i$a$-with-Updater$set$1\\16\\802\\15":I
    nop

    .line 807
    nop

    .line 808
    .end local v4    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v36    # "$i$f$set-impl\\15\\801":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v7, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 809
    nop

    .line 797
    .end local v3    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v35    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\797\\12":I
    nop

    .line 810
    shr-int/lit8 v2, v71, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\17":I
    move-object/from16 v3, v72

    .local v3, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 811
    .local v4, "$i$a$-Layout-RowKt$Row$1\\17\\810\\11":I
    const v8, -0x184f2606

    invoke-static {v3, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v30, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v35, v26, 0x6

    and-int/lit8 v35, v35, 0x70

    or-int/lit8 v75, v35, 0x6

    .local v75, "$changed\\18":I
    check-cast v30, Landroidx/compose/foundation/layout/RowScope;

    .local v30, "$this$Legend_u24lambda_u2458_u24lambda_u2457\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v55, v3

    .local v55, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v76, 0x0

    .line 256
    .local v76, "$i$a$-Row-HitchInspectorKt$Legend$1$1\\18\\811\\10":I
    const v8, 0x59086d6f    # 2.4000575E15f

    move-object/from16 v77, v1

    const-string v1, "C255@15436L68,256@15521L28,257@15599L10,257@15644L11,257@15566L107:HitchInspector.kt#o13vsk"

    move/from16 v78, v2

    move-object/from16 v2, v55

    .end local v55    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v78, "$changed\\17":I
    invoke-static {v2, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v8, 0x8

    .local v8, "$this$dp\\19":I
    const/16 v35, 0x0

    .line 812
    .local v35, "$i$f$getDp\\19\\256":I
    move-object/from16 v79, v3

    .end local v3    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v79, "$composer\\17":Landroidx/compose/runtime/Composer;
    int-to-float v3, v8

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 256
    .end local v8    # "$this$dp\\19":I
    .end local v35    # "$i$f$getDp\\19\\256":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v3, 0x2

    .local v3, "$this$dp\\20":I
    const/4 v8, 0x0

    .line 812
    .local v8, "$i$f$getDp\\20\\256":I
    move/from16 v80, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\17\\810\\11":I
    .local v80, "$i$a$-Layout-RowKt$Row$1\\17\\810\\11":I
    int-to-float v4, v3

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 256
    .end local v3    # "$this$dp\\20":I
    .end local v8    # "$i$f$getDp\\20\\256":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v5, v6, v3}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 257
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x4

    .local v4, "$this$dp\\21":I
    const/4 v8, 0x0

    .line 813
    .local v8, "$i$f$getDp\\21\\257":I
    int-to-float v3, v4

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 257
    .end local v4    # "$this$dp\\21":I
    .end local v8    # "$i$f$getDp\\21\\257":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    move/from16 v3, v20

    invoke-static {v1, v2, v3}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 258
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v54

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v36

    const/16 v57, 0x0

    const v58, 0xfffa

    const/16 v35, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const-wide/16 v47, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v56, 0x0

    .end local v2    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v55    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v58}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 256
    .end local v55    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 259
    nop

    .line 811
    .end local v2    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v30    # "$this$Legend_u24lambda_u2458_u24lambda_u2457\\18":Landroidx/compose/foundation/layout/RowScope;
    .end local v75    # "$changed\\18":I
    .end local v76    # "$i$a$-Row-HitchInspectorKt$Legend$1$1\\18\\811\\10":I
    invoke-static/range {v79 .. v79}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 810
    .end local v78    # "$changed\\17":I
    .end local v79    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v80    # "$i$a$-Layout-RowKt$Row$1\\17\\810\\11":I
    nop

    .line 814
    invoke-interface/range {v72 .. v72}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 789
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 815
    nop

    .line 783
    .end local v70    # "$i$f$ReusableComposeNode\\13\\787":I
    .end local v71    # "$changed\\13":I
    .end local v74    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 816
    nop

    .line 775
    .end local v7    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v17    # "$changed\\12":I
    .end local v64    # "$i$f$Layout\\12\\782":I
    .end local v66    # "compositeKeyHash\\12":I
    .end local v73    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 817
    move/from16 v6, v33

    move-object/from16 v2, v59

    move-object/from16 v8, v61

    move-object/from16 v7, v62

    move-object/from16 v9, v63

    move-object/from16 v3, v69

    move-object/from16 v4, v72

    move-object/from16 v1, v77

    const/16 p0, 0x0

    .end local v5    # "color\\10":J
    .end local v9    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v26    # "$changed\\11":I
    .end local v34    # "name\\10":Ljava/lang/String;
    .end local v60    # "$i$f$Row\\11\\255":I
    .end local v65    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v67    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v68    # "modifier\\11":Landroidx/compose/ui/Modifier;
    goto/16 :goto_4

    .end local v33    # "$changed\\5":I
    .end local v61    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v63    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v72    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$changed\\5":I
    .local v8, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v9, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_b
    move-object/from16 v72, v4

    move/from16 v33, v6

    move-object/from16 v61, v8

    move-object/from16 v63, v9

    .end local v4    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v6    # "$changed\\5":I
    .end local v8    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v9    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v33    # "$changed\\5":I
    .restart local v61    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v63    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v72    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v72 .. v72}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 254
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 261
    nop

    .line 774
    .end local v23    # "$this$Legend_u24lambda_u2458\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v25    # "$changed\\10":I
    .end local v29    # "$i$a$-Row-HitchInspectorKt$Legend$1\\10\\774\\0":I
    .end local v72    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 773
    .end local v22    # "$changed\\9":I
    .end local v31    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-Layout-RowKt$Row$1\\9\\773\\3":I
    nop

    .line 818
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 752
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 819
    nop

    .line 746
    .end local v16    # "$i$f$ReusableComposeNode\\5\\750":I
    .end local v19    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v33    # "$changed\\5":I
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 820
    nop

    .line 740
    .end local v10    # "$changed\\4":I
    .end local v11    # "$i$f$Layout\\4\\745":I
    .end local v12    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v14    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "compositeKeyHash\\4":I
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 821
    nop

    .end local v18    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v21    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v27    # "$changed\\3":I
    .end local v28    # "$i$f$Row\\3\\253":I
    .end local v61    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v63    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_c
    :goto_8
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_d

    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda5;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda5;-><init>(I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 262
    :cond_d
    return-void
.end method

.method private static final Legend$lambda$59(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p1, v0}, Lorg/lighttouch/android/HitchInspectorKt;->Legend(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Message(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 47
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "body"    # Ljava/lang/String;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 68
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v2, -0x4619ab3e

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Message)P(1)68@3524L367:HitchInspector.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, p3, 0x6

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_3

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_2

    .line 380
    :cond_4
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v0, v1

    move-object/from16 v38, v3

    move/from16 v40, v4

    goto/16 :goto_6

    .line 68
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.Message (HitchInspector.kt:67)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 69
    :cond_6
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v2, v7, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v5, 0x20

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 343
    .local v6, "$i$f$getDp\\1\\69":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 69
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\69":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getCenter()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v5

    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v5, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .local v6, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v7, 0x1b6

    .local v7, "$changed\\2":I
    move/from16 v25, v7

    .end local v7    # "$changed\\2":I
    .local v25, "$changed\\2":I
    const/16 v26, 0x0

    .line 344
    .local v26, "$i$f$Column\\2\\69":I
    const v7, -0x1cd0f17e

    const-string v8, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v3, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 345
    shr-int/lit8 v7, v25, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v8, v25, 0x3

    and-int/lit8 v8, v8, 0x70

    or-int/2addr v7, v8

    invoke-static {v5, v6, v3, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v25, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 346
    move/from16 v27, v8

    .local v27, "$changed\\3":I
    const/16 v28, 0x0

    .line 347
    .local v28, "$i$f$Layout\\3\\346":I
    const v8, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 348
    const/4 v8, 0x0

    invoke-static {v3, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 349
    .local v29, "compositeKeyHash\\3":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 350
    .local v8, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 352
    .local v9, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v10

    shl-int/lit8 v11, v27, 0x6

    and-int/lit16 v11, v11, 0x380

    const/4 v12, 0x6

    or-int/2addr v11, v12

    .line 351
    nop

    .local v10, "factory\\4":Lkotlin/jvm/functions/Function0;
    move/from16 v30, v11

    .local v30, "$changed\\4":I
    const/16 v31, 0x0

    .line 353
    .local v31, "$i$f$ReusableComposeNode\\4\\351":I
    const v11, -0x2942ffcf

    const-string v13, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 354
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v11

    instance-of v11, v11, Landroidx/compose/runtime/Applier;

    if-nez v11, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 355
    :cond_7
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 356
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-eqz v11, :cond_8

    .line 357
    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 359
    :cond_8
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 361
    :goto_3
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .local v11, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 362
    .local v13, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\361\\3":I
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v11, v7, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 363
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v11, v8, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 365
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    .local v14, "block\\6":Lkotlin/jvm/functions/Function2;
    const/4 v15, 0x0

    .line 366
    .local v15, "$i$f$set-impl\\6\\365":I
    move-object/from16 p2, v11

    .local p2, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 367
    .local v16, "$i$a$-with-Updater$set$1\\7\\366\\6":I
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v17

    if-nez v17, :cond_a

    move/from16 v17, v12

    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v12, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v12, p2

    goto :goto_5

    :cond_a
    move/from16 v17, v12

    .line 368
    :goto_4
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v12, p2

    .end local p2    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 369
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v11, v0, v14}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 371
    :goto_5
    nop

    .line 366
    .end local v12    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-with-Updater$set$1\\7\\366\\6":I
    nop

    .line 371
    nop

    .line 372
    .end local v14    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v15    # "$i$f$set-impl\\6\\365":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v11, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 373
    nop

    .line 361
    .end local v11    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\361\\3":I
    nop

    .line 374
    shr-int/lit8 v0, v30, 0x6

    and-int/lit8 v32, v0, 0xe

    .local v32, "$changed\\8":I
    move-object v0, v3

    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 375
    .local v33, "$i$a$-Layout-ColumnKt$Column$1\\8\\374\\2":I
    const v11, -0x16ef5699

    const-string v12, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v0, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v11, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v12, v25, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v34, v12, 0x6

    .local v34, "$changed\\9":I
    check-cast v11, Landroidx/compose/foundation/layout/ColumnScope;

    .local v11, "$this$Message_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v12, v0

    .local v12, "$composer\\9":Landroidx/compose/runtime/Composer;
    move-object/from16 v35, v11

    .end local v11    # "$this$Message_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v35, "$this$Message_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const/16 v36, 0x0

    .line 70
    .local v36, "$i$a$-Column-HitchInspectorKt$Message$1\\9\\375\\0":I
    const v11, -0x60c709bc

    const-string v13, "C69@3708L10,69@3674L57,70@3740L29,71@3811L10,71@3856L11,71@3778L107:HitchInspector.kt#o13vsk"

    invoke-static {v12, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v11, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v11, v12, v13}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v11

    invoke-virtual {v11}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    and-int/lit8 v22, v4, 0xe

    const/16 v23, 0x0

    const v24, 0xfffe

    const/4 v1, 0x0

    move-object v13, v2

    move-object v11, v3

    .end local v2    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-wide/16 v2, 0x0

    move v14, v4

    move-object v15, v5

    .end local v4    # "$dirty":I
    .end local v5    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v14, "$dirty":I
    .local v15, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const-wide/16 v4, 0x0

    move-object/from16 v16, v6

    .end local v6    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v16, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/4 v6, 0x0

    move-object/from16 v18, v7

    .end local v7    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v18, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v7, 0x0

    move-object/from16 v19, v8

    .end local v8    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v19, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v8, 0x0

    move-object/from16 v21, v9

    move-object/from16 v37, v10

    .end local v9    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v10    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v21, "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v37, "factory\\4":Lkotlin/jvm/functions/Function0;
    const-wide/16 v9, 0x0

    move-object/from16 v38, v11

    .end local v11    # "$composer":Landroidx/compose/runtime/Composer;
    .local v38, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    move-object/from16 v39, v21

    move-object/from16 v21, v12

    .end local v12    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v39, "materialized\\3":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v41, v13

    move/from16 v40, v14

    .end local v13    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v14    # "$dirty":I
    .local v40, "$dirty":I
    .local v41, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-wide/16 v13, 0x0

    move-object/from16 v42, v15

    .end local v15    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v42, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v15, 0x0

    move-object/from16 v43, v16

    .end local v16    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v43, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v16, 0x0

    move/from16 v44, v17

    const/16 v17, 0x0

    move-object/from16 v45, v18

    .end local v18    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v45, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v18, 0x0

    move-object/from16 v46, v19

    .end local v19    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v46, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v19, 0x0

    move-object/from16 v44, v0

    move-object/from16 v0, p0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 71
    move-object/from16 v0, v21

    .end local v21    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\10":I
    const/4 v3, 0x0

    .line 376
    .local v3, "$i$f$getDp\\10\\71":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 71
    .end local v2    # "$this$dp\\10":I
    .end local v3    # "$i$f$getDp\\10\\71":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v0, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 72
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v2

    shr-int/lit8 v1, v40, 0x3

    and-int/lit8 v22, v1, 0xe

    const v24, 0xfffa

    const/4 v1, 0x0

    const-wide/16 v4, 0x0

    move-object/from16 v0, p1

    .end local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 70
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 73
    nop

    .line 375
    .end local v21    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\9":I
    .end local v35    # "$this$Message_u24lambda_u241\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v36    # "$i$a$-Column-HitchInspectorKt$Message$1\\9\\375\\0":I
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 374
    .end local v32    # "$changed\\8":I
    .end local v33    # "$i$a$-Layout-ColumnKt$Column$1\\8\\374\\2":I
    .end local v44    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 377
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 353
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 378
    nop

    .line 347
    .end local v30    # "$changed\\4":I
    .end local v31    # "$i$f$ReusableComposeNode\\4\\351":I
    .end local v37    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 379
    nop

    .line 344
    .end local v27    # "$changed\\3":I
    .end local v28    # "$i$f$Layout\\3\\346":I
    .end local v29    # "compositeKeyHash\\3":I
    .end local v39    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v46    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 380
    nop

    .end local v25    # "$changed\\2":I
    .end local v26    # "$i$f$Column\\2\\69":I
    .end local v41    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v42    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v43    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v45    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_b
    :goto_6
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_c

    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda2;

    move-object/from16 v3, p0

    move/from16 v4, p3

    invoke-direct {v2, v3, v0, v4}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda2;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_7

    :cond_c
    move-object/from16 v3, p0

    move/from16 v4, p3

    .line 74
    :goto_7
    return-void
.end method

.method private static final Message$lambda$2(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/HitchInspectorKt;->Message(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Overview(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .locals 32
    .param p0, "data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "range"    # Lkotlin/Pair;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "onRange"    # Lkotlin/jvm/functions/Function1;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/HitchData;",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 165
    move-object/from16 v1, p0

    move-object/from16 v11, p2

    move/from16 v12, p5

    const v0, -0x1e54cd6c

    move-object/from16 v2, p4

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(Overview)P(!1,3)167@10280L11,168@10342L11,170@10410L390,178@10829L248,183@11079L940,169@10366L1653:HitchInspector.kt#o13vsk"

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p5

    .local v2, "$dirty":I
    and-int/lit8 v3, v12, 0x6

    if-nez v3, :cond_1

    invoke-interface {v13, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v12, 0x30

    if-nez v3, :cond_3

    move-object/from16 v3, p1

    invoke-interface {v13, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v2, v5

    goto :goto_2

    :cond_3
    move-object/from16 v3, p1

    :goto_2
    and-int/lit16 v5, v12, 0x180

    if-nez v5, :cond_5

    invoke-interface {v13, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x100

    goto :goto_3

    :cond_4
    const/16 v5, 0x80

    :goto_3
    or-int/2addr v2, v5

    :cond_5
    and-int/lit16 v5, v12, 0xc00

    if-nez v5, :cond_7

    move-object/from16 v5, p3

    invoke-interface {v13, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_6

    const/16 v7, 0x800

    goto :goto_4

    :cond_6
    const/16 v7, 0x400

    :goto_4
    or-int/2addr v2, v7

    goto :goto_5

    :cond_7
    move-object/from16 v5, p3

    :goto_5
    and-int/lit16 v7, v2, 0x493

    const/16 v8, 0x492

    if-ne v7, v8, :cond_9

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v7

    if-nez v7, :cond_8

    goto :goto_6

    .line 170
    :cond_8
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v26, v2

    goto/16 :goto_10

    .line 165
    :cond_9
    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_a

    const/4 v7, -0x1

    const-string v8, "org.lighttouch.android.Overview (HitchInspector.kt:164)"

    invoke-static {v0, v2, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 166
    :cond_a
    invoke-virtual {v1}, Lorg/lighttouch/android/HitchData;->getStartNs()J

    move-result-wide v7

    .local v7, "start":J
    invoke-virtual {v1}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/HitchFrame;

    invoke-virtual {v0}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v9

    .line 167
    .local v9, "end":J
    sub-long v14, v9, v7

    const-wide/16 v4, 0x1

    invoke-static {v14, v15, v4, v5}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v4

    .line 168
    .local v4, "span":J
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v13, v14}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v14

    .line 169
    .local v14, "surface":J
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v13, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    move-wide/from16 v22, v9

    .end local v9    # "end":J
    .local v22, "end":J
    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v9

    .line 170
    .local v9, "band":J
    nop

    .line 171
    const v0, -0x6815fd56

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):HitchInspector.kt#9igjgp"

    invoke-static {v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v13, v7, v8}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    invoke-interface {v13, v4, v5}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v16

    or-int v6, v6, v16

    and-int/lit16 v3, v2, 0x1c00

    const/16 v24, 0x1

    const/16 v12, 0x800

    if-ne v3, v12, :cond_b

    move/from16 v3, v24

    goto :goto_7

    :cond_b
    const/4 v3, 0x0

    :goto_7
    or-int/2addr v3, v6

    .local v3, "invalid\\1":Z
    move-object v6, v13

    .local v6, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 699
    .local v12, "$i$f$cache\\1\\171":I
    move/from16 v25, v3

    .end local v3    # "invalid\\1":Z
    .local v25, "invalid\\1":Z
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\1":Ljava/lang/Object;
    const/16 v26, 0x0

    .line 700
    .local v26, "$i$a$-let-ComposerKt$cache$1\\2\\699\\1":I
    if-nez v25, :cond_d

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-wide/from16 v17, v4

    .end local v4    # "span":J
    .local v17, "span":J
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_c

    goto :goto_8

    .line 704
    :cond_c
    move-wide/from16 v28, v14

    move-wide v14, v7

    move-wide/from16 v7, v28

    move-object/from16 v16, v3

    move-wide/from16 v3, v17

    move-object/from16 v17, v16

    goto :goto_9

    .line 700
    .end local v17    # "span":J
    .restart local v4    # "span":J
    :cond_d
    move-wide/from16 v17, v4

    .line 701
    .end local v4    # "span":J
    .restart local v17    # "span":J
    :goto_8
    const/4 v4, 0x0

    .line 171
    .local v4, "$i$a$-cache-HitchInspectorKt$Overview$1\\3\\701\\0":I
    move-wide v15, v14

    .end local v14    # "surface":J
    .local v15, "surface":J
    new-instance v14, Lorg/lighttouch/android/HitchInspectorKt$Overview$1$1;

    const/16 v20, 0x0

    move-wide/from16 v28, v15

    move-wide v15, v7

    move-wide/from16 v7, v28

    move-object/from16 v19, p3

    .local v7, "surface":J
    .local v15, "start":J
    invoke-direct/range {v14 .. v20}, Lorg/lighttouch/android/HitchInspectorKt$Overview$1$1;-><init>(JJLkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V

    move-object v5, v3

    move-wide/from16 v28, v15

    move/from16 v16, v4

    move-wide/from16 v3, v17

    move-object/from16 v17, v14

    move-wide/from16 v14, v28

    .end local v4    # "$i$a$-cache-HitchInspectorKt$Overview$1\\3\\701\\0":I
    .end local v15    # "start":J
    .end local v17    # "span":J
    .local v3, "span":J
    .local v5, "it\\1":Ljava/lang/Object;
    .local v14, "start":J
    .local v16, "$i$a$-cache-HitchInspectorKt$Overview$1\\3\\701\\0":I
    move-object/from16 v16, v17

    check-cast v16, Lkotlin/jvm/functions/Function2;

    .line 701
    .end local v16    # "$i$a$-cache-HitchInspectorKt$Overview$1\\3\\701\\0":I
    move-object/from16 v17, v16

    .line 702
    .local v17, "value\\2":Ljava/lang/Object;
    move-object/from16 v16, v5

    move-object/from16 v5, v17

    .end local v17    # "value\\2":Ljava/lang/Object;
    .local v5, "value\\2":Ljava/lang/Object;
    .local v16, "it\\1":Ljava/lang/Object;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 703
    nop

    .line 700
    .end local v5    # "value\\2":Ljava/lang/Object;
    :goto_9
    nop

    .line 699
    .end local v16    # "it\\1":Ljava/lang/Object;
    .end local v26    # "$i$a$-let-ComposerKt$cache$1\\2\\699\\1":I
    nop

    .line 171
    .end local v6    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\1\\171":I
    .end local v25    # "invalid\\1":Z
    move-object/from16 v5, v17

    check-cast v5, Lkotlin/jvm/functions/Function2;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v11, v1, v5}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 179
    const v6, -0x48fade91

    invoke-interface {v13, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v13, v14, v15}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v12

    invoke-interface {v13, v3, v4}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v16

    or-int v12, v12, v16

    and-int/lit16 v6, v2, 0x1c00

    move/from16 v26, v2

    const/16 v2, 0x800

    .end local v2    # "$dirty":I
    .local v26, "$dirty":I
    if-ne v6, v2, :cond_e

    move/from16 v2, v24

    goto :goto_a

    :cond_e
    const/4 v2, 0x0

    :goto_a
    or-int/2addr v2, v12

    move-wide/from16 v17, v3

    move v4, v2

    move-wide/from16 v2, v22

    .end local v3    # "span":J
    .end local v22    # "end":J
    .local v2, "end":J
    .local v17, "span":J
    invoke-interface {v13, v2, v3}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    or-int/2addr v4, v6

    .local v4, "invalid\\4":Z
    move-object v6, v13

    .local v6, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 705
    .local v12, "$i$f$cache\\4\\179":I
    nop

    .end local v2    # "end":J
    .restart local v22    # "end":J
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\4":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 706
    .local v3, "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    if-nez v4, :cond_10

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v27, v3

    .end local v3    # "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    .local v27, "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_f

    goto :goto_b

    .line 710
    :cond_f
    move-object/from16 v16, v2

    move-wide/from16 v20, v22

    move-wide/from16 v2, v17

    move-object/from16 v18, v16

    move/from16 v17, v4

    goto :goto_c

    .line 706
    .end local v27    # "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    .restart local v3    # "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    :cond_10
    move/from16 v27, v3

    .line 707
    .end local v3    # "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    .restart local v27    # "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    :goto_b
    const/4 v3, 0x0

    .line 179
    .local v3, "$i$a$-cache-HitchInspectorKt$Overview$2\\6\\707\\0":I
    move-wide v15, v14

    .end local v14    # "start":J
    .restart local v15    # "start":J
    new-instance v14, Lorg/lighttouch/android/HitchInspectorKt$Overview$2$1;

    move-wide/from16 v20, v22

    .end local v22    # "end":J
    .local v20, "end":J
    const/16 v22, 0x0

    move-object/from16 v19, p3

    invoke-direct/range {v14 .. v22}, Lorg/lighttouch/android/HitchInspectorKt$Overview$2$1;-><init>(JJLkotlin/jvm/functions/Function1;JLkotlin/coroutines/Continuation;)V

    move-wide/from16 v28, v15

    move-object/from16 v16, v2

    move-wide/from16 v30, v17

    move/from16 v17, v3

    move-object/from16 v18, v14

    move-wide/from16 v14, v28

    move-wide/from16 v2, v30

    .end local v3    # "$i$a$-cache-HitchInspectorKt$Overview$2\\6\\707\\0":I
    .end local v15    # "start":J
    .local v2, "span":J
    .restart local v14    # "start":J
    .local v16, "it\\4":Ljava/lang/Object;
    .local v17, "$i$a$-cache-HitchInspectorKt$Overview$2\\6\\707\\0":I
    move-object/from16 v17, v18

    check-cast v17, Lkotlin/jvm/functions/Function2;

    .line 707
    .end local v17    # "$i$a$-cache-HitchInspectorKt$Overview$2\\6\\707\\0":I
    move-object/from16 v18, v17

    .line 708
    .local v18, "value\\5":Ljava/lang/Object;
    move/from16 v17, v4

    move-object/from16 v4, v18

    .end local v18    # "value\\5":Ljava/lang/Object;
    .local v4, "value\\5":Ljava/lang/Object;
    .local v17, "invalid\\4":Z
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 709
    nop

    .line 706
    .end local v4    # "value\\5":Ljava/lang/Object;
    :goto_c
    nop

    .line 705
    .end local v16    # "it\\4":Ljava/lang/Object;
    .end local v27    # "$i$a$-let-ComposerKt$cache$1\\5\\705\\4":I
    nop

    .line 179
    .end local v6    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\4\\179":I
    .end local v17    # "invalid\\4":Z
    move-object/from16 v4, v18

    check-cast v4, Lkotlin/jvm/functions/Function2;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v5, v1, v4}, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->pointerInput(Landroidx/compose/ui/Modifier;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    const v4, -0x48fade91

    invoke-interface {v13, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v13, v7, v8}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v0

    invoke-interface {v13, v14, v15}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v4

    or-int/2addr v0, v4

    invoke-interface {v13, v2, v3}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v4

    or-int/2addr v0, v4

    invoke-interface {v13, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v0, v4

    and-int/lit8 v4, v26, 0x70

    const/16 v5, 0x20

    if-ne v4, v5, :cond_11

    goto :goto_d

    :cond_11
    const/16 v24, 0x0

    :goto_d
    or-int v0, v0, v24

    invoke-interface {v13, v9, v10}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v4

    or-int/2addr v0, v4

    .line 184
    move/from16 v16, v0

    .local v16, "invalid\\7":Z
    move-object v0, v13

    .local v0, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 711
    .local v17, "$i$f$cache\\7\\184":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\7":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 712
    .local v18, "$i$a$-let-ComposerKt$cache$1\\8\\711\\7":I
    if-nez v16, :cond_13

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_12

    goto :goto_e

    .line 716
    :cond_12
    move-wide v5, v14

    move-object v14, v0

    move-wide v0, v7

    move-wide v7, v5

    move-object v15, v4

    move-wide v5, v9

    goto :goto_f

    .line 713
    :cond_13
    :goto_e
    const/16 v19, 0x0

    .line 184
    .local v19, "$i$a$-cache-HitchInspectorKt$Overview$3\\9\\713\\0":I
    move-object v5, v0

    .end local v0    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .local v5, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda6;

    move-wide/from16 v28, v2

    move-object v3, v1

    move-wide v1, v7

    move-wide v7, v14

    move-object v14, v5

    move-wide v5, v9

    move-wide/from16 v9, v28

    move-object v15, v4

    move-object/from16 v4, p1

    .end local v2    # "span":J
    .end local v4    # "it\\7":Ljava/lang/Object;
    .local v1, "surface":J
    .local v5, "band":J
    .local v7, "start":J
    .local v9, "span":J
    .local v14, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .local v15, "it\\7":Ljava/lang/Object;
    invoke-direct/range {v0 .. v10}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda6;-><init>(JLorg/lighttouch/android/HitchData;Lkotlin/Pair;JJJ)V

    .line 713
    move-object v4, v0

    move-wide v0, v1

    move-wide v2, v9

    .line 714
    .end local v1    # "surface":J
    .end local v9    # "span":J
    .end local v19    # "$i$a$-cache-HitchInspectorKt$Overview$3\\9\\713\\0":I
    .local v0, "surface":J
    .restart local v2    # "span":J
    .local v4, "value\\8":Ljava/lang/Object;
    invoke-interface {v14, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 715
    nop

    .line 712
    .end local v4    # "value\\8":Ljava/lang/Object;
    :goto_f
    nop

    .line 711
    .end local v15    # "it\\7":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\8\\711\\7":I
    nop

    .line 184
    .end local v14    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\7":Z
    .end local v17    # "$i$f$cache\\7\\184":I
    check-cast v4, Lkotlin/jvm/functions/Function1;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 170
    const/4 v9, 0x0

    invoke-static {v12, v4, v13, v9}, Landroidx/compose/foundation/CanvasKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "surface":J
    .end local v2    # "span":J
    .end local v5    # "band":J
    .end local v7    # "start":J
    .end local v20    # "end":J
    :cond_14
    :goto_10
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_15

    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda7;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v4, p3

    move/from16 v5, p5

    move-object v3, v11

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;I)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 198
    :cond_15
    return-void
.end method

.method private static final Overview$lambda$45$lambda$44(JLorg/lighttouch/android/HitchData;Lkotlin/Pair;JJJLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .locals 20
    .param p0, "$surface"    # J
    .param p2, "$data"    # Lorg/lighttouch/android/HitchData;
    .param p3, "$range"    # Lkotlin/Pair;
    .param p4, "$band"    # J
    .param p6, "$start"    # J
    .param p8, "$span"    # J
    .param p10, "$this$Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;

    move-object/from16 v4, p10

    const-string v0, "$this$Canvas"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 185
    const/16 v0, 0x8

    .local v0, "$this$dp\\1":I
    const/4 v1, 0x0

    .line 1055
    .local v1, "$i$f$getDp\\1\\185":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 185
    .end local v0    # "$this$dp\\1":I
    .end local v1    # "$i$f$getDp\\1\\185":I
    invoke-interface {v4, v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v15, 0x0

    invoke-static {v0, v15, v1, v2}, Landroidx/compose/ui/geometry/CornerRadiusKt;->CornerRadius$default(FFILjava/lang/Object;)J

    move-result-wide v7

    const/16 v13, 0xf6

    const/4 v14, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-wide/from16 v1, p0

    move-object/from16 v0, p10

    invoke-static/range {v0 .. v14}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/DrawStyle;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 188
    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/HitchData;->getFrames()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :cond_0
    :goto_0
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lorg/lighttouch/android/HitchFrame;

    .line 189
    .local v17, "f":Lorg/lighttouch/android/HitchFrame;
    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/HitchFrame;->getIdle()Z

    move-result v0

    if-nez v0, :cond_0

    .line 190
    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/HitchInspectorKt;->frameColor(F)J

    move-result-wide v1

    .line 191
    .local v1, "color":J
    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v7

    cmp-long v0, v3, v7

    const/4 v3, 0x0

    if-gtz v0, :cond_1

    cmp-long v0, v7, v5

    if-gtz v0, :cond_1

    const/4 v3, 0x1

    :cond_1
    if-eqz v3, :cond_2

    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_1

    :cond_2
    const v0, 0x3ee66666    # 0.45f

    :goto_1
    move v3, v0

    const/16 v7, 0xe

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v8}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v7

    .line 192
    move-wide/from16 v18, v1

    .end local v1    # "color":J
    .local v18, "color":J
    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v5

    move-wide/from16 v0, p6

    move-wide/from16 v2, p8

    move-object/from16 v4, p10

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-interface/range {p10 .. p10}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    const/high16 v9, 0x40800000    # 4.0f

    sub-float/2addr v0, v9

    invoke-static {v5, v0}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v10

    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v5

    move-wide/from16 v0, p6

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-interface {v4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    sub-float/2addr v0, v9

    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v1

    invoke-static {v4, v1}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$h(Landroidx/compose/ui/graphics/drawscope/DrawScope;F)F

    move-result v1

    sub-float/2addr v0, v1

    invoke-static {v5, v0}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v5

    .line 191
    const/16 v13, 0x1f0

    const/4 v14, 0x0

    move-wide v1, v7

    const/high16 v7, 0x3fc00000    # 1.5f

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-wide v3, v10

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-object/from16 v0, p10

    invoke-static/range {v0 .. v14}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawLine-NGM6Ib0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFILandroidx/compose/ui/graphics/PathEffect;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .end local v17    # "f":Lorg/lighttouch/android/HitchFrame;
    .end local v18    # "color":J
    goto/16 :goto_0

    .line 194
    :cond_3
    const/16 v6, 0xe

    const/4 v7, 0x0

    const v2, 0x3e23d70a    # 0.16f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-wide/from16 v0, p4

    invoke-static/range {v0 .. v7}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v7

    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    move-wide/from16 v2, p8

    move-object/from16 v4, p10

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-static {v5, v15}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v9

    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v11

    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    sub-float/2addr v11, v5

    invoke-interface/range {p10 .. p10}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    invoke-static {v11, v0}, Landroidx/compose/ui/geometry/SizeKt;->Size(FF)J

    move-result-wide v5

    const/16 v11, 0x78

    const/4 v12, 0x0

    move-wide v1, v7

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-wide v3, v9

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object/from16 v0, p10

    invoke-static/range {v0 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 195
    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    move-wide/from16 v2, p8

    move-object/from16 v4, p10

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-static {v5, v15}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v7

    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-interface {v4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    invoke-static {v5, v0}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v5

    const/4 v0, 0x2

    .local v0, "$this$dp\\2":I
    const/4 v1, 0x0

    .line 1056
    .local v1, "$i$f$getDp\\2\\195":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 195
    .end local v0    # "$this$dp\\2":I
    .end local v1    # "$i$f$getDp\\2\\195":I
    invoke-interface {v4, v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v0

    const/16 v13, 0x1f0

    const/4 v14, 0x0

    move-wide v3, v7

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-wide/from16 v1, p4

    move v7, v0

    move-object/from16 v0, p10

    invoke-static/range {v0 .. v14}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawLine-NGM6Ib0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFILandroidx/compose/ui/graphics/PathEffect;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 196
    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    move-wide/from16 v2, p8

    move-object/from16 v4, p10

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-static {v5, v15}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v7

    invoke-virtual/range {p3 .. p3}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v5

    move-wide/from16 v0, p6

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F

    move-result v5

    invoke-interface {v4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    invoke-static {v5, v0}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v5

    const/4 v0, 0x2

    .local v0, "$this$dp\\3":I
    const/4 v1, 0x0

    .line 1057
    .local v1, "$i$f$getDp\\3\\196":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 196
    .end local v0    # "$this$dp\\3":I
    .end local v1    # "$i$f$getDp\\3\\196":I
    invoke-interface {v4, v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v0

    move-wide v3, v7

    const/4 v8, 0x0

    move-wide/from16 v1, p4

    move v7, v0

    move-object/from16 v0, p10

    invoke-static/range {v0 .. v14}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawLine-NGM6Ib0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFILandroidx/compose/ui/graphics/PathEffect;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 197
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Overview$lambda$45$lambda$44$h(Landroidx/compose/ui/graphics/drawscope/DrawScope;F)F
    .locals 4
    .param p0, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p1, "ms"    # F

    .line 187
    const/high16 v0, 0x42c80000    # 100.0f

    invoke-static {p1, v0}, Lkotlin/ranges/RangesKt;->coerceAtMost(FF)F

    move-result v1

    div-float/2addr v1, v0

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    const/high16 v2, 0x41000000    # 8.0f

    sub-float/2addr v0, v2

    mul-float/2addr v1, v0

    return v1
.end method

.method private static final Overview$lambda$45$lambda$44$x(JJLandroidx/compose/ui/graphics/drawscope/DrawScope;J)F
    .locals 3
    .param p0, "start"    # J
    .param p2, "span"    # J
    .param p4, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p5, "t"    # J

    .line 186
    sub-long v0, p5, p0

    long-to-float v0, v0

    long-to-float v1, p2

    div-float/2addr v0, v1

    invoke-interface {p4}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/compose/ui/geometry/Size;->getWidth-impl(J)F

    move-result v1

    mul-float/2addr v0, v1

    return v0
.end method

.method private static final Overview$lambda$46(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/HitchInspectorKt;->Overview(Lorg/lighttouch/android/HitchData;Lkotlin/Pair;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 26
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 152
    move-object/from16 v0, p0

    const v1, -0x284a6c5d

    move-object/from16 v2, p1

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(SectionLabel)151@9306L10,152@9355L11,151@9240L144:HitchInspector.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, p2, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    :cond_2
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v21, v2

    move/from16 v25, v3

    goto/16 :goto_2

    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.SectionLabel (HitchInspector.kt:151)"

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_4
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v4, v1

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 657
    .local v5, "$i$f$getDp\\1\\152":I
    int-to-float v6, v1

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 152
    .end local v1    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\152":I
    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v2, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    .line 153
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v2, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v4

    .line 152
    nop

    .line 153
    nop

    .line 152
    and-int/lit8 v6, v3, 0xe

    or-int/lit8 v22, v6, 0x30

    const/16 v23, 0x0

    const v24, 0xfff8

    move-object/from16 v21, v2

    move v6, v3

    move-wide v2, v4

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .local v6, "$dirty":I
    .local v21, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v4, 0x0

    move v7, v6

    .end local v6    # "$dirty":I
    .local v7, "$dirty":I
    const/4 v6, 0x0

    move v8, v7

    .end local v7    # "$dirty":I
    .local v8, "$dirty":I
    const/4 v7, 0x0

    move v9, v8

    .end local v8    # "$dirty":I
    .local v9, "$dirty":I
    const/4 v8, 0x0

    move v11, v9

    .end local v9    # "$dirty":I
    .local v11, "$dirty":I
    const-wide/16 v9, 0x0

    move v12, v11

    .end local v11    # "$dirty":I
    .local v12, "$dirty":I
    const/4 v11, 0x0

    move v13, v12

    .end local v12    # "$dirty":I
    .local v13, "$dirty":I
    const/4 v12, 0x0

    move v15, v13

    .end local v13    # "$dirty":I
    .local v15, "$dirty":I
    const-wide/16 v13, 0x0

    move/from16 v16, v15

    .end local v15    # "$dirty":I
    .local v16, "$dirty":I
    const/4 v15, 0x0

    move/from16 v17, v16

    .end local v16    # "$dirty":I
    .local v17, "$dirty":I
    const/16 v16, 0x0

    move/from16 v18, v17

    .end local v17    # "$dirty":I
    .local v18, "$dirty":I
    const/16 v17, 0x0

    move/from16 v19, v18

    .end local v18    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v18, 0x0

    move/from16 v25, v19

    .end local v19    # "$dirty":I
    .local v25, "$dirty":I
    const/16 v19, 0x0

    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_5
    :goto_2
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_6

    new-instance v2, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda9;

    move/from16 v3, p2

    invoke-direct {v2, v0, v3}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda9;-><init>(Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_3

    :cond_6
    move/from16 v3, p2

    .line 153
    :goto_3
    return-void
.end method

.method private static final SectionLabel$lambda$39(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/HitchInspectorKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Stat-xqIIw2o(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V
    .locals 50
    .param p0, "label"    # Ljava/lang/String;
    .param p1, "value"    # Ljava/lang/String;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "color"    # Landroidx/compose/ui/graphics/Color;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    .line 156
    move-object/from16 v3, p2

    move/from16 v5, p5

    const v0, -0x70a3fdb5

    move-object/from16 v1, p4

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(Stat)P(1,3,2,0:c#ui.graphics.Color)156@9534L11,156@9493L420:HitchInspector.kt#o13vsk"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p5

    .local v1, "$dirty":I
    and-int/lit8 v2, p6, 0x1

    if-eqz v2, :cond_0

    or-int/lit8 v1, v1, 0x6

    move-object/from16 v8, p0

    goto :goto_1

    :cond_0
    and-int/lit8 v2, v5, 0x6

    if-nez v2, :cond_2

    move-object/from16 v8, p0

    invoke-interface {v7, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v1, v2

    goto :goto_1

    :cond_2
    move-object/from16 v8, p0

    :goto_1
    and-int/lit8 v2, p6, 0x2

    if-eqz v2, :cond_3

    or-int/lit8 v1, v1, 0x30

    move-object/from16 v9, p1

    goto :goto_3

    :cond_3
    and-int/lit8 v2, v5, 0x30

    if-nez v2, :cond_5

    move-object/from16 v9, p1

    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    const/16 v2, 0x20

    goto :goto_2

    :cond_4
    const/16 v2, 0x10

    :goto_2
    or-int/2addr v1, v2

    goto :goto_3

    :cond_5
    move-object/from16 v9, p1

    :goto_3
    and-int/lit8 v2, p6, 0x4

    if-eqz v2, :cond_6

    or-int/lit16 v1, v1, 0x180

    goto :goto_5

    :cond_6
    and-int/lit16 v2, v5, 0x180

    if-nez v2, :cond_8

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    const/16 v2, 0x100

    goto :goto_4

    :cond_7
    const/16 v2, 0x80

    :goto_4
    or-int/2addr v1, v2

    :cond_8
    :goto_5
    and-int/lit8 v2, p6, 0x8

    if-eqz v2, :cond_9

    or-int/lit16 v1, v1, 0xc00

    move-object/from16 v4, p3

    goto :goto_7

    :cond_9
    and-int/lit16 v4, v5, 0xc00

    if-nez v4, :cond_b

    move-object/from16 v4, p3

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_a

    const/16 v6, 0x800

    goto :goto_6

    :cond_a
    const/16 v6, 0x400

    :goto_6
    or-int/2addr v1, v6

    goto :goto_7

    :cond_b
    move-object/from16 v4, p3

    :goto_7
    and-int/lit16 v6, v1, 0x493

    const/16 v10, 0x492

    if-ne v6, v10, :cond_d

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_c

    goto :goto_8

    .line 698
    :cond_c
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v38, v1

    goto/16 :goto_e

    .line 156
    :cond_d
    :goto_8
    if-eqz v2, :cond_e

    const/4 v2, 0x0

    .end local p3    # "color":Landroidx/compose/ui/graphics/Color;
    .local v2, "color":Landroidx/compose/ui/graphics/Color;
    goto :goto_9

    .end local v2    # "color":Landroidx/compose/ui/graphics/Color;
    .restart local p3    # "color":Landroidx/compose/ui/graphics/Color;
    :cond_e
    move-object v2, v4

    .end local p3    # "color":Landroidx/compose/ui/graphics/Color;
    .restart local v2    # "color":Landroidx/compose/ui/graphics/Color;
    :goto_9
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_f

    const/4 v4, -0x1

    const-string v6, "org.lighttouch.android.Stat (HitchInspector.kt:155)"

    invoke-static {v0, v1, v4, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 157
    :cond_f
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v7, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v10

    const/16 v0, 0xc

    .local v0, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 658
    .local v4, "$i$f$getDp\\1\\157":I
    int-to-float v6, v0

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 157
    .end local v0    # "$this$dp\\1":I
    .end local v4    # "$i$f$getDp\\1\\157":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    check-cast v0, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v10, v11, v0}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v4, 0xa

    .local v4, "$this$dp\\2":I
    const/4 v6, 0x0

    .line 658
    .local v6, "$i$f$getDp\\2\\157":I
    int-to-float v10, v4

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 157
    .end local v4    # "$this$dp\\2":I
    .end local v6    # "$i$f$getDp\\2\\157":I
    const/16 v6, 0x8

    .local v6, "$this$dp\\3":I
    const/4 v10, 0x0

    .line 658
    .local v10, "$i$f$getDp\\3\\157":I
    int-to-float v11, v6

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 157
    .end local v6    # "$this$dp\\3":I
    .end local v10    # "$i$f$getDp\\3\\157":I
    invoke-static {v0, v4, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x0

    .local v4, "$changed\\4":I
    const/4 v6, 0x0

    .line 659
    .local v6, "$i$f$Column\\4\\157":I
    const v10, -0x1cd0f17e

    const-string v11, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v7, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 660
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v10

    .line 661
    .local v10, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v11

    .line 664
    .local v11, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v4, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v10, v11, v7, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v4, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 665
    move/from16 v34, v13

    .local v34, "$changed\\5":I
    const/16 v35, 0x0

    .line 666
    .local v35, "$i$f$Layout\\5\\665":I
    const v13, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v7, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 667
    const/4 v13, 0x0

    invoke-static {v7, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v36

    .line 668
    .local v36, "compositeKeyHash\\5":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 669
    .local v13, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 671
    .local v14, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    move-object/from16 p3, v0

    .end local v0    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local p3, "modifier\\4":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v34, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 670
    nop

    .local v0, "$changed\\6":I
    .local v15, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v37, 0x0

    .line 672
    .local v37, "$i$f$ReusableComposeNode\\6\\670":I
    move/from16 p4, v0

    .end local v0    # "$changed\\6":I
    .local p4, "$changed\\6":I
    const v0, -0x2942ffcf

    move/from16 v38, v1

    .end local v1    # "$dirty":I
    .local v38, "$dirty":I
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 673
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 674
    :cond_10
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 675
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_11

    .line 676
    invoke-interface {v7, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 678
    :cond_11
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 680
    :goto_a
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 681
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\680\\5":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v17, v1

    .end local v1    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\680\\5":I
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\680\\5":I
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 682
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 684
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 685
    .local v16, "$i$f$set-impl\\8\\684":I
    move-object/from16 v18, v0

    .local v18, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 686
    .local v19, "$i$a$-with-Updater$set$1\\9\\685\\8":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v20

    if-nez v20, :cond_13

    move-object/from16 v39, v2

    .end local v2    # "color":Landroidx/compose/ui/graphics/Color;
    .local v39, "color":Landroidx/compose/ui/graphics/Color;
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_12

    goto :goto_b

    :cond_12
    move-object/from16 v3, v18

    goto :goto_c

    .end local v39    # "color":Landroidx/compose/ui/graphics/Color;
    .restart local v2    # "color":Landroidx/compose/ui/graphics/Color;
    :cond_13
    move-object/from16 v39, v2

    .line 687
    .end local v2    # "color":Landroidx/compose/ui/graphics/Color;
    .restart local v39    # "color":Landroidx/compose/ui/graphics/Color;
    :goto_b
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 688
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 690
    :goto_c
    nop

    .line 685
    .end local v3    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-with-Updater$set$1\\9\\685\\8":I
    nop

    .line 690
    nop

    .line 691
    .end local v1    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\8\\684":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 692
    nop

    .line 680
    .end local v0    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\680\\5":I
    nop

    .line 693
    shr-int/lit8 v0, p4, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\10":I
    move-object v1, v7

    .local v1, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 694
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\10\\693\\4":I
    const v3, -0x16ef5699

    move/from16 v40, v0

    .end local v0    # "$changed\\10":I
    .local v40, "$changed\\10":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v4, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\11":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$Stat_xqIIw2o_u24lambda_u2440\\11":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v30, v1

    .local v30, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 158
    .local v41, "$i$a$-Column-HitchInspectorKt$Stat$1\\11\\694\\0":I
    move-object/from16 v42, v0

    .end local v0    # "$this$Stat_xqIIw2o_u24lambda_u2440\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .local v42, "$this$Stat_xqIIw2o_u24lambda_u2440\\11":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x1d31348e

    move-object/from16 v43, v1

    .end local v1    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\10":Landroidx/compose/runtime/Composer;
    const-string v1, "C157@9685L10,157@9651L125,158@9819L10,158@9864L11,158@9785L122:HitchInspector.kt#o13vsk"

    move/from16 v44, v2

    move-object/from16 v2, v30

    .end local v30    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v44, "$i$a$-Layout-ColumnKt$Column$1\\10\\693\\4":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v29

    const v0, -0x411f6a7f

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "157@9740L11"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v39, :cond_14

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v0

    goto :goto_d

    :cond_14
    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/graphics/Color;->unbox-impl()J

    move-result-wide v0

    :goto_d
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    shr-int/lit8 v16, v38, 0x3

    and-int/lit8 v31, v16, 0xe

    const/16 v32, 0xc00

    const v33, 0xdffa

    move-object/from16 v16, v10

    .end local v10    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v16, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v10, 0x0

    move-object/from16 v17, v13

    move-object/from16 v18, v14

    .end local v13    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v17, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v18, "materialized\\5":Landroidx/compose/ui/Modifier;
    const-wide/16 v13, 0x0

    move-object/from16 v19, v15

    .end local v15    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v19, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/4 v15, 0x0

    move-object/from16 v20, v16

    .end local v16    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v20, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v16, 0x0

    move-object/from16 v21, v17

    .end local v17    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v21, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v17, 0x0

    move-object/from16 v22, v18

    move-object/from16 v23, v19

    .end local v18    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v19    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v22, "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v23, "factory\\6":Lkotlin/jvm/functions/Function0;
    const-wide/16 v18, 0x0

    move-object/from16 v24, v20

    .end local v20    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v24, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v20, 0x0

    move-object/from16 v25, v21

    .end local v21    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v25, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v21, 0x0

    move-object/from16 v26, v22

    move-object/from16 v27, v23

    .end local v22    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v23    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v26, "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v27, "factory\\6":Lkotlin/jvm/functions/Function0;
    const-wide/16 v22, 0x0

    move-object/from16 v28, v24

    .end local v24    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v28, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v24, 0x0

    move-object/from16 v30, v25

    .end local v25    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v30, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v25, 0x0

    move-object/from16 v45, v26

    .end local v26    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v45, "materialized\\5":Landroidx/compose/ui/Modifier;
    const/16 v26, 0x1

    move-object/from16 v46, v27

    .end local v27    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v46, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v27, 0x0

    move-object/from16 v47, v28

    .end local v28    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v47, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v28, 0x0

    move-object/from16 v48, v30

    move-object/from16 v30, v2

    move-object/from16 v2, v48

    move-wide/from16 v48, v0

    move-object v0, v11

    move-object v1, v12

    move-wide/from16 v11, v48

    .end local v11    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v12    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v0, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .local v1, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v2, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v30, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v9 .. v33}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 159
    move-object/from16 v9, v30

    .end local v30    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\11":Landroidx/compose/runtime/Composer;
    sget-object v10, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v10, v9, v11}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v28

    sget-object v10, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v10, v9, v11}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v10

    and-int/lit8 v30, v38, 0xe

    const/16 v31, 0xc00

    const v32, 0xdffa

    move-object/from16 v29, v9

    .end local v9    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v29, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    const-wide/16 v12, 0x0

    const/4 v14, 0x0

    const-wide/16 v17, 0x0

    const/16 v19, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v25, 0x1

    const/16 v26, 0x0

    const/16 v27, 0x0

    invoke-static/range {v8 .. v32}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 158
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 160
    nop

    .line 694
    .end local v3    # "$changed\\11":I
    .end local v29    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v41    # "$i$a$-Column-HitchInspectorKt$Stat$1\\11\\694\\0":I
    .end local v42    # "$this$Stat_xqIIw2o_u24lambda_u2440\\11":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 693
    .end local v40    # "$changed\\10":I
    .end local v43    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v44    # "$i$a$-Layout-ColumnKt$Column$1\\10\\693\\4":I
    nop

    .line 695
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 672
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 696
    nop

    .line 666
    .end local v37    # "$i$f$ReusableComposeNode\\6\\670":I
    .end local v46    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .end local p4    # "$changed\\6":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 697
    nop

    .line 659
    .end local v2    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v34    # "$changed\\5":I
    .end local v35    # "$i$f$Layout\\5\\665":I
    .end local v36    # "compositeKeyHash\\5":I
    .end local v45    # "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 698
    nop

    .end local v0    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v1    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "$changed\\4":I
    .end local v6    # "$i$f$Column\\4\\157":I
    .end local v47    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local p3    # "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_15
    move-object/from16 v4, v39

    .end local v39    # "color":Landroidx/compose/ui/graphics/Color;
    .local v4, "color":Landroidx/compose/ui/graphics/Color;
    :goto_e
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_16

    new-instance v0, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda4;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/HitchInspectorKt$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;II)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 161
    :cond_16
    return-void
.end method

.method private static final Stat_xqIIw2o$lambda$41(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v7, p5

    move-object v5, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/HitchInspectorKt;->Stat-xqIIw2o(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final synthetic access$EventRow(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "event"    # Lorg/lighttouch/android/SlowEvent;
    .param p1, "start"    # J
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/HitchInspectorKt;->EventRow(Lorg/lighttouch/android/SlowEvent;JLandroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$InspectorBody(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "onSave"    # Lkotlin/jvm/functions/Function2;
    .param p2, "saving"    # Z
    .param p3, "savedNotice"    # Ljava/lang/String;
    .param p4, "onShare"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody(Lorg/lighttouch/android/HitchData;Lkotlin/jvm/functions/Function2;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$InspectorBody$lambda$37$lambda$29(Landroidx/compose/runtime/MutableState;)Z
    .locals 1
    .param p0, "$all$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/HitchInspectorKt;->InspectorBody$lambda$37$lambda$29(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$Message(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "body"    # Ljava/lang/String;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/HitchInspectorKt;->Message(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$frameColor(F)J
    .locals 2
    .param p0, "ms"    # F

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/HitchInspectorKt;->frameColor(F)J

    move-result-wide v0

    return-wide v0
.end method

.method public static final synthetic access$seconds(J)Ljava/lang/String;
    .locals 1
    .param p0, "ns"    # J

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/HitchInspectorKt;->seconds(J)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final frameColor(F)J
    .locals 2
    .param p0, "ms"    # F

    .line 29
    nop

    .line 30
    const/high16 v0, 0x42480000    # 50.0f

    cmpl-float v0, p0, v0

    if-lez v0, :cond_0

    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v0

    goto :goto_0

    .line 31
    :cond_0
    const/high16 v0, 0x41c80000    # 25.0f

    cmpl-float v0, p0, v0

    if-lez v0, :cond_1

    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v0

    goto :goto_0

    .line 32
    :cond_1
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getAccent-0d7_KjU()J

    move-result-wide v0

    .line 33
    :goto_0
    return-wide v0
.end method

.method private static final seconds(J)Ljava/lang/String;
    .locals 5
    .param p0, "ns"    # J

    .line 149
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    long-to-double v1, p0

    const-wide v3, 0x41cdcd6500000000L    # 1.0E9

    div-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.1f s"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

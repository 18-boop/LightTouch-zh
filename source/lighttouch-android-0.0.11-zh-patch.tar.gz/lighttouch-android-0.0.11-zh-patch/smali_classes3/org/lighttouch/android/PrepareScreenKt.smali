.class public final Lorg/lighttouch/android/PrepareScreenKt;
.super Ljava/lang/Object;
.source "PrepareScreen.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/PrepareScreenKt$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPrepareScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 9 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 10 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 11 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 12 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n*L\n1#1,416:1\n1225#2,6:417\n1225#2,6:423\n1225#2,6:429\n1225#2,6:555\n1225#2,6:571\n1225#2,6:592\n1225#2,6:598\n1225#2,6:775\n1225#2,6:787\n1225#2,6:833\n149#3:435\n149#3:436\n149#3:437\n149#3:438\n149#3:439\n149#3:476\n149#3:521\n149#3:522\n149#3:566\n149#3:570\n149#3:590\n149#3:604\n149#3:606\n149#3:607\n149#3:608\n149#3:609\n149#3:610\n149#3:611\n149#3:685\n149#3:686\n149#3:731\n149#3:736\n149#3:773\n149#3:774\n149#3:781\n149#3:782\n149#3:783\n149#3:784\n149#3:785\n149#3:786\n149#3:793\n149#3:794\n149#3:795\n99#4:440\n96#4,6:441\n102#4:475\n106#4:520\n99#4:648\n95#4,7:649\n102#4:684\n106#4:730\n99#4:796\n95#4,7:797\n102#4:832\n106#4:842\n79#5,6:447\n86#5,4:462\n90#5,2:472\n79#5,6:484\n86#5,4:499\n90#5,2:509\n94#5:515\n94#5:519\n79#5,6:619\n86#5,4:634\n90#5,2:644\n79#5,6:656\n86#5,4:671\n90#5,2:681\n79#5,6:694\n86#5,4:709\n90#5,2:719\n94#5:725\n94#5:729\n94#5:734\n79#5,6:744\n86#5,4:759\n90#5,2:769\n79#5,6:804\n86#5,4:819\n90#5,2:829\n94#5:841\n94#5:845\n368#6,9:453\n377#6:474\n368#6,9:490\n377#6:511\n378#6,2:513\n378#6,2:517\n368#6,9:625\n377#6:646\n368#6,9:662\n377#6:683\n368#6,9:700\n377#6:721\n378#6,2:723\n378#6,2:727\n378#6,2:732\n368#6,9:750\n377#6:771\n368#6,9:810\n377#6:831\n378#6,2:839\n378#6,2:843\n4034#7,6:466\n4034#7,6:503\n4034#7,6:638\n4034#7,6:675\n4034#7,6:713\n4034#7,6:763\n4034#7,6:823\n86#8:477\n83#8,6:478\n89#8:512\n93#8:516\n86#8:612\n83#8,6:613\n89#8:647\n86#8:687\n83#8,6:688\n89#8:722\n93#8:726\n93#8:735\n86#8:737\n83#8,6:738\n89#8:772\n93#8:846\n1491#9:523\n1516#9,3:524\n1519#9,3:534\n1056#9:537\n3307#9,4:538\n1761#9,3:542\n3311#9,6:545\n1056#9:551\n774#9:552\n865#9,2:553\n1788#9,4:561\n774#9:567\n865#9,2:568\n774#9:577\n865#9,2:578\n1788#9,4:580\n774#9:584\n865#9,2:585\n774#9:587\n865#9,2:588\n1056#9:591\n1563#9:847\n1634#9,3:848\n1563#9:851\n1634#9,3:852\n295#9,2:855\n384#10,7:527\n1#11:565\n77#12:605\n*S KotlinDebug\n*F\n+ 1 PrepareScreen.kt\norg/lighttouch/android/PrepareScreenKt\n*L\n97#1:417,6\n107#1:423,6\n108#1:429,6\n176#1:555,6\n198#1:571,6\n220#1:592,6\n225#1:598,6\n375#1:775,6\n398#1:787,6\n409#1:833,6\n134#1:435\n136#1:436\n141#1:437\n146#1:438\n147#1:439\n149#1:476\n166#1:521\n167#1:522\n182#1:566\n191#1:570\n216#1:590\n225#1:604\n240#1:606\n253#1:607\n327#1:608\n331#1:609\n333#1:610\n340#1:611\n342#1:685\n343#1:686\n351#1:731\n362#1:736\n366#1:773\n373#1:774\n377#1:781\n380#1:782\n385#1:783\n388#1:784\n393#1:785\n397#1:786\n403#1:793\n407#1:794\n408#1:795\n146#1:440\n146#1:441,6\n146#1:475\n146#1:520\n341#1:648\n341#1:649,7\n341#1:684\n341#1:730\n408#1:796\n408#1:797,7\n408#1:832\n408#1:842\n146#1:447,6\n146#1:462,4\n146#1:472,2\n150#1:484,6\n150#1:499,4\n150#1:509,2\n150#1:515\n146#1:519\n340#1:619,6\n340#1:634,4\n340#1:644,2\n341#1:656,6\n341#1:671,4\n341#1:681,2\n344#1:694,6\n344#1:709,4\n344#1:719,2\n344#1:725\n341#1:729\n340#1:734\n362#1:744,6\n362#1:759,4\n362#1:769,2\n408#1:804,6\n408#1:819,4\n408#1:829,2\n408#1:841\n362#1:845\n146#1:453,9\n146#1:474\n150#1:490,9\n150#1:511\n150#1:513,2\n146#1:517,2\n340#1:625,9\n340#1:646\n341#1:662,9\n341#1:683\n344#1:700,9\n344#1:721\n344#1:723,2\n341#1:727,2\n340#1:732,2\n362#1:750,9\n362#1:771\n408#1:810,9\n408#1:831\n408#1:839,2\n362#1:843,2\n146#1:466,6\n150#1:503,6\n340#1:638,6\n341#1:675,6\n344#1:713,6\n362#1:763,6\n408#1:823,6\n150#1:477\n150#1:478,6\n150#1:512\n150#1:516\n340#1:612\n340#1:613,6\n340#1:647\n344#1:687\n344#1:688,6\n344#1:722\n344#1:726\n340#1:735\n362#1:737\n362#1:738,6\n362#1:772\n362#1:846\n173#1:523\n173#1:524,3\n173#1:534,3\n173#1:537\n174#1:538,4\n174#1:542,3\n174#1:545,6\n175#1:551\n176#1:552\n176#1:553,2\n177#1:561,4\n185#1:567\n185#1:568,2\n209#1:577\n209#1:578,2\n210#1:580,4\n211#1:584\n211#1:585,2\n213#1:587\n213#1:588,2\n217#1:591\n73#1:847\n73#1:848,3\n74#1:851\n74#1:852,3\n74#1:855,2\n173#1:527,7\n238#1:605\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000f\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0013\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\r\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u001a\u0012\u0010\u0007\u001a\u00020\u00082\u0008\u0010\t\u001a\u0004\u0018\u00010\u0005H\u0002\u001a\u00b1\u0001\u0010\n\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0013\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0014\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0017\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0018\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u001a\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0012H\u0001\u00a2\u0006\u0002\u0010\u001c\u001a\u001d\u0010\u001d\u001a\u00020\u000b2\u0006\u0010\u001e\u001a\u00020\u00022\u0006\u0010\u001f\u001a\u00020\u0002H\u0003\u00a2\u0006\u0002\u0010 \u001a\u0015\u0010!\u001a\u00020\u000b2\u0006\u0010\"\u001a\u00020\u0002H\u0003\u00a2\u0006\u0002\u0010#\u001aQ\u0010$\u001a\u00020\u000b2\u0008\u0010%\u001a\u0004\u0018\u00010&2\u0006\u0010\u001e\u001a\u00020\u00022\u0006\u0010\u001f\u001a\u00020\u00022\u0006\u0010\'\u001a\u00020\u000f2\u0006\u0010(\u001a\u00020\u00022\n\u0008\u0002\u0010)\u001a\u0004\u0018\u00010*2\u000c\u0010+\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0012H\u0003\u00a2\u0006\u0002\u0010,\u001a\u0015\u0010-\u001a\u00020\u000b2\u0006\u0010.\u001a\u00020*H\u0003\u00a2\u0006\u0002\u0010/\u001a#\u00100\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u000c\u0010\u001a\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0012H\u0003\u00a2\u0006\u0002\u00101\u001a-\u00102\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u0006\u00103\u001a\u00020\u00022\u0006\u0010\u001f\u001a\u00020\u00022\u0006\u0010.\u001a\u00020*H\u0003\u00a2\u0006\u0002\u00104\u001a\u0015\u00105\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\rH\u0003\u00a2\u0006\u0002\u00106\u001a/\u00107\u001a\u00020\u000b*\u0002082\u0006\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u000c\u0010\u0017\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0012H\u0003\u00a2\u0006\u0002\u00109\u001a\u0010\u0010:\u001a\u00020\u00022\u0006\u0010\t\u001a\u00020\u0005H\u0002\u001ag\u0010;\u001a\u00020\u000b*\u0002082\u0006\u0010\u000c\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0013\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0014\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0012H\u0003\u00a2\u0006\u0002\u0010<\u001aK\u0010=\u001a\u00020\u000b2\u0006\u0010%\u001a\u00020&2\u0006\u0010\u001e\u001a\u00020\u00022\u0006\u0010>\u001a\u00020\u000f2\u0006\u0010\u001f\u001a\u00020\u00022\u001c\u0010?\u001a\u0018\u0012\u0004\u0012\u000208\u0012\u0004\u0012\u00020\u000b0@\u00a2\u0006\u0002\u0008A\u00a2\u0006\u0002\u0008BH\u0003\u00a2\u0006\u0002\u0010C\u001a]\u0010D\u001a\u00020\u000b2\u0006\u0010\u000c\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f2\u000c\u0010\u0016\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0018\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u00122\u000c\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\u000b0\u0012H\u0003\u00a2\u0006\u0002\u0010E\"\u0014\u0010\u0000\u001a\u0008\u0012\u0004\u0012\u00020\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u001e\u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u00050\u0004j\u0008\u0012\u0004\u0012\u00020\u0005`\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006F"
    }
    d2 = {
        "deviceOrder",
        "",
        "",
        "versionOrder",
        "Ljava/util/Comparator;",
        "Lorg/lighttouch/android/CatalogFirmware;",
        "Lkotlin/Comparator;",
        "preparationCost",
        "Lorg/lighttouch/android/PreparationCost;",
        "firmware",
        "PrepareScreen",
        "",
        "state",
        "Lorg/lighttouch/android/PrepareState;",
        "busy",
        "",
        "preparing",
        "onDownload",
        "Lkotlin/Function0;",
        "onChooseIpsw",
        "onChooseRom",
        "onDownloadRom",
        "onPrepare",
        "onChoosePrepared",
        "onCancel",
        "onRetryImport",
        "onAdvanced",
        "onClose",
        "(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "Heading",
        "title",
        "detail",
        "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "SectionLabel",
        "text",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "ChoiceRow",
        "icon",
        "Landroidx/compose/ui/graphics/vector/ImageVector;",
        "enabled",
        "tag",
        "badge",
        "Lorg/lighttouch/android/Support;",
        "onClick",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "SupportBadge",
        "support",
        "(Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V",
        "DeviceStep",
        "(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "DeviceRow",
        "product",
        "(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V",
        "VersionStep",
        "(Lorg/lighttouch/android/PrepareState;Landroidx/compose/runtime/Composer;I)V",
        "PreparedCopyStep",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "released",
        "FilesStep",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "Card",
        "done",
        "content",
        "Lkotlin/Function1;",
        "Landroidx/compose/runtime/Composable;",
        "Lkotlin/ExtensionFunctionType;",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V",
        "Progress",
        "(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final deviceOrder:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final versionOrder:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lorg/lighttouch/android/CatalogFirmware;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$-23IFsbjnVrNTPE_9_Jv-3-p16E(Lorg/lighttouch/android/Support;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/PrepareScreenKt;->SupportBadge$lambda$19(Lorg/lighttouch/android/Support;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$0GDTmKYnX3D_1SooXdgT4v986dA(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p16}, Lorg/lighttouch/android/PrepareScreenKt;->PrepareScreen$lambda$13(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4Mm54TNFjngcdzG_TXCS_C0kfMw(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceRow$lambda$38(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$CMZ20lUFcBBj0zLc83-PVE7l6Ac(Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt;->Progress$lambda$75$lambda$74$lambda$73$lambda$72(Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$DBrJz_j_IBstXfrB0G7jIfmG-jc(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/PrepareScreenKt;->PreparedCopyStep$lambda$50(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$F3ILCaHgLlTE0o-0TyJSfQa40Gc(Lorg/lighttouch/android/PrepareState;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/PrepareScreenKt;->VersionStep$lambda$48(Lorg/lighttouch/android/PrepareState;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FMKj4kT7kBVH8Eq5S2tJXzkdcp4(Lorg/lighttouch/android/PrepareState;Lorg/lighttouch/android/CatalogFirmware;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/PrepareScreenKt;->VersionStep$lambda$45$lambda$44(Lorg/lighttouch/android/PrepareState;Lorg/lighttouch/android/CatalogFirmware;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$I_HiP7DpNkhMhlsezdXiM2EvshI(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/PrepareScreenKt;->FilesStep$lambda$56(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$J9PWYPhoMtOnrSws9aIZwCLj04A(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceStep$lambda$29$lambda$28(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$R0upPe_jb3-yKB9K6e-hkKb7L_A(Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt;->PrepareScreen$lambda$10$lambda$9(Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UJiD8-7iADbrM85p8IPkdu60N9I(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/PrepareScreenKt;->Card$lambda$60(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UUVYwepGcuXpodLvOOcM3M-9CNQ(ZZLkotlin/jvm/functions/Function0;Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/PrepareScreenKt;->PrepareScreen$lambda$8$lambda$7(ZZLkotlin/jvm/functions/Function0;Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UVMp0qNyqOF88auraN3wMKLQvLg(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/PrepareScreenKt;->SectionLabel$lambda$15(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$iSRs-q58B_PQp3WLVEEAuYv57UQ(JJ)F
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/PrepareScreenKt;->Progress$lambda$75$lambda$66$lambda$65(JJ)F

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$kDQRNRD-7UtJb6pvJ6YVHLevn8s(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/PrepareScreenKt;->PreparedCopyStep$lambda$49(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$kpgbCyUU3oLchqTybPTkXDk-OYo(Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt;->VersionStep$lambda$47$lambda$46(Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$q7ufkbcNS5uUOy15gwGhjTrFHos(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p9}, Lorg/lighttouch/android/PrepareScreenKt;->Progress$lambda$76(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rrQxq4tBMfPsVE2Uv-WShNPmgig(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt;->PrepareScreen$lambda$12$lambda$11(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$sI1hWFIMX5Fv_-GAZhwDpwevCe0(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/PrepareScreenKt;->ChoiceRow$lambda$18(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$u4U1KHZ9q43Dh3rAqgUrFW3HUtY(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/PrepareScreenKt;->Heading$lambda$14(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$u5oSg4FTDrbR-aBDtiWeh3HWKgU(Lorg/lighttouch/android/CatalogFirmware;Lorg/lighttouch/android/CatalogFirmware;)I
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/PrepareScreenKt;->versionOrder$lambda$6(Lorg/lighttouch/android/CatalogFirmware;Lorg/lighttouch/android/CatalogFirmware;)I

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$uAOlT43uDdW6O4KnX2CT4FIUq_0(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceStep$lambda$35(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wI_I9rFlHmM659F-8rwHrG5wiJs(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceRow$lambda$37$lambda$36(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$zH4_UjRIdwmZev0k3Mv9GtAVvMw(F)F
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/PrepareScreenKt;->Progress$lambda$75$lambda$69$lambda$68(F)F

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$zxfALr3cKeSyJDJsgz2jU58fdZ4(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/PrepareScreenKt;->FilesStep$lambda$55(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 69
    const/16 v0, 0x9

    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "iPod1,1"

    aput-object v2, v0, v1

    const/4 v1, 0x1

    const-string v2, "iPod2,1"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "iPod3,1"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "iPod4,1"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "iPhone1,1"

    aput-object v2, v0, v1

    const/4 v1, 0x5

    const-string v2, "iPhone1,2"

    aput-object v2, v0, v1

    const/4 v1, 0x6

    const-string v2, "iPhone2,1"

    aput-object v2, v0, v1

    const/4 v1, 0x7

    const-string v2, "iPhone3,1"

    aput-object v2, v0, v1

    const/16 v1, 0x8

    const-string v2, "iPad1,1"

    aput-object v2, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/PrepareScreenKt;->deviceOrder:Ljava/util/List;

    .line 72
    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda18;

    invoke-direct {v0}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda18;-><init>()V

    sput-object v0, Lorg/lighttouch/android/PrepareScreenKt;->versionOrder:Ljava/util/Comparator;

    return-void
.end method

.method private static final Card(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V
    .locals 90
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "done"    # Z
    .param p3, "detail"    # Ljava/lang/String;
    .param p4, "content"    # Lkotlin/jvm/functions/Function3;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 339
    move/from16 v3, p2

    move-object/from16 v5, p4

    move/from16 v6, p6

    const v0, 0x714a8475

    move-object/from16 v1, p5

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(Card)P(3,4,2,1)339@22122L11,339@22009L913:PrepareScreen.kt#o13vsk"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p6

    .local v1, "$dirty":I
    and-int/lit8 v2, v6, 0x6

    if-nez v2, :cond_1

    move-object/from16 v8, p0

    invoke-interface {v7, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v1, v2

    goto :goto_1

    :cond_1
    move-object/from16 v8, p0

    :goto_1
    and-int/lit8 v2, v6, 0x30

    if-nez v2, :cond_3

    move-object/from16 v2, p1

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_2

    :cond_2
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v1, v4

    goto :goto_3

    :cond_3
    move-object/from16 v2, p1

    :goto_3
    and-int/lit16 v4, v6, 0x180

    if-nez v4, :cond_5

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v4

    if-eqz v4, :cond_4

    const/16 v4, 0x100

    goto :goto_4

    :cond_4
    const/16 v4, 0x80

    :goto_4
    or-int/2addr v1, v4

    :cond_5
    and-int/lit16 v4, v6, 0xc00

    if-nez v4, :cond_7

    move-object/from16 v4, p3

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_6

    const/16 v9, 0x800

    goto :goto_5

    :cond_6
    const/16 v9, 0x400

    :goto_5
    or-int/2addr v1, v9

    goto :goto_6

    :cond_7
    move-object/from16 v4, p3

    :goto_6
    and-int/lit16 v9, v6, 0x6000

    if-nez v9, :cond_9

    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    const/16 v9, 0x4000

    goto :goto_7

    :cond_8
    const/16 v9, 0x2000

    :goto_7
    or-int/2addr v1, v9

    :cond_9
    and-int/lit16 v9, v1, 0x2493

    const/16 v10, 0x2492

    if-ne v9, v10, :cond_b

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v9

    if-nez v9, :cond_a

    goto :goto_8

    .line 735
    :cond_a
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v43, v1

    goto/16 :goto_14

    .line 339
    :cond_b
    :goto_8
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v9

    if-eqz v9, :cond_c

    const/4 v9, -0x1

    const-string v10, "org.lighttouch.android.Card (PrepareScreen.kt:338)"

    invoke-static {v0, v1, v9, v10}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 340
    :cond_c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {v0, v9, v10, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v12, 0x6

    .local v12, "$this$dp\\1":I
    const/4 v13, 0x0

    .line 611
    .local v13, "$i$f$getDp\\1\\340":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 340
    .end local v12    # "$this$dp\\1":I
    .end local v13    # "$i$f$getDp\\1\\340":I
    invoke-static {v0, v9, v12, v10, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v9, 0x10

    .local v9, "$this$dp\\2":I
    const/4 v10, 0x0

    .line 611
    .local v10, "$i$f$getDp\\2\\340":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 340
    .end local v9    # "$this$dp\\2":I
    .end local v10    # "$i$f$getDp\\2\\340":I
    invoke-static {v9}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v9}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v7, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v11

    const/4 v14, 0x2

    const/4 v15, 0x0

    const/4 v13, 0x0

    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v9, 0x10

    .local v9, "$this$dp\\3":I
    const/4 v10, 0x0

    .line 611
    .local v10, "$i$f$getDp\\3\\340":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 340
    .end local v9    # "$this$dp\\3":I
    .end local v10    # "$i$f$getDp\\3\\340":I
    invoke-static {v0, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v9, 0x0

    .local v9, "$changed\\4":I
    move/from16 v33, v9

    .end local v9    # "$changed\\4":I
    .local v33, "$changed\\4":I
    const/16 v34, 0x0

    .line 612
    .local v34, "$i$f$Column\\4\\340":I
    const v9, -0x1cd0f17e

    const-string v10, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 613
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v11

    .line 614
    .local v11, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v12

    .line 617
    .local v12, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v13, v33, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v33, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v11, v12, v7, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v33, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 618
    move/from16 v35, v14

    .local v35, "$changed\\5":I
    const/16 v36, 0x0

    .line 619
    .local v36, "$i$f$Layout\\5\\618":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v7, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 620
    const/4 v9, 0x0

    invoke-static {v7, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v37

    .line 621
    .local v37, "compositeKeyHash\\5":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 622
    .local v9, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 624
    .local v14, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v38, v0

    .end local v0    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v38, "modifier\\4":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v35, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v19, v0

    const/4 v0, 0x6

    or-int/lit8 v19, v19, 0x6

    .line 623
    move-object/from16 v39, v18

    .local v39, "factory\\6":Lkotlin/jvm/functions/Function0;
    move/from16 v40, v19

    .local v40, "$changed\\6":I
    const/16 v41, 0x0

    .line 625
    .local v41, "$i$f$ReusableComposeNode\\6\\623":I
    move/from16 v42, v0

    const v0, -0x2942ffcf

    move/from16 v43, v1

    .end local v1    # "$dirty":I
    .local v43, "$dirty":I
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 626
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 627
    :cond_d
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 628
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 629
    move-object/from16 v0, v39

    .end local v39    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 631
    .end local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v39    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :cond_e
    move-object/from16 v0, v39

    .end local v39    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 633
    :goto_9
    move-object/from16 v39, v0

    .end local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v39    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 634
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\633\\5":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v13, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 635
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v9, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 637
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 638
    .local v20, "$i$f$set-impl\\8\\637":I
    move-object/from16 v21, v0

    .local v21, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 639
    .local v22, "$i$a$-with-Updater$set$1\\9\\638\\8":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_10

    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_f

    goto :goto_a

    :cond_f
    move-object/from16 v4, v21

    goto :goto_b

    .line 640
    :cond_10
    :goto_a
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 641
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 643
    :goto_b
    nop

    .line 638
    .end local v4    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\9\\638\\8":I
    nop

    .line 643
    nop

    .line 644
    .end local v2    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v20    # "$i$f$set-impl\\8\\637":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v14, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 645
    nop

    .line 633
    .end local v0    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\633\\5":I
    nop

    .line 646
    shr-int/lit8 v0, v40, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\10":I
    move-object v2, v7

    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 647
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\10\\646\\4":I
    const v4, -0x16ef5699

    move-object/from16 v19, v9

    .end local v9    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v19, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const-string v9, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v2, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v20, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v21, v33, 0x6

    and-int/lit8 v21, v21, 0x70

    or-int/lit8 v44, v21, 0x6

    .local v44, "$changed\\11":I
    move-object/from16 v4, v20

    check-cast v4, Landroidx/compose/foundation/layout/ColumnScope;

    .local v4, "$this$Card_u24lambda_u2459\\11":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v45, v2

    .local v45, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 341
    .local v46, "$i$a$-Column-PrepareScreenKt$Card$1\\11\\647\\0":I
    move/from16 v47, v0

    .end local v0    # "$changed\\10":I
    .local v47, "$changed\\10":I
    const v0, 0x2f50c282

    move-object/from16 v48, v2

    .end local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\10":Landroidx/compose/runtime/Composer;
    const-string v2, "C340@22178L682,350@22869L29,351@22907L9:PrepareScreen.kt#o13vsk"

    move-object/from16 v20, v9

    move-object/from16 v9, v45

    .end local v45    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v9, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v0

    .local v0, "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v2, 0x180

    .local v2, "$changed\\12":I
    const/16 v45, 0x0

    .line 648
    .local v45, "$i$f$Row\\12\\341":I
    move/from16 v49, v2

    .end local v2    # "$changed\\12":I
    .local v49, "$changed\\12":I
    const v2, 0x2952b718

    move/from16 v50, v3

    .end local v3    # "$i$a$-Layout-ColumnKt$Column$1\\10\\646\\4":I
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\10\\646\\4":I
    const-string v3, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v9, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 649
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    .line 650
    .local v2, "modifier\\12":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v3

    .line 654
    .local v3, "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v22, v49, 0x3

    and-int/lit8 v22, v22, 0xe

    shr-int/lit8 v23, v49, 0x3

    and-int/lit8 v23, v23, 0x70

    or-int v6, v22, v23

    invoke-static {v3, v0, v9, v6}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v22, v49, 0x3

    and-int/lit8 v22, v22, 0x70

    .line 655
    move/from16 v51, v22

    .local v51, "$changed\\13":I
    const/16 v52, 0x0

    .line 656
    .local v52, "$i$f$Layout\\13\\655":I
    move-object/from16 v53, v0

    const v0, -0x4ee9b9da

    .end local v0    # "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    .local v53, "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v9, v0, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 657
    const/4 v0, 0x0

    invoke-static {v9, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v54

    .line 658
    .local v54, "compositeKeyHash\\13":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 659
    .local v0, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v22, v15

    invoke-static {v9, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 661
    .local v15, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v55, v2

    .end local v2    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v55, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v51, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 660
    nop

    .local v2, "$changed\\14":I
    move-object/from16 v56, v23

    .local v56, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v57, 0x0

    .line 662
    .local v57, "$i$f$ReusableComposeNode\\14\\660":I
    move/from16 v58, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\14":I
    .local v58, "$changed\\14":I
    invoke-static {v9, v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 663
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 664
    :cond_11
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 665
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_12

    .line 666
    move-object/from16 v2, v56

    .end local v56    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 668
    .end local v2    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v56    # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v2, v56

    .end local v56    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 670
    :goto_c
    move-object/from16 v56, v2

    .end local v2    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v56    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 671
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\670\\13":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v59, v3

    .end local v3    # "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v59, "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 672
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v0, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 674
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 675
    .local v24, "$i$f$set-impl\\16\\674":I
    move-object/from16 v25, v2

    .local v25, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 676
    .local v26, "$i$a$-with-Updater$set$1\\17\\675\\16":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_14

    move-object/from16 v60, v0

    .end local v0    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v60, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v61, v6

    .end local v6    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v61, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_13

    goto :goto_d

    :cond_13
    move-object/from16 v6, v25

    goto :goto_e

    .end local v60    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v61    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v0    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_14
    move-object/from16 v60, v0

    move-object/from16 v61, v6

    .line 677
    .end local v0    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v60    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v61    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_d
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v6, v25

    .end local v25    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 678
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v2, v0, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 680
    :goto_e
    nop

    .line 675
    .end local v6    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\17\\675\\16":I
    nop

    .line 680
    nop

    .line 681
    .end local v3    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\16\\674":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v2, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 682
    nop

    .line 670
    .end local v2    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\670\\13":I
    nop

    .line 683
    shr-int/lit8 v0, v58, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\18":I
    move-object v2, v9

    .local v2, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 684
    .local v3, "$i$a$-Layout-RowKt$Row$1\\18\\683\\12":I
    const v6, -0x184f2606

    move/from16 v62, v0

    .end local v0    # "$changed\\18":I
    .local v62, "$changed\\18":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v49, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\19":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    move-object/from16 v23, v13

    .end local v13    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v0, "$this$Card_u24lambda_u2459_u24lambda_u2458\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v23, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    move-object v13, v2

    .local v13, "$composer\\19":Landroidx/compose/runtime/Composer;
    move-object/from16 v24, v0

    .end local v0    # "$this$Card_u24lambda_u2459_u24lambda_u2458\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v24, "$this$Card_u24lambda_u2459_u24lambda_u2458\\19":Landroidx/compose/foundation/layout/RowScope;
    const/4 v0, 0x0

    .line 342
    .local v0, "$i$a$-Row-PrepareScreenKt$Card$1$1\\19\\684\\11":I
    move/from16 v63, v0

    .end local v0    # "$i$a$-Row-PrepareScreenKt$Card$1$1\\19\\684\\11":I
    .local v63, "$i$a$-Row-PrepareScreenKt$Card$1$1\\19\\684\\11":I
    const v0, -0x38a62696

    move-object/from16 v64, v2

    .end local v2    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\18":Landroidx/compose/runtime/Composer;
    const-string v2, "C341@22244L138,342@22395L29,343@22437L309:PrepareScreen.kt#o13vsk"

    invoke-static {v13, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x18

    .local v2, "$this$dp\\20":I
    const/16 v25, 0x0

    .line 685
    .local v25, "$i$f$getDp\\20\\342":I
    move/from16 v65, v3

    .end local v3    # "$i$a$-Layout-RowKt$Row$1\\18\\683\\12":I
    .local v65, "$i$a$-Layout-RowKt$Row$1\\18\\683\\12":I
    int-to-float v3, v2

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 342
    .end local v2    # "$this$dp\\20":I
    .end local v25    # "$i$f$getDp\\20\\342":I
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    if-eqz p2, :cond_15

    const v2, -0x2b1e1a5e

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "341@22314L11"

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v13, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v2

    goto :goto_f

    :cond_15
    const v2, -0x2b1e1575

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "341@22353L11"

    invoke-static {v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v13, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v2

    :goto_f
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v25, v0

    and-int/lit8 v0, v43, 0xe

    or-int/lit16 v0, v0, 0x1b0

    move-object/from16 v26, v15

    .end local v15    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v26, "materialized\\13":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    move-object/from16 v27, v9

    .end local v9    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    move-object/from16 v69, v11

    move-object/from16 v70, v12

    move-object/from16 v67, v14

    move-object/from16 v66, v19

    move-object/from16 v73, v22

    move-object/from16 v71, v23

    move-object/from16 v68, v26

    move-object/from16 p5, v27

    move v14, v0

    move-wide v11, v2

    move-object v2, v10

    move-object/from16 v0, v20

    move-object/from16 v10, v25

    const v3, -0x1cd0f17e

    .end local v11    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v12    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v14    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v19    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v23    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v26    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .end local v27    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v66, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v67, "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v68, "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v69, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v70, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .local v71, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local p5, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v8 .. v15}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 343
    move-object v8, v13

    .end local v13    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\19":Landroidx/compose/runtime/Composer;
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x10

    .local v10, "$this$dp\\21":I
    const/4 v11, 0x0

    .line 686
    .local v11, "$i$f$getDp\\21\\343":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 343
    .end local v10    # "$this$dp\\21":I
    .end local v11    # "$i$f$getDp\\21\\343":I
    invoke-static {v9, v10}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v9

    move/from16 v10, v42

    invoke-static {v9, v8, v10}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 344
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v25, v9

    check-cast v25, Landroidx/compose/ui/Modifier;

    const/16 v28, 0x2

    const/16 v29, 0x0

    const/high16 v26, 0x3f800000    # 1.0f

    const/16 v27, 0x0

    invoke-static/range {v24 .. v29}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    move-object/from16 v75, v24

    .end local v24    # "$this$Card_u24lambda_u2459_u24lambda_u2458\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v9, "modifier\\22":Landroidx/compose/ui/Modifier;
    .local v75, "$this$Card_u24lambda_u2459_u24lambda_u2458\\19":Landroidx/compose/foundation/layout/RowScope;
    const/16 v76, 0x0

    .local v76, "$changed\\22":I
    const/16 v77, 0x0

    .line 687
    .local v77, "$i$f$Column\\22\\344":I
    invoke-static {v8, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 688
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v2

    .line 689
    .local v2, "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v3

    .line 692
    .local v3, "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v10, v76, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v76, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v2, v3, v8, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v76, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 693
    move/from16 v78, v11

    .local v78, "$changed\\23":I
    const/16 v79, 0x0

    .line 694
    .local v79, "$i$f$Layout\\23\\693":I
    move-object/from16 v11, v73

    const v12, -0x4ee9b9da

    invoke-static {v8, v12, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 695
    const/4 v11, 0x0

    invoke-static {v8, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v72

    .line 696
    .local v72, "compositeKeyHash\\23":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 697
    .local v11, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 699
    .local v12, "materialized\\23":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v78, 0x6

    and-int/lit16 v14, v14, 0x380

    const/16 v42, 0x6

    or-int/lit8 v14, v14, 0x6

    .line 698
    nop

    .local v13, "factory\\24":Lkotlin/jvm/functions/Function0;
    move/from16 v73, v14

    .local v73, "$changed\\24":I
    const/16 v74, 0x0

    .line 700
    .local v74, "$i$f$ReusableComposeNode\\24\\698":I
    const v14, -0x2942ffcf

    invoke-static {v8, v14, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 701
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 702
    :cond_16
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 703
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_17

    .line 704
    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 706
    :cond_17
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 708
    :goto_10
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 709
    .local v14, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\25\\708\\23":I
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    invoke-static {v1, v10, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 710
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    invoke-static {v1, v11, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 712
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    .local v15, "block\\26":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 713
    .local v16, "$i$f$set-impl\\26\\712":I
    move-object/from16 v17, v1

    .local v17, "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 714
    .local v18, "$i$a$-with-Updater$set$1\\27\\713\\26":I
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v19

    if-nez v19, :cond_19

    move-object/from16 v80, v2

    .end local v2    # "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v80, "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v81, v3

    .end local v3    # "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    .local v81, "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static/range {v72 .. v72}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_18

    goto :goto_11

    :cond_18
    move-object/from16 v3, v17

    goto :goto_12

    .end local v80    # "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v81    # "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v2    # "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v3    # "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_19
    move-object/from16 v80, v2

    move-object/from16 v81, v3

    .line 715
    .end local v2    # "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v3    # "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v80    # "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v81    # "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    :goto_11
    invoke-static/range {v72 .. v72}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v17

    .end local v17    # "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 716
    invoke-static/range {v72 .. v72}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v15}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 718
    :goto_12
    nop

    .line 713
    .end local v3    # "$this$set_impl_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-with-Updater$set$1\\27\\713\\26":I
    nop

    .line 718
    nop

    .line 719
    .end local v15    # "block\\26":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\26\\712":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v12, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 720
    nop

    .line 708
    .end local v1    # "$this$Layout_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\25\\708\\23":I
    nop

    .line 721
    shr-int/lit8 v1, v73, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\28":I
    move-object v2, v8

    .local v2, "$composer\\28":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 722
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\28\\721\\22":I
    const v14, -0x16ef5699

    invoke-static {v2, v14, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v14, v76, 0x6

    and-int/lit8 v14, v14, 0x70

    const/16 v42, 0x6

    or-int/lit8 v82, v14, 0x6

    .local v82, "$changed\\29":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$Card_u24lambda_u2459_u24lambda_u2458_u24lambda_u2457\\29":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v14, v2

    .local v14, "$composer\\29":Landroidx/compose/runtime/Composer;
    const/16 v83, 0x0

    .line 345
    .local v83, "$i$a$-Column-PrepareScreenKt$Card$1$1$1\\29\\722\\19":I
    const v15, 0x66b9e725

    move-object/from16 v84, v0

    .end local v0    # "$this$Card_u24lambda_u2459_u24lambda_u2458_u24lambda_u2457\\29":Landroidx/compose/foundation/layout/ColumnScope;
    .local v84, "$this$Card_u24lambda_u2459_u24lambda_u2458_u24lambda_u2457\\29":Landroidx/compose/foundation/layout/ColumnScope;
    const-string v0, "C344@22517L10,344@22483L56,345@22591L10,346@22703L11,345@22556L176:PrepareScreen.kt#o13vsk"

    invoke-static {v14, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v15, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v14, v15}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v28

    shr-int/lit8 v0, v43, 0x3

    and-int/lit8 v30, v0, 0xe

    const/16 v31, 0x0

    const v32, 0xfffe

    move-object v0, v9

    .end local v9    # "modifier\\22":Landroidx/compose/ui/Modifier;
    .local v0, "modifier\\22":Landroidx/compose/ui/Modifier;
    const/4 v9, 0x0

    move-object v15, v10

    move-object/from16 v16, v11

    .end local v10    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v11    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .local v15, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v16, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    const-wide/16 v10, 0x0

    move-object/from16 v17, v12

    move-object/from16 v18, v13

    .end local v12    # "materialized\\23":Landroidx/compose/ui/Modifier;
    .end local v13    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .local v17, "materialized\\23":Landroidx/compose/ui/Modifier;
    .local v18, "factory\\24":Lkotlin/jvm/functions/Function0;
    const-wide/16 v12, 0x0

    move-object/from16 v29, v14

    .end local v14    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .local v29, "$composer\\29":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    move-object/from16 v19, v15

    .end local v15    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v19, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v15, 0x0

    move-object/from16 v20, v16

    .end local v16    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .local v20, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v16, 0x0

    move-object/from16 v21, v17

    move-object/from16 v22, v18

    .end local v17    # "materialized\\23":Landroidx/compose/ui/Modifier;
    .end local v18    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .local v21, "materialized\\23":Landroidx/compose/ui/Modifier;
    .local v22, "factory\\24":Lkotlin/jvm/functions/Function0;
    const-wide/16 v17, 0x0

    move-object/from16 v23, v19

    .end local v19    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v23, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v19, 0x0

    move-object/from16 v24, v20

    .end local v20    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .local v24, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v20, 0x0

    move-object/from16 v25, v21

    move-object/from16 v26, v22

    .end local v21    # "materialized\\23":Landroidx/compose/ui/Modifier;
    .end local v22    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .local v25, "materialized\\23":Landroidx/compose/ui/Modifier;
    .local v26, "factory\\24":Lkotlin/jvm/functions/Function0;
    const-wide/16 v21, 0x0

    move-object/from16 v27, v23

    .end local v23    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v27, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v23, 0x0

    move-object/from16 v85, v24

    .end local v24    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .local v85, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v24, 0x0

    move-object/from16 v86, v25

    .end local v25    # "materialized\\23":Landroidx/compose/ui/Modifier;
    .local v86, "materialized\\23":Landroidx/compose/ui/Modifier;
    const/16 v25, 0x0

    move-object/from16 v87, v26

    .end local v26    # "factory\\24":Lkotlin/jvm/functions/Function0;
    .local v87, "factory\\24":Lkotlin/jvm/functions/Function0;
    const/16 v26, 0x0

    move-object/from16 v88, v27

    .end local v27    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v88, "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v27, 0x0

    move-object/from16 v89, v87

    move-object/from16 v87, v86

    move-object/from16 v86, v85

    move-object/from16 v85, v0

    move-object v0, v8

    move-object/from16 v8, p1

    .end local v8    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v85, "modifier\\22":Landroidx/compose/ui/Modifier;
    .local v86, "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .local v87, "materialized\\23":Landroidx/compose/ui/Modifier;
    .local v89, "factory\\24":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v8 .. v32}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 346
    move-object/from16 v8, v29

    .end local v29    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\29":Landroidx/compose/runtime/Composer;
    sget-object v9, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v9, v8, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v9

    invoke-virtual {v9}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v28

    sget-object v9, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v23

    .line 347
    sget-object v9, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v9, v8, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v9

    invoke-virtual {v9}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v10

    .line 346
    nop

    .line 347
    nop

    .line 346
    shr-int/lit8 v9, v43, 0x9

    and-int/lit8 v30, v9, 0xe

    const/16 v31, 0xc30

    const v32, 0xd7fa

    const/4 v9, 0x0

    const/16 v25, 0x2

    move-object/from16 v8, p3

    .end local v8    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$composer\\29":Landroidx/compose/runtime/Composer;
    invoke-static/range {v8 .. v32}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 345
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 348
    nop

    .line 722
    .end local v29    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .end local v82    # "$changed\\29":I
    .end local v83    # "$i$a$-Column-PrepareScreenKt$Card$1$1$1\\29\\722\\19":I
    .end local v84    # "$this$Card_u24lambda_u2459_u24lambda_u2458_u24lambda_u2457\\29":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 721
    .end local v1    # "$changed\\28":I
    .end local v2    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$a$-Layout-ColumnKt$Column$1\\28\\721\\22":I
    nop

    .line 723
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 700
    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 724
    nop

    .line 694
    .end local v73    # "$changed\\24":I
    .end local v74    # "$i$f$ReusableComposeNode\\24\\698":I
    .end local v89    # "factory\\24":Lkotlin/jvm/functions/Function0;
    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 725
    nop

    .line 687
    .end local v72    # "compositeKeyHash\\23":I
    .end local v78    # "$changed\\23":I
    .end local v79    # "$i$f$Layout\\23\\693":I
    .end local v86    # "localMap\\23":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v87    # "materialized\\23":Landroidx/compose/ui/Modifier;
    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 726
    nop

    .end local v76    # "$changed\\22":I
    .end local v77    # "$i$f$Column\\22\\344":I
    .end local v80    # "verticalArrangement\\22":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v81    # "horizontalAlignment\\22":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v85    # "modifier\\22":Landroidx/compose/ui/Modifier;
    .end local v88    # "measurePolicy\\22":Landroidx/compose/ui/layout/MeasurePolicy;
    const v1, -0x2b1de3ea

    invoke-interface {v0, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "348@22830L11,348@22769L81"

    invoke-static {v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 349
    if-eqz p2, :cond_1a

    sget-object v1, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v1}, Landroidx/compose/material/icons/filled/CheckCircleKt;->getCheckCircle(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v23

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v26

    const/16 v29, 0x30

    const/16 v30, 0x4

    const-string v24, "\u5c31\u7eea"

    const/16 v25, 0x0

    move-object/from16 v28, v0

    .end local v0    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v28, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v23 .. v30}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    goto :goto_13

    .end local v28    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v0    # "$composer\\19":Landroidx/compose/runtime/Composer;
    :cond_1a
    move-object/from16 v28, v0

    .end local v0    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v28    # "$composer\\19":Landroidx/compose/runtime/Composer;
    :goto_13
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 342
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 350
    nop

    .line 684
    .end local v6    # "$changed\\19":I
    .end local v28    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v63    # "$i$a$-Row-PrepareScreenKt$Card$1$1\\19\\684\\11":I
    .end local v75    # "$this$Card_u24lambda_u2459_u24lambda_u2458\\19":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 683
    .end local v62    # "$changed\\18":I
    .end local v64    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v65    # "$i$a$-Layout-RowKt$Row$1\\18\\683\\12":I
    nop

    .line 727
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 662
    invoke-static/range {p5 .. p5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 728
    nop

    .line 656
    .end local v56    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .end local v57    # "$i$f$ReusableComposeNode\\14\\660":I
    .end local v58    # "$changed\\14":I
    invoke-static/range {p5 .. p5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 729
    nop

    .line 648
    .end local v51    # "$changed\\13":I
    .end local v52    # "$i$f$Layout\\13\\655":I
    .end local v54    # "compositeKeyHash\\13":I
    .end local v60    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v68    # "materialized\\13":Landroidx/compose/ui/Modifier;
    invoke-static/range {p5 .. p5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 730
    nop

    .line 351
    .end local v45    # "$i$f$Row\\12\\341":I
    .end local v49    # "$changed\\12":I
    .end local v53    # "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    .end local v55    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v59    # "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v61    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\30":I
    const/4 v2, 0x0

    .line 731
    .local v2, "$i$f$getDp\\30\\351":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 351
    .end local v1    # "$this$dp\\30":I
    .end local v2    # "$i$f$getDp\\30\\351":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object/from16 v9, p5

    const/4 v10, 0x6

    .end local p5    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v0, v9, v10}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 352
    and-int/lit8 v0, v44, 0xe

    shr-int/lit8 v1, v43, 0x9

    and-int/lit8 v1, v1, 0x70

    or-int/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v5, v4, v9, v0}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 341
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 353
    nop

    .line 647
    .end local v4    # "$this$Card_u24lambda_u2459\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v9    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v44    # "$changed\\11":I
    .end local v46    # "$i$a$-Column-PrepareScreenKt$Card$1\\11\\647\\0":I
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 646
    .end local v47    # "$changed\\10":I
    .end local v48    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-ColumnKt$Column$1\\10\\646\\4":I
    nop

    .line 732
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 625
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 733
    nop

    .line 619
    .end local v39    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .end local v40    # "$changed\\6":I
    .end local v41    # "$i$f$ReusableComposeNode\\6\\623":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 734
    nop

    .line 612
    .end local v35    # "$changed\\5":I
    .end local v36    # "$i$f$Layout\\5\\618":I
    .end local v37    # "compositeKeyHash\\5":I
    .end local v66    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v67    # "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 735
    nop

    .end local v33    # "$changed\\4":I
    .end local v34    # "$i$f$Column\\4\\340":I
    .end local v38    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v69    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v70    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v71    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1b
    :goto_14
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_1c

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda19;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda19;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;I)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 354
    :cond_1c
    return-void
.end method

.method private static final Card$lambda$60(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/PrepareScreenKt;->Card(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .locals 68
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "detail"    # Ljava/lang/String;
    .param p3, "enabled"    # Z
    .param p4, "tag"    # Ljava/lang/String;
    .param p5, "badge"    # Lorg/lighttouch/android/Support;
    .param p6, "onClick"    # Lkotlin/jvm/functions/Function0;
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/Support;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    .line 145
    move-object/from16 v0, p0

    move/from16 v2, p3

    move-object/from16 v8, p4

    move/from16 v9, p8

    const v1, 0x1690b40c

    move-object/from16 v3, p7

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(ChoiceRow)P(3,6,1,2,5)145@8269L11,145@8159L751:PrepareScreen.kt#o13vsk"

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p8

    .local v3, "$dirty":I
    and-int/lit8 v4, p9, 0x1

    if-eqz v4, :cond_0

    or-int/lit8 v3, v3, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v4, v9, 0x6

    if-nez v4, :cond_2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v3, v4

    :cond_2
    :goto_1
    and-int/lit8 v4, p9, 0x2

    if-eqz v4, :cond_3

    or-int/lit8 v3, v3, 0x30

    move-object/from16 v11, p1

    goto :goto_3

    :cond_3
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_5

    move-object/from16 v11, p1

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    const/16 v4, 0x20

    goto :goto_2

    :cond_4
    const/16 v4, 0x10

    :goto_2
    or-int/2addr v3, v4

    goto :goto_3

    :cond_5
    move-object/from16 v11, p1

    :goto_3
    and-int/lit8 v4, p9, 0x4

    if-eqz v4, :cond_6

    or-int/lit16 v3, v3, 0x180

    move-object/from16 v12, p2

    goto :goto_5

    :cond_6
    and-int/lit16 v4, v9, 0x180

    if-nez v4, :cond_8

    move-object/from16 v12, p2

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_7

    const/16 v4, 0x100

    goto :goto_4

    :cond_7
    const/16 v4, 0x80

    :goto_4
    or-int/2addr v3, v4

    goto :goto_5

    :cond_8
    move-object/from16 v12, p2

    :goto_5
    and-int/lit8 v4, p9, 0x8

    if-eqz v4, :cond_9

    or-int/lit16 v3, v3, 0xc00

    goto :goto_7

    :cond_9
    and-int/lit16 v4, v9, 0xc00

    if-nez v4, :cond_b

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v4

    if-eqz v4, :cond_a

    const/16 v4, 0x800

    goto :goto_6

    :cond_a
    const/16 v4, 0x400

    :goto_6
    or-int/2addr v3, v4

    :cond_b
    :goto_7
    and-int/lit8 v4, p9, 0x10

    if-eqz v4, :cond_c

    or-int/lit16 v3, v3, 0x6000

    goto :goto_9

    :cond_c
    and-int/lit16 v4, v9, 0x6000

    if-nez v4, :cond_e

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d

    const/16 v4, 0x4000

    goto :goto_8

    :cond_d
    const/16 v4, 0x2000

    :goto_8
    or-int/2addr v3, v4

    :cond_e
    :goto_9
    and-int/lit8 v4, p9, 0x20

    const/4 v5, -0x1

    const/high16 v6, 0x30000

    if-eqz v4, :cond_f

    :goto_a
    or-int/2addr v3, v6

    goto :goto_c

    :cond_f
    and-int/2addr v6, v9

    if-nez v6, :cond_12

    if-nez p5, :cond_10

    move v6, v5

    goto :goto_b

    :cond_10
    move-object/from16 v6, p5

    check-cast v6, Ljava/lang/Enum;

    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    :goto_b
    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_11

    const/high16 v6, 0x20000

    goto :goto_a

    :cond_11
    const/high16 v6, 0x10000

    goto :goto_a

    :cond_12
    :goto_c
    and-int/lit8 v6, p9, 0x40

    const/high16 v7, 0x180000

    if-eqz v6, :cond_13

    or-int/2addr v3, v7

    move-object/from16 v7, p6

    goto :goto_e

    :cond_13
    and-int v6, v9, v7

    if-nez v6, :cond_15

    move-object/from16 v7, p6

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_14

    const/high16 v6, 0x100000

    goto :goto_d

    :cond_14
    const/high16 v6, 0x80000

    :goto_d
    or-int/2addr v3, v6

    goto :goto_e

    :cond_15
    move-object/from16 v7, p6

    :goto_e
    move v13, v3

    .end local v3    # "$dirty":I
    .local v13, "$dirty":I
    const v3, 0x92493

    and-int/2addr v3, v13

    const v6, 0x92492

    if-ne v3, v6, :cond_17

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_16

    goto :goto_f

    .line 520
    :cond_16
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v6, p5

    move/from16 v66, v13

    goto/16 :goto_19

    .line 145
    :cond_17
    :goto_f
    if-eqz v4, :cond_18

    const/4 v3, 0x0

    move-object v14, v3

    .end local p5    # "badge":Lorg/lighttouch/android/Support;
    .local v3, "badge":Lorg/lighttouch/android/Support;
    goto :goto_10

    .end local v3    # "badge":Lorg/lighttouch/android/Support;
    .restart local p5    # "badge":Lorg/lighttouch/android/Support;
    :cond_18
    move-object/from16 v14, p5

    .end local p5    # "badge":Lorg/lighttouch/android/Support;
    .local v14, "badge":Lorg/lighttouch/android/Support;
    :goto_10
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_19

    const-string v3, "org.lighttouch.android.ChoiceRow (PrepareScreen.kt:144)"

    invoke-static {v1, v13, v5, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 146
    :cond_19
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v6, 0x4

    .local v6, "$this$dp\\1":I
    const/4 v15, 0x0

    .line 438
    .local v15, "$i$f$getDp\\1\\146":I
    int-to-float v3, v6

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 146
    .end local v6    # "$this$dp\\1":I
    .end local v15    # "$i$f$getDp\\1\\146":I
    const/4 v6, 0x0

    invoke-static {v1, v6, v3, v4, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v3, 0x10

    .local v3, "$this$dp\\2":I
    const/4 v4, 0x0

    .line 438
    .local v4, "$i$f$getDp\\2\\146":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 146
    .end local v3    # "$this$dp\\2":I
    .end local v4    # "$i$f$getDp\\2\\146":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v3}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v10, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v16

    const/16 v19, 0x2

    const/16 v20, 0x0

    const/16 v18, 0x0

    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 147
    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object/from16 v5, p6

    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    if-eqz p3, :cond_1a

    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_11

    :cond_1a
    const v2, 0x3ee66666    # 0.45f

    :goto_11
    invoke-static {v1, v2}, Landroidx/compose/ui/draw/AlphaKt;->alpha(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x10

    .local v2, "$this$dp\\3":I
    const/4 v3, 0x0

    .line 439
    .local v3, "$i$f$getDp\\3\\147":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 147
    .end local v2    # "$this$dp\\3":I
    .end local v3    # "$i$f$getDp\\3\\147":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 148
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v2

    .line 146
    const/16 v3, 0x180

    move/from16 v36, v3

    .local v36, "$changed\\4":I
    move-object v15, v2

    .local v1, "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v15, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v37, 0x0

    .line 440
    .local v37, "$i$f$Row\\4\\146":I
    const v2, 0x2952b718

    const-string v3, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v10, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 441
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v2

    .line 445
    .local v2, "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v3, v36, 0x3

    and-int/lit8 v3, v3, 0xe

    shr-int/lit8 v4, v36, 0x3

    and-int/lit8 v4, v4, 0x70

    or-int/2addr v3, v4

    invoke-static {v2, v15, v10, v3}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .local v3, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v4, v36, 0x3

    and-int/lit8 v4, v4, 0x70

    .line 446
    move/from16 v38, v4

    .local v38, "$changed\\5":I
    const/16 v39, 0x0

    .line 447
    .local v39, "$i$f$Layout\\5\\446":I
    const v4, -0x4ee9b9da

    const-string v5, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 448
    const/4 v6, 0x0

    invoke-static {v10, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v40

    .line 449
    .local v40, "compositeKeyHash\\5":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 450
    .local v7, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 452
    .local v12, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v4, v38, 0x6

    and-int/lit16 v4, v4, 0x380

    move-object/from16 p7, v1

    .end local v1    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local p7, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x6

    or-int/2addr v4, v1

    .line 451
    move/from16 v41, v4

    .local v41, "$changed\\6":I
    move-object/from16 v4, v16

    .local v4, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v42, 0x0

    .line 453
    .local v42, "$i$f$ReusableComposeNode\\6\\451":I
    move/from16 v16, v1

    const v1, -0x2942ffcf

    const-string v6, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v1, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 454
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_1b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 455
    :cond_1b
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 456
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 457
    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_12

    .line 459
    :cond_1c
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 461
    :goto_12
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 462
    .local v6, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\461\\5":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 463
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 465
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 466
    .local v18, "$i$f$set-impl\\8\\465":I
    move-object/from16 v19, v1

    .local v19, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 467
    .local v20, "$i$a$-with-Updater$set$1\\9\\466\\8":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v21

    if-nez v21, :cond_1e

    move-object/from16 v21, v2

    .end local v2    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v21, "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v22, v3

    .end local v3    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v22, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1d

    goto :goto_13

    :cond_1d
    move-object/from16 v3, v19

    goto :goto_14

    .end local v21    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v22    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v3    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_1e
    move-object/from16 v21, v2

    move-object/from16 v22, v3

    .line 468
    .end local v2    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v3    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v21    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v22    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_13
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v19

    .end local v19    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 469
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 471
    :goto_14
    nop

    .line 466
    .end local v3    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-with-Updater$set$1\\9\\466\\8":I
    nop

    .line 471
    nop

    .line 472
    .end local v0    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\8\\465":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 473
    nop

    .line 461
    .end local v1    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\461\\5":I
    nop

    .line 474
    shr-int/lit8 v0, v41, 0x6

    and-int/lit8 v43, v0, 0xe

    .local v43, "$changed\\10":I
    move-object v0, v10

    .local v0, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v44, 0x0

    .line 475
    .local v44, "$i$a$-Layout-RowKt$Row$1\\10\\474\\4":I
    const v1, -0x184f2606

    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v2, v36, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v45, v2, 0x6

    .local v45, "$changed\\11":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    move-object v2, v5

    .local v1, "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    move-object v5, v0

    .local v5, "$composer\\11":Landroidx/compose/runtime/Composer;
    move-object/from16 v23, v1

    .end local v1    # "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    .local v23, "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    const/16 v46, 0x0

    .line 149
    .local v46, "$i$a$-Row-PrepareScreenKt$ChoiceRow$1\\11\\475\\0":I
    const v1, 0x7e8b6e58

    const-string v3, "C149@8627L230:PrepareScreen.kt#o13vsk"

    invoke-static {v5, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v1, -0x42d0e13

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "148@8565L11,148@8505L80,148@8587L29"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-eqz p0, :cond_1f

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x1a

    .local v3, "$this$dp\\12":I
    const/4 v6, 0x0

    .line 476
    .local v6, "$i$f$getDp\\12\\149":I
    move-object/from16 v18, v0

    .end local v0    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v18, "$composer\\10":Landroidx/compose/runtime/Composer;
    int-to-float v0, v3

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 149
    .end local v3    # "$this$dp\\12":I
    .end local v6    # "$i$f$getDp\\12\\149":I
    invoke-static {v1, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v19

    and-int/lit8 v1, v13, 0xe

    or-int/lit16 v6, v1, 0x1b0

    move-object v1, v7

    .end local v7    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v1, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v7, 0x0

    move-object v3, v1

    .end local v1    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v3, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v1, 0x0

    move-object/from16 v47, p7

    move-object v8, v2

    move-object/from16 v50, v3

    move-object/from16 v51, v4

    move/from16 v9, v16

    move-object/from16 v52, v18

    move-wide/from16 v3, v19

    move-object/from16 v48, v21

    move-object/from16 v49, v22

    move-object v2, v0

    move-object/from16 v0, p0

    .end local v3    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .end local v18    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v21    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v22    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local p7    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v47, "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v48, "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v49, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v50, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v51, "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v52, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v7}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x10

    .local v1, "$this$dp\\13":I
    const/4 v2, 0x0

    .line 476
    .local v2, "$i$f$getDp\\13\\149":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 149
    .end local v1    # "$this$dp\\13":I
    .end local v2    # "$i$f$getDp\\13\\149":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {v0, v5, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    goto :goto_15

    .end local v47    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v48    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v49    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v50    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v51    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .end local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v0    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v4    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v21    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v22    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local p7    # "modifier\\4":Landroidx/compose/ui/Modifier;
    :cond_1f
    move-object/from16 v47, p7

    move-object/from16 v52, v0

    move-object v8, v2

    move-object/from16 v51, v4

    move-object/from16 v50, v7

    move/from16 v9, v16

    move-object/from16 v48, v21

    move-object/from16 v49, v22

    .end local v0    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v4    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .end local v7    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v21    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v22    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local p7    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .restart local v47    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .restart local v48    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v49    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v50    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v51    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :goto_15
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 150
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v24, v0

    check-cast v24, Landroidx/compose/ui/Modifier;

    const/16 v27, 0x2

    const/16 v28, 0x0

    const/high16 v25, 0x3f800000    # 1.0f

    const/16 v26, 0x0

    invoke-static/range {v23 .. v28}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move-object/from16 v1, v23

    .end local v23    # "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    .local v0, "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v1, "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    const/4 v2, 0x0

    .local v2, "$changed\\14":I
    const/4 v3, 0x0

    .line 477
    .local v3, "$i$f$Column\\14\\150":I
    const v4, -0x1cd0f17e

    const-string v6, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v5, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 478
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 479
    .local v4, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .line 482
    .local v6, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v7, v2, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v16, v2, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v7, v7, v16

    invoke-static {v4, v6, v5, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .local v7, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v2, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 483
    move/from16 v53, v16

    .local v53, "$changed\\15":I
    const/16 v54, 0x0

    .line 484
    .local v54, "$i$f$Layout\\15\\483":I
    move/from16 v16, v9

    const v9, -0x4ee9b9da

    invoke-static {v5, v9, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 485
    const/4 v8, 0x0

    invoke-static {v5, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v8

    .line 486
    .local v8, "compositeKeyHash\\15":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 487
    .local v9, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 p5, v12

    .end local v12    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local p5, "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v5, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 489
    .local v12, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 p7, v0

    .end local v0    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local p7, "modifier\\14":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v53, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 488
    move-object/from16 v55, v17

    .local v0, "$changed\\16":I
    .local v55, "factory\\16":Lkotlin/jvm/functions/Function0;
    const/16 v56, 0x0

    .line 490
    .local v56, "$i$f$ReusableComposeNode\\16\\488":I
    move/from16 v57, v0

    .end local v0    # "$changed\\16":I
    .local v57, "$changed\\16":I
    const v0, -0x2942ffcf

    move-object/from16 v58, v1

    .end local v1    # "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    .local v58, "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v5, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 491
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_20

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 492
    :cond_20
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 493
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_21

    .line 494
    move-object/from16 v0, v55

    .end local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_16

    .line 496
    .end local v0    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :cond_21
    move-object/from16 v0, v55

    .end local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 498
    :goto_16
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 499
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\498\\15":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v55, v0

    .end local v0    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 500
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 502
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 503
    .local v18, "$i$f$set-impl\\18\\502":I
    move-object/from16 v19, v1

    .local v19, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 504
    .local v20, "$i$a$-with-Updater$set$1\\19\\503\\18":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v21

    if-nez v21, :cond_23

    move/from16 v59, v2

    .end local v2    # "$changed\\14":I
    .local v59, "$changed\\14":I
    invoke-interface/range {v19 .. v19}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v60, v3

    .end local v3    # "$i$f$Column\\14\\150":I
    .local v60, "$i$f$Column\\14\\150":I
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_22

    goto :goto_17

    :cond_22
    move-object/from16 v3, v19

    goto :goto_18

    .end local v59    # "$changed\\14":I
    .end local v60    # "$i$f$Column\\14\\150":I
    .restart local v2    # "$changed\\14":I
    .restart local v3    # "$i$f$Column\\14\\150":I
    :cond_23
    move/from16 v59, v2

    move/from16 v60, v3

    .line 505
    .end local v2    # "$changed\\14":I
    .end local v3    # "$i$f$Column\\14\\150":I
    .restart local v59    # "$changed\\14":I
    .restart local v60    # "$i$f$Column\\14\\150":I
    :goto_17
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v19

    .end local v19    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 506
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 508
    :goto_18
    nop

    .line 503
    .end local v3    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-with-Updater$set$1\\19\\503\\18":I
    nop

    .line 508
    nop

    .line 509
    .end local v0    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\18\\502":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 510
    nop

    .line 498
    .end local v1    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\498\\15":I
    nop

    .line 511
    shr-int/lit8 v0, v57, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\20":I
    move-object v1, v5

    .local v1, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 512
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\20\\511\\14":I
    const v3, -0x16ef5699

    move/from16 v61, v0

    .end local v0    # "$changed\\20":I
    .local v61, "$changed\\20":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v59, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\21":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$ChoiceRow_u24lambda_u2417_u24lambda_u2416\\21":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v32, v1

    .local v32, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/16 v62, 0x0

    .line 151
    .local v62, "$i$a$-Column-PrepareScreenKt$ChoiceRow$1$1\\21\\512\\11":I
    move-object/from16 v63, v0

    .end local v0    # "$this$ChoiceRow_u24lambda_u2417_u24lambda_u2416\\21":Landroidx/compose/foundation/layout/ColumnScope;
    .local v63, "$this$ChoiceRow_u24lambda_u2417_u24lambda_u2416\\21":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x78361d9f

    move-object/from16 v64, v1

    .end local v1    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\20":Landroidx/compose/runtime/Composer;
    const-string v1, "C150@8703L10,150@8669L57,151@8774L10,151@8818L11,151@8739L108:PrepareScreen.kt#o13vsk"

    move/from16 v65, v2

    move-object/from16 v2, v32

    .end local v32    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v65, "$i$a$-Layout-ColumnKt$Column$1\\20\\511\\14":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v31

    shr-int/lit8 v0, v13, 0x3

    and-int/lit8 v33, v0, 0xe

    const/16 v34, 0x0

    const v35, 0xfffe

    move-object v0, v12

    .end local v12    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v0, "materialized\\15":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move v1, v13

    move-object/from16 v16, v14

    .end local v13    # "$dirty":I
    .end local v14    # "badge":Lorg/lighttouch/android/Support;
    .local v1, "$dirty":I
    .local v16, "badge":Lorg/lighttouch/android/Support;
    const-wide/16 v13, 0x0

    move-object/from16 v17, v15

    move-object/from16 v18, v16

    .end local v15    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .end local v16    # "badge":Lorg/lighttouch/android/Support;
    .local v17, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v18, "badge":Lorg/lighttouch/android/Support;
    const-wide/16 v15, 0x0

    move-object/from16 v19, v17

    .end local v17    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v19, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v17, 0x0

    move-object/from16 v20, v18

    .end local v18    # "badge":Lorg/lighttouch/android/Support;
    .local v20, "badge":Lorg/lighttouch/android/Support;
    const/16 v18, 0x0

    move-object/from16 v21, v19

    .end local v19    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v21, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v19, 0x0

    move-object/from16 v23, v20

    move-object/from16 v22, v21

    .end local v20    # "badge":Lorg/lighttouch/android/Support;
    .end local v21    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v22, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v23, "badge":Lorg/lighttouch/android/Support;
    const-wide/16 v20, 0x0

    move-object/from16 v24, v22

    .end local v22    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v24, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v22, 0x0

    move-object/from16 v25, v23

    .end local v23    # "badge":Lorg/lighttouch/android/Support;
    .local v25, "badge":Lorg/lighttouch/android/Support;
    const/16 v23, 0x0

    move-object/from16 v26, v24

    move-object/from16 v27, v25

    .end local v24    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .end local v25    # "badge":Lorg/lighttouch/android/Support;
    .local v26, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v27, "badge":Lorg/lighttouch/android/Support;
    const-wide/16 v24, 0x0

    move-object/from16 v28, v26

    .end local v26    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v28, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v26, 0x0

    move-object/from16 v29, v27

    .end local v27    # "badge":Lorg/lighttouch/android/Support;
    .local v29, "badge":Lorg/lighttouch/android/Support;
    const/16 v27, 0x0

    move-object/from16 v30, v28

    .end local v28    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v30, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v28, 0x0

    move-object/from16 v32, v29

    .end local v29    # "badge":Lorg/lighttouch/android/Support;
    .local v32, "badge":Lorg/lighttouch/android/Support;
    const/16 v29, 0x0

    move-object/from16 v66, v30

    .end local v30    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v66, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v30, 0x0

    move/from16 v67, v1

    move-object v1, v0

    move-object/from16 v0, v32

    move-object/from16 v32, v2

    move-object/from16 v2, v66

    move/from16 v66, v67

    .local v0, "badge":Lorg/lighttouch/android/Support;
    .local v1, "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v2, "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .local v32, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v66, "$dirty":I
    invoke-static/range {v11 .. v35}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 152
    move-object/from16 v11, v32

    .end local v32    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\21":Landroidx/compose/runtime/Composer;
    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v31

    sget-object v12, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v13, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v12, v11, v13}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v12

    invoke-virtual {v12}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v13

    shr-int/lit8 v12, v66, 0x6

    and-int/lit8 v33, v12, 0xe

    const v35, 0xfffa

    const/4 v12, 0x0

    move-object/from16 v11, p2

    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v32    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v35}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 151
    invoke-static/range {v32 .. v32}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 153
    nop

    .line 512
    .end local v3    # "$changed\\21":I
    .end local v32    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v62    # "$i$a$-Column-PrepareScreenKt$ChoiceRow$1$1\\21\\512\\11":I
    .end local v63    # "$this$ChoiceRow_u24lambda_u2417_u24lambda_u2416\\21":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 511
    .end local v61    # "$changed\\20":I
    .end local v64    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v65    # "$i$a$-Layout-ColumnKt$Column$1\\20\\511\\14":I
    nop

    .line 513
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 490
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 514
    nop

    .line 484
    .end local v55    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v56    # "$i$f$ReusableComposeNode\\16\\488":I
    .end local v57    # "$changed\\16":I
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 515
    nop

    .line 477
    .end local v1    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v8    # "compositeKeyHash\\15":I
    .end local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v53    # "$changed\\15":I
    .end local v54    # "$i$f$Layout\\15\\483":I
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 516
    nop

    .end local v4    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v6    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v7    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v59    # "$changed\\14":I
    .end local v60    # "$i$f$Column\\14\\150":I
    .end local p7    # "modifier\\14":Landroidx/compose/ui/Modifier;
    const v1, -0x42cded2

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "153@8885L19"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 154
    if-eqz v0, :cond_24

    shr-int/lit8 v1, v66, 0xf

    and-int/lit8 v1, v1, 0xe

    invoke-static {v0, v5, v1}, Lorg/lighttouch/android/PrepareScreenKt;->SupportBadge(Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V

    :cond_24
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 149
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 155
    nop

    .line 475
    .end local v5    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v45    # "$changed\\11":I
    .end local v46    # "$i$a$-Row-PrepareScreenKt$ChoiceRow$1\\11\\475\\0":I
    .end local v58    # "$this$ChoiceRow_u24lambda_u2417\\11":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 474
    .end local v43    # "$changed\\10":I
    .end local v44    # "$i$a$-Layout-RowKt$Row$1\\10\\474\\4":I
    .end local v52    # "$composer\\10":Landroidx/compose/runtime/Composer;
    nop

    .line 517
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 453
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 518
    nop

    .line 447
    .end local v41    # "$changed\\6":I
    .end local v42    # "$i$f$ReusableComposeNode\\6\\451":I
    .end local v51    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 519
    nop

    .line 440
    .end local v38    # "$changed\\5":I
    .end local v39    # "$i$f$Layout\\5\\446":I
    .end local v40    # "compositeKeyHash\\5":I
    .end local v50    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local p5    # "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 520
    nop

    .end local v2    # "verticalAlignment\\4":Landroidx/compose/ui/Alignment$Vertical;
    .end local v36    # "$changed\\4":I
    .end local v37    # "$i$f$Row\\4\\146":I
    .end local v47    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v48    # "horizontalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v49    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_25

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_25
    move-object v6, v0

    .end local v0    # "badge":Lorg/lighttouch/android/Support;
    .local v6, "badge":Lorg/lighttouch/android/Support;
    :goto_19
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_26

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda22;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v7, p6

    move/from16 v8, p8

    move/from16 v9, p9

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda22;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;II)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 156
    :cond_26
    return-void
.end method

.method private static final ChoiceRow$lambda$18(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move/from16 v10, p8

    move-object/from16 v8, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/PrepareScreenKt;->ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeviceRow(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V
    .locals 16
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "product"    # Ljava/lang/String;
    .param p2, "detail"    # Ljava/lang/String;
    .param p3, "support"    # Lorg/lighttouch/android/Support;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    .line 197
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v5, p5

    const v0, 0x20b5dd3c

    move-object/from16 v3, p4

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(DeviceRow)P(2,1)197@11652L158,197@11498L312:PrepareScreen.kt#o13vsk"

    invoke-static {v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p5

    .local v3, "$dirty":I
    and-int/lit8 v4, v5, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-nez v4, :cond_1

    invoke-interface {v13, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    move v4, v6

    goto :goto_0

    :cond_0
    move v4, v7

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v5, 0x30

    const/16 v8, 0x20

    if-nez v4, :cond_3

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v8

    goto :goto_1

    :cond_2
    const/16 v4, 0x10

    :goto_1
    or-int/2addr v3, v4

    :cond_3
    and-int/lit16 v4, v5, 0x180

    if-nez v4, :cond_5

    move-object/from16 v4, p2

    invoke-interface {v13, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_4

    const/16 v9, 0x100

    goto :goto_2

    :cond_4
    const/16 v9, 0x80

    :goto_2
    or-int/2addr v3, v9

    goto :goto_3

    :cond_5
    move-object/from16 v4, p2

    :goto_3
    and-int/lit16 v9, v5, 0xc00

    if-nez v9, :cond_7

    move-object/from16 v9, p3

    check-cast v9, Ljava/lang/Enum;

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    invoke-interface {v13, v9}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    if-eqz v9, :cond_6

    const/16 v9, 0x800

    goto :goto_4

    :cond_6
    const/16 v9, 0x400

    :goto_4
    or-int/2addr v3, v9

    :cond_7
    and-int/lit16 v9, v3, 0x493

    const/16 v10, 0x492

    if-ne v9, v10, :cond_9

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v9

    if-nez v9, :cond_8

    goto :goto_5

    .line 198
    :cond_8
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_a

    .line 197
    :cond_9
    :goto_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v9

    if-eqz v9, :cond_a

    const/4 v9, -0x1

    const-string v10, "org.lighttouch.android.DeviceRow (PrepareScreen.kt:196)"

    invoke-static {v0, v3, v9, v10}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 198
    :cond_a
    const-string v0, "iPad"

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v2, v0, v10, v7, v9}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getTablet()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    goto :goto_6

    :cond_b
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getPhone()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    :goto_6
    invoke-static {v2}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "prepare_device_"

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const v11, -0x615d173a

    invoke-interface {v13, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "CC(remember):PrepareScreen.kt#9igjgp"

    invoke-static {v13, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v11, v3, 0xe

    const/4 v12, 0x1

    if-ne v11, v6, :cond_c

    move v6, v12

    goto :goto_7

    :cond_c
    move v6, v10

    :goto_7
    and-int/lit8 v11, v3, 0x70

    if-ne v11, v8, :cond_d

    move v10, v12

    :cond_d
    or-int/2addr v6, v10

    .local v6, "invalid\\1":Z
    move-object v8, v13

    .local v8, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 571
    .local v10, "$i$f$cache\\1\\198":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 572
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\571\\1":I
    if-nez v6, :cond_f

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v11, v14, :cond_e

    goto :goto_8

    .line 576
    :cond_e
    move-object v15, v11

    goto :goto_9

    .line 573
    :cond_f
    :goto_8
    const/4 v14, 0x0

    .line 198
    .local v14, "$i$a$-cache-PrepareScreenKt$DeviceRow$1\\3\\573\\0":I
    new-instance v15, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda15;

    invoke-direct {v15, v1, v2}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda15;-><init>(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;)V

    .line 573
    .end local v14    # "$i$a$-cache-PrepareScreenKt$DeviceRow$1\\3\\573\\0":I
    nop

    .line 574
    .local v15, "value\\2":Ljava/lang/Object;
    invoke-interface {v8, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 575
    nop

    .line 572
    .end local v15    # "value\\2":Ljava/lang/Object;
    :goto_9
    nop

    .line 571
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\571\\1":I
    nop

    .line 198
    .end local v6    # "invalid\\1":Z
    .end local v8    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\1\\198":I
    move-object v12, v15

    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit16 v6, v3, 0x380

    or-int/lit16 v6, v6, 0xc00

    const/high16 v8, 0x70000

    shl-int/lit8 v10, v3, 0x6

    and-int/2addr v8, v10

    or-int v14, v6, v8

    const/4 v15, 0x0

    move-object v10, v9

    const/4 v9, 0x1

    move-object/from16 v11, p3

    move-object v6, v0

    move-object v8, v4

    invoke-static/range {v6 .. v15}, Lorg/lighttouch/android/PrepareScreenKt;->ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_10
    :goto_a
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_11

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda16;

    move-object/from16 v4, p3

    move v7, v3

    move-object/from16 v3, p2

    .end local v3    # "$dirty":I
    .local v7, "$dirty":I
    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda16;-><init>(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;I)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_b

    .end local v7    # "$dirty":I
    .restart local v3    # "$dirty":I
    :cond_11
    move v7, v3

    .line 203
    .end local v3    # "$dirty":I
    .restart local v7    # "$dirty":I
    :goto_b
    return-void
.end method

.method private static final DeviceRow$lambda$37$lambda$36(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "$product"    # Ljava/lang/String;

    .line 199
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/PrepareState;->setProductType(Ljava/lang/String;)V

    .line 200
    invoke-virtual {p0}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, ""

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/PrepareState;->setFirmwareId(Ljava/lang/String;)V

    .line 201
    :cond_1
    sget-object v0, Lorg/lighttouch/android/PrepareStep;->VERSION:Lorg/lighttouch/android/PrepareStep;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/PrepareState;->setStep(Lorg/lighttouch/android/PrepareStep;)V

    .line 202
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeviceRow$lambda$38(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceRow(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final DeviceStep(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 42
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "onAdvanced"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/PrepareState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 171
    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move/from16 v13, p3

    const v1, 0x6d28af2b

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(DeviceStep)P(1)171@9584L93,190@11224L158:PrepareScreen.kt#o13vsk"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v3, v13, 0x6

    if-nez v3, :cond_1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v13, 0x30

    if-nez v3, :cond_3

    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    move v7, v2

    .end local v2    # "$dirty":I
    .local v7, "$dirty":I
    and-int/lit8 v2, v7, 0x13

    const/16 v3, 0x12

    if-ne v2, v3, :cond_5

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_4

    goto :goto_2

    .line 191
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v14, v0

    move-object v0, v6

    move v15, v7

    goto/16 :goto_16

    .line 171
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_6

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.DeviceStep (PrepareScreen.kt:170)"

    invoke-static {v1, v7, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 172
    :cond_6
    const-string v1, "\u9009\u62e9\u8981\u6a21\u62df\u7684\u8bbe\u5907\uff0c\u4e0b\u4e00\u6b65\u518d\u9009 iOS \u7248\u672c\u3002"

    const/16 v2, 0x36

    const-string v3, "\u9009\u62e9\u8bbe\u5907"

    invoke-static {v3, v1, v4, v2}, Lorg/lighttouch/android/PrepareScreenKt;->Heading(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 173
    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getCatalog()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$groupBy\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 523
    .local v2, "$i$f$groupBy\\1\\173":I
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v3, Ljava/util/Map;

    .local v3, "destination\\2":Ljava/util/Map;
    move-object v5, v1

    .local v5, "$this$groupByTo\\2":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 524
    .local v8, "$i$f$groupByTo\\2\\523":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_8

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 525
    .local v10, "element\\2":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/lighttouch/android/CatalogFirmware;

    .local v11, "it\\5":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v12, 0x0

    .line 173
    .local v12, "$i$a$-groupBy-PrepareScreenKt$DeviceStep$devices$1\\5\\525\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v11

    .line 525
    .end local v11    # "it\\5":Lorg/lighttouch/android/CatalogFirmware;
    .end local v12    # "$i$a$-groupBy-PrepareScreenKt$DeviceStep$devices$1\\5\\525\\0":I
    nop

    .line 526
    .local v11, "key\\2":Ljava/lang/Object;
    move-object v12, v3

    .local v12, "$this$getOrPut\\3":Ljava/util/Map;
    const/4 v14, 0x0

    .line 527
    .local v14, "$i$f$getOrPut\\3\\526":I
    invoke-interface {v12, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    .line 528
    .local v15, "value\\3":Ljava/lang/Object;
    if-nez v15, :cond_7

    .line 529
    const/16 v16, 0x0

    .line 526
    .local v16, "$i$a$-getOrPut-CollectionsKt___CollectionsKt$groupByTo$list$1\\4\\529\\2":I
    new-instance v17, Ljava/util/ArrayList;

    invoke-direct/range {v17 .. v17}, Ljava/util/ArrayList;-><init>()V

    check-cast v17, Ljava/util/List;

    .line 529
    .end local v16    # "$i$a$-getOrPut-CollectionsKt___CollectionsKt$groupByTo$list$1\\4\\529\\2":I
    move-object/from16 p2, v17

    .line 530
    .local p2, "answer\\3":Ljava/lang/Object;
    move-object/from16 v0, p2

    .end local p2    # "answer\\3":Ljava/lang/Object;
    .local v0, "answer\\3":Ljava/lang/Object;
    invoke-interface {v12, v11, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 531
    nop

    .end local v0    # "answer\\3":Ljava/lang/Object;
    goto :goto_4

    .line 533
    :cond_7
    move-object v0, v15

    .line 528
    :goto_4
    nop

    .line 526
    .end local v12    # "$this$getOrPut\\3":Ljava/util/Map;
    .end local v14    # "$i$f$getOrPut\\3\\526":I
    .end local v15    # "value\\3":Ljava/lang/Object;
    check-cast v0, Ljava/util/List;

    .line 534
    .local v0, "list\\2":Ljava/util/List;
    invoke-interface {v0, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, p0

    .end local v0    # "list\\2":Ljava/util/List;
    .end local v11    # "key\\2":Ljava/lang/Object;
    goto :goto_3

    .line 536
    .end local v10    # "element\\2":Ljava/lang/Object;
    :cond_8
    nop

    .line 523
    .end local v3    # "destination\\2":Ljava/util/Map;
    .end local v5    # "$this$groupByTo\\2":Ljava/lang/Iterable;
    .end local v8    # "$i$f$groupByTo\\2\\523":I
    nop

    .line 173
    .end local v1    # "$this$groupBy\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$groupBy\\1\\173":I
    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$sortedBy\\6":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 537
    .local v1, "$i$f$sortedBy\\6\\173":I
    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$DeviceStep$$inlined$sortedBy$1;

    invoke-direct {v2}, Lorg/lighttouch/android/PrepareScreenKt$DeviceStep$$inlined$sortedBy$1;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .line 173
    .end local v0    # "$this$sortedBy\\6":Ljava/lang/Iterable;
    .end local v1    # "$i$f$sortedBy\\6\\173":I
    move-object/from16 v39, v0

    .line 174
    .local v39, "devices":Ljava/util/List;
    move-object/from16 v0, v39

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$partition\\7":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 538
    .local v1, "$i$f$partition\\7\\174":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 539
    .local v2, "first\\7":Ljava/util/ArrayList;
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 540
    .local v3, "second\\7":Ljava/util/ArrayList;
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_5
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v9, 0x1

    if-eqz v8, :cond_d

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 541
    .local v8, "element\\7":Ljava/lang/Object;
    move-object v11, v8

    check-cast v11, Ljava/util/Map$Entry;

    const/4 v12, 0x0

    .local v12, "$i$a$-partition-PrepareScreenKt$DeviceStep$1\\8\\541\\0":I
    invoke-interface {v11}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/List;

    .line 174
    .local v11, "firmwares\\8":Ljava/util/List;
    move-object v14, v11

    check-cast v14, Ljava/lang/Iterable;

    .local v14, "$this$any\\9":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 542
    .local v15, "$i$f$any\\9\\174":I
    instance-of v10, v14, Ljava/util/Collection;

    if-eqz v10, :cond_9

    move-object v10, v14

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_9

    const/4 v9, 0x0

    goto :goto_6

    .line 543
    :cond_9
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_a
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .local v16, "element\\9":Ljava/lang/Object;
    move-object/from16 v17, v16

    check-cast v17, Lorg/lighttouch/android/CatalogFirmware;

    .local v17, "it\\10":Lorg/lighttouch/android/CatalogFirmware;
    const/16 v18, 0x0

    .line 174
    .local v18, "$i$a$-any-PrepareScreenKt$DeviceStep$1$1\\10\\543\\8":I
    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Lorg/lighttouch/android/Support;->getTested()Z

    move-result v17

    .line 543
    .end local v17    # "it\\10":Lorg/lighttouch/android/CatalogFirmware;
    .end local v18    # "$i$a$-any-PrepareScreenKt$DeviceStep$1$1\\10\\543\\8":I
    if-eqz v17, :cond_a

    goto :goto_6

    .line 544
    .end local v16    # "element\\9":Ljava/lang/Object;
    :cond_b
    const/4 v9, 0x0

    .line 174
    .end local v14    # "$this$any\\9":Ljava/lang/Iterable;
    .end local v15    # "$i$f$any\\9\\174":I
    :goto_6
    nop

    .line 541
    .end local v11    # "firmwares\\8":Ljava/util/List;
    .end local v12    # "$i$a$-partition-PrepareScreenKt$DeviceStep$1\\8\\541\\0":I
    if-eqz v9, :cond_c

    .line 545
    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7

    .line 547
    :cond_c
    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_7
    goto :goto_5

    .line 550
    .end local v8    # "element\\7":Ljava/lang/Object;
    :cond_d
    new-instance v5, Lkotlin/Pair;

    invoke-direct {v5, v2, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 174
    .end local v0    # "$this$partition\\7":Ljava/lang/Iterable;
    .end local v1    # "$i$f$partition\\7\\174":I
    .end local v2    # "first\\7":Ljava/util/ArrayList;
    .end local v3    # "second\\7":Ljava/util/ArrayList;
    invoke-virtual {v5}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v40, v0

    check-cast v40, Ljava/util/List;

    .local v40, "tested":Ljava/util/List;
    invoke-virtual {v5}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v41, v0

    check-cast v41, Ljava/util/List;

    .local v41, "others":Ljava/util/List;
    const v0, -0x3a463830

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "*175@10134L21,177@10249L125"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 175
    move-object/from16 v0, v40

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$sortedBy\\11":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 551
    .local v1, "$i$f$sortedBy\\11\\175":I
    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$DeviceStep$$inlined$sortedBy$2;

    invoke-direct {v2}, Lorg/lighttouch/android/PrepareScreenKt$DeviceStep$$inlined$sortedBy$2;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .line 175
    .end local v0    # "$this$sortedBy\\11":Ljava/lang/Iterable;
    .end local v1    # "$i$f$sortedBy\\11\\175":I
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_8
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .local v1, "product":Ljava/lang/String;
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Ljava/util/List;

    .line 176
    .local v10, "firmwares":Ljava/util/List;
    move-object v0, v10

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\12":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 552
    .local v2, "$i$f$filter\\12\\176":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\13":Ljava/util/Collection;
    move-object v5, v0

    .local v5, "$this$filterTo\\13":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 553
    .local v11, "$i$f$filterTo\\13\\552":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_e
    :goto_9
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_f

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\13":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Lorg/lighttouch/android/CatalogFirmware;

    .local v15, "it\\14":Lorg/lighttouch/android/CatalogFirmware;
    const/16 v16, 0x0

    .line 176
    .local v16, "$i$a$-filter-PrepareScreenKt$DeviceStep$versions$1\\14\\553\\0":I
    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Lorg/lighttouch/android/Support;->getTested()Z

    move-result v15

    .line 553
    .end local v15    # "it\\14":Lorg/lighttouch/android/CatalogFirmware;
    .end local v16    # "$i$a$-filter-PrepareScreenKt$DeviceStep$versions$1\\14\\553\\0":I
    if-eqz v15, :cond_e

    invoke-interface {v3, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_9

    .line 554
    .end local v14    # "element\\13":Ljava/lang/Object;
    :cond_f
    nop

    .end local v3    # "destination\\13":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\13":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filterTo\\13\\552":I
    check-cast v3, Ljava/util/List;

    .line 552
    nop

    .end local v0    # "$this$filter\\12":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\12\\176":I
    check-cast v3, Ljava/lang/Iterable;

    .line 176
    sget-object v0, Lorg/lighttouch/android/PrepareScreenKt;->versionOrder:Ljava/util/Comparator;

    invoke-static {v3, v0}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Ljava/lang/Iterable;

    const-string v0, ", "

    move-object v15, v0

    check-cast v15, Ljava/lang/CharSequence;

    const v0, 0x6e3c21fe

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):PrepareScreen.kt#9igjgp"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\15":Z
    move-object v2, v4

    .local v2, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 555
    .local v3, "$i$f$cache\\15\\176":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\15":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 556
    .local v11, "$i$a$-let-ComposerKt$cache$1\\16\\555\\15":I
    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v5, v12, :cond_10

    .line 557
    const/4 v12, 0x0

    .local v12, "$i$a$-cache-PrepareScreenKt$DeviceStep$versions$2\\17\\557\\0":I
    new-instance v16, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda13;

    invoke-direct/range {v16 .. v16}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda13;-><init>()V

    .end local v12    # "$i$a$-cache-PrepareScreenKt$DeviceStep$versions$2\\17\\557\\0":I
    move-object/from16 v12, v16

    .line 558
    .local v12, "value\\16":Ljava/lang/Object;
    invoke-interface {v2, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 559
    nop

    .end local v12    # "value\\16":Ljava/lang/Object;
    goto :goto_a

    .line 560
    :cond_10
    move-object v12, v5

    .line 556
    :goto_a
    nop

    .line 555
    .end local v5    # "it\\15":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\16\\555\\15":I
    nop

    .line 176
    .end local v0    # "invalid\\15":Z
    .end local v2    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\15\\176":I
    move-object/from16 v20, v12

    check-cast v20, Lkotlin/jvm/functions/Function1;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v21, 0x1e

    const/16 v22, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    invoke-static/range {v14 .. v22}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    .line 177
    .local v11, "versions":Ljava/lang/String;
    move-object v0, v10

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$count\\18":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 561
    .local v2, "$i$f$count\\18\\177":I
    instance-of v3, v0, Ljava/util/Collection;

    if-eqz v3, :cond_11

    move-object v3, v0

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_11

    const/4 v3, 0x0

    goto :goto_e

    .line 562
    :cond_11
    const/4 v3, 0x0

    .line 563
    .local v3, "count\\18":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_12
    :goto_b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_15

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\18":Ljava/lang/Object;
    move-object v14, v12

    check-cast v14, Lorg/lighttouch/android/CatalogFirmware;

    .local v14, "it\\19":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v15, 0x0

    .line 177
    .local v15, "$i$a$-count-PrepareScreenKt$DeviceStep$more$1\\19\\563\\0":I
    invoke-virtual {v14}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Lorg/lighttouch/android/Support;->getTested()Z

    move-result v16

    if-nez v16, :cond_14

    invoke-virtual {v14}, Lorg/lighttouch/android/CatalogFirmware;->getPrerelease()Ljava/lang/String;

    move-result-object v16

    check-cast v16, Ljava/lang/CharSequence;

    invoke-interface/range {v16 .. v16}, Ljava/lang/CharSequence;->length()I

    move-result v16

    if-nez v16, :cond_13

    move/from16 v16, v9

    goto :goto_c

    :cond_13
    const/16 v16, 0x0

    :goto_c
    if-eqz v16, :cond_14

    move v14, v9

    goto :goto_d

    :cond_14
    const/4 v14, 0x0

    .line 563
    .end local v14    # "it\\19":Lorg/lighttouch/android/CatalogFirmware;
    .end local v15    # "$i$a$-count-PrepareScreenKt$DeviceStep$more$1\\19\\563\\0":I
    :goto_d
    if-eqz v14, :cond_12

    add-int/lit8 v3, v3, 0x1

    if-gez v3, :cond_12

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v12    # "element\\18":Ljava/lang/Object;
    goto :goto_b

    .line 564
    :cond_15
    nop

    .line 177
    .end local v0    # "$this$count\\18":Ljava/lang/Iterable;
    .end local v2    # "$i$f$count\\18\\177":I
    .end local v3    # "count\\18":I
    :goto_e
    move v12, v3

    .line 178
    .local v12, "more":I
    if-lez v12, :cond_16

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " \u00b7 "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u4e2a\u53ef\u5c1d\u8bd5"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_16
    const-string v0, ""

    :goto_f
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u5df2\u6d4b\u8bd5\uff1a"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object v0, v10

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_19

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/lighttouch/android/CatalogFirmware;

    .line 565
    .local v3, "it\\20":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v5, 0x0

    .line 178
    .local v5, "$i$a$-minOf-PrepareScreenKt$DeviceStep$3\\20\\178\\0":I
    invoke-virtual {v3}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v3

    .end local v3    # "it\\20":Lorg/lighttouch/android/CatalogFirmware;
    .end local v5    # "$i$a$-minOf-PrepareScreenKt$DeviceStep$3\\20\\178\\0":I
    check-cast v3, Ljava/lang/Comparable;

    :cond_17
    :goto_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_18

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lorg/lighttouch/android/CatalogFirmware;

    .line 565
    .local v5, "it\\21":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v14, 0x0

    .line 178
    .local v14, "$i$a$-minOf-PrepareScreenKt$DeviceStep$3\\21\\178\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v5

    .end local v5    # "it\\21":Lorg/lighttouch/android/CatalogFirmware;
    .end local v14    # "$i$a$-minOf-PrepareScreenKt$DeviceStep$3\\21\\178\\0":I
    check-cast v5, Ljava/lang/Comparable;

    invoke-interface {v3, v5}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    move-result v14

    if-lez v14, :cond_17

    move-object v3, v5

    goto :goto_10

    :cond_18
    check-cast v3, Lorg/lighttouch/android/Support;

    and-int/lit8 v5, v7, 0xe

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceRow(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V

    .end local v1    # "product":Ljava/lang/String;
    .end local v10    # "firmwares":Ljava/util/List;
    .end local v11    # "versions":Ljava/lang/String;
    .end local v12    # "more":I
    goto/16 :goto_8

    .restart local v1    # "product":Ljava/lang/String;
    .restart local v10    # "firmwares":Ljava/util/List;
    .restart local v11    # "versions":Ljava/lang/String;
    .restart local v12    # "more":I
    :cond_19
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0

    .end local v1    # "product":Ljava/lang/String;
    .end local v10    # "firmwares":Ljava/util/List;
    .end local v11    # "versions":Ljava/lang/String;
    .end local v12    # "more":I
    :cond_1a
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v0, -0x3a45fde4

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "180@10420L44,182@10610L10,182@10654L11,181@10473L210,*186@11026L64"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 180
    move-object/from16 v0, v41

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_23

    .line 181
    const-string v0, "\u5c1a\u672a\u5728 LightTouch \u4e0a\u6d4b\u8bd5"

    const/4 v1, 0x6

    invoke-static {v0, v4, v1}, Lorg/lighttouch/android/PrepareScreenKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 182
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v14, v0

    check-cast v14, Landroidx/compose/ui/Modifier;

    const/4 v0, 0x6

    .local v0, "$this$dp\\22":I
    const/4 v1, 0x0

    .line 566
    .local v1, "$i$f$getDp\\22\\182":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v18

    .line 182
    .end local v0    # "$this$dp\\22":I
    .end local v1    # "$i$f$getDp\\22\\182":I
    const/16 v19, 0x7

    const/16 v20, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-static/range {v14 .. v20}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 183
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v34

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v16

    .line 182
    nop

    .line 183
    nop

    .line 182
    const-string v14, "\u8fd9\u4e9b\u7248\u672c\u53ef\u80fd\u65e0\u6cd5\u542f\u52a8\u6216\u65e0\u6cd5\u5b8c\u5168\u6b63\u5e38\u5de5\u4f5c\uff0c\u53ef\u81ea\u884c\u5c1d\u8bd5\u3002"

    const-wide/16 v18, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const-wide/16 v23, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v36, 0x36

    const/16 v37, 0x0

    const v38, 0xfff8

    move-object/from16 v35, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v35, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v14 .. v38}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 184
    .end local v35    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v41 .. v41}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_11
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .local v1, "product":Ljava/lang/String;
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Ljava/util/List;

    .line 185
    .restart local v10    # "firmwares":Ljava/util/List;
    move-object v0, v10

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\23":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 567
    .local v2, "$i$f$filter\\23\\185":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\24":Ljava/util/Collection;
    move-object v5, v0

    .local v5, "$this$filterTo\\24":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 568
    .local v11, "$i$f$filterTo\\24\\567":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_1b
    :goto_12
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_1d

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\24":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Lorg/lighttouch/android/CatalogFirmware;

    .local v15, "it\\25":Lorg/lighttouch/android/CatalogFirmware;
    const/16 v16, 0x0

    .line 185
    .local v16, "$i$a$-filter-PrepareScreenKt$DeviceStep$sorted$1\\25\\568\\0":I
    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getPrerelease()Ljava/lang/String;

    move-result-object v17

    check-cast v17, Ljava/lang/CharSequence;

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->length()I

    move-result v17

    if-nez v17, :cond_1c

    move/from16 v17, v9

    goto :goto_13

    :cond_1c
    const/16 v17, 0x0

    .line 568
    .end local v15    # "it\\25":Lorg/lighttouch/android/CatalogFirmware;
    .end local v16    # "$i$a$-filter-PrepareScreenKt$DeviceStep$sorted$1\\25\\568\\0":I
    :goto_13
    if-eqz v17, :cond_1b

    invoke-interface {v3, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_12

    .line 569
    .end local v14    # "element\\24":Ljava/lang/Object;
    :cond_1d
    nop

    .end local v3    # "destination\\24":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\24":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filterTo\\24\\567":I
    check-cast v3, Ljava/util/List;

    .line 567
    nop

    .end local v0    # "$this$filter\\23":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\23\\185":I
    check-cast v3, Ljava/lang/Iterable;

    .line 185
    sget-object v0, Lorg/lighttouch/android/PrepareScreenKt;->versionOrder:Ljava/util/Comparator;

    invoke-static {v3, v0}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1e

    .line 565
    const/4 v0, 0x0

    .line 185
    .local v0, "$i$a$-ifEmpty-PrepareScreenKt$DeviceStep$sorted$2\\26\\185\\0":I
    move-object v2, v10

    check-cast v2, Ljava/lang/Iterable;

    sget-object v3, Lorg/lighttouch/android/PrepareScreenKt;->versionOrder:Ljava/util/Comparator;

    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .end local v0    # "$i$a$-ifEmpty-PrepareScreenKt$DeviceStep$sorted$2\\26\\185\\0":I
    :cond_1e
    move-object v11, v0

    check-cast v11, Ljava/util/List;

    .line 186
    .local v11, "sorted":Ljava/util/List;
    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v0

    const-string v2, "iOS "

    if-ne v0, v9, :cond_1f

    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/CatalogFirmware;

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    goto :goto_14

    :cond_1f
    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/CatalogFirmware;

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getVersion()Ljava/lang/String;

    move-result-object v0

    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/lighttouch/android/CatalogFirmware;

    invoke-virtual {v3}, Lorg/lighttouch/android/CatalogFirmware;->getVersion()Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " to "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    :goto_14
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v2, v0

    .line 187
    .local v2, "range":Ljava/lang/String;
    move-object v0, v10

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_22

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/lighttouch/android/CatalogFirmware;

    .line 565
    .local v3, "it\\27":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v5, 0x0

    .line 187
    .local v5, "$i$a$-minOf-PrepareScreenKt$DeviceStep$4\\27\\187\\0":I
    invoke-virtual {v3}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v3

    .end local v3    # "it\\27":Lorg/lighttouch/android/CatalogFirmware;
    .end local v5    # "$i$a$-minOf-PrepareScreenKt$DeviceStep$4\\27\\187\\0":I
    check-cast v3, Ljava/lang/Comparable;

    :cond_20
    :goto_15
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_21

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lorg/lighttouch/android/CatalogFirmware;

    .line 565
    .local v5, "it\\28":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v12, 0x0

    .line 187
    .local v12, "$i$a$-minOf-PrepareScreenKt$DeviceStep$4\\28\\187\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v5

    .end local v5    # "it\\28":Lorg/lighttouch/android/CatalogFirmware;
    .end local v12    # "$i$a$-minOf-PrepareScreenKt$DeviceStep$4\\28\\187\\0":I
    check-cast v5, Ljava/lang/Comparable;

    invoke-interface {v3, v5}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    move-result v12

    if-lez v12, :cond_20

    move-object v3, v5

    goto :goto_15

    :cond_21
    check-cast v3, Lorg/lighttouch/android/Support;

    and-int/lit8 v5, v7, 0xe

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceRow(Lorg/lighttouch/android/PrepareState;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V

    .end local v1    # "product":Ljava/lang/String;
    .end local v2    # "range":Ljava/lang/String;
    .end local v10    # "firmwares":Ljava/util/List;
    .end local v11    # "sorted":Ljava/util/List;
    goto/16 :goto_11

    .restart local v1    # "product":Ljava/lang/String;
    .restart local v2    # "range":Ljava/lang/String;
    .restart local v10    # "firmwares":Ljava/util/List;
    .restart local v11    # "sorted":Ljava/util/List;
    :cond_22
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0

    .end local v1    # "product":Ljava/lang/String;
    .end local v2    # "range":Ljava/lang/String;
    .end local v10    # "firmwares":Ljava/util/List;
    .end local v11    # "sorted":Ljava/util/List;
    :cond_23
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v0, -0x3a45a589

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "189@11197L10,189@11140L79"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 190
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PrepareState;->getCatalog()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_24

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v34

    const/16 v37, 0x0

    const v38, 0xfffe

    const-string v14, "\u6b63\u5728\u52a0\u8f7d\u56fa\u4ef6\u5217\u8868\u2026"

    const/4 v15, 0x0

    const-wide/16 v16, 0x0

    const-wide/16 v18, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const-wide/16 v23, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v36, 0x6

    move-object/from16 v35, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v35    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v14 .. v38}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v35    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_24
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 191
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v14, v0

    check-cast v14, Landroidx/compose/ui/Modifier;

    const/16 v0, 0xc

    .local v0, "$this$dp\\29":I
    const/4 v1, 0x0

    .line 570
    .local v1, "$i$f$getDp\\29\\191":I
    int-to-float v2, v0

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v16

    .line 191
    .end local v0    # "$this$dp\\29":I
    .end local v1    # "$i$f$getDp\\29\\191":I
    const/16 v19, 0xd

    const/16 v20, 0x0

    const/4 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-static/range {v14 .. v20}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "prepare_advanced"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$1748425384$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    shr-int/lit8 v0, v7, 0x3

    and-int/lit8 v0, v0, 0xe

    const v2, 0x30000030

    or-int v11, v0, v2

    const/16 v12, 0x1fc

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object/from16 v35, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v35    # "$composer":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move v0, v7

    .end local v7    # "$dirty":I
    .local v0, "$dirty":I
    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v14, p0

    move v15, v0

    move-object/from16 v10, v35

    move-object/from16 v0, p1

    .end local v0    # "$dirty":I
    .end local v35    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$dirty":I
    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object v4, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_25

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v39    # "devices":Ljava/util/List;
    .end local v40    # "tested":Ljava/util/List;
    .end local v41    # "others":Ljava/util/List;
    :cond_25
    :goto_16
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_26

    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v2, v14, v0, v13}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda14;-><init>(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 194
    :cond_26
    return-void
.end method

.method private static final DeviceStep$lambda$29$lambda$28(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/CharSequence;
    .locals 3
    .param p0, "it"    # Lorg/lighttouch/android/CatalogFirmware;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 176
    invoke-virtual {p0}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "iOS "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private static final DeviceStep$lambda$35(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceStep(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 34
    .param p0, "$this$FilesStep"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p2, "busy"    # Z
    .param p3, "onDownload"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onChooseIpsw"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onChooseRom"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onDownloadRom"    # Lkotlin/jvm/functions/Function0;
    .param p7, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p8, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Lorg/lighttouch/android/PrepareState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 269
    move-object/from16 v1, p0

    move/from16 v3, p2

    move/from16 v9, p9

    const v0, 0x6b22b2c2

    move-object/from16 v2, p8

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p8    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(FilesStep)P(6!1,3)271@16729L182,275@17163L2253,274@16928L2488,326@21146L30,329@21389L10,329@21433L11,328@21222L240,330@21467L30,331@21502L358:PrepareScreen.kt#o13vsk"

    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p9

    .local v2, "$dirty":I
    and-int/lit8 v4, v9, 0x6

    const/4 v8, 0x2

    if-nez v4, :cond_1

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v8

    :goto_0
    or-int/2addr v2, v4

    :cond_1
    and-int/lit8 v4, v9, 0x30

    if-nez v4, :cond_3

    move-object/from16 v4, p1

    invoke-interface {v11, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v2, v5

    goto :goto_2

    :cond_3
    move-object/from16 v4, p1

    :goto_2
    and-int/lit16 v5, v9, 0x180

    if-nez v5, :cond_5

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x100

    goto :goto_3

    :cond_4
    const/16 v5, 0x80

    :goto_3
    or-int/2addr v2, v5

    :cond_5
    and-int/lit16 v5, v9, 0xc00

    if-nez v5, :cond_7

    move-object/from16 v5, p3

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6

    const/16 v6, 0x800

    goto :goto_4

    :cond_6
    const/16 v6, 0x400

    :goto_4
    or-int/2addr v2, v6

    goto :goto_5

    :cond_7
    move-object/from16 v5, p3

    :goto_5
    and-int/lit16 v6, v9, 0x6000

    if-nez v6, :cond_9

    move-object/from16 v6, p4

    invoke-interface {v11, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_8

    const/16 v7, 0x4000

    goto :goto_6

    :cond_8
    const/16 v7, 0x2000

    :goto_6
    or-int/2addr v2, v7

    goto :goto_7

    :cond_9
    move-object/from16 v6, p4

    :goto_7
    const/high16 v7, 0x30000

    and-int/2addr v7, v9

    if-nez v7, :cond_b

    move-object/from16 v7, p5

    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_a

    const/high16 v10, 0x20000

    goto :goto_8

    :cond_a
    const/high16 v10, 0x10000

    :goto_8
    or-int/2addr v2, v10

    goto :goto_9

    :cond_b
    move-object/from16 v7, p5

    :goto_9
    const/high16 v10, 0x180000

    and-int/2addr v10, v9

    if-nez v10, :cond_d

    move-object/from16 v10, p6

    invoke-interface {v11, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_c

    const/high16 v12, 0x100000

    goto :goto_a

    :cond_c
    const/high16 v12, 0x80000

    :goto_a
    or-int/2addr v2, v12

    goto :goto_b

    :cond_d
    move-object/from16 v10, p6

    :goto_b
    const/high16 v12, 0xc00000

    and-int/2addr v12, v9

    if-nez v12, :cond_f

    move-object/from16 v12, p7

    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_e

    const/high16 v13, 0x800000

    goto :goto_c

    :cond_e
    const/high16 v13, 0x400000

    :goto_c
    or-int/2addr v2, v13

    goto :goto_d

    :cond_f
    move-object/from16 v12, p7

    :goto_d
    move v13, v2

    .end local v2    # "$dirty":I
    .local v13, "$dirty":I
    const v2, 0x492493

    and-int/2addr v2, v13

    const v14, 0x492492

    if-ne v2, v14, :cond_11

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_10

    goto :goto_e

    .line 332
    :cond_10
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v14, v1

    move-object/from16 v22, v11

    move/from16 v29, v13

    goto/16 :goto_15

    .line 269
    :cond_11
    :goto_e
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_12

    const/4 v2, -0x1

    const-string v14, "org.lighttouch.android.FilesStep (PrepareScreen.kt:268)"

    invoke-static {v0, v13, v2, v14}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 270
    :cond_12
    invoke-virtual {v4}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-nez v0, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_13
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v14

    if-eqz v14, :cond_14

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda3;

    move-object v2, v4

    move-object v4, v5

    move-object v5, v6

    move-object v6, v7

    move-object v7, v10

    move-object v8, v12

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda3;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v14, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_14
    return-void

    :cond_15
    move-object v1, v0

    .line 271
    .local v1, "firmware":Lorg/lighttouch/android/CatalogFirmware;
    invoke-virtual {v1}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 272
    .local v9, "name":Ljava/lang/String;
    invoke-virtual {v1}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", iOS "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 273
    invoke-virtual {v1}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lorg/lighttouch/android/FirmwareCatalogKt;->needsBootrom(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_16

    const-string v2, "\uff0c\u4ee5\u53ca\u8bbe\u5907\u7684\u5f15\u5bfc\u6587\u4ef6\u3002"

    goto :goto_f

    :cond_16
    const-string v2, "."

    :goto_f
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u6b64\u7248\u672c\u9700\u8981 Apple \u539f\u7248 IPSW"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 272
    const/4 v10, 0x0

    invoke-static {v0, v2, v11, v10}, Lorg/lighttouch/android/PrepareScreenKt;->Heading(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 275
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getLayers()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v6

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v7

    .line 276
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v0

    if-eqz v0, :cond_17

    new-instance v0, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getIpswPath()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u00b7 \u5df2\u9a8c\u8bc1"

    goto :goto_10

    :cond_17
    invoke-virtual {v1}, Lorg/lighttouch/android/CatalogFirmware;->getFileName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1}, Lorg/lighttouch/android/CatalogFirmware;->getBytes()J

    move-result-wide v2

    const v4, 0xf4240

    int-to-long v4, v4

    div-long/2addr v2, v4

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, " \u00b7 "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " MB"

    :goto_10
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v12, v0

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;

    move-object/from16 v2, p1

    move/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v3, p4

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$1;-><init>(Lorg/lighttouch/android/CatalogFirmware;Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;)V

    move-object/from16 v26, v1

    .end local v1    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    .local v26, "firmware":Lorg/lighttouch/android/CatalogFirmware;
    const v1, 0x13ae2071

    const/4 v14, 0x1

    const/16 v15, 0x36

    invoke-static {v1, v14, v0, v11, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Lkotlin/jvm/functions/Function3;

    .line 275
    const-string v2, "iOS \u56fa\u4ef6 (IPSW)"

    move v3, v7

    const/16 v7, 0x6030

    move-object v1, v6

    move-object v6, v11

    move-object v4, v12

    .end local v11    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/PrepareScreenKt;->Card(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 306
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getBootrom()Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    .line 307
    .local v0, "rom":Lorg/lighttouch/android/Bootrom;
    if-nez v0, :cond_18

    const v1, 0x2d429454

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "306@19532L146"

    invoke-static {v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getChip()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    .line 308
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u65e0\u9700\u989d\u5916\u6587\u4ef6\u3002"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u4ece\u51c6\u5907\u9636\u6bb5\u751f\u6210\u7684\u6587\u4ef6\u5f00\u59cb\u3002"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-1815992138$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v5

    .line 307
    const-string v2, "\u5f15\u5bfc\u6587\u4ef6"

    const/4 v3, 0x1

    const/16 v7, 0x61b0

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/PrepareScreenKt;->Card(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_12

    .line 309
    :cond_18
    const v1, 0x2d42acef

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "309@19920L1221,308@19688L1453"

    invoke-static {v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getChip()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v7

    invoke-virtual {v0}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Boot file \u00b7 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " boot ROM"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v12

    .line 310
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getRomLabel()Ljava/lang/String;

    move-result-object v1

    goto :goto_11

    :cond_19
    const-string v1, "64 KB\uff0c\u5c5e\u4e8e\u82af\u7247\u800c\u975e IPSW \u7684\u4e00\u90e8\u5206\uff0c\u5404 iOS \u7248\u672c\u901a\u7528\u3002"

    :goto_11
    move-object/from16 v16, v1

    move-object v4, v0

    .end local v0    # "rom":Lorg/lighttouch/android/Bootrom;
    .local v4, "rom":Lorg/lighttouch/android/Bootrom;
    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;

    move-object/from16 v1, p1

    move/from16 v3, p2

    move-object/from16 v2, p5

    move-object/from16 v5, p6

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt$FilesStep$2;-><init>(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;ZLorg/lighttouch/android/Bootrom;Lkotlin/jvm/functions/Function0;)V

    move-object v1, v0

    move-object v0, v4

    .end local v4    # "rom":Lorg/lighttouch/android/Bootrom;
    .restart local v0    # "rom":Lorg/lighttouch/android/Bootrom;
    const v2, -0x6bfaceb3

    invoke-static {v2, v14, v1, v6, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object v5, v1

    check-cast v5, Lkotlin/jvm/functions/Function3;

    .line 309
    move-object v1, v7

    const/16 v7, 0x6000

    move-object v2, v11

    move v3, v12

    move-object/from16 v4, v16

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/PrepareScreenKt;->Card(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 327
    :goto_12
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xc

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 608
    .local v3, "$i$f$getDp\\1\\327":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 327
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\327":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v6, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 328
    invoke-static/range {v26 .. v26}, Lorg/lighttouch/android/PrepareScreenKt;->preparationCost(Lorg/lighttouch/android/CatalogFirmware;)Lorg/lighttouch/android/PreparationCost;

    move-result-object v27

    .line 329
    .local v27, "cost":Lorg/lighttouch/android/PreparationCost;
    invoke-virtual/range {v27 .. v27}, Lorg/lighttouch/android/PreparationCost;->getTime()Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {v27 .. v27}, Lorg/lighttouch/android/PreparationCost;->getSpace()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u51c6\u5907\u5728\u672c\u673a\u8fdb\u884c\uff0c\u9700\u8981 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, "\uff0c\u7ea6\u9700 "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " \u53ef\u7528\uff0cLightTouch \u4f1a\u81ea\u52a8\u6dfb\u52a0\u5ba2\u6237\u673a\u5de5\u5177\u3002"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 330
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v6, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v6, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    .line 329
    nop

    .line 330
    nop

    .line 329
    move v5, v2

    const/4 v2, 0x0

    move v7, v5

    move-object/from16 v22, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v22, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v5, 0x0

    move v11, v7

    const/4 v7, 0x0

    move v12, v8

    const/4 v8, 0x0

    move-object v15, v9

    .end local v9    # "name":Ljava/lang/String;
    .local v15, "name":Ljava/lang/String;
    const/4 v9, 0x0

    move/from16 v16, v10

    move/from16 v17, v11

    const-wide/16 v10, 0x0

    move/from16 v18, v12

    const/4 v12, 0x0

    move/from16 v19, v13

    .end local v13    # "$dirty":I
    .local v19, "$dirty":I
    const/4 v13, 0x0

    move/from16 v23, v14

    move-object/from16 v20, v15

    .end local v15    # "name":Ljava/lang/String;
    .local v20, "name":Ljava/lang/String;
    const-wide/16 v14, 0x0

    move/from16 v24, v16

    const/16 v16, 0x0

    move/from16 v25, v17

    const/16 v17, 0x0

    move/from16 v28, v18

    const/16 v18, 0x0

    move/from16 v29, v19

    .end local v19    # "$dirty":I
    .local v29, "$dirty":I
    const/16 v19, 0x0

    move-object/from16 v30, v20

    .end local v20    # "name":Ljava/lang/String;
    .local v30, "name":Ljava/lang/String;
    const/16 v20, 0x0

    move/from16 v31, v23

    const/16 v23, 0x0

    move/from16 v32, v24

    const/16 v24, 0x0

    move/from16 v33, v25

    const v25, 0xfffa

    move-object/from16 p8, v0

    move/from16 v0, v33

    .end local v0    # "rom":Lorg/lighttouch/android/Bootrom;
    .local p8, "rom":Lorg/lighttouch/android/Bootrom;
    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 331
    move-object/from16 v6, v22

    .end local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x14

    .local v2, "$this$dp\\2":I
    const/4 v3, 0x0

    .line 609
    .local v3, "$i$f$getDp\\2\\331":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 331
    .end local v2    # "$this$dp\\2":I
    .end local v3    # "$i$f$getDp\\2\\331":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v6, v0}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 332
    if-nez p2, :cond_1b

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/PrepareState;->getIpswChecking()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_1a

    move/from16 v10, v31

    goto :goto_13

    :cond_1a
    move/from16 v10, v32

    :goto_13
    if-eqz v10, :cond_1b

    move/from16 v3, v31

    goto :goto_14

    :cond_1b
    move/from16 v3, v32

    .line 333
    :goto_14
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    move-object/from16 v14, p0

    invoke-interface {v14, v0, v1}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x34

    .local v1, "$this$dp\\3":I
    const/4 v2, 0x0

    .line 610
    .local v2, "$i$f$getDp\\3\\333":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 333
    .end local v1    # "$this$dp\\3":I
    .end local v2    # "$i$f$getDp\\3\\333":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "start_preparation"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v0, 0x20

    .local v0, "$this$dp\\4":I
    const/4 v1, 0x0

    .line 610
    .local v1, "$i$f$getDp\\4\\333":I
    int-to-float v4, v0

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 333
    .end local v0    # "$this$dp\\4":I
    .end local v1    # "$i$f$getDp\\4\\333":I
    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v12, 0x2

    invoke-static {v0, v1, v12, v4}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA$default(FFILjava/lang/Object;)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v8

    .line 332
    nop

    .line 333
    nop

    .line 332
    nop

    .line 333
    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$79442130$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    shr-int/lit8 v0, v29, 0x15

    and-int/lit8 v0, v0, 0xe

    const/high16 v1, 0x30c00000

    or-int v12, v0, v1

    .line 332
    const/4 v5, 0x0

    move-object/from16 v22, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v22    # "$composer":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/16 v13, 0x178

    move-object/from16 v1, p7

    move-object/from16 v11, v22

    .end local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v11    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v22    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v26    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    .end local v27    # "cost":Lorg/lighttouch/android/PreparationCost;
    .end local v30    # "name":Ljava/lang/String;
    .end local p8    # "rom":Lorg/lighttouch/android/Bootrom;
    :cond_1c
    :goto_15
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v10

    if-eqz v10, :cond_1d

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda4;

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move/from16 v9, p9

    move-object v1, v14

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda4;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v10, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 336
    :cond_1d
    return-void
.end method

.method private static final FilesStep$lambda$55(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p8, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v10

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/PrepareScreenKt;->FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final FilesStep$lambda$56(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p8, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v10

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/PrepareScreenKt;->FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Heading(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 26
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "detail"    # Ljava/lang/String;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 132
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const v2, -0x2f1c558b

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Heading)P(1)132@7565L10,132@7531L60,133@7596L29,134@7665L10,134@7710L11,134@7630L109,135@7744L30:PrepareScreen.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, p3, 0x6

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_3

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit8 v5, v4, 0x13

    const/16 v6, 0x12

    if-ne v5, v6, :cond_5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_2

    .line 136
    :cond_4
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v0, v1

    move-object v1, v3

    move/from16 v25, v4

    goto/16 :goto_3

    .line 132
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_6

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.Heading (PrepareScreen.kt:131)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 133
    :cond_6
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getHeadlineMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    and-int/lit8 v22, v4, 0xe

    const/16 v23, 0x0

    const v24, 0xfffe

    const/4 v1, 0x0

    move-object/from16 v21, v3

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v21, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v2, 0x0

    move v6, v4

    .end local v4    # "$dirty":I
    .local v6, "$dirty":I
    const-wide/16 v4, 0x0

    move v7, v6

    .end local v6    # "$dirty":I
    .local v7, "$dirty":I
    const/4 v6, 0x0

    move v8, v7

    .end local v7    # "$dirty":I
    .local v8, "$dirty":I
    const/4 v7, 0x0

    move v9, v8

    .end local v8    # "$dirty":I
    .local v9, "$dirty":I
    const/4 v8, 0x0

    move v11, v9

    .end local v9    # "$dirty":I
    .local v11, "$dirty":I
    const-wide/16 v9, 0x0

    move v12, v11

    .end local v11    # "$dirty":I
    .local v12, "$dirty":I
    const/4 v11, 0x0

    move v13, v12

    .end local v12    # "$dirty":I
    .local v13, "$dirty":I
    const/4 v12, 0x0

    move v15, v13

    .end local v13    # "$dirty":I
    .local v15, "$dirty":I
    const-wide/16 v13, 0x0

    move/from16 v16, v15

    .end local v15    # "$dirty":I
    .local v16, "$dirty":I
    const/4 v15, 0x0

    move/from16 v17, v16

    .end local v16    # "$dirty":I
    .local v17, "$dirty":I
    const/16 v16, 0x0

    move/from16 v18, v17

    .end local v17    # "$dirty":I
    .local v18, "$dirty":I
    const/16 v17, 0x0

    move/from16 v19, v18

    .end local v18    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v18, 0x0

    move/from16 v25, v19

    .end local v19    # "$dirty":I
    .local v25, "$dirty":I
    const/16 v19, 0x0

    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 134
    move-object/from16 v0, v21

    .end local v21    # "$composer":Landroidx/compose/runtime/Composer;
    .local v0, "$composer":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 435
    .local v3, "$i$f$getDp\\1\\134":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 134
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\134":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v0, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 135
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v0, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    shr-int/lit8 v1, v25, 0x3

    and-int/lit8 v22, v1, 0xe

    const v24, 0xfffa

    const/4 v1, 0x0

    move v6, v2

    move-wide v2, v3

    const-wide/16 v4, 0x0

    move v7, v6

    const/4 v6, 0x0

    move v8, v7

    const/4 v7, 0x0

    move v9, v8

    const/4 v8, 0x0

    move v11, v9

    const-wide/16 v9, 0x0

    move v12, v11

    const/4 v11, 0x0

    move v13, v12

    const/4 v12, 0x0

    move v15, v13

    const-wide/16 v13, 0x0

    move/from16 v16, v15

    const/4 v15, 0x0

    move/from16 v17, v16

    const/16 v16, 0x0

    move/from16 v18, v17

    const/16 v17, 0x0

    move/from16 v19, v18

    const/16 v18, 0x0

    move/from16 v21, v19

    const/16 v19, 0x0

    move-object/from16 v21, v0

    move-object/from16 v0, p1

    .end local v0    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 136
    move-object/from16 v1, v21

    .end local v21    # "$composer":Landroidx/compose/runtime/Composer;
    .local v1, "$composer":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x14

    .local v3, "$this$dp\\2":I
    const/4 v4, 0x0

    .line 436
    .local v4, "$i$f$getDp\\2\\136":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 136
    .end local v3    # "$this$dp\\2":I
    .end local v4    # "$i$f$getDp\\2\\136":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v6, 0x6

    invoke-static {v2, v1, v6}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_7
    :goto_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_8

    new-instance v3, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda17;

    move-object/from16 v4, p0

    move/from16 v5, p3

    invoke-direct {v3, v4, v0, v5}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda17;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_4

    :cond_8
    move-object/from16 v4, p0

    move/from16 v5, p3

    .line 137
    :goto_4
    return-void
.end method

.method private static final Heading$lambda$14(Ljava/lang/String;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/PrepareScreenKt;->Heading(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final PrepareScreen(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .locals 27
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "busy"    # Z
    .param p2, "preparing"    # Z
    .param p3, "onDownload"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onChooseIpsw"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onChooseRom"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onDownloadRom"    # Lkotlin/jvm/functions/Function0;
    .param p7, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p8, "onChoosePrepared"    # Lkotlin/jvm/functions/Function0;
    .param p9, "onCancel"    # Lkotlin/jvm/functions/Function0;
    .param p10, "onRetryImport"    # Lkotlin/jvm/functions/Function0;
    .param p11, "onAdvanced"    # Lkotlin/jvm/functions/Function0;
    .param p12, "onClose"    # Lkotlin/jvm/functions/Function0;
    .param p13, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p14, "$changed"    # I
    .param p15, "$changed1"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/PrepareState;",
            "ZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move-object/from16 v10, p9

    move-object/from16 v11, p10

    move-object/from16 v12, p11

    move-object/from16 v13, p12

    move/from16 v0, p14

    move/from16 v2, p15

    const-string v14, "state"

    invoke-static {v1, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onDownload"

    invoke-static {v4, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onChooseIpsw"

    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onChooseRom"

    invoke-static {v6, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onDownloadRom"

    invoke-static {v7, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onPrepare"

    invoke-static {v8, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onChoosePrepared"

    invoke-static {v9, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onCancel"

    invoke-static {v10, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onRetryImport"

    invoke-static {v11, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onAdvanced"

    invoke-static {v12, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v15, "onClose"

    invoke-static {v13, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    const v15, 0x63833fba

    move-object/from16 v16, v14

    move-object/from16 v14, p13

    invoke-interface {v14, v15}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .end local p13    # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "$composer":Landroidx/compose/runtime/Composer;
    const-string v15, "C(PrepareScreen)P(12!1,11,7,3,5,8,9,4,2,10)96@5383L429,106@5829L10,106@5817L22,107@5885L31,107@5959L11,107@5983L1475,107@5844L1614:PrepareScreen.kt#o13vsk"

    invoke-static {v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v15, p14

    .local v15, "$dirty":I
    move/from16 v18, p15

    .local v18, "$dirty1":I
    and-int/lit8 v19, v0, 0x6

    move/from16 p13, v15

    .end local v15    # "$dirty":I
    .local p13, "$dirty":I
    const/16 v20, 0x2

    if-nez v19, :cond_1

    invoke-interface {v14, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_0

    const/16 v19, 0x4

    goto :goto_0

    :cond_0
    move/from16 v19, v20

    :goto_0
    or-int v19, p13, v19

    .end local p13    # "$dirty":I
    .local v19, "$dirty":I
    goto :goto_1

    .end local v19    # "$dirty":I
    .restart local p13    # "$dirty":I
    :cond_1
    move/from16 v19, p13

    .end local p13    # "$dirty":I
    .restart local v19    # "$dirty":I
    :goto_1
    and-int/lit8 v21, v0, 0x30

    const/16 v22, 0x20

    const/16 v23, 0x10

    if-nez v21, :cond_3

    move/from16 v15, p1

    invoke-interface {v14, v15}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v21

    if-eqz v21, :cond_2

    move/from16 v21, v22

    goto :goto_2

    :cond_2
    move/from16 v21, v23

    :goto_2
    or-int v19, v19, v21

    goto :goto_3

    :cond_3
    move/from16 v15, p1

    :goto_3
    and-int/lit16 v15, v0, 0x180

    const/16 v21, 0x80

    move/from16 v24, v15

    if-nez v24, :cond_5

    invoke-interface {v14, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v24

    if-eqz v24, :cond_4

    const/16 v24, 0x100

    goto :goto_4

    :cond_4
    move/from16 v24, v21

    :goto_4
    or-int v19, v19, v24

    :cond_5
    and-int/lit16 v15, v0, 0xc00

    if-nez v15, :cond_7

    invoke-interface {v14, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_6

    const/16 v15, 0x800

    goto :goto_5

    :cond_6
    const/16 v15, 0x400

    :goto_5
    or-int v19, v19, v15

    :cond_7
    and-int/lit16 v15, v0, 0x6000

    if-nez v15, :cond_9

    invoke-interface {v14, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_8

    const/16 v15, 0x4000

    goto :goto_6

    :cond_8
    const/16 v15, 0x2000

    :goto_6
    or-int v19, v19, v15

    :cond_9
    const/high16 v15, 0x30000

    and-int/2addr v15, v0

    if-nez v15, :cond_b

    invoke-interface {v14, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_a

    const/high16 v15, 0x20000

    goto :goto_7

    :cond_a
    const/high16 v15, 0x10000

    :goto_7
    or-int v19, v19, v15

    :cond_b
    const/high16 v15, 0x180000

    and-int/2addr v15, v0

    if-nez v15, :cond_d

    invoke-interface {v14, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_c

    const/high16 v15, 0x100000

    goto :goto_8

    :cond_c
    const/high16 v15, 0x80000

    :goto_8
    or-int v19, v19, v15

    :cond_d
    const/high16 v15, 0xc00000

    and-int/2addr v15, v0

    if-nez v15, :cond_f

    invoke-interface {v14, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_e

    const/high16 v15, 0x800000

    goto :goto_9

    :cond_e
    const/high16 v15, 0x400000

    :goto_9
    or-int v19, v19, v15

    :cond_f
    const/high16 v15, 0x6000000

    and-int/2addr v15, v0

    if-nez v15, :cond_11

    invoke-interface {v14, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_10

    const/high16 v15, 0x4000000

    goto :goto_a

    :cond_10
    const/high16 v15, 0x2000000

    :goto_a
    or-int v19, v19, v15

    :cond_11
    const/high16 v15, 0x30000000

    and-int/2addr v15, v0

    if-nez v15, :cond_13

    invoke-interface {v14, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_12

    const/high16 v15, 0x20000000

    goto :goto_b

    :cond_12
    const/high16 v15, 0x10000000

    :goto_b
    or-int v19, v19, v15

    :cond_13
    move/from16 v15, v19

    .end local v19    # "$dirty":I
    .restart local v15    # "$dirty":I
    and-int/lit8 v19, v2, 0x6

    if-nez v19, :cond_15

    invoke-interface {v14, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_14

    const/16 v19, 0x4

    goto :goto_c

    :cond_14
    move/from16 v19, v20

    :goto_c
    or-int v18, v18, v19

    :cond_15
    and-int/lit8 v19, v2, 0x30

    if-nez v19, :cond_17

    invoke-interface {v14, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_16

    goto :goto_d

    :cond_16
    move/from16 v22, v23

    :goto_d
    or-int v18, v18, v22

    :cond_17
    and-int/lit16 v0, v2, 0x180

    if-nez v0, :cond_19

    invoke-interface {v14, v13}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_18

    const/16 v21, 0x100

    :cond_18
    or-int v18, v18, v21

    :cond_19
    move/from16 v0, v18

    .end local v18    # "$dirty1":I
    .local v0, "$dirty1":I
    const v18, 0x12492493

    and-int v2, v15, v18

    const v4, 0x12492492

    if-ne v2, v4, :cond_1b

    and-int/lit16 v2, v0, 0x93

    const/16 v4, 0x92

    if-ne v2, v4, :cond_1b

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_1a

    goto :goto_e

    .line 108
    :cond_1a
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v20, v0

    move-object/from16 v25, v14

    move/from16 v19, v15

    goto/16 :goto_1a

    .line 94
    :cond_1b
    :goto_e
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_1c

    const-string v2, "org.lighttouch.android.PrepareScreen (PrepareScreen.kt:93)"

    const v4, 0x63833fba

    invoke-static {v4, v15, v0, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 95
    :cond_1c
    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_1d

    move-object/from16 v4, v16

    invoke-virtual {v2, v4}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_f

    :cond_1d
    const/4 v2, 0x0

    .line 96
    .local v2, "run":Ljava/lang/String;
    :goto_f
    const/16 v16, 0x0

    if-nez v3, :cond_1f

    const/16 v18, 0x1

    const/4 v4, 0x3

    new-array v4, v4, [Ljava/lang/String;

    const-string v19, "complete"

    aput-object v19, v4, v16

    const-string v19, "failed"

    aput-object v19, v4, v18

    const-string v19, "cancelled"

    aput-object v19, v4, v20

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4, v2}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1e

    goto :goto_10

    :cond_1e
    move/from16 v4, v16

    goto :goto_11

    :cond_1f
    const/16 v18, 0x1

    :goto_10
    move/from16 v4, v18

    :goto_11
    move-object/from16 v19, v2

    .end local v2    # "run":Ljava/lang/String;
    .local v4, "showProgress":Z
    .local v19, "run":Ljava/lang/String;
    const v2, -0x48fade91

    invoke-interface {v14, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):PrepareScreen.kt#9igjgp"

    invoke-static {v14, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v5, v15, 0x380

    const/16 v6, 0x100

    if-ne v5, v6, :cond_20

    move/from16 v5, v18

    goto :goto_12

    :cond_20
    move/from16 v5, v16

    :goto_12
    invoke-interface {v14, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v20

    or-int v5, v5, v20

    move/from16 v20, v5

    and-int/lit16 v5, v0, 0x380

    if-ne v5, v6, :cond_21

    move/from16 v5, v18

    goto :goto_13

    :cond_21
    move/from16 v5, v16

    :goto_13
    or-int v5, v20, v5

    and-int/lit8 v6, v15, 0xe

    move/from16 v20, v0

    const/4 v0, 0x4

    .end local v0    # "$dirty1":I
    .local v20, "$dirty1":I
    if-ne v6, v0, :cond_22

    move/from16 v0, v18

    goto :goto_14

    :cond_22
    move/from16 v0, v16

    :goto_14
    or-int/2addr v0, v5

    .line 97
    nop

    .local v0, "invalid\\1":Z
    move-object v5, v14

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 417
    .local v6, "$i$f$cache\\1\\97":I
    move/from16 p13, v0

    .end local v0    # "invalid\\1":Z
    .local p13, "invalid\\1":Z
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\1":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 418
    .local v21, "$i$a$-let-ComposerKt$cache$1\\2\\417\\1":I
    if-nez p13, :cond_24

    sget-object v22, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v23, v6

    .end local v6    # "$i$f$cache\\1\\97":I
    .local v23, "$i$f$cache\\1\\97":I
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v0, v6, :cond_23

    goto :goto_15

    .line 422
    :cond_23
    move-object/from16 v22, v0

    goto :goto_16

    .line 418
    .end local v23    # "$i$f$cache\\1\\97":I
    .restart local v6    # "$i$f$cache\\1\\97":I
    :cond_24
    move/from16 v23, v6

    .line 419
    .end local v6    # "$i$f$cache\\1\\97":I
    .restart local v23    # "$i$f$cache\\1\\97":I
    :goto_15
    const/4 v6, 0x0

    .line 97
    .local v6, "$i$a$-cache-PrepareScreenKt$PrepareScreen$back$1\\3\\419\\0":I
    move-object/from16 v22, v0

    .end local v0    # "it\\1":Ljava/lang/Object;
    .local v22, "it\\1":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v0, v3, v4, v13, v1}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda5;-><init>(ZZLkotlin/jvm/functions/Function0;Lorg/lighttouch/android/PrepareState;)V

    .line 419
    .end local v6    # "$i$a$-cache-PrepareScreenKt$PrepareScreen$back$1\\3\\419\\0":I
    nop

    .line 420
    .local v0, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 421
    nop

    .line 418
    .end local v0    # "value\\2":Ljava/lang/Object;
    :goto_16
    nop

    .line 417
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\2\\417\\1":I
    .end local v22    # "it\\1":Ljava/lang/Object;
    nop

    .line 97
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$f$cache\\1\\97":I
    .end local p13    # "invalid\\1":Z
    check-cast v0, Lkotlin/jvm/functions/Function0;

    .local v0, "back":Lkotlin/jvm/functions/Function0;
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v5, 0x4c5de2

    invoke-interface {v14, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v14, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    .line 107
    nop

    .local v5, "invalid\\4":Z
    move-object v6, v14

    .local v6, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 423
    .local v21, "$i$f$cache\\4\\107":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\4":Ljava/lang/Object;
    const/16 v22, 0x0

    .line 424
    .local v22, "$i$a$-let-ComposerKt$cache$1\\5\\423\\4":I
    if-nez v5, :cond_26

    sget-object v23, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v1, v3, :cond_25

    goto :goto_17

    .line 428
    :cond_25
    move-object/from16 p13, v1

    goto :goto_18

    .line 425
    :cond_26
    :goto_17
    const/4 v3, 0x0

    .line 107
    .local v3, "$i$a$-cache-PrepareScreenKt$PrepareScreen$1\\6\\425\\0":I
    move-object/from16 p13, v1

    .end local v1    # "it\\4":Ljava/lang/Object;
    .local p13, "it\\4":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v1, v0}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda6;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 425
    .end local v3    # "$i$a$-cache-PrepareScreenKt$PrepareScreen$1\\6\\425\\0":I
    nop

    .line 426
    .local v1, "value\\5":Ljava/lang/Object;
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 427
    nop

    .line 424
    .end local v1    # "value\\5":Ljava/lang/Object;
    :goto_18
    nop

    .line 423
    .end local v22    # "$i$a$-let-ComposerKt$cache$1\\5\\423\\4":I
    .end local p13    # "it\\4":Ljava/lang/Object;
    nop

    .line 107
    .end local v5    # "invalid\\4":Z
    .end local v6    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$f$cache\\4\\107":I
    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v3, v16

    move/from16 v5, v18

    invoke-static {v3, v1, v14, v3, v5}, Landroidx/activity/compose/BackHandlerKt;->BackHandler(ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 108
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v3, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const v3, 0x6e3c21fe

    invoke-interface {v14, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v14, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\7":Z
    move-object v3, v14

    .local v3, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 429
    .local v5, "$i$f$cache\\7\\108":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\7":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 430
    .local v21, "$i$a$-let-ComposerKt$cache$1\\8\\429\\7":I
    sget-object v22, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 p13, v0

    .end local v0    # "back":Lkotlin/jvm/functions/Function0;
    .local p13, "back":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v6, v0, :cond_27

    .line 431
    const/4 v0, 0x0

    .local v0, "$i$a$-cache-PrepareScreenKt$PrepareScreen$2\\9\\431\\0":I
    new-instance v22, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda7;

    invoke-direct/range {v22 .. v22}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda7;-><init>()V

    .end local v0    # "$i$a$-cache-PrepareScreenKt$PrepareScreen$2\\9\\431\\0":I
    move-object/from16 v0, v22

    .line 432
    .local v0, "value\\8":Ljava/lang/Object;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 433
    nop

    .end local v0    # "value\\8":Ljava/lang/Object;
    goto :goto_19

    .line 434
    :cond_27
    move-object v0, v6

    .line 430
    :goto_19
    nop

    .line 429
    .end local v6    # "it\\7":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\8\\429\\7":I
    nop

    .line 108
    .end local v2    # "invalid\\7":Z
    .end local v3    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\7\\108":I
    check-cast v0, Lkotlin/jvm/functions/Function1;

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1, v3, v0, v5, v6}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "prepare"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v14, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v17

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$PrepareScreen$3;

    move/from16 v5, p1

    move/from16 v1, p2

    move-object/from16 v2, p13

    move v3, v4

    move-object v6, v8

    move-object v8, v11

    move-object/from16 v25, v14

    move-object/from16 v21, v19

    move-object/from16 v4, p0

    move-object/from16 v14, p5

    move-object v11, v9

    move-object v9, v13

    move/from16 v19, v15

    move-object/from16 v13, p4

    move-object v15, v7

    move-object v7, v10

    move-object v10, v12

    move-object/from16 v12, p3

    .end local v4    # "showProgress":Z
    .end local v14    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v15    # "$dirty":I
    .end local p13    # "back":Lkotlin/jvm/functions/Function0;
    .local v2, "back":Lkotlin/jvm/functions/Function0;
    .local v3, "showProgress":Z
    .local v19, "$dirty":I
    .local v21, "run":Ljava/lang/String;
    .local v25, "$composer":Landroidx/compose/runtime/Composer;
    invoke-direct/range {v0 .. v15}, Lorg/lighttouch/android/PrepareScreenKt$PrepareScreen$3;-><init>(ZLkotlin/jvm/functions/Function0;ZLorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    move-object v14, v2

    move v13, v3

    .end local v2    # "back":Lkotlin/jvm/functions/Function0;
    .end local v3    # "showProgress":Z
    .local v13, "showProgress":Z
    .local v14, "back":Lkotlin/jvm/functions/Function0;
    const/16 v1, 0x36

    const v2, 0x13b4c13f

    move-object/from16 v10, v25

    const/4 v5, 0x1

    .end local v25    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v5, v0, v10, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lkotlin/jvm/functions/Function2;

    const/high16 v11, 0xc00000

    const/16 v12, 0x7a

    const/4 v1, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v0, v16

    move-wide/from16 v2, v17

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v25    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_28

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v13    # "showProgress":Z
    .end local v14    # "back":Lkotlin/jvm/functions/Function0;
    .end local v21    # "run":Ljava/lang/String;
    :cond_28
    :goto_1a
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_29

    move-object v1, v0

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda8;

    move/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move-object/from16 v10, p9

    move-object/from16 v11, p10

    move-object/from16 v12, p11

    move-object/from16 v13, p12

    move/from16 v14, p14

    move/from16 v15, p15

    move-object/from16 v26, v1

    move-object/from16 v1, p0

    invoke-direct/range {v0 .. v15}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;II)V

    move-object/from16 v1, v26

    invoke-interface {v1, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 129
    :cond_29
    return-void
.end method

.method private static final PrepareScreen$lambda$10$lambda$9(Lkotlin/jvm/functions/Function0;)Lkotlin/Unit;
    .locals 1
    .param p0, "$back"    # Lkotlin/jvm/functions/Function0;

    .line 107
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareScreen$lambda$12$lambda$11(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 108
    const/4 v0, 0x1

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsProperties_androidKt;->setTestTagsAsResourceId(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareScreen$lambda$13(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 17

    or-int/lit8 v0, p13, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v15

    invoke-static/range {p14 .. p14}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v16

    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move-object/from16 v10, p9

    move-object/from16 v11, p10

    move-object/from16 v12, p11

    move-object/from16 v13, p12

    move-object/from16 v14, p15

    invoke-static/range {v1 .. v16}, Lorg/lighttouch/android/PrepareScreenKt;->PrepareScreen(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareScreen$lambda$8$lambda$7(ZZLkotlin/jvm/functions/Function0;Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;
    .locals 2
    .param p0, "$preparing"    # Z
    .param p1, "$showProgress"    # Z
    .param p2, "$onClose"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$state"    # Lorg/lighttouch/android/PrepareState;

    .line 98
    nop

    .line 99
    if-nez p0, :cond_3

    .line 100
    if-eqz p1, :cond_0

    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    goto :goto_0

    .line 101
    :cond_0
    invoke-virtual {p3}, Lorg/lighttouch/android/PrepareState;->getStep()Lorg/lighttouch/android/PrepareStep;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/PrepareStep;->FILES:Lorg/lighttouch/android/PrepareStep;

    if-ne v0, v1, :cond_1

    sget-object v0, Lorg/lighttouch/android/PrepareStep;->VERSION:Lorg/lighttouch/android/PrepareStep;

    invoke-virtual {p3, v0}, Lorg/lighttouch/android/PrepareState;->setStep(Lorg/lighttouch/android/PrepareStep;)V

    goto :goto_0

    .line 102
    :cond_1
    invoke-virtual {p3}, Lorg/lighttouch/android/PrepareState;->getStep()Lorg/lighttouch/android/PrepareStep;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/PrepareStep;->VERSION:Lorg/lighttouch/android/PrepareStep;

    if-ne v0, v1, :cond_2

    sget-object v0, Lorg/lighttouch/android/PrepareStep;->DEVICE:Lorg/lighttouch/android/PrepareStep;

    invoke-virtual {p3, v0}, Lorg/lighttouch/android/PrepareState;->setStep(Lorg/lighttouch/android/PrepareStep;)V

    goto :goto_0

    .line 104
    :cond_2
    const-string v0, ""

    invoke-virtual {p3, v0}, Lorg/lighttouch/android/PrepareState;->setFirmwareId(Ljava/lang/String;)V

    invoke-interface {p2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 106
    :cond_3
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PreparedCopyStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 32
    .param p0, "$this$PreparedCopyStep"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p2, "busy"    # Z
    .param p3, "onChoosePrepared"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Lorg/lighttouch/android/PrepareState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 235
    move/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p5

    const v0, 0x7756761b

    move-object/from16 v1, p4

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(PreparedCopyStep)P(2)237@13901L7,238@13913L138,241@14499L1036,241@14364L1171,252@15540L30,255@15818L10,255@15862L11,253@15575L316:PrepareScreen.kt#o13vsk"

    invoke-static {v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p5

    .local v1, "$dirty":I
    and-int/lit8 v2, v5, 0x30

    if-nez v2, :cond_1

    move-object/from16 v2, p1

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/16 v7, 0x20

    goto :goto_0

    :cond_0
    const/16 v7, 0x10

    :goto_0
    or-int/2addr v1, v7

    goto :goto_1

    :cond_1
    move-object/from16 v2, p1

    :goto_1
    and-int/lit16 v7, v5, 0x180

    if-nez v7, :cond_3

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_2

    const/16 v7, 0x100

    goto :goto_2

    :cond_2
    const/16 v7, 0x80

    :goto_2
    or-int/2addr v1, v7

    :cond_3
    and-int/lit16 v7, v5, 0xc00

    if-nez v7, :cond_5

    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v7, 0x800

    goto :goto_3

    :cond_4
    const/16 v7, 0x400

    :goto_3
    or-int/2addr v1, v7

    :cond_5
    move v7, v1

    .end local v1    # "$dirty":I
    .local v7, "$dirty":I
    and-int/lit16 v1, v7, 0x491

    const/16 v8, 0x490

    if-ne v1, v8, :cond_7

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_6

    goto :goto_4

    .line 254
    :cond_6
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v22, v6

    move/from16 v27, v7

    goto/16 :goto_8

    .line 235
    :cond_7
    :goto_4
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_8

    const/4 v1, -0x1

    const-string v8, "org.lighttouch.android.PreparedCopyStep (PrepareScreen.kt:234)"

    invoke-static {v0, v7, v1, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 236
    :cond_8
    invoke-virtual {v2}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-nez v0, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_a

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda20;

    move-object/from16 v1, p0

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda20;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;I)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_a
    return-void

    .line 237
    .local v0, "firmware":Lorg/lighttouch/android/CatalogFirmware;
    :cond_b
    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 238
    .local v1, "name":Ljava/lang/String;
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    .local v2, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v3, 0x0

    .local v3, "$changed\\1":I
    const/4 v4, 0x0

    .line 605
    .local v4, "$i$f$getCurrent\\1\\238":I
    const v5, 0x789c5f52

    const-string v8, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v6, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 238
    .end local v2    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v3    # "$changed\\1":I
    .end local v4    # "$i$f$getCurrent\\1\\238":I
    move-object v2, v5

    check-cast v2, Landroid/content/Context;

    .line 239
    .local v2, "context":Landroid/content/Context;
    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ", iOS "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "LightTouch \u6682\u65f6\u65e0\u6cd5\u5728\u624b\u673a\u4e0a\u6784\u5efa\u6b64\u7248\u672c\u3002\u8bf7\u5728\u7535\u8111\u4e0a\u51c6\u5907\u597d\uff0c\u518d\u6dfb\u52a0\u5230\u8fd9\u91cc\u3002"

    const/16 v5, 0x30

    invoke-static {v3, v4, v6, v5}, Lorg/lighttouch/android/PrepareScreenKt;->Heading(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    const v3, -0x46e6d36

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "240@14222L10,239@14096L263"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 240
    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v3

    sget-object v4, Lorg/lighttouch/android/Support;->TESTED:Lorg/lighttouch/android/Support;

    if-eq v3, v4, :cond_d

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v3

    invoke-virtual {v3}, Lorg/lighttouch/android/Support;->getLabel()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/Support;->getDetail()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v5, ": "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v8, v4

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xc

    .local v4, "$this$dp\\2":I
    const/4 v5, 0x0

    .line 606
    .local v5, "$i$f$getDp\\2\\240":I
    int-to-float v9, v4

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 240
    .end local v4    # "$this$dp\\2":I
    .end local v5    # "$i$f$getDp\\2\\240":I
    const/4 v13, 0x7

    const/4 v14, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 241
    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v6, v8}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const v5, -0x46e557b

    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "240@14308L11"

    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v5

    sget-object v8, Lorg/lighttouch/android/Support;->UNTESTED:Lorg/lighttouch/android/Support;

    if-ne v5, v8, :cond_c

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v6, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v8

    goto :goto_5

    :cond_c
    sget-object v5, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v5}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v8

    :goto_5
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 240
    nop

    .line 241
    nop

    .line 240
    move-object/from16 v22, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v22, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v5, 0x0

    move v10, v7

    .end local v7    # "$dirty":I
    .local v10, "$dirty":I
    const/4 v7, 0x0

    move-object v11, v2

    move-object v2, v4

    move-wide/from16 v30, v8

    move-object v9, v1

    move-object v1, v3

    move-wide/from16 v3, v30

    .end local v1    # "name":Ljava/lang/String;
    .end local v2    # "context":Landroid/content/Context;
    .local v9, "name":Ljava/lang/String;
    .local v11, "context":Landroid/content/Context;
    const/4 v8, 0x0

    move-object v12, v9

    .end local v9    # "name":Ljava/lang/String;
    .local v12, "name":Ljava/lang/String;
    const/4 v9, 0x0

    move v13, v10

    move-object v14, v11

    .end local v10    # "$dirty":I
    .end local v11    # "context":Landroid/content/Context;
    .local v13, "$dirty":I
    .local v14, "context":Landroid/content/Context;
    const-wide/16 v10, 0x0

    move-object v15, v12

    .end local v12    # "name":Ljava/lang/String;
    .local v15, "name":Ljava/lang/String;
    const/4 v12, 0x0

    move/from16 v16, v13

    .end local v13    # "$dirty":I
    .local v16, "$dirty":I
    const/4 v13, 0x0

    move-object/from16 v18, v14

    move-object/from16 v17, v15

    .end local v14    # "context":Landroid/content/Context;
    .end local v15    # "name":Ljava/lang/String;
    .local v17, "name":Ljava/lang/String;
    .local v18, "context":Landroid/content/Context;
    const-wide/16 v14, 0x0

    move/from16 v19, v16

    .end local v16    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v16, 0x0

    move-object/from16 v20, v17

    .end local v17    # "name":Ljava/lang/String;
    .local v20, "name":Ljava/lang/String;
    const/16 v17, 0x0

    move-object/from16 v23, v18

    .end local v18    # "context":Landroid/content/Context;
    .local v23, "context":Landroid/content/Context;
    const/16 v18, 0x0

    move/from16 v24, v19

    .end local v19    # "$dirty":I
    .local v24, "$dirty":I
    const/16 v19, 0x0

    move-object/from16 v25, v20

    .end local v20    # "name":Ljava/lang/String;
    .local v25, "name":Ljava/lang/String;
    const/16 v20, 0x0

    move-object/from16 v26, v23

    .end local v23    # "context":Landroid/content/Context;
    .local v26, "context":Landroid/content/Context;
    const/16 v23, 0x30

    move/from16 v27, v24

    .end local v24    # "$dirty":I
    .local v27, "$dirty":I
    const/16 v24, 0x0

    move-object/from16 v28, v25

    .end local v25    # "name":Ljava/lang/String;
    .local v28, "name":Ljava/lang/String;
    const v25, 0xfff8

    move-object/from16 v29, v26

    .end local v26    # "context":Landroid/content/Context;
    .local v29, "context":Landroid/content/Context;
    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v6, v22

    .end local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_6

    .end local v27    # "$dirty":I
    .end local v28    # "name":Ljava/lang/String;
    .end local v29    # "context":Landroid/content/Context;
    .restart local v1    # "name":Ljava/lang/String;
    .restart local v2    # "context":Landroid/content/Context;
    .restart local v7    # "$dirty":I
    :cond_d
    move-object/from16 v28, v1

    move-object/from16 v29, v2

    move/from16 v27, v7

    .end local v1    # "name":Ljava/lang/String;
    .end local v2    # "context":Landroid/content/Context;
    .end local v7    # "$dirty":I
    .restart local v27    # "$dirty":I
    .restart local v28    # "name":Ljava/lang/String;
    .restart local v29    # "context":Landroid/content/Context;
    :goto_6
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 242
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getLayers()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getFileName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, ".itbase\uff0c\u6e90\u81ea "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;

    move/from16 v8, p2

    move-object/from16 v9, p3

    move-object/from16 v10, v29

    .end local v29    # "context":Landroid/content/Context;
    .local v10, "context":Landroid/content/Context;
    invoke-direct {v2, v0, v8, v9, v10}, Lorg/lighttouch/android/PrepareScreenKt$PreparedCopyStep$1;-><init>(Lorg/lighttouch/android/CatalogFirmware;ZLkotlin/jvm/functions/Function0;Landroid/content/Context;)V

    const/16 v3, 0x36

    const v5, 0x17351a8c

    const/4 v7, 0x1

    invoke-static {v5, v7, v2, v6, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Lkotlin/jvm/functions/Function3;

    const/16 v7, 0x61b0

    const-string v2, "\u5df2\u51c6\u5907\u7cfb\u7edf"

    const/4 v3, 0x0

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/PrepareScreenKt;->Card(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    .line 253
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xc

    .local v2, "$this$dp\\3":I
    const/4 v3, 0x0

    .line 607
    .local v3, "$i$f$getDp\\3\\253":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 253
    .end local v2    # "$this$dp\\3":I
    .end local v3    # "$i$f$getDp\\3\\253":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v6, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 254
    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareCatalogKt;->needsBootrom(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_e

    const-string v1, "\u6b64\u8bbe\u5907\u8fd8\u9700\u8981\u5f15\u5bfc\u6587\u4ef6\uff1b\u521b\u5efa\u540e\u53ef\u5230\u300c\u8bbe\u7f6e\u300d\u4e2d\u6dfb\u52a0\u3002"

    goto :goto_7

    .line 255
    :cond_e
    const-string v1, "\u6b64\u8bbe\u5907\u65e0\u9700\u5f15\u5bfc\u6587\u4ef6\uff0cLightTouch \u4f1a\u81ea\u52a8\u6dfb\u52a0\u5ba2\u6237\u673a\u5de5\u5177\u3002"

    .line 254
    :goto_7
    nop

    .line 256
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v6, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v6, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    .line 254
    nop

    .line 256
    nop

    .line 254
    const/4 v2, 0x0

    move-object/from16 v22, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v22    # "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v26, v10

    .end local v10    # "context":Landroid/content/Context;
    .restart local v26    # "context":Landroid/content/Context;
    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const v25, 0xfffa

    invoke-static/range {v1 .. v25}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    .end local v26    # "context":Landroid/content/Context;
    .end local v28    # "name":Ljava/lang/String;
    :cond_f
    :goto_8
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_10

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda21;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda21;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;I)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 257
    :cond_10
    return-void
.end method

.method private static final PreparedCopyStep$lambda$49(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/PrepareScreenKt;->PreparedCopyStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final PreparedCopyStep$lambda$50(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/PrepareScreenKt;->PreparedCopyStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final Progress(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 74
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "preparing"    # Z
    .param p2, "busy"    # Z
    .param p3, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onCancel"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onRetryImport"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onClose"    # Lkotlin/jvm/functions/Function0;
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/PrepareState;",
            "ZZ",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 357
    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move/from16 v8, p8

    const v0, -0x16f2a744

    move-object/from16 v4, p7

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Progress)P(6,5!1,3!1,4)361@23340L4189:PrepareScreen.kt#o13vsk"

    invoke-static {v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p8

    .local v4, "$dirty":I
    and-int/lit8 v5, v8, 0x6

    if-nez v5, :cond_1

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v8, 0x30

    if-nez v5, :cond_3

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_2

    const/16 v5, 0x20

    goto :goto_1

    :cond_2
    const/16 v5, 0x10

    :goto_1
    or-int/2addr v4, v5

    :cond_3
    and-int/lit16 v5, v8, 0x180

    if-nez v5, :cond_5

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x100

    goto :goto_2

    :cond_4
    const/16 v5, 0x80

    :goto_2
    or-int/2addr v4, v5

    :cond_5
    and-int/lit16 v5, v8, 0xc00

    if-nez v5, :cond_7

    move-object/from16 v10, p3

    invoke-interface {v9, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6

    const/16 v5, 0x800

    goto :goto_3

    :cond_6
    const/16 v5, 0x400

    :goto_3
    or-int/2addr v4, v5

    goto :goto_4

    :cond_7
    move-object/from16 v10, p3

    :goto_4
    and-int/lit16 v5, v8, 0x6000

    if-nez v5, :cond_9

    move-object/from16 v11, p4

    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_8

    const/16 v5, 0x4000

    goto :goto_5

    :cond_8
    const/16 v5, 0x2000

    :goto_5
    or-int/2addr v4, v5

    goto :goto_6

    :cond_9
    move-object/from16 v11, p4

    :goto_6
    const/high16 v5, 0x30000

    and-int/2addr v5, v8

    if-nez v5, :cond_b

    move-object/from16 v5, p5

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_a

    const/high16 v7, 0x20000

    goto :goto_7

    :cond_a
    const/high16 v7, 0x10000

    :goto_7
    or-int/2addr v4, v7

    goto :goto_8

    :cond_b
    move-object/from16 v5, p5

    :goto_8
    const v7, 0x12493

    and-int/2addr v7, v4

    const v12, 0x12492

    if-ne v7, v12, :cond_d

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v7

    if-nez v7, :cond_c

    goto :goto_9

    .line 846
    :cond_c
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v30, v4

    move-object/from16 v38, v9

    goto/16 :goto_2c

    .line 357
    :cond_d
    :goto_9
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_e

    const/4 v7, -0x1

    const-string v12, "org.lighttouch.android.Progress (PrepareScreen.kt:356)"

    invoke-static {v0, v4, v7, v12}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 358
    :cond_e
    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v0

    .line 359
    .local v0, "run":Landroid/os/Bundle;
    if-eqz v0, :cond_f

    const-string v7, "state"

    invoke-virtual {v0, v7}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_10

    :cond_f
    const-string v7, "starting"

    .line 360
    .local v7, "phase":Ljava/lang/String;
    :cond_10
    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v24

    .line 361
    .local v24, "firmware":Lorg/lighttouch/android/CatalogFirmware;
    if-eqz v24, :cond_11

    move-object/from16 v12, v24

    .line 565
    .local v12, "it\\1":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v13, 0x0

    .line 361
    .local v13, "$i$a$-let-PrepareScreenKt$Progress$title$1\\1\\361\\0":I
    invoke-virtual {v12}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v15

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v14, ", iOS "

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .end local v12    # "it\\1":Lorg/lighttouch/android/CatalogFirmware;
    .end local v13    # "$i$a$-let-PrepareScreenKt$Progress$title$1\\1\\361\\0":I
    if-nez v6, :cond_12

    :cond_11
    const-string v6, "\u4f60\u7684\u8bbe\u5907"

    .line 362
    .local v6, "title":Ljava/lang/String;
    :cond_12
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/4 v13, 0x0

    const/4 v14, 0x1

    const/4 v15, 0x0

    invoke-static {v12, v13, v14, v15}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    const/16 v12, 0x30

    .local v12, "$this$dp\\2":I
    const/16 v17, 0x0

    .line 736
    .local v17, "$i$f$getDp\\2\\362":I
    int-to-float v13, v12

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v18

    .line 362
    .end local v12    # "$this$dp\\2":I
    .end local v17    # "$i$f$getDp\\2\\362":I
    const/16 v21, 0xd

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .local v12, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .local v13, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v16, 0x186

    .local v16, "$changed\\3":I
    move/from16 v25, v16

    .end local v16    # "$changed\\3":I
    .local v25, "$changed\\3":I
    const/16 v26, 0x0

    .line 737
    .local v26, "$i$f$Column\\3\\362":I
    const v15, -0x1cd0f17e

    const-string v14, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v9, v15, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 738
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v14

    .line 742
    .local v14, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v15, v25, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v18, v25, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v15, v15, v18

    invoke-static {v14, v13, v9, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v18, v25, 0x3

    and-int/lit8 v18, v18, 0x70

    .line 743
    move/from16 v27, v18

    .local v27, "$changed\\4":I
    const/16 v28, 0x0

    .line 744
    .local v28, "$i$f$Layout\\4\\743":I
    const v2, -0x4ee9b9da

    const-string v3, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v9, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 745
    const/4 v2, 0x0

    invoke-static {v9, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v29

    .line 746
    .local v29, "compositeKeyHash\\4":I
    move-object/from16 v19, v14

    .end local v14    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v19, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 747
    .local v14, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v20, v2

    invoke-static {v9, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 749
    .local v2, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    move/from16 v30, v4

    .end local v4    # "$dirty":I
    .local v30, "$dirty":I
    shl-int/lit8 v4, v27, 0x6

    and-int/lit16 v4, v4, 0x380

    move/from16 v22, v4

    const/4 v4, 0x6

    or-int/lit8 v22, v22, 0x6

    .line 748
    move-object/from16 v31, v21

    .local v31, "factory\\5":Lkotlin/jvm/functions/Function0;
    move/from16 v32, v22

    .local v32, "$changed\\5":I
    const/16 v33, 0x0

    .line 750
    .local v33, "$i$f$ReusableComposeNode\\5\\748":I
    move/from16 v21, v4

    const v4, -0x2942ffcf

    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v9, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 751
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 752
    :cond_13
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 753
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_14

    .line 754
    move-object/from16 v4, v31

    .end local v31    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 756
    .end local v4    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v31    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_14
    move-object/from16 v4, v31

    .end local v31    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 758
    :goto_a
    move-object/from16 v31, v4

    .end local v4    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v31    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 759
    .local v34, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\758\\4":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v4, v15, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 760
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v4, v14, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 762
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 763
    .local v35, "$i$f$set-impl\\7\\762":I
    move-object/from16 v36, v4

    .local v36, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v37, 0x0

    .line 764
    .local v37, "$i$a$-with-Updater$set$1\\8\\763\\7":I
    invoke-interface/range {v36 .. v36}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v38

    if-nez v38, :cond_16

    move-object/from16 v38, v9

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v38, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v36 .. v36}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_15

    goto :goto_b

    :cond_15
    move-object/from16 v10, v36

    goto :goto_c

    .end local v38    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_16
    move-object/from16 v38, v9

    .line 765
    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v38    # "$composer":Landroidx/compose/runtime/Composer;
    :goto_b
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v36

    .end local v36    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 766
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v4, v9, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 768
    :goto_c
    nop

    .line 763
    .end local v10    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v37    # "$i$a$-with-Updater$set$1\\8\\763\\7":I
    nop

    .line 768
    nop

    .line 769
    .end local v8    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v35    # "$i$f$set-impl\\7\\762":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v4, v2, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 770
    nop

    .line 758
    .end local v4    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\758\\4":I
    nop

    .line 771
    shr-int/lit8 v4, v32, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\9":I
    move-object/from16 v8, v38

    .local v8, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 772
    .local v9, "$i$a$-Layout-ColumnKt$Column$1\\9\\771\\3":I
    const v10, -0x16ef5699

    move-object/from16 v34, v2

    .end local v2    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v34, "materialized\\4":Landroidx/compose/ui/Modifier;
    const-string v2, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v8, v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v10, v25, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v35, v10, 0x6

    .local v35, "$changed\\10":I
    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    .local v2, "$this$Progress_u24lambda_u2475\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v10, v8

    .local v10, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 363
    .local v36, "$i$a$-Column-PrepareScreenKt$Progress$1\\10\\772\\0":I
    move-object/from16 v37, v2

    .end local v2    # "$this$Progress_u24lambda_u2475\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .local v37, "$this$Progress_u24lambda_u2475\\10":Landroidx/compose/foundation/layout/ColumnScope;
    const v2, -0x508a593

    move/from16 v64, v4

    .end local v4    # "$changed\\9":I
    .local v64, "$changed\\9":I
    const-string v4, "C:PrepareScreen.kt#o13vsk"

    invoke-static {v10, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 364
    const-string v2, "CC(remember):PrepareScreen.kt#9igjgp"

    const-string v4, ""

    if-eqz p1, :cond_25

    const v3, -0x5093ae3

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "364@23552L10,364@23505L99,365@23621L29,369@24090L10,369@24135L11,368@23927L267,372@24408L30,376@24770L30,378@24980L10,378@25024L11,377@24817L266,379@25100L30,380@25147L137"

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 365
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u6b63\u5728\u51c6\u5907 "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v39

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v10, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v3, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    const/16 v62, 0x0

    const v63, 0xfdfe

    const/16 v40, 0x0

    const-wide/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    move-object/from16 v60, v10

    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v60, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 366
    move-object/from16 v3, v60

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x8

    .local v10, "$this$dp\\11":I
    const/16 v18, 0x0

    .line 773
    .local v18, "$i$f$getDp\\11\\366":I
    move-object/from16 v65, v4

    int-to-float v4, v10

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 366
    .end local v10    # "$this$dp\\11":I
    .end local v18    # "$i$f$getDp\\11\\366":I
    invoke-static {v5, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    move/from16 v5, v21

    invoke-static {v4, v3, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 368
    if-eqz v0, :cond_17

    const-string v4, "stage"

    invoke-virtual {v0, v4}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_18

    :cond_17
    move-object/from16 v4, v65

    :cond_18
    move-object/from16 v39, v4

    check-cast v39, Ljava/lang/CharSequence;

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/String;

    const-string v4, " \u2014 "

    aput-object v4, v5, v20

    const/16 v43, 0x2

    const/16 v44, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x2

    move-object/from16 v40, v5

    invoke-static/range {v39 .. v44}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 565
    .local v4, "it\\12":Ljava/util/List;
    const/4 v5, 0x0

    .line 368
    .local v5, "$i$a$-let-PrepareScreenKt$Progress$1$1\\12\\368\\10":I
    move/from16 p7, v5

    move/from16 v10, v20

    .end local v5    # "$i$a$-let-PrepareScreenKt$Progress$1$1\\12\\368\\10":I
    .local p7, "$i$a$-let-PrepareScreenKt$Progress$1$1\\12\\368\\10":I
    invoke-interface {v4, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v10

    move-object/from16 v66, v8

    const/4 v8, 0x1

    .end local v8    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\9":Landroidx/compose/runtime/Composer;
    if-ge v8, v10, :cond_19

    move/from16 v17, v8

    goto :goto_d

    :cond_19
    const/16 v17, 0x0

    :goto_d
    if-eqz v17, :cond_1a

    invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    goto :goto_e

    .line 565
    :cond_1a
    move v10, v8

    .local v10, "it\\13":I
    const/4 v8, 0x0

    .line 368
    .local v8, "$i$a$-getOrElse-PrepareScreenKt$Progress$1$1$1\\13\\368\\12":I
    move-object/from16 v10, v65

    .end local v8    # "$i$a$-getOrElse-PrepareScreenKt$Progress$1$1$1\\13\\368\\12":I
    .end local v10    # "it\\13":I
    :goto_e
    invoke-static {v5, v10}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .end local v4    # "it\\12":Ljava/util/List;
    .end local p7    # "$i$a$-let-PrepareScreenKt$Progress$1$1\\12\\368\\10":I
    invoke-virtual {v4}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .local v5, "stage\\10":Ljava/lang/String;
    invoke-virtual {v4}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 369
    .local v4, "elapsed\\10":Ljava/lang/String;
    const-string v8, "cancelling"

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1b

    const-string v10, "\u6b63\u5728\u53d6\u6d88\u2026"

    :goto_f
    move-object/from16 v39, v10

    goto :goto_11

    :cond_1b
    move-object v10, v5

    check-cast v10, Ljava/lang/CharSequence;

    invoke-interface {v10}, Ljava/lang/CharSequence;->length()I

    move-result v18

    if-nez v18, :cond_1c

    const/16 v18, 0x1

    goto :goto_10

    :cond_1c
    const/16 v18, 0x0

    :goto_10
    if-eqz v18, :cond_1d

    .line 565
    const/4 v10, 0x0

    .line 369
    .local v10, "$i$a$-ifEmpty-PrepareScreenKt$Progress$1$2\\14\\369\\10":I
    nop

    .end local v10    # "$i$a$-ifEmpty-PrepareScreenKt$Progress$1$2\\14\\369\\10":I
    const-string v10, "\u6b63\u5728\u542f\u52a8"

    :cond_1d
    check-cast v10, Ljava/lang/String;

    goto :goto_f

    :goto_11
    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v10, Landroidx/compose/ui/Modifier;

    move-object/from16 p7, v4

    .end local v4    # "elapsed\\10":Ljava/lang/String;
    .local p7, "elapsed\\10":Ljava/lang/String;
    const-string v4, "preparation_status"

    invoke-static {v10, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v40

    .line 370
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v3, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v3, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v41

    sget-object v4, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v4

    .line 369
    nop

    .line 370
    invoke-static {v4}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    .line 369
    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x30

    const/16 v62, 0x0

    const v63, 0xfdf8

    move-object/from16 v60, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    const v4, 0x20deffa6

    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "371@24318L10,371@24362L11,371@24282L109"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 371
    move-object/from16 v4, p7

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_1e

    const/16 v20, 0x1

    goto :goto_12

    :cond_1e
    const/16 v20, 0x0

    :goto_12
    if-eqz v20, :cond_1f

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1f

    .line 372
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v3, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v3, v10}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v41

    const/16 v62, 0x0

    const v63, 0xfffa

    const/16 v40, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    move-object/from16 v39, p7

    move-object/from16 v60, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local p7    # "elapsed\\10":Ljava/lang/String;
    .local v39, "elapsed\\10":Ljava/lang/String;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v4, v39

    .end local v39    # "elapsed\\10":Ljava/lang/String;
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v4    # "elapsed\\10":Ljava/lang/String;
    goto :goto_13

    .line 371
    .end local v4    # "elapsed\\10":Ljava/lang/String;
    .restart local p7    # "elapsed\\10":Ljava/lang/String;
    :cond_1f
    move-object/from16 v4, p7

    .line 372
    .end local p7    # "elapsed\\10":Ljava/lang/String;
    .restart local v4    # "elapsed\\10":Ljava/lang/String;
    :goto_13
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 373
    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v10, Landroidx/compose/ui/Modifier;

    move-object/from16 p7, v4

    .end local v4    # "elapsed\\10":Ljava/lang/String;
    .restart local p7    # "elapsed\\10":Ljava/lang/String;
    const/16 v4, 0x18

    .local v4, "$this$dp\\15":I
    const/16 v18, 0x0

    .line 774
    .local v18, "$i$f$getDp\\15\\373":I
    move-object/from16 v65, v5

    .end local v5    # "stage\\10":Ljava/lang/String;
    .local v65, "stage\\10":Ljava/lang/String;
    int-to-float v5, v4

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 373
    .end local v4    # "$this$dp\\15":I
    .end local v18    # "$i$f$getDp\\15\\373":I
    invoke-static {v10, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v5, 0x6

    invoke-static {v4, v3, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 374
    const-wide/16 v4, 0x0

    if-eqz v0, :cond_20

    const-string v10, "done"

    invoke-virtual {v0, v10}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v39

    goto :goto_14

    :cond_20
    move-wide/from16 v39, v4

    :goto_14
    move-wide/from16 v67, v39

    .local v67, "done\\10":J
    if-eqz v0, :cond_21

    const-string v10, "total"

    invoke-virtual {v0, v10}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v39

    goto :goto_15

    :cond_21
    move-wide/from16 v39, v4

    :goto_15
    move-wide/from16 v69, v39

    .line 375
    .local v69, "total\\10":J
    cmp-long v10, v69, v4

    if-lez v10, :cond_24

    cmp-long v4, v67, v4

    if-lez v4, :cond_24

    const v4, 0x20df2d1c

    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "374@24612L45,374@24577L106"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v4, -0x615d173a

    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-wide/from16 v4, v67

    .end local v67    # "done\\10":J
    .local v4, "done\\10":J
    invoke-interface {v3, v4, v5}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v2

    move-object/from16 v67, v14

    move-object v10, v15

    move-wide/from16 v14, v69

    .end local v15    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v69    # "total\\10":J
    .local v10, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v14, "total\\10":J
    .local v67, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface {v3, v14, v15}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v18

    or-int v2, v2, v18

    .local v2, "invalid\\16":Z
    move-object/from16 v18, v3

    .local v18, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 775
    .local v20, "$i$f$cache\\16\\375":I
    move/from16 v22, v2

    .end local v2    # "invalid\\16":Z
    .local v22, "invalid\\16":Z
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\16":Ljava/lang/Object;
    const/16 v39, 0x0

    .line 776
    .local v39, "$i$a$-let-ComposerKt$cache$1\\17\\775\\16":I
    if-nez v22, :cond_23

    sget-object v40, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v60, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v40 .. v40}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_22

    goto :goto_16

    .line 780
    :cond_22
    move-object/from16 v40, v2

    move-object/from16 v3, v18

    goto :goto_17

    .line 776
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_23
    move-object/from16 v60, v3

    .line 777
    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :goto_16
    const/4 v3, 0x0

    .line 375
    .local v3, "$i$a$-cache-PrepareScreenKt$Progress$1$3\\18\\777\\10":I
    move-object/from16 v40, v2

    .end local v2    # "it\\16":Ljava/lang/Object;
    .local v40, "it\\16":Ljava/lang/Object;
    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda23;

    invoke-direct {v2, v4, v5, v14, v15}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda23;-><init>(JJ)V

    .line 777
    .end local v3    # "$i$a$-cache-PrepareScreenKt$Progress$1$3\\18\\777\\10":I
    nop

    .line 778
    .local v2, "value\\17":Ljava/lang/Object;
    move-object/from16 v3, v18

    .end local v18    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .local v3, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 779
    nop

    .line 776
    .end local v2    # "value\\17":Ljava/lang/Object;
    :goto_17
    nop

    .line 775
    .end local v39    # "$i$a$-let-ComposerKt$cache$1\\17\\775\\16":I
    .end local v40    # "it\\16":Ljava/lang/Object;
    nop

    .line 375
    .end local v3    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$f$cache\\16\\375":I
    .end local v22    # "invalid\\16":Z
    move-object/from16 v39, v2

    check-cast v39, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v60 .. v60}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-wide/from16 v68, v4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    .end local v4    # "done\\10":J
    .local v68, "done\\10":J
    invoke-static {v2, v4, v5, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v40

    const/16 v49, 0x30

    const/16 v50, 0x7c

    const-wide/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    move-object/from16 v48, v60

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v50}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v3, v48

    .end local v48    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_18

    .end local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v68    # "done\\10":J
    .local v14, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v15    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v67, "done\\10":J
    .restart local v69    # "total\\10":J
    :cond_24
    move-object v10, v15

    move-wide/from16 v72, v67

    move-object/from16 v67, v14

    move-wide/from16 v14, v69

    move-wide/from16 v68, v72

    .line 376
    .end local v15    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v69    # "total\\10":J
    .restart local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v14, "total\\10":J
    .local v67, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v68    # "done\\10":J
    const v2, 0x20df3ce2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "375@24705L48"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v60, v3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v5, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v39

    const/16 v47, 0x6

    const/16 v48, 0x1e

    const-wide/16 v40, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    move-object/from16 v46, v60

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v48}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v3, v46

    .end local v46    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 377
    :goto_18
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xc

    .local v4, "$this$dp\\19":I
    const/4 v5, 0x0

    .line 781
    .local v5, "$i$f$getDp\\19\\377":I
    move/from16 v16, v5

    .end local v5    # "$i$f$getDp\\19\\377":I
    .local v16, "$i$f$getDp\\19\\377":I
    int-to-float v5, v4

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 377
    .end local v4    # "$this$dp\\19":I
    .end local v16    # "$i$f$getDp\\19\\377":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v5, 0x6

    invoke-static {v2, v3, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 378
    invoke-static/range {v24 .. v24}, Lorg/lighttouch/android/PrepareScreenKt;->preparationCost(Lorg/lighttouch/android/CatalogFirmware;)Lorg/lighttouch/android/PreparationCost;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/PreparationCost;->getTime()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u8fd9\u9700\u8981 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "\u3002\u4f60\u53ef\u4ee5\u79bb\u5f00 LightTouch\uff0c\u51c6\u5907\u4f1a\u5728\u540e\u53f0\u7ee7\u7eed\u3002"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v39

    .line 379
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v41

    sget-object v2, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v2

    .line 378
    nop

    .line 379
    invoke-static {v2}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    .line 378
    const/16 v40, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const v63, 0xfdfa

    move-object/from16 v60, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 380
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x18

    .local v4, "$this$dp\\20":I
    const/4 v5, 0x0

    .line 782
    .local v5, "$i$f$getDp\\20\\380":I
    move/from16 v16, v5

    .end local v5    # "$i$f$getDp\\20\\380":I
    .local v16, "$i$f$getDp\\20\\380":I
    int-to-float v5, v4

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 380
    .end local v4    # "$this$dp\\20":I
    .end local v16    # "$i$f$getDp\\20\\380":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v5, 0x6

    invoke-static {v2, v3, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 381
    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/16 v17, 0x1

    xor-int/lit8 v2, v2, 0x1

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const-string v5, "cancel_preparation"

    invoke-static {v4, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v5, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v5}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-76310244$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v20

    shr-int/lit8 v5, v30, 0xc

    and-int/lit8 v5, v5, 0xe

    const v8, 0x30000030

    or-int v22, v5, v8

    const/16 v23, 0x1f8

    move-wide/from16 v39, v14

    .end local v14    # "total\\10":J
    .local v39, "total\\10":J
    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v5, v19

    .end local v19    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v5, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v19, 0x0

    move-object v8, v12

    move-object v12, v4

    move-object v4, v8

    move-object/from16 v21, v3

    move-object/from16 v70, v10

    move-object v8, v13

    move-object/from16 v71, v67

    move v13, v2

    move-object/from16 v67, v5

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v5    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v4, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v8, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v21, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v67, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v70, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v71, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v11 .. v23}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 364
    move-object/from16 v10, v21

    .end local v21    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v39    # "total\\10":J
    .end local v65    # "stage\\10":Ljava/lang/String;
    .end local v68    # "done\\10":J
    .end local p7    # "elapsed\\10":Ljava/lang/String;
    .local v10, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v43, v0

    move-object/from16 v48, v4

    move-object/from16 v49, v6

    move-object/from16 v60, v10

    goto/16 :goto_2b

    .line 383
    .end local v4    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v66    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v67    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v70    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v71    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v8, "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v13    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .local v14, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v15    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v19    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_25
    move-object/from16 v65, v4

    move-object/from16 v66, v8

    move-object v4, v12

    move-object v8, v13

    move-object/from16 v71, v14

    move-object/from16 v70, v15

    move-object/from16 v67, v19

    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v14    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v4    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v8, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v66    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v67    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v70    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v71    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const-string v11, "complete"

    invoke-static {v7, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    const/high16 v13, 0x30000000

    if-eqz v12, :cond_27

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getImportError()Ljava/lang/String;

    move-result-object v12

    check-cast v12, Ljava/lang/CharSequence;

    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    move-result v12

    if-lez v12, :cond_26

    const/4 v12, 0x1

    goto :goto_19

    :cond_26
    const/4 v12, 0x0

    :goto_19
    if-eqz v12, :cond_27

    const v2, -0x4ed5c0b

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "383@25435L10,383@25386L101,384@25504L29,385@25636L10,386@25701L11,385@25550L199,387@25766L30,388@25813L80"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 384
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5df2\u51c6\u5907\u5c31\u7eea"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v39

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v2, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v2

    invoke-static {v2}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    const/16 v62, 0x0

    const v63, 0xfdfe

    const/16 v40, 0x0

    const-wide/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    move-object/from16 v60, v10

    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 385
    move-object/from16 v3, v60

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x8

    .local v5, "$this$dp\\21":I
    const/4 v10, 0x0

    .line 783
    .local v10, "$i$f$getDp\\21\\385":I
    int-to-float v11, v5

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 385
    .end local v5    # "$this$dp\\21":I
    .end local v10    # "$i$f$getDp\\21\\385":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v5, 0x6

    invoke-static {v2, v3, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 386
    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getImportError()Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "\u65e0\u6cd5\u5c06\u5176\u6dfb\u52a0\u4e3a\u8bbe\u5907\uff1a"

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v39

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    .line 387
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v41

    sget-object v2, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v2

    .line 386
    nop

    .line 387
    invoke-static {v2}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    .line 386
    const v63, 0xfdfa

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 388
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x18

    .local v5, "$this$dp\\22":I
    const/4 v10, 0x0

    .line 784
    .local v10, "$i$f$getDp\\22\\388":I
    int-to-float v11, v5

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 388
    .end local v5    # "$this$dp\\22":I
    .end local v10    # "$i$f$getDp\\22\\388":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v5, 0x6

    invoke-static {v2, v3, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 389
    move v10, v13

    xor-int/lit8 v13, p2, 0x1

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$233933123$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v20

    shr-int/lit8 v2, v30, 0xf

    and-int/lit8 v2, v2, 0xe

    or-int v22, v2, v10

    const/16 v23, 0x1fa

    const/4 v12, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v11, p5

    move-object/from16 v21, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v21    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v23}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 383
    move-object/from16 v12, v21

    .end local v21    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v12, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v43, v0

    move-object/from16 v48, v4

    move-object/from16 v49, v6

    move-object/from16 v60, v12

    goto/16 :goto_2b

    .end local v12    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_27
    move-object v12, v10

    move v10, v13

    .line 391
    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v7, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_2e

    const v3, -0x4e49108

    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "391@26005L10,391@25961L96,392@26074L29,395@26340L10,395@26385L11,394@26172L242,396@26431L30"

    invoke-static {v12, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 392
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u6b63\u5728\u6dfb\u52a0 "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v39

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v12, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v3, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    const/16 v62, 0x0

    const v63, 0xfdfe

    const/16 v40, 0x0

    const-wide/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    move-object/from16 v60, v12

    .end local v12    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 393
    move-object/from16 v3, v60

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x8

    .local v10, "$this$dp\\23":I
    const/4 v11, 0x0

    .line 785
    .local v11, "$i$f$getDp\\23\\393":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 393
    .end local v10    # "$this$dp\\23":I
    .end local v11    # "$i$f$getDp\\23\\393":I
    invoke-static {v5, v10}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v10, 0x6

    invoke-static {v5, v3, v10}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 394
    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getImportProgress()F

    move-result v5

    .line 395
    .local v5, "fraction\\10":F
    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getImportPhase()Ljava/lang/String;

    move-result-object v10

    check-cast v10, Ljava/lang/CharSequence;

    invoke-interface {v10}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-nez v11, :cond_28

    const/16 v20, 0x1

    goto :goto_1a

    :cond_28
    const/16 v20, 0x0

    :goto_1a
    if-eqz v20, :cond_29

    .line 565
    const/4 v10, 0x0

    .line 395
    .local v10, "$i$a$-ifEmpty-PrepareScreenKt$Progress$1$4\\24\\395\\10":I
    nop

    .end local v10    # "$i$a$-ifEmpty-PrepareScreenKt$Progress$1$4\\24\\395\\10":I
    const-string v10, "\u6b63\u5728\u8bbe\u7f6e iOS \u7cfb\u7edf\u2026"

    :cond_29
    const/16 v23, 0x0

    cmpl-float v11, v5, v23

    if-ltz v11, :cond_2a

    const/16 v11, 0x64

    int-to-float v11, v11

    mul-float/2addr v11, v5

    float-to-int v11, v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, " "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v11

    const-string v12, "%"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    goto :goto_1b

    :cond_2a
    move-object/from16 v11, v65

    :goto_1b
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v39

    .line 396
    sget-object v10, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v10, v3, v11}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v10, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v10, v3, v11}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v41

    .line 395
    nop

    .line 396
    nop

    .line 395
    const/16 v40, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const v63, 0xfffa

    move-object/from16 v60, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 397
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v10, Landroidx/compose/ui/Modifier;

    const/16 v11, 0x18

    .local v11, "$this$dp\\25":I
    const/4 v12, 0x0

    .line 786
    .local v12, "$i$f$getDp\\25\\397":I
    int-to-float v13, v11

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 397
    .end local v11    # "$this$dp\\25":I
    .end local v12    # "$i$f$getDp\\25\\397":I
    invoke-static {v10, v11}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v10

    const/4 v11, 0x6

    invoke-static {v10, v3, v11}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 398
    const/16 v23, 0x0

    cmpl-float v10, v5, v23

    if-ltz v10, :cond_2d

    const v10, 0x20e01d0c

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "397@26532L29,397@26497L90"

    invoke-static {v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v10, 0x4c5de2

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v2

    .local v2, "invalid\\26":Z
    move-object v10, v3

    .local v10, "$this$cache\\26":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 787
    .local v11, "$i$f$cache\\26\\398":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\26":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 788
    .local v13, "$i$a$-let-ComposerKt$cache$1\\27\\787\\26":I
    if-nez v2, :cond_2c

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v12, v14, :cond_2b

    goto :goto_1c

    .line 792
    :cond_2b
    move-object v15, v12

    goto :goto_1d

    .line 789
    :cond_2c
    :goto_1c
    const/4 v14, 0x0

    .line 398
    .local v14, "$i$a$-cache-PrepareScreenKt$Progress$1$5\\28\\789\\10":I
    new-instance v15, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda24;

    invoke-direct {v15, v5}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda24;-><init>(F)V

    .line 789
    .end local v14    # "$i$a$-cache-PrepareScreenKt$Progress$1$5\\28\\789\\10":I
    nop

    .line 790
    .local v15, "value\\27":Ljava/lang/Object;
    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 791
    nop

    .line 788
    .end local v15    # "value\\27":Ljava/lang/Object;
    :goto_1d
    nop

    .line 787
    .end local v12    # "it\\26":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\27\\787\\26":I
    nop

    .line 398
    .end local v2    # "invalid\\26":Z
    .end local v10    # "$this$cache\\26":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\26\\398":I
    move-object/from16 v39, v15

    check-cast v39, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v2, v11, v12, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v40

    const/16 v49, 0x30

    const/16 v50, 0x7c

    const-wide/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    move-object/from16 v48, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v48    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v50}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .end local v48    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v13, v3

    goto :goto_1e

    .line 399
    :cond_2d
    const v2, 0x20e02ae2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "398@26609L48"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v2, v10, v12, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v39

    const/16 v47, 0x6

    const/16 v48, 0x1e

    const-wide/16 v40, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    move-object/from16 v46, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v46    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v48}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v13, v46

    .end local v46    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v13, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 391
    .end local v5    # "fraction\\10":F
    :goto_1e
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v43, v0

    move-object/from16 v48, v4

    move-object/from16 v49, v6

    move-object/from16 v60, v13

    goto/16 :goto_2b

    .line 401
    .end local v13    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v12, "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_2e
    move-object v13, v12

    const/4 v11, 0x0

    const/4 v12, 0x1

    .end local v12    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v13    # "$composer\\10":Landroidx/compose/runtime/Composer;
    const v14, -0x4d92f65

    invoke-interface {v13, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v14, "401@26814L10,401@26710L126,402@26853L29,406@27161L30,407@27208L291"

    invoke-static {v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 402
    const-string v14, "cancelled"

    invoke-static {v7, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_2f

    const-string v15, "\u51c6\u5907\u5df2\u53d6\u6d88"

    goto :goto_1f

    :cond_2f
    const-string v15, "\u51c6\u5907\u5931\u8d25"

    :goto_1f
    move-object/from16 v39, v15

    sget-object v15, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move/from16 v16, v10

    sget v10, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v15, v13, v10}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    const/16 v62, 0x0

    const v63, 0xfffe

    const/16 v40, 0x0

    const-wide/16 v41, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    move-object/from16 v60, v13

    .end local v13    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 403
    move-object/from16 v10, v60

    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v13, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v13, Landroidx/compose/ui/Modifier;

    const/16 v15, 0x8

    .local v15, "$this$dp\\29":I
    const/16 v17, 0x0

    .line 793
    .local v17, "$i$f$getDp\\29\\403":I
    int-to-float v11, v15

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 403
    .end local v15    # "$this$dp\\29":I
    .end local v17    # "$i$f$getDp\\29\\403":I
    invoke-static {v13, v11}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/4 v13, 0x6

    invoke-static {v11, v10, v13}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 404
    if-eqz v0, :cond_32

    const-string v11, "error"

    invoke-virtual {v0, v11}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_32

    move-object v13, v11

    .line 565
    .local v13, "it\\30":Ljava/lang/String;
    const/4 v15, 0x0

    .line 404
    .local v15, "$i$a$-takeIf-PrepareScreenKt$Progress$1$6\\30\\404\\10":I
    move-object/from16 v17, v13

    check-cast v17, Ljava/lang/CharSequence;

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->length()I

    move-result v17

    if-lez v17, :cond_30

    move/from16 v17, v12

    goto :goto_20

    :cond_30
    const/16 v17, 0x0

    :goto_20
    if-eqz v17, :cond_31

    invoke-static {v7, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_31

    move v13, v12

    goto :goto_21

    :cond_31
    const/4 v13, 0x0

    .end local v13    # "it\\30":Ljava/lang/String;
    .end local v15    # "$i$a$-takeIf-PrepareScreenKt$Progress$1$6\\30\\404\\10":I
    :goto_21
    if-eqz v13, :cond_32

    move-object/from16 v39, v11

    goto :goto_22

    :cond_32
    const/16 v39, 0x0

    :goto_22
    const v11, 0x20e0593a

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "*404@27033L10,404@27078L11,404@27002L124"

    invoke-static {v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v39, :cond_33

    goto :goto_23

    .local v39, "it\\31":Ljava/lang/String;
    :cond_33
    const/4 v11, 0x0

    .line 405
    .local v11, "$i$a$-let-PrepareScreenKt$Progress$1$7\\31\\404\\10":I
    sget-object v13, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v13, v10, v14}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v13

    invoke-virtual {v13}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v59

    sget-object v13, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v13, v10, v14}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v13

    invoke-virtual {v13}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v41

    sget-object v13, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v13

    invoke-static {v13}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v51

    const/16 v62, 0x0

    const v63, 0xfdfa

    const/16 v40, 0x0

    const-wide/16 v43, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v61, 0x0

    move-object/from16 v60, v10

    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v39 .. v63}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 406
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    nop

    .end local v11    # "$i$a$-let-PrepareScreenKt$Progress$1$7\\31\\404\\10":I
    .end local v39    # "it\\31":Ljava/lang/String;
    sget-object v11, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 404
    sget-object v11, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_23
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 407
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    const/16 v13, 0x18

    .local v13, "$this$dp\\32":I
    const/4 v14, 0x0

    .line 794
    .local v14, "$i$f$getDp\\32\\407":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 407
    .end local v13    # "$this$dp\\32":I
    .end local v14    # "$i$f$getDp\\32\\407":I
    invoke-static {v11, v13}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/4 v13, 0x6

    invoke-static {v11, v10, v13}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 408
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v13, 0x8

    .local v13, "$this$dp\\33":I
    const/4 v14, 0x0

    .line 795
    .local v14, "$i$f$getDp\\33\\408":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 408
    .end local v13    # "$this$dp\\33":I
    .end local v14    # "$i$f$getDp\\33\\408":I
    invoke-virtual {v11, v13}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v11

    check-cast v11, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v11, "horizontalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v13, 0x30

    .local v13, "$changed\\34":I
    move/from16 v23, v13

    .end local v13    # "$changed\\34":I
    .local v23, "$changed\\34":I
    const/16 v39, 0x0

    .line 796
    .local v39, "$i$f$Row\\34\\408":I
    const v13, 0x2952b718

    const-string v14, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v10, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 797
    sget-object v13, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v13, Landroidx/compose/ui/Modifier;

    .line 799
    .local v13, "modifier\\34":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v14

    .line 802
    .local v14, "verticalAlignment\\34":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v15, v23, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v17, v23, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v15, v15, v17

    invoke-static {v11, v14, v10, v15}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v23, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 803
    move/from16 v40, v17

    .local v40, "$changed\\35":I
    const/16 v41, 0x0

    .line 804
    .local v41, "$i$f$Layout\\35\\803":I
    const v12, -0x4ee9b9da

    invoke-static {v10, v12, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 805
    const/4 v3, 0x0

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v42

    .line 806
    .local v42, "compositeKeyHash\\35":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 807
    .local v12, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 809
    .local v3, "materialized\\35":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v43, v0

    .end local v0    # "run":Landroid/os/Bundle;
    .local v43, "run":Landroid/os/Bundle;
    shl-int/lit8 v0, v40, 0x6

    and-int/lit16 v0, v0, 0x380

    const/16 v21, 0x6

    or-int/lit8 v0, v0, 0x6

    .line 808
    nop

    .local v0, "$changed\\36":I
    move-object/from16 v44, v18

    .local v44, "factory\\36":Lkotlin/jvm/functions/Function0;
    const/16 v45, 0x0

    .line 810
    .local v45, "$i$f$ReusableComposeNode\\36\\808":I
    move/from16 v46, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\36":I
    .local v46, "$changed\\36":I
    invoke-static {v10, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 811
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_34

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 812
    :cond_34
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 813
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_35

    .line 814
    move-object/from16 v0, v44

    .end local v44    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_24

    .line 816
    .end local v0    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\36":Lkotlin/jvm/functions/Function0;
    :cond_35
    move-object/from16 v0, v44

    .end local v44    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 818
    :goto_24
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 819
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\37\\818\\35":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v44, v0

    .end local v0    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 820
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 822
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\38":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 823
    .local v19, "$i$f$set-impl\\38\\822":I
    move-object/from16 v22, v5

    .local v22, "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 824
    .local v47, "$i$a$-with-Updater$set$1\\39\\823\\38":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v48

    if-nez v48, :cond_37

    move-object/from16 v48, v4

    .end local v4    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v48, "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v49, v6

    .end local v6    # "title":Ljava/lang/String;
    .local v49, "title":Ljava/lang/String;
    invoke-static/range {v42 .. v42}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_36

    goto :goto_25

    :cond_36
    move-object/from16 v6, v22

    goto :goto_26

    .end local v48    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v49    # "title":Ljava/lang/String;
    .restart local v4    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v6    # "title":Ljava/lang/String;
    :cond_37
    move-object/from16 v48, v4

    move-object/from16 v49, v6

    .line 825
    .end local v4    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v6    # "title":Ljava/lang/String;
    .restart local v48    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v49    # "title":Ljava/lang/String;
    :goto_25
    invoke-static/range {v42 .. v42}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v6, v22

    .end local v22    # "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 826
    invoke-static/range {v42 .. v42}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 828
    :goto_26
    nop

    .line 823
    .end local v6    # "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .end local v47    # "$i$a$-with-Updater$set$1\\39\\823\\38":I
    nop

    .line 828
    nop

    .line 829
    .end local v0    # "block\\38":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\38\\822":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 830
    nop

    .line 818
    .end local v5    # "$this$Layout_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\37\\818\\35":I
    nop

    .line 831
    shr-int/lit8 v0, v46, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\40":I
    move-object v4, v10

    .local v4, "$composer\\40":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 832
    .local v5, "$i$a$-Layout-RowKt$Row$1\\40\\831\\34":I
    const v6, -0x184f2606

    move/from16 v47, v0

    .end local v0    # "$changed\\40":I
    .local v47, "$changed\\40":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v4, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v23, 0x6

    and-int/lit8 v6, v6, 0x70

    const/16 v21, 0x6

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\41":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$Progress_u24lambda_u2475_u24lambda_u2474\\41":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v60, v4

    .local v60, "$composer\\41":Landroidx/compose/runtime/Composer;
    const/16 v63, 0x0

    .line 409
    .local v63, "$i$a$-Row-PrepareScreenKt$Progress$1$8\\41\\832\\10":I
    move-object/from16 v65, v0

    .end local v0    # "$this$Progress_u24lambda_u2475_u24lambda_u2474\\41":Landroidx/compose/foundation/layout/RowScope;
    .local v65, "$this$Progress_u24lambda_u2475_u24lambda_u2474\\41":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x40477557

    move-object/from16 v68, v3

    .end local v3    # "materialized\\35":Landroidx/compose/ui/Modifier;
    .local v68, "materialized\\35":Landroidx/compose/ui/Modifier;
    const-string v3, "C408@27311L28,408@27286L71,409@27378L103:PrepareScreen.kt#o13vsk"

    move-object/from16 v69, v4

    .end local v60    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v69, "$composer\\40":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, 0x4c5de2

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v30, 0xe

    const/4 v2, 0x4

    if-ne v0, v2, :cond_38

    const/4 v0, 0x1

    goto :goto_27

    :cond_38
    const/4 v0, 0x0

    .local v0, "invalid\\42":Z
    :goto_27
    move-object v2, v4

    .local v2, "$this$cache\\42":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 833
    .local v3, "$i$f$cache\\42\\409":I
    move/from16 p7, v0

    .end local v0    # "invalid\\42":Z
    .local p7, "invalid\\42":Z
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\42":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 834
    .local v18, "$i$a$-let-ComposerKt$cache$1\\43\\833\\42":I
    if-nez p7, :cond_3a

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v21, v3

    .end local v3    # "$i$f$cache\\42\\409":I
    .local v21, "$i$f$cache\\42\\409":I
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v0, v3, :cond_39

    goto :goto_28

    .line 838
    :cond_39
    move-object/from16 v19, v0

    goto :goto_29

    .line 834
    .end local v21    # "$i$f$cache\\42\\409":I
    .restart local v3    # "$i$f$cache\\42\\409":I
    :cond_3a
    move/from16 v21, v3

    .line 835
    .end local v3    # "$i$f$cache\\42\\409":I
    .restart local v21    # "$i$f$cache\\42\\409":I
    :goto_28
    const/4 v3, 0x0

    .line 409
    .local v3, "$i$a$-cache-PrepareScreenKt$Progress$1$8$1\\44\\835\\41":I
    move-object/from16 v19, v0

    .end local v0    # "it\\42":Ljava/lang/Object;
    .local v19, "it\\42":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v0, v1}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/PrepareState;)V

    .line 835
    .end local v3    # "$i$a$-cache-PrepareScreenKt$Progress$1$8$1\\44\\835\\41":I
    nop

    .line 836
    .local v0, "value\\43":Ljava/lang/Object;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 837
    nop

    .line 834
    .end local v0    # "value\\43":Ljava/lang/Object;
    :goto_29
    nop

    .line 833
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\43\\833\\42":I
    .end local v19    # "it\\42":Ljava/lang/Object;
    nop

    .line 409
    .end local v2    # "$this$cache\\42":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$f$cache\\42\\409":I
    .end local p7    # "invalid\\42":Z
    move-object/from16 v50, v0

    check-cast v50, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$-927593527$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v59

    const/high16 v61, 0x30000000

    const/16 v62, 0x1fe

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    move-object/from16 v60, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v60    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v50 .. v62}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 410
    if-nez p2, :cond_3b

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v0

    if-eqz v0, :cond_3b

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v0

    if-eqz v0, :cond_3b

    const/16 v17, 0x1

    goto :goto_2a

    :cond_3b
    const/16 v17, 0x0

    :goto_2a
    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$PrepareScreenKt;->getLambda$327637703$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v19

    shr-int/lit8 v0, v30, 0x9

    and-int/lit8 v0, v0, 0xe

    or-int v21, v0, v16

    const/16 v22, 0x1fa

    move-object v0, v11

    .end local v11    # "horizontalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v0, "horizontalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/4 v11, 0x0

    move-object v2, v13

    .end local v13    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .local v2, "modifier\\34":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    move-object v3, v14

    .end local v14    # "verticalAlignment\\34":Landroidx/compose/ui/Alignment$Vertical;
    .local v3, "verticalAlignment\\34":Landroidx/compose/ui/Alignment$Vertical;
    const/4 v14, 0x0

    move-object v4, v15

    .end local v15    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v4, "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v15, 0x0

    const/16 v16, 0x0

    move-object/from16 v18, v12

    move/from16 v12, v17

    .end local v12    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .local v18, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v17, 0x0

    move-object/from16 v20, v18

    .end local v18    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .local v20, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v18, 0x0

    move-object/from16 v50, v20

    move-object/from16 v20, v60

    move-object/from16 v60, v10

    move-object/from16 v10, p3

    .end local v10    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v50, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .local v60, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v22}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 409
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 411
    nop

    .line 832
    .end local v6    # "$changed\\41":I
    .end local v20    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v63    # "$i$a$-Row-PrepareScreenKt$Progress$1$8\\41\\832\\10":I
    .end local v65    # "$this$Progress_u24lambda_u2475_u24lambda_u2474\\41":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v69 .. v69}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 831
    .end local v5    # "$i$a$-Layout-RowKt$Row$1\\40\\831\\34":I
    .end local v47    # "$changed\\40":I
    .end local v69    # "$composer\\40":Landroidx/compose/runtime/Composer;
    nop

    .line 839
    invoke-interface/range {v60 .. v60}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 810
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 840
    nop

    .line 804
    .end local v44    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .end local v45    # "$i$f$ReusableComposeNode\\36\\808":I
    .end local v46    # "$changed\\36":I
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 841
    nop

    .line 796
    .end local v40    # "$changed\\35":I
    .end local v41    # "$i$f$Layout\\35\\803":I
    .end local v42    # "compositeKeyHash\\35":I
    .end local v50    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v68    # "materialized\\35":Landroidx/compose/ui/Modifier;
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 842
    nop

    .line 401
    .end local v0    # "horizontalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v2    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .end local v3    # "verticalAlignment\\34":Landroidx/compose/ui/Alignment$Vertical;
    .end local v4    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "$changed\\34":I
    .end local v39    # "$i$f$Row\\34\\408":I
    invoke-interface/range {v60 .. v60}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 363
    :goto_2b
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 414
    nop

    .line 772
    .end local v35    # "$changed\\10":I
    .end local v36    # "$i$a$-Column-PrepareScreenKt$Progress$1\\10\\772\\0":I
    .end local v37    # "$this$Progress_u24lambda_u2475\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v60    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v66 .. v66}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 771
    .end local v9    # "$i$a$-Layout-ColumnKt$Column$1\\9\\771\\3":I
    .end local v64    # "$changed\\9":I
    .end local v66    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 843
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 750
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 844
    nop

    .line 744
    .end local v31    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v32    # "$changed\\5":I
    .end local v33    # "$i$f$ReusableComposeNode\\5\\748":I
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 845
    nop

    .line 737
    .end local v27    # "$changed\\4":I
    .end local v28    # "$i$f$Layout\\4\\743":I
    .end local v29    # "compositeKeyHash\\4":I
    .end local v34    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v71    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 846
    nop

    .end local v8    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v25    # "$changed\\3":I
    .end local v26    # "$i$f$Column\\3\\362":I
    .end local v48    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v67    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v70    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v7    # "phase":Ljava/lang/String;
    .end local v24    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    .end local v43    # "run":Landroid/os/Bundle;
    .end local v49    # "title":Ljava/lang/String;
    :cond_3c
    :goto_2c
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_3d

    new-instance v0, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda2;

    move/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move/from16 v8, p8

    invoke-direct/range {v0 .. v8}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 415
    :cond_3d
    return-void
.end method

.method private static final Progress$lambda$75$lambda$66$lambda$65(JJ)F
    .locals 3
    .param p0, "$done"    # J
    .param p2, "$total"    # J

    .line 375
    long-to-float v0, p0

    long-to-float v1, p2

    div-float/2addr v0, v1

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    return v0
.end method

.method private static final Progress$lambda$75$lambda$69$lambda$68(F)F
    .locals 2
    .param p0, "$fraction"    # F

    .line 398
    const/4 v0, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {p0, v0, v1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    return v0
.end method

.method private static final Progress$lambda$75$lambda$74$lambda$73$lambda$72(Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$state"    # Lorg/lighttouch/android/PrepareState;

    .line 409
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Progress$lambda$76(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 10

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p8

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/PrepareScreenKt;->Progress(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 26
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 140
    move-object/from16 v0, p0

    const v1, 0x462adaf9

    move-object/from16 v2, p1

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(SectionLabel)140@7914L10,140@7959L11,140@7835L153:PrepareScreen.kt#o13vsk"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, p2, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 141
    :cond_2
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v21, v2

    move/from16 v25, v3

    goto/16 :goto_2

    .line 140
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.SectionLabel (PrepareScreen.kt:139)"

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 141
    :cond_4
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v4, v1

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x10

    .local v1, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 437
    .local v5, "$i$f$getDp\\1\\141":I
    int-to-float v6, v1

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 141
    .end local v1    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\141":I
    const/4 v1, 0x6

    .local v1, "$this$dp\\2":I
    const/4 v5, 0x0

    .line 437
    .local v5, "$i$f$getDp\\2\\141":I
    int-to-float v7, v1

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 141
    .end local v1    # "$this$dp\\2":I
    .end local v5    # "$i$f$getDp\\2\\141":I
    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v2, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v20

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v2, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v4

    and-int/lit8 v6, v3, 0xe

    or-int/lit8 v22, v6, 0x30

    const/16 v23, 0x0

    const v24, 0xfff8

    move-object/from16 v21, v2

    move v6, v3

    move-wide v2, v4

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .local v6, "$dirty":I
    .local v21, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v4, 0x0

    move v7, v6

    .end local v6    # "$dirty":I
    .local v7, "$dirty":I
    const/4 v6, 0x0

    move v8, v7

    .end local v7    # "$dirty":I
    .local v8, "$dirty":I
    const/4 v7, 0x0

    move v9, v8

    .end local v8    # "$dirty":I
    .local v9, "$dirty":I
    const/4 v8, 0x0

    move v11, v9

    .end local v9    # "$dirty":I
    .local v11, "$dirty":I
    const-wide/16 v9, 0x0

    move v12, v11

    .end local v11    # "$dirty":I
    .local v12, "$dirty":I
    const/4 v11, 0x0

    move v13, v12

    .end local v12    # "$dirty":I
    .local v13, "$dirty":I
    const/4 v12, 0x0

    move v15, v13

    .end local v13    # "$dirty":I
    .local v15, "$dirty":I
    const-wide/16 v13, 0x0

    move/from16 v16, v15

    .end local v15    # "$dirty":I
    .local v16, "$dirty":I
    const/4 v15, 0x0

    move/from16 v17, v16

    .end local v16    # "$dirty":I
    .local v17, "$dirty":I
    const/16 v16, 0x0

    move/from16 v18, v17

    .end local v17    # "$dirty":I
    .local v18, "$dirty":I
    const/16 v17, 0x0

    move/from16 v19, v18

    .end local v18    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v18, 0x0

    move/from16 v25, v19

    .end local v19    # "$dirty":I
    .local v25, "$dirty":I
    const/16 v19, 0x0

    invoke-static/range {v0 .. v24}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_5
    :goto_2
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_6

    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda0;

    move/from16 v3, p2

    invoke-direct {v2, v0, v3}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_3

    :cond_6
    move/from16 v3, p2

    .line 142
    :goto_3
    return-void
.end method

.method private static final SectionLabel$lambda$15(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/PrepareScreenKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SupportBadge(Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V
    .locals 29
    .param p0, "support"    # Lorg/lighttouch/android/Support;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 159
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x648887a

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(SupportBadge)166@9457L10,165@9260L234:PrepareScreen.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_1

    move-object v5, v0

    check-cast v5, Ljava/lang/Enum;

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    move v5, v6

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v4, 0x3

    if-ne v5, v6, :cond_3

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_1

    .line 166
    :cond_2
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v2, v4

    goto/16 :goto_3

    .line 159
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_4

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.SupportBadge (PrepareScreen.kt:158)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 160
    :cond_4
    sget-object v2, Lorg/lighttouch/android/PrepareScreenKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v0}, Lorg/lighttouch/android/Support;->ordinal()I

    move-result v5

    aget v2, v2, v5

    packed-switch v2, :pswitch_data_0

    move v2, v4

    .end local v4    # "$dirty":I
    .local v2, "$dirty":I
    const v4, 0x69b7b832

    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v4, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v4}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v4

    .line 164
    .end local v2    # "$dirty":I
    .restart local v4    # "$dirty":I
    :pswitch_0
    const v2, 0x69b7d5f6

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "163@9221L11"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_2

    .line 163
    :pswitch_1
    const v2, 0x69b7ce2d

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtColors;->getWarning-0d7_KjU()J

    move-result-wide v5

    goto :goto_2

    .line 162
    :pswitch_2
    const v2, 0x69b7c7ee

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "161@9109L11"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getTertiary-0d7_KjU()J

    move-result-wide v5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_2

    .line 161
    :pswitch_3
    const v2, 0x69b7bfcd

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "160@9044L11"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v5

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 160
    :goto_2
    nop

    .line 166
    .local v5, "color":J
    invoke-virtual {v0}, Lorg/lighttouch/android/Support;->getLabel()Ljava/lang/String;

    move-result-object v2

    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v8, v7

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/16 v7, 0xc

    .local v7, "$this$dp\\1":I
    const/4 v9, 0x0

    .line 521
    .local v9, "$i$f$getDp\\1\\166":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 166
    .end local v7    # "$this$dp\\1":I
    .end local v9    # "$i$f$getDp\\1\\166":I
    const/16 v13, 0xe

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const/16 v8, 0x8

    .local v8, "$this$dp\\2":I
    const/4 v9, 0x0

    .line 521
    .local v9, "$i$f$getDp\\2\\166":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 166
    .end local v8    # "$this$dp\\2":I
    .end local v9    # "$i$f$getDp\\2\\166":I
    invoke-static {v8}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v8

    check-cast v8, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v7, v8}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    const v9, 0x3e0f5c29    # 0.14f

    const/4 v10, 0x0

    move-wide v7, v5

    .end local v5    # "color":J
    .local v7, "color":J
    invoke-static/range {v7 .. v14}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v10

    .end local v7    # "color":J
    .restart local v5    # "color":J
    const/4 v13, 0x2

    const/4 v12, 0x0

    move-object v9, v15

    invoke-static/range {v9 .. v14}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 167
    const/16 v8, 0x8

    .local v8, "$this$dp\\3":I
    const/4 v9, 0x0

    .line 522
    .local v9, "$i$f$getDp\\3\\167":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 167
    .end local v8    # "$this$dp\\3":I
    .end local v9    # "$i$f$getDp\\3\\167":I
    const/4 v9, 0x3

    .local v9, "$this$dp\\4":I
    const/4 v10, 0x0

    .line 522
    .local v10, "$i$f$getDp\\4\\167":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 167
    .end local v9    # "$this$dp\\4":I
    .end local v10    # "$i$f$getDp\\4\\167":I
    invoke-static {v7, v8, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v7

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v3, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/Typography;->getLabelSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v23

    .line 166
    nop

    .line 167
    nop

    .line 166
    move v9, v4

    move-object v4, v7

    .end local v4    # "$dirty":I
    .local v9, "$dirty":I
    const-wide/16 v7, 0x0

    move v10, v9

    .end local v9    # "$dirty":I
    .local v10, "$dirty":I
    const/4 v9, 0x0

    move v11, v10

    .end local v10    # "$dirty":I
    .local v11, "$dirty":I
    const/4 v10, 0x0

    move v12, v11

    .end local v11    # "$dirty":I
    .local v12, "$dirty":I
    const/4 v11, 0x0

    move v14, v12

    .end local v12    # "$dirty":I
    .local v14, "$dirty":I
    const-wide/16 v12, 0x0

    move v15, v14

    .end local v14    # "$dirty":I
    .local v15, "$dirty":I
    const/4 v14, 0x0

    move/from16 v16, v15

    .end local v15    # "$dirty":I
    .local v16, "$dirty":I
    const/4 v15, 0x0

    move/from16 v18, v16

    .end local v16    # "$dirty":I
    .local v18, "$dirty":I
    const-wide/16 v16, 0x0

    move/from16 v19, v18

    .end local v18    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v18, 0x0

    move/from16 v20, v19

    .end local v19    # "$dirty":I
    .local v20, "$dirty":I
    const/16 v19, 0x0

    move/from16 v21, v20

    .end local v20    # "$dirty":I
    .local v21, "$dirty":I
    const/16 v20, 0x0

    move/from16 v22, v21

    .end local v21    # "$dirty":I
    .local v22, "$dirty":I
    const/16 v21, 0x0

    move/from16 v24, v22

    .end local v22    # "$dirty":I
    .local v24, "$dirty":I
    const/16 v22, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const v27, 0xfff8

    move-object/from16 v28, v3

    move-object v3, v2

    move/from16 v2, v24

    move-object/from16 v24, v28

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$dirty":I
    .local v24, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v27}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v3, v24

    .end local v24    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v5    # "color":J
    :cond_5
    :goto_3
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v4

    if-eqz v4, :cond_6

    new-instance v5, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v5, v0, v1}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/Support;I)V

    invoke-interface {v4, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 168
    :cond_6
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static final SupportBadge$lambda$19(Lorg/lighttouch/android/Support;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/PrepareScreenKt;->SupportBadge(Lorg/lighttouch/android/Support;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final VersionStep(Lorg/lighttouch/android/PrepareState;Landroidx/compose/runtime/Composer;I)V
    .locals 41
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 206
    move-object/from16 v0, p0

    const v2, 0x7866f79

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(VersionStep)207@11928L106,224@13172L38,224@13283L96,224@13151L228:PrepareScreen.kt#o13vsk"

    invoke-static {v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, p2, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_1

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v3, 0x3

    if-ne v4, v5, :cond_3

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 225
    :cond_2
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v36, v3

    goto/16 :goto_17

    .line 206
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_4

    const/4 v4, -0x1

    const-string v5, "org.lighttouch.android.VersionStep (PrepareScreen.kt:205)"

    invoke-static {v2, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 207
    :cond_4
    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getProductType()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 208
    .local v2, "name":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u4e3a\u4ee5\u4e0b\u8bbe\u5907\u9009\u62e9 iOS\uff1a"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v5, "\u5df2\u6d4b\u8bd5\u7248\u672c\u5747\u7ecf LightTouch \u9a8c\u8bc1\uff0c\u5176\u4f59\u7684\u53ef\u4ee5\u81ea\u884c\u5c1d\u8bd5\u3002"

    const/16 v7, 0x30

    invoke-static {v4, v5, v13, v7}, Lorg/lighttouch/android/PrepareScreenKt;->Heading(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 209
    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getCatalog()Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 577
    .local v5, "$i$f$filter\\1\\209":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\2":Ljava/util/Collection;
    move-object v8, v4

    .local v8, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 578
    .local v9, "$i$f$filterTo\\2\\577":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_5
    :goto_2
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_6

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\2":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/CatalogFirmware;

    .local v12, "it\\3":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v14, 0x0

    .line 209
    .local v14, "$i$a$-filter-PrepareScreenKt$VersionStep$firmwares$1\\3\\578\\0":I
    invoke-virtual {v12}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getProductType()Ljava/lang/String;

    move-result-object v6

    invoke-static {v15, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    .line 578
    .end local v12    # "it\\3":Lorg/lighttouch/android/CatalogFirmware;
    .end local v14    # "$i$a$-filter-PrepareScreenKt$VersionStep$firmwares$1\\3\\578\\0":I
    if-eqz v6, :cond_5

    invoke-interface {v7, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 579
    .end local v11    # "element\\2":Ljava/lang/Object;
    :cond_6
    nop

    .end local v7    # "destination\\2":Ljava/util/Collection;
    .end local v8    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$filterTo\\2\\577":I
    move-object v6, v7

    check-cast v6, Ljava/util/List;

    .line 577
    nop

    .end local v4    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\1\\209":I
    check-cast v6, Ljava/lang/Iterable;

    .line 209
    sget-object v4, Lorg/lighttouch/android/PrepareScreenKt;->versionOrder:Ljava/util/Comparator;

    invoke-interface {v4}, Ljava/util/Comparator;->reversed()Ljava/util/Comparator;

    move-result-object v4

    const-string v5, "reversed(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v6, v4}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v28

    .line 210
    .local v28, "firmwares":Ljava/util/List;
    move-object/from16 v4, v28

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$count\\4":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 580
    .local v5, "$i$f$count\\4\\210":I
    instance-of v6, v4, Ljava/util/Collection;

    if-eqz v6, :cond_7

    move-object v6, v4

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_7

    const/4 v6, 0x0

    goto :goto_5

    .line 581
    :cond_7
    const/4 v6, 0x0

    .line 582
    .local v6, "count\\4":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_8
    :goto_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_a

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\4":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/lighttouch/android/CatalogFirmware;

    .local v11, "it\\5":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v12, 0x0

    .line 210
    .local v12, "$i$a$-count-PrepareScreenKt$VersionStep$betas$1\\5\\582\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/CatalogFirmware;->getPrerelease()Ljava/lang/String;

    move-result-object v14

    check-cast v14, Ljava/lang/CharSequence;

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-lez v14, :cond_9

    const/4 v14, 0x1

    goto :goto_4

    :cond_9
    const/4 v14, 0x0

    .line 582
    .end local v11    # "it\\5":Lorg/lighttouch/android/CatalogFirmware;
    .end local v12    # "$i$a$-count-PrepareScreenKt$VersionStep$betas$1\\5\\582\\0":I
    :goto_4
    if-eqz v14, :cond_8

    add-int/lit8 v6, v6, 0x1

    if-gez v6, :cond_8

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v10    # "element\\4":Ljava/lang/Object;
    goto :goto_3

    .line 583
    :cond_a
    nop

    .line 210
    .end local v4    # "$this$count\\4":Ljava/lang/Iterable;
    .end local v5    # "$i$f$count\\4\\210":I
    .end local v6    # "count\\4":I
    :goto_5
    nop

    .line 211
    .local v6, "betas":I
    move-object/from16 v4, v28

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\6":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 584
    .local v5, "$i$f$filter\\6\\211":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\7":Ljava/util/Collection;
    move-object v10, v4

    .local v10, "$this$filterTo\\7":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 585
    .local v11, "$i$f$filterTo\\7\\584":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_b
    :goto_6
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_f

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\7":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Lorg/lighttouch/android/CatalogFirmware;

    .local v15, "it\\8":Lorg/lighttouch/android/CatalogFirmware;
    const/16 v16, 0x0

    .line 211
    .local v16, "$i$a$-filter-PrepareScreenKt$VersionStep$shown$1\\8\\585\\0":I
    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getPrerelease()Ljava/lang/String;

    move-result-object v17

    check-cast v17, Ljava/lang/CharSequence;

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->length()I

    move-result v17

    if-nez v17, :cond_c

    const/16 v17, 0x1

    goto :goto_7

    :cond_c
    const/16 v17, 0x0

    :goto_7
    if-nez v17, :cond_e

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getShowBetas()Z

    move-result v17

    if-eqz v17, :cond_d

    goto :goto_8

    :cond_d
    const/4 v15, 0x0

    goto :goto_9

    :cond_e
    :goto_8
    const/4 v15, 0x1

    .line 585
    .end local v15    # "it\\8":Lorg/lighttouch/android/CatalogFirmware;
    .end local v16    # "$i$a$-filter-PrepareScreenKt$VersionStep$shown$1\\8\\585\\0":I
    :goto_9
    if-eqz v15, :cond_b

    invoke-interface {v9, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_6

    .line 586
    .end local v14    # "element\\7":Ljava/lang/Object;
    :cond_f
    nop

    .end local v9    # "destination\\7":Ljava/util/Collection;
    .end local v10    # "$this$filterTo\\7":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filterTo\\7\\584":I
    check-cast v9, Ljava/util/List;

    .line 584
    nop

    .line 211
    .end local v4    # "$this$filter\\6":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filter\\6\\211":I
    move-object/from16 v29, v9

    .local v29, "shown":Ljava/util/List;
    const v4, 0x3fa8b519

    invoke-interface {v13, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, ""

    invoke-static {v13, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 212
    invoke-static {}, Lorg/lighttouch/android/Support;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v5

    invoke-interface {v5}, Lkotlin/enums/EnumEntries;->iterator()Ljava/util/Iterator;

    move-result-object v30

    :goto_a
    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const-string v9, "CC(remember):PrepareScreen.kt#9igjgp"

    if-eqz v5, :cond_1a

    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lorg/lighttouch/android/Support;

    .local v5, "support":Lorg/lighttouch/android/Support;
    const v10, -0x4a919616

    invoke-interface {v13, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "214@12439L27,215@12551L10,215@12595L11,215@12475L149,*219@13021L94,219@12932L183"

    invoke-static {v13, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 213
    move-object/from16 v10, v29

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$filter\\9":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 587
    .local v11, "$i$f$filter\\9\\213":I
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\10":Ljava/util/Collection;
    move-object v14, v10

    .local v14, "$this$filterTo\\10":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 588
    .local v15, "$i$f$filterTo\\10\\587":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :cond_10
    :goto_b
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_12

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\10":Ljava/lang/Object;
    move-object/from16 v18, v7

    check-cast v18, Lorg/lighttouch/android/CatalogFirmware;

    .local v18, "it\\11":Lorg/lighttouch/android/CatalogFirmware;
    const/16 v19, 0x0

    .line 213
    .local v19, "$i$a$-filter-PrepareScreenKt$VersionStep$group$1\\11\\588\\0":I
    invoke-virtual/range {v18 .. v18}, Lorg/lighttouch/android/CatalogFirmware;->getSupport()Lorg/lighttouch/android/Support;

    move-result-object v8

    if-ne v8, v5, :cond_11

    const/4 v8, 0x1

    goto :goto_c

    :cond_11
    const/4 v8, 0x0

    .line 588
    .end local v18    # "it\\11":Lorg/lighttouch/android/CatalogFirmware;
    .end local v19    # "$i$a$-filter-PrepareScreenKt$VersionStep$group$1\\11\\588\\0":I
    :goto_c
    if-eqz v8, :cond_10

    invoke-interface {v12, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_b

    .line 589
    .end local v7    # "element\\10":Ljava/lang/Object;
    :cond_12
    nop

    .end local v12    # "destination\\10":Ljava/util/Collection;
    .end local v14    # "$this$filterTo\\10":Ljava/lang/Iterable;
    .end local v15    # "$i$f$filterTo\\10\\587":I
    move-object v7, v12

    check-cast v7, Ljava/util/List;

    .line 587
    nop

    .line 213
    .end local v10    # "$this$filter\\9":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filter\\9\\213":I
    move-object/from16 v31, v7

    .line 214
    .local v31, "group":Ljava/util/List;
    invoke-interface/range {v31 .. v31}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_13

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_a

    .line 215
    :cond_13
    invoke-virtual {v5}, Lorg/lighttouch/android/Support;->getLabel()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-static {v7, v13, v8}, Lorg/lighttouch/android/PrepareScreenKt;->SectionLabel(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 216
    move v7, v3

    .end local v3    # "$dirty":I
    .local v7, "$dirty":I
    invoke-virtual {v5}, Lorg/lighttouch/android/Support;->getDetail()Ljava/lang/String;

    move-result-object v3

    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v18, v10

    check-cast v18, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x6

    .local v10, "$this$dp\\12":I
    const/4 v11, 0x0

    .line 590
    .local v11, "$i$f$getDp\\12\\216":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v22

    .line 216
    .end local v10    # "$this$dp\\12":I
    .end local v11    # "$i$f$getDp\\12\\216":I
    const/16 v23, 0x7

    const/16 v24, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    invoke-static/range {v18 .. v24}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    sget-object v11, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v11, v13, v12}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v11

    invoke-virtual {v11}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v23

    sget-object v11, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v11, v13, v12}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v11

    invoke-virtual {v11}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v11

    const/16 v26, 0x0

    const v27, 0xfff8

    move v14, v7

    move/from16 v20, v8

    .end local v7    # "$dirty":I
    .local v14, "$dirty":I
    const-wide/16 v7, 0x0

    move-object v15, v9

    const/4 v9, 0x0

    move-object/from16 v16, v4

    move-object v4, v10

    const/4 v10, 0x0

    move-object/from16 v18, v5

    move-wide/from16 v39, v11

    move v12, v6

    move-wide/from16 v5, v39

    .end local v5    # "support":Lorg/lighttouch/android/Support;
    .end local v6    # "betas":I
    .local v12, "betas":I
    .local v18, "support":Lorg/lighttouch/android/Support;
    const/4 v11, 0x0

    move/from16 v19, v12

    move-object/from16 v24, v13

    .end local v12    # "betas":I
    .end local v13    # "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "betas":I
    .local v24, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v12, 0x0

    move/from16 v21, v14

    .end local v14    # "$dirty":I
    .local v21, "$dirty":I
    const/4 v14, 0x0

    move-object/from16 v22, v15

    const/4 v15, 0x0

    move-object/from16 v25, v16

    const/16 v32, 0x1

    const-wide/16 v16, 0x0

    move-object/from16 v33, v18

    .end local v18    # "support":Lorg/lighttouch/android/Support;
    .local v33, "support":Lorg/lighttouch/android/Support;
    const/16 v18, 0x0

    move/from16 v34, v19

    .end local v19    # "betas":I
    .local v34, "betas":I
    const/16 v19, 0x0

    move/from16 v35, v20

    const/16 v20, 0x0

    move/from16 v36, v21

    .end local v21    # "$dirty":I
    .local v36, "$dirty":I
    const/16 v21, 0x0

    move-object/from16 v37, v22

    const/16 v22, 0x0

    move-object/from16 v38, v25

    const/16 v25, 0x30

    move-object/from16 p1, v2

    move-object/from16 v1, v37

    const/4 v2, 0x4

    .end local v2    # "name":Ljava/lang/String;
    .local p1, "name":Ljava/lang/String;
    invoke-static/range {v3 .. v27}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 217
    move-object/from16 v13, v24

    .end local v24    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v13    # "$composer":Landroidx/compose/runtime/Composer;
    move-object/from16 v3, v31

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$sortedBy\\13":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 591
    .local v4, "$i$f$sortedBy\\13\\217":I
    new-instance v5, Lorg/lighttouch/android/PrepareScreenKt$VersionStep$$inlined$sortedBy$1;

    invoke-direct {v5}, Lorg/lighttouch/android/PrepareScreenKt$VersionStep$$inlined$sortedBy$1;-><init>()V

    check-cast v5, Ljava/util/Comparator;

    invoke-static {v3, v5}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v3

    .line 217
    .end local v3    # "$this$sortedBy\\13":Ljava/lang/Iterable;
    .end local v4    # "$i$f$sortedBy\\13\\217":I
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_d
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_19

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v15, v3

    check-cast v15, Lorg/lighttouch/android/CatalogFirmware;

    .line 218
    .local v15, "firmware":Lorg/lighttouch/android/CatalogFirmware;
    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v3

    const-string v4, "n72ap-7E18"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_14

    const-string v4, "\u63a8\u8350 \u00b7 "

    goto :goto_e

    :cond_14
    move-object/from16 v4, v38

    :goto_e
    invoke-static {v15}, Lorg/lighttouch/android/PrepareScreenKt;->released(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/String;

    move-result-object v3

    .line 219
    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getSupported()Ljava/util/Set;

    move-result-object v5

    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_15

    move-object/from16 v5, v38

    goto :goto_f

    :cond_15
    const-string v5, "\n\u5728\u7535\u8111\u4e0a\u51c6\u5907\u597d\u540e\u518d\u6dfb\u52a0\u5230\u8fd9\u91cc"

    :goto_f
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 218
    nop

    .line 220
    .local v5, "detail":Ljava/lang/String;
    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "iOS "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v3

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "prepare_version_"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const v3, -0x615d173a

    invoke-interface {v13, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v13, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v36, 0xe

    if-ne v3, v2, :cond_16

    const/4 v3, 0x1

    goto :goto_10

    :cond_16
    move/from16 v3, v35

    :goto_10
    invoke-interface {v13, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v3, v6

    .local v3, "invalid\\14":Z
    move-object v6, v13

    .local v6, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 592
    .local v8, "$i$f$cache\\14\\220":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\14":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 593
    .local v10, "$i$a$-let-ComposerKt$cache$1\\15\\592\\14":I
    if-nez v3, :cond_18

    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v9, v11, :cond_17

    goto :goto_11

    .line 597
    :cond_17
    move-object v12, v9

    goto :goto_12

    .line 594
    :cond_18
    :goto_11
    const/4 v11, 0x0

    .line 220
    .local v11, "$i$a$-cache-PrepareScreenKt$VersionStep$2\\16\\594\\0":I
    new-instance v12, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda9;

    invoke-direct {v12, v0, v15}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda9;-><init>(Lorg/lighttouch/android/PrepareState;Lorg/lighttouch/android/CatalogFirmware;)V

    .line 594
    .end local v11    # "$i$a$-cache-PrepareScreenKt$VersionStep$2\\16\\594\\0":I
    nop

    .line 595
    .local v12, "value\\15":Ljava/lang/Object;
    invoke-interface {v6, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 596
    nop

    .line 593
    .end local v12    # "value\\15":Ljava/lang/Object;
    :goto_12
    nop

    .line 592
    .end local v9    # "it\\14":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\15\\592\\14":I
    nop

    .line 220
    .end local v3    # "invalid\\14":Z
    .end local v6    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\14\\220":I
    move-object v9, v12

    check-cast v9, Lkotlin/jvm/functions/Function0;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v11, 0xc06

    const/16 v12, 0x20

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v8, 0x0

    move-object v10, v13

    .end local v13    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v12}, Lorg/lighttouch/android/PrepareScreenKt;->ChoiceRow(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Lorg/lighttouch/android/Support;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .end local v5    # "detail":Ljava/lang/String;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v15    # "firmware":Lorg/lighttouch/android/CatalogFirmware;
    .restart local v13    # "$composer":Landroidx/compose/runtime/Composer;
    goto/16 :goto_d

    .line 212
    .end local v31    # "group":Ljava/util/List;
    :cond_19
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v2, p1

    move/from16 v6, v34

    move/from16 v3, v36

    move-object/from16 v4, v38

    .end local v33    # "support":Lorg/lighttouch/android/Support;
    goto/16 :goto_a

    .end local v34    # "betas":I
    .end local v36    # "$dirty":I
    .end local p1    # "name":Ljava/lang/String;
    .restart local v2    # "name":Ljava/lang/String;
    .local v3, "$dirty":I
    .local v6, "betas":I
    :cond_1a
    move-object/from16 p1, v2

    move/from16 v36, v3

    move/from16 v34, v6

    move-object v1, v9

    const/4 v2, 0x4

    const/16 v35, 0x0

    .end local v2    # "name":Ljava/lang/String;
    .end local v3    # "$dirty":I
    .end local v6    # "betas":I
    .restart local v34    # "betas":I
    .restart local v36    # "$dirty":I
    .restart local p1    # "name":Ljava/lang/String;
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 225
    if-lez v34, :cond_1e

    const v3, 0x4c5de2

    invoke-interface {v13, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v13, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v36, 0xe

    if-ne v1, v2, :cond_1b

    const/4 v7, 0x1

    goto :goto_13

    :cond_1b
    move/from16 v7, v35

    .local v7, "invalid\\17":Z
    :goto_13
    move-object v1, v13

    .local v1, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 598
    .local v2, "$i$f$cache\\17\\225":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\17":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 599
    .local v4, "$i$a$-let-ComposerKt$cache$1\\18\\598\\17":I
    if-nez v7, :cond_1d

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_1c

    goto :goto_14

    .line 603
    :cond_1c
    move-object v6, v3

    goto :goto_15

    .line 600
    :cond_1d
    :goto_14
    const/4 v5, 0x0

    .line 225
    .local v5, "$i$a$-cache-PrepareScreenKt$VersionStep$3\\19\\600\\0":I
    new-instance v6, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v6, v0}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/PrepareState;)V

    .line 600
    .end local v5    # "$i$a$-cache-PrepareScreenKt$VersionStep$3\\19\\600\\0":I
    nop

    .line 601
    .local v6, "value\\18":Ljava/lang/Object;
    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 602
    nop

    .line 599
    .end local v6    # "value\\18":Ljava/lang/Object;
    :goto_15
    nop

    .line 598
    .end local v3    # "it\\17":Ljava/lang/Object;
    .end local v4    # "$i$a$-let-ComposerKt$cache$1\\18\\598\\17":I
    nop

    .line 225
    .end local v1    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$f$cache\\17\\225":I
    .end local v7    # "invalid\\17":Z
    move-object v3, v6

    check-cast v3, Lkotlin/jvm/functions/Function0;

    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v4, v1

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\20":I
    const/4 v2, 0x0

    .line 604
    .local v2, "$i$f$getDp\\20\\225":I
    int-to-float v5, v1

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 225
    .end local v1    # "$this$dp\\20":I
    .end local v2    # "$i$f$getDp\\20\\225":I
    const/16 v9, 0xd

    const/4 v10, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v4 .. v10}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "prepare_show_betas"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    new-instance v1, Lorg/lighttouch/android/PrepareScreenKt$VersionStep$4;

    move/from16 v2, v34

    .end local v34    # "betas":I
    .local v2, "betas":I
    invoke-direct {v1, v0, v2}, Lorg/lighttouch/android/PrepareScreenKt$VersionStep$4;-><init>(Lorg/lighttouch/android/PrepareState;I)V

    const/16 v5, 0x36

    const v6, 0x45b4bd21

    const/4 v7, 0x1

    invoke-static {v6, v7, v1, v13, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object v12, v1

    check-cast v12, Lkotlin/jvm/functions/Function3;

    const v14, 0x30000030

    const/16 v15, 0x1fc

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v11, 0x0

    invoke-static/range {v3 .. v15}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    goto :goto_16

    .end local v2    # "betas":I
    .restart local v34    # "betas":I
    :cond_1e
    move/from16 v2, v34

    .end local v34    # "betas":I
    .restart local v2    # "betas":I
    :goto_16
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "betas":I
    .end local v28    # "firmwares":Ljava/util/List;
    .end local v29    # "shown":Ljava/util/List;
    .end local p1    # "name":Ljava/lang/String;
    :cond_1f
    :goto_17
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_20

    new-instance v2, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda12;

    move/from16 v3, p2

    invoke-direct {v2, v0, v3}, Lorg/lighttouch/android/PrepareScreenKt$$ExternalSyntheticLambda12;-><init>(Lorg/lighttouch/android/PrepareState;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_18

    :cond_20
    move/from16 v3, p2

    .line 228
    :goto_18
    return-void
.end method

.method private static final VersionStep$lambda$45$lambda$44(Lorg/lighttouch/android/PrepareState;Lorg/lighttouch/android/CatalogFirmware;)Lkotlin/Unit;
    .locals 1
    .param p0, "$state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "$firmware"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 221
    invoke-virtual {p1}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/PrepareState;->setFirmwareId(Ljava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/PrepareStep;->FILES:Lorg/lighttouch/android/PrepareStep;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/PrepareState;->setStep(Lorg/lighttouch/android/PrepareStep;)V

    .line 222
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final VersionStep$lambda$47$lambda$46(Lorg/lighttouch/android/PrepareState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$state"    # Lorg/lighttouch/android/PrepareState;

    .line 225
    invoke-virtual {p0}, Lorg/lighttouch/android/PrepareState;->getShowBetas()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/PrepareState;->setShowBetas(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final VersionStep$lambda$48(Lorg/lighttouch/android/PrepareState;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/PrepareScreenKt;->VersionStep(Lorg/lighttouch/android/PrepareState;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$DeviceStep(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "onAdvanced"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/PrepareScreenKt;->DeviceStep(Lorg/lighttouch/android/PrepareState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "$receiver"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p2, "busy"    # Z
    .param p3, "onDownload"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onChooseIpsw"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onChooseRom"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onDownloadRom"    # Lkotlin/jvm/functions/Function0;
    .param p7, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p8, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p9}, Lorg/lighttouch/android/PrepareScreenKt;->FilesStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$PreparedCopyStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "$receiver"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p2, "busy"    # Z
    .param p3, "onChoosePrepared"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/PrepareScreenKt;->PreparedCopyStep(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/PrepareState;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$Progress(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "preparing"    # Z
    .param p2, "busy"    # Z
    .param p3, "onPrepare"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onCancel"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onRetryImport"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onClose"    # Lkotlin/jvm/functions/Function0;
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p8}, Lorg/lighttouch/android/PrepareScreenKt;->Progress(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$VersionStep(Lorg/lighttouch/android/PrepareState;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "state"    # Lorg/lighttouch/android/PrepareState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/PrepareScreenKt;->VersionStep(Lorg/lighttouch/android/PrepareState;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$getDeviceOrder$p()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, Lorg/lighttouch/android/PrepareScreenKt;->deviceOrder:Ljava/util/List;

    return-object v0
.end method

.method private static final preparationCost(Lorg/lighttouch/android/CatalogFirmware;)Lorg/lighttouch/android/PreparationCost;
    .locals 3
    .param p0, "firmware"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 84
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "n72ap"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lorg/lighttouch/android/PreparationCost;

    const-string v1, "\u7ea6\u4e00\u5206\u949f"

    const-string v2, "1.5 GB"

    invoke-direct {v0, v1, v2}, Lorg/lighttouch/android/PreparationCost;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_1
    new-instance v0, Lorg/lighttouch/android/PreparationCost;

    const-string v1, "\u51e0\u5206\u949f"

    const-string v2, "5 GB"

    invoke-direct {v0, v1, v2}, Lorg/lighttouch/android/PreparationCost;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    return-object v0
.end method

.method private static final released(Lorg/lighttouch/android/CatalogFirmware;)Ljava/lang/String;
    .locals 18
    .param p0, "firmware"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 260
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/CatalogFirmware;->getReleased()Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v0, 0x1

    new-array v2, v0, [C

    const/4 v7, 0x0

    const/16 v3, 0x2d

    aput-char v3, v2, v7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v1

    move-object v2, v1

    .line 565
    .local v2, "it\\1":Ljava/util/List;
    const/4 v3, 0x0

    .line 260
    .local v3, "$i$a$-takeIf-PrepareScreenKt$released$date$1\\1\\260\\0":I
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v4

    const/4 v5, 0x2

    if-lt v4, v5, :cond_0

    move v2, v0

    goto :goto_0

    :cond_0
    move v2, v7

    .end local v2    # "it\\1":Ljava/util/List;
    .end local v3    # "$i$a$-takeIf-PrepareScreenKt$released$date$1\\1\\260\\0":I
    :goto_0
    const/4 v3, 0x0

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    move-object v1, v3

    :goto_1
    if-eqz v1, :cond_4

    const/4 v2, 0x0

    .local v2, "$i$a$-let-PrepareScreenKt$released$date$2\\2\\260\\0":I
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "year\\2":Ljava/lang/String;
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 261
    .local v1, "month\\2":Ljava/lang/String;
    const/16 v6, 0xc

    new-array v6, v6, [Ljava/lang/String;

    const-string v8, "\u4e00\u6708"

    aput-object v8, v6, v7

    const-string v8, "\u4e8c\u6708"

    aput-object v8, v6, v0

    const-string v8, "\u4e09\u6708"

    aput-object v8, v6, v5

    const/4 v8, 0x3

    const-string v9, "\u56db\u6708"

    aput-object v9, v6, v8

    const/4 v8, 0x4

    const-string v9, "\u4e94\u6708"

    aput-object v9, v6, v8

    const/4 v8, 0x5

    const-string v9, "\u516d\u6708"

    aput-object v9, v6, v8

    const/4 v8, 0x6

    const-string v9, "\u4e03\u6708"

    aput-object v9, v6, v8

    const/4 v8, 0x7

    const-string v9, "\u516b\u6708"

    aput-object v9, v6, v8

    const/16 v8, 0x8

    const-string v9, "\u4e5d\u6708"

    aput-object v9, v6, v8

    const/16 v8, 0x9

    const-string v9, "\u5341\u6708"

    aput-object v9, v6, v8

    const/16 v8, 0xa

    const-string v9, "\u5341\u4e00\u6708"

    aput-object v9, v6, v8

    const/16 v8, 0xb

    const-string v9, "\u5341\u4e8c\u6708"

    aput-object v9, v6, v8

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 262
    .local v6, "months\\2":Ljava/util/List;
    invoke-static {v1}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v8

    if-eqz v8, :cond_2

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    goto :goto_2

    :cond_2
    move v8, v7

    :goto_2
    sub-int/2addr v8, v0

    invoke-static {v6, v8}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    if-eqz v8, :cond_3

    .line 565
    .local v8, "it\\3":Ljava/lang/String;
    const/4 v9, 0x0

    .line 262
    .local v9, "$i$a$-let-PrepareScreenKt$released$date$2$1\\3\\262\\2":I
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .end local v8    # "it\\3":Ljava/lang/String;
    .end local v9    # "$i$a$-let-PrepareScreenKt$released$date$2$1\\3\\262\\2":I
    goto :goto_3

    :cond_3
    move-object v8, v3

    .line 260
    .end local v1    # "month\\2":Ljava/lang/String;
    .end local v2    # "$i$a$-let-PrepareScreenKt$released$date$2\\2\\260\\0":I
    .end local v4    # "year\\2":Ljava/lang/String;
    .end local v6    # "months\\2":Ljava/util/List;
    :goto_3
    goto :goto_4

    :cond_4
    move-object v8, v3

    .line 264
    .local v8, "date":Ljava/lang/String;
    :goto_4
    new-array v1, v5, [Ljava/lang/String;

    if-eqz v8, :cond_5

    .line 565
    move-object v2, v8

    .local v2, "it\\4":Ljava/lang/String;
    const/4 v3, 0x0

    .line 264
    .local v3, "$i$a$-let-PrepareScreenKt$released$1\\4\\264\\0":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u53d1\u5e03\u4e8e "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .end local v2    # "it\\4":Ljava/lang/String;
    .end local v3    # "$i$a$-let-PrepareScreenKt$released$1\\4\\264\\0":I
    :cond_5
    aput-object v3, v1, v7

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/CatalogFirmware;->getBuild()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u7248\u672c "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/lang/Iterable;

    const-string v0, " \u00b7 "

    move-object v10, v0

    check-cast v10, Ljava/lang/CharSequence;

    const/16 v16, 0x3e

    const/16 v17, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static/range {v9 .. v17}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final versionOrder$lambda$6(Lorg/lighttouch/android/CatalogFirmware;Lorg/lighttouch/android/CatalogFirmware;)I
    .locals 17
    .param p0, "a"    # Lorg/lighttouch/android/CatalogFirmware;
    .param p1, "b"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 73
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/CatalogFirmware;->getVersion()Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v0, 0x1

    new-array v2, v0, [C

    const/4 v7, 0x0

    .line 74
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    .line 73
    const/16 v9, 0x2e

    aput-char v9, v2, v7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static/range {v1 .. v6}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 847
    .local v2, "$i$f$map\\1\\73":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 848
    .local v6, "$i$f$mapTo\\2\\847":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_1

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 849
    .local v11, "item\\2":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Ljava/lang/String;

    .local v12, "it\\3":Ljava/lang/String;
    const/4 v13, 0x0

    .line 73
    .local v13, "$i$a$-map-PrepareScreenKt$versionOrder$1$x$1\\3\\849\\0":I
    invoke-static {v12}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v14

    if-eqz v14, :cond_0

    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    move-result v14

    goto :goto_1

    :cond_0
    move v14, v7

    .end local v12    # "it\\3":Ljava/lang/String;
    .end local v13    # "$i$a$-map-PrepareScreenKt$versionOrder$1$x$1\\3\\849\\0":I
    :goto_1
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 849
    invoke-interface {v3, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 850
    .end local v11    # "item\\2":Ljava/lang/Object;
    :cond_1
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\2\\847":I
    check-cast v3, Ljava/util/List;

    .line 847
    nop

    .line 73
    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map\\1\\73":I
    nop

    .local v3, "x":Ljava/util/List;
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getVersion()Ljava/lang/String;

    move-result-object v1

    move-object v10, v1

    check-cast v10, Ljava/lang/CharSequence;

    new-array v11, v0, [C

    aput-char v9, v11, v7

    const/4 v14, 0x6

    const/4 v15, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static/range {v10 .. v15}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 847
    .local v2, "$i$f$map\\4\\73":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\5":Ljava/util/Collection;
    move-object v6, v1

    .local v6, "$this$mapTo\\5":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 848
    .local v9, "$i$f$mapTo\\5\\847":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_2
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_3

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 849
    .local v11, "item\\5":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Ljava/lang/String;

    .local v12, "it\\6":Ljava/lang/String;
    const/4 v13, 0x0

    .line 73
    .local v13, "$i$a$-map-PrepareScreenKt$versionOrder$1$y$1\\6\\849\\0":I
    invoke-static {v12}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v14

    if-eqz v14, :cond_2

    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    move-result v14

    goto :goto_3

    :cond_2
    move v14, v7

    .end local v12    # "it\\6":Ljava/lang/String;
    .end local v13    # "$i$a$-map-PrepareScreenKt$versionOrder$1$y$1\\6\\849\\0":I
    :goto_3
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 849
    invoke-interface {v5, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 850
    .end local v11    # "item\\5":Ljava/lang/Object;
    :cond_3
    nop

    .end local v5    # "destination\\5":Ljava/util/Collection;
    .end local v6    # "$this$mapTo\\5":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\5\\847":I
    check-cast v5, Ljava/util/List;

    .line 847
    nop

    .line 73
    .end local v1    # "$this$map\\4":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map\\4\\73":I
    nop

    .line 74
    .local v5, "y":Ljava/util/List;
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v1

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v7, v1}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\7":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 851
    .local v2, "$i$f$map\\7\\74":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v6, v4}, Ljava/util/ArrayList;-><init>(I)V

    move-object v4, v6

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\8":Ljava/util/Collection;
    move-object v6, v1

    .local v6, "$this$mapTo\\8":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 852
    .local v9, "$i$f$mapTo\\8\\851":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_4
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_8

    move-object v11, v10

    check-cast v11, Lkotlin/collections/IntIterator;

    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v11

    .line 853
    .local v11, "item\\8":I
    move v12, v11

    .local v12, "it\\9":I
    const/4 v13, 0x0

    .line 74
    .local v13, "$i$a$-map-PrepareScreenKt$versionOrder$1$1\\9\\853\\0":I
    if-ltz v12, :cond_4

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v14

    if-ge v12, v14, :cond_4

    move v14, v0

    goto :goto_5

    :cond_4
    move v14, v7

    :goto_5
    if-eqz v14, :cond_5

    invoke-interface {v3, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    goto :goto_6

    :cond_5
    move v14, v12

    .line 565
    .local v14, "it\\10":I
    const/4 v15, 0x0

    .line 74
    .local v15, "$i$a$-getOrElse-PrepareScreenKt$versionOrder$1$1$1\\10\\74\\9":I
    move-object v14, v8

    .end local v14    # "it\\10":I
    .end local v15    # "$i$a$-getOrElse-PrepareScreenKt$versionOrder$1$1$1\\10\\74\\9":I
    :goto_6
    check-cast v14, Ljava/lang/Number;

    invoke-virtual {v14}, Ljava/lang/Number;->intValue()I

    move-result v14

    if-ltz v12, :cond_6

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v15

    if-ge v12, v15, :cond_6

    move v15, v0

    goto :goto_7

    :cond_6
    move v15, v7

    :goto_7
    if-eqz v15, :cond_7

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    goto :goto_8

    .line 565
    :cond_7
    move v15, v12

    .local v15, "it\\11":I
    const/16 v16, 0x0

    .line 74
    .local v16, "$i$a$-getOrElse-PrepareScreenKt$versionOrder$1$1$2\\11\\74\\9":I
    move-object v15, v8

    .end local v15    # "it\\11":I
    .end local v16    # "$i$a$-getOrElse-PrepareScreenKt$versionOrder$1$1$2\\11\\74\\9":I
    :goto_8
    check-cast v15, Ljava/lang/Number;

    invoke-virtual {v15}, Ljava/lang/Number;->intValue()I

    move-result v15

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v12

    .end local v12    # "it\\9":I
    .end local v13    # "$i$a$-map-PrepareScreenKt$versionOrder$1$1\\9\\853\\0":I
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    .line 853
    invoke-interface {v4, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_4

    .line 854
    .end local v11    # "item\\8":I
    :cond_8
    nop

    .end local v4    # "destination\\8":Ljava/util/Collection;
    .end local v6    # "$this$mapTo\\8":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapTo\\8\\851":I
    check-cast v4, Ljava/util/List;

    .line 851
    nop

    .line 74
    .end local v1    # "$this$map\\7":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map\\7\\74":I
    move-object v1, v4

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$firstOrNull\\12":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 855
    .local v2, "$i$f$firstOrNull\\12\\74":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_9
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element\\12":Ljava/lang/Object;
    move-object v8, v6

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    .local v8, "it\\13":I
    const/4 v9, 0x0

    .line 74
    .local v9, "$i$a$-firstOrNull-PrepareScreenKt$versionOrder$1$2\\13\\855\\0":I
    if-eqz v8, :cond_a

    move v8, v0

    goto :goto_9

    :cond_a
    move v8, v7

    .line 855
    .end local v8    # "it\\13":I
    .end local v9    # "$i$a$-firstOrNull-PrepareScreenKt$versionOrder$1$2\\13\\855\\0":I
    :goto_9
    if-eqz v8, :cond_9

    goto :goto_a

    .line 856
    .end local v6    # "element\\12":Ljava/lang/Object;
    :cond_b
    const/4 v6, 0x0

    .line 74
    .end local v1    # "$this$firstOrNull\\12":Ljava/lang/Iterable;
    .end local v2    # "$i$f$firstOrNull\\12\\74":I
    :goto_a
    check-cast v6, Ljava/lang/Integer;

    if-eqz v6, :cond_c

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_b

    :cond_c
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/CatalogFirmware;->getBuild()Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getBuild()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v0

    :goto_b
    return v0
.end method

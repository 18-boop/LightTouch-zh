.class public final Lorg/lighttouch/android/StoreInstalledKt;
.super Ljava/lang/Object;
.source "StoreInstalled.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreInstalled.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreInstalled.kt\norg/lighttouch/android/StoreInstalledKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 9 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 10 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt\n*L\n1#1,204:1\n1225#2,6:205\n1225#2,6:211\n1225#2,6:255\n1225#2,6:266\n1225#2,6:313\n1225#2,6:400\n1225#2,6:571\n149#3:217\n149#3:218\n149#3:265\n149#3:272\n149#3:305\n149#3:306\n149#3:312\n149#3:355\n149#3:406\n149#3:443\n149#3:480\n149#3:526\n149#3:527\n149#3:564\n149#3:569\n149#3:570\n99#4:219\n96#4,6:220\n102#4:254\n106#4:264\n99#4:319\n96#4,6:320\n102#4:354\n106#4:399\n99#4:444\n96#4,6:445\n102#4:479\n106#4:525\n79#5,6:226\n86#5,4:241\n90#5,2:251\n94#5:263\n79#5,6:276\n86#5,4:291\n90#5,2:301\n94#5:310\n79#5,6:326\n86#5,4:341\n90#5,2:351\n79#5,6:363\n86#5,4:378\n90#5,2:388\n94#5:394\n94#5:398\n79#5,6:414\n86#5,4:429\n90#5,2:439\n79#5,6:451\n86#5,4:466\n90#5,2:476\n79#5,6:489\n86#5,4:504\n90#5,2:514\n94#5:520\n94#5:524\n79#5,6:535\n86#5,4:550\n90#5,2:560\n94#5:567\n94#5:579\n368#6,9:232\n377#6:253\n378#6,2:261\n368#6,9:282\n377#6:303\n378#6,2:308\n368#6,9:332\n377#6:353\n368#6,9:369\n377#6:390\n378#6,2:392\n378#6,2:396\n368#6,9:420\n377#6:441\n368#6,9:457\n377#6:478\n368#6,9:495\n377#6:516\n378#6,2:518\n378#6,2:522\n368#6,9:541\n377#6:562\n378#6,2:565\n378#6,2:577\n4034#7,6:245\n4034#7,6:295\n4034#7,6:345\n4034#7,6:382\n4034#7,6:433\n4034#7,6:470\n4034#7,6:508\n4034#7,6:554\n86#8,3:273\n89#8:304\n93#8:311\n86#8:356\n83#8,6:357\n89#8:391\n93#8:395\n86#8:407\n83#8,6:408\n89#8:442\n86#8:481\n82#8,7:482\n89#8:517\n93#8:521\n86#8:528\n83#8,6:529\n89#8:563\n93#8:568\n93#8:580\n1#9:307\n143#10,12:581\n*S KotlinDebug\n*F\n+ 1 StoreInstalled.kt\norg/lighttouch/android/StoreInstalledKt\n*L\n112#1:205,6\n117#1:211,6\n124#1:255,6\n127#1:266,6\n151#1:313,6\n174#1:400,6\n201#1:571,6\n118#1:217\n122#1:218\n127#1:265\n136#1:272\n137#1:305\n138#1:306\n151#1:312\n154#1:355\n175#1:406\n176#1:443\n178#1:480\n184#1:526\n185#1:527\n189#1:564\n194#1:569\n199#1:570\n122#1:219\n122#1:220,6\n122#1:254\n122#1:264\n151#1:319\n151#1:320,6\n151#1:354\n151#1:399\n176#1:444\n176#1:445,6\n176#1:479\n176#1:525\n122#1:226,6\n122#1:241,4\n122#1:251,2\n122#1:263\n136#1:276,6\n136#1:291,4\n136#1:301,2\n136#1:310\n151#1:326,6\n151#1:341,4\n151#1:351,2\n155#1:363,6\n155#1:378,4\n155#1:388,2\n155#1:394\n151#1:398\n175#1:414,6\n175#1:429,4\n175#1:439,2\n176#1:451,6\n176#1:466,4\n176#1:476,2\n179#1:489,6\n179#1:504,4\n179#1:514,2\n179#1:520\n176#1:524\n185#1:535,6\n185#1:550,4\n185#1:560,2\n185#1:567\n175#1:579\n122#1:232,9\n122#1:253\n122#1:261,2\n136#1:282,9\n136#1:303\n136#1:308,2\n151#1:332,9\n151#1:353\n155#1:369,9\n155#1:390\n155#1:392,2\n151#1:396,2\n175#1:420,9\n175#1:441\n176#1:457,9\n176#1:478\n179#1:495,9\n179#1:516\n179#1:518,2\n176#1:522,2\n185#1:541,9\n185#1:562\n185#1:565,2\n175#1:577,2\n122#1:245,6\n136#1:295,6\n151#1:345,6\n155#1:382,6\n175#1:433,6\n176#1:470,6\n179#1:508,6\n185#1:554,6\n136#1:273,3\n136#1:304\n136#1:311\n155#1:356\n155#1:357,6\n155#1:391\n155#1:395\n175#1:407\n175#1:408,6\n175#1:442\n179#1:481\n179#1:482,7\n179#1:517\n179#1:521\n185#1:528\n185#1:529,6\n185#1:563\n185#1:568\n175#1:580\n128#1:581,12\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0004\u001a!\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0001\u00a2\u0006\u0002\u0010\u0007\u001a3\u0010\u0008\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0010\u0008\u0002\u0010\u000c\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\rH\u0003\u00a2\u0006\u0002\u0010\u000e\u001a\u001d\u0010\u000f\u001a\u00020\u00012\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0003\u001a\u00020\u0004H\u0003\u00a2\u0006\u0002\u0010\u0012\u001a!\u0010\u0013\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u0011H\u0001\u00a2\u0006\u0002\u0010\u0014\u00a8\u0006\u0015"
    }
    d2 = {
        "InstalledTab",
        "",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "model",
        "Lorg/lighttouch/android/StoreModel;",
        "running",
        "",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZLandroidx/compose/runtime/Composer;I)V",
        "InstalledMessage",
        "title",
        "",
        "body",
        "retry",
        "Lkotlin/Function0;",
        "(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "InstalledRow",
        "app",
        "Lorg/lighttouch/android/InstalledApp;",
        "(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V",
        "InstalledPlainPage",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;Landroidx/compose/runtime/Composer;I)V",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$79mJbdwxQ8AbOoiU_mXcEOK6JTw(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledTab$lambda$2$lambda$1(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RIIlGkOqWN26lKwiTWLQMuEpbN0(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledTab$lambda$10$lambda$9(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$VvJyQNOVqYlS4EQH7i47poUGzIw(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledRow$lambda$21(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$aSGimFeargg5pLAqyoDZZCH2764(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledPlainPage$lambda$29$lambda$28$lambda$27(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lAmzPOm9M19YVbk3V3NGH9P8EDU(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledRow$lambda$17$lambda$16(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ngm6ExKkyldvRwZaYC3-O4myGfY(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledTab$lambda$6$lambda$5$lambda$4$lambda$3(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$oGRK8cQpcEpttCJjr4I2IO1R4dU(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledTab$lambda$11(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$pMkHzMckMm9QIVOv79vWaMk4q8Q(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledMessage$lambda$14(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rORBQuFo7y8uDMrptIWNGeJtRCs(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledPlainPage$lambda$30(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$s6CulLorESw9zPGZs7X-igeQlzs(Lorg/lighttouch/android/InstalledApp;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledTab$lambda$10$lambda$9$lambda$7(Lorg/lighttouch/android/InstalledApp;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method private static final InstalledMessage(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .locals 47
    .param p0, "$this$InstalledMessage"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "body"    # Ljava/lang/String;
    .param p3, "retry"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    .line 135
    move/from16 v5, p5

    const v0, -0x2f6b1536

    move-object/from16 v1, p4

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(InstalledMessage)P(2)135@7005L614:StoreInstalled.kt#o13vsk"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p5

    .local v1, "$dirty":I
    const/high16 v2, -0x80000000

    and-int v2, p6, v2

    if-eqz v2, :cond_0

    or-int/lit8 v1, v1, 0x6

    move-object/from16 v8, p0

    goto :goto_1

    :cond_0
    and-int/lit8 v2, v5, 0x6

    if-nez v2, :cond_2

    move-object/from16 v8, p0

    invoke-interface {v7, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v1, v2

    goto :goto_1

    :cond_2
    move-object/from16 v8, p0

    :goto_1
    and-int/lit8 v2, p6, 0x1

    if-eqz v2, :cond_3

    or-int/lit8 v1, v1, 0x30

    move-object/from16 v2, p1

    goto :goto_3

    :cond_3
    and-int/lit8 v2, v5, 0x30

    if-nez v2, :cond_5

    move-object/from16 v2, p1

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x20

    goto :goto_2

    :cond_4
    const/16 v3, 0x10

    :goto_2
    or-int/2addr v1, v3

    goto :goto_3

    :cond_5
    move-object/from16 v2, p1

    :goto_3
    and-int/lit8 v3, p6, 0x2

    if-eqz v3, :cond_6

    or-int/lit16 v1, v1, 0x180

    move-object/from16 v3, p2

    goto :goto_5

    :cond_6
    and-int/lit16 v3, v5, 0x180

    if-nez v3, :cond_8

    move-object/from16 v3, p2

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_7

    const/16 v4, 0x100

    goto :goto_4

    :cond_7
    const/16 v4, 0x80

    :goto_4
    or-int/2addr v1, v4

    goto :goto_5

    :cond_8
    move-object/from16 v3, p2

    :goto_5
    and-int/lit8 v4, p6, 0x4

    if-eqz v4, :cond_9

    or-int/lit16 v1, v1, 0xc00

    move-object/from16 v6, p3

    goto :goto_7

    :cond_9
    and-int/lit16 v6, v5, 0xc00

    if-nez v6, :cond_b

    move-object/from16 v6, p3

    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_a

    const/16 v9, 0x800

    goto :goto_6

    :cond_a
    const/16 v9, 0x400

    :goto_6
    or-int/2addr v1, v9

    goto :goto_7

    :cond_b
    move-object/from16 v6, p3

    :goto_7
    and-int/lit16 v9, v1, 0x493

    const/16 v10, 0x492

    if-ne v9, v10, :cond_d

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v9

    if-nez v9, :cond_c

    goto :goto_8

    .line 311
    :cond_c
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 p4, v1

    move-object v4, v6

    goto/16 :goto_d

    .line 135
    :cond_d
    :goto_8
    if-eqz v4, :cond_e

    const/4 v4, 0x0

    .end local p3    # "retry":Lkotlin/jvm/functions/Function0;
    .local v4, "retry":Lkotlin/jvm/functions/Function0;
    goto :goto_9

    .end local v4    # "retry":Lkotlin/jvm/functions/Function0;
    .restart local p3    # "retry":Lkotlin/jvm/functions/Function0;
    :cond_e
    move-object v4, v6

    .end local p3    # "retry":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "retry":Lkotlin/jvm/functions/Function0;
    :goto_9
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_f

    const/4 v6, -0x1

    const-string v9, "org.lighttouch.android.InstalledMessage (StoreInstalled.kt:134)"

    invoke-static {v0, v1, v6, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 136
    :cond_f
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v9, v0

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/4 v12, 0x2

    const/4 v13, 0x0

    const/high16 v10, 0x3f800000    # 1.0f

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v0, v6, v9, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v6, 0x20

    .local v6, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 272
    .local v8, "$i$f$getDp\\1\\136":I
    int-to-float v9, v6

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 136
    .end local v6    # "$this$dp\\1":I
    .end local v8    # "$i$f$getDp\\1\\136":I
    invoke-static {v0, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getCenter()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v8

    const/16 v33, 0x1b0

    .local v33, "$changed\\2":I
    const/16 v34, 0x0

    .line 273
    .local v34, "$i$f$Column\\2\\136":I
    const v9, -0x1cd0f17e

    const-string v10, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 274
    check-cast v8, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    shr-int/lit8 v9, v33, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v33, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v8, v6, v7, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v33, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 275
    move/from16 v35, v8

    .local v35, "$changed\\3":I
    const/16 v36, 0x0

    .line 276
    .local v36, "$i$f$Layout\\3\\275":I
    const v8, -0x4ee9b9da

    const-string v9, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v7, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 277
    const/4 v8, 0x0

    invoke-static {v7, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v37

    .line 278
    .local v37, "compositeKeyHash\\3":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 279
    .local v8, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 281
    .local v0, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v9

    shl-int/lit8 v10, v35, 0x6

    and-int/lit16 v10, v10, 0x380

    const/4 v11, 0x6

    or-int/2addr v10, v11

    .line 280
    nop

    .local v9, "factory\\4":Lkotlin/jvm/functions/Function0;
    move/from16 v38, v10

    .local v38, "$changed\\4":I
    const/16 v39, 0x0

    .line 282
    .local v39, "$i$f$ReusableComposeNode\\4\\280":I
    const v10, -0x2942ffcf

    const-string v12, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v7, v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 283
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v10

    instance-of v10, v10, Landroidx/compose/runtime/Applier;

    if-nez v10, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 284
    :cond_10
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 285
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v10

    if-eqz v10, :cond_11

    .line 286
    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 288
    :cond_11
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 290
    :goto_a
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .local v10, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 291
    .local v12, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\290\\3":I
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v10, v6, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 292
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v10, v8, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 294
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\6":Lkotlin/jvm/functions/Function2;
    const/4 v14, 0x0

    .line 295
    .local v14, "$i$f$set-impl\\6\\294":I
    move-object v15, v10

    .local v15, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 296
    .local v16, "$i$a$-with-Updater$set$1\\7\\295\\6":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v17

    if-nez v17, :cond_12

    move/from16 p3, v11

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    move/from16 p4, v1

    .end local v1    # "$dirty":I
    .local p4, "$dirty":I
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v11, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    goto :goto_b

    .end local p4    # "$dirty":I
    .restart local v1    # "$dirty":I
    :cond_12
    move/from16 p4, v1

    move/from16 p3, v11

    .line 297
    .end local v1    # "$dirty":I
    .restart local p4    # "$dirty":I
    :goto_b
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 298
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v10, v1, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 300
    :cond_13
    nop

    .line 295
    .end local v15    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-with-Updater$set$1\\7\\295\\6":I
    nop

    .line 300
    nop

    .line 301
    .end local v13    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v14    # "$i$f$set-impl\\6\\294":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 302
    nop

    .line 290
    .end local v10    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\290\\3":I
    nop

    .line 303
    shr-int/lit8 v1, v38, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object v10, v7

    .local v10, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v40, 0x0

    .line 304
    .local v40, "$i$a$-Layout-ColumnKt$Column$1\\8\\303\\2":I
    const v11, -0x16ef5699

    const-string v12, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v10, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v11, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v12, v33, 0x6

    and-int/lit8 v12, v12, 0x70

    or-int/lit8 v41, v12, 0x6

    .local v41, "$changed\\9":I
    move-object/from16 v42, v11

    check-cast v42, Landroidx/compose/foundation/layout/ColumnScope;

    .local v42, "$this$InstalledMessage_u24lambda_u2413\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v11, v10

    .local v11, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 137
    .local v43, "$i$a$-Column-StoreInstalledKt$InstalledMessage$1\\9\\304\\0":I
    const v12, 0x7701ed05

    const-string v13, "C136@7234L11,136@7167L96,137@7272L30,138@7345L10,138@7311L87,139@7440L10,139@7484L11,139@7407L136:StoreInstalled.kt#o13vsk"

    invoke-static {v11, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v12, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v12}, Lorg/lighttouch/android/LtIcons;->getBag()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v12

    sget-object v13, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v13, Landroidx/compose/ui/Modifier;

    const/16 v14, 0x28

    .local v14, "$this$dp\\10":I
    const/4 v15, 0x0

    .line 305
    .local v15, "$i$f$getDp\\10\\137":I
    move-object/from16 v44, v0

    .end local v0    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v44, "materialized\\3":Landroidx/compose/ui/Modifier;
    int-to-float v0, v14

    invoke-static {v0}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 137
    .end local v14    # "$this$dp\\10":I
    .end local v15    # "$i$f$getDp\\10\\137":I
    invoke-static {v13, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v13

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v11, v14}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v14

    const/16 v17, 0x1b0

    const/16 v18, 0x0

    move-object/from16 v29, v11

    move-object v11, v12

    .end local v11    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v29, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    move-object/from16 v16, v29

    .end local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v16, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v18}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 138
    move-object/from16 v0, v16

    .end local v16    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    const/16 v12, 0xc

    .local v12, "$this$dp\\11":I
    const/4 v13, 0x0

    .line 306
    .local v13, "$i$f$getDp\\11\\138":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 138
    .end local v12    # "$this$dp\\11":I
    .end local v13    # "$i$f$getDp\\11\\138":I
    invoke-static {v11, v12}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v11

    move/from16 v12, p3

    invoke-static {v11, v0, v12}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 139
    sget-object v11, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v12, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v11, v0, v12}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v11

    invoke-virtual {v11}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v28

    sget-object v11, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v11

    invoke-static {v11}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v20

    shr-int/lit8 v11, p4, 0x3

    and-int/lit8 v30, v11, 0xe

    const/16 v31, 0x0

    const v32, 0xfdfe

    move-object v11, v9

    .end local v9    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v11, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/4 v9, 0x0

    move-object/from16 v29, v10

    move-object v12, v11

    .end local v10    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v11    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v12, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v29, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-wide/16 v10, 0x0

    move-object v14, v12

    .end local v12    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v14, "factory\\4":Lkotlin/jvm/functions/Function0;
    const-wide/16 v12, 0x0

    move-object v15, v14

    .end local v14    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v15, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/4 v14, 0x0

    move-object/from16 v16, v15

    .end local v15    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v16, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/4 v15, 0x0

    move-object/from16 v17, v16

    .end local v16    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v17, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    move-object/from16 v19, v17

    .end local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    const-wide/16 v17, 0x0

    move-object/from16 v21, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v21, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v19, 0x0

    move-object/from16 v23, v21

    .end local v21    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\4":Lkotlin/jvm/functions/Function0;
    const-wide/16 v21, 0x0

    move-object/from16 v24, v23

    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v24, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    move-object/from16 v25, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v25, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v24, 0x0

    move-object/from16 v26, v25

    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v26, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v25, 0x0

    move-object/from16 v27, v26

    .end local v26    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v27, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v26, 0x0

    move-object/from16 v45, v27

    .end local v27    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v45, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v27, 0x0

    move-object/from16 v46, v29

    move-object/from16 v29, v0

    move-object v0, v8

    move-object v8, v2

    move-object/from16 v2, v46

    .end local v8    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v0, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v29, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v8 .. v32}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 140
    move-object/from16 v10, v29

    .end local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v10, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v28

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v10, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v8

    sget-object v11, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v11

    invoke-static {v11}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v20

    shr-int/lit8 v11, p4, 0x6

    and-int/lit8 v30, v11, 0xe

    const v32, 0xfdfa

    move-wide v10, v8

    .end local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    move-object v8, v3

    invoke-static/range {v8 .. v32}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v10, v29

    .end local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    const v3, 0x566b9a36

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*140@7565L46"

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 141
    if-nez v4, :cond_14

    move-object/from16 v29, v10

    goto :goto_c

    :cond_14
    move-object v11, v4

    .line 307
    .local v11, "it\\12":Lkotlin/jvm/functions/Function0;
    const/4 v3, 0x0

    .line 141
    .local v3, "$i$a$-let-StoreInstalledKt$InstalledMessage$1$1\\12\\141\\9":I
    sget-object v8, Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;

    invoke-virtual {v8}, Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;->getLambda$-1297690640$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v20

    const/high16 v22, 0x30000000

    const/16 v23, 0x1fe

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v21, v10

    .end local v10    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v23}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v29, v21

    .end local v3    # "$i$a$-let-StoreInstalledKt$InstalledMessage$1$1\\12\\141\\9":I
    .end local v11    # "it\\12":Lkotlin/jvm/functions/Function0;
    .end local v21    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    :goto_c
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 137
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 142
    nop

    .line 304
    .end local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v41    # "$changed\\9":I
    .end local v42    # "$this$InstalledMessage_u24lambda_u2413\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v43    # "$i$a$-Column-StoreInstalledKt$InstalledMessage$1\\9\\304\\0":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 303
    .end local v1    # "$changed\\8":I
    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v40    # "$i$a$-Layout-ColumnKt$Column$1\\8\\303\\2":I
    nop

    .line 308
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 282
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 309
    nop

    .line 276
    .end local v38    # "$changed\\4":I
    .end local v39    # "$i$f$ReusableComposeNode\\4\\280":I
    .end local v45    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 310
    nop

    .line 273
    .end local v0    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v35    # "$changed\\3":I
    .end local v36    # "$i$f$Layout\\3\\275":I
    .end local v37    # "compositeKeyHash\\3":I
    .end local v44    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 311
    nop

    .end local v6    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v33    # "$changed\\2":I
    .end local v34    # "$i$f$Column\\2\\136":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_15
    :goto_d
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_16

    new-instance v0, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda9;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v9, p4

    move/from16 v6, p6

    .end local p4    # "$dirty":I
    .local v9, "$dirty":I
    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda9;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;II)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_e

    .end local v9    # "$dirty":I
    .restart local p4    # "$dirty":I
    :cond_16
    move/from16 v9, p4

    .line 143
    .end local p4    # "$dirty":I
    .restart local v9    # "$dirty":I
    :goto_e
    return-void
.end method

.method private static final InstalledMessage$lambda$14(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v7, p5

    move-object v5, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledMessage(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final InstalledPlainPage(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;Landroidx/compose/runtime/Composer;I)V
    .locals 112
    .param p0, "$this$InstalledPlainPage"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "app"    # Lorg/lighttouch/android/InstalledApp;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move-object/from16 v7, p2

    move/from16 v8, p4

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "app"

    invoke-static {v7, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    const v1, 0x7f3d1ba5

    move-object/from16 v2, p3

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(InstalledPlainPage)P(1)173@9473L87,173@9450L110,174@9565L2116:StoreInstalled.kt#o13vsk"

    invoke-static {v9, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p4

    .local v2, "$dirty":I
    and-int/lit8 v3, v8, 0x6

    if-nez v3, :cond_1

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v8, 0x30

    if-nez v3, :cond_3

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    and-int/lit16 v3, v8, 0x180

    if-nez v3, :cond_5

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/16 v3, 0x100

    goto :goto_2

    :cond_4
    const/16 v3, 0x80

    :goto_2
    or-int/2addr v2, v3

    :cond_5
    move v11, v2

    .end local v2    # "$dirty":I
    .local v11, "$dirty":I
    and-int/lit16 v2, v11, 0x93

    const/16 v3, 0x92

    if-ne v2, v3, :cond_7

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_6

    goto :goto_3

    .line 580
    :cond_6
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v35, v9

    move/from16 v31, v11

    goto/16 :goto_18

    .line 170
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.InstalledPlainPage (StoreInstalled.kt:169)"

    invoke-static {v1, v11, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 171
    :cond_8
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getInstalledList()Lorg/lighttouch/android/InstalledList;

    move-result-object v12

    .line 172
    .local v12, "installed":Lorg/lighttouch/android/InstalledList;
    invoke-virtual {v12}, Lorg/lighttouch/android/InstalledList;->getLookups()Ljava/util/Map;

    move-result-object v1

    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object v13, v1

    check-cast v13, Lorg/lighttouch/android/Lookup;

    .line 174
    .local v13, "lookup":Lorg/lighttouch/android/Lookup;
    const v1, -0x6815fd56

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v14, "CC(remember):StoreInstalled.kt#9igjgp"

    invoke-static {v9, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v9, v13}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v9, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v1, v2

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v1, v2

    .local v1, "invalid\\1":Z
    move-object v2, v9

    .local v2, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 400
    .local v3, "$i$f$cache\\1\\174":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 401
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\400\\1":I
    const/4 v15, 0x0

    if-nez v1, :cond_a

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v4, v10, :cond_9

    goto :goto_4

    .line 405
    :cond_9
    move-object v0, v4

    goto :goto_5

    .line 402
    :cond_a
    :goto_4
    const/4 v10, 0x0

    .line 174
    .local v10, "$i$a$-cache-StoreInstalledKt$InstalledPlainPage$1\\3\\402\\0":I
    new-instance v0, Lorg/lighttouch/android/StoreInstalledKt$InstalledPlainPage$1$1;

    invoke-direct {v0, v13, v12, v6, v15}, Lorg/lighttouch/android/StoreInstalledKt$InstalledPlainPage$1$1;-><init>(Lorg/lighttouch/android/Lookup;Lorg/lighttouch/android/InstalledList;Lorg/lighttouch/android/StoreModel;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    .line 402
    .end local v10    # "$i$a$-cache-StoreInstalledKt$InstalledPlainPage$1\\3\\402\\0":I
    nop

    .line 403
    .local v0, "value\\2":Ljava/lang/Object;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 404
    nop

    .line 401
    .end local v0    # "value\\2":Ljava/lang/Object;
    :goto_5
    nop

    .line 400
    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\400\\1":I
    nop

    .line 174
    .end local v1    # "invalid\\1":Z
    .end local v2    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\1\\174":I
    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v10, 0x0

    invoke-static {v13, v0, v9, v10}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 175
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v1, v0

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x10

    .local v2, "$this$dp\\4":I
    const/4 v3, 0x0

    .line 406
    .local v3, "$i$f$getDp\\4\\175":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 175
    .end local v2    # "$this$dp\\4":I
    .end local v3    # "$i$f$getDp\\4\\175":I
    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1, v2, v3, v4, v15}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "store_installed_page"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\5":Landroidx/compose/ui/Modifier;
    const/4 v2, 0x0

    .local v2, "$changed\\5":I
    const/4 v4, 0x0

    .line 407
    .local v4, "$i$f$Column\\5\\175":I
    const v5, -0x1cd0f17e

    const-string v3, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v9, v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 408
    sget-object v17, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v5

    .line 409
    .local v5, "verticalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v17, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v15

    .line 412
    .local v15, "horizontalAlignment\\5":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v17, v2, 0x3

    and-int/lit8 v17, v17, 0xe

    shr-int/lit8 v19, v2, 0x3

    and-int/lit8 v19, v19, 0x70

    or-int v10, v17, v19

    invoke-static {v5, v15, v9, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v2, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 413
    nop

    .local v17, "$changed\\6":I
    const/16 v19, 0x0

    .line 414
    .local v19, "$i$f$Layout\\6\\413":I
    move/from16 v21, v2

    .end local v2    # "$changed\\5":I
    .local v21, "$changed\\5":I
    const v2, -0x4ee9b9da

    move/from16 v22, v4

    .end local v4    # "$i$f$Column\\5\\175":I
    .local v22, "$i$f$Column\\5\\175":I
    const-string v4, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v9, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 415
    const/4 v2, 0x0

    invoke-static {v9, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v24

    .line 416
    .local v24, "compositeKeyHash\\6":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 417
    .local v2, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v25, v5

    .end local v5    # "verticalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v25, "verticalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v9, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 419
    .local v5, "materialized\\6":Landroidx/compose/ui/Modifier;
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v26

    move-object/from16 v27, v1

    .end local v1    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v27, "modifier\\5":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v17, 0x6

    and-int/lit16 v1, v1, 0x380

    move/from16 v28, v1

    const/4 v1, 0x6

    or-int/lit8 v28, v28, 0x6

    .line 418
    move-object/from16 v29, v26

    .local v28, "$changed\\7":I
    .local v29, "factory\\7":Lkotlin/jvm/functions/Function0;
    const/16 v26, 0x0

    .line 420
    .local v26, "$i$f$ReusableComposeNode\\7\\418":I
    move/from16 v30, v1

    const v1, -0x2942ffcf

    move/from16 v31, v11

    .end local v11    # "$dirty":I
    .local v31, "$dirty":I
    const-string v11, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v9, v1, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 421
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 422
    :cond_b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 423
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_c

    .line 424
    move-object/from16 v1, v29

    .end local v29    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 426
    .end local v1    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v29    # "factory\\7":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v1, v29

    .end local v29    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 428
    :goto_6
    move-object/from16 v29, v1

    .end local v1    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v29    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 429
    .local v33, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\428\\6":I
    sget-object v34, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v35, v9

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v35, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v34 .. v34}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v1, v10, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 430
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v1, v2, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 432
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .local v9, "block\\9":Lkotlin/jvm/functions/Function2;
    const/16 v34, 0x0

    .line 433
    .local v34, "$i$f$set-impl\\9\\432":I
    move-object/from16 v36, v1

    .local v36, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v37, 0x0

    .line 434
    .local v37, "$i$a$-with-Updater$set$1\\10\\433\\9":I
    invoke-interface/range {v36 .. v36}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v38

    if-nez v38, :cond_e

    move-object/from16 v38, v2

    .end local v2    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .local v38, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v36 .. v36}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v39, v10

    .end local v10    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v39, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v2, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_d

    goto :goto_7

    :cond_d
    move-object/from16 v10, v36

    goto :goto_8

    .end local v38    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v39    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_e
    move-object/from16 v38, v2

    move-object/from16 v39, v10

    .line 435
    .end local v2    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v38    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v39    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_7
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v10, v36

    .end local v36    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 436
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 438
    :goto_8
    nop

    .line 433
    .end local v10    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v37    # "$i$a$-with-Updater$set$1\\10\\433\\9":I
    nop

    .line 438
    nop

    .line 439
    .end local v9    # "block\\9":Lkotlin/jvm/functions/Function2;
    .end local v34    # "$i$f$set-impl\\9\\432":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 440
    nop

    .line 428
    .end local v1    # "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\428\\6":I
    nop

    .line 441
    shr-int/lit8 v1, v28, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\11":I
    move-object/from16 v2, v35

    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 442
    .local v9, "$i$a$-Layout-ColumnKt$Column$1\\11\\441\\5":I
    const v10, -0x16ef5699

    move/from16 v33, v1

    .end local v1    # "$changed\\11":I
    .local v33, "$changed\\11":I
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v2, v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v34, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v36, v21, 0x6

    and-int/lit8 v36, v36, 0x70

    or-int/lit8 v36, v36, 0x6

    .local v36, "$changed\\12":I
    check-cast v34, Landroidx/compose/foundation/layout/ColumnScope;

    .local v34, "$this$InstalledPlainPage_u24lambda_u2429\\12":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v61, v2

    .local v61, "$composer\\12":Landroidx/compose/runtime/Composer;
    const/16 v37, 0x0

    .line 176
    .local v37, "$i$a$-Column-StoreInstalledKt$InstalledPlainPage$2\\12\\442\\0":I
    const v10, -0x6d8ca294

    move-object/from16 v65, v2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v65, "$composer\\11":Landroidx/compose/runtime/Composer;
    const-string v2, "C175@9663L501,183@10173L29,184@10299L11,184@10211L714,193@10934L30,198@11372L10,194@10973L574:StoreInstalled.kt#o13vsk"

    move-object/from16 v66, v5

    move-object/from16 v5, v61

    .end local v61    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v66, "materialized\\6":Landroidx/compose/ui/Modifier;
    invoke-static {v5, v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x8

    .local v10, "$this$dp\\13":I
    const/16 v41, 0x0

    .line 443
    .local v41, "$i$f$getDp\\13\\176":I
    move/from16 v67, v9

    .end local v9    # "$i$a$-Layout-ColumnKt$Column$1\\11\\441\\5":I
    .local v67, "$i$a$-Layout-ColumnKt$Column$1\\11\\441\\5":I
    int-to-float v9, v10

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 176
    .end local v10    # "$this$dp\\13":I
    .end local v41    # "$i$f$getDp\\13\\176":I
    const/4 v10, 0x1

    move-object/from16 v68, v13

    move-object/from16 v69, v15

    const/4 v13, 0x0

    const/4 v15, 0x0

    .end local v13    # "lookup":Lorg/lighttouch/android/Lookup;
    .end local v15    # "horizontalAlignment\\5":Landroidx/compose/ui/Alignment$Horizontal;
    .local v68, "lookup":Lorg/lighttouch/android/Lookup;
    .local v69, "horizontalAlignment\\5":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v2, v13, v9, v10, v15}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\14":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v9

    .local v9, "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v13, 0x186

    .local v13, "$changed\\14":I
    const/4 v15, 0x0

    .line 444
    .local v15, "$i$f$Row\\14\\176":I
    const v10, 0x2952b718

    move/from16 v42, v13

    .end local v13    # "$changed\\14":I
    .local v42, "$changed\\14":I
    const-string v13, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v5, v10, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 445
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v10

    .line 449
    .local v10, "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v13, v42, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v43, v42, 0x3

    and-int/lit8 v43, v43, 0x70

    or-int v13, v13, v43

    invoke-static {v10, v9, v5, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v43, v42, 0x3

    and-int/lit8 v43, v43, 0x70

    .line 450
    nop

    .local v43, "$changed\\15":I
    const/16 v44, 0x0

    .line 451
    .local v44, "$i$f$Layout\\15\\450":I
    move-object/from16 v45, v9

    const v9, -0x4ee9b9da

    .end local v9    # "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .local v45, "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v5, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 452
    const/4 v9, 0x0

    invoke-static {v5, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v46

    .line 453
    .local v46, "compositeKeyHash\\15":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 454
    .local v9, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v47, v10

    .end local v10    # "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v47, "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v5, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 456
    .local v10, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v48, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v48 .. v48}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v48

    move-object/from16 v49, v2

    .end local v2    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v49, "modifier\\14":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v43, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 455
    nop

    .local v2, "$changed\\16":I
    move-object/from16 v50, v48

    .local v50, "factory\\16":Lkotlin/jvm/functions/Function0;
    const/16 v48, 0x0

    .line 457
    .local v48, "$i$f$ReusableComposeNode\\16\\455":I
    move/from16 v51, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\16":I
    .local v51, "$changed\\16":I
    invoke-static {v5, v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 458
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 459
    :cond_f
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 460
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_10

    .line 461
    move-object/from16 v2, v50

    .end local v50    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 463
    .end local v2    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v50    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v2, v50

    .end local v50    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 465
    :goto_9
    move-object/from16 v50, v2

    .end local v2    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v50    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 466
    .local v52, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\465\\15":I
    sget-object v53, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v54, v15

    .end local v15    # "$i$f$Row\\14\\176":I
    .local v54, "$i$f$Row\\14\\176":I
    invoke-virtual/range {v53 .. v53}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    invoke-static {v2, v13, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 467
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    invoke-static {v2, v9, v15}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 469
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    .local v15, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v53, 0x0

    .line 470
    .local v53, "$i$f$set-impl\\18\\469":I
    move-object/from16 v55, v2

    .local v55, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v56, 0x0

    .line 471
    .local v56, "$i$a$-with-Updater$set$1\\19\\470\\18":I
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v57

    if-nez v57, :cond_12

    move-object/from16 v57, v9

    .end local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .local v57, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v58, v13

    .end local v13    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v58, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v9, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_11

    goto :goto_a

    :cond_11
    move-object/from16 v13, v55

    goto :goto_b

    .end local v57    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v58    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v13    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_12
    move-object/from16 v57, v9

    move-object/from16 v58, v13

    .line 472
    .end local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v13    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v57    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v58    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_a
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v13, v55

    .end local v55    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v13, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v13, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 473
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v2, v9, v15}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 475
    :goto_b
    nop

    .line 470
    .end local v13    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v56    # "$i$a$-with-Updater$set$1\\19\\470\\18":I
    nop

    .line 475
    nop

    .line 476
    .end local v15    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v53    # "$i$f$set-impl\\18\\469":I
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v2, v10, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 477
    nop

    .line 465
    .end local v2    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\465\\15":I
    nop

    .line 478
    shr-int/lit8 v2, v51, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\20":I
    move-object v9, v5

    .local v9, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 479
    .local v13, "$i$a$-Layout-RowKt$Row$1\\20\\478\\14":I
    const v15, -0x184f2606

    move/from16 v52, v2

    .end local v2    # "$changed\\20":I
    .local v52, "$changed\\20":I
    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v9, v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v15, v42, 0x6

    and-int/lit8 v15, v15, 0x70

    or-int/lit8 v15, v15, 0x6

    .local v15, "$changed\\21":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2425\\21":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v62, v9

    .local v62, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 177
    .local v53, "$i$a$-Row-StoreInstalledKt$InstalledPlainPage$2$1\\21\\479\\12":I
    move-object/from16 v55, v2

    .end local v2    # "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2425\\21":Landroidx/compose/foundation/layout/RowScope;
    .local v55, "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2425\\21":Landroidx/compose/foundation/layout/RowScope;
    const v2, 0x521b6b9e

    move-object/from16 v56, v9

    .end local v9    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v56, "$composer\\20":Landroidx/compose/runtime/Composer;
    const-string v9, "C176@9764L28,177@9805L29,178@9847L307:StoreInstalled.kt#o13vsk"

    move-object/from16 v70, v10

    move-object/from16 v10, v62

    .end local v62    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v70, "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v10, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getTitle()Ljava/lang/String;

    move-result-object v61

    const/16 v63, 0x36

    const/16 v64, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x48

    .end local v10    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v62    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v59 .. v64}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 178
    .end local v62    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\21":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v9, 0x10

    .local v9, "$this$dp\\22":I
    const/16 v59, 0x0

    .line 480
    .local v59, "$i$f$getDp\\22\\178":I
    move/from16 v60, v13

    .end local v13    # "$i$a$-Layout-RowKt$Row$1\\20\\478\\14":I
    .local v60, "$i$a$-Layout-RowKt$Row$1\\20\\478\\14":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 178
    .end local v9    # "$this$dp\\22":I
    .end local v59    # "$i$f$getDp\\22\\178":I
    invoke-static {v2, v9}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    move/from16 v9, v30

    invoke-static {v2, v10, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 179
    const/16 v20, 0x0

    move/from16 v2, v20

    .local v2, "$changed\\23":I
    const/4 v9, 0x0

    .line 481
    .local v9, "$i$f$Column\\23\\179":I
    const v13, -0x1cd0f17e

    invoke-static {v10, v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 482
    sget-object v13, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v13, Landroidx/compose/ui/Modifier;

    .line 483
    .local v13, "modifier\\23":Landroidx/compose/ui/Modifier;
    sget-object v59, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move/from16 v61, v2

    .end local v2    # "$changed\\23":I
    .local v61, "$changed\\23":I
    invoke-virtual/range {v59 .. v59}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v2

    .line 484
    .local v2, "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v59, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v62, v9

    .end local v9    # "$i$f$Column\\23\\179":I
    .local v62, "$i$f$Column\\23\\179":I
    invoke-virtual/range {v59 .. v59}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 487
    .local v9, "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v59, v61, 0x3

    and-int/lit8 v59, v59, 0xe

    shr-int/lit8 v63, v61, 0x3

    and-int/lit8 v63, v63, 0x70

    move/from16 v64, v15

    .end local v15    # "$changed\\21":I
    .local v64, "$changed\\21":I
    or-int v15, v59, v63

    invoke-static {v2, v9, v10, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v59, v61, 0x3

    and-int/lit8 v59, v59, 0x70

    .line 488
    nop

    .local v59, "$changed\\24":I
    const/16 v63, 0x0

    .line 489
    .local v63, "$i$f$Layout\\24\\488":I
    move-object/from16 v71, v2

    const v2, -0x4ee9b9da

    .end local v2    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v71, "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v10, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 490
    const/4 v2, 0x0

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v72

    .line 491
    .local v72, "compositeKeyHash\\24":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 492
    .local v2, "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v73, v9

    .end local v9    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    .local v73, "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v10, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 494
    .local v9, "materialized\\24":Landroidx/compose/ui/Modifier;
    sget-object v74, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v74 .. v74}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v74

    move-object/from16 v75, v13

    .end local v13    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .local v75, "modifier\\23":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v13, v59, 0x6

    and-int/lit16 v13, v13, 0x380

    const/16 v30, 0x6

    or-int/lit8 v13, v13, 0x6

    .line 493
    nop

    .local v13, "$changed\\25":I
    move-object/from16 v76, v74

    .local v76, "factory\\25":Lkotlin/jvm/functions/Function0;
    const/16 v74, 0x0

    .line 495
    .local v74, "$i$f$ReusableComposeNode\\25\\493":I
    move/from16 v77, v13

    const v13, -0x2942ffcf

    .end local v13    # "$changed\\25":I
    .local v77, "$changed\\25":I
    invoke-static {v10, v13, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 496
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v13

    instance-of v13, v13, Landroidx/compose/runtime/Applier;

    if-nez v13, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 497
    :cond_13
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 498
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v13

    if-eqz v13, :cond_14

    .line 499
    move-object/from16 v13, v76

    .end local v76    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .local v13, "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 501
    .end local v13    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .restart local v76    # "factory\\25":Lkotlin/jvm/functions/Function0;
    :cond_14
    move-object/from16 v13, v76

    .end local v76    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .restart local v13    # "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 503
    :goto_c
    move-object/from16 v76, v10

    .end local v10    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v76, "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .local v10, "$this$Layout_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    const/16 v78, 0x0

    .line 504
    .local v78, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\26\\503\\24":I
    sget-object v79, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v80, v13

    .end local v13    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .local v80, "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v79 .. v79}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v10, v15, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 505
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 507
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\27":Lkotlin/jvm/functions/Function2;
    const/16 v79, 0x0

    .line 508
    .local v79, "$i$f$set-impl\\27\\507":I
    move-object/from16 v81, v10

    .local v81, "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    const/16 v82, 0x0

    .line 509
    .local v82, "$i$a$-with-Updater$set$1\\28\\508\\27":I
    invoke-interface/range {v81 .. v81}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v83

    if-nez v83, :cond_16

    move-object/from16 v83, v2

    .end local v2    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .local v83, "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v81 .. v81}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v84, v15

    .end local v15    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v84, "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v72 .. v72}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_15

    goto :goto_d

    :cond_15
    move-object/from16 v15, v81

    goto :goto_e

    .end local v83    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v84    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v15    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_16
    move-object/from16 v83, v2

    move-object/from16 v84, v15

    .line 510
    .end local v2    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v83    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v84    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_d
    invoke-static/range {v72 .. v72}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v15, v81

    .end local v81    # "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .local v15, "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 511
    invoke-static/range {v72 .. v72}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v10, v2, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 513
    :goto_e
    nop

    .line 508
    .end local v15    # "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .end local v82    # "$i$a$-with-Updater$set$1\\28\\508\\27":I
    nop

    .line 513
    nop

    .line 514
    .end local v13    # "block\\27":Lkotlin/jvm/functions/Function2;
    .end local v79    # "$i$f$set-impl\\27\\507":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v10, v9, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 515
    nop

    .line 503
    .end local v10    # "$this$Layout_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .end local v78    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\26\\503\\24":I
    nop

    .line 516
    shr-int/lit8 v2, v77, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\29":I
    move-object/from16 v10, v76

    .local v10, "$composer\\29":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 517
    .local v13, "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    const v15, -0x16ef5699

    invoke-static {v10, v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v15, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v78, v61, 0x6

    and-int/lit8 v78, v78, 0x70

    const/16 v30, 0x6

    or-int/lit8 v78, v78, 0x6

    .local v78, "$changed\\30":I
    check-cast v15, Landroidx/compose/foundation/layout/ColumnScope;

    .local v15, "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2425_u24lambda_u2424\\30":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v106, v10

    .local v106, "$composer\\30":Landroidx/compose/runtime/Composer;
    const/16 v79, 0x0

    .line 180
    .local v79, "$i$a$-Column-StoreInstalledKt$InstalledPlainPage$2$1$1\\30\\517\\21":I
    move/from16 v81, v2

    .end local v2    # "$changed\\29":I
    .local v81, "$changed\\29":I
    const v2, -0x1f25595e

    move-object/from16 v82, v9

    .end local v9    # "materialized\\24":Landroidx/compose/ui/Modifier;
    .local v82, "materialized\\24":Landroidx/compose/ui/Modifier;
    const-string v9, "C179@9910L10,179@9872L108,180@10066L10,180@10111L11,180@9997L143:StoreInstalled.kt#o13vsk"

    move-object/from16 v110, v10

    .end local v106    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v110, "$composer\\29":Landroidx/compose/runtime/Composer;
    invoke-static {v10, v2, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getTitle()Ljava/lang/String;

    move-result-object v85

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v105

    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v100

    const/16 v108, 0xc30

    const v109, 0xd7fe

    const/16 v86, 0x0

    const-wide/16 v87, 0x0

    const-wide/16 v89, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const-wide/16 v98, 0x0

    const/16 v101, 0x0

    const/16 v102, 0x2

    const/16 v103, 0x0

    const/16 v104, 0x0

    const/16 v107, 0x0

    .end local v10    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v106    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v85 .. v109}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 181
    .end local v106    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getVersion()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_17

    .line 307
    .local v2, "it\\31":Ljava/lang/String;
    const/4 v9, 0x0

    .line 181
    .local v9, "$i$a$-let-StoreInstalledKt$InstalledPlainPage$2$1$1$1\\31\\181\\30":I
    move/from16 v85, v9

    .end local v9    # "$i$a$-let-StoreInstalledKt$InstalledPlainPage$2$1$1$1\\31\\181\\30":I
    .local v85, "$i$a$-let-StoreInstalledKt$InstalledPlainPage$2$1$1$1\\31\\181\\30":I
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v111, v13

    .end local v13    # "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    .local v111, "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    const-string v13, "\u7248\u672c "

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .end local v2    # "it\\31":Ljava/lang/String;
    .end local v85    # "$i$a$-let-StoreInstalledKt$InstalledPlainPage$2$1$1$1\\31\\181\\30":I
    if-nez v2, :cond_18

    goto :goto_f

    .end local v111    # "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    .restart local v13    # "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    :cond_17
    move/from16 v111, v13

    .end local v13    # "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    .restart local v111    # "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    :goto_f
    const-string v2, ""

    :cond_18
    move-object/from16 v85, v2

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v105

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v10, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v87

    const/16 v108, 0x0

    const v109, 0xfffa

    const/16 v86, 0x0

    const-wide/16 v89, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const-wide/16 v98, 0x0

    const/16 v100, 0x0

    const/16 v101, 0x0

    const/16 v102, 0x0

    const/16 v103, 0x0

    const/16 v104, 0x0

    const/16 v107, 0x0

    move-object/from16 v106, v10

    .end local v10    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .restart local v106    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v85 .. v109}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 180
    invoke-static/range {v106 .. v106}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 182
    nop

    .line 517
    .end local v15    # "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2425_u24lambda_u2424\\30":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v78    # "$changed\\30":I
    .end local v79    # "$i$a$-Column-StoreInstalledKt$InstalledPlainPage$2$1$1\\30\\517\\21":I
    .end local v106    # "$composer\\30":Landroidx/compose/runtime/Composer;
    invoke-static/range {v110 .. v110}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 516
    .end local v81    # "$changed\\29":I
    .end local v110    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .end local v111    # "$i$a$-Layout-ColumnKt$Column$1\\29\\516\\23":I
    nop

    .line 518
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 495
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 519
    nop

    .line 489
    .end local v74    # "$i$f$ReusableComposeNode\\25\\493":I
    .end local v77    # "$changed\\25":I
    .end local v80    # "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 520
    nop

    .line 481
    .end local v59    # "$changed\\24":I
    .end local v63    # "$i$f$Layout\\24\\488":I
    .end local v72    # "compositeKeyHash\\24":I
    .end local v82    # "materialized\\24":Landroidx/compose/ui/Modifier;
    .end local v83    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 521
    nop

    .line 177
    .end local v61    # "$changed\\23":I
    .end local v62    # "$i$f$Column\\23\\179":I
    .end local v71    # "verticalArrangement\\23":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v73    # "horizontalAlignment\\23":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v75    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .end local v84    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v76 .. v76}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 183
    nop

    .line 479
    .end local v53    # "$i$a$-Row-StoreInstalledKt$InstalledPlainPage$2$1\\21\\479\\12":I
    .end local v55    # "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2425\\21":Landroidx/compose/foundation/layout/RowScope;
    .end local v64    # "$changed\\21":I
    .end local v76    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 478
    .end local v52    # "$changed\\20":I
    .end local v56    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v60    # "$i$a$-Layout-RowKt$Row$1\\20\\478\\14":I
    nop

    .line 522
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 457
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 523
    nop

    .line 451
    .end local v48    # "$i$f$ReusableComposeNode\\16\\455":I
    .end local v50    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v51    # "$changed\\16":I
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 524
    nop

    .line 444
    .end local v43    # "$changed\\15":I
    .end local v44    # "$i$f$Layout\\15\\450":I
    .end local v46    # "compositeKeyHash\\15":I
    .end local v57    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v70    # "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 525
    nop

    .line 184
    .end local v42    # "$changed\\14":I
    .end local v45    # "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .end local v47    # "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v49    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .end local v54    # "$i$f$Row\\14\\176":I
    .end local v58    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v9, 0x8

    .local v9, "$this$dp\\32":I
    const/4 v10, 0x0

    .line 526
    .local v10, "$i$f$getDp\\32\\184":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 184
    .end local v9    # "$this$dp\\32":I
    .end local v10    # "$i$f$getDp\\32\\184":I
    invoke-static {v2, v9}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/4 v9, 0x6

    invoke-static {v2, v5, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 185
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v9, 0x1

    const/4 v13, 0x0

    const/4 v15, 0x0

    invoke-static {v2, v13, v9, v15}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v9, 0x14

    .local v9, "$this$dp\\33":I
    const/4 v10, 0x0

    .line 527
    .local v10, "$i$f$getDp\\33\\185":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 185
    .end local v9    # "$this$dp\\33":I
    .end local v10    # "$i$f$getDp\\33\\185":I
    invoke-static {v9}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v9}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v41

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v42

    const/16 v45, 0x2

    const/16 v46, 0x0

    const/16 v44, 0x0

    invoke-static/range {v41 .. v46}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v9, 0x10

    .local v9, "$this$dp\\34":I
    const/4 v10, 0x0

    .line 527
    .local v10, "$i$f$getDp\\34\\185":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 185
    .end local v9    # "$this$dp\\34":I
    .end local v10    # "$i$f$getDp\\34\\185":I
    invoke-static {v2, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\35":Landroidx/compose/ui/Modifier;
    const/4 v9, 0x0

    .local v9, "$changed\\35":I
    const/4 v10, 0x0

    .line 528
    .local v10, "$i$f$Column\\35\\185":I
    const v13, -0x1cd0f17e

    invoke-static {v5, v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 529
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v3

    .line 530
    .local v3, "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 533
    .local v13, "horizontalAlignment\\35":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v15, v9, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v18, v9, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v15, v15, v18

    invoke-static {v3, v13, v5, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\35":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v18, v9, 0x3

    and-int/lit8 v18, v18, 0x70

    .line 534
    nop

    .local v18, "$changed\\36":I
    const/16 v41, 0x0

    .line 535
    .local v41, "$i$f$Layout\\36\\534":I
    move-object/from16 v42, v3

    const v3, -0x4ee9b9da

    .end local v3    # "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v42, "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 536
    const/4 v3, 0x0

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 537
    .local v3, "compositeKeyHash\\36":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 538
    .local v4, "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v20, v3

    .end local v3    # "compositeKeyHash\\36":I
    .local v20, "compositeKeyHash\\36":I
    invoke-static {v5, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 540
    .local v3, "materialized\\36":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v43, v2

    .end local v2    # "modifier\\35":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\35":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v18, 0x6

    and-int/lit16 v2, v2, 0x380

    const/16 v30, 0x6

    or-int/lit8 v2, v2, 0x6

    .line 539
    nop

    .local v2, "$changed\\37":I
    move-object/from16 v44, v23

    .local v44, "factory\\37":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 541
    .local v23, "$i$f$ReusableComposeNode\\37\\539":I
    move/from16 v45, v2

    const v2, -0x2942ffcf

    .end local v2    # "$changed\\37":I
    .local v45, "$changed\\37":I
    invoke-static {v5, v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 542
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_19

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 543
    :cond_19
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 544
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_1a

    .line 545
    move-object/from16 v2, v44

    .end local v44    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 547
    .end local v2    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\37":Lkotlin/jvm/functions/Function0;
    :cond_1a
    move-object/from16 v2, v44

    .end local v44    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 549
    :goto_10
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .local v11, "$this$Layout_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 550
    .local v32, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\38\\549\\36":I
    sget-object v44, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v46, v2

    .end local v2    # "factory\\37":Lkotlin/jvm/functions/Function0;
    .local v46, "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v44 .. v44}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v11, v15, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 551
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v11, v4, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 553
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\39":Lkotlin/jvm/functions/Function2;
    const/16 v44, 0x0

    .line 554
    .local v44, "$i$f$set-impl\\39\\553":I
    move-object/from16 v47, v11

    .local v47, "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    const/16 v48, 0x0

    .line 555
    .local v48, "$i$a$-with-Updater$set$1\\40\\554\\39":I
    invoke-interface/range {v47 .. v47}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v49

    if-nez v49, :cond_1c

    move-object/from16 v49, v4

    .end local v4    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .local v49, "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v47 .. v47}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v50, v9

    .end local v9    # "$changed\\35":I
    .local v50, "$changed\\35":I
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1b

    goto :goto_11

    :cond_1b
    move-object/from16 v9, v47

    goto :goto_12

    .end local v49    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "$changed\\35":I
    .restart local v4    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "$changed\\35":I
    :cond_1c
    move-object/from16 v49, v4

    move/from16 v50, v9

    .line 556
    .end local v4    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "$changed\\35":I
    .restart local v49    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v50    # "$changed\\35":I
    :goto_11
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v9, v47

    .end local v47    # "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 557
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v11, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 559
    :goto_12
    nop

    .line 554
    .end local v9    # "$this$set_impl_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .end local v48    # "$i$a$-with-Updater$set$1\\40\\554\\39":I
    nop

    .line 559
    nop

    .line 560
    .end local v2    # "block\\39":Lkotlin/jvm/functions/Function2;
    .end local v44    # "$i$f$set-impl\\39\\553":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v11, v3, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 561
    nop

    .line 549
    .end local v11    # "$this$Layout_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\38\\549\\36":I
    nop

    .line 562
    shr-int/lit8 v2, v45, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\41":I
    move-object v4, v5

    .local v4, "$composer\\41":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 563
    .local v9, "$i$a$-Layout-ColumnKt$Column$1\\41\\562\\35":I
    const v11, -0x16ef5699

    invoke-static {v4, v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v11, v50, 0x6

    and-int/lit8 v11, v11, 0x70

    const/16 v30, 0x6

    or-int/lit8 v11, v11, 0x6

    .local v11, "$changed\\42":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2426\\42":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v91, v4

    .local v91, "$composer\\42":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 186
    .local v32, "$i$a$-Column-StoreInstalledKt$InstalledPlainPage$2$2\\42\\563\\12":I
    move-object/from16 v40, v1

    .end local v1    # "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2426\\42":Landroidx/compose/foundation/layout/ColumnScope;
    .local v40, "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2426\\42":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x6b9b0866

    move/from16 v44, v2

    .end local v2    # "$changed\\41":I
    .local v44, "$changed\\41":I
    const-string v2, "C185@10400L10,185@10446L11,185@10359L116,186@10529L10,186@10488L63:StoreInstalled.kt#o13vsk"

    move-object/from16 v47, v3

    move-object/from16 v3, v91

    .end local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\42":Landroidx/compose/runtime/Composer;
    .local v47, "materialized\\36":Landroidx/compose/ui/Modifier;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v90

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v72

    const/16 v93, 0x0

    const v94, 0xfffa

    const-string v70, "\u6807\u8bc6\u7b26"

    const/16 v71, 0x0

    const-wide/16 v74, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const-wide/16 v79, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const-wide/16 v83, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x0

    const/16 v92, 0x6

    .end local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v70 .. v94}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 187
    .end local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v70

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v90

    const v94, 0xfffe

    const-wide/16 v72, 0x0

    const/16 v92, 0x0

    .end local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v70 .. v94}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    const v1, 0x2480f810

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "188@10666L30,189@10749L10,189@10795L11,189@10713L111,190@10879L10,190@10841L60"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 188
    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getShortVersion()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1d

    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getBuild()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1d

    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getBuild()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getShortVersion()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d

    .line 189
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xc

    .local v2, "$this$dp\\43":I
    const/16 v48, 0x0

    .line 564
    .local v48, "$i$f$getDp\\43\\189":I
    move-object/from16 v51, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\41":Landroidx/compose/runtime/Composer;
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 189
    .end local v2    # "$this$dp\\43":I
    .end local v48    # "$i$f$getDp\\43\\189":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v3, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 190
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v90

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v72

    const/16 v93, 0x0

    const v94, 0xfffa

    const-string v70, "\u7248\u672c\u53f7"

    const/16 v71, 0x0

    const-wide/16 v74, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const-wide/16 v79, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const-wide/16 v83, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x0

    const/16 v92, 0x6

    move-object/from16 v91, v3

    .end local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v70 .. v94}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 191
    .end local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-virtual {v7}, Lorg/lighttouch/android/InstalledApp;->getBuild()Ljava/lang/String;

    move-result-object v70

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v90

    const v94, 0xfffe

    const-wide/16 v72, 0x0

    const/16 v92, 0x0

    .end local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v70 .. v94}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    goto :goto_13

    .line 188
    .end local v51    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    :cond_1d
    move-object/from16 v91, v3

    move-object/from16 v51, v4

    .line 191
    .end local v3    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v51    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    :goto_13
    invoke-interface/range {v91 .. v91}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 186
    invoke-static/range {v91 .. v91}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 193
    nop

    .line 563
    .end local v11    # "$changed\\42":I
    .end local v32    # "$i$a$-Column-StoreInstalledKt$InstalledPlainPage$2$2\\42\\563\\12":I
    .end local v40    # "$this$InstalledPlainPage_u24lambda_u2429_u24lambda_u2426\\42":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v91    # "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 562
    .end local v9    # "$i$a$-Layout-ColumnKt$Column$1\\41\\562\\35":I
    .end local v44    # "$changed\\41":I
    .end local v51    # "$composer\\41":Landroidx/compose/runtime/Composer;
    nop

    .line 565
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 541
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 566
    nop

    .line 535
    .end local v23    # "$i$f$ReusableComposeNode\\37\\539":I
    .end local v45    # "$changed\\37":I
    .end local v46    # "factory\\37":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 567
    nop

    .line 528
    .end local v18    # "$changed\\36":I
    .end local v20    # "compositeKeyHash\\36":I
    .end local v41    # "$i$f$Layout\\36\\534":I
    .end local v47    # "materialized\\36":Landroidx/compose/ui/Modifier;
    .end local v49    # "localMap\\36":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 568
    nop

    .line 194
    .end local v10    # "$i$f$Column\\35\\185":I
    .end local v13    # "horizontalAlignment\\35":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v15    # "measurePolicy\\35":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v42    # "verticalArrangement\\35":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v43    # "modifier\\35":Landroidx/compose/ui/Modifier;
    .end local v50    # "$changed\\35":I
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xc

    .local v2, "$this$dp\\44":I
    const/4 v3, 0x0

    .line 569
    .local v3, "$i$f$getDp\\44\\194":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 194
    .end local v2    # "$this$dp\\44":I
    .end local v3    # "$i$f$getDp\\44\\194":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v9, 0x6

    invoke-static {v1, v5, v9}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 195
    nop

    .line 196
    if-nez v68, :cond_1e

    invoke-virtual {v12}, Lorg/lighttouch/android/InstalledList;->getLookupError()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1e

    const-string v1, "\u6b63\u5728\u65e7\u7248\u5546\u5e97\u4e2d\u67e5\u627e\u6b64\u5e94\u7528\u2026"

    move-object/from16 v40, v1

    goto :goto_14

    .line 197
    :cond_1e
    if-nez v68, :cond_1f

    invoke-virtual {v12}, Lorg/lighttouch/android/InstalledList;->getLookupError()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u65e0\u6cd5\u8bbf\u95ee\u65e7\u7248\u5546\u5e97\uff1a"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move-object/from16 v40, v1

    goto :goto_14

    .line 198
    :cond_1f
    const-string v1, "\u65e7\u7248\u5546\u5e97\u6ca1\u6709\u6536\u5f55\u6b64\u5e94\u7528\uff0c\u56e0\u6b64\u6ca1\u6709\u8be6\u60c5\u9875\uff0c\u4e5f\u6ca1\u6709\u53ef\u63d0\u4f9b\u7684\u65b0\u7248\u672c\u3002"

    move-object/from16 v40, v1

    .line 195
    :goto_14
    nop

    .line 199
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x4

    .local v2, "$this$dp\\45":I
    const/4 v3, 0x0

    .line 570
    .local v3, "$i$f$getDp\\45\\199":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 199
    .end local v2    # "$this$dp\\45":I
    .end local v3    # "$i$f$getDp\\45\\199":I
    const/4 v4, 0x2

    const/4 v13, 0x0

    const/4 v15, 0x0

    invoke-static {v1, v2, v13, v4, v15}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v41

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v60

    .line 200
    if-nez v68, :cond_20

    invoke-virtual {v12}, Lorg/lighttouch/android/InstalledList;->getLookupError()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_20

    const v1, -0x459851a0

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "199@11481L11"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v1

    goto :goto_15

    :cond_20
    const v1, -0x45984cf5

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "199@11518L11"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v1

    :goto_15
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v42, v1

    .line 195
    nop

    .line 199
    nop

    .line 200
    nop

    .line 199
    nop

    .line 195
    const-wide/16 v44, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const-wide/16 v53, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v62, 0x30

    const/16 v63, 0x0

    const v64, 0xfff8

    move-object/from16 v61, v5

    .end local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v61, "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static/range {v40 .. v64}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v61    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    const v1, -0x4598494e

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "200@11630L22,200@11609L66"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 201
    if-nez v68, :cond_23

    invoke-virtual {v12}, Lorg/lighttouch/android/InstalledList;->getLookupError()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_23

    const v1, 0x4c5de2

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\46":Z
    move-object v2, v5

    .local v2, "$this$cache\\46":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 571
    .local v3, "$i$f$cache\\46\\201":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\46":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 572
    .local v9, "$i$a$-let-ComposerKt$cache$1\\47\\571\\46":I
    if-nez v1, :cond_22

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v4, v10, :cond_21

    goto :goto_16

    .line 576
    :cond_21
    move-object v11, v4

    goto :goto_17

    .line 573
    :cond_22
    :goto_16
    const/4 v10, 0x0

    .line 201
    .local v10, "$i$a$-cache-StoreInstalledKt$InstalledPlainPage$2$3\\48\\573\\12":I
    new-instance v11, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda7;

    invoke-direct {v11, v12}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/InstalledList;)V

    .line 573
    .end local v10    # "$i$a$-cache-StoreInstalledKt$InstalledPlainPage$2$3\\48\\573\\12":I
    nop

    .line 574
    .local v11, "value\\47":Ljava/lang/Object;
    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 575
    nop

    .line 572
    .end local v11    # "value\\47":Ljava/lang/Object;
    :goto_17
    nop

    .line 571
    .end local v4    # "it\\46":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\47\\571\\46":I
    nop

    .line 201
    .end local v1    # "invalid\\46":Z
    .end local v2    # "$this$cache\\46":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\46\\201":I
    move-object/from16 v40, v11

    check-cast v40, Lkotlin/jvm/functions/Function0;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;->getLambda$-592599949$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v49

    const/high16 v51, 0x30000000

    const/16 v52, 0x1fe

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    move-object/from16 v50, v5

    .end local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static/range {v40 .. v52}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v50    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    :cond_23
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 176
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 202
    nop

    .line 442
    .end local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v34    # "$this$InstalledPlainPage_u24lambda_u2429\\12":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v36    # "$changed\\12":I
    .end local v37    # "$i$a$-Column-StoreInstalledKt$InstalledPlainPage$2\\12\\442\\0":I
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 441
    .end local v33    # "$changed\\11":I
    .end local v65    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v67    # "$i$a$-Layout-ColumnKt$Column$1\\11\\441\\5":I
    nop

    .line 577
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 420
    invoke-static/range {v35 .. v35}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 578
    nop

    .line 414
    .end local v26    # "$i$f$ReusableComposeNode\\7\\418":I
    .end local v28    # "$changed\\7":I
    .end local v29    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v35 .. v35}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 579
    nop

    .line 407
    .end local v17    # "$changed\\6":I
    .end local v19    # "$i$f$Layout\\6\\413":I
    .end local v24    # "compositeKeyHash\\6":I
    .end local v38    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v66    # "materialized\\6":Landroidx/compose/ui/Modifier;
    invoke-static/range {v35 .. v35}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 580
    nop

    .end local v21    # "$changed\\5":I
    .end local v22    # "$i$f$Column\\5\\175":I
    .end local v25    # "verticalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v27    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .end local v39    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v69    # "horizontalAlignment\\5":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_24

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v12    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v68    # "lookup":Lorg/lighttouch/android/Lookup;
    :cond_24
    :goto_18
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_25

    new-instance v2, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda8;

    invoke-direct {v2, v0, v6, v7, v8}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda8;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 203
    :cond_25
    return-void
.end method

.method private static final InstalledPlainPage$lambda$29$lambda$28$lambda$27(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;
    .locals 1
    .param p0, "$installed"    # Lorg/lighttouch/android/InstalledList;

    .line 201
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->lookUp()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InstalledPlainPage$lambda$30(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledPlainPage(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InstalledRow(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 78
    .param p0, "app"    # Lorg/lighttouch/android/InstalledApp;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 146
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const v3, -0x22bf3a4e

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(InstalledRow)150@7999L28,150@7929L1178:StoreInstalled.kt#o13vsk"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    const/4 v7, 0x4

    if-nez v6, :cond_1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    move v6, v7

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v5, v6

    :cond_1
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_3

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_1

    :cond_2
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v5, v6

    :cond_3
    and-int/lit8 v6, v5, 0x13

    const/16 v8, 0x12

    if-ne v6, v8, :cond_5

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_4

    goto :goto_2

    .line 399
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v26, v4

    move/from16 v22, v5

    goto/16 :goto_13

    .line 146
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, -0x1

    const-string v8, "org.lighttouch.android.InstalledRow (StoreInstalled.kt:145)"

    invoke-static {v3, v5, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 147
    :cond_6
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getInstalledList()Lorg/lighttouch/android/InstalledList;

    move-result-object v3

    .line 148
    .local v3, "installed":Lorg/lighttouch/android/InstalledList;
    invoke-virtual {v3}, Lorg/lighttouch/android/InstalledList;->getLookups()Ljava/util/Map;

    move-result-object v6

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    instance-of v8, v6, Lorg/lighttouch/android/Lookup$Found;

    const/4 v9, 0x0

    if-eqz v8, :cond_7

    check-cast v6, Lorg/lighttouch/android/Lookup$Found;

    goto :goto_3

    :cond_7
    move-object v6, v9

    :goto_3
    if-eqz v6, :cond_8

    invoke-virtual {v6}, Lorg/lighttouch/android/Lookup$Found;->getKnown()Lorg/lighttouch/android/LegacyStore$Known;

    move-result-object v6

    goto :goto_4

    :cond_8
    move-object v6, v9

    .line 149
    .local v6, "found":Lorg/lighttouch/android/LegacyStore$Known;
    :goto_4
    invoke-virtual {v3, v0}, Lorg/lighttouch/android/InstalledList;->update(Lorg/lighttouch/android/InstalledApp;)Ljava/lang/String;

    move-result-object v8

    .line 150
    .local v8, "update":Ljava/lang/String;
    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v1, v10}, Lorg/lighttouch/android/StoreModel;->queuedBundle(Ljava/lang/String;)Lorg/lighttouch/android/QueueItem;

    move-result-object v10

    if-eqz v10, :cond_9

    move-object v11, v10

    .line 307
    .local v11, "it\\1":Lorg/lighttouch/android/QueueItem;
    const/4 v12, 0x0

    .line 150
    .local v12, "$i$a$-takeIf-StoreInstalledKt$InstalledRow$queued$1\\1\\150\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v11

    .end local v11    # "it\\1":Lorg/lighttouch/android/QueueItem;
    .end local v12    # "$i$a$-takeIf-StoreInstalledKt$InstalledRow$queued$1\\1\\150\\0":I
    if-eqz v11, :cond_9

    goto :goto_5

    :cond_9
    move-object v10, v9

    .line 151
    .local v10, "queued":Lorg/lighttouch/android/QueueItem;
    :goto_5
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-static {v11, v12, v13, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/16 v12, 0x10

    .local v12, "$this$dp\\2":I
    const/4 v14, 0x0

    .line 312
    .local v14, "$i$f$getDp\\2\\151":I
    int-to-float v15, v12

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 151
    .end local v12    # "$this$dp\\2":I
    .end local v14    # "$i$f$getDp\\2\\151":I
    invoke-static {v12}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v12

    check-cast v12, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v11, v12}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    const v11, -0x615d173a

    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "CC(remember):StoreInstalled.kt#9igjgp"

    invoke-static {v4, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    and-int/lit8 v12, v5, 0xe

    if-ne v12, v7, :cond_a

    goto :goto_6

    :cond_a
    const/4 v13, 0x0

    :goto_6
    or-int v7, v11, v13

    .local v7, "invalid\\3":Z
    move-object v11, v4

    .local v11, "$this$cache\\3":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 313
    .local v12, "$i$f$cache\\3\\151":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\3":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 314
    .local v16, "$i$a$-let-ComposerKt$cache$1\\4\\313\\3":I
    if-nez v7, :cond_c

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v9

    if-ne v13, v9, :cond_b

    goto :goto_7

    .line 318
    :cond_b
    move-object v15, v13

    goto :goto_8

    .line 315
    :cond_c
    :goto_7
    const/4 v9, 0x0

    .line 151
    .local v9, "$i$a$-cache-StoreInstalledKt$InstalledRow$1\\5\\315\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda1;

    invoke-direct {v15, v1, v0}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;)V

    .line 315
    .end local v9    # "$i$a$-cache-StoreInstalledKt$InstalledRow$1\\5\\315\\0":I
    nop

    .line 316
    .local v15, "value\\4":Ljava/lang/Object;
    invoke-interface {v11, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 317
    nop

    .line 314
    .end local v15    # "value\\4":Ljava/lang/Object;
    :goto_8
    nop

    .line 313
    .end local v13    # "it\\3":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\4\\313\\3":I
    nop

    .line 151
    .end local v7    # "invalid\\3":Z
    .end local v11    # "$this$cache\\3":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\3\\151":I
    move-object/from16 v18, v15

    check-cast v18, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v19, 0x7

    const/16 v20, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/4 v7, 0x0

    const/16 v17, 0x0

    invoke-static/range {v14 .. v20}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    const/16 v11, 0x8

    .local v11, "$this$dp\\6":I
    const/4 v12, 0x0

    .line 312
    .local v12, "$i$f$getDp\\6\\151":I
    int-to-float v13, v11

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 151
    .end local v11    # "$this$dp\\6":I
    .end local v12    # "$i$f$getDp\\6\\151":I
    const/16 v12, 0x8

    .local v12, "$this$dp\\7":I
    const/4 v13, 0x0

    .line 312
    .local v13, "$i$f$getDp\\7\\151":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 151
    .end local v12    # "$this$dp\\7":I
    .end local v13    # "$i$f$getDp\\7\\151":I
    invoke-static {v9, v11, v12}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v9

    const-string v11, "store_installed_row"

    invoke-static {v9, v11}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 152
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v11

    .line 151
    const/16 v12, 0x180

    .local v9, "modifier\\8":Landroidx/compose/ui/Modifier;
    .local v11, "verticalAlignment\\8":Landroidx/compose/ui/Alignment$Vertical;
    .local v12, "$changed\\8":I
    const/4 v13, 0x0

    .line 319
    .local v13, "$i$f$Row\\8\\151":I
    const v14, 0x2952b718

    const-string v15, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v4, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 320
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v14

    .line 324
    .local v14, "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v15, v12, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v16, v12, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v15, v15, v16

    invoke-static {v14, v11, v4, v15}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\8":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v12, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 325
    nop

    .local v16, "$changed\\9":I
    const/16 v17, 0x0

    .line 326
    .local v17, "$i$f$Layout\\9\\325":I
    const v7, -0x4ee9b9da

    move-object/from16 v19, v3

    .end local v3    # "installed":Lorg/lighttouch/android/InstalledList;
    .local v19, "installed":Lorg/lighttouch/android/InstalledList;
    const-string v3, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v4, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 327
    const/4 v7, 0x0

    invoke-static {v4, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v21

    .line 328
    .local v21, "compositeKeyHash\\9":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 329
    .local v7, "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v22, v5

    .end local v5    # "$dirty":I
    .local v22, "$dirty":I
    invoke-static {v4, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 331
    .local v5, "materialized\\9":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v24, v6

    .end local v6    # "found":Lorg/lighttouch/android/LegacyStore$Known;
    .local v24, "found":Lorg/lighttouch/android/LegacyStore$Known;
    shl-int/lit8 v6, v16, 0x6

    and-int/lit16 v6, v6, 0x380

    move/from16 v25, v6

    const/4 v6, 0x6

    or-int/lit8 v25, v25, 0x6

    .line 330
    nop

    .local v25, "$changed\\10":I
    move-object/from16 v26, v23

    .local v26, "factory\\10":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 332
    .local v23, "$i$f$ReusableComposeNode\\10\\330":I
    move/from16 v27, v6

    const v6, -0x2942ffcf

    move-object/from16 v28, v9

    .end local v9    # "modifier\\8":Landroidx/compose/ui/Modifier;
    .local v28, "modifier\\8":Landroidx/compose/ui/Modifier;
    const-string v9, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v4, v6, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 333
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 334
    :cond_d
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 335
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_e

    .line 336
    move-object/from16 v6, v26

    .end local v26    # "factory\\10":Lkotlin/jvm/functions/Function0;
    .local v6, "factory\\10":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 338
    .end local v6    # "factory\\10":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\10":Lkotlin/jvm/functions/Function0;
    :cond_e
    move-object/from16 v6, v26

    .end local v26    # "factory\\10":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "factory\\10":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 340
    :goto_9
    move-object/from16 v26, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v26, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 341
    .local v30, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\11\\340\\9":I
    sget-object v31, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v32, v6

    .end local v6    # "factory\\10":Lkotlin/jvm/functions/Function0;
    .local v32, "factory\\10":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v4, v15, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 342
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v4, v7, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 344
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\12":Lkotlin/jvm/functions/Function2;
    const/16 v31, 0x0

    .line 345
    .local v31, "$i$f$set-impl\\12\\344":I
    move-object/from16 v33, v4

    .local v33, "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 346
    .local v34, "$i$a$-with-Updater$set$1\\13\\345\\12":I
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v35

    if-nez v35, :cond_10

    move-object/from16 v35, v7

    .end local v7    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .local v35, "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move-object/from16 v36, v10

    .end local v10    # "queued":Lorg/lighttouch/android/QueueItem;
    .local v36, "queued":Lorg/lighttouch/android/QueueItem;
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_f

    goto :goto_a

    :cond_f
    move-object/from16 v10, v33

    goto :goto_b

    .end local v35    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v36    # "queued":Lorg/lighttouch/android/QueueItem;
    .restart local v7    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v10    # "queued":Lorg/lighttouch/android/QueueItem;
    :cond_10
    move-object/from16 v35, v7

    move-object/from16 v36, v10

    .line 347
    .end local v7    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "queued":Lorg/lighttouch/android/QueueItem;
    .restart local v35    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v36    # "queued":Lorg/lighttouch/android/QueueItem;
    :goto_a
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v10, v33

    .end local v33    # "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 348
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v4, v7, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 350
    :goto_b
    nop

    .line 345
    .end local v10    # "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-with-Updater$set$1\\13\\345\\12":I
    nop

    .line 350
    nop

    .line 351
    .end local v6    # "block\\12":Lkotlin/jvm/functions/Function2;
    .end local v31    # "$i$f$set-impl\\12\\344":I
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v4, v5, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 352
    nop

    .line 340
    .end local v4    # "$this$Layout_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\11\\340\\9":I
    nop

    .line 353
    shr-int/lit8 v4, v25, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\14":I
    move-object/from16 v6, v26

    .local v6, "$composer\\14":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 354
    .local v7, "$i$a$-Layout-RowKt$Row$1\\14\\353\\8":I
    const v10, -0x184f2606

    move/from16 v30, v4

    .end local v4    # "$changed\\14":I
    .local v30, "$changed\\14":I
    const-string v4, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v6, v10, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v12, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\15":I
    check-cast v4, Landroidx/compose/foundation/layout/RowScope;

    .local v4, "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v40, v6

    .local v40, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 153
    .local v31, "$i$a$-Row-StoreInstalledKt$InstalledRow$2\\15\\354\\0":I
    move-object/from16 v33, v4

    .end local v4    # "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    .local v33, "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    const v4, 0x52bdc4aa

    move-object/from16 v34, v5

    .end local v5    # "materialized\\9":Landroidx/compose/ui/Modifier;
    .local v34, "materialized\\9":Landroidx/compose/ui/Modifier;
    const-string v5, "C152@8170L52,153@8231L29,154@8269L832:StoreInstalled.kt#o13vsk"

    move-object/from16 v47, v6

    .end local v40    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v47, "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    if-eqz v24, :cond_11

    invoke-virtual/range {v24 .. v24}, Lorg/lighttouch/android/LegacyStore$Known;->getApp()Lorg/json/JSONObject;

    move-result-object v4

    if-eqz v4, :cond_11

    const-string v5, "icon_url"

    invoke-static {v4, v5}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v37, v4

    goto :goto_c

    :cond_11
    const/16 v37, 0x0

    :goto_c
    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledApp;->getTitle()Ljava/lang/String;

    move-result-object v39

    const/16 v41, 0x30

    const/16 v42, 0x0

    const/16 v38, 0x34

    move-object/from16 v40, v6

    .end local v6    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .restart local v40    # "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static/range {v37 .. v42}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 154
    .end local v40    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\15":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0xe

    .local v5, "$this$dp\\16":I
    const/16 v37, 0x0

    .line 355
    .local v37, "$i$f$getDp\\16\\154":I
    move/from16 p2, v7

    .end local v7    # "$i$a$-Layout-RowKt$Row$1\\14\\353\\8":I
    .local p2, "$i$a$-Layout-RowKt$Row$1\\14\\353\\8":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 154
    .end local v5    # "$this$dp\\16":I
    .end local v37    # "$i$f$getDp\\16\\154":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    move/from16 v5, v27

    invoke-static {v4, v6, v5}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 155
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v42, v4

    check-cast v42, Landroidx/compose/ui/Modifier;

    const/16 v45, 0x2

    const/16 v46, 0x0

    const/high16 v43, 0x3f800000    # 1.0f

    const/16 v44, 0x0

    move-object/from16 v41, v33

    .end local v33    # "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    .local v41, "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v41 .. v46}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .end local v41    # "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    .local v4, "modifier\\17":Landroidx/compose/ui/Modifier;
    .restart local v33    # "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    const/4 v5, 0x0

    .local v5, "$changed\\17":I
    const/4 v7, 0x0

    .line 356
    .local v7, "$i$f$Column\\17\\155":I
    move/from16 v37, v5

    .end local v5    # "$changed\\17":I
    .local v37, "$changed\\17":I
    const v5, -0x1cd0f17e

    move/from16 v38, v7

    .end local v7    # "$i$f$Column\\17\\155":I
    .local v38, "$i$f$Column\\17\\155":I
    const-string v7, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v6, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 357
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v5

    .line 358
    .local v5, "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    .line 361
    .local v7, "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v39, v37, 0x3

    and-int/lit8 v39, v39, 0xe

    shr-int/lit8 v40, v37, 0x3

    and-int/lit8 v40, v40, 0x70

    move/from16 v41, v10

    .end local v10    # "$changed\\15":I
    .local v41, "$changed\\15":I
    or-int v10, v39, v40

    invoke-static {v5, v7, v6, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\17":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v39, v37, 0x3

    and-int/lit8 v39, v39, 0x70

    .line 362
    nop

    .local v39, "$changed\\18":I
    const/16 v40, 0x0

    .line 363
    .local v40, "$i$f$Layout\\18\\362":I
    move-object/from16 v42, v5

    const v5, -0x4ee9b9da

    .end local v5    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v42, "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v6, v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 364
    const/4 v3, 0x0

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 365
    .local v3, "compositeKeyHash\\18":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 366
    .local v5, "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v18, v3

    .end local v3    # "compositeKeyHash\\18":I
    .local v18, "compositeKeyHash\\18":I
    invoke-static {v6, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 368
    .local v3, "materialized\\18":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move-object/from16 v43, v4

    .end local v4    # "modifier\\17":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\17":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v39, 0x6

    and-int/lit16 v4, v4, 0x380

    const/16 v27, 0x6

    or-int/lit8 v4, v4, 0x6

    .line 367
    move-object/from16 v44, v20

    .local v4, "$changed\\19":I
    .local v44, "factory\\19":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 369
    .local v20, "$i$f$ReusableComposeNode\\19\\367":I
    move/from16 v45, v4

    const v4, -0x2942ffcf

    .end local v4    # "$changed\\19":I
    .local v45, "$changed\\19":I
    invoke-static {v6, v4, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 370
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_12

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 371
    :cond_12
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 372
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_13

    .line 373
    move-object/from16 v4, v44

    .end local v44    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 375
    .end local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\19":Lkotlin/jvm/functions/Function0;
    :cond_13
    move-object/from16 v4, v44

    .end local v44    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 377
    :goto_d
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 378
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\20\\377\\18":I
    sget-object v44, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v46, v4

    .end local v4    # "factory\\19":Lkotlin/jvm/functions/Function0;
    .local v46, "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v44 .. v44}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v9, v10, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 379
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v9, v5, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 381
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\21":Lkotlin/jvm/functions/Function2;
    const/16 v44, 0x0

    .line 382
    .local v44, "$i$f$set-impl\\21\\381":I
    move-object/from16 v48, v9

    .local v48, "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    const/16 v49, 0x0

    .line 383
    .local v49, "$i$a$-with-Updater$set$1\\22\\382\\21":I
    invoke-interface/range {v48 .. v48}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v50

    if-nez v50, :cond_15

    move-object/from16 v50, v5

    .end local v5    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    .local v50, "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v48 .. v48}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v51, v6

    .end local v6    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_14

    goto :goto_e

    :cond_14
    move-object/from16 v6, v48

    goto :goto_f

    .end local v50    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v51    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .restart local v5    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "$composer\\15":Landroidx/compose/runtime/Composer;
    :cond_15
    move-object/from16 v50, v5

    move-object/from16 v51, v6

    .line 384
    .end local v5    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .restart local v50    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v51    # "$composer\\15":Landroidx/compose/runtime/Composer;
    :goto_e
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v48

    .end local v48    # "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 385
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v9, v5, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 387
    :goto_f
    nop

    .line 382
    .end local v6    # "$this$set_impl_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    .end local v49    # "$i$a$-with-Updater$set$1\\22\\382\\21":I
    nop

    .line 387
    nop

    .line 388
    .end local v4    # "block\\21":Lkotlin/jvm/functions/Function2;
    .end local v44    # "$i$f$set-impl\\21\\381":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v9, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 389
    nop

    .line 377
    .end local v9    # "$this$Layout_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\20\\377\\18":I
    nop

    .line 390
    shr-int/lit8 v4, v45, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\23":I
    move-object/from16 v5, v51

    .local v5, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 391
    .local v6, "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    const v9, -0x16ef5699

    move-object/from16 v29, v3

    .end local v3    # "materialized\\18":Landroidx/compose/ui/Modifier;
    .local v29, "materialized\\18":Landroidx/compose/ui/Modifier;
    const-string v3, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v5, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v37, 0x6

    and-int/lit8 v9, v9, 0x70

    const/16 v27, 0x6

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\24":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$InstalledRow_u24lambda_u2420_u24lambda_u2419\\24":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v73, v5

    .local v73, "$composer\\24":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 156
    .local v27, "$i$a$-Column-StoreInstalledKt$InstalledRow$2$1\\24\\391\\15":I
    move-object/from16 v44, v3

    .end local v3    # "$this$InstalledRow_u24lambda_u2420_u24lambda_u2419\\24":Landroidx/compose/foundation/layout/ColumnScope;
    .local v44, "$this$InstalledRow_u24lambda_u2420_u24lambda_u2419\\24":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, -0x596bb455

    move/from16 v48, v4

    .end local v4    # "$changed\\23":I
    .local v48, "$changed\\23":I
    const-string v4, "C155@8397L10,155@8311L108,157@8575L10,157@8619L11,156@8432L216:StoreInstalled.kt#o13vsk"

    move-object/from16 v49, v5

    .end local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\23":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledApp;->getTitle()Ljava/lang/String;

    move-result-object v52

    sget-object v3, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v67

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v72

    const/16 v75, 0xc30

    const v76, 0xd7fe

    const/16 v53, 0x0

    const-wide/16 v54, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x1

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v74, 0x0

    .end local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-static/range {v52 .. v76}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 157
    .end local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledApp;->getVersion()Ljava/lang/String;

    move-result-object v3

    const-string v4, "\u7248\u672c "

    if-eqz v3, :cond_16

    .line 307
    .local v3, "it\\25":Ljava/lang/String;
    const/16 v52, 0x0

    .line 157
    .local v52, "$i$a$-let-StoreInstalledKt$InstalledRow$2$1$1\\25\\157\\24":I
    move/from16 v77, v6

    .end local v6    # "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    .local v77, "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .end local v3    # "it\\25":Ljava/lang/String;
    .end local v52    # "$i$a$-let-StoreInstalledKt$InstalledRow$2$1$1\\25\\157\\24":I
    if-nez v3, :cond_17

    goto :goto_10

    .end local v77    # "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    .restart local v6    # "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    :cond_16
    move/from16 v77, v6

    .end local v6    # "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    .restart local v77    # "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    :goto_10
    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v3

    :cond_17
    move-object/from16 v52, v3

    sget-object v3, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v67

    .line 158
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v6}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v72

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v54

    .line 157
    nop

    .line 158
    nop

    .line 157
    nop

    .line 158
    nop

    .line 157
    const/16 v53, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x1

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v74, 0x0

    const/16 v75, 0xc30

    const v76, 0xd7fa

    move-object/from16 v73, v5

    .end local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-static/range {v52 .. v76}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 159
    .end local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    nop

    .line 160
    if-eqz v36, :cond_19

    const v3, -0x59660f53

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "159@8803L10,160@8869L11,159@8702L201"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {v36 .. v36}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v3

    sget-object v4, Lorg/lighttouch/android/QueueState;->PENDING:Lorg/lighttouch/android/QueueState;

    if-ne v3, v4, :cond_18

    const-string v3, "\u6392\u961f\u4e2d"

    goto :goto_11

    :cond_18
    invoke-virtual/range {v36 .. v36}, Lorg/lighttouch/android/QueueItem;->getPhase()Ljava/lang/String;

    move-result-object v3

    :goto_11
    move-object/from16 v52, v3

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v72

    .line 161
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v54

    .line 160
    nop

    .line 161
    nop

    .line 160
    const/16 v75, 0xc00

    const v76, 0xdffa

    const/16 v53, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x1

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v74, 0x0

    move-object/from16 v73, v5

    .end local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-static/range {v52 .. v76}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_12

    .line 162
    :cond_19
    if-eqz v8, :cond_1a

    const v3, -0x59628455

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "161@8997L10,161@9043L11,161@8938L139"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " \u53ef\u7528"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v72

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v54

    const/16 v75, 0xc00

    const v76, 0xdffa

    const/16 v53, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x1

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v74, 0x0

    move-object/from16 v73, v5

    .end local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-static/range {v52 .. v76}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v73    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_12

    .line 163
    :cond_1a
    const v3, -0x5960444a

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 156
    :goto_12
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 164
    nop

    .line 391
    .end local v5    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .end local v9    # "$changed\\24":I
    .end local v27    # "$i$a$-Column-StoreInstalledKt$InstalledRow$2$1\\24\\391\\15":I
    .end local v44    # "$this$InstalledRow_u24lambda_u2420_u24lambda_u2419\\24":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 390
    .end local v48    # "$changed\\23":I
    .end local v49    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v77    # "$i$a$-Layout-ColumnKt$Column$1\\23\\390\\17":I
    nop

    .line 392
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 369
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 393
    nop

    .line 363
    .end local v20    # "$i$f$ReusableComposeNode\\19\\367":I
    .end local v45    # "$changed\\19":I
    .end local v46    # "factory\\19":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 394
    nop

    .line 356
    .end local v18    # "compositeKeyHash\\18":I
    .end local v29    # "materialized\\18":Landroidx/compose/ui/Modifier;
    .end local v39    # "$changed\\18":I
    .end local v40    # "$i$f$Layout\\18\\362":I
    .end local v50    # "localMap\\18":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 395
    nop

    .line 153
    .end local v7    # "horizontalAlignment\\17":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "measurePolicy\\17":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v37    # "$changed\\17":I
    .end local v38    # "$i$f$Column\\17\\155":I
    .end local v42    # "verticalArrangement\\17":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v43    # "modifier\\17":Landroidx/compose/ui/Modifier;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 165
    nop

    .line 354
    .end local v31    # "$i$a$-Row-StoreInstalledKt$InstalledRow$2\\15\\354\\0":I
    .end local v33    # "$this$InstalledRow_u24lambda_u2420\\15":Landroidx/compose/foundation/layout/RowScope;
    .end local v41    # "$changed\\15":I
    .end local v51    # "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 353
    .end local v30    # "$changed\\14":I
    .end local v47    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local p2    # "$i$a$-Layout-RowKt$Row$1\\14\\353\\8":I
    nop

    .line 396
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 332
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 397
    nop

    .line 326
    .end local v23    # "$i$f$ReusableComposeNode\\10\\330":I
    .end local v25    # "$changed\\10":I
    .end local v32    # "factory\\10":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 398
    nop

    .line 319
    .end local v16    # "$changed\\9":I
    .end local v17    # "$i$f$Layout\\9\\325":I
    .end local v21    # "compositeKeyHash\\9":I
    .end local v34    # "materialized\\9":Landroidx/compose/ui/Modifier;
    .end local v35    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 399
    nop

    .end local v11    # "verticalAlignment\\8":Landroidx/compose/ui/Alignment$Vertical;
    .end local v12    # "$changed\\8":I
    .end local v13    # "$i$f$Row\\8\\151":I
    .end local v14    # "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v15    # "measurePolicy\\8":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v28    # "modifier\\8":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_1b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v8    # "update":Ljava/lang/String;
    .end local v19    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v24    # "found":Lorg/lighttouch/android/LegacyStore$Known;
    .end local v36    # "queued":Lorg/lighttouch/android/QueueItem;
    :cond_1b
    :goto_13
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_1c

    new-instance v4, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda2;

    invoke-direct {v4, v0, v1, v2}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 166
    :cond_1c
    return-void
.end method

.method private static final InstalledRow$lambda$17$lambda$16(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/InstalledApp;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/lighttouch/android/InstalledApp;

    .line 151
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreModel;->openInstalled(Lorg/lighttouch/android/InstalledApp;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InstalledRow$lambda$21(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledRow(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final InstalledTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZLandroidx/compose/runtime/Composer;I)V
    .locals 59
    .param p0, "$this$InstalledTab"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "running"    # Z
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move/from16 v8, p2

    move/from16 v9, p4

    const-string v1, "<this>"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "model"

    invoke-static {v7, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    const v1, -0x713ed36e

    move-object/from16 v2, p3

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(InstalledTab)111@5368L36,111@5321L83:StoreInstalled.kt#o13vsk"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p4

    .local v2, "$dirty":I
    and-int/lit8 v3, v9, 0x6

    if-nez v3, :cond_1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v9, 0x30

    if-nez v3, :cond_3

    invoke-interface {v4, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    and-int/lit16 v3, v9, 0x180

    const/16 v5, 0x100

    if-nez v3, :cond_5

    invoke-interface {v4, v8}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v3

    if-eqz v3, :cond_4

    move v3, v5

    goto :goto_2

    :cond_4
    const/16 v3, 0x80

    :goto_2
    or-int/2addr v2, v3

    :cond_5
    move v10, v2

    .end local v2    # "$dirty":I
    .local v10, "$dirty":I
    and-int/lit16 v2, v10, 0x93

    const/16 v3, 0x92

    if-ne v2, v3, :cond_7

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_6

    goto :goto_3

    .line 120
    :cond_6
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v22, v10

    goto/16 :goto_12

    .line 110
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.InstalledTab (StoreInstalled.kt:109)"

    invoke-static {v1, v10, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 111
    :cond_8
    invoke-virtual {v7}, Lorg/lighttouch/android/StoreModel;->getInstalledList()Lorg/lighttouch/android/InstalledList;

    move-result-object v11

    .line 112
    .local v11, "installed":Lorg/lighttouch/android/InstalledList;
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v7}, Lorg/lighttouch/android/StoreModel;->getTargetConfirmed()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const v6, -0x615d173a

    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "CC(remember):StoreInstalled.kt#9igjgp"

    invoke-static {v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v3, v10, 0x380

    if-ne v3, v5, :cond_9

    const/4 v3, 0x1

    goto :goto_4

    :cond_9
    const/4 v3, 0x0

    :goto_4
    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v3, v5

    .local v3, "invalid\\1":Z
    move-object v5, v4

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 205
    .local v15, "$i$f$cache\\1\\112":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\1":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 206
    .local v16, "$i$a$-let-ComposerKt$cache$1\\2\\205\\1":I
    const/4 v14, 0x0

    if-nez v3, :cond_b

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v6, v13, :cond_a

    goto :goto_5

    .line 210
    :cond_a
    move-object v0, v6

    goto :goto_6

    .line 207
    :cond_b
    :goto_5
    const/4 v13, 0x0

    .line 112
    .local v13, "$i$a$-cache-StoreInstalledKt$InstalledTab$1\\3\\207\\0":I
    new-instance v0, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$1$1;

    invoke-direct {v0, v8, v11, v14}, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$1$1;-><init>(ZLorg/lighttouch/android/InstalledList;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    .line 207
    .end local v13    # "$i$a$-cache-StoreInstalledKt$InstalledTab$1\\3\\207\\0":I
    nop

    .line 208
    .local v0, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 209
    nop

    .line 206
    .end local v0    # "value\\2":Ljava/lang/Object;
    :goto_6
    nop

    .line 205
    .end local v6    # "it\\1":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\2\\205\\1":I
    nop

    .line 112
    .end local v3    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\1\\112":I
    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    shr-int/lit8 v3, v10, 0x6

    and-int/lit8 v3, v3, 0xe

    invoke-static {v1, v2, v0, v4, v3}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 113
    invoke-virtual {v11}, Lorg/lighttouch/android/InstalledList;->getList()Ljava/util/List;

    move-result-object v13

    .line 114
    .local v13, "list":Ljava/util/List;
    nop

    .line 115
    if-nez v8, :cond_c

    const v0, -0x1cd78cc2

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "114@5466L108"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v10, 0xe

    or-int/lit16 v5, v0, 0x1b0

    const/4 v6, 0x4

    const-string v1, "\u542f\u52a8\u8bbe\u5907\u4ee5\u67e5\u770b\u5176\u5e94\u7528"

    const-string v2, "\u8bbe\u5907\u8fd0\u884c\u65f6\u624d\u4f1a\u8bfb\u53d6\u5176\u4e2d\u7684\u5e94\u7528\u3002"

    const/4 v3, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledMessage(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v22, v10

    move-object v1, v11

    move-object v2, v13

    goto/16 :goto_11

    .line 116
    :cond_c
    invoke-virtual {v7}, Lorg/lighttouch/android/StoreModel;->getServicesAvailable()Z

    move-result v0

    if-nez v0, :cond_d

    const v0, -0x1cd77aa5

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "115@5611L105"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v10, 0xe

    or-int/lit16 v5, v0, 0x1b0

    const/4 v6, 0x4

    const-string v1, "\u6b64\u7248\u672c\u4e0d\u63d0\u4f9b"

    const-string v2, "\u6b64\u7248\u672c\u4e0d\u5305\u542b\u8bfb\u53d6\u8bbe\u5907\u5e94\u7528\u7684\u529f\u80fd\u3002"

    const/4 v3, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledMessage(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v22, v10

    move-object v1, v11

    move-object v2, v13

    goto/16 :goto_11

    .line 117
    :cond_d
    invoke-virtual {v11}, Lorg/lighttouch/android/InstalledList;->getError()Ljava/lang/String;

    move-result-object v0

    const v1, 0x4c5de2

    if-eqz v0, :cond_11

    if-nez v13, :cond_11

    const v0, -0x1cd766fe

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "116@5852L27,116@5768L112"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual {v11}, Lorg/lighttouch/android/InstalledList;->getError()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_e

    const-string v0, ""

    :cond_e
    move-object v2, v0

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\4":Z
    move-object v1, v4

    .local v1, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 211
    .local v3, "$i$f$cache\\4\\117":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\4":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 212
    .local v6, "$i$a$-let-ComposerKt$cache$1\\5\\211\\4":I
    if-nez v0, :cond_10

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v5, v12, :cond_f

    goto :goto_7

    .line 216
    :cond_f
    move-object v14, v5

    goto :goto_8

    .line 213
    :cond_10
    :goto_7
    const/4 v12, 0x0

    .line 117
    .local v12, "$i$a$-cache-StoreInstalledKt$InstalledTab$2\\6\\213\\0":I
    new-instance v14, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda3;

    invoke-direct {v14, v11}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/InstalledList;)V

    .line 213
    .end local v12    # "$i$a$-cache-StoreInstalledKt$InstalledTab$2\\6\\213\\0":I
    nop

    .line 214
    .local v14, "value\\5":Ljava/lang/Object;
    invoke-interface {v1, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 215
    nop

    .line 212
    .end local v14    # "value\\5":Ljava/lang/Object;
    :goto_8
    nop

    .line 211
    .end local v5    # "it\\4":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\5\\211\\4":I
    nop

    .line 117
    .end local v0    # "invalid\\4":Z
    .end local v1    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\4\\117":I
    move-object v3, v14

    check-cast v3, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v0, v10, 0xe

    or-int/lit8 v5, v0, 0x30

    const/4 v6, 0x0

    const-string v1, "\u65e0\u6cd5\u8bfb\u53d6\u6b64\u8bbe\u5907\u7684\u5e94\u7528"

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledMessage(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v22, v10

    move-object v1, v11

    move-object v2, v13

    goto/16 :goto_11

    .line 118
    :cond_11
    if-nez v13, :cond_12

    const v0, -0x1cd755f1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "117@5905L93"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, v1, v2, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x10

    .local v1, "$this$dp\\7":I
    const/4 v2, 0x0

    .line 217
    .local v2, "$i$f$getDp\\7\\118":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 118
    .end local v1    # "$this$dp\\7":I
    .end local v2    # "$i$f$getDp\\7\\118":I
    const/16 v2, 0x8

    .local v2, "$this$dp\\8":I
    const/4 v3, 0x0

    .line 217
    .local v3, "$i$f$getDp\\8\\118":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 118
    .end local v2    # "$this$dp\\8":I
    .end local v3    # "$i$f$getDp\\8\\118":I
    invoke-static {v0, v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v18, 0x6

    const/16 v19, 0x1e

    move-object v1, v11

    .end local v11    # "installed":Lorg/lighttouch/android/InstalledList;
    .local v1, "installed":Lorg/lighttouch/android/InstalledList;
    const-wide/16 v11, 0x0

    move-object v2, v13

    .end local v13    # "list":Ljava/util/List;
    .local v2, "list":Ljava/util/List;
    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    move-object/from16 v17, v4

    move/from16 v22, v10

    move-object v10, v0

    move-object v0, v1

    .end local v1    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v10    # "$dirty":I
    .local v0, "installed":Lorg/lighttouch/android/InstalledList;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    .local v22, "$dirty":I
    invoke-static/range {v10 .. v19}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v0, p0

    goto/16 :goto_11

    .line 119
    .end local v0    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v2    # "list":Ljava/util/List;
    .end local v22    # "$dirty":I
    .restart local v10    # "$dirty":I
    .restart local v11    # "installed":Lorg/lighttouch/android/InstalledList;
    .restart local v13    # "list":Ljava/util/List;
    :cond_12
    move/from16 v22, v10

    move-object v0, v11

    move-object v2, v13

    .end local v10    # "$dirty":I
    .end local v11    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v13    # "list":Ljava/util/List;
    .restart local v0    # "installed":Lorg/lighttouch/android/InstalledList;
    .restart local v2    # "list":Ljava/util/List;
    .restart local v22    # "$dirty":I
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_13

    const v1, -0x1cd746dd

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "118@6025L113"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v22, 0xe

    or-int/lit16 v5, v1, 0x1b0

    const/4 v6, 0x4

    const-string v1, "\u5c1a\u672a\u6dfb\u52a0\u5e94\u7528"

    move-object v3, v2

    .end local v2    # "list":Ljava/util/List;
    .local v3, "list":Ljava/util/List;
    const-string v2, "\u4ece\u65e7\u7248\u5546\u5e97\u6216 IPA \u6587\u4ef6\u5b89\u88c5\u7684\u5e94\u7528\u4f1a\u663e\u793a\u5728\u8fd9\u91cc\u3002"

    move-object v10, v3

    .end local v3    # "list":Ljava/util/List;
    .local v10, "list":Ljava/util/List;
    const/4 v3, 0x0

    move-object v11, v10

    move-object v10, v0

    move-object/from16 v0, p0

    .end local v0    # "installed":Lorg/lighttouch/android/InstalledList;
    .local v10, "installed":Lorg/lighttouch/android/InstalledList;
    .local v11, "list":Ljava/util/List;
    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledMessage(Landroidx/compose/foundation/layout/ColumnScope;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    move-object v6, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v1, v10

    move-object v2, v11

    goto/16 :goto_11

    .line 120
    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v10    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v11    # "list":Ljava/util/List;
    .restart local v0    # "installed":Lorg/lighttouch/android/InstalledList;
    .restart local v2    # "list":Ljava/util/List;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_13
    move-object v10, v0

    move-object v11, v2

    move-object v6, v4

    .end local v0    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v2    # "list":Ljava/util/List;
    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "installed":Lorg/lighttouch/android/InstalledList;
    .restart local v11    # "list":Ljava/util/List;
    const v0, -0x7e0f5323

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "126@6766L102,126@6639L229"

    invoke-static {v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 121
    invoke-virtual {v10}, Lorg/lighttouch/android/InstalledList;->getLookupError()Ljava/lang/String;

    move-result-object v0

    const v2, -0x1cd730bc

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*121@6225L387"

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v0, :cond_14

    goto/16 :goto_e

    .local v0, "message\\9":Ljava/lang/String;
    :cond_14
    const/4 v2, 0x0

    .line 122
    .local v2, "$i$a$-let-StoreInstalledKt$InstalledTab$3\\9\\121\\0":I
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x10

    .local v4, "$this$dp\\10":I
    const/4 v5, 0x0

    .line 218
    .local v5, "$i$f$getDp\\10\\122":I
    int-to-float v13, v4

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 122
    .end local v4    # "$this$dp\\10":I
    .end local v5    # "$i$f$getDp\\10\\122":I
    const/4 v5, 0x4

    .local v5, "$this$dp\\11":I
    const/4 v13, 0x0

    .line 218
    .local v13, "$i$f$getDp\\11\\122":I
    int-to-float v14, v5

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 122
    .end local v5    # "$this$dp\\11":I
    .end local v13    # "$i$f$getDp\\11\\122":I
    invoke-static {v3, v4, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\12":Landroidx/compose/ui/Modifier;
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v4

    .local v4, "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v5, 0x186

    .local v5, "$changed\\12":I
    const/4 v13, 0x0

    .line 219
    .local v13, "$i$f$Row\\12\\122":I
    const v14, 0x2952b718

    const-string v15, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v6, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 220
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v14

    .line 224
    .local v14, "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v15, v5, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v16, v5, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v15, v15, v16

    invoke-static {v14, v4, v6, v15}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v5, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 225
    nop

    .local v16, "$changed\\13":I
    const/16 v18, 0x0

    .line 226
    .local v18, "$i$f$Layout\\13\\225":I
    const v1, -0x4ee9b9da

    move/from16 v20, v2

    .end local v2    # "$i$a$-let-StoreInstalledKt$InstalledTab$3\\9\\121\\0":I
    .local v20, "$i$a$-let-StoreInstalledKt$InstalledTab$3\\9\\121\\0":I
    const-string v2, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v6, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 227
    const/4 v1, 0x0

    invoke-static {v6, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v1

    .line 228
    .local v1, "compositeKeyHash\\13":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 229
    .local v2, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v17, v1

    .end local v1    # "compositeKeyHash\\13":I
    .local v17, "compositeKeyHash\\13":I
    invoke-static {v6, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 231
    .local v1, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    move-object/from16 v23, v3

    .end local v3    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v23, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v16, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 230
    nop

    .local v3, "$changed\\14":I
    move-object/from16 v24, v21

    .local v24, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v21, 0x0

    .line 232
    .local v21, "$i$f$ReusableComposeNode\\14\\230":I
    move/from16 v25, v3

    .end local v3    # "$changed\\14":I
    .local v25, "$changed\\14":I
    const v3, -0x2942ffcf

    move-object/from16 v26, v4

    .end local v4    # "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    .local v26, "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    const-string v4, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 233
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 234
    :cond_15
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 235
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_16

    .line 236
    move-object/from16 v3, v24

    .end local v24    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 238
    .end local v3    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_16
    move-object/from16 v3, v24

    .end local v24    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 240
    :goto_9
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 241
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\240\\13":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v28, v3

    .end local v3    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v28, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v15, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 242
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 244
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 245
    .local v27, "$i$f$set-impl\\16\\244":I
    move-object/from16 v29, v4

    .local v29, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 246
    .local v30, "$i$a$-with-Updater$set$1\\17\\245\\16":I
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v31

    if-nez v31, :cond_18

    move-object/from16 v31, v2

    .end local v2    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v31, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v32, v5

    .end local v5    # "$changed\\12":I
    .local v32, "$changed\\12":I
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_17

    goto :goto_a

    :cond_17
    move-object/from16 v5, v29

    goto :goto_b

    .end local v31    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v32    # "$changed\\12":I
    .restart local v2    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "$changed\\12":I
    :cond_18
    move-object/from16 v31, v2

    move/from16 v32, v5

    .line 247
    .end local v2    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "$changed\\12":I
    .restart local v31    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v32    # "$changed\\12":I
    :goto_a
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v5, v29

    .end local v29    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 248
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v4, v2, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 250
    :goto_b
    nop

    .line 245
    .end local v5    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-with-Updater$set$1\\17\\245\\16":I
    nop

    .line 250
    nop

    .line 251
    .end local v3    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v27    # "$i$f$set-impl\\16\\244":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 252
    nop

    .line 240
    .end local v4    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\240\\13":I
    nop

    .line 253
    shr-int/lit8 v2, v25, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\18":I
    move-object v3, v6

    .local v3, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 254
    .local v4, "$i$a$-Layout-RowKt$Row$1\\18\\253\\12":I
    const v5, -0x184f2606

    move-object/from16 v24, v1

    .end local v1    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v24, "materialized\\13":Landroidx/compose/ui/Modifier;
    const-string v1, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v32, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\19":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v54, v3

    .local v54, "$composer\\19":Landroidx/compose/runtime/Composer;
    move-object/from16 v33, v1

    .end local v1    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v33, "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    const/4 v1, 0x0

    .line 123
    .local v1, "$i$a$-Row-StoreInstalledKt$InstalledTab$3$1\\19\\254\\9":I
    move/from16 v27, v1

    .end local v1    # "$i$a$-Row-StoreInstalledKt$InstalledTab$3$1\\19\\254\\9":I
    .local v27, "$i$a$-Row-StoreInstalledKt$InstalledTab$3$1\\19\\254\\9":I
    const v1, 0x62350720

    move/from16 v29, v2

    .end local v2    # "$changed\\18":I
    .local v29, "$changed\\18":I
    const-string v2, "C122@6449L10,122@6493L11,122@6354L157,123@6553L22,123@6532L62:StoreInstalled.kt#o13vsk"

    move-object/from16 v30, v3

    .end local v54    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u65e0\u6cd5\u68c0\u67e5\u65b0\u7248\u672c\u3002"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v34, v2

    check-cast v34, Landroidx/compose/ui/Modifier;

    const/16 v37, 0x2

    const/16 v38, 0x0

    const/high16 v35, 0x3f800000    # 1.0f

    const/16 v36, 0x0

    invoke-static/range {v33 .. v38}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v34

    move-object/from16 v58, v0

    move-object/from16 v2, v33

    .end local v0    # "message\\9":Ljava/lang/String;
    .end local v33    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v2, "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v58, "message\\9":Ljava/lang/String;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v33, v1

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v53

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v35

    const/16 v56, 0x0

    const v57, 0xfff8

    const-wide/16 v37, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const-wide/16 v46, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v55, 0x0

    .end local v3    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v54    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v33 .. v57}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    const v0, 0x4c5de2

    .end local v54    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .line 124
    move-object v1, v3

    .local v0, "invalid\\20":Z
    .local v1, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 255
    .local v19, "$i$f$cache\\20\\124":I
    move/from16 v33, v0

    .end local v0    # "invalid\\20":Z
    .local v33, "invalid\\20":Z
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\20":Ljava/lang/Object;
    const/16 v34, 0x0

    .line 256
    .local v34, "$i$a$-let-ComposerKt$cache$1\\21\\255\\20":I
    if-nez v33, :cond_1a

    sget-object v35, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v46, v2

    .end local v2    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    .local v46, "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_19

    goto :goto_c

    .line 260
    :cond_19
    move-object/from16 v35, v0

    goto :goto_d

    .line 256
    .end local v46    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    .restart local v2    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    :cond_1a
    move-object/from16 v46, v2

    .line 257
    .end local v2    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    .restart local v46    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    :goto_c
    const/4 v2, 0x0

    .line 124
    .local v2, "$i$a$-cache-StoreInstalledKt$InstalledTab$3$1$1\\22\\257\\19":I
    move-object/from16 v35, v0

    .end local v0    # "it\\20":Ljava/lang/Object;
    .local v35, "it\\20":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda4;

    invoke-direct {v0, v10}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/InstalledList;)V

    .line 257
    .end local v2    # "$i$a$-cache-StoreInstalledKt$InstalledTab$3$1$1\\22\\257\\19":I
    nop

    .line 258
    .local v0, "value\\21":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 259
    nop

    .line 256
    .end local v0    # "value\\21":Ljava/lang/Object;
    :goto_d
    nop

    .line 255
    .end local v34    # "$i$a$-let-ComposerKt$cache$1\\21\\255\\20":I
    .end local v35    # "it\\20":Ljava/lang/Object;
    nop

    .line 124
    .end local v1    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$f$cache\\20\\124":I
    .end local v33    # "invalid\\20":Z
    move-object/from16 v33, v0

    check-cast v33, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;

    invoke-virtual {v0}, Lorg/lighttouch/android/ComposableSingletons$StoreInstalledKt;->getLambda$-473526576$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v42

    const/high16 v44, 0x30000000

    const/16 v45, 0x1fe

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    move-object/from16 v43, v3

    .end local v3    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v33 .. v45}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 123
    .end local v43    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 125
    nop

    .line 254
    .end local v3    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v5    # "$changed\\19":I
    .end local v27    # "$i$a$-Row-StoreInstalledKt$InstalledTab$3$1\\19\\254\\9":I
    .end local v46    # "$this$InstalledTab_u24lambda_u246_u24lambda_u245\\19":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 253
    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\18\\253\\12":I
    .end local v29    # "$changed\\18":I
    .end local v30    # "$composer\\18":Landroidx/compose/runtime/Composer;
    nop

    .line 261
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 232
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 262
    nop

    .line 226
    .end local v21    # "$i$f$ReusableComposeNode\\14\\230":I
    .end local v25    # "$changed\\14":I
    .end local v28    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 263
    nop

    .line 219
    .end local v16    # "$changed\\13":I
    .end local v17    # "compositeKeyHash\\13":I
    .end local v18    # "$i$f$Layout\\13\\225":I
    .end local v24    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .end local v31    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 264
    nop

    .line 126
    .end local v13    # "$i$f$Row\\12\\122":I
    .end local v14    # "horizontalArrangement\\12":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v15    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v26    # "verticalAlignment\\12":Landroidx/compose/ui/Alignment$Vertical;
    .end local v32    # "$changed\\12":I
    nop

    .end local v20    # "$i$a$-let-StoreInstalledKt$InstalledTab$3\\9\\121\\0":I
    .end local v58    # "message\\9":Ljava/lang/String;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 121
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_e
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 127
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v1, v0

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "store_installed"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x8

    .local v2, "$this$dp\\23":I
    const/4 v3, 0x0

    .line 265
    .local v3, "$i$f$getDp\\23\\127":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 127
    .end local v2    # "$this$dp\\23":I
    .end local v3    # "$i$f$getDp\\23\\127":I
    const/4 v3, 0x4

    .local v3, "$this$dp\\24":I
    const/4 v4, 0x0

    .line 265
    .local v4, "$i$f$getDp\\24\\127":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 127
    .end local v3    # "$this$dp\\24":I
    .end local v4    # "$i$f$getDp\\24\\127":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v2

    const v3, -0x615d173a

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v6, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v6, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    .local v3, "invalid\\25":Z
    move-object v4, v6

    .local v4, "$this$cache\\25":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 266
    .local v5, "$i$f$cache\\25\\127":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\25":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 267
    .local v13, "$i$a$-let-ComposerKt$cache$1\\26\\266\\25":I
    if-nez v3, :cond_1c

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v12, v14, :cond_1b

    goto :goto_f

    .line 271
    :cond_1b
    move-object v15, v12

    goto :goto_10

    .line 268
    :cond_1c
    :goto_f
    const/4 v14, 0x0

    .line 127
    .local v14, "$i$a$-cache-StoreInstalledKt$InstalledTab$4\\27\\268\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda5;

    invoke-direct {v15, v11, v7}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda5;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    .line 268
    .end local v14    # "$i$a$-cache-StoreInstalledKt$InstalledTab$4\\27\\268\\0":I
    nop

    .line 269
    .local v15, "value\\26":Ljava/lang/Object;
    invoke-interface {v4, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 270
    nop

    .line 267
    .end local v15    # "value\\26":Ljava/lang/Object;
    :goto_10
    nop

    .line 266
    .end local v12    # "it\\25":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\26\\266\\25":I
    nop

    .line 127
    .end local v3    # "invalid\\25":Z
    .end local v4    # "$this$cache\\25":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\25\\127":I
    move-object/from16 v18, v15

    check-cast v18, Lkotlin/jvm/functions/Function1;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v20, 0x180

    const/16 v21, 0xfa

    move-object v3, v11

    .end local v11    # "list":Ljava/util/List;
    .local v3, "list":Ljava/util/List;
    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object v12, v10

    move-object v10, v1

    move-object v1, v12

    move-object v12, v2

    move-object v2, v3

    move-object/from16 v19, v6

    .end local v3    # "list":Ljava/util/List;
    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v10    # "installed":Lorg/lighttouch/android/InstalledList;
    .local v1, "installed":Lorg/lighttouch/android/InstalledList;
    .local v2, "list":Ljava/util/List;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v21}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 120
    move-object/from16 v4, v19

    .end local v19    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_11
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_1d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "installed":Lorg/lighttouch/android/InstalledList;
    .end local v2    # "list":Ljava/util/List;
    :cond_1d
    :goto_12
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_1e

    new-instance v2, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda6;

    invoke-direct {v2, v0, v7, v8, v9}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda6;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZI)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 132
    :cond_1e
    return-void
.end method

.method private static final InstalledTab$lambda$10$lambda$9(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 10
    .param p0, "$list"    # Ljava/util/List;
    .param p1, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    new-instance v0, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lorg/lighttouch/android/StoreInstalledKt$$ExternalSyntheticLambda0;-><init>()V

    .local v0, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object v1, p2

    .line 581
    .local v1, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 584
    sget-object v2, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$1;

    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 581
    .local v2, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v3, 0x0

    .line 586
    .local v3, "$i$f$items\\1\\128":I
    nop

    .line 587
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v4

    .line 588
    nop

    .line 586
    new-instance v5, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$2;

    invoke-direct {v5, v0, p0}, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v5, Lkotlin/jvm/functions/Function1;

    new-instance v6, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$3;

    invoke-direct {v6, v2, p0}, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 590
    new-instance v7, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$4;

    invoke-direct {v7, p0, p1}, Lorg/lighttouch/android/StoreInstalledKt$InstalledTab$lambda$10$lambda$9$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    const v8, -0x25b7f321

    const/4 v9, 0x1

    invoke-static {v8, v9, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function4;

    .line 586
    invoke-interface {v1, v4, v5, v6, v7}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 592
    nop

    .line 129
    .end local v0    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v1    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v2    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v3    # "$i$f$items\\1\\128":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InstalledTab$lambda$10$lambda$9$lambda$7(Lorg/lighttouch/android/InstalledApp;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/InstalledApp;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final InstalledTab$lambda$11(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ZLandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InstalledTab$lambda$2$lambda$1(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;
    .locals 1
    .param p0, "$installed"    # Lorg/lighttouch/android/InstalledList;

    .line 117
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->refresh(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final InstalledTab$lambda$6$lambda$5$lambda$4$lambda$3(Lorg/lighttouch/android/InstalledList;)Lkotlin/Unit;
    .locals 1
    .param p0, "$installed"    # Lorg/lighttouch/android/InstalledList;

    .line 124
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->lookUp()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$InstalledRow(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "app"    # Lorg/lighttouch/android/InstalledApp;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreInstalledKt;->InstalledRow(Lorg/lighttouch/android/InstalledApp;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

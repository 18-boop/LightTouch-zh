.class public final Lorg/lighttouch/android/MainActivity;
.super Landroidx/activity/ComponentActivity;
.source "MainActivity.kt"

# interfaces
.implements Landroid/hardware/SensorEventListener;
.implements Lorg/lighttouch/android/GuestHost;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/MainActivity$GuestStartRequest;,
        Lorg/lighttouch/android/MainActivity$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMainActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MainActivity.kt\norg/lighttouch/android/MainActivity\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 SnapshotIntState.kt\nandroidx/compose/runtime/SnapshotIntStateKt__SnapshotIntStateKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 5 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 6 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 7 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 8 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n*L\n1#1,1266:1\n81#2:1267\n107#2,2:1268\n81#2:1270\n107#2,2:1271\n81#2:1273\n107#2,2:1274\n81#2:1276\n107#2,2:1277\n81#2:1279\n107#2,2:1280\n81#2:1285\n107#2,2:1286\n81#2:1288\n107#2,2:1289\n81#2:1291\n107#2,2:1292\n81#2:1294\n107#2,2:1295\n81#2:1297\n107#2,2:1298\n81#2:1300\n107#2,2:1301\n81#2:1303\n107#2,2:1304\n81#2:1306\n107#2,2:1307\n81#2:1309\n107#2,2:1310\n81#2:1312\n107#2,2:1313\n81#2:1315\n107#2,2:1316\n81#2:1318\n107#2,2:1319\n81#2:1321\n107#2,2:1322\n81#2:1324\n107#2,2:1325\n81#2:1330\n107#2,2:1331\n81#2:1333\n107#2,2:1334\n81#2:1342\n107#2,2:1343\n81#2:1345\n107#2,2:1346\n81#2:1348\n107#2,2:1349\n81#2:1351\n107#2,2:1352\n81#2:1354\n107#2,2:1355\n81#2:1357\n107#2,2:1358\n81#2:1360\n107#2,2:1361\n81#2:1363\n107#2,2:1364\n81#2:1366\n107#2,2:1367\n78#3:1282\n111#3,2:1283\n78#3:1327\n111#3,2:1328\n1563#4:1336\n1634#4,3:1337\n295#4,2:1340\n2423#4,14:1373\n1761#4,3:1387\n1761#4,3:1390\n774#4:1393\n865#4,2:1394\n1617#4,9:1396\n1869#4:1405\n1870#4:1407\n1626#4:1408\n774#4:1409\n865#4,2:1410\n1563#4:1412\n1634#4,3:1413\n1617#4,9:1452\n1869#4:1461\n1870#4:1463\n1626#4:1464\n1068#4:1465\n1563#4:1466\n1634#4,3:1467\n295#4,2:1470\n295#4,2:1472\n295#4,2:1474\n1193#4,2:1476\n1267#4,4:1478\n1563#4:1482\n1634#4,3:1483\n1374#4:1489\n1460#4,5:1490\n774#4:1495\n865#4,2:1496\n295#4,2:1501\n295#4,2:1503\n295#4,2:1505\n295#4,2:1507\n295#4,2:1509\n774#4:1511\n865#4,2:1512\n1617#4,9:1514\n1869#4:1523\n1870#4:1525\n1626#4:1526\n295#4,2:1529\n1563#4:1531\n1634#4,3:1532\n1617#4,9:1539\n1869#4:1548\n1870#4:1550\n1626#4:1551\n1788#4,4:1552\n1#5:1369\n1#5:1406\n1#5:1462\n1#5:1524\n1#5:1549\n3829#6:1370\n4344#6,2:1371\n3829#6:1486\n4344#6,2:1487\n3829#6:1498\n4344#6,2:1499\n1310#6,2:1535\n1225#7,6:1416\n1225#7,6:1422\n1225#7,6:1428\n1225#7,6:1434\n1225#7,6:1440\n1225#7,6:1446\n1321#8,2:1527\n1321#8,2:1537\n*S KotlinDebug\n*F\n+ 1 MainActivity.kt\norg/lighttouch/android/MainActivity\n*L\n36#1:1267\n36#1:1268,2\n37#1:1270\n37#1:1271,2\n39#1:1273\n39#1:1274,2\n40#1:1276\n40#1:1277,2\n42#1:1279\n42#1:1280,2\n46#1:1285\n46#1:1286,2\n54#1:1288\n54#1:1289,2\n57#1:1291\n57#1:1292,2\n58#1:1294\n58#1:1295,2\n60#1:1297\n60#1:1298,2\n62#1:1300\n62#1:1301,2\n64#1:1303\n64#1:1304,2\n67#1:1306\n67#1:1307,2\n68#1:1309\n68#1:1310,2\n77#1:1312\n77#1:1313,2\n78#1:1315\n78#1:1316,2\n79#1:1318\n79#1:1319,2\n80#1:1321\n80#1:1322,2\n81#1:1324\n81#1:1325,2\n98#1:1330\n98#1:1331,2\n99#1:1333\n99#1:1334,2\n109#1:1342\n109#1:1343,2\n111#1:1345\n111#1:1346,2\n113#1:1348\n113#1:1349,2\n114#1:1351\n114#1:1352,2\n115#1:1354\n115#1:1355,2\n116#1:1357\n116#1:1358,2\n117#1:1360\n117#1:1361,2\n125#1:1363\n125#1:1364,2\n130#1:1366\n130#1:1367,2\n45#1:1282\n45#1:1283,2\n95#1:1327\n95#1:1328,2\n100#1:1336\n100#1:1337,3\n101#1:1340,2\n283#1:1373,14\n303#1:1387,3\n304#1:1390,3\n435#1:1393\n435#1:1394,2\n599#1:1396,9\n599#1:1405\n599#1:1407\n599#1:1408\n727#1:1409\n727#1:1410,2\n728#1:1412\n728#1:1413,3\n836#1:1452,9\n836#1:1461\n836#1:1463\n836#1:1464\n1150#1:1465\n1150#1:1466\n1150#1:1467,3\n1171#1:1470,2\n1203#1:1472,2\n1204#1:1474,2\n321#1:1476,2\n321#1:1478,4\n323#1:1482\n323#1:1483,3\n534#1:1489\n534#1:1490,5\n535#1:1495\n535#1:1496,2\n542#1:1501,2\n544#1:1503,2\n545#1:1505,2\n547#1:1507,2\n620#1:1509,2\n626#1:1511\n626#1:1512,2\n626#1:1514,9\n626#1:1523\n626#1:1525\n626#1:1526\n731#1:1529,2\n842#1:1531\n842#1:1532,3\n948#1:1539,9\n948#1:1548\n948#1:1550\n948#1:1551\n949#1:1552,4\n599#1:1406\n836#1:1462\n626#1:1524\n948#1:1549\n282#1:1370\n282#1:1371,2\n534#1:1486\n534#1:1487,2\n537#1:1498\n537#1:1499,2\n849#1:1535,2\n743#1:1416,6\n745#1:1422,6\n746#1:1428,6\n747#1:1434,6\n748#1:1440,6\n749#1:1446,6\n687#1:1527,2\n856#1:1537,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00be\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000e\n\u0002\u0008\n\n\u0002\u0010\u000b\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u000c\n\u0002\u0018\u0002\n\u0002\u0008\'\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u000f\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u000f\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0012\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0008\u0008\n\u0002\u0010\t\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0008\u0004\n\u0002\u00085\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008-\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u000c*\u0006\u00ee\u0001\u0086\u0002\u008a\u0002\u0008\u0007\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003:\u0002\u009d\u0003B\u0007\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\n\u0010\u0080\u0001\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u00f0\u0001\u001a\u00030\u008f\u0001H\u0002J\n\u0010\u00f8\u0001\u001a\u00030\u0081\u0001H\u0016J\t\u0010\u00f9\u0001\u001a\u00020\u001aH\u0002J\t\u0010\u00fa\u0001\u001a\u00020\u001aH\u0002J\u0013\u0010\u008d\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u008e\u0002\u001a\u00020\u001aH\u0002J\u0016\u0010\u0093\u0002\u001a\u00030\u0081\u00012\n\u0010\u0094\u0002\u001a\u0005\u0018\u00010\u008f\u0001H\u0014J\n\u0010\u0096\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u0097\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u0098\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u0099\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u009a\u0002\u001a\u00030\u0081\u0001H\u0016J\u0013\u0010\u009b\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009c\u0002\u001a\u00020\u001aH\u0016J\u001c\u0010\u009d\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009e\u0002\u001a\u00020\'2\u0007\u0010\u009f\u0002\u001a\u00020\u001aH\u0016J\n\u0010\u00a0\u0002\u001a\u00030\u0081\u0001H\u0016J\u0014\u0010\u00a1\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00a2\u0002\u001a\u00030\u00ad\u0001H\u0016J\n\u0010\u00a3\u0002\u001a\u00030\u0081\u0001H\u0016J\u0013\u0010\u00a4\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00a5\u0002\u001a\u00020eH\u0016J\n\u0010\u00a6\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u00a7\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u00a8\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u00a9\u0002\u001a\u00030\u0081\u0001H\u0016J\u001e\u0010\u00aa\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00ab\u0002\u001a\u00020\u000f2\t\u0010\u00ac\u0002\u001a\u0004\u0018\u00010\u000fH\u0002J\u0013\u0010\u00ad\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00ae\u0002\u001a\u00020\u001aH\u0016J\u0013\u0010\u00af\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00ae\u0002\u001a\u00020\u001aH\u0016J\u0013\u0010\u00b0\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00ae\u0002\u001a\u00020\u001aH\u0016J\n\u0010\u00b1\u0002\u001a\u00030\u0081\u0001H\u0016J\u0013\u0010\u00b2\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009e\u0002\u001a\u00020\u000fH\u0016J\u001c\u0010\u00b3\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009e\u0002\u001a\u00020\u000f2\u0007\u0010\u00b4\u0002\u001a\u00020\u000fH\u0016J\u0013\u0010\u00b5\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009e\u0002\u001a\u00020\u000fH\u0016J\n\u0010\u00b6\u0002\u001a\u00030\u0081\u0001H\u0016J\n\u0010\u00b7\u0002\u001a\u00030\u0081\u0001H\u0002J\u001e\u0010\u00b8\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00b9\u0002\u001a\u00030\u00f6\u00012\u0008\u0010\u00ba\u0002\u001a\u00030\u00f6\u0001H\u0002J\u0014\u0010\u00bb\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u0001H\u0002J\u0013\u0010\u00bd\u0002\u001a\u00020\u000f2\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u0001H\u0002J\u0014\u0010\u00be\u0002\u001a\u00030\u00bf\u00022\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u0001H\u0002J)\u0010\u00c0\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00c1\u0002\u001a\u00030\u00cd\u00012\u0013\u0008\u0002\u0010\u00c2\u0002\u001a\u000c\u0012\u0005\u0012\u00030\u0081\u0001\u0018\u00010\u00d8\u0001H\u0002J\u0012\u0010\u00c3\u0002\u001a\u00020\u000f2\u0007\u0010\u00c4\u0002\u001a\u00020\u000fH\u0002J8\u0010\u00c5\u0002\u001a\n\u0012\u0005\u0012\u00030\u0081\u00010\u00d8\u00012\u0007\u0010\u00c6\u0002\u001a\u00020\u00072\u001c\u0010\u00c7\u0002\u001a\u0017\u0012\u0004\u0012\u00020\u000f\u0012\u0005\u0012\u00030\u00c9\u0002\u0012\u0005\u0012\u00030\u0081\u00010\u00c8\u0002H\u0002J&\u0010\u00ca\u0002\u001a\u00020\u000f2\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u00012\u0008\u0010\u00cb\u0002\u001a\u00030\u00cc\u00022\u0007\u0010\u00cd\u0002\u001a\u00020\u000fH\u0002J\n\u0010\u00ce\u0002\u001a\u00030\u0081\u0001H\u0002J\u001c\u0010\u00cf\u0002\u001a\u00020\u001a2\u0007\u0010\u00d0\u0002\u001a\u00020\'2\u0008\u0010\u00d1\u0002\u001a\u00030\u00d2\u0002H\u0016J\u001c\u0010\u00d3\u0002\u001a\u00020\u001a2\u0007\u0010\u00d0\u0002\u001a\u00020\'2\u0008\u0010\u00d1\u0002\u001a\u00030\u00d2\u0002H\u0016J\n\u0010\u00d4\u0002\u001a\u00030\u008f\u0001H\u0002J\n\u0010\u00d5\u0002\u001a\u00030\u0081\u0001H\u0002J\t\u0010\u00d6\u0002\u001a\u00020\u001aH\u0002J\n\u0010\u00d7\u0002\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u00d8\u0002\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u00d9\u0002\u001a\u00030\u0081\u0001H\u0002J\u0013\u0010\u00da\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00db\u0002\u001a\u00020\u000fH\u0002J\u0010\u0010\u00dc\u0002\u001a\u00030\u0081\u0001H\u0003\u00a2\u0006\u0003\u0010\u00dd\u0002J\n\u0010\u00de\u0002\u001a\u00030\u0081\u0001H\u0002J\u0014\u0010\u00df\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u0001H\u0002J\n\u0010\u00e0\u0002\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u00e1\u0002\u001a\u00030\u0081\u0001H\u0002J\u0014\u0010\u00e2\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00e3\u0002\u001a\u00030\u008f\u0001H\u0002J\u0014\u0010\u00e4\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00e3\u0002\u001a\u00030\u008f\u0001H\u0002J\u001c\u0010\u00e5\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00e6\u0002\u001a\u00020\u000f2\u0007\u0010\u00e7\u0002\u001a\u00020\u000fH\u0002J\n\u0010\u00e8\u0002\u001a\u00030\u0081\u0001H\u0002J\u0014\u0010\u00e9\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u0001H\u0002J\n\u0010\u00ea\u0002\u001a\u00030\u0081\u0001H\u0002J\u0014\u0010\u00eb\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u0001H\u0002J\u0015\u0010\u00ec\u0002\u001a\u00030\u0081\u00012\t\u0008\u0002\u0010\u00ed\u0002\u001a\u00020\u001aH\u0002J\n\u0010\u00ee\u0002\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u00ef\u0002\u001a\u00030\u0081\u0001H\u0002J\"\u0010\u00f0\u0002\u001a\u00030\u0081\u00012\t\u0008\u0002\u0010\u00f1\u0002\u001a\u00020\u001a2\u000b\u0008\u0002\u0010\u00f2\u0002\u001a\u0004\u0018\u000104H\u0002J\n\u0010\u00f3\u0002\u001a\u00030\u0081\u0001H\u0002J\u0013\u0010\u00f4\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u00f5\u0002\u001a\u00020\u0007H\u0002J\u0013\u0010\u00f6\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009e\u0002\u001a\u00020\'H\u0016J\u001d\u0010\u00f6\u0002\u001a\u00030\u0081\u00012\u0007\u0010\u009d\u0002\u001a\u00020\'2\u0008\u0010\u00f7\u0002\u001a\u00030\u00f6\u0001H\u0002J\n\u0010\u00f8\u0002\u001a\u00030\u0081\u0001H\u0002J\u001d\u0010\u00f9\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00bc\u0002\u001a\u00030\u00cd\u00012\u0007\u0010\u00fa\u0002\u001a\u00020\u000fH\u0002J=\u0010\u00fb\u0002\u001a\u00030\u0081\u00012\u0008\u0010\u00c1\u0002\u001a\u00030\u00cd\u00012\u0008\u0010\u00fc\u0002\u001a\u00030\u00cc\u00022\u001d\u0010\u00fd\u0002\u001a\u0018\u0012\u0005\u0012\u00030\u00f6\u0001\u0012\u0005\u0012\u00030\u00f6\u0001\u0012\u0005\u0012\u00030\u0081\u00010\u00c8\u0002H\u0002J\n\u0010\u0086\u0003\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u0087\u0003\u001a\u00030\u0081\u0001H\u0002J\u0014\u0010\u0088\u0003\u001a\u00030\u0081\u00012\u0008\u0010\u00d1\u0002\u001a\u00030\u0089\u0003H\u0016J\u001c\u0010\u008a\u0003\u001a\u00030\u0081\u00012\u0007\u0010\u009e\u0002\u001a\u00020\'2\u0007\u0010\u009f\u0002\u001a\u00020\u001aH\u0002J\u0013\u0010\u008b\u0003\u001a\u00030\u0081\u00012\u0007\u0010\u008c\u0003\u001a\u00020\u001aH\u0002J\u000c\u0010\u008d\u0003\u001a\u0005\u0018\u00010\u0086\u0001H\u0002J\t\u0010\u008e\u0003\u001a\u00020\u000fH\u0002J\n\u0010\u008f\u0003\u001a\u00030\u0081\u0001H\u0002J\u001d\u0010\u0090\u0003\u001a\u00030\u0081\u00012\u0008\u0010\u0091\u0003\u001a\u00030\u0092\u00032\u0007\u0010\u0093\u0003\u001a\u00020\'H\u0016J\n\u0010\u0094\u0003\u001a\u00030\u0081\u0001H\u0014J\n\u0010\u0095\u0003\u001a\u00030\u0081\u0001H\u0014J\n\u0010\u0096\u0003\u001a\u00030\u0081\u0001H\u0014J\u0013\u0010\u0097\u0003\u001a\u00030\u0081\u00012\u0007\u0010\u0098\u0003\u001a\u00020\u001aH\u0016J\n\u0010\u0099\u0003\u001a\u00030\u0081\u0001H\u0014J\n\u0010\u009a\u0003\u001a\u00030\u0081\u0001H\u0014J\n\u0010\u009b\u0003\u001a\u00030\u0081\u0001H\u0002J\n\u0010\u009c\u0003\u001a\u00030\u0081\u0001H\u0014R/\u0010\u0008\u001a\u0004\u0018\u00010\u00072\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u00078B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\r\u0010\u000e\u001a\u0004\u0008\t\u0010\n\"\u0004\u0008\u000b\u0010\u000cR+\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0015\u0010\u000e\u001a\u0004\u0008\u0011\u0010\u0012\"\u0004\u0008\u0013\u0010\u0014R+\u0010\u0016\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0019\u0010\u000e\u001a\u0004\u0008\u0017\u0010\u0012\"\u0004\u0008\u0018\u0010\u0014R+\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008 \u0010\u000e\u001a\u0004\u0008\u001c\u0010\u001d\"\u0004\u0008\u001e\u0010\u001fR+\u0010!\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008$\u0010\u000e\u001a\u0004\u0008\"\u0010\u0012\"\u0004\u0008#\u0010\u0014R\u000e\u0010%\u001a\u00020&X\u0082\u0004\u00a2\u0006\u0002\n\u0000R+\u0010(\u001a\u00020\'2\u0006\u0010\u0006\u001a\u00020\'8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008-\u0010.\u001a\u0004\u0008)\u0010*\"\u0004\u0008+\u0010,R+\u0010/\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u00082\u0010\u000e\u001a\u0004\u00080\u0010\u001d\"\u0004\u00081\u0010\u001fR\u0010\u00103\u001a\u0004\u0018\u000104X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R+\u00109\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008<\u0010\u000e\u001a\u0004\u0008:\u0010\u001d\"\u0004\u0008;\u0010\u001fR+\u0010=\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008@\u0010\u000e\u001a\u0004\u0008>\u0010\u0012\"\u0004\u0008?\u0010\u0014R+\u0010A\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008D\u0010\u000e\u001a\u0004\u0008B\u0010\u001d\"\u0004\u0008C\u0010\u001fR+\u0010E\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008H\u0010\u000e\u001a\u0004\u0008F\u0010\u001d\"\u0004\u0008G\u0010\u001fR+\u0010I\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008L\u0010\u000e\u001a\u0004\u0008J\u0010\u001d\"\u0004\u0008K\u0010\u001fR+\u0010M\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008P\u0010\u000e\u001a\u0004\u0008N\u0010\u0012\"\u0004\u0008O\u0010\u0014R+\u0010Q\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@VX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008T\u0010\u000e\u001a\u0004\u0008R\u0010\u001d\"\u0004\u0008S\u0010\u001fR+\u0010U\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8V@RX\u0096\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008X\u0010\u000e\u001a\u0004\u0008V\u0010\u001d\"\u0004\u0008W\u0010\u001fR\u0014\u0010Y\u001a\u00020\u001a8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\u0008Z\u0010\u001dR\u0014\u0010[\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R+\u0010]\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008`\u0010\u000e\u001a\u0004\u0008^\u0010\u001d\"\u0004\u0008_\u0010\u001fR+\u0010a\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008d\u0010\u000e\u001a\u0004\u0008b\u0010\u001d\"\u0004\u0008c\u0010\u001fR/\u0010f\u001a\u0004\u0018\u00010e2\u0008\u0010\u0006\u001a\u0004\u0018\u00010e8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008k\u0010\u000e\u001a\u0004\u0008g\u0010h\"\u0004\u0008i\u0010jR+\u0010l\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008o\u0010\u000e\u001a\u0004\u0008m\u0010\u0012\"\u0004\u0008n\u0010\u0014R+\u0010p\u001a\u00020\u000f2\u0006\u0010\u0006\u001a\u00020\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008s\u0010\u000e\u001a\u0004\u0008q\u0010\u0012\"\u0004\u0008r\u0010\u0014R\u001b\u0010t\u001a\u00020u8BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008x\u0010y\u001a\u0004\u0008v\u0010wR\u001b\u0010z\u001a\u00020{8BX\u0082\u0084\u0002\u00a2\u0006\u000c\n\u0004\u0008~\u0010y\u001a\u0004\u0008|\u0010}R\u0014\u0010\u007f\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0082\u0001\u001a\u000f\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0083\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u0084\u0001\u001a\u0010\u0012\u0004\u0012\u00020\u000f\u0012\u0005\u0012\u00030\u0086\u00010\u0085\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R/\u0010\u0087\u0001\u001a\u00020\'2\u0006\u0010\u0006\u001a\u00020\'8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u008a\u0001\u0010.\u001a\u0005\u0008\u0088\u0001\u0010*\"\u0005\u0008\u0089\u0001\u0010,R\u001a\u0010\u008b\u0001\u001a\r \u008d\u0001*\u0005\u0018\u00010\u008c\u00010\u008c\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000RA\u0010\u0090\u0001\u001a\n\u0012\u0005\u0012\u00030\u008f\u00010\u008e\u00012\u000e\u0010\u0006\u001a\n\u0012\u0005\u0012\u00030\u008f\u00010\u008e\u00018B@BX\u0082\u008e\u0002\u00a2\u0006\u0017\n\u0005\u0008\u0095\u0001\u0010\u000e\u001a\u0006\u0008\u0091\u0001\u0010\u0092\u0001\"\u0006\u0008\u0093\u0001\u0010\u0094\u0001R/\u0010\u0096\u0001\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u0099\u0001\u0010\u000e\u001a\u0005\u0008\u0097\u0001\u0010\u001d\"\u0005\u0008\u0098\u0001\u0010\u001fR\u001e\u0010\u009a\u0001\u001a\t\u0012\u0004\u0012\u00020e0\u008e\u00018VX\u0096\u0004\u00a2\u0006\u0008\u001a\u0006\u0008\u009b\u0001\u0010\u0092\u0001R\u0018\u0010\u009c\u0001\u001a\u0004\u0018\u00010e8VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\u0008\u009d\u0001\u0010hR \u0010\u009e\u0001\u001a\u00030\u009f\u00018VX\u0096\u0084\u0002\u00a2\u0006\u000f\n\u0005\u0008\u00a2\u0001\u0010y\u001a\u0006\u0008\u00a0\u0001\u0010\u00a1\u0001R\u0010\u0010\u00a3\u0001\u001a\u00030\u00a4\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0018\u0010\u00a5\u0001\u001a\u00030\u00a6\u00018VX\u0096\u0004\u00a2\u0006\u0008\u001a\u0006\u0008\u00a7\u0001\u0010\u00a8\u0001R\u0016\u0010\u00a9\u0001\u001a\u00020\u001a8VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\u0008\u00aa\u0001\u0010\u001dR\u0016\u0010\u00ab\u0001\u001a\u00020\u001aX\u0096D\u00a2\u0006\t\n\u0000\u001a\u0005\u0008\u00ac\u0001\u0010\u001dR3\u0010\u00ae\u0001\u001a\u00030\u00ad\u00012\u0007\u0010\u0006\u001a\u00030\u00ad\u00018B@BX\u0082\u008e\u0002\u00a2\u0006\u0017\n\u0005\u0008\u00b3\u0001\u0010\u000e\u001a\u0006\u0008\u00af\u0001\u0010\u00b0\u0001\"\u0006\u0008\u00b1\u0001\u0010\u00b2\u0001R7\u0010\u00b4\u0001\u001a\u0005\u0018\u00010\u00ad\u00012\t\u0010\u0006\u001a\u0005\u0018\u00010\u00ad\u00018B@BX\u0082\u008e\u0002\u00a2\u0006\u0017\n\u0005\u0008\u00b7\u0001\u0010\u000e\u001a\u0006\u0008\u00b5\u0001\u0010\u00b0\u0001\"\u0006\u0008\u00b6\u0001\u0010\u00b2\u0001R\u0010\u0010\u00b8\u0001\u001a\u00030\u00b9\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R7\u0010\u00bb\u0001\u001a\u0005\u0018\u00010\u00ba\u00012\t\u0010\u0006\u001a\u0005\u0018\u00010\u00ba\u00018B@BX\u0082\u008e\u0002\u00a2\u0006\u0017\n\u0005\u0008\u00c0\u0001\u0010\u000e\u001a\u0006\u0008\u00bc\u0001\u0010\u00bd\u0001\"\u0006\u0008\u00be\u0001\u0010\u00bf\u0001R3\u0010\u00c1\u0001\u001a\u0004\u0018\u00010\u000f2\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u00c4\u0001\u0010\u000e\u001a\u0005\u0008\u00c2\u0001\u0010\u0012\"\u0005\u0008\u00c3\u0001\u0010\u0014R/\u0010\u00c5\u0001\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u00c8\u0001\u0010\u000e\u001a\u0005\u0008\u00c6\u0001\u0010\u001d\"\u0005\u0008\u00c7\u0001\u0010\u001fR3\u0010\u00c9\u0001\u001a\u0004\u0018\u00010\u000f2\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u00cc\u0001\u0010\u000e\u001a\u0005\u0008\u00ca\u0001\u0010\u0012\"\u0005\u0008\u00cb\u0001\u0010\u0014R7\u0010\u00ce\u0001\u001a\u0005\u0018\u00010\u00cd\u00012\t\u0010\u0006\u001a\u0005\u0018\u00010\u00cd\u00018B@BX\u0082\u008e\u0002\u00a2\u0006\u0017\n\u0005\u0008\u00d3\u0001\u0010\u000e\u001a\u0006\u0008\u00cf\u0001\u0010\u00d0\u0001\"\u0006\u0008\u00d1\u0001\u0010\u00d2\u0001R\u000f\u0010\u00d4\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00d5\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00d6\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u00d7\u0001\u001a\n\u0012\u0005\u0012\u00030\u0081\u00010\u00d8\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u00d9\u0001\u001a\u0005\u0018\u00010\u00da\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00db\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R/\u0010\u00dc\u0001\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u00df\u0001\u0010\u000e\u001a\u0005\u0008\u00dd\u0001\u0010\u001d\"\u0005\u0008\u00de\u0001\u0010\u001fR\u000f\u0010\u00e0\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00e1\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00e2\u0001\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00e3\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R/\u0010\u00e4\u0001\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u001a8B@BX\u0082\u008e\u0002\u00a2\u0006\u0015\n\u0005\u0008\u00e7\u0001\u0010\u000e\u001a\u0005\u0008\u00e5\u0001\u0010\u001d\"\u0005\u0008\u00e6\u0001\u0010\u001fR\u0010\u0010\u00e8\u0001\u001a\u00030\u00e9\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00ea\u0001\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00eb\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00ec\u0001\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0013\u0010\u00ed\u0001\u001a\u00030\u00ee\u0001X\u0082\u0004\u00a2\u0006\u0005\n\u0003\u0010\u00ef\u0001R\u001c\u0010\u00f1\u0001\u001a\u000f\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0083\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u00f2\u0001\u001a\u000f\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0083\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0018\u0010\u00f3\u0001\u001a\u000b\u0012\u0007\u0012\u0005\u0018\u00010\u00cd\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00f4\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u00f5\u0001\u001a\u00030\u00f6\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00f7\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00fb\u0001\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u00fc\u0001\u001a\u0005\u0018\u00010\u00fd\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u00fe\u0001\u001a\u00030\u00ff\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R*\u0010\u0080\u0002\u001a\r \u008d\u0001*\u0005\u0018\u00010\u0081\u00020\u0081\u00028BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\u0008\u0084\u0002\u0010y\u001a\u0006\u0008\u0082\u0002\u0010\u0083\u0002R\u0013\u0010\u0085\u0002\u001a\u00030\u0086\u0002X\u0082\u0004\u00a2\u0006\u0005\n\u0003\u0010\u0087\u0002R\u000f\u0010\u0088\u0002\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0013\u0010\u0089\u0002\u001a\u00030\u008a\u0002X\u0082\u0004\u00a2\u0006\u0005\n\u0003\u0010\u008b\u0002R\u000f\u0010\u008c\u0002\u001a\u00020\'X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0018\u0010\u008f\u0002\u001a\u000b\u0012\u0007\u0012\u0005\u0018\u00010\u00cd\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0090\u0002\u001a\u000f\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0083\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0091\u0002\u001a\u000f\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0083\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0092\u0002\u001a\u000f\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0083\u00010\\X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u0095\u0002\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u00fe\u0002\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R \u0010\u00ff\u0002\u001a\u00030\u0080\u00038BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\u0008\u0083\u0003\u0010y\u001a\u0006\u0008\u0081\u0003\u0010\u0082\u0003R\u0011\u0010\u0084\u0003\u001a\u0004\u0018\u00010\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000f\u0010\u0085\u0003\u001a\u00020\'X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u009e\u0003"
    }
    d2 = {
        "Lorg/lighttouch/android/MainActivity;",
        "Landroidx/activity/ComponentActivity;",
        "Landroid/hardware/SensorEventListener;",
        "Lorg/lighttouch/android/GuestHost;",
        "<init>",
        "()V",
        "<set-?>",
        "Lorg/lighttouch/android/IEngine;",
        "engine",
        "getEngine",
        "()Lorg/lighttouch/android/IEngine;",
        "setEngine",
        "(Lorg/lighttouch/android/IEngine;)V",
        "engine$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "",
        "status",
        "getStatus",
        "()Ljava/lang/String;",
        "setStatus",
        "(Ljava/lang/String;)V",
        "status$delegate",
        "detail",
        "getDetail",
        "setDetail",
        "detail$delegate",
        "",
        "displayAsleep",
        "getDisplayAsleep",
        "()Z",
        "setDisplayAsleep",
        "(Z)V",
        "displayAsleep$delegate",
        "error",
        "getError",
        "setError",
        "error$delegate",
        "workerEvidenceDelivery",
        "Lorg/lighttouch/android/SessionDeliveryGate;",
        "",
        "workerPid",
        "getWorkerPid",
        "()I",
        "setWorkerPid",
        "(I)V",
        "workerPid$delegate",
        "Landroidx/compose/runtime/MutableIntState;",
        "sessionOwned",
        "getSessionOwned",
        "setSessionOwned",
        "sessionOwned$delegate",
        "pendingGuestRequest",
        "Lorg/lighttouch/android/MainActivity$GuestStartRequest;",
        "pendingGuestStart",
        "guestStartRequested",
        "engineExpectedExit",
        "engineRestarting",
        "busy",
        "getBusy",
        "setBusy",
        "busy$delegate",
        "notice",
        "getNotice",
        "setNotice",
        "notice$delegate",
        "profileRecording",
        "getProfileRecording",
        "setProfileRecording",
        "profileRecording$delegate",
        "profileAutomatic",
        "getProfileAutomatic",
        "setProfileAutomatic",
        "profileAutomatic$delegate",
        "profileBusy",
        "getProfileBusy",
        "setProfileBusy",
        "profileBusy$delegate",
        "profileNotice",
        "getProfileNotice",
        "setProfileNotice",
        "profileNotice$delegate",
        "presentAsync",
        "getPresentAsync",
        "setPresentAsync",
        "presentAsync$delegate",
        "faithfulScaler",
        "getFaithfulScaler",
        "setFaithfulScaler",
        "faithfulScaler$delegate",
        "microphone",
        "getMicrophone",
        "microphonePermission",
        "Landroidx/activity/result/ActivityResultLauncher;",
        "licensesOpen",
        "getLicensesOpen",
        "setLicensesOpen",
        "licensesOpen$delegate",
        "devicesOpen",
        "getDevicesOpen",
        "setDevicesOpen",
        "devicesOpen$delegate",
        "Lorg/lighttouch/android/DeviceSummary;",
        "detailsDevice",
        "getDetailsDevice",
        "()Lorg/lighttouch/android/DeviceSummary;",
        "setDetailsDevice",
        "(Lorg/lighttouch/android/DeviceSummary;)V",
        "detailsDevice$delegate",
        "muxSocket",
        "getMuxSocket",
        "setMuxSocket",
        "muxSocket$delegate",
        "appServicesError",
        "getAppServicesError",
        "setAppServicesError",
        "appServicesError$delegate",
        "installer",
        "Lorg/lighttouch/android/StoreInstaller;",
        "getInstaller",
        "()Lorg/lighttouch/android/StoreInstaller;",
        "installer$delegate",
        "Lkotlin/Lazy;",
        "store",
        "Lorg/lighttouch/android/StoreModel;",
        "getStore",
        "()Lorg/lighttouch/android/StoreModel;",
        "store$delegate",
        "notificationPermission",
        "askNotifications",
        "",
        "localIpa",
        "",
        "firmwareTargets",
        "",
        "Lorg/lighttouch/android/StoreTarget;",
        "catalogVersion",
        "getCatalogVersion",
        "setCatalogVersion",
        "catalogVersion$delegate",
        "buttonCalls",
        "Ljava/util/concurrent/ExecutorService;",
        "kotlin.jvm.PlatformType",
        "",
        "Landroid/os/Bundle;",
        "records",
        "getRecords",
        "()Ljava/util/List;",
        "setRecords",
        "(Ljava/util/List;)V",
        "records$delegate",
        "recordsLoaded",
        "getRecordsLoaded",
        "setRecordsLoaded",
        "recordsLoaded$delegate",
        "devices",
        "getDevices",
        "selected",
        "getSelected",
        "settings",
        "Lorg/lighttouch/android/AppSettings;",
        "getSettings",
        "()Lorg/lighttouch/android/AppSettings;",
        "settings$delegate",
        "monitor",
        "Lorg/lighttouch/android/PerformanceMonitor;",
        "perf",
        "Lorg/lighttouch/android/PerfSnapshot;",
        "getPerf",
        "()Lorg/lighttouch/android/PerfSnapshot;",
        "storeInstalling",
        "getStoreInstalling",
        "canSaveState",
        "getCanSaveState",
        "Lorg/lighttouch/android/Screen;",
        "base",
        "getBase",
        "()Lorg/lighttouch/android/Screen;",
        "setBase",
        "(Lorg/lighttouch/android/Screen;)V",
        "base$delegate",
        "overlay",
        "getOverlay",
        "setOverlay",
        "overlay$delegate",
        "setup",
        "Lorg/lighttouch/android/SetupState;",
        "Lorg/lighttouch/android/HitchData;",
        "hitchData",
        "getHitchData",
        "()Lorg/lighttouch/android/HitchData;",
        "setHitchData",
        "(Lorg/lighttouch/android/HitchData;)V",
        "hitchData$delegate",
        "hitchError",
        "getHitchError",
        "setHitchError",
        "hitchError$delegate",
        "hitchSaving",
        "getHitchSaving",
        "setHitchSaving",
        "hitchSaving$delegate",
        "hitchNotice",
        "getHitchNotice",
        "setHitchNotice",
        "hitchNotice$delegate",
        "Landroid/net/Uri;",
        "hitchReport",
        "getHitchReport",
        "()Landroid/net/Uri;",
        "setHitchReport",
        "(Landroid/net/Uri;)V",
        "hitchReport$delegate",
        "hitchResume",
        "pausedByBackground",
        "askedNotifications",
        "idleHook",
        "Lkotlin/Function0;",
        "firmware",
        "Lorg/lighttouch/android/IFirmware;",
        "firmwareBound",
        "firmwareRestarting",
        "getFirmwareRestarting",
        "setFirmwareRestarting",
        "firmwareRestarting$delegate",
        "pendingFirmwareStart",
        "firmwareExpectedExit",
        "retainedPreparedOutput",
        "preparedImportInFlight",
        "preparationOpen",
        "getPreparationOpen",
        "setPreparationOpen",
        "preparationOpen$delegate",
        "prep",
        "Lorg/lighttouch/android/PrepareState;",
        "preparedImported",
        "addRetainedWhenReady",
        "dismissedRun",
        "firmwareConnection",
        "org/lighttouch/android/MainActivity$firmwareConnection$1",
        "Lorg/lighttouch/android/MainActivity$firmwareConnection$1;",
        "workerExitedRun",
        "stockIpsw",
        "prepRom",
        "preparedCopy",
        "active",
        "displayOwnerTicket",
        "",
        "displayResumed",
        "toggleProfile",
        "ownsDisplay",
        "mayClaimDisplay",
        "bound",
        "displayView",
        "Lorg/lighttouch/android/GuestDisplay;",
        "handler",
        "Landroid/os/Handler;",
        "sensors",
        "Landroid/hardware/SensorManager;",
        "getSensors",
        "()Landroid/hardware/SensorManager;",
        "sensors$delegate",
        "connection",
        "org/lighttouch/android/MainActivity$connection$1",
        "Lorg/lighttouch/android/MainActivity$connection$1;",
        "pollInFlight",
        "poll",
        "org/lighttouch/android/MainActivity$poll$1",
        "Lorg/lighttouch/android/MainActivity$poll$1;",
        "sixtyHertzMode",
        "preferSixtyHertz",
        "guestInFront",
        "pickFolder",
        "pickSystem",
        "pickRom",
        "pickGuestToolsFile",
        "onCreate",
        "savedInstanceState",
        "dismissedError",
        "dismissError",
        "start",
        "recover",
        "stop",
        "saveAndStop",
        "setPaused",
        "paused",
        "button",
        "id",
        "down",
        "screenshot",
        "navigate",
        "screen",
        "openDevices",
        "openDetails",
        "device",
        "addDevice",
        "openLicenses",
        "openPreparation",
        "pickGuestTools",
        "setDebugEnv",
        "key",
        "value",
        "usePresentAsync",
        "on",
        "useFaithfulScaler",
        "useMicrophone",
        "applySettings",
        "selectDevice",
        "renameDevice",
        "name",
        "deleteDevice",
        "openHitch",
        "closeHitch",
        "saveHitch",
        "from",
        "to",
        "shareReport",
        "uri",
        "displayName",
        "picked",
        "Lorg/lighttouch/android/PickedFile;",
        "scanFolder",
        "tree",
        "onFound",
        "importPhaseText",
        "phase",
        "watchImport",
        "worker",
        "show",
        "Lkotlin/Function2;",
        "",
        "copyWithProgress",
        "target",
        "Ljava/io/File;",
        "label",
        "createDevice",
        "onKeyDown",
        "keyCode",
        "event",
        "Landroid/view/KeyEvent;",
        "onKeyUp",
        "retainedPreparation",
        "resumePreparation",
        "preparationActive",
        "closePreparation",
        "releaseFirmware",
        "bindFirmware",
        "findBootrom",
        "board",
        "PrepareOverlay",
        "(Landroidx/compose/runtime/Composer;I)V",
        "openDeviceFiles",
        "addPreparedCopy",
        "beginPreparation",
        "restartFirmwareForPreparation",
        "pollPreparation",
        "state",
        "importPreparedOutput",
        "rememberIpsw",
        "path",
        "firmwareId",
        "downloadIpsw",
        "importStockIpsw",
        "downloadBootrom",
        "importPrepRom",
        "refreshDevices",
        "afterDelete",
        "bindWorker",
        "workerExited",
        "startGuest",
        "coldRecovery",
        "retainedRequest",
        "stopGuest",
        "restartGuestForStart",
        "old",
        "pulse",
        "holdMs",
        "capture",
        "copyAsset",
        "targetName",
        "copyTree",
        "destination",
        "progress",
        "listening",
        "sensorThread",
        "Landroid/os/HandlerThread;",
        "getSensorThread",
        "()Landroid/os/HandlerThread;",
        "sensorThread$delegate",
        "motionWorker",
        "displayRotation",
        "startSensors",
        "stopSensors",
        "onSensorChanged",
        "Landroid/hardware/SensorEvent;",
        "sendButton",
        "applyWindowMode",
        "immersive",
        "recordTarget",
        "selectedRecordId",
        "openStore",
        "onAccuracyChanged",
        "sensor",
        "Landroid/hardware/Sensor;",
        "accuracy",
        "onStart",
        "onResume",
        "onPostResume",
        "onWindowFocusChanged",
        "hasFocus",
        "onPause",
        "onStop",
        "installsFinished",
        "onDestroy",
        "GuestStartRequest",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private active:Z

.field private addRetainedWhenReady:Z

.field private final appServicesError$delegate:Landroidx/compose/runtime/MutableState;

.field private askedNotifications:Z

.field private final base$delegate:Landroidx/compose/runtime/MutableState;

.field private bound:Z

.field private final busy$delegate:Landroidx/compose/runtime/MutableState;

.field private final buttonCalls:Ljava/util/concurrent/ExecutorService;

.field private final canSaveState:Z

.field private final catalogVersion$delegate:Landroidx/compose/runtime/MutableIntState;

.field private final connection:Lorg/lighttouch/android/MainActivity$connection$1;

.field private final detail$delegate:Landroidx/compose/runtime/MutableState;

.field private final detailsDevice$delegate:Landroidx/compose/runtime/MutableState;

.field private final devicesOpen$delegate:Landroidx/compose/runtime/MutableState;

.field private dismissedError:Ljava/lang/String;

.field private dismissedRun:Ljava/lang/String;

.field private final displayAsleep$delegate:Landroidx/compose/runtime/MutableState;

.field private displayOwnerTicket:J

.field private displayResumed:Z

.field private volatile displayRotation:I

.field private displayView:Lorg/lighttouch/android/GuestDisplay;

.field private final engine$delegate:Landroidx/compose/runtime/MutableState;

.field private engineExpectedExit:Z

.field private engineRestarting:Z

.field private final error$delegate:Landroidx/compose/runtime/MutableState;

.field private final faithfulScaler$delegate:Landroidx/compose/runtime/MutableState;

.field private firmware:Lorg/lighttouch/android/IFirmware;

.field private firmwareBound:Z

.field private final firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

.field private firmwareExpectedExit:Z

.field private final firmwareRestarting$delegate:Landroidx/compose/runtime/MutableState;

.field private volatile firmwareTargets:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/StoreTarget;",
            ">;"
        }
    .end annotation
.end field

.field private guestStartRequested:Z

.field private final handler:Landroid/os/Handler;

.field private final hitchData$delegate:Landroidx/compose/runtime/MutableState;

.field private final hitchError$delegate:Landroidx/compose/runtime/MutableState;

.field private final hitchNotice$delegate:Landroidx/compose/runtime/MutableState;

.field private final hitchReport$delegate:Landroidx/compose/runtime/MutableState;

.field private hitchResume:Z

.field private final hitchSaving$delegate:Landroidx/compose/runtime/MutableState;

.field private final idleHook:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final installer$delegate:Lkotlin/Lazy;

.field private final licensesOpen$delegate:Landroidx/compose/runtime/MutableState;

.field private listening:Z

.field private final localIpa:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final microphonePermission:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final monitor:Lorg/lighttouch/android/PerformanceMonitor;

.field private volatile motionWorker:Lorg/lighttouch/android/IEngine;

.field private final muxSocket$delegate:Landroidx/compose/runtime/MutableState;

.field private final notice$delegate:Landroidx/compose/runtime/MutableState;

.field private final notificationPermission:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final overlay$delegate:Landroidx/compose/runtime/MutableState;

.field private pausedByBackground:Z

.field private pendingFirmwareStart:Z

.field private pendingGuestRequest:Lorg/lighttouch/android/MainActivity$GuestStartRequest;

.field private pendingGuestStart:Z

.field private final pickFolder:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation
.end field

.field private final pickGuestToolsFile:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final pickRom:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final pickSystem:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final poll:Lorg/lighttouch/android/MainActivity$poll$1;

.field private pollInFlight:Z

.field private final prep:Lorg/lighttouch/android/PrepareState;

.field private final prepRom:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final preparationOpen$delegate:Landroidx/compose/runtime/MutableState;

.field private final preparedCopy:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation
.end field

.field private preparedImportInFlight:Z

.field private preparedImported:Ljava/lang/String;

.field private final presentAsync$delegate:Landroidx/compose/runtime/MutableState;

.field private final profileAutomatic$delegate:Landroidx/compose/runtime/MutableState;

.field private final profileBusy$delegate:Landroidx/compose/runtime/MutableState;

.field private final profileNotice$delegate:Landroidx/compose/runtime/MutableState;

.field private final profileRecording$delegate:Landroidx/compose/runtime/MutableState;

.field private final records$delegate:Landroidx/compose/runtime/MutableState;

.field private final recordsLoaded$delegate:Landroidx/compose/runtime/MutableState;

.field private retainedPreparedOutput:Ljava/lang/String;

.field private final sensorThread$delegate:Lkotlin/Lazy;

.field private final sensors$delegate:Lkotlin/Lazy;

.field private final sessionOwned$delegate:Landroidx/compose/runtime/MutableState;

.field private final settings$delegate:Lkotlin/Lazy;

.field private final setup:Lorg/lighttouch/android/SetupState;

.field private sixtyHertzMode:I

.field private final status$delegate:Landroidx/compose/runtime/MutableState;

.field private final stockIpsw:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final store$delegate:Lkotlin/Lazy;

.field private final workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

.field private final workerPid$delegate:Landroidx/compose/runtime/MutableIntState;


# direct methods
.method public static synthetic $r8$lambda$-W94WAuACaArXgGGrUz3GL-hc5k(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreModel;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->store_delegate$lambda$4(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreModel;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$0TJbu8QYYM8LNqiOz9f2ZupqbBY()Landroid/os/HandlerThread;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/MainActivity;->sensorThread_delegate$lambda$249()Landroid/os/HandlerThread;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$0UKWQyGE32XlXkcH5qq9VvvvpT4(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->pickGuestToolsFile$lambda$29(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$1hhWFd2SEVxS7tNtOzzwZLaO_Pw(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->copyAsset$lambda$238$lambda$236(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$1wV2lIZEzJ_4z4cWJuO8kW_VXNI(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->pickFolder$lambda$26(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$2_IPtCiaewrqW2fCnIAER_HMIzU(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->copyAsset$lambda$238$lambda$237(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$32vpU7Q0pCkWo0GcTYEgxOIc1Gs(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;J)V
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/MainActivity;->importPreparedOutput$lambda$167(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$3GwPHOQtkmtnXiE1Qt6XfclPKiY(B)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->copyWithProgress$lambda$86(B)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4TwkLBlGuXJIZry49X4y7vdpL7w(Lorg/lighttouch/android/MainActivity;)Landroid/hardware/SensorManager;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->sensors_delegate$lambda$21(Lorg/lighttouch/android/MainActivity;)Landroid/hardware/SensorManager;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$5GXgLKKyO_yTRkKHtjuCyVLRQGc(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay$lambda$137$lambda$136(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$5a25w4Gqc8goet5Iq1bK_nGO3Rs(Lorg/lighttouch/android/MainActivity;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay$lambda$143(Lorg/lighttouch/android/MainActivity;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$5mH61ku_-C16BFiPklZ-_cPHGUs(Lorg/lighttouch/android/MainActivity;Landroid/os/RemoteException;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->refreshDevices$lambda$196$lambda$195(Lorg/lighttouch/android/MainActivity;Landroid/os/RemoteException;)V

    return-void
.end method

.method public static synthetic $r8$lambda$649F25n6RVbZVR-0JP9lRdYbe64(Ljava/util/concurrent/atomic/AtomicBoolean;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->watchImport$lambda$82(Ljava/util/concurrent/atomic/AtomicBoolean;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6botUoeAHtKCLB4_lbw_oShCK_w(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->addPreparedCopy$lambda$144(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$80KUpJkT0PW3ED7pMjtQs5hTFtE(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$107(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$88LwdNpb_QWbd92kP0YDuHyN2XQ(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->preparedCopy$lambda$15(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$8_GDbZe_2RSniH3yKx_ADahwpaU(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->pickSystem$lambda$27(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$9XIhCo_Rw1GBAJdzfJYiE9e_noI(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Lkotlin/Pair;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->findBootrom$lambda$124$lambda$123(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Lkotlin/Pair;)V

    return-void
.end method

.method public static synthetic $r8$lambda$9_6FwZMjVlJdAAdpct2tlT7PCcI(Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$106(Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$9oLZ2W9lynAvtuQMGEPfWFiabdc(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/CatalogFirmware;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->importStockIpsw$lambda$180$lambda$178(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/CatalogFirmware;)V

    return-void
.end method

.method public static synthetic $r8$lambda$9ou0DKZNRA_fYdL_jHIpI_yEMuo(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->microphonePermission$lambda$0(Lorg/lighttouch/android/MainActivity;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$BaOcrDor5ZOfmmv7Z3XK3hHZPyM(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->saveHitch$lambda$59$lambda$58(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Cg6dDSZ8AjuA-UJC915CSdoZTKI(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->importPrepRom$lambda$190(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$DfkiXNdE-MGIkUkW9IvT39k0oMw(Ljava/util/concurrent/CountDownLatch;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->restartFirmwareForPreparation$lambda$156$lambda$152(Ljava/util/concurrent/CountDownLatch;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ECGp1eDEs3N-lIO5C1XgZipCqt8(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->selectDevice$lambda$46$lambda$45(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ECOWpFDYTZH9Ako6UiOU20U-R-4(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->capture$lambda$231$lambda$230(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$F0ubltc_xQZqlf0j4IOSmYn0DAY(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->capture$lambda$231(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$FsZWFlJA7F1A0p4AEjEqwFKLiuU(Lorg/lighttouch/android/MainActivity;JJ)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$94$lambda$93$lambda$92(Lorg/lighttouch/android/MainActivity;JJ)V

    return-void
.end method

.method public static synthetic $r8$lambda$FyY0tJiptDLkYaYoU6ea61T8hts(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->capture$lambda$231$lambda$229(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$GcAVzFSboXPwPckBJqJYwE_UOBg(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Ljava/io/File;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->downloadIpsw$lambda$169(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Ljava/io/File;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$GqmHg6ChkpG4oSz9soz4RUuuNYM(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->restartGuestForStart$lambda$222$lambda$221(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$H03_upkY3iHE_jL0qZYok2gZDr0(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->importStockIpsw$lambda$180$lambda$179(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$HbGn9ZX0I6IcjTxOk5Bh46NVmjU(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$copyTree$Entry;Ljava/util/concurrent/atomic/AtomicLong;JLkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/functions/Function2;)V
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/MainActivity;->copyTree$lambda$247$lambda$246(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$copyTree$Entry;Ljava/util/concurrent/atomic/AtomicLong;JLkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/functions/Function2;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Ho8pn8zuKEEzKQfv_zDDN87naiE(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209$lambda$202$lambda$201(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$I4kGSzbiq7lXM-5_jDK5PPpwwg4(Z)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->notificationPermission$lambda$5(Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$I6ATQ--8gnhrEScKcsHf9kVnvSc(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->startGuest$lambda$215$lambda$213(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$IdCxMggTET7oJICmqrMaW92QMcQ(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->selectDevice$lambda$46(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$LOIHt2IEVD3UWrfZlu7qkrYmUsI(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->onPostResume$lambda$258(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MIVmQDhd91vqU0vkhTBnYLey_4o(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->deleteDevice$lambda$50(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MQyst1-K3uvg9UfkbzgKLBLUZxw(Ljava/lang/String;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->resumePreparation$lambda$117(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MST4mFI7PdYypEANaRmPtpaXWhk(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;JJ)V
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/MainActivity;->saveHitch$lambda$59(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;JJ)V

    return-void
.end method

.method public static synthetic $r8$lambda$N9CO55P26k_lxkuhmfrwI1z5IAE(Lorg/lighttouch/android/IEngine;IZ)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->applySettings$lambda$44(Lorg/lighttouch/android/IEngine;IZ)V

    return-void
.end method

.method public static synthetic $r8$lambda$NTF8fvASlkmCNUK9IykjJkKB4Ac(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->refreshDevices$lambda$196(Lorg/lighttouch/android/MainActivity;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$Ow5XlD6U70ibH4yUJlquUVUOJRg(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$101$lambda$100(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$PfArl4iVTct5Wr8D9PsDCIbtK3E(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209$lambda$208$lambda$207(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$PfD5nDIEstDckakkrqdaAwb7bfM(Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->renameDevice$lambda$48$lambda$47(Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Ph8y5FzLWApxXsOY2dfSVYaNZ7Y(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay$lambda$128$lambda$127(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$QiU20mJXFcSLhbGS2IXD9RXlLsY(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->openHitch$lambda$56$lambda$55(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$RBxfsNlKoKKCBpAGxO-4DO4kCfQ(Lorg/lighttouch/android/IEngine;IZ)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->sendButton$lambda$253(Lorg/lighttouch/android/IEngine;IZ)V

    return-void
.end method

.method public static synthetic $r8$lambda$S5w3UcsJ53F5cnYrAKR468-xQV0(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->beginPreparation$lambda$150$lambda$147(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Sa2ka0HztDoGA-E_6IKCVot55C0(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->openHitch$lambda$56$lambda$51(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$SuZVX9-0RAxJZO812ErA9ZX1gq0(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->stopGuest$lambda$217(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Sxv0RyKmf4hqx1gj57FqDrS31f4(Ljava/util/concurrent/CountDownLatch;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->restartGuestForStart$lambda$222$lambda$218(Ljava/util/concurrent/CountDownLatch;)V

    return-void
.end method

.method public static synthetic $r8$lambda$T8kiOHX4BNavmb7r7PsVI2UBhgg(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;Lkotlin/jvm/internal/Ref$LongRef;)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->copyWithProgress$lambda$85$lambda$84$lambda$83(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;Lkotlin/jvm/internal/Ref$LongRef;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Ttjjp1aKsekcnm9r9j-jPoqu9Ws(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->localIpa$lambda$6(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$UOF0ncspenE0pQJlLwinjY8n-Yw(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209$lambda$202(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$U_usJz8fZqIoVudcyrtvqnkiaaA(B)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->importStockIpsw$lambda$180$lambda$175(B)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UyN3JiZuT8e6y9V6EFzsl7WVf74(Lorg/lighttouch/android/IEngine;IJLorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->pulse$lambda$224(Lorg/lighttouch/android/IEngine;IJLorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$V-95lWF9cypqdyCoJgnVAkTrgEU(Ljava/util/concurrent/atomic/AtomicBoolean;Lkotlin/jvm/functions/Function2;Ljava/lang/String;F)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->watchImport$lambda$81$lambda$80(Ljava/util/concurrent/atomic/AtomicBoolean;Lkotlin/jvm/functions/Function2;Ljava/lang/String;F)V

    return-void
.end method

.method public static synthetic $r8$lambda$XmZ49oP1V3eNdh9-qd9b0Jit6pQ(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->downloadBootrom$lambda$183$lambda$182(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Z1hrfNQnHY7vKKry5Bty553GWcQ(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay$lambda$130$lambda$129(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_PjctUFvTR1m4nDv0V-dnChBD5I(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->downloadBootrom$lambda$183(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V

    return-void
.end method

.method public static synthetic $r8$lambda$_WHQbSn_ydhFODdrtjvujY76z_Y(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/CatalogFirmware;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->beginPreparation$lambda$150(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/CatalogFirmware;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ap_TMnBIu8pBsa41WAe17ctAeTI(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$96(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$b6ovck_5D9wCvpVDIGeQ8nOU_TM(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->openHitch$lambda$56$lambda$54(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;)V

    return-void
.end method

.method public static synthetic $r8$lambda$bKGOd4G5wktTDXTuTk5JwFfpDAA(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->buttonCalls$lambda$7(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$bvuSpTXutSnXoiCugNX1iJkbLjc(ZLorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->openHitch$lambda$56(ZLorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$c7oslS7gHqLkBTSuG9J69Bwkf7k(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->importPrepRom$lambda$190$lambda$188(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$c9GlmhbBDMx9JfnJBtD2dbXZD10(Ljava/util/concurrent/atomic/AtomicBoolean;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function2;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->watchImport$lambda$81(Ljava/util/concurrent/atomic/AtomicBoolean;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function2;)V

    return-void
.end method

.method public static synthetic $r8$lambda$dF9JqnPTq2-cnkN8S3BeLZHYuwA(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->monitor$lambda$11(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dbvTHN0frNwkTy18tshY8RT3O0Q(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay$lambda$134$lambda$133(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fvG4cgZudWgC_xcdj9rM51KrkjA(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$GuestStartRequest;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->startGuest$lambda$215(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$GuestStartRequest;)V

    return-void
.end method

.method public static synthetic $r8$lambda$gCRSAv7pYwYEVdmChSVzDYFE-H0(Landroid/os/IBinder;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->restartFirmwareForPreparation$lambda$156(Landroid/os/IBinder;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$g_TA-UURs5rEXs53Rp5XvLRIftk(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->pulse$lambda$224$lambda$223(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$grS4U00AETNe-sYV0VdIwEDKPF8(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->downloadBootrom$lambda$183$lambda$181(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;)V

    return-void
.end method

.method public static synthetic $r8$lambda$gyPdJgDz9VNdIyYRGQdxEINCrrE(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->toggleProfile$lambda$20$lambda$19(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hLnlQtpbwmBZaGqnI7FD_XivkPg(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->startGuest$lambda$215$lambda$214(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$hLqaD7RIFxHyosZvG_EkkDxFQUs(Lorg/lighttouch/android/MainActivity;J)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209$lambda$204(Lorg/lighttouch/android/MainActivity;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$hy2xhB31W36wpuS-jZSW77Wr6_Y(Lorg/lighttouch/android/MainActivity;JJ)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$94$lambda$93(Lorg/lighttouch/android/MainActivity;JJ)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$iLeXyPniD3hxs8DRDgE0yvEPwcM(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->refreshDevices$lambda$196$lambda$194(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$iprk2eoHPO77TfooElfAcTJ0P2g(Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->scanFolder$lambda$79$lambda$78(Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$iq00h4jS48hixQG2SqjbO5Nu1xU(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->onCreate$lambda$35(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$j5G1vXkwDIVsi1cI1oY6GK51NBg(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->pickRom$lambda$28(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$jIg1ViIbLybw-rI05_USphCDBso(Ljava/io/File;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->downloadIpsw$lambda$169$lambda$168(Ljava/io/File;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kptSrYvu7QAoxs41Y3Bx7Klz6rs(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/RemoteException;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->stopGuest$lambda$217$lambda$216(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/RemoteException;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kr8cngfSxHrMaIKjjrUMdPOkdRM(Lorg/lighttouch/android/MainActivity;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$105(Lorg/lighttouch/android/MainActivity;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$m0Id3UQHp9pV18xpwXbvwoiqUso(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay$lambda$140$lambda$139(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$m88Qfmbz8mVlHCAD9b8ecvP95tE(Lorg/lighttouch/android/IEngine;ZLorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->toggleProfile$lambda$20(Lorg/lighttouch/android/IEngine;ZLorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$mlXMPMMtCV2HDPaRhfX74FuZiZI(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/util/Set;)V
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/util/Set;)V

    return-void
.end method

.method public static synthetic $r8$lambda$n8DaiuhGPwGTKmBTQB2uLtNVH_4(Ljava/util/List;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->findBootrom$lambda$124(Ljava/util/List;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V

    return-void
.end method

.method public static synthetic $r8$lambda$o-sJNY6ZA-5iVtTvXdy0U69bX5U(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->prepRom$lambda$14(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$oReaG-XgYDD9sqwyqabeXYos_Fg(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;J)V
    .locals 0

    invoke-static/range {p0 .. p8}, Lorg/lighttouch/android/MainActivity;->importPreparedOutput$lambda$167$lambda$166(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$ohyPFO8nXRQDrcfzOOTJU0H--_k(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->onCreate$lambda$41(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$pZzE5qGq3YR-8TnFtXMib2Dzj88(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->restartFirmwareForPreparation$lambda$156$lambda$155(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$p_Hp8t_vAEbX5qtSqfQ5OHrWyDM(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->restartGuestForStart$lambda$222$lambda$220(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$phmZ4R1K_LZflX9rz_RVo05lvD0(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->startGuest$lambda$215$lambda$211(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$plOL8ak3akkmntq0qpIYt2rcEdY(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->saveHitch$lambda$59$lambda$57(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$pohPsD0tUhtkkSaUHgM4iY1qE7I(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->deleteDevice$lambda$50$lambda$49(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qAb29fMuyxLKPuapyG7UMGu03YU(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->renameDevice$lambda$48(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qBffG62sRkcSfizFzjU4dfVnjX4(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->copyAsset$lambda$238(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qEjvbbwjTd8Cw1ScTyJCb1JH-IQ(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreInstaller;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->installer_delegate$lambda$1(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreInstaller;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qeUg_Be7lheUERr7FZ1l0vi61sU(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/AppSettings;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->settings_delegate$lambda$10(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/AppSettings;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$s5AgKkZFdzTRx8tN99zGIm1Run0(Lorg/lighttouch/android/IEngine;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->installsFinished$lambda$259(Lorg/lighttouch/android/IEngine;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sIasw6dww7pgbG6palaWETHmQ1Q(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$LongRef;J)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity;->importStockIpsw$lambda$180$lambda$174$lambda$173$lambda$172(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$LongRef;J)V

    return-void
.end method

.method public static synthetic $r8$lambda$sJbzyEq5t8yEkwLCKBv8DSAYucw(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->store_delegate$lambda$4$lambda$3(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$spQQsSFgTL6FeaxCYSK7bMzavsQ(Landroidx/documentfile/provider/DocumentFile;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->scanFolder$lambda$79(Landroidx/documentfile/provider/DocumentFile;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$tlF9EhPuxJCEHUdH39wuCoBmOdo(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->importPrepRom$lambda$190$lambda$189(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$tqOGZkues_b20MRYz1BhAuy641c(Landroid/os/IBinder;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->restartGuestForStart$lambda$222(Landroid/os/IBinder;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$uPM8oSirtsS9Qtr2wYYT1aJyKLE(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->stockIpsw$lambda$13(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$uoIVCR4m2jnAnuD_KXgsLwWqE28(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->beginPreparation$lambda$150$lambda$149(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    return-void
.end method

.method public static synthetic $r8$lambda$usEhw3NIb16RLVoSJQyGoT3ECXM(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;F)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->importPreparedOutput$lambda$167$lambda$162(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;F)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wiHe2A0GroDiRRX_vFLmefTIaMM(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209$lambda$208$lambda$207$lambda$206(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$x7NsyK6rVAL3DG6Kpha2dfEtw5E(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Landroid/net/Uri;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->importStockIpsw$lambda$180(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$yKM1f25mtcs3Ayx1XILFv0dRhdo(Lorg/lighttouch/android/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->restartFirmwareForPreparation$lambda$156$lambda$154(Lorg/lighttouch/android/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$z5qJfvZEbLeWb753EDwvlnq8Dtk(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;F)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->createDevice$lambda$108$lambda$97(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;F)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$z8-dM1r_lQ5wi-hps0iu-RnHL2M(Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/util/Set;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->onCreate$lambda$41$lambda$40(Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/util/Set;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zASsjd6TrpKstj9BH3hT3j19ABw(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209$lambda$204$lambda$203(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$zMjUM-4S9KcvhRtEEGF5xkHMH6g(Lorg/lighttouch/android/MainActivity;IZJ)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->workerExited$lambda$209(Lorg/lighttouch/android/MainActivity;IZJ)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/MainActivity;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .locals 7

    .line 35
    invoke-direct {p0}, Landroidx/activity/ComponentActivity;-><init>()V

    .line 36
    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->engine$delegate:Landroidx/compose/runtime/MutableState;

    .line 37
    const-string v2, "stopped"

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->status$delegate:Landroidx/compose/runtime/MutableState;

    .line 39
    const-string v2, ""

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->detail$delegate:Landroidx/compose/runtime/MutableState;

    .line 40
    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->displayAsleep$delegate:Landroidx/compose/runtime/MutableState;

    .line 42
    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->error$delegate:Landroidx/compose/runtime/MutableState;

    .line 44
    new-instance v5, Lorg/lighttouch/android/SessionDeliveryGate;

    invoke-direct {v5}, Lorg/lighttouch/android/SessionDeliveryGate;-><init>()V

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    .line 45
    invoke-static {v3}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->workerPid$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 46
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->sessionOwned$delegate:Landroidx/compose/runtime/MutableState;

    .line 54
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->busy$delegate:Landroidx/compose/runtime/MutableState;

    .line 57
    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->notice$delegate:Landroidx/compose/runtime/MutableState;

    .line 58
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->profileRecording$delegate:Landroidx/compose/runtime/MutableState;

    .line 60
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->profileAutomatic$delegate:Landroidx/compose/runtime/MutableState;

    .line 62
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->profileBusy$delegate:Landroidx/compose/runtime/MutableState;

    .line 64
    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->profileNotice$delegate:Landroidx/compose/runtime/MutableState;

    .line 67
    const/4 v5, 0x1

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-static {v5, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v6

    iput-object v6, p0, Lorg/lighttouch/android/MainActivity;->presentAsync$delegate:Landroidx/compose/runtime/MutableState;

    .line 68
    invoke-static {v5, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->faithfulScaler$delegate:Landroidx/compose/runtime/MutableState;

    .line 73
    new-instance v5, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;

    invoke-direct {v5}, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;-><init>()V

    check-cast v5, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v6, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda31;

    invoke-direct {v6, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda31;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v5, v6}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->microphonePermission:Landroidx/activity/result/ActivityResultLauncher;

    .line 77
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->licensesOpen$delegate:Landroidx/compose/runtime/MutableState;

    .line 78
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->devicesOpen$delegate:Landroidx/compose/runtime/MutableState;

    .line 79
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->detailsDevice$delegate:Landroidx/compose/runtime/MutableState;

    .line 80
    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->muxSocket$delegate:Landroidx/compose/runtime/MutableState;

    .line 81
    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->appServicesError$delegate:Landroidx/compose/runtime/MutableState;

    .line 82
    new-instance v5, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda39;

    invoke-direct {v5, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda39;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-static {v5}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->installer$delegate:Lkotlin/Lazy;

    .line 83
    new-instance v5, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda41;

    invoke-direct {v5, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda41;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-static {v5}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->store$delegate:Lkotlin/Lazy;

    .line 85
    new-instance v5, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;

    invoke-direct {v5}, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;-><init>()V

    check-cast v5, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v6, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda42;

    invoke-direct {v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda42;-><init>()V

    invoke-virtual {p0, v5, v6}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->notificationPermission:Landroidx/activity/result/ActivityResultLauncher;

    .line 92
    new-instance v5, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v5}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v5, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v6, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda43;

    invoke-direct {v6, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda43;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v5, v6}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->localIpa:Landroidx/activity/result/ActivityResultLauncher;

    .line 94
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    .line 95
    invoke-static {v3}, Landroidx/compose/runtime/SnapshotIntStateKt;->mutableIntStateOf(I)Landroidx/compose/runtime/MutableIntState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->catalogVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    .line 97
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda44;

    invoke-direct {v3}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda44;-><init>()V

    invoke-static {v3}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->buttonCalls:Ljava/util/concurrent/ExecutorService;

    .line 98
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->records$delegate:Landroidx/compose/runtime/MutableState;

    .line 99
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->recordsLoaded$delegate:Landroidx/compose/runtime/MutableState;

    .line 102
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda45;

    invoke-direct {v3, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda45;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-static {v3}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->settings$delegate:Lkotlin/Lazy;

    .line 103
    new-instance v3, Lorg/lighttouch/android/PerformanceMonitor;

    new-instance v5, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda46;

    invoke-direct {v5, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda46;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-direct {v3, v5}, Lorg/lighttouch/android/PerformanceMonitor;-><init>(Lkotlin/jvm/functions/Function0;)V

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->monitor:Lorg/lighttouch/android/PerformanceMonitor;

    .line 109
    sget-object v3, Lorg/lighttouch/android/Screen;->HOME:Lorg/lighttouch/android/Screen;

    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->base$delegate:Landroidx/compose/runtime/MutableState;

    .line 111
    sget-object v3, Lorg/lighttouch/android/Screen;->LOADING:Lorg/lighttouch/android/Screen;

    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->overlay$delegate:Landroidx/compose/runtime/MutableState;

    .line 112
    new-instance v3, Lorg/lighttouch/android/SetupState;

    invoke-direct {v3}, Lorg/lighttouch/android/SetupState;-><init>()V

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    .line 113
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->hitchData$delegate:Landroidx/compose/runtime/MutableState;

    .line 114
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->hitchError$delegate:Landroidx/compose/runtime/MutableState;

    .line 115
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->hitchSaving$delegate:Landroidx/compose/runtime/MutableState;

    .line 116
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->hitchNotice$delegate:Landroidx/compose/runtime/MutableState;

    .line 117
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->hitchReport$delegate:Landroidx/compose/runtime/MutableState;

    .line 122
    new-instance v3, Lorg/lighttouch/android/MainActivity$idleHook$1;

    invoke-direct {v3, p0}, Lorg/lighttouch/android/MainActivity$idleHook$1;-><init>(Ljava/lang/Object;)V

    check-cast v3, Lkotlin/jvm/functions/Function0;

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->idleHook:Lkotlin/jvm/functions/Function0;

    .line 125
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->firmwareRestarting$delegate:Landroidx/compose/runtime/MutableState;

    .line 128
    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    .line 130
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->preparationOpen$delegate:Landroidx/compose/runtime/MutableState;

    .line 131
    new-instance v0, Lorg/lighttouch/android/PrepareState;

    invoke-direct {v0}, Lorg/lighttouch/android/PrepareState;-><init>()V

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    .line 132
    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    .line 136
    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->dismissedRun:Ljava/lang/String;

    .line 137
    new-instance v0, Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/MainActivity$firmwareConnection$1;-><init>(Lorg/lighttouch/android/MainActivity;)V

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    .line 159
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda47;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda47;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->stockIpsw:Landroidx/activity/result/ActivityResultLauncher;

    .line 160
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda48;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda48;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->prepRom:Landroidx/activity/result/ActivityResultLauncher;

    .line 161
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda32;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda32;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->preparedCopy:Landroidx/activity/result/ActivityResultLauncher;

    .line 186
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    .line 187
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda33;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda33;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->sensors$delegate:Lkotlin/Lazy;

    .line 188
    new-instance v0, Lorg/lighttouch/android/MainActivity$connection$1;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/MainActivity$connection$1;-><init>(Lorg/lighttouch/android/MainActivity;)V

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->connection:Lorg/lighttouch/android/MainActivity$connection$1;

    .line 212
    new-instance v0, Lorg/lighttouch/android/MainActivity$poll$1;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/MainActivity$poll$1;-><init>(Lorg/lighttouch/android/MainActivity;)V

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->poll:Lorg/lighttouch/android/MainActivity$poll$1;

    .line 276
    const/4 v0, -0x1

    iput v0, p0, Lorg/lighttouch/android/MainActivity;->sixtyHertzMode:I

    .line 290
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocumentTree;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda34;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda34;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickFolder:Landroidx/activity/result/ActivityResultLauncher;

    .line 291
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda35;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda35;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickSystem:Landroidx/activity/result/ActivityResultLauncher;

    .line 292
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda36;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda36;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickRom:Landroidx/activity/result/ActivityResultLauncher;

    .line 293
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$OpenDocument;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda37;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda37;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickGuestToolsFile:Landroidx/activity/result/ActivityResultLauncher;

    .line 398
    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->dismissedError:Ljava/lang/String;

    .line 1166
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda38;

    invoke-direct {v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda38;-><init>()V

    invoke-static {v0}, Lkotlin/LazyKt;->lazy(Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->sensorThread$delegate:Lkotlin/Lazy;

    .line 34
    return-void
.end method

.method private final PrepareOverlay(Landroidx/compose/runtime/Composer;I)V
    .locals 24
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 741
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x29617287

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(PrepareOverlay)742@49247L34,742@49216L65,744@49362L14,744@49393L64,745@49485L62,745@49565L17,745@49596L18,746@49647L29,747@49701L103,748@49834L54,748@49903L17,748@49932L18,743@49290L661:MainActivity.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    move v5, v6

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v4, 0x3

    if-ne v5, v6, :cond_3

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_1

    .line 744
    :cond_2
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v16, v3

    move v2, v4

    goto/16 :goto_19

    .line 741
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_4

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.MainActivity.PrepareOverlay (MainActivity.kt:740)"

    invoke-static {v2, v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 742
    :cond_4
    iget-object v2, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v2}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v2

    const/4 v5, 0x0

    if-eqz v2, :cond_5

    invoke-virtual {v2}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v2

    goto :goto_2

    :cond_5
    move-object v2, v5

    .line 743
    .local v2, "board":Ljava/lang/String;
    :goto_2
    invoke-direct {v0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v6

    const v7, -0x615d173a

    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "CC(remember):MainActivity.kt#9igjgp"

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v8, v9

    .local v8, "invalid\\1":Z
    move-object v9, v3

    .local v9, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 1416
    .local v10, "$i$f$cache\\1\\743":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 1417
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\1416\\1":I
    if-nez v8, :cond_7

    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_6

    goto :goto_3

    .line 1421
    :cond_6
    move-object v14, v11

    goto :goto_4

    .line 1418
    :cond_7
    :goto_3
    const/4 v13, 0x0

    .line 743
    .local v13, "$i$a$-cache-MainActivity$PrepareOverlay$1\\3\\1418\\0":I
    new-instance v14, Lorg/lighttouch/android/MainActivity$PrepareOverlay$1$1;

    invoke-direct {v14, v2, v0, v5}, Lorg/lighttouch/android/MainActivity$PrepareOverlay$1$1;-><init>(Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Lkotlin/coroutines/Continuation;)V

    check-cast v14, Lkotlin/jvm/functions/Function2;

    .line 1418
    .end local v13    # "$i$a$-cache-MainActivity$PrepareOverlay$1\\3\\1418\\0":I
    nop

    .line 1419
    .local v14, "value\\2":Ljava/lang/Object;
    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1420
    nop

    .line 1417
    .end local v14    # "value\\2":Ljava/lang/Object;
    :goto_4
    nop

    .line 1416
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\1416\\1":I
    nop

    .line 743
    .end local v8    # "invalid\\1":Z
    .end local v9    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\1\\743":I
    check-cast v14, Lkotlin/jvm/functions/Function2;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v5, 0x0

    invoke-static {v2, v6, v14, v3, v5}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 744
    iget-object v5, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    move v6, v4

    .end local v4    # "$dirty":I
    .local v6, "$dirty":I
    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getBusy()Z

    move-result v4

    move-object v8, v5

    invoke-direct {v0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v5

    const v9, 0x4c5de2

    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .line 745
    move-object v11, v3

    .local v10, "invalid\\4":Z
    .local v11, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1422
    .local v12, "$i$f$cache\\4\\745":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\4":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1423
    .local v14, "$i$a$-let-ComposerKt$cache$1\\5\\1422\\4":I
    if-nez v10, :cond_9

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_8

    goto :goto_5

    .line 1427
    :cond_8
    move-object v9, v13

    goto :goto_6

    .line 1424
    :cond_9
    :goto_5
    const/4 v15, 0x0

    .line 745
    .local v15, "$i$a$-cache-MainActivity$PrepareOverlay$2\\6\\1424\\0":I
    new-instance v9, Lorg/lighttouch/android/MainActivity$PrepareOverlay$2$1;

    invoke-direct {v9, v0}, Lorg/lighttouch/android/MainActivity$PrepareOverlay$2$1;-><init>(Ljava/lang/Object;)V

    check-cast v9, Lkotlin/reflect/KFunction;

    .line 1424
    .end local v15    # "$i$a$-cache-MainActivity$PrepareOverlay$2\\6\\1424\\0":I
    nop

    .line 1425
    .local v9, "value\\5":Ljava/lang/Object;
    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1426
    nop

    .line 1423
    .end local v9    # "value\\5":Ljava/lang/Object;
    :goto_6
    nop

    .line 1422
    .end local v13    # "it\\4":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\5\\1422\\4":I
    nop

    .line 745
    .end local v10    # "invalid\\4":Z
    .end local v11    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\4\\745":I
    check-cast v9, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    check-cast v9, Lkotlin/jvm/functions/Function0;

    const v10, 0x4c5de2

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .local v10, "invalid\\7":Z
    move-object v11, v3

    .local v11, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1422
    .local v12, "$i$f$cache\\7\\745":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\7":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1423
    .local v14, "$i$a$-let-ComposerKt$cache$1\\8\\1422\\7":I
    if-nez v10, :cond_b

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_a

    goto :goto_7

    .line 1427
    :cond_a
    move-object/from16 v19, v2

    move-object v2, v13

    goto :goto_8

    .line 1424
    :cond_b
    :goto_7
    const/4 v15, 0x0

    .line 745
    .local v15, "$i$a$-cache-MainActivity$PrepareOverlay$3\\9\\1424\\0":I
    move-object/from16 v19, v2

    .end local v2    # "board":Ljava/lang/String;
    .local v19, "board":Ljava/lang/String;
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda20;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda20;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 1424
    .end local v15    # "$i$a$-cache-MainActivity$PrepareOverlay$3\\9\\1424\\0":I
    nop

    .line 1425
    .local v2, "value\\8":Ljava/lang/Object;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1426
    nop

    .line 1423
    .end local v2    # "value\\8":Ljava/lang/Object;
    :goto_8
    nop

    .line 1422
    .end local v13    # "it\\7":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\8\\1422\\7":I
    nop

    .line 745
    .end local v10    # "invalid\\7":Z
    .end local v11    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\7\\745":I
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v10, 0x4c5de2

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .line 746
    move-object v11, v3

    .local v10, "invalid\\10":Z
    .local v11, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1428
    .local v12, "$i$f$cache\\10\\746":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\10":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1429
    .local v14, "$i$a$-let-ComposerKt$cache$1\\11\\1428\\10":I
    if-nez v10, :cond_d

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_c

    goto :goto_9

    .line 1433
    :cond_c
    move-object/from16 v16, v2

    move-object v2, v13

    goto :goto_a

    .line 1430
    :cond_d
    :goto_9
    const/4 v15, 0x0

    .line 746
    .local v15, "$i$a$-cache-MainActivity$PrepareOverlay$4\\12\\1430\\0":I
    move-object/from16 v16, v2

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda21;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda21;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 1430
    .end local v15    # "$i$a$-cache-MainActivity$PrepareOverlay$4\\12\\1430\\0":I
    nop

    .line 1431
    .local v2, "value\\11":Ljava/lang/Object;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1432
    nop

    .line 1429
    .end local v2    # "value\\11":Ljava/lang/Object;
    :goto_a
    nop

    .line 1428
    .end local v13    # "it\\10":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\11\\1428\\10":I
    nop

    .line 746
    .end local v10    # "invalid\\10":Z
    .end local v11    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\10\\746":I
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v10, 0x4c5de2

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .local v10, "invalid\\13":Z
    move-object v11, v3

    .local v11, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1428
    .local v12, "$i$f$cache\\13\\746":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\13":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1429
    .local v14, "$i$a$-let-ComposerKt$cache$1\\14\\1428\\13":I
    if-nez v10, :cond_f

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_e

    goto :goto_b

    .line 1433
    :cond_e
    move-object/from16 v17, v2

    move-object v2, v13

    goto :goto_c

    .line 1430
    :cond_f
    :goto_b
    const/4 v15, 0x0

    .line 746
    .local v15, "$i$a$-cache-MainActivity$PrepareOverlay$5\\15\\1430\\0":I
    move-object/from16 v17, v2

    new-instance v2, Lorg/lighttouch/android/MainActivity$PrepareOverlay$5$1;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$PrepareOverlay$5$1;-><init>(Ljava/lang/Object;)V

    check-cast v2, Lkotlin/reflect/KFunction;

    .line 1430
    .end local v15    # "$i$a$-cache-MainActivity$PrepareOverlay$5\\15\\1430\\0":I
    nop

    .line 1431
    .local v2, "value\\14":Ljava/lang/Object;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1432
    nop

    .line 1429
    .end local v2    # "value\\14":Ljava/lang/Object;
    :goto_c
    nop

    .line 1428
    .end local v13    # "it\\13":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\14\\1428\\13":I
    nop

    .line 746
    .end local v10    # "invalid\\13":Z
    .end local v11    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\13\\746":I
    check-cast v2, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    check-cast v2, Lkotlin/jvm/functions/Function0;

    const v10, 0x4c5de2

    invoke-interface {v3, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .local v10, "invalid\\16":Z
    move-object v11, v3

    .local v11, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1428
    .local v12, "$i$f$cache\\16\\746":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\16":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1429
    .local v14, "$i$a$-let-ComposerKt$cache$1\\17\\1428\\16":I
    if-nez v10, :cond_11

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_10

    goto :goto_d

    .line 1433
    :cond_10
    move-object/from16 v18, v2

    move-object v2, v13

    goto :goto_e

    .line 1430
    :cond_11
    :goto_d
    const/4 v15, 0x0

    .line 746
    .local v15, "$i$a$-cache-MainActivity$PrepareOverlay$6\\18\\1430\\0":I
    move-object/from16 v18, v2

    new-instance v2, Lorg/lighttouch/android/MainActivity$PrepareOverlay$6$1;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$PrepareOverlay$6$1;-><init>(Ljava/lang/Object;)V

    check-cast v2, Lkotlin/reflect/KFunction;

    .line 1430
    .end local v15    # "$i$a$-cache-MainActivity$PrepareOverlay$6\\18\\1430\\0":I
    nop

    .line 1431
    .local v2, "value\\17":Ljava/lang/Object;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1432
    nop

    .line 1429
    .end local v2    # "value\\17":Ljava/lang/Object;
    :goto_e
    nop

    .line 1428
    .end local v13    # "it\\16":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\17\\1428\\16":I
    nop

    .line 746
    .end local v10    # "invalid\\16":Z
    .end local v11    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\16\\746":I
    check-cast v2, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v10, v2

    check-cast v10, Lkotlin/jvm/functions/Function0;

    const v2, 0x4c5de2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .line 747
    move-object v11, v3

    .local v2, "invalid\\19":Z
    .local v11, "$this$cache\\19":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1434
    .local v12, "$i$f$cache\\19\\747":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\19":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1435
    .local v14, "$i$a$-let-ComposerKt$cache$1\\20\\1434\\19":I
    if-nez v2, :cond_13

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_12

    goto :goto_f

    .line 1439
    :cond_12
    move/from16 v20, v2

    move-object v2, v13

    goto :goto_10

    .line 1436
    :cond_13
    :goto_f
    const/4 v15, 0x0

    .line 747
    .local v15, "$i$a$-cache-MainActivity$PrepareOverlay$7\\21\\1436\\0":I
    move/from16 v20, v2

    .end local v2    # "invalid\\19":Z
    .local v20, "invalid\\19":Z
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda22;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda22;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 1436
    .end local v15    # "$i$a$-cache-MainActivity$PrepareOverlay$7\\21\\1436\\0":I
    nop

    .line 1437
    .local v2, "value\\20":Ljava/lang/Object;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1438
    nop

    .line 1435
    .end local v2    # "value\\20":Ljava/lang/Object;
    :goto_10
    nop

    .line 1434
    .end local v13    # "it\\19":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\20\\1434\\19":I
    nop

    .line 747
    .end local v11    # "$this$cache\\19":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\19\\747":I
    .end local v20    # "invalid\\19":Z
    move-object v11, v2

    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x4c5de2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .line 748
    move-object v12, v3

    .local v2, "invalid\\22":Z
    .local v12, "$this$cache\\22":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 1440
    .local v13, "$i$f$cache\\22\\748":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\22":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 1441
    .local v15, "$i$a$-let-ComposerKt$cache$1\\23\\1440\\22":I
    if-nez v2, :cond_15

    sget-object v20, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v21, v2

    .end local v2    # "invalid\\22":Z
    .local v21, "invalid\\22":Z
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v14, v2, :cond_14

    goto :goto_11

    .line 1445
    :cond_14
    move-object v2, v14

    goto :goto_12

    .line 1441
    .end local v21    # "invalid\\22":Z
    .restart local v2    # "invalid\\22":Z
    :cond_15
    move/from16 v21, v2

    .line 1442
    .end local v2    # "invalid\\22":Z
    .restart local v21    # "invalid\\22":Z
    :goto_11
    const/4 v2, 0x0

    .line 748
    .local v2, "$i$a$-cache-MainActivity$PrepareOverlay$8\\24\\1442\\0":I
    move/from16 v20, v2

    .end local v2    # "$i$a$-cache-MainActivity$PrepareOverlay$8\\24\\1442\\0":I
    .local v20, "$i$a$-cache-MainActivity$PrepareOverlay$8\\24\\1442\\0":I
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda23;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda23;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 1442
    .end local v20    # "$i$a$-cache-MainActivity$PrepareOverlay$8\\24\\1442\\0":I
    nop

    .line 1443
    .local v2, "value\\23":Ljava/lang/Object;
    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1444
    nop

    .line 1441
    .end local v2    # "value\\23":Ljava/lang/Object;
    :goto_12
    nop

    .line 1440
    .end local v14    # "it\\22":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\23\\1440\\22":I
    nop

    .line 748
    .end local v12    # "$this$cache\\22":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$cache\\22\\748":I
    .end local v21    # "invalid\\22":Z
    move-object v12, v2

    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x4c5de2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .line 749
    move-object v13, v3

    .local v2, "invalid\\25":Z
    .local v13, "$this$cache\\25":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 1446
    .local v14, "$i$f$cache\\25\\749":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\25":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 1447
    .local v20, "$i$a$-let-ComposerKt$cache$1\\26\\1446\\25":I
    if-nez v2, :cond_17

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v22, v2

    .end local v2    # "invalid\\25":Z
    .local v22, "invalid\\25":Z
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v15, v2, :cond_16

    goto :goto_13

    .line 1451
    :cond_16
    move-object v2, v15

    goto :goto_14

    .line 1447
    .end local v22    # "invalid\\25":Z
    .restart local v2    # "invalid\\25":Z
    :cond_17
    move/from16 v22, v2

    .line 1448
    .end local v2    # "invalid\\25":Z
    .restart local v22    # "invalid\\25":Z
    :goto_13
    const/4 v2, 0x0

    .line 749
    .local v2, "$i$a$-cache-MainActivity$PrepareOverlay$9\\27\\1448\\0":I
    move/from16 v21, v2

    .end local v2    # "$i$a$-cache-MainActivity$PrepareOverlay$9\\27\\1448\\0":I
    .local v21, "$i$a$-cache-MainActivity$PrepareOverlay$9\\27\\1448\\0":I
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda24;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda24;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 1448
    .end local v21    # "$i$a$-cache-MainActivity$PrepareOverlay$9\\27\\1448\\0":I
    nop

    .line 1449
    .local v2, "value\\26":Ljava/lang/Object;
    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1450
    nop

    .line 1447
    .end local v2    # "value\\26":Ljava/lang/Object;
    :goto_14
    nop

    .line 1446
    .end local v15    # "it\\25":Ljava/lang/Object;
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\26\\1446\\25":I
    nop

    .line 749
    .end local v13    # "$this$cache\\25":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\25\\749":I
    .end local v22    # "invalid\\25":Z
    move-object v13, v2

    check-cast v13, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v2, 0x4c5de2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\28":Z
    move-object v14, v3

    .local v14, "$this$cache\\28":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 1446
    .local v15, "$i$f$cache\\28\\749":I
    move/from16 v20, v2

    .end local v2    # "invalid\\28":Z
    .local v20, "invalid\\28":Z
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\28":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 1447
    .local v21, "$i$a$-let-ComposerKt$cache$1\\29\\1446\\28":I
    if-nez v20, :cond_19

    sget-object v22, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v23, v4

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v2, v4, :cond_18

    goto :goto_15

    .line 1451
    :cond_18
    move-object/from16 v22, v2

    goto :goto_16

    .line 1447
    :cond_19
    move/from16 v23, v4

    .line 1448
    :goto_15
    const/4 v4, 0x0

    .line 749
    .local v4, "$i$a$-cache-MainActivity$PrepareOverlay$10\\30\\1448\\0":I
    move-object/from16 v22, v2

    .end local v2    # "it\\28":Ljava/lang/Object;
    .local v22, "it\\28":Ljava/lang/Object;
    new-instance v2, Lorg/lighttouch/android/MainActivity$PrepareOverlay$10$1;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$PrepareOverlay$10$1;-><init>(Ljava/lang/Object;)V

    check-cast v2, Lkotlin/reflect/KFunction;

    .line 1448
    .end local v4    # "$i$a$-cache-MainActivity$PrepareOverlay$10\\30\\1448\\0":I
    nop

    .line 1449
    .local v2, "value\\29":Ljava/lang/Object;
    invoke-interface {v14, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1450
    nop

    .line 1447
    .end local v2    # "value\\29":Ljava/lang/Object;
    :goto_16
    nop

    .line 1446
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\29\\1446\\28":I
    .end local v22    # "it\\28":Ljava/lang/Object;
    nop

    .line 749
    .end local v14    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\28\\749":I
    .end local v20    # "invalid\\28":Z
    check-cast v2, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v14, v2

    check-cast v14, Lkotlin/jvm/functions/Function0;

    const v2, 0x4c5de2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\31":Z
    move-object v4, v3

    .local v4, "$this$cache\\31":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1446
    .local v7, "$i$f$cache\\31\\749":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\31":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 1447
    .local v20, "$i$a$-let-ComposerKt$cache$1\\32\\1446\\31":I
    if-nez v2, :cond_1b

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p1, v2

    .end local v2    # "invalid\\31":Z
    .local p1, "invalid\\31":Z
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v15, v2, :cond_1a

    goto :goto_17

    .line 1451
    :cond_1a
    move-object v2, v15

    goto :goto_18

    .line 1447
    .end local p1    # "invalid\\31":Z
    .restart local v2    # "invalid\\31":Z
    :cond_1b
    move/from16 p1, v2

    .line 1448
    .end local v2    # "invalid\\31":Z
    .restart local p1    # "invalid\\31":Z
    :goto_17
    const/4 v2, 0x0

    .line 749
    .local v2, "$i$a$-cache-MainActivity$PrepareOverlay$11\\33\\1448\\0":I
    move/from16 v21, v2

    .end local v2    # "$i$a$-cache-MainActivity$PrepareOverlay$11\\33\\1448\\0":I
    .local v21, "$i$a$-cache-MainActivity$PrepareOverlay$11\\33\\1448\\0":I
    new-instance v2, Lorg/lighttouch/android/MainActivity$PrepareOverlay$11$1;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$PrepareOverlay$11$1;-><init>(Ljava/lang/Object;)V

    check-cast v2, Lkotlin/reflect/KFunction;

    .line 1448
    .end local v21    # "$i$a$-cache-MainActivity$PrepareOverlay$11\\33\\1448\\0":I
    nop

    .line 1449
    .local v2, "value\\32":Ljava/lang/Object;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1450
    nop

    .line 1447
    .end local v2    # "value\\32":Ljava/lang/Object;
    :goto_18
    nop

    .line 1446
    .end local v15    # "it\\31":Ljava/lang/Object;
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\32\\1446\\31":I
    nop

    .line 749
    .end local v4    # "$this$cache\\31":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\31\\749":I
    .end local p1    # "invalid\\31":Z
    check-cast v2, Lkotlin/reflect/KFunction;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v15, v2

    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 744
    move-object/from16 v2, v17

    const/16 v17, 0x0

    move v4, v6

    move-object v6, v9

    move-object/from16 v9, v18

    .end local v6    # "$dirty":I
    .local v4, "$dirty":I
    const/16 v18, 0x0

    move-object/from16 v7, v16

    move-object/from16 v16, v3

    move-object v3, v8

    move-object v8, v2

    move v2, v4

    move/from16 v4, v23

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v4    # "$dirty":I
    .local v2, "$dirty":I
    .local v16, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v18}, Lorg/lighttouch/android/PrepareScreenKt;->PrepareScreen(Lorg/lighttouch/android/PrepareState;ZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v19    # "board":Ljava/lang/String;
    :cond_1c
    :goto_19
    invoke-interface/range {v16 .. v16}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_1d

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda25;

    invoke-direct {v4, v0, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda25;-><init>(Lorg/lighttouch/android/MainActivity;I)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 750
    :cond_1d
    return-void
.end method

.method private static final PrepareOverlay$lambda$128$lambda$127(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 745
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->stockIpsw:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "application/octet-stream"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "*/*"

    aput-object v3, v1, v2

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareOverlay$lambda$130$lambda$129(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 746
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prepRom:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "application/octet-stream"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "*/*"

    aput-object v3, v1, v2

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareOverlay$lambda$134$lambda$133(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 747
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->preparedCopy:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareOverlay$lambda$137$lambda$136(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 6
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 748
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IFirmware;->cancel()V

    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v1

    if-eqz v1, :cond_1

    .line 1369
    move-object v2, v1

    .local v2, "$this$PrepareOverlay_u24lambda_u24137_u24lambda_u24136_u24lambda_u24135\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 748
    .local v3, "$i$a$-apply-MainActivity$PrepareOverlay$8$1$1\\1\\748\\0":I
    const-string v4, "state"

    const-string v5, "cancelling"

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .end local v2    # "$this$PrepareOverlay_u24lambda_u24137_u24lambda_u24136_u24lambda_u24135\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-MainActivity$PrepareOverlay$8$1$1\\1\\748\\0":I
    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareOverlay$lambda$140$lambda$139(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 749
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 1369
    .local v0, "it\\1":Landroid/os/Bundle;
    const/4 v1, 0x0

    .line 749
    .local v1, "$i$a$-let-MainActivity$PrepareOverlay$9$1$1\\1\\749\\0":I
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->importPreparedOutput(Landroid/os/Bundle;)V

    .end local v0    # "it\\1":Landroid/os/Bundle;
    .end local v1    # "$i$a$-let-MainActivity$PrepareOverlay$9$1$1\\1\\749\\0":I
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrepareOverlay$lambda$143(Lorg/lighttouch/android/MainActivity;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-direct {p0, p2, v0}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$PrepareOverlay(Lorg/lighttouch/android/MainActivity;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 34
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->PrepareOverlay(Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$applyWindowMode(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "immersive"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->applyWindowMode(Z)V

    return-void
.end method

.method public static final synthetic access$askNotifications(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->askNotifications()V

    return-void
.end method

.method public static final synthetic access$beginPreparation(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->beginPreparation()V

    return-void
.end method

.method public static final synthetic access$closeHitch(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->closeHitch()V

    return-void
.end method

.method public static final synthetic access$closePreparation(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->closePreparation()V

    return-void
.end method

.method public static final synthetic access$createDevice(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->createDevice()V

    return-void
.end method

.method public static final synthetic access$downloadBootrom(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->downloadBootrom()V

    return-void
.end method

.method public static final synthetic access$downloadIpsw(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->downloadIpsw()V

    return-void
.end method

.method public static final synthetic access$findBootrom(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "board"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->findBootrom(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$getActive$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    return v0
.end method

.method public static final synthetic access$getAddRetainedWhenReady$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->addRetainedWhenReady:Z

    return v0
.end method

.method public static final synthetic access$getBase(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/Screen;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getBase()Lorg/lighttouch/android/Screen;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getDetailsDevice(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/DeviceSummary;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getDetailsDevice()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getDevicesOpen(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getDevicesOpen()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$getDismissedError$p(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->dismissedError:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getDisplayOwnerTicket$p(Lorg/lighttouch/android/MainActivity;)J
    .locals 2
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-wide v0, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    return-wide v0
.end method

.method public static final synthetic access$getDisplayView$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/GuestDisplay;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    return-object v0
.end method

.method public static final synthetic access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getEngineExpectedExit$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineExpectedExit:Z

    return v0
.end method

.method public static final synthetic access$getFirmware$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IFirmware;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    return-object v0
.end method

.method public static final synthetic access$getFirmwareExpectedExit$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareExpectedExit:Z

    return v0
.end method

.method public static final synthetic access$getFirmwareRestarting(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getFirmwareRestarting()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$getHandler$p(Lorg/lighttouch/android/MainActivity;)Landroid/os/Handler;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    return-object v0
.end method

.method public static final synthetic access$getHitchData(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/HitchData;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getHitchData()Lorg/lighttouch/android/HitchData;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getHitchError(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getHitchError()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getHitchNotice(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getHitchNotice()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getHitchReport(Lorg/lighttouch/android/MainActivity;)Landroid/net/Uri;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getHitchReport()Landroid/net/Uri;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getHitchSaving(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getHitchSaving()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$getLicensesOpen(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getLicensesOpen()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$getLocalIpa$p(Lorg/lighttouch/android/MainActivity;)Landroidx/activity/result/ActivityResultLauncher;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->localIpa:Landroidx/activity/result/ActivityResultLauncher;

    return-object v0
.end method

.method public static final synthetic access$getMonitor$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/PerformanceMonitor;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->monitor:Lorg/lighttouch/android/PerformanceMonitor;

    return-object v0
.end method

.method public static final synthetic access$getMuxSocket(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getMuxSocket()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getNotice(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getNotice()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getOverlay(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/Screen;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getPendingFirmwareStart$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pendingFirmwareStart:Z

    return v0
.end method

.method public static final synthetic access$getPendingGuestRequest$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/MainActivity$GuestStartRequest;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestRequest:Lorg/lighttouch/android/MainActivity$GuestStartRequest;

    return-object v0
.end method

.method public static final synthetic access$getPendingGuestStart$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestStart:Z

    return v0
.end method

.method public static final synthetic access$getPickFolder$p(Lorg/lighttouch/android/MainActivity;)Landroidx/activity/result/ActivityResultLauncher;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickFolder:Landroidx/activity/result/ActivityResultLauncher;

    return-object v0
.end method

.method public static final synthetic access$getPickRom$p(Lorg/lighttouch/android/MainActivity;)Landroidx/activity/result/ActivityResultLauncher;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickRom:Landroidx/activity/result/ActivityResultLauncher;

    return-object v0
.end method

.method public static final synthetic access$getPickSystem$p(Lorg/lighttouch/android/MainActivity;)Landroidx/activity/result/ActivityResultLauncher;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickSystem:Landroidx/activity/result/ActivityResultLauncher;

    return-object v0
.end method

.method public static final synthetic access$getPollInFlight$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pollInFlight:Z

    return v0
.end method

.method public static final synthetic access$getPrep$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/PrepareState;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    return-object v0
.end method

.method public static final synthetic access$getPreparationOpen(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getPreparationOpen()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$getPreparedImportInFlight$p(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->preparedImportInFlight:Z

    return v0
.end method

.method public static final synthetic access$getRecords(Lorg/lighttouch/android/MainActivity;)Ljava/util/List;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getRecordsLoaded(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getRecordsLoaded()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$getRetainedPreparedOutput$p(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    return-object v0
.end method

.method public static final synthetic access$getSetup$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/SetupState;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    return-object v0
.end method

.method public static final synthetic access$getStore(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreModel;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$getWorkerEvidenceDelivery$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/SessionDeliveryGate;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    return-object v0
.end method

.method public static final synthetic access$importPreparedOutput(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "state"    # Landroid/os/Bundle;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->importPreparedOutput(Landroid/os/Bundle;)V

    return-void
.end method

.method public static final synthetic access$installsFinished(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->installsFinished()V

    return-void
.end method

.method public static final synthetic access$mayClaimDisplay(Lorg/lighttouch/android/MainActivity;)Z
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->mayClaimDisplay()Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$openDeviceFiles(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->openDeviceFiles()V

    return-void
.end method

.method public static final synthetic access$pollPreparation(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "state"    # Landroid/os/Bundle;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->pollPreparation(Landroid/os/Bundle;)V

    return-void
.end method

.method public static final synthetic access$preferSixtyHertz(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "guestInFront"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->preferSixtyHertz(Z)V

    return-void
.end method

.method public static final synthetic access$restartFirmwareForPreparation(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->restartFirmwareForPreparation()V

    return-void
.end method

.method public static final synthetic access$retainedPreparation(Lorg/lighttouch/android/MainActivity;)Landroid/os/Bundle;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->retainedPreparation()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$saveHitch(Lorg/lighttouch/android/MainActivity;JJ)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "from"    # J
    .param p3, "to"    # J

    .line 34
    invoke-direct {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/MainActivity;->saveHitch(JJ)V

    return-void
.end method

.method public static final synthetic access$setAddRetainedWhenReady$p(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    iput-boolean p1, p0, Lorg/lighttouch/android/MainActivity;->addRetainedWhenReady:Z

    return-void
.end method

.method public static final synthetic access$setAppServicesError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setAppServicesError(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setBase(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Screen;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/Screen;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setBase(Lorg/lighttouch/android/Screen;)V

    return-void
.end method

.method public static final synthetic access$setDetail(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setDetail(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setDevicesOpen(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setDevicesOpen(Z)V

    return-void
.end method

.method public static final synthetic access$setDismissedError$p(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    iput-object p1, p0, Lorg/lighttouch/android/MainActivity;->dismissedError:Ljava/lang/String;

    return-void
.end method

.method public static final synthetic access$setDisplayAsleep(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setDisplayAsleep(Z)V

    return-void
.end method

.method public static final synthetic access$setDisplayView$p(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/GuestDisplay;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/GuestDisplay;

    .line 34
    iput-object p1, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    return-void
.end method

.method public static final synthetic access$setEngine(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/IEngine;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setEngine(Lorg/lighttouch/android/IEngine;)V

    return-void
.end method

.method public static final synthetic access$setEngineRestarting$p(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    iput-boolean p1, p0, Lorg/lighttouch/android/MainActivity;->engineRestarting:Z

    return-void
.end method

.method public static final synthetic access$setError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setFirmware$p(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IFirmware;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/IFirmware;

    .line 34
    iput-object p1, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    return-void
.end method

.method public static final synthetic access$setFirmwareExpectedExit$p(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    iput-boolean p1, p0, Lorg/lighttouch/android/MainActivity;->firmwareExpectedExit:Z

    return-void
.end method

.method public static final synthetic access$setFirmwareRestarting(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setFirmwareRestarting(Z)V

    return-void
.end method

.method public static final synthetic access$setLicensesOpen(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setLicensesOpen(Z)V

    return-void
.end method

.method public static final synthetic access$setMuxSocket(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setMuxSocket(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setNotice(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setOverlay(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Screen;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Lorg/lighttouch/android/Screen;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    return-void
.end method

.method public static final synthetic access$setPendingFirmwareStart$p(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    iput-boolean p1, p0, Lorg/lighttouch/android/MainActivity;->pendingFirmwareStart:Z

    return-void
.end method

.method public static final synthetic access$setPendingGuestStart$p(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    iput-boolean p1, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestStart:Z

    return-void
.end method

.method public static final synthetic access$setPollInFlight$p(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    iput-boolean p1, p0, Lorg/lighttouch/android/MainActivity;->pollInFlight:Z

    return-void
.end method

.method public static final synthetic access$setProfileAutomatic(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setProfileAutomatic(Z)V

    return-void
.end method

.method public static final synthetic access$setProfileNotice(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setProfileNotice(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setProfileRecording(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setProfileRecording(Z)V

    return-void
.end method

.method public static final synthetic access$setSessionOwned(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Z

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setSessionOwned(Z)V

    return-void
.end method

.method public static final synthetic access$setStatus(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setWorkerPid(Lorg/lighttouch/android/MainActivity;I)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "<set-?>"    # I

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setWorkerPid(I)V

    return-void
.end method

.method public static final synthetic access$shareReport(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 34
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->shareReport(Landroid/net/Uri;)V

    return-void
.end method

.method public static final synthetic access$startSensors(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->startSensors()V

    return-void
.end method

.method public static final synthetic access$stopSensors(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopSensors()V

    return-void
.end method

.method public static final synthetic access$workerExited(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->workerExited()V

    return-void
.end method

.method public static final synthetic access$workerExitedRun(Lorg/lighttouch/android/MainActivity;)Landroid/os/Bundle;
    .locals 1
    .param p0, "$this"    # Lorg/lighttouch/android/MainActivity;

    .line 34
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->workerExitedRun()Landroid/os/Bundle;

    move-result-object v0

    return-object v0
.end method

.method private final addPreparedCopy(Landroid/net/Uri;)V
    .locals 2
    .param p1, "uri"    # Landroid/net/Uri;

    .line 759
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getBusy()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 760
    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->releaseFirmware()V

    .line 761
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/SetupState;->reset(Z)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    sget-object v1, Lorg/lighttouch/android/SetupStep;->FILES:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    sget-object v0, Lorg/lighttouch/android/Screen;->SETUP:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 762
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda52;

    invoke-direct {v0, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda52;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-direct {p0, p1, v0}, Lorg/lighttouch/android/MainActivity;->scanFolder(Landroid/net/Uri;Lkotlin/jvm/functions/Function0;)V

    .line 763
    return-void

    .line 759
    :cond_1
    :goto_0
    return-void
.end method

.method private static final addPreparedCopy$lambda$144(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 762
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->createDevice()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final applySettings$lambda$44(Lorg/lighttouch/android/IEngine;IZ)V
    .locals 1
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$scale"    # I
    .param p2, "$detailed"    # Z

    .line 461
    :try_start_0
    invoke-interface {p0, p1}, Lorg/lighttouch/android/IEngine;->setPresentScale(I)V

    invoke-interface {p0, p2}, Lorg/lighttouch/android/IEngine;->setDetailedTiming(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    :goto_0
    return-void
.end method

.method private final applyWindowMode(Z)V
    .locals 3
    .param p1, "immersive"    # Z

    .line 1193
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getInsetsController()Landroid/view/WindowInsetsController;

    move-result-object v0

    if-eqz v0, :cond_3

    .local v0, "controller\\1":Landroid/view/WindowInsetsController;
    const/4 v1, 0x0

    .line 1194
    .local v1, "$i$a$-let-MainActivity$applyWindowMode$1\\1\\1193\\0":I
    if-eqz p1, :cond_0

    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v2

    invoke-interface {v0, v2}, Landroid/view/WindowInsetsController;->hide(I)V

    const/4 v2, 0x2

    invoke-interface {v0, v2}, Landroid/view/WindowInsetsController;->setSystemBarsBehavior(I)V

    goto :goto_0

    .line 1195
    :cond_0
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v2

    invoke-interface {v0, v2}, Landroid/view/WindowInsetsController;->show(I)V

    .line 1196
    :goto_0
    nop

    .line 1193
    .end local v0    # "controller\\1":Landroid/view/WindowInsetsController;
    .end local v1    # "$i$a$-let-MainActivity$applyWindowMode$1\\1\\1193\\0":I
    goto :goto_2

    .line 1197
    :cond_1
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    if-eqz p1, :cond_2

    const/16 v1, 0x1706

    goto :goto_1

    .line 1199
    :cond_2
    const/16 v1, 0x700

    .line 1197
    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 1202
    :cond_3
    :goto_2
    return-void
.end method

.method private final askNotifications()V
    .locals 2

    .line 87
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_0

    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->askedNotifications:Z

    if-nez v0, :cond_0

    const-string v0, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_0

    .line 88
    const/4 v1, 0x1

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->askedNotifications:Z

    .line 89
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->notificationPermission:Landroidx/activity/result/ActivityResultLauncher;

    invoke-virtual {v1, v0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 91
    :cond_0
    return-void
.end method

.method private final beginPreparation()V
    .locals 11

    .line 765
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getBusy()Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_3

    .line 766
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    move-object v4, v0

    .line 767
    .local v4, "chosen":Lorg/lighttouch/android/CatalogFirmware;
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v0

    if-eqz v0, :cond_6

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v0

    if-nez v0, :cond_2

    goto/16 :goto_2

    .line 768
    :cond_2
    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    const/4 v1, 0x1

    if-nez v3, :cond_3

    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/MainActivity;

    .line 1369
    .local v0, "$this$beginPreparation_u24lambda_u24145\\1":Lorg/lighttouch/android/MainActivity;
    const/4 v2, 0x0

    .line 768
    .local v2, "$i$a$-run-MainActivity$beginPreparation$worker$1\\1\\768\\0":I
    iput-boolean v1, v0, Lorg/lighttouch/android/MainActivity;->pendingFirmwareStart:Z

    invoke-direct {v0, v1}, Lorg/lighttouch/android/MainActivity;->setFirmwareRestarting(Z)V

    invoke-direct {v0}, Lorg/lighttouch/android/MainActivity;->bindFirmware()V

    return-void

    .line 771
    .end local v0    # "$this$beginPreparation_u24lambda_u24145\\1":Lorg/lighttouch/android/MainActivity;
    .end local v2    # "$i$a$-run-MainActivity$beginPreparation$worker$1\\1\\768\\0":I
    .local v3, "worker":Lorg/lighttouch/android/IFirmware;
    :cond_3
    :try_start_0
    invoke-interface {v3}, Lorg/lighttouch/android/IFirmware;->status()Landroid/os/Bundle;

    move-result-object v0

    const-string v2, "consumed"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    :goto_0
    move v0, v1

    .line 772
    .local v0, "spent":Z
    if-eqz v0, :cond_4

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->restartFirmwareForPreparation()V

    return-void

    .line 773
    :cond_4
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getIpswPath()Ljava/lang/String;

    move-result-object v5

    .line 774
    .local v5, "selectedIpsw":Ljava/lang/String;
    invoke-virtual {v4}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareCatalogKt;->needsBootrom(Ljava/lang/String;)Z

    move-result v1

    const-string v2, ""

    if-eqz v1, :cond_5

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getRomPath()Ljava/lang/String;

    move-result-object v1

    move-object v6, v1

    goto :goto_1

    :cond_5
    move-object v6, v2

    .line 775
    .local v6, "selectedRom":Ljava/lang/String;
    :goto_1
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setImportError(Ljava/lang/String;)V

    .line 776
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 1369
    move-object v7, v2

    .local v7, "$this$beginPreparation_u24lambda_u24146\\2":Landroid/os/Bundle;
    const/4 v8, 0x0

    .line 776
    .local v8, "$i$a$-apply-MainActivity$beginPreparation$1\\2\\776\\0":I
    const-string v9, "state"

    const-string v10, "starting"

    invoke-virtual {v7, v9, v10}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v9, "firmwareId"

    invoke-virtual {v4}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v9, v10}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .end local v7    # "$this$beginPreparation_u24lambda_u24146\\2":Landroid/os/Bundle;
    .end local v8    # "$i$a$-apply-MainActivity$beginPreparation$1\\2\\776\\0":I
    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    .line 777
    new-instance v1, Landroid/content/Intent;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    const-class v7, Lorg/lighttouch/android/FirmwareService;

    invoke-direct {v1, v2, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 778
    new-instance v7, Ljava/lang/Thread;

    .line 785
    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda56;

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda56;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/CatalogFirmware;Ljava/lang/String;Ljava/lang/String;)V

    .line 778
    const-string v2, "prepare-start"

    invoke-direct {v7, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 785
    invoke-virtual {v7}, Ljava/lang/Thread;->start()V

    .line 786
    return-void

    .line 767
    .end local v0    # "spent":Z
    .end local v3    # "worker":Lorg/lighttouch/android/IFirmware;
    .end local v5    # "selectedIpsw":Ljava/lang/String;
    .end local v6    # "selectedRom":Ljava/lang/String;
    :cond_6
    :goto_2
    return-void

    .line 765
    .end local v4    # "chosen":Lorg/lighttouch/android/CatalogFirmware;
    :cond_7
    :goto_3
    return-void
.end method

.method private static final beginPreparation$lambda$150(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/CatalogFirmware;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$worker"    # Lorg/lighttouch/android/IFirmware;
    .param p2, "$chosen"    # Lorg/lighttouch/android/CatalogFirmware;
    .param p3, "$selectedIpsw"    # Ljava/lang/String;
    .param p4, "$selectedRom"    # Ljava/lang/String;

    .line 779
    nop

    .line 781
    :try_start_0
    sget-object v0, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/GuestTools;->firmwareTools(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    .line 782
    .local v0, "tools":Ljava/io/File;
    invoke-virtual {p2}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v1, p3, v2, p4}, Lorg/lighttouch/android/IFirmware;->start(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v1

    .line 783
    .local v1, "state":Landroid/os/Bundle;
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda68;

    invoke-direct {v3, p0, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda68;-><init>(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "tools":Ljava/io/File;
    .end local v1    # "state":Landroid/os/Bundle;
    goto :goto_0

    .line 784
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda69;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda69;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 785
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method private static final beginPreparation$lambda$150$lambda$147(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$state"    # Landroid/os/Bundle;

    .line 783
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    return-void
.end method

.method private static final beginPreparation$lambda$150$lambda$149(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 6
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 784
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 1369
    move-object v2, v1

    .local v2, "$this$beginPreparation_u24lambda_u24150_u24lambda_u24149_u24lambda_u24148\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 784
    .local v3, "$i$a$-apply-MainActivity$beginPreparation$2$2$1\\1\\784\\0":I
    const-string v4, "state"

    const-string v5, "failed"

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_0

    const-string v4, "\u65e0\u6cd5\u5f00\u59cb\u51c6\u5907"

    :cond_0
    const-string v5, "error"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v4, "consumed"

    const/4 v5, 0x1

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .end local v2    # "$this$beginPreparation_u24lambda_u24150_u24lambda_u24149_u24lambda_u24148\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-MainActivity$beginPreparation$2$2$1\\1\\784\\0":I
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    return-void
.end method

.method private final bindFirmware()V
    .locals 3

    .line 716
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    check-cast v0, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    .line 717
    :cond_0
    new-instance v0, Landroid/content/Intent;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    const-class v2, Lorg/lighttouch/android/FirmwareService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    check-cast v1, Landroid/content/ServiceConnection;

    const/4 v2, 0x1

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/MainActivity;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    .line 718
    return-void
.end method

.method private final bindWorker()V
    .locals 3

    .line 965
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    invoke-virtual {v0}, Lorg/lighttouch/android/SessionDeliveryGate;->advance()J

    .line 966
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->bound:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->connection:Lorg/lighttouch/android/MainActivity$connection$1;

    check-cast v0, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->bound:Z

    .line 971
    :cond_0
    new-instance v0, Landroid/content/Intent;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    const-class v2, Lorg/lighttouch/android/EngineService;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->connection:Lorg/lighttouch/android/MainActivity$connection$1;

    check-cast v1, Landroid/content/ServiceConnection;

    const/16 v2, 0x41

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/MainActivity;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->bound:Z

    .line 972
    return-void
.end method

.method private static final buttonCalls$lambda$7(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 2
    .param p0, "it"    # Ljava/lang/Runnable;

    .line 97
    new-instance v0, Ljava/lang/Thread;

    const-string v1, "guest-buttons"

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    return-object v0
.end method

.method private final capture()V
    .locals 6

    .line 1080
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "screenshots/guest-"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    .line 1081
    .local v0, "path":Ljava/lang/String;
    new-instance v1, Ljava/lang/Thread;

    .line 1099
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda117;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda117;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 1081
    const-string v3, "screenshot"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1099
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 1100
    return-void
.end method

.method private static final capture$lambda$231(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 14
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$path"    # Ljava/lang/String;

    .line 1082
    const-string v0, "is_pending"

    .line 1083
    :try_start_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-interface {v1, p1}, Lorg/lighttouch/android/IEngine;->screenshot(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1

    :cond_0
    const-string v1, "\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528"

    .line 1084
    .local v1, "result":Ljava/lang/String;
    :cond_1
    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_2

    move v2, v3

    goto :goto_0

    :cond_2
    move v2, v4

    :goto_0
    if-eqz v2, :cond_5

    .line 1085
    new-instance v2, Landroid/content/ContentValues;

    invoke-direct {v2}, Landroid/content/ContentValues;-><init>()V

    move-object v5, v2

    .local v5, "$this$capture_u24lambda_u24231_u24lambda_u24226\\2":Landroid/content/ContentValues;
    const/4 v6, 0x0

    .line 1086
    .local v6, "$i$a$-apply-MainActivity$capture$1$values$1\\2\\1085\\0":I
    const-string v7, "_display_name"

    new-instance v8, Ljava/io/File;

    invoke-direct {v8, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v7, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 1087
    const-string v7, "mime_type"

    const-string v8, "image/png"

    invoke-virtual {v5, v7, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 1088
    const-string v7, "relative_path"

    const-string v8, "Pictures/LightTouch"

    invoke-virtual {v5, v7, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 1089
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v5, v0, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 1090
    nop

    .line 1085
    .end local v5    # "$this$capture_u24lambda_u24231_u24lambda_u24226\\2":Landroid/content/ContentValues;
    .end local v6    # "$i$a$-apply-MainActivity$capture$1$values$1\\2\\1085\\0":I
    nop

    .line 1091
    .local v2, "values":Landroid/content/ContentValues;
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    sget-object v5, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-virtual {v3, v5, v2}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-eqz v3, :cond_4

    .line 1092
    .local v3, "uri":Landroid/net/Uri;
    nop

    .line 1093
    const/4 v5, 0x0

    :try_start_1
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    invoke-virtual {v6, v3}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v6

    if-eqz v6, :cond_3

    check-cast v6, Ljava/io/Closeable;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    move-object v7, v6

    check-cast v7, Ljava/io/OutputStream;

    .line 1369
    .local v7, "output\\3":Ljava/io/OutputStream;
    const/4 v8, 0x0

    .local v8, "$i$a$-use-MainActivity$capture$1$2\\3\\1093\\0":I
    new-instance v9, Ljava/io/FileInputStream;

    .line 1093
    new-instance v10, Ljava/io/File;

    invoke-direct {v10, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v9, v10}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v9, Ljava/io/Closeable;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    move-object v10, v9

    check-cast v10, Ljava/io/FileInputStream;

    .line 1369
    .local v10, "it\\4":Ljava/io/FileInputStream;
    const/4 v11, 0x0

    .line 1093
    .local v11, "$i$a$-use-MainActivity$capture$1$2$1\\4\\1093\\3":I
    move-object v12, v10

    check-cast v12, Ljava/io/InputStream;

    const/4 v13, 0x2

    invoke-static {v12, v7, v4, v13, v5}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .end local v10    # "it\\4":Ljava/io/FileInputStream;
    .end local v11    # "$i$a$-use-MainActivity$capture$1$2$1\\4\\1093\\3":I
    :try_start_4
    invoke-static {v9, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .end local v7    # "output\\3":Ljava/io/OutputStream;
    .end local v8    # "$i$a$-use-MainActivity$capture$1$2\\3\\1093\\0":I
    :try_start_5
    invoke-static {v6, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1094
    invoke-virtual {v2}, Landroid/content/ContentValues;->clear()V

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v0, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 1095
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, v3, v2, v5, v5}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    .line 1097
    :try_start_6
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda110;

    invoke-direct {v4, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda110;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v0, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    .end local v1    # "result":Ljava/lang/String;
    .end local v2    # "values":Landroid/content/ContentValues;
    .end local v3    # "uri":Landroid/net/Uri;
    goto :goto_1

    .line 1093
    .restart local v1    # "result":Ljava/lang/String;
    .restart local v2    # "values":Landroid/content/ContentValues;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v7    # "output\\3":Ljava/io/OutputStream;
    .restart local v8    # "$i$a$-use-MainActivity$capture$1$2\\3\\1093\\0":I
    :catchall_0
    move-exception v0

    .end local v1    # "result":Ljava/lang/String;
    .end local v2    # "values":Landroid/content/ContentValues;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local v7    # "output\\3":Ljava/io/OutputStream;
    .end local v8    # "$i$a$-use-MainActivity$capture$1$2\\3\\1093\\0":I
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    :try_start_7
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .restart local v1    # "result":Ljava/lang/String;
    .restart local v2    # "values":Landroid/content/ContentValues;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v7    # "output\\3":Ljava/io/OutputStream;
    .restart local v8    # "$i$a$-use-MainActivity$capture$1$2\\3\\1093\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :catchall_1
    move-exception v4

    :try_start_8
    invoke-static {v9, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v1    # "result":Ljava/lang/String;
    .end local v2    # "values":Landroid/content/ContentValues;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    throw v4
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .end local v7    # "output\\3":Ljava/io/OutputStream;
    .end local v8    # "$i$a$-use-MainActivity$capture$1$2\\3\\1093\\0":I
    .restart local v1    # "result":Ljava/lang/String;
    .restart local v2    # "values":Landroid/content/ContentValues;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :catchall_2
    move-exception v0

    .end local v1    # "result":Ljava/lang/String;
    .end local v2    # "values":Landroid/content/ContentValues;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    :try_start_9
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .restart local v1    # "result":Ljava/lang/String;
    .restart local v2    # "values":Landroid/content/ContentValues;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :catchall_3
    move-exception v4

    :try_start_a
    invoke-static {v6, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v1    # "result":Ljava/lang/String;
    .end local v2    # "values":Landroid/content/ContentValues;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    throw v4

    .restart local v1    # "result":Ljava/lang/String;
    .restart local v2    # "values":Landroid/content/ContentValues;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v4, "\u65e0\u6cd5\u5199\u5165\u622a\u56fe"

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v1    # "result":Ljava/lang/String;
    .end local v2    # "values":Landroid/content/ContentValues;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    throw v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0

    .line 1096
    .restart local v1    # "result":Ljava/lang/String;
    .restart local v2    # "values":Landroid/content/ContentValues;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    :try_start_b
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    invoke-virtual {v4, v3, v5, v5}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    throw v0

    .line 1091
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v3    # "uri":Landroid/net/Uri;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v3, "\u65e0\u6cd5\u521b\u5efa\u622a\u56fe"

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    throw v0

    .line 1369
    .end local v2    # "values":Landroid/content/ContentValues;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :cond_5
    const/4 v0, 0x0

    .line 1084
    .local v0, "$i$a$-require-MainActivity$capture$1$1\\1\\1084\\0":I
    nop

    .end local v0    # "$i$a$-require-MainActivity$capture$1$1\\1\\1084\\0":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$path":Ljava/lang/String;
    throw v0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_1

    .line 1098
    .end local v1    # "result":Ljava/lang/String;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$path":Ljava/lang/String;
    :catch_1
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda111;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda111;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1099
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method

.method private static final capture$lambda$231$lambda$229(Lorg/lighttouch/android/MainActivity;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1097
    const-string v0, "\u622a\u56fe\u5df2\u4fdd\u5b58\u5230 Pictures/LightTouch"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    return-void
.end method

.method private static final capture$lambda$231$lambda$230(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 1098
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, "\u622a\u5c4f\u5931\u8d25"

    :cond_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    return-void
.end method

.method private final closeHitch()V
    .locals 1

    .line 508
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchData(Lorg/lighttouch/android/HitchData;)V

    .line 509
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->hitchResume:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPaused(Z)V

    .line 510
    :cond_0
    return-void
.end method

.method private final closePreparation()V
    .locals 2

    .line 702
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getBusy()Z

    move-result v0

    if-nez v0, :cond_3

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 703
    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    .line 705
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getFirmwareId()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    move v1, v0

    :goto_0
    if-eqz v1, :cond_2

    const-string v1, "preparation-imports"

    invoke-virtual {p0, v1, v0}, Lorg/lighttouch/android/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "firmwareId"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 706
    :cond_2
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->releaseFirmware()V

    .line 707
    return-void

    .line 702
    :cond_3
    :goto_1
    return-void
.end method

.method private final copyAsset(Landroid/net/Uri;Ljava/lang/String;)V
    .locals 3
    .param p1, "uri"    # Landroid/net/Uri;
    .param p2, "targetName"    # Ljava/lang/String;

    .line 1102
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    .line 1103
    new-instance v0, Ljava/lang/Thread;

    .line 1118
    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p2, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Landroid/net/Uri;)V

    .line 1103
    const-string v2, "asset-import"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1118
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 1119
    return-void
.end method

.method private static final copyAsset$lambda$238(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Landroid/net/Uri;)V
    .locals 12
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$targetName"    # Ljava/lang/String;
    .param p2, "$uri"    # Landroid/net/Uri;

    .line 1104
    nop

    .line 1105
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 1106
    .local v0, "target":Ljava/io/File;
    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ".partial"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 1107
    .local v1, "temporary":Ljava/io/File;
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    invoke-virtual {v2, p2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v2

    if-eqz v2, :cond_6

    check-cast v2, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    move-object v3, v2

    check-cast v3, Ljava/io/InputStream;

    .line 1369
    .local v3, "input\\1":Ljava/io/InputStream;
    const/4 v4, 0x0

    .local v4, "$i$a$-use-MainActivity$copyAsset$1$1\\1\\1107\\0":I
    new-instance v5, Ljava/io/FileOutputStream;

    .line 1107
    invoke-direct {v5, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v5, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v6, v5

    check-cast v6, Ljava/io/FileOutputStream;

    .line 1369
    .local v6, "it\\2":Ljava/io/FileOutputStream;
    const/4 v7, 0x0

    .line 1107
    .local v7, "$i$a$-use-MainActivity$copyAsset$1$1$1\\2\\1107\\1":I
    move-object v8, v6

    check-cast v8, Ljava/io/OutputStream;

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v3, v8, v10, v9, v11}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v6    # "it\\2":Ljava/io/FileOutputStream;
    .end local v7    # "$i$a$-use-MainActivity$copyAsset$1$1$1\\2\\1107\\1":I
    :try_start_3
    invoke-static {v5, v11}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyAsset$1$1\\1\\1107\\0":I
    :try_start_4
    invoke-static {v2, v11}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1108
    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 1111
    const-string v2, "guest.itpack"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lorg/lighttouch/android/DeviceSummary;->getId()Ljava/lang/String;

    move-result-object v11

    .line 1112
    .local v11, "device":Ljava/lang/String;
    :cond_0
    if-eqz v11, :cond_4

    .line 1113
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v2

    if-eqz v2, :cond_3

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v11, v3}, Lorg/lighttouch/android/IEngine;->setGuestPackage(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_3

    .line 1114
    .local v2, "result":Ljava/lang/String;
    move-object v3, v2

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-nez v3, :cond_1

    const/4 v10, 0x1

    :cond_1
    if-eqz v10, :cond_2

    goto :goto_0

    .line 1369
    :cond_2
    const/4 v3, 0x0

    .line 1114
    .local v3, "$i$a$-require-MainActivity$copyAsset$1$3\\4\\1114\\0":I
    nop

    .end local v3    # "$i$a$-require-MainActivity$copyAsset$1$3\\4\\1114\\0":I
    new-instance v3, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v3

    .line 1113
    .end local v2    # "result":Ljava/lang/String;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_3
    new-instance v2, Ljava/lang/IllegalStateException;

    const-string v3, "\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528"

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v2

    .line 1116
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_4
    :goto_0
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda62;

    invoke-direct {v3, p0, v11, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda62;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local v11    # "device":Ljava/lang/String;
    goto :goto_1

    .line 1369
    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    :cond_5
    const/4 v2, 0x0

    .line 1108
    .local v2, "$i$a$-check-MainActivity$copyAsset$1$2\\3\\1108\\0":I
    const-string v3, "\u65e0\u6cd5\u53d1\u5e03\u5bfc\u5165\u7684\u6587\u4ef6"

    .end local v2    # "$i$a$-check-MainActivity$copyAsset$1$2\\3\\1108\\0":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v2
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 1107
    .local v3, "input\\1":Ljava/io/InputStream;
    .restart local v4    # "$i$a$-use-MainActivity$copyAsset$1$1\\1\\1107\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_0
    move-exception v6

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyAsset$1$1\\1\\1107\\0":I
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    :try_start_5
    throw v6
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    .restart local v3    # "input\\1":Ljava/io/InputStream;
    .restart local v4    # "$i$a$-use-MainActivity$copyAsset$1$1\\1\\1107\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_1
    move-exception v7

    :try_start_6
    invoke-static {v5, v6}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v7
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyAsset$1$1\\1\\1107\\0":I
    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_2
    move-exception v3

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    :try_start_7
    throw v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .restart local v0    # "target":Ljava/io/File;
    .restart local v1    # "temporary":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_3
    move-exception v4

    :try_start_8
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v4

    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_6
    new-instance v2, Ljava/lang/IllegalStateException;

    const-string v3, "\u65e0\u6cd5\u8bfb\u53d6\u6587\u4ef6"

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$targetName":Ljava/lang/String;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v2
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 1117
    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "temporary":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$targetName":Ljava/lang/String;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda73;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda73;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1118
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method

.method private static final copyAsset$lambda$238$lambda$236(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$device"    # Ljava/lang/String;
    .param p2, "$targetName"    # Ljava/lang/String;

    .line 1116
    if-eqz p1, :cond_0

    const-string v0, "\u5ba2\u6237\u673a\u5de5\u5177\u5df2\u66f4\u65b0\uff0c\u5c06\u5728\u4e0b\u6b21\u542f\u52a8\u65f6\u5b89\u88c5"

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Imported "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    return-void
.end method

.method private static final copyAsset$lambda$238$lambda$237(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 1117
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, "\u5bfc\u5165\u5931\u8d25"

    :cond_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    return-void
.end method

.method private final copyTree(Landroid/net/Uri;Ljava/io/File;Lkotlin/jvm/functions/Function2;)V
    .locals 21
    .param p1, "tree"    # Landroid/net/Uri;
    .param p2, "destination"    # Ljava/io/File;
    .param p3, "progress"    # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Ljava/io/File;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 1127
    move-object/from16 v1, p0

    move-object/from16 v8, p1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v9, v0

    check-cast v9, Ljava/util/List;

    .line 1144
    .local v9, "files":Ljava/util/List;
    move-object v0, v1

    check-cast v0, Landroid/content/Context;

    invoke-static {v0, v8}, Landroid/provider/DocumentsContract;->isDocumentUri(Landroid/content/Context;Landroid/net/Uri;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {v8}, Landroid/provider/DocumentsContract;->getDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-static {v8}, Landroid/provider/DocumentsContract;->getTreeDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v10, p2

    invoke-static {v8, v1, v9, v0, v10}, Lorg/lighttouch/android/MainActivity;->copyTree$list(Landroid/net/Uri;Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/lang/String;Ljava/io/File;)V

    .line 1145
    move-object v0, v9

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-wide/16 v2, 0x0

    move-wide v4, v2

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lorg/lighttouch/android/MainActivity$copyTree$Entry;

    .line 1369
    nop

    .local v6, "it\\1":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    const/4 v7, 0x0

    .line 1145
    .local v7, "$i$a$-sumOfLong-MainActivity$copyTree$total$1\\1\\1145\\0":I
    invoke-virtual {v6}, Lorg/lighttouch/android/MainActivity$copyTree$Entry;->getSize()J

    move-result-wide v6

    .end local v6    # "it\\1":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .end local v7    # "$i$a$-sumOfLong-MainActivity$copyTree$total$1\\1\\1145\\0":I
    add-long/2addr v4, v6

    goto :goto_1

    .local v4, "total":J
    :cond_1
    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    move-object v6, v0

    .local v6, "copied":Ljava/util/concurrent/atomic/AtomicLong;
    new-instance v0, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    move-object v7, v0

    .local v7, "shown":Lkotlin/jvm/internal/Ref$LongRef;
    const-wide/16 v11, -0x1

    iput-wide v11, v7, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 1146
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    move-object/from16 v3, p3

    invoke-interface {v3, v0, v2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1147
    const/4 v0, 0x4

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v11

    .line 1148
    .local v11, "pool":Ljava/util/concurrent/ExecutorService;
    nop

    .line 1150
    :try_start_0
    move-object v0, v9

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$sortedByDescending\\2":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1465
    .local v2, "$i$f$sortedByDescending\\2\\1150":I
    new-instance v12, Lorg/lighttouch/android/MainActivity$copyTree$$inlined$sortedByDescending$1;

    invoke-direct {v12}, Lorg/lighttouch/android/MainActivity$copyTree$$inlined$sortedByDescending$1;-><init>()V

    check-cast v12, Ljava/util/Comparator;

    invoke-static {v0, v12}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v12

    .end local v0    # "$this$sortedByDescending\\2":Ljava/lang/Iterable;
    .end local v2    # "$i$f$sortedByDescending\\2\\1150":I
    check-cast v12, Ljava/lang/Iterable;

    .line 1150
    nop

    .local v12, "$this$map\\3":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 1466
    .local v13, "$i$f$map\\3\\1150":I
    new-instance v0, Ljava/util/ArrayList;

    const/16 v2, 0xa

    invoke-static {v12, v2}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    move-object v14, v0

    .local v14, "destination\\4":Ljava/util/Collection;
    move-object v15, v12

    .local v15, "$this$mapTo\\4":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 1467
    .local v16, "$i$f$mapTo\\4\\1466":I
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_2
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v0

    .line 1468
    .local v18, "item\\4":Ljava/lang/Object;
    move-object/from16 v2, v18

    check-cast v2, Lorg/lighttouch/android/MainActivity$copyTree$Entry;

    .local v2, "entry\\5":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    const/16 v19, 0x0

    .line 1150
    .local v19, "$i$a$-map-MainActivity$copyTree$jobs$2\\5\\1468\\0":I
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda105;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v20, v7

    move-object v7, v3

    move-object v3, v6

    move-object/from16 v6, v20

    .end local v7    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    .local v3, "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .local v6, "shown":Lkotlin/jvm/internal/Ref$LongRef;
    :try_start_1
    invoke-direct/range {v0 .. v7}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda105;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$copyTree$Entry;Ljava/util/concurrent/atomic/AtomicLong;JLkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/functions/Function2;)V

    invoke-interface {v11, v0}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    move-result-object v0

    .line 1160
    nop

    .line 1468
    .end local v2    # "entry\\5":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .end local v19    # "$i$a$-map-MainActivity$copyTree$jobs$2\\5\\1468\\0":I
    invoke-interface {v14, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p0

    move-object v7, v6

    move-object v6, v3

    move-object/from16 v3, p3

    goto :goto_2

    .line 1469
    .end local v3    # "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .end local v18    # "item\\4":Ljava/lang/Object;
    .local v6, "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .restart local v7    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    :cond_2
    move-object v3, v6

    move-object v6, v7

    .end local v7    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v14    # "destination\\4":Ljava/util/Collection;
    .end local v15    # "$this$mapTo\\4":Ljava/lang/Iterable;
    .end local v16    # "$i$f$mapTo\\4\\1466":I
    .restart local v3    # "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .local v6, "shown":Lkotlin/jvm/internal/Ref$LongRef;
    move-object v0, v14

    check-cast v0, Ljava/util/List;

    .line 1466
    nop

    .line 1150
    .end local v12    # "$this$map\\3":Ljava/lang/Iterable;
    .end local v13    # "$i$f$map\\3\\1150":I
    move-object v1, v0

    .line 1161
    .local v1, "jobs":Ljava/util/List;
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/concurrent/Future;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .local v2, "job":Ljava/util/concurrent/Future;
    :try_start_2
    invoke-interface {v2}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;
    :try_end_2
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_3

    :catch_0
    move-exception v0

    .local v0, "e":Ljava/util/concurrent/ExecutionException;
    :try_start_3
    invoke-virtual {v0}, Ljava/util/concurrent/ExecutionException;->getCause()Ljava/lang/Throwable;

    move-result-object v7

    instance-of v12, v7, Ljava/lang/Exception;

    if-eqz v12, :cond_3

    check-cast v7, Ljava/lang/Exception;

    goto :goto_4

    :cond_3
    const/4 v7, 0x0

    :goto_4
    if-eqz v7, :cond_4

    check-cast v7, Ljava/lang/Throwable;

    goto :goto_5

    :cond_4
    move-object v7, v0

    check-cast v7, Ljava/lang/Throwable;

    .end local v3    # "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .end local v4    # "total":J
    .end local v6    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v9    # "files":Ljava/util/List;
    .end local v11    # "pool":Ljava/util/concurrent/ExecutorService;
    .end local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "tree":Landroid/net/Uri;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "progress":Lkotlin/jvm/functions/Function2;
    :goto_5
    throw v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 1162
    .end local v0    # "e":Ljava/util/concurrent/ExecutionException;
    .end local v1    # "jobs":Ljava/util/List;
    .end local v2    # "job":Ljava/util/concurrent/Future;
    .restart local v3    # "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .restart local v4    # "total":J
    .restart local v6    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local v9    # "files":Ljava/util/List;
    .restart local v11    # "pool":Ljava/util/concurrent/ExecutorService;
    .restart local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "tree":Landroid/net/Uri;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "progress":Lkotlin/jvm/functions/Function2;
    :cond_5
    invoke-interface {v11}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 1163
    return-void

    .line 1162
    :catchall_0
    move-exception v0

    goto :goto_6

    .end local v3    # "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .local v6, "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .restart local v7    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    :catchall_1
    move-exception v0

    move-object v3, v6

    move-object v6, v7

    .end local v7    # "shown":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local v3    # "copied":Ljava/util/concurrent/atomic/AtomicLong;
    .local v6, "shown":Lkotlin/jvm/internal/Ref$LongRef;
    :goto_6
    invoke-interface {v11}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    throw v0
.end method

.method private static final copyTree$lambda$247$lambda$246(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$copyTree$Entry;Ljava/util/concurrent/atomic/AtomicLong;JLkotlin/jvm/internal/Ref$LongRef;Lkotlin/jvm/functions/Function2;)V
    .locals 18
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$entry"    # Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .param p2, "$copied"    # Ljava/util/concurrent/atomic/AtomicLong;
    .param p3, "$total"    # J
    .param p5, "$shown"    # Lkotlin/jvm/internal/Ref$LongRef;
    .param p6, "$progress"    # Lkotlin/jvm/functions/Function2;

    .line 1151
    move-object/from16 v1, p5

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/MainActivity$copyTree$Entry;->getUri()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v0

    if-eqz v0, :cond_3

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v2

    check-cast v0, Ljava/io/InputStream;

    move-object v3, v0

    .line 1369
    .local v3, "input\\1":Ljava/io/InputStream;
    const/4 v4, 0x0

    .local v4, "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    new-instance v0, Ljava/io/FileOutputStream;

    .line 1151
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/MainActivity$copyTree$Entry;->getTarget()Ljava/io/File;

    move-result-object v5

    invoke-direct {v0, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v5, v0

    check-cast v5, Ljava/io/Closeable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    :try_start_1
    move-object v0, v5

    check-cast v0, Ljava/io/FileOutputStream;

    .local v0, "output\\2":Ljava/io/FileOutputStream;
    const/4 v6, 0x0

    .line 1152
    .local v6, "$i$a$-use-MainActivity$copyTree$jobs$2$1$1$1\\2\\1151\\1":I
    const/high16 v7, 0x100000

    new-array v7, v7, [B

    .line 1153
    .local v7, "buffer\\2":[B
    :goto_0
    nop

    .line 1154
    invoke-virtual {v3, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    .local v8, "n\\2":I
    if-ltz v8, :cond_2

    .line 1155
    const/4 v9, 0x0

    invoke-virtual {v0, v7, v9, v8}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 1156
    int-to-long v9, v8

    move-object/from16 v11, p2

    :try_start_2
    invoke-virtual {v11, v9, v10}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide v9

    .line 1157
    .local v9, "done\\2":J
    const-wide/16 v12, 0x0

    cmp-long v12, p3, v12

    if-lez v12, :cond_1

    const/16 v12, 0x64

    int-to-long v12, v12

    mul-long v14, v9, v12

    div-long v14, v14, p3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object/from16 v16, v3

    move/from16 v17, v4

    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .local v16, "input\\1":Ljava/io/InputStream;
    .local v17, "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    :try_start_3
    iget-wide v3, v1, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    cmp-long v3, v14, v3

    if-eqz v3, :cond_0

    mul-long/2addr v12, v9

    div-long v12, v12, p3

    iput-wide v12, v1, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static/range {p3 .. p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move-object/from16 v12, p6

    :try_start_4
    invoke-interface {v12, v3, v4}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_0
    move-object/from16 v12, p6

    :goto_1
    move-object/from16 v3, v16

    move/from16 v4, v17

    goto :goto_0

    .line 1151
    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .end local v6    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1$1\\2\\1151\\1":I
    .end local v7    # "buffer\\2":[B
    .end local v8    # "n\\2":I
    .end local v9    # "done\\2":J
    :catchall_0
    move-exception v0

    move-object/from16 v12, p6

    goto :goto_2

    .line 1157
    .end local v16    # "input\\1":Ljava/io/InputStream;
    .end local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local v0    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v3    # "input\\1":Ljava/io/InputStream;
    .restart local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local v6    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1$1\\2\\1151\\1":I
    .restart local v7    # "buffer\\2":[B
    .restart local v8    # "n\\2":I
    .restart local v9    # "done\\2":J
    :cond_1
    move-object/from16 v12, p6

    move-object/from16 v16, v3

    move/from16 v17, v4

    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local v16    # "input\\1":Ljava/io/InputStream;
    .restart local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    goto :goto_0

    .line 1151
    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .end local v6    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1$1\\2\\1151\\1":I
    .end local v7    # "buffer\\2":[B
    .end local v8    # "n\\2":I
    .end local v9    # "done\\2":J
    .end local v16    # "input\\1":Ljava/io/InputStream;
    .end local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local v3    # "input\\1":Ljava/io/InputStream;
    .restart local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    :catchall_1
    move-exception v0

    goto :goto_3

    .line 1154
    .restart local v0    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v6    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1$1\\2\\1151\\1":I
    .restart local v7    # "buffer\\2":[B
    .restart local v8    # "n\\2":I
    :cond_2
    move-object/from16 v11, p2

    move-object/from16 v12, p6

    move-object/from16 v16, v3

    move/from16 v17, v4

    .line 1159
    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .end local v8    # "n\\2":I
    .restart local v16    # "input\\1":Ljava/io/InputStream;
    .restart local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    nop

    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .end local v6    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1$1\\2\\1151\\1":I
    .end local v7    # "buffer\\2":[B
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 1151
    const/4 v0, 0x0

    :try_start_5
    invoke-static {v5, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1159
    nop

    .end local v16    # "input\\1":Ljava/io/InputStream;
    .end local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    .line 1151
    invoke-static {v2, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1160
    return-void

    .line 1151
    .restart local v16    # "input\\1":Ljava/io/InputStream;
    .restart local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    :catchall_2
    move-exception v0

    :goto_2
    move-object v3, v0

    goto :goto_4

    .end local v16    # "input\\1":Ljava/io/InputStream;
    .end local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local v3    # "input\\1":Ljava/io/InputStream;
    .restart local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    :catchall_3
    move-exception v0

    move-object/from16 v11, p2

    :goto_3
    move-object/from16 v12, p6

    move-object/from16 v16, v3

    move/from16 v17, v4

    move-object v3, v0

    .end local v3    # "input\\1":Ljava/io/InputStream;
    .end local v4    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$entry":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .end local p2    # "$copied":Ljava/util/concurrent/atomic/AtomicLong;
    .end local p3    # "$total":J
    .end local p5    # "$shown":Lkotlin/jvm/internal/Ref$LongRef;
    .end local p6    # "$progress":Lkotlin/jvm/functions/Function2;
    :goto_4
    :try_start_6
    throw v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .restart local v16    # "input\\1":Ljava/io/InputStream;
    .restart local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$entry":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .restart local p2    # "$copied":Ljava/util/concurrent/atomic/AtomicLong;
    .restart local p3    # "$total":J
    .restart local p5    # "$shown":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local p6    # "$progress":Lkotlin/jvm/functions/Function2;
    :catchall_4
    move-exception v0

    :try_start_7
    invoke-static {v5, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$entry":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .end local p2    # "$copied":Ljava/util/concurrent/atomic/AtomicLong;
    .end local p3    # "$total":J
    .end local p5    # "$shown":Lkotlin/jvm/internal/Ref$LongRef;
    .end local p6    # "$progress":Lkotlin/jvm/functions/Function2;
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .end local v16    # "input\\1":Ljava/io/InputStream;
    .end local v17    # "$i$a$-use-MainActivity$copyTree$jobs$2$1$1\\1\\1151\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$entry":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .restart local p2    # "$copied":Ljava/util/concurrent/atomic/AtomicLong;
    .restart local p3    # "$total":J
    .restart local p5    # "$shown":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local p6    # "$progress":Lkotlin/jvm/functions/Function2;
    :catchall_5
    move-exception v0

    goto :goto_5

    :catchall_6
    move-exception v0

    move-object/from16 v11, p2

    move-object/from16 v12, p6

    :goto_5
    move-object v3, v0

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$entry":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .end local p2    # "$copied":Ljava/util/concurrent/atomic/AtomicLong;
    .end local p3    # "$total":J
    .end local p5    # "$shown":Lkotlin/jvm/internal/Ref$LongRef;
    .end local p6    # "$progress":Lkotlin/jvm/functions/Function2;
    :try_start_8
    throw v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_7

    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$entry":Lorg/lighttouch/android/MainActivity$copyTree$Entry;
    .restart local p2    # "$copied":Ljava/util/concurrent/atomic/AtomicLong;
    .restart local p3    # "$total":J
    .restart local p5    # "$shown":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local p6    # "$progress":Lkotlin/jvm/functions/Function2;
    :catchall_7
    move-exception v0

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_3
    move-object/from16 v11, p2

    move-object/from16 v12, p6

    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1159
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/MainActivity$copyTree$Entry;->getTarget()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u65e0\u6cd5\u8bfb\u53d6 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static final copyTree$list(Landroid/net/Uri;Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/lang/String;Ljava/io/File;)V
    .locals 16
    .param p0, "$tree"    # Landroid/net/Uri;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "files"    # Ljava/util/List;
    .param p3, "documentId"    # Ljava/lang/String;
    .param p4, "into"    # Ljava/io/File;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Lorg/lighttouch/android/MainActivity;",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/MainActivity$copyTree$Entry;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    .line 1129
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v3, p4

    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_7

    .line 1130
    move-object/from16 v4, p3

    invoke-static {v1, v4}, Landroid/provider/DocumentsContract;->buildChildDocumentsUriUsingTree(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    .line 1131
    .local v6, "children":Landroid/net/Uri;
    const/4 v0, 0x4

    new-array v7, v0, [Ljava/lang/String;

    const-string v0, "document_id"

    const/4 v11, 0x0

    aput-object v0, v7, v11

    const-string v0, "_display_name"

    const/4 v12, 0x1

    aput-object v0, v7, v12

    .line 1132
    const-string v0, "mime_type"

    const/4 v13, 0x2

    aput-object v0, v7, v13

    .line 1131
    nop

    .line 1132
    const-string v0, "_size"

    const/4 v14, 0x3

    aput-object v0, v7, v14

    .line 1131
    nop

    .line 1133
    .local v7, "columns":[Ljava/lang/String;
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v15, v0

    check-cast v15, Ljava/util/List;

    .line 1134
    .local v15, "folders":Ljava/util/List;
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v5 .. v10}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    if-eqz v0, :cond_6

    move-object v5, v0

    check-cast v5, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v5

    check-cast v0, Landroid/database/Cursor;

    .local v0, "c\\2":Landroid/database/Cursor;
    const/4 v8, 0x0

    .line 1135
    .local v8, "$i$a$-use-MainActivity$copyTree$list$2\\2\\1134\\0":I
    :goto_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v9

    const/4 v10, 0x0

    if-eqz v9, :cond_4

    .line 1136
    invoke-interface {v0, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_3

    .line 1137
    .local v9, "name\\2":Ljava/lang/String;
    const-string v12, "."

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_0

    const-string v12, ".."

    invoke-static {v9, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_0

    move-object v12, v9

    check-cast v12, Ljava/lang/CharSequence;

    const/16 v14, 0x2f

    invoke-static {v12, v14, v11, v13, v10}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_0

    const/4 v10, 0x1

    goto :goto_1

    :cond_0
    move v10, v11

    :goto_1
    if-eqz v10, :cond_2

    .line 1138
    invoke-interface {v0, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    const-string v12, "vnd.android.document/directory"

    invoke-static {v10, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1

    move-object v10, v15

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v0, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v12

    new-instance v14, Ljava/io/File;

    invoke-direct {v14, v3, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v12, v14}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v12

    invoke-interface {v10, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v12, 0x1

    const/4 v14, 0x3

    goto :goto_0

    .line 1139
    :cond_1
    move-object v10, v2

    check-cast v10, Ljava/util/Collection;

    new-instance v12, Lorg/lighttouch/android/MainActivity$copyTree$Entry;

    invoke-interface {v0, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v14}, Landroid/provider/DocumentsContract;->buildDocumentUriUsingTree(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v14

    const-string v11, "buildDocumentUriUsingTree(...)"

    invoke-static {v14, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v11, Ljava/io/File;

    invoke-direct {v11, v3, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v13, 0x3

    invoke-interface {v0, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v3

    invoke-direct {v12, v14, v11, v3, v4}, Lorg/lighttouch/android/MainActivity$copyTree$Entry;-><init>(Landroid/net/Uri;Ljava/io/File;J)V

    invoke-interface {v10, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v4, p3

    move-object/from16 v3, p4

    move v14, v13

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x2

    goto :goto_0

    .line 1369
    :cond_2
    const/4 v3, 0x0

    .line 1137
    .local v3, "$i$a$-require-MainActivity$copyTree$list$2$1\\3\\1137\\2":I
    const-string v4, "\u6761\u76ee\u540d\u79f0\u65e0\u6548"

    .end local v3    # "$i$a$-require-MainActivity$copyTree$list$2$1\\3\\1137\\2":I
    new-instance v3, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v6    # "children":Landroid/net/Uri;
    .end local v7    # "columns":[Ljava/lang/String;
    .end local v15    # "folders":Ljava/util/List;
    .end local p0    # "$tree":Landroid/net/Uri;
    .end local p1    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p2    # "files":Ljava/util/List;
    .end local p3    # "documentId":Ljava/lang/String;
    .end local p4    # "into":Ljava/io/File;
    throw v3

    .line 1136
    .end local v9    # "name\\2":Ljava/lang/String;
    .restart local v6    # "children":Landroid/net/Uri;
    .restart local v7    # "columns":[Ljava/lang/String;
    .restart local v15    # "folders":Ljava/util/List;
    .restart local p0    # "$tree":Landroid/net/Uri;
    .restart local p1    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p2    # "files":Ljava/util/List;
    .restart local p3    # "documentId":Ljava/lang/String;
    .restart local p4    # "into":Ljava/io/File;
    :cond_3
    new-instance v3, Ljava/lang/IllegalStateException;

    const-string v4, "\u7f3a\u5c11\u6761\u76ee\u540d\u79f0"

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v6    # "children":Landroid/net/Uri;
    .end local v7    # "columns":[Ljava/lang/String;
    .end local v15    # "folders":Ljava/util/List;
    .end local p0    # "$tree":Landroid/net/Uri;
    .end local p1    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p2    # "files":Ljava/util/List;
    .end local p3    # "documentId":Ljava/lang/String;
    .end local p4    # "into":Ljava/io/File;
    throw v3

    .line 1141
    .restart local v6    # "children":Landroid/net/Uri;
    .restart local v7    # "columns":[Ljava/lang/String;
    .restart local v15    # "folders":Ljava/util/List;
    .restart local p0    # "$tree":Landroid/net/Uri;
    .restart local p1    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p2    # "files":Ljava/util/List;
    .restart local p3    # "documentId":Ljava/lang/String;
    .restart local p4    # "into":Ljava/io/File;
    :cond_4
    nop

    .end local v0    # "c\\2":Landroid/database/Cursor;
    .end local v8    # "$i$a$-use-MainActivity$copyTree$list$2\\2\\1134\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 1134
    invoke-static {v5, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1142
    invoke-interface {v15}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lkotlin/Pair;

    invoke-virtual {v3}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "id":Ljava/lang/String;
    invoke-virtual {v3}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/io/File;

    move-object/from16 v8, p1

    .local v3, "folder":Ljava/io/File;
    invoke-static {v1, v8, v2, v4, v3}, Lorg/lighttouch/android/MainActivity;->copyTree$list(Landroid/net/Uri;Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/lang/String;Ljava/io/File;)V

    .end local v3    # "folder":Ljava/io/File;
    .end local v4    # "id":Ljava/lang/String;
    goto :goto_2

    .line 1143
    :cond_5
    move-object/from16 v8, p1

    return-void

    .line 1134
    :catchall_0
    move-exception v0

    move-object/from16 v8, p1

    move-object v3, v0

    .end local v6    # "children":Landroid/net/Uri;
    .end local v7    # "columns":[Ljava/lang/String;
    .end local v15    # "folders":Ljava/util/List;
    .end local p0    # "$tree":Landroid/net/Uri;
    .end local p1    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p2    # "files":Ljava/util/List;
    .end local p3    # "documentId":Ljava/lang/String;
    .end local p4    # "into":Ljava/io/File;
    :try_start_1
    throw v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local v6    # "children":Landroid/net/Uri;
    .restart local v7    # "columns":[Ljava/lang/String;
    .restart local v15    # "folders":Ljava/util/List;
    .restart local p0    # "$tree":Landroid/net/Uri;
    .restart local p1    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p2    # "files":Ljava/util/List;
    .restart local p3    # "documentId":Ljava/lang/String;
    .restart local p4    # "into":Ljava/io/File;
    :catchall_1
    move-exception v0

    invoke-static {v5, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_6
    move-object/from16 v8, p1

    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1141
    const-string v3, "\u65e0\u6cd5\u8bfb\u53d6\u8be5\u6587\u4ef6\u5939"

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 1369
    .end local v6    # "children":Landroid/net/Uri;
    .end local v7    # "columns":[Ljava/lang/String;
    .end local v15    # "folders":Ljava/util/List;
    :cond_7
    move-object/from16 v8, p1

    const/4 v0, 0x0

    .line 1129
    .local v0, "$i$a$-check-MainActivity$copyTree$list$1\\1\\1129\\0":I
    invoke-virtual/range {p4 .. p4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Cannot create "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v0    # "$i$a$-check-MainActivity$copyTree$list$1\\1\\1129\\0":I
    new-instance v3, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v3, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v3
.end method

.method private final copyWithProgress(Landroid/net/Uri;Ljava/io/File;Ljava/lang/String;)Ljava/lang/String;
    .locals 25
    .param p1, "uri"    # Landroid/net/Uri;
    .param p2, "target"    # Ljava/io/File;
    .param p3, "label"    # Ljava/lang/String;

    .line 582
    move-object/from16 v1, p0

    move-object/from16 v6, p1

    move-object v0, v1

    check-cast v0, Landroid/content/Context;

    invoke-static {v0, v6}, Landroidx/documentfile/provider/DocumentFile;->fromSingleUri(Landroid/content/Context;Landroid/net/Uri;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/documentfile/provider/DocumentFile;->length()J

    move-result-wide v2

    goto :goto_0

    :cond_0
    const-wide/16 v2, 0x0

    :goto_0
    move-wide v9, v2

    .line 583
    .local v9, "total":J
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v11

    .line 584
    .local v11, "digest":Ljava/security/MessageDigest;
    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, v6}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v0

    if-eqz v0, :cond_4

    move-object v12, v0

    check-cast v12, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v12

    check-cast v0, Ljava/io/InputStream;

    move-object v13, v0

    .line 1369
    .local v13, "input\\1":Ljava/io/InputStream;
    const/4 v14, 0x0

    .local v14, "$i$a$-use-MainActivity$copyWithProgress$1\\1\\584\\0":I
    new-instance v0, Ljava/io/FileOutputStream;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    .line 584
    move-object/from16 v15, p2

    :try_start_1
    invoke-direct {v0, v15}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    :try_start_2
    move-object v0, v2

    check-cast v0, Ljava/io/FileOutputStream;

    .local v0, "output\\2":Ljava/io/FileOutputStream;
    const/16 v16, 0x0

    .line 585
    .local v16, "$i$a$-use-MainActivity$copyWithProgress$1$1\\2\\584\\1":I
    const/high16 v3, 0x100000

    new-array v3, v3, [B

    .local v3, "buffer\\2":[B
    new-instance v5, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct {v5}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V

    .local v5, "done\\2":Lkotlin/jvm/internal/Ref$LongRef;
    const-wide/16 v17, -0x1

    .line 586
    .local v17, "shown\\2":J
    :goto_1
    nop

    .line 587
    invoke-virtual {v13, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    .local v4, "n\\2":I
    if-ltz v4, :cond_3

    .line 588
    const-wide/16 v19, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v7, v4}, Ljava/io/FileOutputStream;->write([BII)V

    invoke-virtual {v11, v3, v7, v4}, Ljava/security/MessageDigest;->update([BII)V

    iget-wide v7, v5, Lkotlin/jvm/internal/Ref$LongRef;->element:J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    move-object/from16 v21, v2

    move-object/from16 v22, v3

    .end local v3    # "buffer\\2":[B
    .local v22, "buffer\\2":[B
    int-to-long v2, v4

    add-long/2addr v7, v2

    :try_start_3
    iput-wide v7, v5, Lkotlin/jvm/internal/Ref$LongRef;->element:J
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 589
    cmp-long v2, v9, v19

    if-lez v2, :cond_1

    :try_start_4
    iget-wide v2, v5, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    const/16 v7, 0x64

    int-to-long v7, v7

    mul-long/2addr v2, v7

    div-long/2addr v2, v9
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_2

    .line 584
    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .end local v4    # "n\\2":I
    .end local v5    # "done\\2":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v16    # "$i$a$-use-MainActivity$copyWithProgress$1$1\\2\\584\\1":I
    .end local v17    # "shown\\2":J
    .end local v22    # "buffer\\2":[B
    :catchall_0
    move-exception v0

    move-object v1, v0

    move-object/from16 v8, v21

    goto/16 :goto_5

    .line 589
    .restart local v0    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v4    # "n\\2":I
    .restart local v5    # "done\\2":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local v16    # "$i$a$-use-MainActivity$copyWithProgress$1$1\\2\\584\\1":I
    .restart local v17    # "shown\\2":J
    .restart local v22    # "buffer\\2":[B
    :cond_1
    const-wide/16 v2, -0x1

    .line 590
    .local v2, "percent\\2":J
    :goto_2
    cmp-long v7, v2, v17

    if-eqz v7, :cond_2

    move-wide/from16 v17, v2

    :try_start_5
    iget-object v7, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    move-object v8, v0

    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .local v8, "output\\2":Ljava/io/FileOutputStream;
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda49;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    move-object/from16 v23, v21

    move-object/from16 v21, v8

    move-object/from16 v8, v23

    move/from16 v23, v4

    move-object/from16 v4, p3

    .end local v4    # "n\\2":I
    .end local v8    # "output\\2":Ljava/io/FileOutputStream;
    .local v21, "output\\2":Ljava/io/FileOutputStream;
    .local v23, "n\\2":I
    :try_start_6
    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda49;-><init>(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;Lkotlin/jvm/internal/Ref$LongRef;)V

    invoke-virtual {v7, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-object/from16 v1, p0

    move-object v2, v8

    move-object/from16 v0, v21

    goto :goto_3

    .end local v21    # "output\\2":Ljava/io/FileOutputStream;
    .end local v23    # "n\\2":I
    .restart local v0    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v4    # "n\\2":I
    :cond_2
    move/from16 v23, v4

    move-object/from16 v8, v21

    move-object/from16 v21, v0

    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .end local v4    # "n\\2":I
    .restart local v21    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v23    # "n\\2":I
    move-object/from16 v1, p0

    move-object v2, v8

    :goto_3
    move-object/from16 v3, v22

    goto :goto_1

    .line 584
    .end local v2    # "percent\\2":J
    .end local v5    # "done\\2":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v16    # "$i$a$-use-MainActivity$copyWithProgress$1$1\\2\\584\\1":I
    .end local v17    # "shown\\2":J
    .end local v21    # "output\\2":Ljava/io/FileOutputStream;
    .end local v22    # "buffer\\2":[B
    .end local v23    # "n\\2":I
    :catchall_1
    move-exception v0

    move-object/from16 v8, v21

    goto :goto_4

    .line 587
    .restart local v0    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v3    # "buffer\\2":[B
    .restart local v4    # "n\\2":I
    .restart local v5    # "done\\2":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local v16    # "$i$a$-use-MainActivity$copyWithProgress$1$1\\2\\584\\1":I
    .restart local v17    # "shown\\2":J
    :cond_3
    move-object/from16 v21, v0

    move-object v8, v2

    move-object/from16 v22, v3

    move/from16 v23, v4

    .line 592
    .end local v0    # "output\\2":Ljava/io/FileOutputStream;
    .end local v3    # "buffer\\2":[B
    .end local v4    # "n\\2":I
    .restart local v21    # "output\\2":Ljava/io/FileOutputStream;
    .restart local v22    # "buffer\\2":[B
    nop

    .end local v5    # "done\\2":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v16    # "$i$a$-use-MainActivity$copyWithProgress$1$1\\2\\584\\1":I
    .end local v17    # "shown\\2":J
    .end local v21    # "output\\2":Ljava/io/FileOutputStream;
    .end local v22    # "buffer\\2":[B
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 584
    const/4 v0, 0x0

    :try_start_7
    invoke-static {v8, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 592
    nop

    .end local v13    # "input\\1":Ljava/io/InputStream;
    .end local v14    # "$i$a$-use-MainActivity$copyWithProgress$1\\1\\584\\0":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .line 584
    invoke-static {v12, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 593
    invoke-virtual {v11}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v0

    const-string v1, "digest(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, ""

    move-object/from16 v17, v1

    check-cast v17, Ljava/lang/CharSequence;

    new-instance v22, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda50;

    invoke-direct/range {v22 .. v22}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda50;-><init>()V

    const/16 v23, 0x1e

    const/16 v24, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    move-object/from16 v16, v0

    invoke-static/range {v16 .. v24}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 584
    .restart local v13    # "input\\1":Ljava/io/InputStream;
    .restart local v14    # "$i$a$-use-MainActivity$copyWithProgress$1\\1\\584\\0":I
    :catchall_2
    move-exception v0

    goto :goto_4

    :catchall_3
    move-exception v0

    move-object v8, v2

    :goto_4
    move-object v1, v0

    .end local v9    # "total":J
    .end local v11    # "digest":Ljava/security/MessageDigest;
    .end local v13    # "input\\1":Ljava/io/InputStream;
    .end local v14    # "$i$a$-use-MainActivity$copyWithProgress$1\\1\\584\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "uri":Landroid/net/Uri;
    .end local p2    # "target":Ljava/io/File;
    .end local p3    # "label":Ljava/lang/String;
    :goto_5
    :try_start_8
    throw v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .restart local v9    # "total":J
    .restart local v11    # "digest":Ljava/security/MessageDigest;
    .restart local v13    # "input\\1":Ljava/io/InputStream;
    .restart local v14    # "$i$a$-use-MainActivity$copyWithProgress$1\\1\\584\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "uri":Landroid/net/Uri;
    .restart local p2    # "target":Ljava/io/File;
    .restart local p3    # "label":Ljava/lang/String;
    :catchall_4
    move-exception v0

    :try_start_9
    invoke-static {v8, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v9    # "total":J
    .end local v11    # "digest":Ljava/security/MessageDigest;
    .end local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "uri":Landroid/net/Uri;
    .end local p2    # "target":Ljava/io/File;
    .end local p3    # "label":Ljava/lang/String;
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .end local v13    # "input\\1":Ljava/io/InputStream;
    .end local v14    # "$i$a$-use-MainActivity$copyWithProgress$1\\1\\584\\0":I
    .restart local v9    # "total":J
    .restart local v11    # "digest":Ljava/security/MessageDigest;
    .restart local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "uri":Landroid/net/Uri;
    .restart local p2    # "target":Ljava/io/File;
    .restart local p3    # "label":Ljava/lang/String;
    :catchall_5
    move-exception v0

    goto :goto_6

    :catchall_6
    move-exception v0

    move-object/from16 v15, p2

    :goto_6
    move-object v1, v0

    .end local v9    # "total":J
    .end local v11    # "digest":Ljava/security/MessageDigest;
    .end local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "uri":Landroid/net/Uri;
    .end local p2    # "target":Ljava/io/File;
    .end local p3    # "label":Ljava/lang/String;
    :try_start_a
    throw v1
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    .restart local v9    # "total":J
    .restart local v11    # "digest":Ljava/security/MessageDigest;
    .restart local p0    # "this":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "uri":Landroid/net/Uri;
    .restart local p2    # "target":Ljava/io/File;
    .restart local p3    # "label":Ljava/lang/String;
    :catchall_7
    move-exception v0

    invoke-static {v12, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_4
    move-object/from16 v15, p2

    new-instance v0, Ljava/lang/IllegalStateException;

    .line 592
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u65e0\u6cd5\u8bfb\u53d6 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object/from16 v4, p3

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static final copyWithProgress$lambda$85$lambda$84$lambda$83(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;Lkotlin/jvm/internal/Ref$LongRef;)V
    .locals 7
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$percent"    # J
    .param p3, "$label"    # Ljava/lang/String;
    .param p4, "$done"    # Lkotlin/jvm/internal/Ref$LongRef;

    .line 590
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-wide/16 v1, 0x0

    cmp-long v3, p1, v1

    if-ltz v3, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\u2026"

    goto :goto_0

    :cond_0
    iget-wide v3, p4, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    const/16 v5, 0x14

    shr-long/2addr v3, v5

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\u2026 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " MB"

    :goto_0
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lorg/lighttouch/android/SetupState;->setPhase(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    cmp-long v1, p1, v1

    if-ltz v1, :cond_1

    long-to-float v1, p1

    const/high16 v2, 0x42c80000    # 100.0f

    div-float/2addr v1, v2

    goto :goto_1

    :cond_1
    const/high16 v1, -0x40800000    # -1.0f

    :goto_1
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setProgress(F)V

    return-void
.end method

.method private static final copyWithProgress$lambda$86(B)Ljava/lang/CharSequence;
    .locals 2
    .param p0, "it"    # B

    .line 593
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02x"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private final createDevice()V
    .locals 19

    .line 596
    move-object/from16 v1, p0

    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0}, Lorg/lighttouch/android/SetupState;->getSystem()Lorg/lighttouch/android/PickedFile;

    move-result-object v3

    if-nez v3, :cond_0

    return-void

    .line 597
    .local v3, "system":Lorg/lighttouch/android/PickedFile;
    :cond_0
    invoke-direct {v1}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v4

    if-nez v4, :cond_1

    move-object v0, v1

    check-cast v0, Lorg/lighttouch/android/MainActivity;

    .line 1369
    .local v0, "$this$createDevice_u24lambda_u2487\\1":Lorg/lighttouch/android/MainActivity;
    const/4 v2, 0x0

    .line 597
    .local v2, "$i$a$-run-MainActivity$createDevice$worker$1\\1\\597\\0":I
    iget-object v4, v0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-string v5, "LightTouch \u4ecd\u5728\u542f\u52a8\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\u3002"

    invoke-virtual {v4, v5}, Lorg/lighttouch/android/SetupState;->setError(Ljava/lang/String;)V

    return-void

    .line 598
    .end local v0    # "$this$createDevice_u24lambda_u2487\\1":Lorg/lighttouch/android/MainActivity;
    .end local v2    # "$i$a$-run-MainActivity$createDevice$worker$1\\1\\597\\0":I
    .local v4, "worker":Lorg/lighttouch/android/IEngine;
    :cond_1
    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0}, Lorg/lighttouch/android/SetupState;->getRom()Lorg/lighttouch/android/PickedFile;

    move-result-object v2

    .local v2, "rom":Lorg/lighttouch/android/PickedFile;
    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0}, Lorg/lighttouch/android/SetupState;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    .line 599
    .local v5, "requested":Ljava/lang/String;
    invoke-direct {v1}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1396
    .local v6, "$i$f$mapNotNull\\2\\599":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\3":Ljava/util/Collection;
    move-object v8, v0

    .local v8, "$this$mapNotNullTo\\3":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1404
    .local v9, "$i$f$mapNotNullTo\\3\\1396":I
    move-object v10, v8

    .local v10, "$this$forEach\\4":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 1405
    .local v11, "$i$f$forEach\\4\\1404":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_3

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\4":Ljava/lang/Object;
    move-object v14, v13

    .local v14, "element\\5":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 1404
    .local v15, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\5\\1405\\3":I
    move-object/from16 v16, v0

    .end local v0    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .local v16, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    move-object v0, v14

    check-cast v0, Landroid/os/Bundle;

    .local v0, "it\\7":Landroid/os/Bundle;
    const/16 v17, 0x0

    .line 599
    .local v17, "$i$a$-mapNotNull-MainActivity$createDevice$before$1\\7\\1404\\0":I
    move-object/from16 v18, v2

    .end local v2    # "rom":Lorg/lighttouch/android/PickedFile;
    .local v18, "rom":Lorg/lighttouch/android/PickedFile;
    const-string v2, "id"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1404
    .end local v0    # "it\\7":Landroid/os/Bundle;
    .end local v17    # "$i$a$-mapNotNull-MainActivity$createDevice$before$1\\7\\1404\\0":I
    if-eqz v0, :cond_2

    .line 1406
    .local v0, "it\\5":Ljava/lang/Object;
    const/4 v2, 0x0

    .line 1404
    .local v2, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\6\\1406\\5":I
    invoke-interface {v7, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1405
    .end local v0    # "it\\5":Ljava/lang/Object;
    .end local v2    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\6\\1406\\5":I
    .end local v14    # "element\\5":Ljava/lang/Object;
    .end local v15    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\5\\1405\\3":I
    :cond_2
    move-object/from16 v0, v16

    move-object/from16 v2, v18

    .end local v13    # "element\\4":Ljava/lang/Object;
    goto :goto_0

    .line 1407
    .end local v16    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .end local v18    # "rom":Lorg/lighttouch/android/PickedFile;
    .local v0, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .local v2, "rom":Lorg/lighttouch/android/PickedFile;
    :cond_3
    move-object/from16 v16, v0

    move-object/from16 v18, v2

    .line 1408
    .end local v0    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .end local v2    # "rom":Lorg/lighttouch/android/PickedFile;
    .end local v10    # "$this$forEach\\4":Ljava/lang/Iterable;
    .end local v11    # "$i$f$forEach\\4\\1404":I
    .restart local v16    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .restart local v18    # "rom":Lorg/lighttouch/android/PickedFile;
    nop

    .end local v7    # "destination\\3":Ljava/util/Collection;
    .end local v8    # "$this$mapNotNullTo\\3":Ljava/lang/Iterable;
    .end local v9    # "$i$f$mapNotNullTo\\3\\1396":I
    move-object v0, v7

    check-cast v0, Ljava/util/List;

    .line 1396
    nop

    .end local v6    # "$i$f$mapNotNull\\2\\599":I
    .end local v16    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    check-cast v0, Ljava/lang/Iterable;

    .line 599
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v6

    .line 600
    .local v6, "before":Ljava/util/Set;
    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    sget-object v2, Lorg/lighttouch/android/SetupStep;->CREATING:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-string v2, ""

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/SetupState;->setError(Ljava/lang/String;)V

    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/SetupState;->setPhase(Ljava/lang/String;)V

    const/4 v0, 0x1

    invoke-direct {v1, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    .line 601
    new-instance v7, Ljava/lang/Thread;

    .line 645
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda0;

    move-object/from16 v2, v18

    .end local v18    # "rom":Lorg/lighttouch/android/PickedFile;
    .restart local v2    # "rom":Lorg/lighttouch/android/PickedFile;
    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/util/Set;)V

    .line 601
    const-string v1, "setup-create"

    invoke-direct {v7, v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 645
    invoke-virtual {v7}, Ljava/lang/Thread;->start()V

    .line 646
    return-void
.end method

.method private static final createDevice$lambda$108(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/util/Set;)V
    .locals 37
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$rom"    # Lorg/lighttouch/android/PickedFile;
    .param p2, "$system"    # Lorg/lighttouch/android/PickedFile;
    .param p3, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p4, "$requested"    # Ljava/lang/String;
    .param p5, "$before"    # Ljava/util/Set;

    .line 602
    move-object/from16 v1, p0

    move-object/from16 v2, p3

    const-string v0, "build"

    const-string v8, "board"

    new-instance v3, Ljava/io/File;

    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v4

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "setup-"

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v4, v3

    .line 1369
    .local v4, "$this$createDevice_u24lambda_u24108_u24lambda_u2489\\1":Ljava/io/File;
    const/4 v5, 0x0

    .line 602
    .local v5, "$i$a$-apply-MainActivity$createDevice$1$staging$1\\1\\602\\0":I
    invoke-virtual {v4}, Ljava/io/File;->mkdirs()Z

    .end local v4    # "$this$createDevice_u24lambda_u24108_u24lambda_u2489\\1":Ljava/io/File;
    .end local v5    # "$i$a$-apply-MainActivity$createDevice$1$staging$1\\1\\602\\0":I
    move-object v9, v3

    .line 603
    .local v9, "staging":Ljava/io/File;
    new-instance v3, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v3}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    move-object v10, v3

    .line 604
    .local v10, "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    nop

    .line 605
    const-string v11, ""

    if-eqz p1, :cond_0

    move-object/from16 v3, p1

    .line 1369
    .local v3, "it\\2":Lorg/lighttouch/android/PickedFile;
    const/4 v4, 0x0

    .line 605
    .local v4, "$i$a$-let-MainActivity$createDevice$1$romPath$1\\2\\605\\0":I
    :try_start_0
    new-instance v5, Ljava/io/File;

    const-string v6, "bootrom.bin"

    invoke-direct {v5, v9, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v5

    .line 1369
    .local v6, "f\\3":Ljava/io/File;
    const/4 v7, 0x0

    .line 605
    .local v7, "$i$a$-also-MainActivity$createDevice$1$romPath$1$1\\3\\605\\2":I
    invoke-virtual {v3}, Lorg/lighttouch/android/PickedFile;->getUri()Landroid/net/Uri;

    move-result-object v12

    const-string v13, "\u6b63\u5728\u590d\u5236\u5f15\u5bfc\u6587\u4ef6"

    invoke-direct {v1, v12, v6, v13}, Lorg/lighttouch/android/MainActivity;->copyWithProgress(Landroid/net/Uri;Ljava/io/File;Ljava/lang/String;)Ljava/lang/String;

    .end local v6    # "f\\3":Ljava/io/File;
    .end local v7    # "$i$a$-also-MainActivity$createDevice$1$romPath$1$1\\3\\605\\2":I
    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v3    # "it\\2":Lorg/lighttouch/android/PickedFile;
    .end local v4    # "$i$a$-let-MainActivity$createDevice$1$romPath$1\\2\\605\\0":I
    if-nez v5, :cond_1

    goto :goto_2

    .line 644
    :catchall_0
    move-exception v0

    move-object v7, v2

    :goto_0
    move-object/from16 v22, v9

    goto/16 :goto_18

    .line 638
    :catch_0
    move-exception v0

    move-object v7, v2

    :goto_1
    move-object/from16 v22, v9

    goto/16 :goto_16

    .line 605
    :cond_0
    :goto_2
    move-object v5, v11

    .line 606
    .local v5, "romPath":Ljava/lang/String;
    :cond_1
    const/4 v3, 0x0

    .local v3, "sha256":Ljava/lang/Object;
    move-object v3, v11

    .line 607
    :try_start_1
    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/PickedFile;->getFolder()Z

    move-result v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    if-eqz v4, :cond_2

    :try_start_2
    new-instance v4, Ljava/io/File;

    const-string v6, "base"

    invoke-direct {v4, v9, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v4

    .line 1369
    .local v6, "it\\4":Ljava/io/File;
    const/4 v7, 0x0

    .line 607
    .local v7, "$i$a$-also-MainActivity$createDevice$1$source$1\\4\\607\\0":I
    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/PickedFile;->getUri()Landroid/net/Uri;

    move-result-object v12

    new-instance v13, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda70;

    invoke-direct {v13, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda70;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-direct {v1, v12, v6, v13}, Lorg/lighttouch/android/MainActivity;->copyTree(Landroid/net/Uri;Ljava/io/File;Lkotlin/jvm/functions/Function2;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 608
    nop

    .line 607
    .end local v6    # "it\\4":Ljava/io/File;
    .end local v7    # "$i$a$-also-MainActivity$createDevice$1$source$1\\4\\607\\0":I
    move-object v7, v3

    goto :goto_3

    .line 609
    :cond_2
    :try_start_3
    new-instance v4, Ljava/io/File;

    const-string v6, "system.itbase"

    invoke-direct {v4, v9, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v4

    .line 1369
    .local v6, "it\\5":Ljava/io/File;
    const/4 v7, 0x0

    .line 609
    .local v7, "$i$a$-also-MainActivity$createDevice$1$source$2\\5\\609\\0":I
    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/PickedFile;->getUri()Landroid/net/Uri;

    move-result-object v12

    const-string v13, "\u6b63\u5728\u590d\u5236 iOS \u7cfb\u7edf"

    invoke-direct {v1, v12, v6, v13}, Lorg/lighttouch/android/MainActivity;->copyWithProgress(Landroid/net/Uri;Ljava/io/File;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v3, v12

    .end local v6    # "it\\5":Ljava/io/File;
    .end local v7    # "$i$a$-also-MainActivity$createDevice$1$source$2\\5\\609\\0":I
    move-object v7, v3

    .line 607
    .end local v3    # "sha256":Ljava/lang/Object;
    .local v7, "sha256":Ljava/lang/Object;
    :goto_3
    move-object v12, v4

    .line 610
    .local v12, "source":Ljava/io/File;
    iget-object v3, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda71;

    invoke-direct {v4, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda71;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 611
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    move-wide v13, v3

    .line 612
    .local v13, "started":J
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda72;

    invoke-direct {v3, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda72;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-direct {v1, v2, v3}, Lorg/lighttouch/android/MainActivity;->watchImport(Lorg/lighttouch/android/IEngine;Lkotlin/jvm/functions/Function2;)Lkotlin/jvm/functions/Function0;

    move-result-object v3
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    move-object v15, v3

    .line 613
    .local v15, "stopWatching":Lkotlin/jvm/functions/Function0;
    :try_start_4
    invoke-virtual {v12}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    const-string v6, ""

    invoke-interface/range {v2 .. v7}, Lorg/lighttouch/android/IEngine;->importDevice(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    move-object/from16 v16, v5

    move-object/from16 v17, v7

    move-object v7, v2

    .end local v5    # "romPath":Ljava/lang/String;
    .end local v7    # "sha256":Ljava/lang/Object;
    .local v16, "romPath":Ljava/lang/String;
    .local v17, "sha256":Ljava/lang/Object;
    :try_start_5
    invoke-interface {v15}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-object/from16 v18, v3

    .line 614
    .local v18, "result":Ljava/lang/String;
    const-string v2, "LightTouch"

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    sub-long/2addr v3, v13

    const v5, 0xf4240

    int-to-long v5, v5

    div-long/2addr v3, v5

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Device import took "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " \u6beb\u79d2"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 615
    invoke-static/range {v18 .. v18}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v2, v18

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v4, 0x1

    if-nez v2, :cond_3

    move v2, v4

    goto :goto_4

    :cond_3
    const/4 v2, 0x0

    :goto_4
    if-eqz v2, :cond_19

    .line 618
    iput-boolean v4, v10, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    .line 619
    invoke-interface {v7}, Lorg/lighttouch/android/IEngine;->records()[Landroid/os/Bundle;

    move-result-object v2

    const-string v5, "records(...)"

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, [Ljava/lang/Object;

    invoke-static {v2}, Lkotlin/collections/ArraysKt;->toList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    move-object/from16 v19, v2

    .line 620
    .local v19, "all":Ljava/util/List;
    move-object/from16 v2, v19

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$firstOrNull\\7":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1509
    .local v5, "$i$f$firstOrNull\\7\\620":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_5
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v20
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    const/16 v21, 0x0

    const-string v3, "id"

    if-eqz v20, :cond_5

    :try_start_6
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v20

    .local v20, "element\\7":Ljava/lang/Object;
    move-object/from16 v22, v20

    check-cast v22, Landroid/os/Bundle;

    move-object/from16 v23, v22

    .local v23, "it\\8":Landroid/os/Bundle;
    const/16 v22, 0x0

    .line 620
    .local v22, "$i$a$-firstOrNull-MainActivity$createDevice$1$created$1\\8\\1509\\0":I
    move/from16 v24, v4

    move-object/from16 v4, p5

    check-cast v4, Ljava/lang/Iterable;

    move-object/from16 v25, v2

    move-object/from16 v2, v23

    move/from16 v23, v5

    .end local v5    # "$i$f$firstOrNull\\7\\620":I
    .local v2, "it\\8":Landroid/os/Bundle;
    .local v23, "$i$f$firstOrNull\\7\\620":I
    .local v25, "$this$firstOrNull\\7":Ljava/lang/Iterable;
    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v4
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 1509
    .end local v2    # "it\\8":Landroid/os/Bundle;
    .end local v22    # "$i$a$-firstOrNull-MainActivity$createDevice$1$created$1\\8\\1509\\0":I
    if-nez v4, :cond_4

    goto :goto_6

    :cond_4
    move/from16 v5, v23

    move/from16 v4, v24

    move-object/from16 v2, v25

    goto :goto_5

    .line 644
    .end local v12    # "source":Ljava/io/File;
    .end local v13    # "started":J
    .end local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v16    # "romPath":Ljava/lang/String;
    .end local v17    # "sha256":Ljava/lang/Object;
    .end local v18    # "result":Ljava/lang/String;
    .end local v19    # "all":Ljava/util/List;
    .end local v20    # "element\\7":Ljava/lang/Object;
    .end local v23    # "$i$f$firstOrNull\\7\\620":I
    .end local v25    # "$this$firstOrNull\\7":Ljava/lang/Iterable;
    :catchall_1
    move-exception v0

    goto/16 :goto_0

    .line 638
    :catch_1
    move-exception v0

    goto/16 :goto_1

    .line 1510
    .local v2, "$this$firstOrNull\\7":Ljava/lang/Iterable;
    .restart local v5    # "$i$f$firstOrNull\\7\\620":I
    .restart local v12    # "source":Ljava/io/File;
    .restart local v13    # "started":J
    .restart local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v16    # "romPath":Ljava/lang/String;
    .restart local v17    # "sha256":Ljava/lang/Object;
    .restart local v18    # "result":Ljava/lang/String;
    .restart local v19    # "all":Ljava/util/List;
    :cond_5
    move-object/from16 v25, v2

    move/from16 v24, v4

    move/from16 v23, v5

    .end local v2    # "$this$firstOrNull\\7":Ljava/lang/Iterable;
    .end local v5    # "$i$f$firstOrNull\\7\\620":I
    .restart local v23    # "$i$f$firstOrNull\\7\\620":I
    .restart local v25    # "$this$firstOrNull\\7":Ljava/lang/Iterable;
    const/16 v20, 0x0

    .line 620
    .end local v23    # "$i$f$firstOrNull\\7\\620":I
    .end local v25    # "$this$firstOrNull\\7":Ljava/lang/Iterable;
    :goto_6
    :try_start_7
    check-cast v20, Landroid/os/Bundle;

    if-eqz v20, :cond_18

    move-object/from16 v2, v20

    .line 621
    .local v2, "created":Landroid/os/Bundle;
    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_6

    move-object v4, v11

    .line 623
    .local v4, "id":Ljava/lang/String;
    :cond_6
    sget-object v5, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    move-object v6, v1

    check-cast v6, Landroid/content/Context;

    invoke-virtual {v2, v8}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_2
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    if-nez v20, :cond_7

    move-object/from16 v22, v9

    move-object v9, v11

    goto :goto_7

    :cond_7
    move-object/from16 v22, v9

    move-object/from16 v9, v20

    .end local v9    # "staging":Ljava/io/File;
    .local v22, "staging":Ljava/io/File;
    :goto_7
    :try_start_8
    invoke-virtual {v2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    if-nez v20, :cond_8

    move-object/from16 v23, v11

    goto :goto_8

    :cond_8
    move-object/from16 v23, v11

    move-object/from16 v11, v20

    :goto_8
    invoke-virtual {v5, v6, v9, v11}, Lorg/lighttouch/android/GuestTools;->forDevice(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object v5

    move-object v9, v5

    .line 624
    .local v9, "tools":Ljava/io/File;
    if-eqz v9, :cond_a

    move-object v5, v9

    .line 1369
    .local v5, "it\\9":Ljava/io/File;
    const/4 v6, 0x0

    .line 624
    .local v6, "$i$a$-let-MainActivity$createDevice$1$toolsResult$1\\9\\624\\0":I
    iget-object v11, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    move-object/from16 v20, v5

    .end local v5    # "it\\9":Ljava/io/File;
    .local v20, "it\\9":Ljava/io/File;
    new-instance v5, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda74;

    invoke-direct {v5, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda74;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v11, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    invoke-virtual/range {v20 .. v20}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v7, v4, v5}, Lorg/lighttouch/android/IEngine;->setGuestPackage(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .end local v6    # "$i$a$-let-MainActivity$createDevice$1$toolsResult$1\\9\\624\\0":I
    .end local v20    # "it\\9":Ljava/io/File;
    if-nez v5, :cond_9

    goto :goto_9

    :cond_9
    move-object v6, v5

    goto :goto_a

    :cond_a
    :goto_9
    move-object/from16 v6, v23

    .line 625
    .local v6, "toolsResult":Ljava/lang/String;
    :goto_a
    move-object/from16 v5, p4

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v11
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    if-nez v11, :cond_b

    move/from16 v11, v24

    goto :goto_b

    :cond_b
    move/from16 v11, v21

    :goto_b
    move-object/from16 v20, v5

    const-string v5, "name"

    if-eqz v11, :cond_12

    .line 1369
    const/4 v11, 0x0

    .line 625
    .local v11, "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    :try_start_9
    invoke-virtual {v2, v8}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_c

    move-object/from16 v8, v23

    :cond_c
    invoke-virtual {v2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_d

    move-object/from16 v0, v23

    :cond_d
    move-object/from16 v23, v6

    .end local v6    # "toolsResult":Ljava/lang/String;
    .local v23, "toolsResult":Ljava/lang/String;
    iget-object v6, v1, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    .line 626
    move-object/from16 v20, v19

    check-cast v20, Ljava/lang/Iterable;

    .local v20, "$this$filter\\11":Ljava/lang/Iterable;
    const/16 v25, 0x0

    .line 1511
    .local v25, "$i$f$filter\\11\\626":I
    new-instance v26, Ljava/util/ArrayList;

    invoke-direct/range {v26 .. v26}, Ljava/util/ArrayList;-><init>()V

    check-cast v26, Ljava/util/Collection;

    move-object/from16 v27, v26

    .local v27, "destination\\12":Ljava/util/Collection;
    move-object/from16 v26, v20

    .local v26, "$this$filterTo\\12":Ljava/lang/Iterable;
    const/16 v28, 0x0

    .line 1512
    .local v28, "$i$f$filterTo\\12\\1511":I
    invoke-interface/range {v26 .. v26}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v29

    :goto_c
    invoke-interface/range {v29 .. v29}, Ljava/util/Iterator;->hasNext()Z

    move-result v30

    if-eqz v30, :cond_f

    invoke-interface/range {v29 .. v29}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v30

    move-object/from16 v31, v30

    .local v31, "element\\12":Ljava/lang/Object;
    move-object/from16 v30, v31

    check-cast v30, Landroid/os/Bundle;

    move-object/from16 v32, v30

    .local v32, "it\\13":Landroid/os/Bundle;
    const/16 v30, 0x0

    .line 626
    .local v30, "$i$a$-filter-MainActivity$createDevice$1$name$1$1\\13\\1512\\10":I
    move-object/from16 v33, v9

    move-object/from16 v9, v32

    move/from16 v32, v11

    .end local v11    # "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    .local v9, "it\\13":Landroid/os/Bundle;
    .local v32, "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    .local v33, "tools":Ljava/io/File;
    invoke-virtual {v9, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    .line 1512
    .end local v9    # "it\\13":Landroid/os/Bundle;
    .end local v30    # "$i$a$-filter-MainActivity$createDevice$1$name$1$1\\13\\1512\\10":I
    if-nez v11, :cond_e

    move-object/from16 v9, v27

    move-object/from16 v11, v31

    .end local v27    # "destination\\12":Ljava/util/Collection;
    .end local v31    # "element\\12":Ljava/lang/Object;
    .local v9, "destination\\12":Ljava/util/Collection;
    .local v11, "element\\12":Ljava/lang/Object;
    invoke-interface {v9, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v27, v9

    goto :goto_d

    .end local v9    # "destination\\12":Ljava/util/Collection;
    .end local v11    # "element\\12":Ljava/lang/Object;
    .restart local v27    # "destination\\12":Ljava/util/Collection;
    .restart local v31    # "element\\12":Ljava/lang/Object;
    :cond_e
    move-object/from16 v9, v27

    move-object/from16 v11, v31

    .end local v27    # "destination\\12":Ljava/util/Collection;
    .end local v31    # "element\\12":Ljava/lang/Object;
    .restart local v9    # "destination\\12":Ljava/util/Collection;
    .restart local v11    # "element\\12":Ljava/lang/Object;
    :goto_d
    move/from16 v11, v32

    move-object/from16 v9, v33

    goto :goto_c

    .line 1513
    .end local v32    # "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    .end local v33    # "tools":Ljava/io/File;
    .local v9, "tools":Ljava/io/File;
    .local v11, "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    .restart local v27    # "destination\\12":Ljava/util/Collection;
    :cond_f
    move-object/from16 v33, v9

    move/from16 v32, v11

    move-object/from16 v9, v27

    .end local v9    # "tools":Ljava/io/File;
    .end local v11    # "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    .end local v26    # "$this$filterTo\\12":Ljava/lang/Iterable;
    .end local v27    # "destination\\12":Ljava/util/Collection;
    .end local v28    # "$i$f$filterTo\\12\\1511":I
    .restart local v32    # "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    .restart local v33    # "tools":Ljava/io/File;
    move-object v3, v9

    check-cast v3, Ljava/util/List;

    .line 1511
    nop

    .end local v20    # "$this$filter\\11":Ljava/lang/Iterable;
    .end local v25    # "$i$f$filter\\11\\626":I
    check-cast v3, Ljava/lang/Iterable;

    .line 626
    nop

    .local v3, "$this$mapNotNull\\14":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1514
    .local v9, "$i$f$mapNotNull\\14\\626":I
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    check-cast v11, Ljava/util/Collection;

    .local v11, "destination\\15":Ljava/util/Collection;
    move-object/from16 v20, v3

    .local v20, "$this$mapNotNullTo\\15":Ljava/lang/Iterable;
    const/16 v25, 0x0

    .line 1522
    .local v25, "$i$f$mapNotNullTo\\15\\1514":I
    move-object/from16 v26, v20

    .local v26, "$this$forEach\\16":Ljava/lang/Iterable;
    const/16 v27, 0x0

    .line 1523
    .local v27, "$i$f$forEach\\16\\1522":I
    invoke-interface/range {v26 .. v26}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v28

    :goto_e
    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->hasNext()Z

    move-result v29

    if-eqz v29, :cond_11

    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v29

    .local v29, "element\\16":Ljava/lang/Object;
    move-object/from16 v30, v29

    .local v30, "element\\17":Ljava/lang/Object;
    const/16 v31, 0x0

    .line 1522
    .local v31, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\17\\1523\\15":I
    move-object/from16 v34, v30

    check-cast v34, Landroid/os/Bundle;

    move-object/from16 v35, v34

    .local v35, "it\\18":Landroid/os/Bundle;
    const/16 v34, 0x0

    .line 626
    .local v34, "$i$a$-mapNotNull-MainActivity$createDevice$1$name$1$2\\18\\1522\\10":I
    move-object/from16 v36, v3

    move-object/from16 v3, v35

    .end local v35    # "it\\18":Landroid/os/Bundle;
    .local v3, "it\\18":Landroid/os/Bundle;
    .local v36, "$this$mapNotNull\\14":Ljava/lang/Iterable;
    invoke-virtual {v3, v5}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v35

    .line 1522
    .end local v3    # "it\\18":Landroid/os/Bundle;
    .end local v34    # "$i$a$-mapNotNull-MainActivity$createDevice$1$name$1$2\\18\\1522\\10":I
    if-eqz v35, :cond_10

    move-object/from16 v3, v35

    .line 1524
    .local v3, "it\\17":Ljava/lang/Object;
    const/16 v34, 0x0

    .line 1522
    .local v34, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\19\\1524\\17":I
    invoke-interface {v11, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1523
    .end local v3    # "it\\17":Ljava/lang/Object;
    .end local v30    # "element\\17":Ljava/lang/Object;
    .end local v31    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\17\\1523\\15":I
    .end local v34    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\19\\1524\\17":I
    :cond_10
    move-object/from16 v3, v36

    .end local v29    # "element\\16":Ljava/lang/Object;
    goto :goto_e

    .line 1525
    .end local v36    # "$this$mapNotNull\\14":Ljava/lang/Iterable;
    .local v3, "$this$mapNotNull\\14":Ljava/lang/Iterable;
    :cond_11
    move-object/from16 v36, v3

    .line 1526
    .end local v3    # "$this$mapNotNull\\14":Ljava/lang/Iterable;
    .end local v26    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v27    # "$i$f$forEach\\16\\1522":I
    .restart local v36    # "$this$mapNotNull\\14":Ljava/lang/Iterable;
    nop

    .end local v11    # "destination\\15":Ljava/util/Collection;
    .end local v20    # "$this$mapNotNullTo\\15":Ljava/lang/Iterable;
    .end local v25    # "$i$f$mapNotNullTo\\15\\1514":I
    move-object v3, v11

    check-cast v3, Ljava/util/List;

    .line 1514
    nop

    .end local v9    # "$i$f$mapNotNull\\14\\626":I
    .end local v36    # "$this$mapNotNull\\14":Ljava/lang/Iterable;
    check-cast v3, Ljava/util/Collection;

    .line 625
    invoke-static {v8, v0, v6, v3}, Lorg/lighttouch/android/DevicesKt;->defaultDeviceName(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Collection;)Ljava/lang/String;

    move-result-object v0

    .line 626
    nop

    .line 625
    .end local v32    # "$i$a$-ifEmpty-MainActivity$createDevice$1$name$1\\10\\625\\0":I
    goto :goto_f

    .end local v23    # "toolsResult":Ljava/lang/String;
    .end local v33    # "tools":Ljava/io/File;
    .restart local v6    # "toolsResult":Ljava/lang/String;
    .local v9, "tools":Ljava/io/File;
    :cond_12
    move-object/from16 v23, v6

    move-object/from16 v33, v9

    .end local v6    # "toolsResult":Ljava/lang/String;
    .end local v9    # "tools":Ljava/io/File;
    .restart local v23    # "toolsResult":Ljava/lang/String;
    .restart local v33    # "tools":Ljava/io/File;
    move-object/from16 v0, v20

    :goto_f
    check-cast v0, Ljava/lang/String;

    .line 627
    .local v0, "name":Ljava/lang/String;
    invoke-interface {v7, v4, v0}, Lorg/lighttouch/android/IEngine;->rename(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 628
    .local v3, "renamed":Ljava/lang/String;
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v6, v3

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-nez v6, :cond_13

    move/from16 v6, v24

    goto :goto_10

    :cond_13
    move/from16 v6, v21

    :goto_10
    if-eqz v6, :cond_14

    :goto_11
    goto :goto_12

    :cond_14
    invoke-virtual {v2, v5}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_15

    goto :goto_11

    :goto_12
    move-object v5, v0

    .line 630
    .local v5, "shown":Ljava/lang/String;
    :cond_15
    const/4 v6, 0x4

    new-array v6, v6, [Ljava/lang/String;

    const-string v8, "running"

    aput-object v8, v6, v21

    const-string v8, "paused"

    aput-object v8, v6, v24

    const-string v8, "starting"

    const/4 v9, 0x2

    aput-object v8, v6, v9

    const-string v8, "stopping"

    const/4 v9, 0x3

    aput-object v8, v6, v9

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v6, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_17

    invoke-interface {v7, v4}, Lorg/lighttouch/android/IEngine;->select(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v8, "select(...)"

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-nez v6, :cond_16

    move/from16 v6, v24

    goto :goto_13

    :cond_16
    move/from16 v6, v21

    :goto_13
    if-eqz v6, :cond_17

    move/from16 v21, v24

    .line 631
    .local v21, "selected":Z
    :cond_17
    iget-object v8, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    move-object v6, v4

    move-object v4, v3

    move-object v3, v5

    move-object v5, v0

    .end local v0    # "name":Ljava/lang/String;
    .local v3, "shown":Ljava/lang/String;
    .local v4, "renamed":Ljava/lang/String;
    .local v5, "name":Ljava/lang/String;
    .local v6, "id":Ljava/lang/String;
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda75;

    move-object/from16 v20, v2

    move-object v9, v6

    move/from16 v2, v21

    move-object/from16 v6, v23

    .end local v21    # "selected":Z
    .end local v23    # "toolsResult":Ljava/lang/String;
    .local v2, "selected":Z
    .local v6, "toolsResult":Ljava/lang/String;
    .local v9, "id":Ljava/lang/String;
    .local v20, "created":Landroid/os/Bundle;
    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda75;-><init>(Lorg/lighttouch/android/MainActivity;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v8, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_3
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 644
    .end local v2    # "selected":Z
    .end local v3    # "shown":Ljava/lang/String;
    .end local v4    # "renamed":Ljava/lang/String;
    .end local v5    # "name":Ljava/lang/String;
    .end local v6    # "toolsResult":Ljava/lang/String;
    .end local v9    # "id":Ljava/lang/String;
    .end local v12    # "source":Ljava/io/File;
    .end local v13    # "started":J
    .end local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v16    # "romPath":Ljava/lang/String;
    .end local v17    # "sha256":Ljava/lang/Object;
    .end local v18    # "result":Ljava/lang/String;
    .end local v19    # "all":Ljava/util/List;
    .end local v20    # "created":Landroid/os/Bundle;
    .end local v33    # "tools":Ljava/io/File;
    invoke-static/range {v22 .. v22}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda76;

    invoke-direct {v2, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda76;-><init>(Lorg/lighttouch/android/MainActivity;)V

    goto :goto_17

    .line 620
    .end local v22    # "staging":Ljava/io/File;
    .local v9, "staging":Ljava/io/File;
    .restart local v12    # "source":Ljava/io/File;
    .restart local v13    # "started":J
    .restart local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v16    # "romPath":Ljava/lang/String;
    .restart local v17    # "sha256":Ljava/lang/Object;
    .restart local v18    # "result":Ljava/lang/String;
    .restart local v19    # "all":Ljava/util/List;
    :cond_18
    move-object/from16 v22, v9

    .end local v9    # "staging":Ljava/io/File;
    .restart local v22    # "staging":Ljava/io/File;
    :try_start_a
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "\u65b0\u8bbe\u5907\u672a\u51fa\u73b0\u5728\u8bbe\u5907\u5e93\u4e2d"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v10    # "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v22    # "staging":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/PickedFile;
    .end local p2    # "$system":Lorg/lighttouch/android/PickedFile;
    .end local p3    # "$worker":Lorg/lighttouch/android/IEngine;
    .end local p4    # "$requested":Ljava/lang/String;
    .end local p5    # "$before":Ljava/util/Set;
    throw v0

    .line 1369
    .end local v19    # "all":Ljava/util/List;
    .restart local v9    # "staging":Ljava/io/File;
    .restart local v10    # "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/PickedFile;
    .restart local p2    # "$system":Lorg/lighttouch/android/PickedFile;
    .restart local p3    # "$worker":Lorg/lighttouch/android/IEngine;
    .restart local p4    # "$requested":Ljava/lang/String;
    .restart local p5    # "$before":Ljava/util/Set;
    :cond_19
    move-object/from16 v22, v9

    .end local v9    # "staging":Ljava/io/File;
    .restart local v22    # "staging":Ljava/io/File;
    const/4 v0, 0x0

    .line 615
    .local v0, "$i$a$-require-MainActivity$createDevice$1$2\\6\\615\\0":I
    nop

    .end local v0    # "$i$a$-require-MainActivity$createDevice$1$2\\6\\615\\0":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v10    # "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v22    # "staging":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/PickedFile;
    .end local p2    # "$system":Lorg/lighttouch/android/PickedFile;
    .end local p3    # "$worker":Lorg/lighttouch/android/IEngine;
    .end local p4    # "$requested":Ljava/lang/String;
    .end local p5    # "$before":Ljava/util/Set;
    throw v0

    .line 644
    .end local v12    # "source":Ljava/io/File;
    .end local v13    # "started":J
    .end local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v16    # "romPath":Ljava/lang/String;
    .end local v17    # "sha256":Ljava/lang/Object;
    .end local v18    # "result":Ljava/lang/String;
    .restart local v9    # "staging":Ljava/io/File;
    .restart local v10    # "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/PickedFile;
    .restart local p2    # "$system":Lorg/lighttouch/android/PickedFile;
    .restart local p3    # "$worker":Lorg/lighttouch/android/IEngine;
    .restart local p4    # "$requested":Ljava/lang/String;
    .restart local p5    # "$before":Ljava/util/Set;
    :catchall_2
    move-exception v0

    goto :goto_14

    .line 638
    :catch_2
    move-exception v0

    goto :goto_15

    .line 613
    .local v5, "romPath":Ljava/lang/String;
    .restart local v7    # "sha256":Ljava/lang/Object;
    .restart local v12    # "source":Ljava/io/File;
    .restart local v13    # "started":J
    .restart local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    :catchall_3
    move-exception v0

    move-object/from16 v16, v5

    move-object/from16 v17, v7

    move-object/from16 v22, v9

    move-object v7, v2

    .end local v5    # "romPath":Ljava/lang/String;
    .end local v7    # "sha256":Ljava/lang/Object;
    .end local v9    # "staging":Ljava/io/File;
    .restart local v16    # "romPath":Ljava/lang/String;
    .restart local v17    # "sha256":Ljava/lang/Object;
    .restart local v22    # "staging":Ljava/io/File;
    invoke-interface {v15}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .end local v10    # "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v22    # "staging":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/PickedFile;
    .end local p2    # "$system":Lorg/lighttouch/android/PickedFile;
    .end local p3    # "$worker":Lorg/lighttouch/android/IEngine;
    .end local p4    # "$requested":Ljava/lang/String;
    .end local p5    # "$before":Ljava/util/Set;
    throw v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_3
    .catchall {:try_start_a .. :try_end_a} :catchall_5

    .line 638
    .end local v12    # "source":Ljava/io/File;
    .end local v13    # "started":J
    .end local v15    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v16    # "romPath":Ljava/lang/String;
    .end local v17    # "sha256":Ljava/lang/Object;
    .restart local v10    # "imported":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v22    # "staging":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/PickedFile;
    .restart local p2    # "$system":Lorg/lighttouch/android/PickedFile;
    .restart local p3    # "$worker":Lorg/lighttouch/android/IEngine;
    .restart local p4    # "$requested":Ljava/lang/String;
    .restart local p5    # "$before":Ljava/util/Set;
    :catch_3
    move-exception v0

    goto :goto_16

    .line 644
    .end local v22    # "staging":Ljava/io/File;
    .restart local v9    # "staging":Ljava/io/File;
    :catchall_4
    move-exception v0

    move-object v7, v2

    :goto_14
    move-object/from16 v22, v9

    .end local v9    # "staging":Ljava/io/File;
    .restart local v22    # "staging":Ljava/io/File;
    goto :goto_18

    .line 638
    .end local v22    # "staging":Ljava/io/File;
    .restart local v9    # "staging":Ljava/io/File;
    :catch_4
    move-exception v0

    move-object v7, v2

    :goto_15
    move-object/from16 v22, v9

    .line 639
    .end local v9    # "staging":Ljava/io/File;
    .local v0, "e":Ljava/lang/Exception;
    .restart local v22    # "staging":Ljava/io/File;
    :goto_16
    :try_start_b
    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda77;

    invoke-direct {v3, v10, v1, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda77;-><init>(Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 644
    nop

    .end local v0    # "e":Ljava/lang/Exception;
    invoke-static/range {v22 .. v22}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    iget-object v0, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda76;

    invoke-direct {v2, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda76;-><init>(Lorg/lighttouch/android/MainActivity;)V

    :goto_17
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 645
    return-void

    .line 644
    :catchall_5
    move-exception v0

    :goto_18
    invoke-static/range {v22 .. v22}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda76;

    invoke-direct {v3, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda76;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    throw v0
.end method

.method private static final createDevice$lambda$108$lambda$101$lambda$100(Lorg/lighttouch/android/MainActivity;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 624
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-string v1, "\u6b63\u5728\u6dfb\u52a0\u5ba2\u6237\u673a\u5de5\u5177\u2026"

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setPhase(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const/high16 v1, -0x40800000    # -1.0f

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setProgress(F)V

    return-void
.end method

.method private static final createDevice$lambda$108$lambda$105(Lorg/lighttouch/android/MainActivity;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$selected"    # Z
    .param p2, "$shown"    # Ljava/lang/String;
    .param p3, "$renamed"    # Ljava/lang/String;
    .param p4, "$name"    # Ljava/lang/String;
    .param p5, "$toolsResult"    # Ljava/lang/String;

    .line 632
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    .line 633
    if-eqz p1, :cond_0

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v2, p2}, Lorg/lighttouch/android/SetupState;->setCreated(Ljava/lang/String;)V

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    sget-object v3, Lorg/lighttouch/android/SetupStep;->DONE:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    goto :goto_0

    .line 634
    :cond_0
    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Added "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "; stop the running device to switch to it"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    .line 635
    :goto_0
    invoke-static {p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v2, p3

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_1

    move v2, v1

    goto :goto_1

    :cond_1
    move v2, v0

    :goto_1
    if-eqz v2, :cond_2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Added the device, but could not name it \""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    goto :goto_2

    .line 636
    :cond_2
    move-object v2, p5

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_3

    move v0, v1

    :cond_3
    if-eqz v0, :cond_4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Added the device, but could not add LightTouch\'s guest tools: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 637
    :cond_4
    :goto_2
    return-void
.end method

.method private static final createDevice$lambda$108$lambda$106(Lkotlin/jvm/internal/Ref$BooleanRef;Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 4
    .param p0, "$imported"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "$e"    # Ljava/lang/Exception;

    .line 641
    iget-boolean v0, p0, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    invoke-virtual {p2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Added the device, but could not finish setting it up: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p1, v1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v1, v2, v0}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    goto :goto_0

    .line 642
    :cond_0
    iget-object v0, p1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {p2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1

    const-string v1, "\u65e0\u6cd5\u521b\u5efa\u8bbe\u5907"

    :cond_1
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setError(Ljava/lang/String;)V

    iget-object v0, p1, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    sget-object v1, Lorg/lighttouch/android/SetupStep;->FILES:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    .line 643
    :goto_0
    return-void
.end method

.method private static final createDevice$lambda$108$lambda$107(Lorg/lighttouch/android/MainActivity;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 644
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    return-void
.end method

.method private static final createDevice$lambda$108$lambda$94$lambda$93(Lorg/lighttouch/android/MainActivity;JJ)Lkotlin/Unit;
    .locals 7
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "done"    # J
    .param p3, "total"    # J

    .line 608
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda3;

    move-object v2, p0

    move-wide v5, p1

    move-wide v3, p3

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "done":J
    .end local p3    # "total":J
    .local v2, "this$0":Lorg/lighttouch/android/MainActivity;
    .local v3, "total":J
    .local v5, "done":J
    invoke-direct/range {v1 .. v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/MainActivity;JJ)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final createDevice$lambda$108$lambda$94$lambda$93$lambda$92(Lorg/lighttouch/android/MainActivity;JJ)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$total"    # J
    .param p3, "$done"    # J

    .line 608
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-string v1, "\u6b63\u5728\u590d\u5236 iOS \u7cfb\u7edf\u2026"

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setPhase(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-wide/16 v1, 0x0

    cmp-long v1, p1, v1

    if-lez v1, :cond_0

    long-to-float v1, p3

    long-to-float v2, p1

    div-float/2addr v1, v2

    goto :goto_0

    :cond_0
    const/high16 v1, -0x40800000    # -1.0f

    :goto_0
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setProgress(F)V

    return-void
.end method

.method private static final createDevice$lambda$108$lambda$96(Lorg/lighttouch/android/MainActivity;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 610
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const-string v1, "\u6b63\u5728\u8bbe\u7f6e iOS \u7cfb\u7edf\u2026"

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setPhase(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    const/high16 v1, -0x40800000    # -1.0f

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setProgress(F)V

    return-void
.end method

.method private static final createDevice$lambda$108$lambda$97(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;F)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "text"    # Ljava/lang/String;
    .param p2, "fraction"    # F

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 612
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/SetupState;->setPhase(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/SetupState;->setProgress(F)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final deleteDevice$lambda$50(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$id"    # Ljava/lang/String;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 482
    :try_start_0
    invoke-interface {p0, p1}, Lorg/lighttouch/android/IEngine;->remove(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, "\u5220\u9664\u5931\u8d25"

    :cond_0
    move-object v0, v1

    .line 483
    .local v0, "result":Ljava/lang/String;
    :goto_0
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda113;

    invoke-direct {v2, p2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda113;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 484
    return-void
.end method

.method private static final deleteDevice$lambda$50$lambda$49(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$result"    # Ljava/lang/String;

    .line 483
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    move v0, v2

    :cond_0
    if-eqz v0, :cond_1

    const-string v0, "\u8bbe\u5907\u5df2\u5220\u9664"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    goto :goto_0

    :cond_1
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    :goto_0
    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->refreshDevices(Z)V

    return-void
.end method

.method private final displayName(Landroid/net/Uri;)Ljava/lang/String;
    .locals 1
    .param p1, "uri"    # Landroid/net/Uri;

    .line 527
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-static {v0, p1}, Landroidx/documentfile/provider/DocumentFile;->fromSingleUri(Landroid/content/Context;Landroid/net/Uri;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "file"

    :cond_1
    return-object v0
.end method

.method private final downloadBootrom()V
    .locals 4

    .line 918
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getBootrom()Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 919
    .local v0, "rom":Lorg/lighttouch/android/Bootrom;
    :cond_0
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setRomChecking(Z)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v2, ""

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setRomError(Ljava/lang/String;)V

    .line 920
    new-instance v1, Ljava/lang/Thread;

    .line 926
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda65;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda65;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V

    .line 920
    const-string v3, "bootrom-download"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 926
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 927
    return-void
.end method

.method private static final downloadBootrom$lambda$183(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V
    .locals 5
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$rom"    # Lorg/lighttouch/android/Bootrom;

    .line 921
    nop

    .line 922
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {p1}, Lorg/lighttouch/android/Bootrom;->name()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "toLowerCase(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "prepare-bootrom-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".bin"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 923
    .local v0, "target":Ljava/io/File;
    invoke-virtual {p1, v0}, Lorg/lighttouch/android/Bootrom;->fetch(Ljava/io/File;)V

    .line 924
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda87;

    invoke-direct {v2, p0, v0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda87;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "target":Ljava/io/File;
    goto :goto_0

    .line 925
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda88;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda88;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 926
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method private static final downloadBootrom$lambda$183$lambda$181(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$target"    # Ljava/io/File;
    .param p2, "$rom"    # Lorg/lighttouch/android/Bootrom;

    .line 924
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomPath(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/PrepareState;->setRomFor(Lorg/lighttouch/android/Bootrom;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p2}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Downloaded \u00b7 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomLabel(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomChecking(Z)V

    return-void
.end method

.method private static final downloadBootrom$lambda$183$lambda$182(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 925
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Could not download the boot file: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomError(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomChecking(Z)V

    return-void
.end method

.method private final downloadIpsw()V
    .locals 4

    .line 882
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 883
    .local v0, "chosen":Lorg/lighttouch/android/CatalogFirmware;
    :cond_0
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v2, ""

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setIpswError(Ljava/lang/String;)V

    .line 884
    sget-object v1, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda29;

    invoke-direct {v3, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda29;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;)V

    invoke-virtual {v1, v2, v0, v3}, Lorg/lighttouch/android/IpswDownload;->start(Landroid/content/Context;Lorg/lighttouch/android/CatalogFirmware;Lkotlin/jvm/functions/Function2;)V

    .line 885
    return-void
.end method

.method private static final downloadIpsw$lambda$169(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Ljava/io/File;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$chosen"    # Lorg/lighttouch/android/CatalogFirmware;
    .param p2, "file"    # Ljava/io/File;

    const-string v0, "<unused var>"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 884
    iget-object p3, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda115;

    invoke-direct {v0, p2, p0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda115;-><init>(Ljava/io/File;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;)V

    invoke-virtual {p3, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object p3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p3
.end method

.method private static final downloadIpsw$lambda$169$lambda$168(Ljava/io/File;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;)V
    .locals 2
    .param p0, "$file"    # Ljava/io/File;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "$chosen"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 884
    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    const-string v1, "getAbsolutePath(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p1, v0, v1}, Lorg/lighttouch/android/MainActivity;->rememberIpsw(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private final findBootrom(Ljava/lang/String;)V
    .locals 16
    .param p1, "board"    # Ljava/lang/String;

    .line 724
    move-object/from16 v0, p0

    sget-object v1, Lorg/lighttouch/android/Bootrom;->Companion:Lorg/lighttouch/android/Bootrom$Companion;

    move-object/from16 v2, p1

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/Bootrom$Companion;->forBoard(Ljava/lang/String;)Lorg/lighttouch/android/Bootrom;

    move-result-object v1

    if-nez v1, :cond_0

    return-void

    .line 725
    .local v1, "rom":Lorg/lighttouch/android/Bootrom;
    :cond_0
    iget-object v3, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3}, Lorg/lighttouch/android/PrepareState;->getRomFor()Lorg/lighttouch/android/Bootrom;

    move-result-object v3

    const/4 v5, 0x0

    if-ne v3, v1, :cond_2

    iget-object v3, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3}, Lorg/lighttouch/android/PrepareState;->getRomPath()Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    move v3, v5

    :goto_0
    if-eqz v3, :cond_2

    new-instance v3, Ljava/io/File;

    iget-object v6, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v6}, Lorg/lighttouch/android/PrepareState;->getRomPath()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v3, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v3

    if-eqz v3, :cond_2

    return-void

    .line 726
    :cond_2
    iget-object v3, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v6, ""

    invoke-virtual {v3, v6}, Lorg/lighttouch/android/PrepareState;->setRomPath(Ljava/lang/String;)V

    iget-object v3, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const/4 v7, 0x0

    invoke-virtual {v3, v7}, Lorg/lighttouch/android/PrepareState;->setRomFor(Lorg/lighttouch/android/Bootrom;)V

    iget-object v3, v0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3, v6}, Lorg/lighttouch/android/PrepareState;->setRomLabel(Ljava/lang/String;)V

    .line 727
    invoke-direct {v0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$filter\\1":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1409
    .local v7, "$i$f$filter\\1\\727":I
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\2":Ljava/util/Collection;
    move-object v9, v3

    .local v9, "$this$filterTo\\2":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1410
    .local v10, "$i$f$filterTo\\2\\1409":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_3
    :goto_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_6

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\2":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Landroid/os/Bundle;

    .local v13, "it\\3":Landroid/os/Bundle;
    const/4 v14, 0x0

    .line 727
    .local v14, "$i$a$-filter-MainActivity$findBootrom$candidates$1\\3\\1410\\0":I
    sget-object v15, Lorg/lighttouch/android/Bootrom;->Companion:Lorg/lighttouch/android/Bootrom$Companion;

    const-string v4, "board"

    invoke-virtual {v13, v4}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_4

    move-object v4, v6

    :cond_4
    invoke-virtual {v15, v4}, Lorg/lighttouch/android/Bootrom$Companion;->forBoard(Ljava/lang/String;)Lorg/lighttouch/android/Bootrom;

    move-result-object v4

    if-ne v4, v1, :cond_5

    const-string v4, "bootromAvailable"

    invoke-virtual {v13, v4}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5

    const/4 v4, 0x1

    goto :goto_2

    :cond_5
    move v4, v5

    .line 1410
    .end local v13    # "it\\3":Landroid/os/Bundle;
    .end local v14    # "$i$a$-filter-MainActivity$findBootrom$candidates$1\\3\\1410\\0":I
    :goto_2
    if-eqz v4, :cond_3

    invoke-interface {v8, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 1411
    .end local v12    # "element\\2":Ljava/lang/Object;
    :cond_6
    nop

    .end local v8    # "destination\\2":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\2":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterTo\\2\\1409":I
    move-object v4, v8

    check-cast v4, Ljava/util/List;

    .line 1409
    nop

    .end local v3    # "$this$filter\\1":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filter\\1\\727":I
    check-cast v4, Ljava/lang/Iterable;

    .line 728
    nop

    .local v4, "$this$map\\4":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1412
    .local v3, "$i$f$map\\4\\728":I
    new-instance v5, Ljava/util/ArrayList;

    const/16 v6, 0xa

    invoke-static {v4, v6}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v6

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\5":Ljava/util/Collection;
    move-object v6, v4

    .local v6, "$this$mapTo\\5":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1413
    .local v7, "$i$f$mapTo\\5\\1412":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_3
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_7

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 1414
    .local v9, "item\\5":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Landroid/os/Bundle;

    .local v10, "it\\6":Landroid/os/Bundle;
    const/4 v11, 0x0

    .line 728
    .local v11, "$i$a$-map-MainActivity$findBootrom$candidates$2\\6\\1414\\0":I
    new-instance v12, Ljava/io/File;

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v13

    const-string v14, "id"

    invoke-virtual {v10, v14}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "library/records/"

    invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v14, "/assets/bootrom.bin"

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v12, v13, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const-string v2, "name"

    invoke-virtual {v10, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "Reusing the one from "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v12, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    .line 1414
    .end local v10    # "it\\6":Landroid/os/Bundle;
    .end local v11    # "$i$a$-map-MainActivity$findBootrom$candidates$2\\6\\1414\\0":I
    invoke-interface {v5, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, p1

    goto :goto_3

    .line 1415
    .end local v9    # "item\\5":Ljava/lang/Object;
    :cond_7
    nop

    .end local v5    # "destination\\5":Ljava/util/Collection;
    .end local v6    # "$this$mapTo\\5":Ljava/lang/Iterable;
    .end local v7    # "$i$f$mapTo\\5\\1412":I
    move-object v2, v5

    check-cast v2, Ljava/util/List;

    .line 1412
    nop

    .end local v3    # "$i$f$map\\4\\728":I
    .end local v4    # "$this$map\\4":Ljava/lang/Iterable;
    check-cast v2, Ljava/util/Collection;

    .line 729
    new-instance v3, Ljava/io/File;

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const-string v5, "bootrom.bin"

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const-string v4, "\u590d\u7528\u5df2\u4fdd\u5b58\u7684\u6587\u4ef6"

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .line 727
    invoke-static {v2, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    .line 730
    .local v2, "candidates":Ljava/util/List;
    new-instance v3, Ljava/lang/Thread;

    .line 738
    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda78;

    invoke-direct {v4, v2, v0, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda78;-><init>(Ljava/util/List;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V

    .line 730
    const-string v5, "find-bootrom"

    invoke-direct {v3, v4, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 738
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 739
    return-void
.end method

.method private static final findBootrom$lambda$124(Ljava/util/List;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;)V
    .locals 10
    .param p0, "$candidates"    # Ljava/util/List;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "$rom"    # Lorg/lighttouch/android/Bootrom;

    .line 731
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1529
    .local v1, "$i$f$firstOrNull\\1\\731":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lkotlin/Pair;

    const/4 v5, 0x0

    .local v5, "$i$a$-firstOrNull-MainActivity$findBootrom$1$found$1\\2\\1529\\0":I
    invoke-virtual {v4}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/io/File;

    .line 731
    .local v4, "file\\2":Ljava/io/File;
    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-virtual {v4}, Ljava/io/File;->length()J

    move-result-wide v6

    const-wide/32 v8, 0x100000

    cmp-long v6, v6, v8

    if-gtz v6, :cond_1

    invoke-static {v4}, Lkotlin/io/FilesKt;->readBytes(Ljava/io/File;)[B

    move-result-object v6

    invoke-virtual {p2, v6}, Lorg/lighttouch/android/Bootrom;->matches([B)Z

    move-result v6

    if-eqz v6, :cond_1

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    .line 1529
    .end local v4    # "file\\2":Ljava/io/File;
    .end local v5    # "$i$a$-firstOrNull-MainActivity$findBootrom$1$found$1\\2\\1529\\0":I
    :goto_0
    if-eqz v6, :cond_0

    goto :goto_1

    .line 1530
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_2
    const/4 v3, 0x0

    .line 731
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\731":I
    :goto_1
    move-object v0, v3

    check-cast v0, Lkotlin/Pair;

    .line 732
    .local v0, "found":Lkotlin/Pair;
    if-eqz v0, :cond_3

    iget-object v1, p1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda51;

    invoke-direct {v2, p1, p2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda51;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Lkotlin/Pair;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 738
    :cond_3
    return-void
.end method

.method private static final findBootrom$lambda$124$lambda$123(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Lkotlin/Pair;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$rom"    # Lorg/lighttouch/android/Bootrom;
    .param p2, "$found"    # Lkotlin/Pair;

    .line 733
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 1369
    .local v0, "it\\1":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v1, 0x0

    .line 733
    .local v1, "$i$a$-let-MainActivity$findBootrom$1$1$1\\1\\733\\0":I
    sget-object v2, Lorg/lighttouch/android/Bootrom;->Companion:Lorg/lighttouch/android/Bootrom$Companion;

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/Bootrom$Companion;->forBoard(Ljava/lang/String;)Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    .end local v0    # "it\\1":Lorg/lighttouch/android/CatalogFirmware;
    .end local v1    # "$i$a$-let-MainActivity$findBootrom$1$1$1\\1\\733\\0":I
    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-ne v0, p1, :cond_1

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getRomFor()Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    if-nez v0, :cond_1

    .line 734
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p2}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomPath(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/PrepareState;->setRomFor(Lorg/lighttouch/android/Bootrom;)V

    .line 735
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p2}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " ("

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "). It is the same for every iOS version."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomLabel(Ljava/lang/String;)V

    .line 737
    :cond_1
    return-void
.end method

.method private final getAppServicesError()Ljava/lang/String;
    .locals 3

    .line 81
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->appServicesError$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1324
    .local v2, "$i$f$getValue\\1\\81":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\81":I
    check-cast v0, Ljava/lang/String;

    .line 81
    return-object v0
.end method

.method private final getBase()Lorg/lighttouch/android/Screen;
    .locals 3

    .line 109
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->base$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1342
    .local v2, "$i$f$getValue\\1\\109":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\109":I
    check-cast v0, Lorg/lighttouch/android/Screen;

    .line 109
    return-object v0
.end method

.method private final getCatalogVersion()I
    .locals 3

    .line 95
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->catalogVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    check-cast v0, Landroidx/compose/runtime/IntState;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/IntState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1327
    .local v2, "$i$f$getValue\\1\\95":I
    invoke-interface {v0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result v0

    .line 95
    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/IntState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\95":I
    return v0
.end method

.method private final getDetail()Ljava/lang/String;
    .locals 3

    .line 39
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->detail$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1273
    .local v2, "$i$f$getValue\\1\\39":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\39":I
    check-cast v0, Ljava/lang/String;

    .line 39
    return-object v0
.end method

.method private final getDetailsDevice()Lorg/lighttouch/android/DeviceSummary;
    .locals 3

    .line 79
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->detailsDevice$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1318
    .local v2, "$i$f$getValue\\1\\79":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\79":I
    check-cast v0, Lorg/lighttouch/android/DeviceSummary;

    .line 79
    return-object v0
.end method

.method private final getDevicesOpen()Z
    .locals 3

    .line 78
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->devicesOpen$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1315
    .local v2, "$i$f$getValue\\1\\78":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\78":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 78
    return v0
.end method

.method private final getEngine()Lorg/lighttouch/android/IEngine;
    .locals 3

    .line 36
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->engine$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1267
    .local v2, "$i$f$getValue\\1\\36":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\36":I
    check-cast v0, Lorg/lighttouch/android/IEngine;

    .line 36
    return-object v0
.end method

.method private final getFirmwareRestarting()Z
    .locals 3

    .line 125
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareRestarting$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1363
    .local v2, "$i$f$getValue\\1\\125":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\125":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 125
    return v0
.end method

.method private final getHitchData()Lorg/lighttouch/android/HitchData;
    .locals 3

    .line 113
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchData$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1348
    .local v2, "$i$f$getValue\\1\\113":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\113":I
    check-cast v0, Lorg/lighttouch/android/HitchData;

    .line 113
    return-object v0
.end method

.method private final getHitchError()Ljava/lang/String;
    .locals 3

    .line 114
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchError$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1351
    .local v2, "$i$f$getValue\\1\\114":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\114":I
    check-cast v0, Ljava/lang/String;

    .line 114
    return-object v0
.end method

.method private final getHitchNotice()Ljava/lang/String;
    .locals 3

    .line 116
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchNotice$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1357
    .local v2, "$i$f$getValue\\1\\116":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\116":I
    check-cast v0, Ljava/lang/String;

    .line 116
    return-object v0
.end method

.method private final getHitchReport()Landroid/net/Uri;
    .locals 3

    .line 117
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchReport$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1360
    .local v2, "$i$f$getValue\\1\\117":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\117":I
    check-cast v0, Landroid/net/Uri;

    .line 117
    return-object v0
.end method

.method private final getHitchSaving()Z
    .locals 3

    .line 115
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchSaving$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1354
    .local v2, "$i$f$getValue\\1\\115":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\115":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 115
    return v0
.end method

.method private final getInstaller()Lorg/lighttouch/android/StoreInstaller;
    .locals 1

    .line 82
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->installer$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/StoreInstaller;

    return-object v0
.end method

.method private final getLicensesOpen()Z
    .locals 3

    .line 77
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->licensesOpen$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1312
    .local v2, "$i$f$getValue\\1\\77":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\77":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 77
    return v0
.end method

.method private final getMuxSocket()Ljava/lang/String;
    .locals 3

    .line 80
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->muxSocket$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1321
    .local v2, "$i$f$getValue\\1\\80":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\80":I
    check-cast v0, Ljava/lang/String;

    .line 80
    return-object v0
.end method

.method private final getNotice()Ljava/lang/String;
    .locals 3

    .line 57
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->notice$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1291
    .local v2, "$i$f$getValue\\1\\57":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\57":I
    check-cast v0, Ljava/lang/String;

    .line 57
    return-object v0
.end method

.method private final getOverlay()Lorg/lighttouch/android/Screen;
    .locals 3

    .line 111
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->overlay$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1345
    .local v2, "$i$f$getValue\\1\\111":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\111":I
    check-cast v0, Lorg/lighttouch/android/Screen;

    .line 111
    return-object v0
.end method

.method private final getPreparationOpen()Z
    .locals 3

    .line 130
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->preparationOpen$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1366
    .local v2, "$i$f$getValue\\1\\130":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\130":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 130
    return v0
.end method

.method private final getRecords()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/os/Bundle;",
            ">;"
        }
    .end annotation

    .line 98
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->records$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1330
    .local v2, "$i$f$getValue\\1\\98":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\98":I
    check-cast v0, Ljava/util/List;

    .line 98
    return-object v0
.end method

.method private final getRecordsLoaded()Z
    .locals 3

    .line 99
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->recordsLoaded$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1333
    .local v2, "$i$f$getValue\\1\\99":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\99":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 99
    return v0
.end method

.method private final getSensorThread()Landroid/os/HandlerThread;
    .locals 1

    .line 1166
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->sensorThread$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/HandlerThread;

    return-object v0
.end method

.method private final getSensors()Landroid/hardware/SensorManager;
    .locals 1

    .line 187
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->sensors$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/SensorManager;

    return-object v0
.end method

.method private final getStore()Lorg/lighttouch/android/StoreModel;
    .locals 1

    .line 83
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->store$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/StoreModel;

    return-object v0
.end method

.method private final getWorkerPid()I
    .locals 3

    .line 45
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerPid$delegate:Landroidx/compose/runtime/MutableIntState;

    check-cast v0, Landroidx/compose/runtime/IntState;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/IntState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1282
    .local v2, "$i$f$getValue\\1\\45":I
    invoke-interface {v0}, Landroidx/compose/runtime/IntState;->getIntValue()I

    move-result v0

    .line 45
    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/IntState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\45":I
    return v0
.end method

.method private final importPhaseText(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p1, "phase"    # Ljava/lang/String;

    .line 557
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    :goto_0
    goto :goto_1

    :sswitch_0
    const-string v0, "extracting"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 559
    :cond_0
    const-string v0, "\u6b63\u5728\u89e3\u5305 iOS \u7cfb\u7edf\u2026"

    goto :goto_2

    .line 557
    :sswitch_1
    const-string v0, "hashing"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 558
    :cond_1
    const-string v0, "\u6b63\u5728\u68c0\u67e5\u6587\u4ef6\u2026"

    goto :goto_2

    .line 557
    :sswitch_2
    const-string v0, "packing"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 560
    :cond_2
    const-string v0, "\u6b63\u5728\u6253\u5305 iOS \u5b58\u50a8\u2026"

    goto :goto_2

    .line 557
    :sswitch_3
    const-string v0, "verifying"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    .line 561
    :cond_3
    const-string v0, "\u6b63\u5728\u68c0\u67e5 iOS \u7cfb\u7edf\u2026"

    goto :goto_2

    .line 562
    :goto_1
    const-string v0, "\u6b63\u5728\u8bbe\u7f6e iOS \u7cfb\u7edf\u2026"

    .line 563
    :goto_2
    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x6514ef37 -> :sswitch_3
        -0x301aacd7 -> :sswitch_2
        0x29939414 -> :sswitch_1
        0x2ccbdfc1 -> :sswitch_0
    .end sparse-switch
.end method

.method private final importPrepRom(Landroid/net/Uri;)V
    .locals 4
    .param p1, "uri"    # Landroid/net/Uri;

    .line 929
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getBootrom()Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 930
    .local v0, "rom":Lorg/lighttouch/android/Bootrom;
    :cond_0
    new-instance v1, Ljava/lang/Thread;

    .line 940
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda86;

    invoke-direct {v2, p0, v0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda86;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Landroid/net/Uri;)V

    .line 930
    const-string v3, "prepare-bootrom"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 940
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 941
    return-void
.end method

.method private static final importPrepRom$lambda$190(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/Bootrom;Landroid/net/Uri;)V
    .locals 11
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$rom"    # Lorg/lighttouch/android/Bootrom;
    .param p2, "$uri"    # Landroid/net/Uri;

    .line 931
    nop

    .line 932
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-virtual {p1}, Lorg/lighttouch/android/Bootrom;->name()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "toLowerCase(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "prepare-bootrom-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ".bin"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 933
    .local v0, "target":Ljava/io/File;
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-virtual {v1, p2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v1

    if-eqz v1, :cond_3

    check-cast v1, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    move-object v2, v1

    check-cast v2, Ljava/io/InputStream;

    .line 1369
    .local v2, "input\\1":Ljava/io/InputStream;
    const/4 v3, 0x0

    .local v3, "$i$a$-use-MainActivity$importPrepRom$1$1\\1\\933\\0":I
    new-instance v4, Ljava/io/FileOutputStream;

    .line 933
    invoke-direct {v4, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v4, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v5, v4

    check-cast v5, Ljava/io/FileOutputStream;

    .line 1369
    .local v5, "it\\2":Ljava/io/FileOutputStream;
    const/4 v6, 0x0

    .line 933
    .local v6, "$i$a$-use-MainActivity$importPrepRom$1$1$1\\2\\933\\1":I
    move-object v7, v5

    check-cast v7, Ljava/io/OutputStream;

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v2, v7, v9, v8, v10}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v5    # "it\\2":Ljava/io/FileOutputStream;
    .end local v6    # "$i$a$-use-MainActivity$importPrepRom$1$1$1\\2\\933\\1":I
    :try_start_3
    invoke-static {v4, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .end local v2    # "input\\1":Ljava/io/InputStream;
    .end local v3    # "$i$a$-use-MainActivity$importPrepRom$1$1\\1\\933\\0":I
    :try_start_4
    invoke-static {v1, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 934
    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v1

    const-wide/16 v3, 0x1

    cmp-long v3, v3, v1

    if-gtz v3, :cond_0

    const-wide/32 v3, 0x100001

    cmp-long v1, v1, v3

    if-gez v1, :cond_0

    const/4 v9, 0x1

    :cond_0
    if-eqz v9, :cond_2

    .line 936
    invoke-static {v0}, Lkotlin/io/FilesKt;->readBytes(Ljava/io/File;)[B

    move-result-object v1

    invoke-virtual {p1, v1}, Lorg/lighttouch/android/Bootrom;->matches([B)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 937
    invoke-direct {p0, p2}, Lorg/lighttouch/android/MainActivity;->displayName(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    .line 938
    .local v1, "name":Ljava/lang/String;
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda102;

    invoke-direct {v3, p0, v0, p1, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda102;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .end local v0    # "target":Ljava/io/File;
    .end local v1    # "name":Ljava/lang/String;
    goto :goto_0

    .line 1369
    .restart local v0    # "target":Ljava/io/File;
    :cond_1
    const/4 v1, 0x0

    .line 936
    .local v1, "$i$a$-require-MainActivity$importPrepRom$1$3\\4\\936\\0":I
    invoke-virtual {p1}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "That file is not the "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " boot ROM"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .end local v1    # "$i$a$-require-MainActivity$importPrepRom$1$3\\4\\936\\0":I
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v1

    .line 1369
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_2
    const/4 v1, 0x0

    .line 934
    .local v1, "$i$a$-require-MainActivity$importPrepRom$1$2\\3\\934\\0":I
    const-string v2, "\u8be5\u6587\u4ef6\u4e0d\u662f boot ROM"

    .end local v1    # "$i$a$-require-MainActivity$importPrepRom$1$2\\3\\934\\0":I
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 933
    .restart local v2    # "input\\1":Ljava/io/InputStream;
    .restart local v3    # "$i$a$-use-MainActivity$importPrepRom$1$1\\1\\933\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_0
    move-exception v5

    .end local v0    # "target":Ljava/io/File;
    .end local v2    # "input\\1":Ljava/io/InputStream;
    .end local v3    # "$i$a$-use-MainActivity$importPrepRom$1$1\\1\\933\\0":I
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    :try_start_5
    throw v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v0    # "target":Ljava/io/File;
    .restart local v2    # "input\\1":Ljava/io/InputStream;
    .restart local v3    # "$i$a$-use-MainActivity$importPrepRom$1$1\\1\\933\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_1
    move-exception v6

    :try_start_6
    invoke-static {v4, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v6
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .end local v2    # "input\\1":Ljava/io/InputStream;
    .end local v3    # "$i$a$-use-MainActivity$importPrepRom$1$1\\1\\933\\0":I
    .restart local v0    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_2
    move-exception v2

    .end local v0    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    :try_start_7
    throw v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .restart local v0    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_3
    move-exception v3

    :try_start_8
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v3

    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_3
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "\u65e0\u6cd5\u8bfb\u53d6\u5f15\u5bfc\u6587\u4ef6"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v1
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 939
    .end local v0    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$rom":Lorg/lighttouch/android/Bootrom;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda103;

    invoke-direct {v2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda103;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 940
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method private static final importPrepRom$lambda$190$lambda$188(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/Bootrom;Ljava/lang/String;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$target"    # Ljava/io/File;
    .param p2, "$rom"    # Lorg/lighttouch/android/Bootrom;
    .param p3, "$name"    # Ljava/lang/String;

    .line 938
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomPath(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/PrepareState;->setRomFor(Lorg/lighttouch/android/Bootrom;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p2}, Lorg/lighttouch/android/Bootrom;->getLabel()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u00b7 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomLabel(Ljava/lang/String;)V

    return-void
.end method

.method private static final importPrepRom$lambda$190$lambda$189(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 939
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, "\u65e0\u6cd5\u4f7f\u7528\u8be5\u5f15\u5bfc\u6587\u4ef6"

    :cond_0
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setRomError(Ljava/lang/String;)V

    return-void
.end method

.method private final importPreparedOutput(Landroid/os/Bundle;)V
    .locals 24
    .param p1, "state"    # Landroid/os/Bundle;

    .line 828
    move-object/from16 v4, p0

    move-object/from16 v12, p1

    iget-boolean v0, v4, Lorg/lighttouch/android/MainActivity;->preparedImportInFlight:Z

    if-eqz v0, :cond_0

    return-void

    .line 829
    :cond_0
    invoke-direct {v4}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v1

    .line 830
    .local v1, "worker":Lorg/lighttouch/android/IEngine;
    const-string v0, "destination"

    invoke-virtual {v12, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_9

    .local v5, "destination":Ljava/lang/String;
    iput-object v5, v4, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    const/4 v0, 0x1

    invoke-direct {v4, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    iput-boolean v0, v4, Lorg/lighttouch/android/MainActivity;->preparedImportInFlight:Z

    .line 831
    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v2, ""

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/PrepareState;->setImportPhase(Ljava/lang/String;)V

    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const/high16 v3, -0x40800000    # -1.0f

    invoke-virtual {v0, v3}, Lorg/lighttouch/android/PrepareState;->setImportProgress(F)V

    .line 832
    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v13

    .local v13, "chosen":Lorg/lighttouch/android/CatalogFirmware;
    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getIpswPath()Ljava/lang/String;

    move-result-object v7

    .line 834
    .local v7, "ipsw":Ljava/lang/String;
    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getBootrom()Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getRomReady()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getRomPath()Ljava/lang/String;

    move-result-object v0

    move-object v6, v0

    goto :goto_0

    :cond_1
    move-object v6, v2

    .line 835
    .local v6, "rom":Ljava/lang/String;
    :goto_0
    const/4 v0, 0x2

    const/16 v3, 0x2d

    const/4 v8, 0x0

    if-eqz v13, :cond_2

    invoke-virtual {v13}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_3

    :cond_2
    iget-object v9, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v9}, Lorg/lighttouch/android/PrepareState;->getFirmwareId()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v3, v8, v0, v8}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    .local v9, "board":Ljava/lang/String;
    :cond_3
    if-eqz v13, :cond_4

    invoke-virtual {v13}, Lorg/lighttouch/android/CatalogFirmware;->getBuild()Ljava/lang/String;

    move-result-object v10

    if-nez v10, :cond_5

    :cond_4
    iget-object v10, v4, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v10}, Lorg/lighttouch/android/PrepareState;->getFirmwareId()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v3, v8, v0, v8}, Lkotlin/text/StringsKt;->substringAfter$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    :cond_5
    move-object v3, v10

    .line 836
    .local v3, "build":Ljava/lang/String;
    invoke-direct {v4}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 1452
    .local v8, "$i$f$mapNotNull\\2\\836":I
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    check-cast v10, Ljava/util/Collection;

    .local v10, "destination\\3":Ljava/util/Collection;
    move-object v11, v0

    .local v11, "$this$mapNotNullTo\\3":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 1460
    .local v14, "$i$f$mapNotNullTo\\3\\1452":I
    move-object v15, v11

    .local v15, "$this$forEach\\4":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 1461
    .local v16, "$i$f$forEach\\4\\1460":I
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_1
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_7

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    .local v18, "element\\4":Ljava/lang/Object;
    move-object/from16 v19, v18

    .local v19, "element\\5":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 1460
    .local v20, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\5\\1461\\3":I
    move-object/from16 v21, v0

    .end local v0    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .local v21, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    move-object/from16 v0, v19

    check-cast v0, Landroid/os/Bundle;

    .local v0, "it\\7":Landroid/os/Bundle;
    const/16 v22, 0x0

    .line 836
    .local v22, "$i$a$-mapNotNull-MainActivity$importPreparedOutput$before$1\\7\\1460\\0":I
    move-object/from16 v23, v1

    .end local v1    # "worker":Lorg/lighttouch/android/IEngine;
    .local v23, "worker":Lorg/lighttouch/android/IEngine;
    const-string v1, "id"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1460
    .end local v0    # "it\\7":Landroid/os/Bundle;
    .end local v22    # "$i$a$-mapNotNull-MainActivity$importPreparedOutput$before$1\\7\\1460\\0":I
    if-eqz v0, :cond_6

    .line 1462
    .local v0, "it\\5":Ljava/lang/Object;
    const/4 v1, 0x0

    .line 1460
    .local v1, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\6\\1462\\5":I
    invoke-interface {v10, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1461
    .end local v0    # "it\\5":Ljava/lang/Object;
    .end local v1    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\6\\1462\\5":I
    .end local v19    # "element\\5":Ljava/lang/Object;
    .end local v20    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\5\\1461\\3":I
    :cond_6
    move-object/from16 v0, v21

    move-object/from16 v1, v23

    .end local v18    # "element\\4":Ljava/lang/Object;
    goto :goto_1

    .line 1463
    .end local v21    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .end local v23    # "worker":Lorg/lighttouch/android/IEngine;
    .local v0, "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .local v1, "worker":Lorg/lighttouch/android/IEngine;
    :cond_7
    move-object/from16 v21, v0

    move-object/from16 v23, v1

    .line 1464
    .end local v0    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .end local v1    # "worker":Lorg/lighttouch/android/IEngine;
    .end local v15    # "$this$forEach\\4":Ljava/lang/Iterable;
    .end local v16    # "$i$f$forEach\\4\\1460":I
    .restart local v21    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    .restart local v23    # "worker":Lorg/lighttouch/android/IEngine;
    nop

    .end local v10    # "destination\\3":Ljava/util/Collection;
    .end local v11    # "$this$mapNotNullTo\\3":Ljava/lang/Iterable;
    .end local v14    # "$i$f$mapNotNullTo\\3\\1452":I
    move-object v0, v10

    check-cast v0, Ljava/util/List;

    .line 1452
    nop

    .end local v8    # "$i$f$mapNotNull\\2\\836":I
    .end local v21    # "$this$mapNotNull\\2":Ljava/lang/Iterable;
    check-cast v0, Ljava/lang/Iterable;

    .line 836
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v8

    .line 837
    .local v8, "before":Ljava/util/Set;
    const-string v0, "timings"

    invoke-virtual {v12, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_8

    goto :goto_2

    :cond_8
    move-object v2, v0

    .local v2, "timings":Ljava/lang/String;
    :goto_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    .line 838
    .local v10, "started":J
    new-instance v14, Ljava/lang/Thread;

    .line 875
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda11;

    move-object v1, v9

    move-object v9, v2

    move-object v2, v1

    move-object/from16 v1, v23

    .end local v23    # "worker":Lorg/lighttouch/android/IEngine;
    .restart local v1    # "worker":Lorg/lighttouch/android/IEngine;
    .local v2, "board":Ljava/lang/String;
    .local v9, "timings":Ljava/lang/String;
    invoke-direct/range {v0 .. v11}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;J)V

    .line 838
    const-string v4, "prepared-device-import"

    invoke-direct {v14, v0, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 875
    invoke-virtual {v14}, Ljava/lang/Thread;->start()V

    .line 876
    return-void

    .line 830
    .end local v2    # "board":Ljava/lang/String;
    .end local v3    # "build":Ljava/lang/String;
    .end local v5    # "destination":Ljava/lang/String;
    .end local v6    # "rom":Ljava/lang/String;
    .end local v7    # "ipsw":Ljava/lang/String;
    .end local v8    # "before":Ljava/util/Set;
    .end local v9    # "timings":Ljava/lang/String;
    .end local v10    # "started":J
    .end local v13    # "chosen":Lorg/lighttouch/android/CatalogFirmware;
    :cond_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v2, "\u5fc5\u9700\u7684\u503c\u4e3a\u7a7a\u3002"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static final importPreparedOutput$lambda$167(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;Ljava/lang/String;J)V
    .locals 28
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$board"    # Ljava/lang/String;
    .param p2, "$build"    # Ljava/lang/String;
    .param p3, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p4, "$destination"    # Ljava/lang/String;
    .param p5, "$rom"    # Ljava/lang/String;
    .param p6, "$ipsw"    # Ljava/lang/String;
    .param p7, "$before"    # Ljava/util/Set;
    .param p8, "$timings"    # Ljava/lang/String;
    .param p9, "$started"    # J

    .line 839
    move-object/from16 v1, p0

    move-object/from16 v3, p3

    move-object/from16 v5, p4

    move-object/from16 v12, p5

    move-object/from16 v6, p6

    new-instance v8, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v8}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .local v8, "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    const-string v0, ""

    iput-object v0, v8, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    new-instance v7, Lkotlin/jvm/internal/Ref$BooleanRef;

    invoke-direct {v7}, Lkotlin/jvm/internal/Ref$BooleanRef;-><init>()V

    .line 840
    .local v7, "selected":Lkotlin/jvm/internal/Ref$BooleanRef;
    nop

    .line 841
    const-string v2, "getAbsolutePath(...)"

    const/4 v9, 0x2

    const/4 v11, 0x0

    if-eqz v1, :cond_9

    .line 842
    :try_start_0
    iget-object v0, v3, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    invoke-virtual {v3}, Lorg/lighttouch/android/MainActivity;->getDevices()Ljava/util/List;

    move-result-object v13

    check-cast v13, Ljava/lang/Iterable;

    .local v13, "$this$map\\2":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 1531
    .local v14, "$i$f$map\\2\\842":I
    new-instance v15, Ljava/util/ArrayList;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_6

    const/16 v16, 0x1

    const/16 v10, 0xa

    :try_start_1
    invoke-static {v13, v10}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v10

    invoke-direct {v15, v10}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v15, Ljava/util/Collection;

    .local v15, "destination\\3":Ljava/util/Collection;
    move-object v10, v13

    .local v10, "$this$mapTo\\3":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 1532
    .local v17, "$i$f$mapTo\\3\\1531":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_0
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v19
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_5

    if-eqz v19, :cond_0

    :try_start_2
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    .line 1533
    .local v19, "item\\3":Ljava/lang/Object;
    move-object/from16 v20, v19

    check-cast v20, Lorg/lighttouch/android/DeviceSummary;

    .local v20, "it\\4":Lorg/lighttouch/android/DeviceSummary;
    const/16 v21, 0x0

    .line 842
    .local v21, "$i$a$-map-MainActivity$importPreparedOutput$1$result$2\\4\\1533\\0":I
    invoke-virtual/range {v20 .. v20}, Lorg/lighttouch/android/DeviceSummary;->getName()Ljava/lang/String;

    move-result-object v4

    .line 1533
    .end local v20    # "it\\4":Lorg/lighttouch/android/DeviceSummary;
    .end local v21    # "$i$a$-map-MainActivity$importPreparedOutput$1$result$2\\4\\1533\\0":I
    invoke-interface {v15, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_0

    .line 853
    .end local v10    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v13    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v14    # "$i$f$map\\2\\842":I
    .end local v15    # "destination\\3":Ljava/util/Collection;
    .end local v17    # "$i$f$mapTo\\3\\1531":I
    .end local v19    # "item\\3":Ljava/lang/Object;
    :catch_0
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v14, p2

    :goto_1
    move-object/from16 v22, v8

    move/from16 v18, v9

    move/from16 v19, v11

    goto/16 :goto_e

    .line 1534
    .restart local v10    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .restart local v13    # "$this$map\\2":Ljava/lang/Iterable;
    .restart local v14    # "$i$f$map\\2\\842":I
    .restart local v15    # "destination\\3":Ljava/util/Collection;
    .restart local v17    # "$i$f$mapTo\\3\\1531":I
    :cond_0
    nop

    .end local v10    # "$this$mapTo\\3":Ljava/lang/Iterable;
    .end local v15    # "destination\\3":Ljava/util/Collection;
    .end local v17    # "$i$f$mapTo\\3\\1531":I
    :try_start_3
    move-object v4, v15

    check-cast v4, Ljava/util/List;

    .line 1531
    nop

    .end local v13    # "$this$map\\2":Ljava/lang/Iterable;
    .end local v14    # "$i$f$map\\2\\842":I
    check-cast v4, Ljava/util/Collection;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_5

    .line 842
    move-object/from16 v13, p1

    move-object/from16 v14, p2

    :try_start_4
    invoke-static {v13, v14, v0, v4}, Lorg/lighttouch/android/DevicesKt;->defaultDeviceName(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Collection;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v8, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 843
    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda83;

    invoke-direct {v0, v3}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda83;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-direct {v3, v1, v0}, Lorg/lighttouch/android/MainActivity;->watchImport(Lorg/lighttouch/android/IEngine;Lkotlin/jvm/functions/Function2;)Lkotlin/jvm/functions/Function0;

    move-result-object v0

    move-object v4, v0

    .line 845
    .local v4, "stopWatching":Lkotlin/jvm/functions/Function0;
    invoke-virtual {v3}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v10, 0x0

    invoke-static {v5, v0, v11, v9, v10}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    if-eqz v0, :cond_1

    :try_start_5
    new-instance v0, Ljava/io/File;

    const-string v10, "device.lock.json"

    invoke-direct {v0, v5, v10}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->isFile()Z

    move-result v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    if-eqz v0, :cond_1

    move/from16 v0, v16

    goto :goto_2

    .line 853
    .end local v4    # "stopWatching":Lkotlin/jvm/functions/Function0;
    :catch_1
    move-exception v0

    goto :goto_1

    .line 845
    .restart local v4    # "stopWatching":Lkotlin/jvm/functions/Function0;
    :cond_1
    move v0, v11

    :goto_2
    move v10, v0

    .line 846
    .local v10, "own":Z
    if-eqz v10, :cond_2

    :try_start_6
    iget-object v0, v8, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-interface {v1, v5, v0, v12}, Lorg/lighttouch/android/IEngine;->adoptPrepared(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    goto :goto_3

    .line 847
    :catchall_0
    move-exception v0

    move-object/from16 v21, v4

    move-object/from16 v22, v8

    move/from16 v18, v9

    move/from16 v19, v11

    goto/16 :goto_a

    .line 846
    :cond_2
    :try_start_7
    iget-object v0, v8, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-interface {v1, v5, v0, v12}, Lorg/lighttouch/android/IEngine;->importPrepared(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 847
    :goto_3
    :try_start_8
    invoke-interface {v4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-object v15, v0

    .local v15, "result\\5":Ljava/lang/String;
    const/16 v17, 0x0

    .line 848
    .local v17, "$i$a$-also-MainActivity$importPreparedOutput$1$result$3\\5\\847\\0":I
    invoke-static {v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v18, v15

    check-cast v18, Ljava/lang/CharSequence;

    invoke-interface/range {v18 .. v18}, Ljava/lang/CharSequence;->length()I

    move-result v18
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4

    if-nez v18, :cond_3

    move/from16 v18, v16

    goto :goto_4

    :cond_3
    move/from16 v18, v11

    :goto_4
    if-eqz v18, :cond_8

    .line 849
    move/from16 v18, v9

    :try_start_9
    invoke-interface {v1}, Lorg/lighttouch/android/IEngine;->records()[Landroid/os/Bundle;

    move-result-object v9
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_3

    move/from16 v19, v11

    :try_start_a
    const-string v11, "records(...)"

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v9, [Ljava/lang/Object;

    .local v9, "$this$firstOrNull\\6":[Ljava/lang/Object;
    const/4 v11, 0x0

    .line 1535
    .local v11, "$i$f$firstOrNull\\6\\849":I
    move-object/from16 v20, v0

    array-length v0, v9
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_2

    move-object/from16 v21, v4

    move/from16 v4, v19

    .end local v4    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .local v21, "stopWatching":Lkotlin/jvm/functions/Function0;
    :goto_5
    move-object/from16 v22, v8

    .end local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v22, "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    const-string v8, "id"

    if-ge v4, v0, :cond_5

    :try_start_b
    aget-object v23, v9, v4

    .local v23, "element\\6":Ljava/lang/Object;
    move-object/from16 v24, v23

    check-cast v24, Landroid/os/Bundle;

    move-object/from16 v25, v24

    .local v25, "it\\7":Landroid/os/Bundle;
    const/16 v24, 0x0

    .line 849
    .local v24, "$i$a$-firstOrNull-MainActivity$importPreparedOutput$1$result$3$created$1\\7\\1535\\5":I
    move/from16 v26, v0

    move-object/from16 v0, p7

    check-cast v0, Ljava/lang/Iterable;

    move/from16 v27, v4

    move-object/from16 v4, v25

    move-object/from16 v25, v9

    .end local v9    # "$this$firstOrNull\\6":[Ljava/lang/Object;
    .local v4, "it\\7":Landroid/os/Bundle;
    .local v25, "$this$firstOrNull\\6":[Ljava/lang/Object;
    invoke-virtual {v4, v8}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v0, v9}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    .line 1535
    .end local v4    # "it\\7":Landroid/os/Bundle;
    .end local v24    # "$i$a$-firstOrNull-MainActivity$importPreparedOutput$1$result$3$created$1\\7\\1535\\5":I
    if-nez v0, :cond_4

    goto :goto_6

    .end local v23    # "element\\6":Ljava/lang/Object;
    :cond_4
    add-int/lit8 v4, v27, 0x1

    move-object/from16 v8, v22

    move-object/from16 v9, v25

    move/from16 v0, v26

    goto :goto_5

    .line 1536
    .end local v25    # "$this$firstOrNull\\6":[Ljava/lang/Object;
    .restart local v9    # "$this$firstOrNull\\6":[Ljava/lang/Object;
    :cond_5
    move-object/from16 v25, v9

    .end local v9    # "$this$firstOrNull\\6":[Ljava/lang/Object;
    .restart local v25    # "$this$firstOrNull\\6":[Ljava/lang/Object;
    const/16 v23, 0x0

    .line 849
    .end local v11    # "$i$f$firstOrNull\\6\\849":I
    .end local v25    # "$this$firstOrNull\\6":[Ljava/lang/Object;
    :goto_6
    check-cast v23, Landroid/os/Bundle;

    move-object/from16 v0, v23

    .line 850
    .local v0, "created\\5":Landroid/os/Bundle;
    if-eqz v0, :cond_7

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/String;

    const-string v9, "running"

    aput-object v9, v4, v19

    const-string v9, "paused"

    aput-object v9, v4, v16

    const-string v9, "starting"

    aput-object v9, v4, v18

    const-string v9, "stopping"

    const/4 v11, 0x3

    aput-object v9, v4, v11

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v3}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v4, v9}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_7

    invoke-virtual {v0, v8}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v1, v4}, Lorg/lighttouch/android/IEngine;->select(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v8, "select(...)"

    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_6

    move/from16 v4, v16

    goto :goto_7

    :cond_6
    move/from16 v4, v19

    :goto_7
    if-eqz v4, :cond_7

    move/from16 v4, v16

    goto :goto_8

    :cond_7
    move/from16 v4, v19

    :goto_8
    iput-boolean v4, v7, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    goto :goto_9

    .line 853
    .end local v0    # "created\\5":Landroid/os/Bundle;
    .end local v10    # "own":Z
    .end local v15    # "result\\5":Ljava/lang/String;
    .end local v17    # "$i$a$-also-MainActivity$importPreparedOutput$1$result$3\\5\\847\\0":I
    .end local v21    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    :catch_2
    move-exception v0

    move-object/from16 v22, v8

    goto :goto_d

    :catch_3
    move-exception v0

    move-object/from16 v22, v8

    goto :goto_c

    .line 848
    .local v4, "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v10    # "own":Z
    .restart local v15    # "result\\5":Ljava/lang/String;
    .restart local v17    # "$i$a$-also-MainActivity$importPreparedOutput$1$result$3\\5\\847\\0":I
    :cond_8
    move-object/from16 v20, v0

    move-object/from16 v21, v4

    move-object/from16 v22, v8

    move/from16 v18, v9

    move/from16 v19, v11

    .line 852
    .end local v4    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v21    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    :goto_9
    nop

    .line 847
    .end local v15    # "result\\5":Ljava/lang/String;
    .end local v17    # "$i$a$-also-MainActivity$importPreparedOutput$1$result$3\\5\\847\\0":I
    move-object/from16 v4, v20

    .end local v10    # "own":Z
    .end local v21    # "stopWatching":Lkotlin/jvm/functions/Function0;
    goto :goto_f

    .end local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v4    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v10    # "own":Z
    :catchall_1
    move-exception v0

    move-object/from16 v21, v4

    move-object/from16 v22, v8

    move/from16 v18, v9

    move/from16 v19, v11

    .end local v4    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .end local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v21    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    :goto_a
    invoke-interface/range {v21 .. v21}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .end local v7    # "selected":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local p0    # "$worker":Lorg/lighttouch/android/IEngine;
    .end local p1    # "$board":Ljava/lang/String;
    .end local p2    # "$build":Ljava/lang/String;
    .end local p3    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p4    # "$destination":Ljava/lang/String;
    .end local p5    # "$rom":Ljava/lang/String;
    .end local p6    # "$ipsw":Ljava/lang/String;
    .end local p7    # "$before":Ljava/util/Set;
    .end local p8    # "$timings":Ljava/lang/String;
    .end local p9    # "$started":J
    throw v0

    .line 853
    .end local v10    # "own":Z
    .end local v21    # "stopWatching":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "selected":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p0    # "$worker":Lorg/lighttouch/android/IEngine;
    .restart local p1    # "$board":Ljava/lang/String;
    .restart local p2    # "$build":Ljava/lang/String;
    .restart local p3    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p4    # "$destination":Ljava/lang/String;
    .restart local p5    # "$rom":Ljava/lang/String;
    .restart local p6    # "$ipsw":Ljava/lang/String;
    .restart local p7    # "$before":Ljava/util/Set;
    .restart local p8    # "$timings":Ljava/lang/String;
    .restart local p9    # "$started":J
    :catch_4
    move-exception v0

    goto :goto_b

    :catch_5
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v14, p2

    :goto_b
    move-object/from16 v22, v8

    move/from16 v18, v9

    :goto_c
    move/from16 v19, v11

    goto :goto_d

    :catch_6
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v14, p2

    move-object/from16 v22, v8

    move/from16 v18, v9

    move/from16 v19, v11

    const/16 v16, 0x1

    .end local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    :goto_d
    goto :goto_e

    .line 1369
    .end local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    :cond_9
    move-object/from16 v13, p1

    move-object/from16 v14, p2

    move-object/from16 v22, v8

    move/from16 v18, v9

    move/from16 v19, v11

    const/16 v16, 0x1

    .end local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    const/4 v0, 0x0

    .line 841
    .local v0, "$i$a$-checkNotNull-MainActivity$importPreparedOutput$1$result$1\\1\\841\\0":I
    const-string v4, "\u8bbe\u5907\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528"

    .end local v0    # "$i$a$-checkNotNull-MainActivity$importPreparedOutput$1$result$1\\1\\841\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v7    # "selected":Lkotlin/jvm/internal/Ref$BooleanRef;
    .end local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local p0    # "$worker":Lorg/lighttouch/android/IEngine;
    .end local p1    # "$board":Ljava/lang/String;
    .end local p2    # "$build":Ljava/lang/String;
    .end local p3    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p4    # "$destination":Ljava/lang/String;
    .end local p5    # "$rom":Ljava/lang/String;
    .end local p6    # "$ipsw":Ljava/lang/String;
    .end local p7    # "$before":Ljava/util/Set;
    .end local p8    # "$timings":Ljava/lang/String;
    .end local p9    # "$started":J
    throw v0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_7

    .line 853
    .restart local v7    # "selected":Lkotlin/jvm/internal/Ref$BooleanRef;
    .restart local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p0    # "$worker":Lorg/lighttouch/android/IEngine;
    .restart local p1    # "$board":Ljava/lang/String;
    .restart local p2    # "$build":Ljava/lang/String;
    .restart local p3    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p4    # "$destination":Ljava/lang/String;
    .restart local p5    # "$rom":Ljava/lang/String;
    .restart local p6    # "$ipsw":Ljava/lang/String;
    .restart local p7    # "$before":Ljava/util/Set;
    .restart local p8    # "$timings":Ljava/lang/String;
    .restart local p9    # "$started":J
    :catch_7
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    :goto_e
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_a

    const-string v4, "\u5bfc\u5165\u8fc7\u7a0b\u4e2d\u8bbe\u5907\u5de5\u4f5c\u8fdb\u7a0b\u9000\u51fa"

    .line 840
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_a
    :goto_f
    nop

    .line 854
    .local v4, "result":Ljava/lang/String;
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v0, v4

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_b

    move/from16 v0, v16

    goto :goto_10

    :cond_b
    move/from16 v0, v19

    :goto_10
    if-eqz v0, :cond_d

    .line 856
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/io/FilesKt;->walkTopDown(Ljava/io/File;)Lkotlin/io/FileTreeWalk;

    move-result-object v0

    check-cast v0, Lkotlin/sequences/Sequence;

    .local v0, "$this$forEach\\8":Lkotlin/sequences/Sequence;
    const/4 v8, 0x0

    .line 1537
    .local v8, "$i$f$forEach\\8\\856":I
    invoke-interface {v0}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_11
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_c

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\8":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Ljava/io/File;

    .local v11, "it\\9":Ljava/io/File;
    const/4 v15, 0x0

    .line 856
    .local v15, "$i$a$-forEach-MainActivity$importPreparedOutput$1$1\\9\\1537\\0":I
    move/from16 v1, v16

    invoke-virtual {v11, v1, v1}, Ljava/io/File;->setWritable(ZZ)Z

    .line 1537
    .end local v11    # "it\\9":Ljava/io/File;
    .end local v15    # "$i$a$-forEach-MainActivity$importPreparedOutput$1$1\\9\\1537\\0":I
    move-object/from16 v1, p0

    .end local v10    # "element\\8":Ljava/lang/Object;
    goto :goto_11

    .line 1538
    :cond_c
    nop

    .line 857
    .end local v0    # "$this$forEach\\8":Lkotlin/sequences/Sequence;
    .end local v8    # "$i$f$forEach\\8\\856":I
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    new-instance v0, Ljava/io/File;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v8, ".native.log"

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 858
    invoke-virtual {v3}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move/from16 v1, v18

    move/from16 v2, v19

    const/4 v10, 0x0

    invoke-static {v6, v0, v2, v1, v10}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v6}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 860
    :cond_d
    iget-object v0, v3, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda85;

    move-object/from16 v9, p8

    move-wide/from16 v10, p9

    move-object/from16 v8, v22

    .end local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .local v8, "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-direct/range {v2 .. v11}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda85;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;J)V

    .end local v8    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v22    # "name":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 875
    return-void
.end method

.method private static final importPreparedOutput$lambda$167$lambda$162(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;F)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "text"    # Ljava/lang/String;
    .param p2, "fraction"    # F

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 843
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/PrepareState;->setImportPhase(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/PrepareState;->setImportProgress(F)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final importPreparedOutput$lambda$167$lambda$166(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$ObjectRef;Ljava/lang/String;J)V
    .locals 6
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$result"    # Ljava/lang/String;
    .param p2, "$destination"    # Ljava/lang/String;
    .param p3, "$ipsw"    # Ljava/lang/String;
    .param p4, "$selected"    # Lkotlin/jvm/internal/Ref$BooleanRef;
    .param p5, "$name"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p6, "$timings"    # Ljava/lang/String;
    .param p7, "$started"    # J

    .line 861
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->preparedImportInFlight:Z

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v1, p1}, Lorg/lighttouch/android/PrepareState;->setImportError(Ljava/lang/String;)V

    .line 862
    move-object v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    move v1, v0

    :goto_0
    if-eqz v1, :cond_5

    .line 863
    const-string v1, ""

    iput-object v1, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    .line 864
    sget-object v3, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v4, p0

    check-cast v4, Landroid/content/Context;

    invoke-virtual {v3, v4}, Lorg/lighttouch/android/PreparationNote;->read(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    const-string v5, "destination"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :cond_1
    move-object v3, v4

    :goto_1
    invoke-static {v3, p2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    sget-object v3, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    invoke-virtual {v3, v5}, Lorg/lighttouch/android/PreparationNote;->clear(Landroid/content/Context;)V

    .line 865
    :cond_2
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const-string v5, "getAbsolutePath(...)"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x2

    invoke-static {p3, v3, v0, v5, v4}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3, v1}, Lorg/lighttouch/android/PrepareState;->setIpswPath(Ljava/lang/String;)V

    .line 866
    :cond_3
    const-string v1, "preparation-imports"

    invoke-virtual {p0, v1, v0}, Lorg/lighttouch/android/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "preparedImported"

    invoke-interface {v1, v3, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "pendingPrepared"

    invoke-interface {v1, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "ipsw"

    invoke-interface {v1, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 867
    invoke-static {p0, v0, v2, v4}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->releaseFirmware()V

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1, v4}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    sget-object v2, Lorg/lighttouch/android/PrepareStep;->DEVICE:Lorg/lighttouch/android/PrepareStep;

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setStep(Lorg/lighttouch/android/PrepareStep;)V

    .line 868
    iget-boolean v1, p4, Lkotlin/jvm/internal/Ref$BooleanRef;->element:Z

    if-eqz v1, :cond_4

    .line 869
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/SetupState;->reset(Z)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    iget-object v1, p5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setCreated(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    sget-object v1, Lorg/lighttouch/android/SetupStep;->DONE:Lorg/lighttouch/android/SetupStep;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setStep(Lorg/lighttouch/android/SetupStep;)V

    sget-object v0, Lorg/lighttouch/android/Screen;->SETUP:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 870
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    sub-long/2addr v1, p7

    const/16 v3, 0x64

    int-to-long v3, v3

    div-long/2addr v1, v3

    long-to-double v1, v1

    const-wide/high16 v3, 0x4024000000000000L    # 10.0

    div-double/2addr v1, v3

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "Adding the device\t"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setTimings(Ljava/lang/String;)V

    goto :goto_2

    .line 872
    :cond_4
    iget-object v0, p5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Added "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "; stop the running device to switch to it"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    .line 874
    :cond_5
    :goto_2
    return-void
.end method

.method private final importStockIpsw(Landroid/net/Uri;)V
    .locals 6
    .param p1, "uri"    # Landroid/net/Uri;

    .line 888
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 889
    .local v0, "chosen":Lorg/lighttouch/android/CatalogFirmware;
    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getBusy()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    .line 890
    :cond_1
    const/4 v1, 0x1

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v2, ""

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setIpswError(Ljava/lang/String;)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->displayName(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Copying "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/PrepareState;->setIpswChecking(Ljava/lang/String;)V

    .line 891
    sget-object v1, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "getApplicationContext(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Copying iOS "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/lighttouch/android/DownloadService$Companion;->hold(Landroid/content/Context;Ljava/lang/String;)V

    .line 892
    new-instance v1, Ljava/lang/Thread;

    .line 915
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda9;

    invoke-direct {v2, p0, v0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda9;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Landroid/net/Uri;)V

    .line 892
    const-string v3, "stock-ipsw-import"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 915
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 916
    return-void

    .line 889
    :cond_2
    :goto_0
    return-void
.end method

.method private static final importStockIpsw$lambda$180(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/CatalogFirmware;Landroid/net/Uri;)V
    .locals 30
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$chosen"    # Lorg/lighttouch/android/CatalogFirmware;
    .param p2, "$uri"    # Landroid/net/Uri;

    .line 893
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    const-string v3, "getApplicationContext(...)"

    sget-object v0, Lorg/lighttouch/android/IpswDownload;->INSTANCE:Lorg/lighttouch/android/IpswDownload;

    move-object v4, v1

    check-cast v4, Landroid/content/Context;

    invoke-virtual {v0, v4}, Lorg/lighttouch/android/IpswDownload;->directory(Landroid/content/Context;)Ljava/io/File;

    move-result-object v0

    move-object v4, v0

    .line 1369
    .local v4, "$this$importStockIpsw_u24lambda_u24180_u24lambda_u24170\\1":Ljava/io/File;
    const/4 v5, 0x0

    .line 893
    .local v5, "$i$a$-apply-MainActivity$importStockIpsw$1$target$1\\1\\893\\0":I
    invoke-virtual {v4}, Ljava/io/File;->mkdirs()Z

    .end local v4    # "$this$importStockIpsw_u24lambda_u24180_u24lambda_u24170\\1":Ljava/io/File;
    .end local v5    # "$i$a$-apply-MainActivity$importStockIpsw$1$target$1\\1\\893\\0":I
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getFileName()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 894
    .local v5, "target":Ljava/io/File;
    new-instance v0, Ljava/io/File;

    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, ".copy"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v4, v0

    .line 895
    .local v4, "partial":Ljava/io/File;
    nop

    .line 896
    :try_start_0
    const-string v0, "SHA-1"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    move-object v6, v0

    .line 897
    .local v6, "digest":Ljava/security/MessageDigest;
    move-object v0, v1

    check-cast v0, Landroid/content/Context;

    invoke-static {v0, v2}, Landroidx/documentfile/provider/DocumentFile;->fromSingleUri(Landroid/content/Context;Landroid/net/Uri;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v0

    const-wide/16 v7, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroidx/documentfile/provider/DocumentFile;->length()J

    move-result-wide v9

    goto :goto_0

    :cond_0
    move-wide v9, v7

    .line 898
    .local v9, "total":J
    :goto_0
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getBytes()J

    move-result-wide v11

    cmp-long v0, v11, v7

    if-lez v0, :cond_2

    cmp-long v0, v9, v7

    if-lez v0, :cond_2

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getBytes()J

    move-result-wide v13
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_8

    cmp-long v0, v9, v13

    if-nez v0, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v0, 0x1

    :goto_2
    const-string v13, " IPSW for the "

    const-string v14, "That file is not the iOS "

    if-eqz v0, :cond_b

    .line 899
    :try_start_1
    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v0

    if-eqz v0, :cond_a

    move-object v15, v0

    check-cast v15, Ljava/io/Closeable;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_8

    :try_start_2
    move-object v0, v15

    check-cast v0, Ljava/io/InputStream;

    move-object/from16 v16, v0

    .line 1369
    .local v16, "input\\3":Ljava/io/InputStream;
    const/16 v17, 0x0

    .local v17, "$i$a$-use-MainActivity$importStockIpsw$1$2\\3\\899\\0":I
    new-instance v0, Ljava/io/FileOutputStream;

    .line 899
    invoke-direct {v0, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-wide/from16 v18, v7

    move-object v7, v0

    check-cast v7, Ljava/io/Closeable;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_6

    :try_start_3
    move-object v0, v7

    check-cast v0, Ljava/io/FileOutputStream;

    .local v0, "output\\4":Ljava/io/FileOutputStream;
    const/4 v8, 0x0

    .line 900
    .local v8, "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    const/high16 v11, 0x100000

    new-array v11, v11, [B

    .local v11, "buffer\\4":[B
    new-instance v20, Lkotlin/jvm/internal/Ref$LongRef;

    invoke-direct/range {v20 .. v20}, Lkotlin/jvm/internal/Ref$LongRef;-><init>()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    move-object/from16 v21, v20

    .line 901
    .local v21, "done\\4":Lkotlin/jvm/internal/Ref$LongRef;
    :goto_3
    nop

    .line 902
    move-object/from16 v12, v16

    .end local v16    # "input\\3":Ljava/io/InputStream;
    .local v12, "input\\3":Ljava/io/InputStream;
    :try_start_4
    invoke-virtual {v12, v11}, Ljava/io/InputStream;->read([B)I

    move-result v16
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    move/from16 v22, v16

    .local v22, "n\\4":I
    if-ltz v22, :cond_4

    .line 903
    move/from16 v16, v8

    move/from16 v2, v22

    const/4 v8, 0x0

    .end local v8    # "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    .end local v22    # "n\\4":I
    .local v2, "n\\4":I
    .local v16, "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    :try_start_5
    invoke-virtual {v0, v11, v8, v2}, Ljava/io/FileOutputStream;->write([BII)V

    invoke-virtual {v6, v11, v8, v2}, Ljava/security/MessageDigest;->update([BII)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    move-object/from16 v22, v12

    move-object/from16 v8, v21

    move-object/from16 v21, v11

    .end local v11    # "buffer\\4":[B
    .end local v12    # "input\\3":Ljava/io/InputStream;
    .local v8, "done\\4":Lkotlin/jvm/internal/Ref$LongRef;
    .local v21, "buffer\\4":[B
    .local v22, "input\\3":Ljava/io/InputStream;
    :try_start_6
    iget-wide v11, v8, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    move-wide/from16 v23, v11

    int-to-long v11, v2

    add-long v11, v23, v11

    iput-wide v11, v8, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 904
    cmp-long v11, v9, v18

    if-lez v11, :cond_3

    iget-object v11, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v12, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda16;

    invoke-direct {v12, v1, v8, v9, v10}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda16;-><init>(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$LongRef;J)V

    invoke-virtual {v11, v12}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_3
    move-object/from16 v2, p2

    move-object/from16 v11, v21

    move-object/from16 v21, v8

    move/from16 v8, v16

    move-object/from16 v16, v22

    goto :goto_3

    .line 899
    .end local v0    # "output\\4":Ljava/io/FileOutputStream;
    .end local v2    # "n\\4":I
    .end local v8    # "done\\4":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v16    # "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    .end local v21    # "buffer\\4":[B
    .end local v22    # "input\\3":Ljava/io/InputStream;
    .restart local v12    # "input\\3":Ljava/io/InputStream;
    :catchall_0
    move-exception v0

    move-object/from16 v22, v12

    move-object/from16 v8, p1

    goto/16 :goto_7

    .line 902
    .restart local v0    # "output\\4":Ljava/io/FileOutputStream;
    .local v8, "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    .restart local v11    # "buffer\\4":[B
    .local v21, "done\\4":Lkotlin/jvm/internal/Ref$LongRef;
    .local v22, "n\\4":I
    :cond_4
    move/from16 v16, v8

    move-object/from16 v8, v21

    move/from16 v2, v22

    move-object/from16 v21, v11

    move-object/from16 v22, v12

    .line 906
    .end local v11    # "buffer\\4":[B
    .end local v12    # "input\\3":Ljava/io/InputStream;
    .local v8, "done\\4":Lkotlin/jvm/internal/Ref$LongRef;
    .restart local v16    # "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    .local v21, "buffer\\4":[B
    .local v22, "input\\3":Ljava/io/InputStream;
    nop

    .end local v0    # "output\\4":Ljava/io/FileOutputStream;
    .end local v8    # "done\\4":Lkotlin/jvm/internal/Ref$LongRef;
    .end local v16    # "$i$a$-use-MainActivity$importStockIpsw$1$2$1\\4\\899\\3":I
    .end local v21    # "buffer\\4":[B
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 899
    const/4 v0, 0x0

    :try_start_7
    invoke-static {v7, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 906
    nop

    .end local v17    # "$i$a$-use-MainActivity$importStockIpsw$1$2\\3\\899\\0":I
    .end local v22    # "input\\3":Ljava/io/InputStream;
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    .line 899
    :try_start_8
    invoke-static {v15, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 907
    invoke-virtual {v6}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v0

    const-string v2, "digest(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, ""

    move-object/from16 v22, v2

    check-cast v22, Ljava/lang/CharSequence;

    new-instance v27, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda17;

    invoke-direct/range {v27 .. v27}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda17;-><init>()V

    const/16 v28, 0x1e

    const/16 v29, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    move-object/from16 v21, v0

    invoke-static/range {v21 .. v29}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 908
    .local v0, "sha1":Ljava/lang/String;
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-nez v2, :cond_5

    const/4 v2, 0x1

    goto :goto_4

    :cond_5
    const/4 v2, 0x0

    :goto_4
    if-nez v2, :cond_7

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/CatalogFirmware;->getSha1()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    goto :goto_5

    :cond_6
    const/4 v11, 0x0

    goto :goto_6

    :cond_7
    :goto_5
    const/4 v11, 0x1

    :goto_6
    if-eqz v11, :cond_9

    .line 909
    invoke-virtual {v4, v5}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v2

    if-eqz v2, :cond_8

    .line 910
    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v7, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda18;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_1
    .catchall {:try_start_8 .. :try_end_8} :catchall_8

    move-object/from16 v8, p1

    :try_start_9
    invoke-direct {v7, v1, v5, v8}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda18;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/CatalogFirmware;)V

    invoke-virtual {v2, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 914
    .end local v0    # "sha1":Ljava/lang/String;
    .end local v6    # "digest":Ljava/security/MessageDigest;
    .end local v9    # "total":J
    goto/16 :goto_b

    .line 1369
    .restart local v0    # "sha1":Ljava/lang/String;
    .restart local v6    # "digest":Ljava/security/MessageDigest;
    .restart local v9    # "total":J
    :cond_8
    move-object/from16 v8, p1

    const/4 v2, 0x0

    .line 909
    .local v2, "$i$a$-check-MainActivity$importStockIpsw$1$4\\6\\909\\0":I
    const-string v7, "\u65e0\u6cd5\u4fdd\u5b58 IPSW"

    .end local v2    # "$i$a$-check-MainActivity$importStockIpsw$1$4\\6\\909\\0":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v2, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v2

    .line 1369
    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_9
    move-object/from16 v8, p1

    const/4 v2, 0x0

    .line 908
    .local v2, "$i$a$-require-MainActivity$importStockIpsw$1$3\\5\\908\\0":I
    invoke-virtual {v8}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .end local v2    # "$i$a$-require-MainActivity$importStockIpsw$1$3\\5\\908\\0":I
    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v2, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v2
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_9

    .line 899
    .end local v0    # "sha1":Ljava/lang/String;
    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local v17    # "$i$a$-use-MainActivity$importStockIpsw$1$2\\3\\899\\0":I
    .restart local v22    # "input\\3":Ljava/io/InputStream;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_1
    move-exception v0

    move-object/from16 v8, p1

    move-object v2, v0

    goto :goto_8

    .end local v22    # "input\\3":Ljava/io/InputStream;
    .restart local v12    # "input\\3":Ljava/io/InputStream;
    :catchall_2
    move-exception v0

    move-object/from16 v8, p1

    move-object/from16 v22, v12

    :goto_7
    move-object v2, v0

    .end local v12    # "input\\3":Ljava/io/InputStream;
    .restart local v22    # "input\\3":Ljava/io/InputStream;
    goto :goto_8

    .end local v22    # "input\\3":Ljava/io/InputStream;
    .local v16, "input\\3":Ljava/io/InputStream;
    :catchall_3
    move-exception v0

    move-object/from16 v8, p1

    move-object/from16 v22, v16

    move-object v2, v0

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local v6    # "digest":Ljava/security/MessageDigest;
    .end local v9    # "total":J
    .end local v16    # "input\\3":Ljava/io/InputStream;
    .end local v17    # "$i$a$-use-MainActivity$importStockIpsw$1$2\\3\\899\\0":I
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    :goto_8
    :try_start_a
    throw v2
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local v6    # "digest":Ljava/security/MessageDigest;
    .restart local v9    # "total":J
    .restart local v17    # "$i$a$-use-MainActivity$importStockIpsw$1$2\\3\\899\\0":I
    .restart local v22    # "input\\3":Ljava/io/InputStream;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_4
    move-exception v0

    :try_start_b
    invoke-static {v7, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local v6    # "digest":Ljava/security/MessageDigest;
    .end local v9    # "total":J
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .end local v17    # "$i$a$-use-MainActivity$importStockIpsw$1$2\\3\\899\\0":I
    .end local v22    # "input\\3":Ljava/io/InputStream;
    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local v6    # "digest":Ljava/security/MessageDigest;
    .restart local v9    # "total":J
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_5
    move-exception v0

    goto :goto_9

    :catchall_6
    move-exception v0

    move-object/from16 v8, p1

    :goto_9
    move-object v2, v0

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local v6    # "digest":Ljava/security/MessageDigest;
    .end local v9    # "total":J
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    :try_start_c
    throw v2
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_7

    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local v6    # "digest":Ljava/security/MessageDigest;
    .restart local v9    # "total":J
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catchall_7
    move-exception v0

    :try_start_d
    invoke-static {v15, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v0

    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_a
    move-object/from16 v8, p1

    new-instance v0, Ljava/lang/IllegalStateException;

    .line 906
    const-string v2, "\u65e0\u6cd5\u8bfb\u53d6 IPSW"

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v0

    .line 1369
    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :cond_b
    move-object/from16 v8, p1

    const/4 v0, 0x0

    .line 898
    .local v0, "$i$a$-require-MainActivity$importStockIpsw$1$1\\2\\898\\0":I
    invoke-virtual {v8}, Lorg/lighttouch/android/CatalogFirmware;->getLabel()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .end local v0    # "$i$a$-require-MainActivity$importStockIpsw$1$1\\2\\898\\0":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v4    # "partial":Ljava/io/File;
    .end local v5    # "target":Ljava/io/File;
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .end local p2    # "$uri":Landroid/net/Uri;
    throw v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_0
    .catchall {:try_start_d .. :try_end_d} :catchall_9

    .line 911
    .end local v6    # "digest":Ljava/security/MessageDigest;
    .end local v9    # "total":J
    .restart local v4    # "partial":Ljava/io/File;
    .restart local v5    # "target":Ljava/io/File;
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "$chosen":Lorg/lighttouch/android/CatalogFirmware;
    .restart local p2    # "$uri":Landroid/net/Uri;
    :catch_0
    move-exception v0

    goto :goto_a

    .line 914
    :catchall_8
    move-exception v0

    move-object/from16 v8, p1

    goto :goto_c

    .line 911
    :catch_1
    move-exception v0

    move-object/from16 v8, p1

    .line 912
    .local v0, "e":Ljava/lang/Exception;
    :goto_a
    :try_start_e
    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    .line 913
    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v6, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda19;

    invoke-direct {v6, v1, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda19;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v2, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_9

    .line 914
    nop

    .end local v0    # "e":Ljava/lang/Exception;
    :goto_b
    sget-object v0, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/DownloadService$Companion;->release(Landroid/content/Context;)V

    .line 915
    return-void

    .line 914
    :catchall_9
    move-exception v0

    :goto_c
    sget-object v2, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v6}, Lorg/lighttouch/android/DownloadService$Companion;->release(Landroid/content/Context;)V

    throw v0
.end method

.method private static final importStockIpsw$lambda$180$lambda$174$lambda$173$lambda$172(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$LongRef;J)V
    .locals 5
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$done"    # Lkotlin/jvm/internal/Ref$LongRef;
    .param p2, "$total"    # J

    .line 904
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    iget-wide v1, p1, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    const/16 v3, 0x64

    int-to-long v3, v3

    mul-long/2addr v1, v3

    div-long/2addr v1, p2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Copying and checking\u2026 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "%"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setIpswChecking(Ljava/lang/String;)V

    return-void
.end method

.method private static final importStockIpsw$lambda$180$lambda$175(B)Ljava/lang/CharSequence;
    .locals 2
    .param p0, "it"    # B

    .line 907
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02x"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private static final importStockIpsw$lambda$180$lambda$178(Lorg/lighttouch/android/MainActivity;Ljava/io/File;Lorg/lighttouch/android/CatalogFirmware;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$target"    # Ljava/io/File;
    .param p2, "$chosen"    # Lorg/lighttouch/android/CatalogFirmware;

    .line 910
    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    const-string v1, "getAbsolutePath(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p2}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->rememberIpsw(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v1, ""

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setIpswChecking(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    return-void
.end method

.method private static final importStockIpsw$lambda$180$lambda$179(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 913
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, "\u65e0\u6cd5\u4f7f\u7528\u8be5 IPSW"

    :cond_0
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setIpswError(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v1, ""

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setIpswChecking(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    return-void
.end method

.method private static final installer_delegate$lambda$1(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreInstaller;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 82
    sget-object v0, Lorg/lighttouch/android/StoreInstaller;->Companion:Lorg/lighttouch/android/StoreInstaller$Companion;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/StoreInstaller$Companion;->of(Landroid/content/Context;)Lorg/lighttouch/android/StoreInstaller;

    move-result-object v0

    return-object v0
.end method

.method private final installsFinished()V
    .locals 4

    .line 1259
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v0

    const-string v1, "running"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSessionOwned()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/Screen;->HITCH:Lorg/lighttouch/android/Screen;

    if-ne v0, v1, :cond_0

    goto :goto_0

    .line 1260
    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    .line 1261
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_1
    const/4 v1, 0x1

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->pausedByBackground:Z

    .line 1262
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda97;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda97;-><init>(Lorg/lighttouch/android/IEngine;)V

    const-string v3, "install-idle-pause"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 1263
    return-void

    .line 1259
    .end local v0    # "worker":Lorg/lighttouch/android/IEngine;
    :cond_2
    :goto_0
    return-void
.end method

.method private static final installsFinished$lambda$259(Lorg/lighttouch/android/IEngine;)V
    .locals 1
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;

    .line 1262
    const/4 v0, 0x1

    :try_start_0
    invoke-interface {p0, v0}, Lorg/lighttouch/android/IEngine;->pause(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    :goto_0
    return-void
.end method

.method private static final localIpa$lambda$6(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 92
    if-eqz p1, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/StoreModel;->installLocal(Landroid/net/Uri;)V

    :cond_0
    return-void
.end method

.method private final mayClaimDisplay()Z
    .locals 3

    .line 183
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->displayResumed:Z

    if-eqz v0, :cond_0

    sget-object v0, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v0}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v0

    iget-wide v1, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    invoke-virtual {v0, p0, v1, v2}, Lorg/lighttouch/android/ActiveDisplayOwner;->canClaim(Ljava/lang/Object;J)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static final microphonePermission$lambda$0(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "granted"    # Z

    .line 74
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/AppSettings;->setMicrophone(Z)V

    .line 75
    if-nez p1, :cond_0

    const-string v0, "\u6ca1\u6709\u9ea6\u514b\u98ce\u6743\u9650\u65f6\uff0c\u6a21\u62df\u8bbe\u5907\u5c06\u6ca1\u6709\u97f3\u9891\u8f93\u5165\u3002"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 76
    :cond_0
    return-void
.end method

.method private static final monitor$lambda$11(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 103
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    return-object v0
.end method

.method private static final notificationPermission$lambda$5(Z)V
    .locals 0
    .param p0, "it"    # Z

    .line 85
    return-void
.end method

.method private static final onCreate$lambda$35(Lorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 308
    sget-object v0, Lorg/lighttouch/android/WorkerExitEvidence;->INSTANCE:Lorg/lighttouch/android/WorkerExitEvidence;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/lighttouch/android/WorkerExitEvidence;->capture(Landroid/content/Context;I)V

    return-void
.end method

.method private static final onCreate$lambda$41(Lorg/lighttouch/android/MainActivity;)V
    .locals 16
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 319
    move-object/from16 v1, p0

    .line 320
    :try_start_0
    sget-object v0, Lorg/lighttouch/android/FirmwareCatalog;->INSTANCE:Lorg/lighttouch/android/FirmwareCatalog;

    move-object v2, v1

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/FirmwareCatalog;->load(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    .line 321
    .local v0, "catalog":Ljava/util/List;
    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$associate\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1476
    .local v3, "$i$f$associate\\1\\321":I
    const/16 v4, 0xa

    invoke-static {v2, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-static {v5}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v5

    const/16 v6, 0x10

    invoke-static {v5, v6}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v5

    .line 1477
    .local v5, "capacity\\1":I
    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6, v5}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v6, Ljava/util/Map;

    .local v6, "destination\\2":Ljava/util/Map;
    move-object v7, v2

    .local v7, "$this$associateTo\\2":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 1478
    .local v8, "$i$f$associateTo\\2\\1477":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_0

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 1479
    .local v10, "element\\2":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/lighttouch/android/CatalogFirmware;

    .local v11, "it\\3":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v12, 0x0

    .line 321
    .local v12, "$i$a$-associate-MainActivity$onCreate$7$1\\3\\1479\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/CatalogFirmware;->getBoard()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11}, Lorg/lighttouch/android/CatalogFirmware;->getBuild()Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v15, "-"

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    sget-object v14, Lorg/lighttouch/android/StoreTarget;->Companion:Lorg/lighttouch/android/StoreTarget$Companion;

    invoke-virtual {v11}, Lorg/lighttouch/android/CatalogFirmware;->getProductType()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v11}, Lorg/lighttouch/android/CatalogFirmware;->getVersion()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v15, v4}, Lorg/lighttouch/android/StoreTarget$Companion;->of(Ljava/lang/String;Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;

    move-result-object v4

    invoke-static {v13, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    .line 1479
    .end local v11    # "it\\3":Lorg/lighttouch/android/CatalogFirmware;
    .end local v12    # "$i$a$-associate-MainActivity$onCreate$7$1\\3\\1479\\0":I
    invoke-virtual {v4}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v4}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v6, v11, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0xa

    goto :goto_0

    .line 1481
    .end local v10    # "element\\2":Ljava/lang/Object;
    :cond_0
    nop

    .line 1477
    .end local v6    # "destination\\2":Ljava/util/Map;
    .end local v7    # "$this$associateTo\\2":Ljava/lang/Iterable;
    .end local v8    # "$i$f$associateTo\\2\\1477":I
    nop

    .line 321
    .end local v2    # "$this$associate\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$associate\\1\\321":I
    .end local v5    # "capacity\\1":I
    iput-object v6, v1, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    .line 323
    new-instance v2, Ljava/io/File;

    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;

    const-string v4, "libfirmwarekit.so"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->canExecute()Z

    move-result v2

    if-eqz v2, :cond_2

    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\4":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1482
    .local v3, "$i$f$map\\4\\323":I
    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v2, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\5":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapTo\\5":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1483
    .local v6, "$i$f$mapTo\\5\\1482":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_1

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 1484
    .local v8, "item\\5":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/CatalogFirmware;

    .local v9, "it\\6":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v10, 0x0

    .line 323
    .local v10, "$i$a$-map-MainActivity$onCreate$7$supported$1\\6\\1484\\0":I
    invoke-virtual {v9}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v11

    .line 1484
    .end local v9    # "it\\6":Lorg/lighttouch/android/CatalogFirmware;
    .end local v10    # "$i$a$-map-MainActivity$onCreate$7$supported$1\\6\\1484\\0":I
    invoke-interface {v4, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 1485
    .end local v8    # "item\\5":Ljava/lang/Object;
    :cond_1
    nop

    .end local v4    # "destination\\5":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\5":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\5\\1482":I
    check-cast v4, Ljava/util/List;

    .line 1482
    nop

    .end local v2    # "$this$map\\4":Ljava/lang/Iterable;
    .end local v3    # "$i$f$map\\4\\323":I
    check-cast v4, Ljava/lang/Iterable;

    .line 323
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v2

    goto :goto_2

    :cond_2
    invoke-static {}, Lkotlin/collections/SetsKt;->emptySet()Ljava/util/Set;

    move-result-object v2

    .line 324
    .local v2, "supported":Ljava/util/Set;
    :goto_2
    iget-object v3, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda30;

    invoke-direct {v4, v1, v0, v2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda30;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/util/Set;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "catalog":Ljava/util/List;
    .end local v2    # "supported":Ljava/util/Set;
    goto :goto_3

    .line 325
    :catch_0
    move-exception v0

    .line 326
    :goto_3
    return-void
.end method

.method private static final onCreate$lambda$41$lambda$40(Lorg/lighttouch/android/MainActivity;Ljava/util/List;Ljava/util/Set;)V
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$catalog"    # Ljava/util/List;
    .param p2, "$supported"    # Ljava/util/Set;

    .line 324
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/PrepareState;->setCatalog(Ljava/util/List;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/PrepareState;->setSupported(Ljava/util/Set;)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getCatalogVersion()I

    move-result v0

    const/4 v1, 0x1

    add-int/2addr v0, v1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setCatalogVersion(I)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v0

    sget-object v2, Lorg/lighttouch/android/Screen;->STORE:Lorg/lighttouch/android/Screen;

    if-ne v0, v2, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->selectedRecordId()Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->recordTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lorg/lighttouch/android/StoreModel;->useRecord(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)V

    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    :cond_1
    return-void
.end method

.method private static final onPostResume$lambda$258(Lorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1224
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pausedByBackground:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->displayResumed:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v0

    const-string v2, "paused"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/MainActivity;->setPaused(Z)V

    .line 1225
    :cond_0
    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->pausedByBackground:Z

    .line 1226
    return-void
.end method

.method private final openDeviceFiles()V
    .locals 2

    .line 753
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getBusy()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 754
    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->releaseFirmware()V

    .line 755
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/SetupState;->reset(Z)V

    sget-object v0, Lorg/lighttouch/android/Screen;->SETUP:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 756
    return-void

    .line 753
    :cond_1
    :goto_0
    return-void
.end method

.method private static final openHitch$lambda$56(ZLorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V
    .locals 6
    .param p0, "$running"    # Z
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 496
    nop

    .line 499
    const/4 v0, 0x0

    if-eqz p0, :cond_0

    :try_start_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->frontmostApp()Landroid/os/Bundle;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 504
    :catch_0
    move-exception v0

    goto :goto_1

    .line 499
    :catch_1
    move-exception v1

    .line 500
    .local v0, "app":Landroid/os/Bundle;
    :cond_0
    :goto_0
    if-eqz p0, :cond_1

    :try_start_1
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda53;

    invoke-direct {v2, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda53;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 501
    :cond_1
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->hitchSnapshot()Landroid/os/Bundle;

    move-result-object v1

    move-object v2, v1

    .line 1369
    .local v2, "$this$openHitch_u24lambda_u2456_u24lambda_u2453\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 501
    .local v3, "$i$a$-apply-MainActivity$openHitch$1$snapshot$1\\1\\501\\0":I
    if-eqz v0, :cond_2

    move-object v4, v0

    .line 1369
    .local v4, "it\\2":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 501
    .local v5, "$i$a$-let-MainActivity$openHitch$1$snapshot$1$1\\2\\501\\1":I
    invoke-virtual {v2, v4}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 502
    .end local v2    # "$this$openHitch_u24lambda_u2456_u24lambda_u2453\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-MainActivity$openHitch$1$snapshot$1\\1\\501\\0":I
    .end local v4    # "it\\2":Landroid/os/Bundle;
    .end local v5    # "$i$a$-let-MainActivity$openHitch$1$snapshot$1$1\\2\\501\\1":I
    .local v1, "snapshot":Landroid/os/Bundle;
    :cond_2
    sget-object v2, Lorg/lighttouch/android/HitchData;->Companion:Lorg/lighttouch/android/HitchData$Companion;

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v2, v1}, Lorg/lighttouch/android/HitchData$Companion;->load(Landroid/os/Bundle;)Lorg/lighttouch/android/HitchData;

    move-result-object v2

    .line 503
    .local v2, "data":Lorg/lighttouch/android/HitchData;
    iget-object v3, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda54;

    invoke-direct {v4, p2, v2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda54;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .end local v0    # "app":Landroid/os/Bundle;
    .end local v1    # "snapshot":Landroid/os/Bundle;
    .end local v2    # "data":Lorg/lighttouch/android/HitchData;
    goto :goto_2

    .line 504
    .local v0, "e":Ljava/lang/Exception;
    :goto_1
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda55;

    invoke-direct {v2, p2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda55;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 505
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    return-void
.end method

.method private static final openHitch$lambda$56$lambda$51(Lorg/lighttouch/android/MainActivity;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 500
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/Screen;->HITCH:Lorg/lighttouch/android/Screen;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPaused(Z)V

    :cond_0
    return-void
.end method

.method private static final openHitch$lambda$56$lambda$54(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$data"    # Lorg/lighttouch/android/HitchData;

    .line 503
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v0

    sget-object v1, Lorg/lighttouch/android/Screen;->HITCH:Lorg/lighttouch/android/Screen;

    if-ne v0, v1, :cond_0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setHitchData(Lorg/lighttouch/android/HitchData;)V

    :cond_0
    return-void
.end method

.method private static final openHitch$lambda$56$lambda$55(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 504
    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, "\u5e27\u5386\u53f2\u4e0d\u53ef\u7528"

    :cond_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchError(Ljava/lang/String;)V

    return-void
.end method

.method private final openStore()V
    .locals 3

    .line 1206
    sget-object v0, Lorg/lighttouch/android/Screen;->STORE:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 1207
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreModel;->close()V

    .line 1208
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->selectedRecordId()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->recordTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/lighttouch/android/StoreModel;->useRecord(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)V

    .line 1209
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getMuxSocket()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreModel;->refreshGuest()V

    .line 1210
    :cond_1
    return-void
.end method

.method private final ownsDisplay()Z
    .locals 3

    .line 182
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    if-eqz v0, :cond_0

    sget-object v0, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v0}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v0

    iget-wide v1, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    invoke-virtual {v0, p0, v1, v2}, Lorg/lighttouch/android/ActiveDisplayOwner;->owns(Ljava/lang/Object;J)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private static final pickFolder$lambda$26(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 290
    if-eqz p1, :cond_0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1, v1, v0, v1}, Lorg/lighttouch/android/MainActivity;->scanFolder$default(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)V

    :cond_0
    return-void
.end method

.method private static final pickGuestToolsFile$lambda$29(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 293
    if-eqz p1, :cond_0

    const-string v0, "guest.itpack"

    invoke-direct {p0, p1, v0}, Lorg/lighttouch/android/MainActivity;->copyAsset(Landroid/net/Uri;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method private static final pickRom$lambda$28(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 292
    if-eqz p1, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->picked(Landroid/net/Uri;)Lorg/lighttouch/android/PickedFile;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setRom(Lorg/lighttouch/android/PickedFile;)V

    :cond_0
    return-void
.end method

.method private static final pickSystem$lambda$27(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 291
    if-eqz p1, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->picked(Landroid/net/Uri;)Lorg/lighttouch/android/PickedFile;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SetupState;->setSystem(Lorg/lighttouch/android/PickedFile;)V

    :cond_0
    return-void
.end method

.method private final picked(Landroid/net/Uri;)Lorg/lighttouch/android/PickedFile;
    .locals 7
    .param p1, "uri"    # Landroid/net/Uri;

    .line 528
    new-instance v0, Lorg/lighttouch/android/PickedFile;

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->displayName(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v2

    const/16 v5, 0xc

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v1, p1

    .end local p1    # "uri":Landroid/net/Uri;
    .local v1, "uri":Landroid/net/Uri;
    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/PickedFile;-><init>(Landroid/net/Uri;Ljava/lang/String;ZLjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private final pollPreparation(Landroid/os/Bundle;)V
    .locals 10
    .param p1, "state"    # Landroid/os/Bundle;

    .line 810
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getFirmwareRestarting()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 811
    :cond_0
    const-string v0, "state"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 812
    .local v1, "phase":Ljava/lang/String;
    const-string v2, "idle"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_1

    move v3, v4

    goto :goto_0

    :cond_1
    move v3, v5

    :goto_0
    if-eqz v3, :cond_2

    return-void

    .line 813
    :cond_2
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_4

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v2}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_3

    invoke-virtual {v2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_3
    move-object v0, v3

    :goto_1
    const-string v2, "starting"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, v3}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    return-void

    .line 815
    :cond_4
    const/4 v0, 0x2

    new-array v2, v0, [Ljava/lang/String;

    const-string v6, "failed"

    aput-object v6, v2, v5

    const-string v7, "cancelled"

    aput-object v7, v2, v4

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    invoke-static {v2, v1}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v2}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v2

    if-nez v2, :cond_5

    return-void

    .line 817
    :cond_5
    new-array v0, v0, [Ljava/lang/String;

    aput-object v6, v0, v5

    aput-object v7, v0, v4

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-static {v0, v1}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    sget-object v0, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/PreparationNote;->clear(Landroid/content/Context;)V

    .line 818
    :cond_6
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    .line 819
    const-string v0, "complete"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const-string v6, "destination"

    if-eqz v2, :cond_8

    invoke-virtual {p1, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v7, p0, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    invoke-static {v2, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8

    .line 820
    invoke-virtual {p1, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_7

    const-string v2, ""

    :cond_7
    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    .line 821
    const-string v2, "preparation-imports"

    invoke-virtual {p0, v2, v5}, Lorg/lighttouch/android/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v7, "pendingPrepared"

    iget-object v8, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    invoke-interface {v2, v7, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 823
    :cond_8
    const-string v2, "firmwareId"

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_b

    move-object v7, v2

    .line 1369
    .local v7, "it\\1":Ljava/lang/String;
    const/4 v8, 0x0

    .line 823
    .local v8, "$i$a$-takeIf-MainActivity$pollPreparation$1\\1\\823\\0":I
    move-object v9, v7

    check-cast v9, Ljava/lang/CharSequence;

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-lez v9, :cond_9

    goto :goto_2

    :cond_9
    move v4, v5

    .end local v7    # "it\\1":Ljava/lang/String;
    .end local v8    # "$i$a$-takeIf-MainActivity$pollPreparation$1\\1\\823\\0":I
    :goto_2
    if-eqz v4, :cond_a

    move-object v3, v2

    :cond_a
    if-eqz v3, :cond_b

    .line 1369
    .local v3, "it\\2":Ljava/lang/String;
    const/4 v2, 0x0

    .line 823
    .local v2, "$i$a$-let-MainActivity$pollPreparation$2\\2\\823\\0":I
    iget-object v4, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v4, v3}, Lorg/lighttouch/android/PrepareState;->setFirmwareId(Ljava/lang/String;)V

    .line 825
    .end local v2    # "$i$a$-let-MainActivity$pollPreparation$2\\2\\823\\0":I
    .end local v3    # "it\\2":Ljava/lang/String;
    :cond_b
    iget-boolean v2, p0, Lorg/lighttouch/android/MainActivity;->preparedImportInFlight:Z

    if-nez v2, :cond_c

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getCatalog()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_c

    invoke-virtual {p1, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_c

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->importPreparedOutput(Landroid/os/Bundle;)V

    .line 826
    :cond_c
    return-void
.end method

.method private final preferSixtyHertz(Z)V
    .locals 16
    .param p1, "guestInFront"    # Z

    .line 278
    move-object/from16 v0, p0

    iget v1, v0, Lorg/lighttouch/android/MainActivity;->sixtyHertzMode:I

    if-gez v1, :cond_c

    .line 279
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1e

    if-lt v1, v3, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getDisplay()Landroid/view/Display;

    move-result-object v1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    :goto_0
    if-nez v1, :cond_1

    return-void

    .line 280
    .local v1, "current":Landroid/view/Display;
    :cond_1
    invoke-virtual {v1}, Landroid/view/Display;->getMode()Landroid/view/Display$Mode;

    move-result-object v3

    .line 281
    .local v3, "size":Landroid/view/Display$Mode;
    nop

    .line 284
    nop

    .line 281
    invoke-virtual {v1}, Landroid/view/Display;->getSupportedModes()[Landroid/view/Display$Mode;

    move-result-object v4

    const-string v5, "getSupportedModes(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, [Ljava/lang/Object;

    .line 282
    nop

    .local v4, "$this$filter\\1":[Ljava/lang/Object;
    const/4 v5, 0x0

    .line 1370
    .local v5, "$i$f$filter\\1\\282":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\2":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$filterTo\\2":[Ljava/lang/Object;
    const/4 v8, 0x0

    .line 1371
    .local v8, "$i$f$filterTo\\2\\1370":I
    array-length v9, v7

    const/4 v10, 0x0

    :goto_1
    const/4 v11, 0x1

    if-ge v10, v9, :cond_4

    aget-object v12, v7, v10

    .local v12, "element\\2":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Landroid/view/Display$Mode;

    .local v13, "it\\3":Landroid/view/Display$Mode;
    const/4 v14, 0x0

    .line 282
    .local v14, "$i$a$-filter-MainActivity$preferSixtyHertz$1\\3\\1371\\0":I
    invoke-virtual {v13}, Landroid/view/Display$Mode;->getPhysicalWidth()I

    move-result v15

    invoke-virtual {v3}, Landroid/view/Display$Mode;->getPhysicalWidth()I

    move-result v2

    if-ne v15, v2, :cond_2

    invoke-virtual {v13}, Landroid/view/Display$Mode;->getPhysicalHeight()I

    move-result v2

    invoke-virtual {v3}, Landroid/view/Display$Mode;->getPhysicalHeight()I

    move-result v15

    if-ne v2, v15, :cond_2

    goto :goto_2

    :cond_2
    const/4 v11, 0x0

    .line 1371
    .end local v13    # "it\\3":Landroid/view/Display$Mode;
    .end local v14    # "$i$a$-filter-MainActivity$preferSixtyHertz$1\\3\\1371\\0":I
    :goto_2
    if-eqz v11, :cond_3

    invoke-interface {v6, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v12    # "element\\2":Ljava/lang/Object;
    :cond_3
    add-int/lit8 v10, v10, 0x1

    goto :goto_1

    .line 1372
    :cond_4
    nop

    .end local v6    # "destination\\2":Ljava/util/Collection;
    .end local v7    # "$this$filterTo\\2":[Ljava/lang/Object;
    .end local v8    # "$i$f$filterTo\\2\\1370":I
    move-object v2, v6

    check-cast v2, Ljava/util/List;

    .line 1370
    nop

    .line 282
    .end local v4    # "$this$filter\\1":[Ljava/lang/Object;
    .end local v5    # "$i$f$filter\\1\\282":I
    check-cast v2, Ljava/lang/Iterable;

    .line 283
    nop

    .local v2, "$this$minByOrNull\\4":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1373
    .local v4, "$i$f$minByOrNull\\4\\283":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    .line 1374
    .local v5, "iterator\\4":Ljava/util/Iterator;
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x0

    const/high16 v8, 0x42700000    # 60.0f

    if-nez v6, :cond_5

    move-object v6, v7

    goto :goto_3

    .line 1375
    :cond_5
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 1376
    .local v6, "minElem\\4":Ljava/lang/Object;
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-nez v9, :cond_6

    goto :goto_3

    .line 1377
    :cond_6
    move-object v9, v6

    check-cast v9, Landroid/view/Display$Mode;

    .local v9, "it\\5":Landroid/view/Display$Mode;
    const/4 v10, 0x0

    .line 283
    .local v10, "$i$a$-minByOrNull-MainActivity$preferSixtyHertz$2\\5\\1377\\0":I
    invoke-virtual {v9}, Landroid/view/Display$Mode;->getRefreshRate()F

    move-result v12

    sub-float/2addr v12, v8

    invoke-static {v12}, Ljava/lang/Math;->abs(F)F

    move-result v12

    .line 1377
    .end local v9    # "it\\5":Landroid/view/Display$Mode;
    .end local v10    # "$i$a$-minByOrNull-MainActivity$preferSixtyHertz$2\\5\\1377\\0":I
    nop

    .line 1379
    .local v12, "minValue\\4":F
    :cond_7
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .line 1380
    .local v9, "e\\4":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Landroid/view/Display$Mode;

    .local v10, "it\\6":Landroid/view/Display$Mode;
    const/4 v13, 0x0

    .line 283
    .local v13, "$i$a$-minByOrNull-MainActivity$preferSixtyHertz$2\\6\\1380\\0":I
    invoke-virtual {v10}, Landroid/view/Display$Mode;->getRefreshRate()F

    move-result v14

    sub-float/2addr v14, v8

    invoke-static {v14}, Ljava/lang/Math;->abs(F)F

    move-result v14

    .line 1380
    .end local v10    # "it\\6":Landroid/view/Display$Mode;
    .end local v13    # "$i$a$-minByOrNull-MainActivity$preferSixtyHertz$2\\6\\1380\\0":I
    nop

    .line 1381
    .local v14, "v\\4":F
    invoke-static {v12, v14}, Ljava/lang/Float;->compare(FF)I

    move-result v10

    if-lez v10, :cond_8

    .line 1382
    move-object v6, v9

    .line 1383
    move v10, v14

    move v12, v10

    .line 1385
    .end local v9    # "e\\4":Ljava/lang/Object;
    .end local v14    # "v\\4":F
    :cond_8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-nez v9, :cond_7

    .line 1386
    nop

    .line 283
    .end local v2    # "$this$minByOrNull\\4":Ljava/lang/Iterable;
    .end local v4    # "$i$f$minByOrNull\\4\\283":I
    .end local v5    # "iterator\\4":Ljava/util/Iterator;
    .end local v6    # "minElem\\4":Ljava/lang/Object;
    .end local v12    # "minValue\\4":F
    :goto_3
    check-cast v6, Landroid/view/Display$Mode;

    .line 284
    if-eqz v6, :cond_b

    .line 281
    nop

    .line 284
    nop

    .line 1369
    move-object v2, v6

    .local v2, "it\\7":Landroid/view/Display$Mode;
    const/4 v4, 0x0

    .line 284
    .local v4, "$i$a$-takeIf-MainActivity$preferSixtyHertz$3\\7\\284\\0":I
    invoke-virtual {v2}, Landroid/view/Display$Mode;->getRefreshRate()F

    move-result v5

    sub-float/2addr v5, v8

    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v5

    const/high16 v8, 0x3f800000    # 1.0f

    cmpg-float v5, v5, v8

    if-gez v5, :cond_9

    goto :goto_4

    :cond_9
    const/4 v11, 0x0

    .end local v2    # "it\\7":Landroid/view/Display$Mode;
    .end local v4    # "$i$a$-takeIf-MainActivity$preferSixtyHertz$3\\7\\284\\0":I
    :goto_4
    if-eqz v11, :cond_a

    move-object v7, v6

    :cond_a
    if-eqz v7, :cond_b

    .line 281
    nop

    .line 284
    invoke-virtual {v7}, Landroid/view/Display$Mode;->getModeId()I

    move-result v2

    .line 281
    goto :goto_5

    .line 284
    :cond_b
    const/4 v2, 0x0

    .line 281
    :goto_5
    iput v2, v0, Lorg/lighttouch/android/MainActivity;->sixtyHertzMode:I

    .line 286
    .end local v1    # "current":Landroid/view/Display;
    .end local v3    # "size":Landroid/view/Display$Mode;
    :cond_c
    if-eqz p1, :cond_d

    iget v2, v0, Lorg/lighttouch/android/MainActivity;->sixtyHertzMode:I

    goto :goto_6

    :cond_d
    const/4 v2, 0x0

    .line 287
    .local v2, "mode":I
    :goto_6
    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    iget v1, v1, Landroid/view/WindowManager$LayoutParams;->preferredDisplayModeId:I

    if-eq v1, v2, :cond_e

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v3

    .line 1369
    move-object v4, v3

    .local v4, "$this$preferSixtyHertz_u24lambda_u2425\\8":Landroid/view/WindowManager$LayoutParams;
    const/4 v5, 0x0

    .line 287
    .local v5, "$i$a$-apply-MainActivity$preferSixtyHertz$4\\8\\287\\0":I
    iput v2, v4, Landroid/view/WindowManager$LayoutParams;->preferredDisplayModeId:I

    .end local v4    # "$this$preferSixtyHertz_u24lambda_u2425\\8":Landroid/view/WindowManager$LayoutParams;
    .end local v5    # "$i$a$-apply-MainActivity$preferSixtyHertz$4\\8\\287\\0":I
    invoke-virtual {v1, v3}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 288
    :cond_e
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x23

    if-lt v1, v3, :cond_f

    invoke-virtual {v0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    xor-int/lit8 v3, p1, 0x1

    invoke-virtual {v1, v3}, Landroid/view/Window;->setFrameRateBoostOnTouchEnabled(Z)V

    .line 289
    :cond_f
    return-void
.end method

.method private static final prepRom$lambda$14(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 160
    if-eqz p1, :cond_0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->importPrepRom(Landroid/net/Uri;)V

    :cond_0
    return-void
.end method

.method private final preparationActive()Z
    .locals 5

    .line 700
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getFirmwareRestarting()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_2

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const-string v2, "starting"

    const/4 v3, 0x0

    aput-object v2, v0, v3

    const-string v2, "preparing"

    aput-object v2, v0, v1

    const/4 v2, 0x2

    const-string v4, "cancelling"

    aput-object v4, v0, v2

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v2}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_0

    const-string v4, "state"

    invoke-virtual {v2, v4}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->contains(Ljava/lang/Iterable;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    move v1, v3

    :cond_2
    :goto_1
    return v1
.end method

.method private static final preparedCopy$lambda$15(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 161
    if-eqz p1, :cond_0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->addPreparedCopy(Landroid/net/Uri;)V

    :cond_0
    return-void
.end method

.method private final pulse(IJ)V
    .locals 7
    .param p1, "button"    # I
    .param p2, "holdMs"    # J

    .line 1073
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    move-object v2, v0

    .line 1074
    .local v2, "worker":Lorg/lighttouch/android/IEngine;
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->buttonCalls:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda40;

    move-object v6, p0

    move v3, p1

    move-wide v4, p2

    .end local p1    # "button":I
    .end local p2    # "holdMs":J
    .local v3, "button":I
    .local v4, "holdMs":J
    invoke-direct/range {v1 .. v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda40;-><init>(Lorg/lighttouch/android/IEngine;IJLorg/lighttouch/android/MainActivity;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 1078
    return-void
.end method

.method private static final pulse$lambda$224(Lorg/lighttouch/android/IEngine;IJLorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$button"    # I
    .param p2, "$holdMs"    # J
    .param p4, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1075
    const/4 v0, 0x1

    :try_start_0
    invoke-interface {p0, p1, v0}, Lorg/lighttouch/android/IEngine;->button(IZ)V

    invoke-static {p2, p3}, Ljava/lang/Thread;->sleep(J)V

    const/4 v0, 0x0

    invoke-interface {p0, p1, v0}, Lorg/lighttouch/android/IEngine;->button(IZ)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1076
    :catch_0
    move-exception v0

    .local v0, "<unused var>":Landroid/os/RemoteException;
    iget-object v1, p4, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda79;

    invoke-direct {v2, p4}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda79;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1077
    .end local v0    # "<unused var>":Landroid/os/RemoteException;
    :goto_0
    return-void
.end method

.method private static final pulse$lambda$224$lambda$223(Lorg/lighttouch/android/MainActivity;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1076
    const-string v0, "\u5ba2\u6237\u673a\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528\uff1b\u8bf7\u542f\u52a8\u4e00\u4e2a\u65b0\u7684\u5de5\u4f5c\u8fdb\u7a0b\u3002"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    return-void
.end method

.method private final recordTarget()Lorg/lighttouch/android/StoreTarget;
    .locals 8

    .line 1203
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1472
    .local v1, "$i$f$firstOrNull\\1\\1203":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v5, v3

    check-cast v5, Landroid/os/Bundle;

    .local v5, "it\\2":Landroid/os/Bundle;
    const/4 v6, 0x0

    .line 1203
    .local v6, "$i$a$-firstOrNull-MainActivity$recordTarget$1\\2\\1472\\0":I
    const-string v7, "selected"

    invoke-virtual {v5, v7}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    .line 1472
    .end local v5    # "it\\2":Landroid/os/Bundle;
    .end local v6    # "$i$a$-firstOrNull-MainActivity$recordTarget$1\\2\\1472\\0":I
    if-eqz v5, :cond_0

    goto :goto_0

    .line 1473
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_1
    move-object v3, v4

    .line 1203
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\1203":I
    :goto_0
    check-cast v3, Landroid/os/Bundle;

    if-eqz v3, :cond_2

    .line 1369
    .local v3, "it\\3":Landroid/os/Bundle;
    const/4 v0, 0x0

    .line 1203
    .local v0, "$i$a$-let-MainActivity$recordTarget$2\\3\\1203\\0":I
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    const-string v2, "board"

    invoke-virtual {v3, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "build"

    invoke-virtual {v3, v4}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, "-"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, Lorg/lighttouch/android/StoreTarget;

    .end local v0    # "$i$a$-let-MainActivity$recordTarget$2\\3\\1203\\0":I
    .end local v3    # "it\\3":Landroid/os/Bundle;
    :cond_2
    return-object v4
.end method

.method private final refreshDevices(Z)V
    .locals 3
    .param p1, "afterDelete"    # Z

    .line 943
    new-instance v0, Ljava/lang/Thread;

    .line 962
    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda116;

    invoke-direct {v1, p0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda116;-><init>(Lorg/lighttouch/android/MainActivity;Z)V

    .line 943
    const-string v2, "device-library"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 962
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 963
    return-void
.end method

.method static synthetic refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V
    .locals 0

    .line 942
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    const/4 p1, 0x0

    :cond_0
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->refreshDevices(Z)V

    return-void
.end method

.method private static final refreshDevices$lambda$196(Lorg/lighttouch/android/MainActivity;Z)V
    .locals 19
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$afterDelete"    # Z

    .line 944
    move-object/from16 v1, p0

    .line 945
    :try_start_0
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .local v0, "loaded":Lkotlin/jvm/internal/Ref$ObjectRef;
    invoke-direct {v1}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v2

    if-eqz v2, :cond_14

    invoke-interface {v2}, Lorg/lighttouch/android/IEngine;->records()[Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_14

    invoke-static {v2}, Lkotlin/collections/ArraysKt;->toList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    if-nez v2, :cond_0

    move/from16 v4, p1

    goto/16 :goto_8

    :cond_0
    iput-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 947
    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_13

    .line 948
    iget-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 1539
    .local v3, "$i$f$mapNotNull\\1\\948":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 1547
    .local v6, "$i$f$mapNotNullTo\\2\\1539":I
    move-object v7, v5

    .local v7, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 1548
    .local v8, "$i$f$forEach\\3\\1547":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1

    const-string v11, "name"

    if-eqz v10, :cond_2

    :try_start_1
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\3":Ljava/lang/Object;
    move-object v12, v10

    .local v12, "element\\4":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 1547
    .local v13, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\1548\\2":I
    move-object v14, v12

    check-cast v14, Landroid/os/Bundle;

    .local v14, "it\\6":Landroid/os/Bundle;
    const/4 v15, 0x0

    .line 948
    .local v15, "$i$a$-mapNotNull-MainActivity$refreshDevices$1$names$1\\6\\1547\\0":I
    invoke-virtual {v14, v11}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 1547
    .end local v14    # "it\\6":Landroid/os/Bundle;
    .end local v15    # "$i$a$-mapNotNull-MainActivity$refreshDevices$1$names$1\\6\\1547\\0":I
    if-eqz v11, :cond_1

    .line 1549
    .local v11, "it\\4":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 1547
    .local v14, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\1549\\4":I
    invoke-interface {v4, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1548
    .end local v11    # "it\\4":Ljava/lang/Object;
    .end local v12    # "element\\4":Ljava/lang/Object;
    .end local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\1548\\2":I
    .end local v14    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\1549\\4":I
    :cond_1
    nop

    .end local v10    # "element\\3":Ljava/lang/Object;
    goto :goto_0

    .line 1550
    :cond_2
    nop

    .line 1551
    .end local v7    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\3\\1547":I
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapNotNullTo\\2\\1539":I
    check-cast v4, Ljava/util/List;

    .line 1539
    nop

    .end local v2    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\1\\948":I
    check-cast v4, Ljava/util/Collection;

    .line 948
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->toMutableList(Ljava/util/Collection;)Ljava/util/List;

    move-result-object v2

    .line 949
    .local v2, "names":Ljava/util/List;
    iget-object v3, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$count\\7":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1552
    .local v4, "$i$f$count\\7\\949":I
    instance-of v5, v3, Ljava/util/Collection;

    if-eqz v5, :cond_3

    move-object v5, v3

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    move-object/from16 v16, v2

    const/4 v6, 0x0

    goto/16 :goto_7

    .line 1553
    :cond_3
    const/4 v5, 0x0

    .line 1554
    .local v5, "count\\7":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_10

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\7":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Landroid/os/Bundle;

    .local v9, "record\\8":Landroid/os/Bundle;
    const/4 v10, 0x0

    .line 950
    .local v10, "$i$a$-count-MainActivity$refreshDevices$1$renamed$1\\8\\1554\\0":I
    invoke-virtual {v9, v11}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    const-string v13, ""

    if-nez v12, :cond_4

    move-object v12, v13

    .local v12, "name\\8":Ljava/lang/String;
    :cond_4
    :try_start_2
    const-string v14, "board"

    invoke-virtual {v9, v14}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-nez v14, :cond_5

    move-object v14, v13

    .local v14, "board\\8":Ljava/lang/String;
    :cond_5
    const-string v15, "build"

    invoke-virtual {v9, v15}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    if-nez v15, :cond_6

    goto :goto_2

    :cond_6
    move-object v13, v15

    .line 951
    .local v13, "build\\8":Ljava/lang/String;
    :goto_2
    invoke-static {v12, v14, v13}, Lorg/lighttouch/android/DevicesKt;->isGeneratedDeviceName(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v15

    if-nez v15, :cond_7

    move-object/from16 v16, v2

    const/4 v15, 0x0

    goto :goto_6

    .line 952
    :cond_7
    iget-object v15, v1, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    move-object v6, v2

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v6, v12}, Lkotlin/collections/CollectionsKt;->minus(Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/util/Collection;

    invoke-static {v14, v13, v15, v6}, Lorg/lighttouch/android/DevicesKt;->defaultDeviceName(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Collection;)Ljava/lang/String;

    move-result-object v6

    .line 953
    .local v6, "friendly\\8":Ljava/lang/String;
    invoke-static {v6, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_c

    invoke-direct {v1}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v15

    if-eqz v15, :cond_8

    move-object/from16 v16, v2

    .end local v2    # "names":Ljava/util/List;
    .local v16, "names":Ljava/util/List;
    const-string v2, "id"

    invoke-virtual {v9, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v15, v2, v6}, Lorg/lighttouch/android/IEngine;->rename(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_3

    .end local v16    # "names":Ljava/util/List;
    .restart local v2    # "names":Ljava/util/List;
    :cond_8
    move-object/from16 v16, v2

    .end local v2    # "names":Ljava/util/List;
    .restart local v16    # "names":Ljava/util/List;
    const/4 v2, 0x0

    :goto_3
    check-cast v2, Ljava/lang/CharSequence;

    if-eqz v2, :cond_a

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-nez v2, :cond_9

    goto :goto_4

    :cond_9
    const/4 v2, 0x0

    goto :goto_5

    :cond_a
    :goto_4
    const/4 v2, 0x1

    :goto_5
    move/from16 v17, v2

    .line 1369
    .local v17, "it\\9":Z
    const/16 v18, 0x0

    .line 953
    .local v18, "$i$a$-also-MainActivity$refreshDevices$1$renamed$1$1\\9\\953\\8":I
    if-eqz v17, :cond_b

    move-object/from16 v15, v16

    check-cast v15, Ljava/util/Collection;

    invoke-interface {v15, v12}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    move-object/from16 v15, v16

    check-cast v15, Ljava/util/Collection;

    invoke-interface {v15, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v17    # "it\\9":Z
    .end local v18    # "$i$a$-also-MainActivity$refreshDevices$1$renamed$1$1\\9\\953\\8":I
    :cond_b
    if-eqz v2, :cond_d

    const/4 v15, 0x1

    goto :goto_6

    .end local v16    # "names":Ljava/util/List;
    .restart local v2    # "names":Ljava/util/List;
    :cond_c
    move-object/from16 v16, v2

    .end local v2    # "names":Ljava/util/List;
    .restart local v16    # "names":Ljava/util/List;
    :cond_d
    const/4 v15, 0x0

    .line 1554
    .end local v6    # "friendly\\8":Ljava/lang/String;
    .end local v9    # "record\\8":Landroid/os/Bundle;
    .end local v10    # "$i$a$-count-MainActivity$refreshDevices$1$renamed$1\\8\\1554\\0":I
    .end local v12    # "name\\8":Ljava/lang/String;
    .end local v13    # "build\\8":Ljava/lang/String;
    .end local v14    # "board\\8":Ljava/lang/String;
    :goto_6
    if-eqz v15, :cond_f

    add-int/lit8 v5, v5, 0x1

    if-gez v5, :cond_e

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v8    # "element\\7":Ljava/lang/Object;
    :cond_e
    move-object/from16 v2, v16

    goto/16 :goto_1

    .restart local v8    # "element\\7":Ljava/lang/Object;
    :cond_f
    move-object/from16 v2, v16

    goto/16 :goto_1

    .line 1555
    .end local v8    # "element\\7":Ljava/lang/Object;
    .end local v16    # "names":Ljava/util/List;
    .restart local v2    # "names":Ljava/util/List;
    :cond_10
    move-object/from16 v16, v2

    .end local v2    # "names":Ljava/util/List;
    .restart local v16    # "names":Ljava/util/List;
    move v6, v5

    .line 949
    .end local v3    # "$this$count\\7":Ljava/lang/Iterable;
    .end local v4    # "$i$f$count\\7\\949":I
    .end local v5    # "count\\7":I
    :goto_7
    nop

    .line 955
    .local v6, "renamed":I
    if-lez v6, :cond_13

    invoke-direct {v1}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v2

    if-eqz v2, :cond_11

    invoke-interface {v2}, Lorg/lighttouch/android/IEngine;->records()[Landroid/os/Bundle;

    move-result-object v2

    if-eqz v2, :cond_11

    invoke-static {v2}, Lkotlin/collections/ArraysKt;->toList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    if-nez v2, :cond_12

    :cond_11
    iget-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    :cond_12
    iput-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 957
    .end local v6    # "renamed":I
    .end local v16    # "names":Ljava/util/List;
    :cond_13
    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda58;
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1

    move/from16 v4, p1

    :try_start_3
    invoke-direct {v3, v1, v0, v4}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda58;-><init>(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_0

    .end local v0    # "loaded":Lkotlin/jvm/internal/Ref$ObjectRef;
    goto :goto_a

    .line 961
    :catch_0
    move-exception v0

    goto :goto_9

    .line 945
    .restart local v0    # "loaded":Lkotlin/jvm/internal/Ref$ObjectRef;
    :cond_14
    move/from16 v4, p1

    :goto_8
    return-void

    .line 961
    .end local v0    # "loaded":Lkotlin/jvm/internal/Ref$ObjectRef;
    :catch_1
    move-exception v0

    move/from16 v4, p1

    .local v0, "e":Landroid/os/RemoteException;
    :goto_9
    iget-object v2, v1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda59;

    invoke-direct {v3, v1, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda59;-><init>(Lorg/lighttouch/android/MainActivity;Landroid/os/RemoteException;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 962
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_a
    return-void
.end method

.method private static final refreshDevices$lambda$196$lambda$194(Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/internal/Ref$ObjectRef;Z)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$loaded"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p2, "$afterDelete"    # Z

    .line 958
    iget-object v0, p1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setRecords(Ljava/util/List;)V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setRecordsLoaded(Z)V

    .line 959
    if-eqz p2, :cond_0

    iget-object v1, p1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/SetupState;->reset(Z)V

    sget-object v0, Lorg/lighttouch/android/Screen;->SETUP:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 960
    :cond_0
    return-void
.end method

.method private static final refreshDevices$lambda$196$lambda$195(Lorg/lighttouch/android/MainActivity;Landroid/os/RemoteException;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Landroid/os/RemoteException;

    .line 961
    invoke-virtual {p1}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Device library unavailable: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    return-void
.end method

.method private final releaseFirmware()V
    .locals 2

    .line 710
    const/4 v0, 0x1

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareExpectedExit:Z

    .line 711
    :try_start_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    if-eqz v0, :cond_1

    invoke-interface {v0}, Lorg/lighttouch/android/IFirmware;->finish()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, "\u56fa\u4ef6\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528"

    :cond_0
    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 712
    .end local v0    # "e":Landroid/os/RemoteException;
    :cond_1
    :goto_0
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    check-cast v0, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    .line 713
    :cond_2
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    .line 714
    return-void
.end method

.method private final rememberIpsw(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "path"    # Ljava/lang/String;
    .param p2, "firmwareId"    # Ljava/lang/String;

    .line 878
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/PrepareState;->setIpswPath(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/PrepareState;->setIpswFor(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v1, ""

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setIpswError(Ljava/lang/String;)V

    .line 879
    const-string v0, "preparation-imports"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ipsw"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "ipswFor"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "firmwareId"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 880
    return-void
.end method

.method private static final renameDevice$lambda$48(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$id"    # Ljava/lang/String;
    .param p2, "$name"    # Ljava/lang/String;
    .param p3, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 474
    :try_start_0
    invoke-interface {p0, p1, p2}, Lorg/lighttouch/android/IEngine;->rename(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, "\u91cd\u547d\u540d\u5931\u8d25"

    :cond_0
    move-object v0, v1

    .line 475
    .local v0, "result":Ljava/lang/String;
    :goto_0
    iget-object v1, p3, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda57;

    invoke-direct {v2, v0, p3, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda57;-><init>(Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 476
    return-void
.end method

.method private static final renameDevice$lambda$48$lambda$47(Ljava/lang/String;Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 4
    .param p0, "$result"    # Ljava/lang/String;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "$name"    # Ljava/lang/String;

    .line 475
    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v0, p0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    move v0, v1

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Renamed to "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    goto :goto_1

    :cond_1
    invoke-direct {p1, p0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    :goto_1
    const/4 v0, 0x0

    invoke-static {p1, v2, v1, v0}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    return-void
.end method

.method private final restartFirmwareForPreparation()V
    .locals 5

    .line 788
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getFirmwareRestarting()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 789
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    const/4 v1, 0x1

    if-nez v0, :cond_1

    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/MainActivity;

    .line 1369
    .local v0, "$this$restartFirmwareForPreparation_u24lambda_u24151\\1":Lorg/lighttouch/android/MainActivity;
    const/4 v2, 0x0

    .line 789
    .local v2, "$i$a$-run-MainActivity$restartFirmwareForPreparation$old$1\\1\\789\\0":I
    iput-boolean v1, v0, Lorg/lighttouch/android/MainActivity;->pendingFirmwareStart:Z

    invoke-direct {v0, v1}, Lorg/lighttouch/android/MainActivity;->setFirmwareRestarting(Z)V

    invoke-direct {v0}, Lorg/lighttouch/android/MainActivity;->bindFirmware()V

    return-void

    .line 790
    .end local v2    # "$i$a$-run-MainActivity$restartFirmwareForPreparation$old$1\\1\\789\\0":I
    .local v0, "old":Lorg/lighttouch/android/IFirmware;
    :cond_1
    invoke-interface {v0}, Lorg/lighttouch/android/IFirmware;->asBinder()Landroid/os/IBinder;

    move-result-object v2

    .line 791
    .local v2, "oldBinder":Landroid/os/IBinder;
    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setFirmwareRestarting(Z)V

    .line 792
    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->firmwareExpectedExit:Z

    .line 793
    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->pendingFirmwareStart:Z

    .line 794
    iget-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    if-eqz v1, :cond_2

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    check-cast v1, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v1, 0x0

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    .line 795
    :cond_2
    new-instance v1, Ljava/lang/Thread;

    .line 807
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda96;

    invoke-direct {v3, v2, v0, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda96;-><init>(Landroid/os/IBinder;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;)V

    .line 795
    const-string v4, "firmware-worker-restart"

    invoke-direct {v1, v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 807
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 808
    return-void
.end method

.method private static final restartFirmwareForPreparation$lambda$156(Landroid/os/IBinder;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;)V
    .locals 7
    .param p0, "$oldBinder"    # Landroid/os/IBinder;
    .param p1, "$old"    # Lorg/lighttouch/android/IFirmware;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 796
    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    .line 797
    .local v0, "died":Ljava/util/concurrent/CountDownLatch;
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda99;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda99;-><init>(Ljava/util/concurrent/CountDownLatch;)V

    .line 798
    .local v2, "recipient":Landroid/os/IBinder$DeathRecipient;
    nop

    .line 799
    const/4 v3, 0x0

    :try_start_0
    invoke-interface {p0}, Landroid/os/IBinder;->isBinderAlive()Z

    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v4, :cond_3

    .line 800
    :try_start_1
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_1
    .catch Landroid/os/DeadObjectException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v4

    .local v4, "<unused var>":Landroid/os/DeadObjectException;
    :try_start_2
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 801
    .end local v4    # "<unused var>":Landroid/os/DeadObjectException;
    :goto_0
    :try_start_3
    invoke-interface {p1}, Lorg/lighttouch/android/IFirmware;->finish()V
    :try_end_3
    .catch Landroid/os/DeadObjectException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    :catch_1
    move-exception v4

    .restart local v4    # "<unused var>":Landroid/os/DeadObjectException;
    :try_start_4
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 802
    .end local v4    # "<unused var>":Landroid/os/DeadObjectException;
    :goto_1
    invoke-interface {p0}, Landroid/os/IBinder;->isBinderAlive()Z

    move-result v4

    if-eqz v4, :cond_1

    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v5, 0x5

    invoke-virtual {v0, v5, v6, v4}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_2

    :cond_0
    move v1, v3

    :cond_1
    :goto_2
    if-eqz v1, :cond_2

    goto :goto_3

    .line 1369
    :cond_2
    const/4 v1, 0x0

    .line 802
    .local v1, "$i$a$-check-MainActivity$restartFirmwareForPreparation$1$3\\1\\802\\0":I
    const-string v4, "\u4e0a\u4e00\u4e2a\u56fa\u4ef6\u5de5\u4f5c\u8fdb\u7a0b\u5c1a\u672a\u9000\u51fa\uff0c\u8bf7\u5f85\u5176\u505c\u6b62\u540e\u91cd\u8bd5\u3002"

    .end local v1    # "$i$a$-check-MainActivity$restartFirmwareForPreparation$1$3\\1\\802\\0":I
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "died":Ljava/util/concurrent/CountDownLatch;
    .end local v2    # "recipient":Landroid/os/IBinder$DeathRecipient;
    .end local p0    # "$oldBinder":Landroid/os/IBinder;
    .end local p1    # "$old":Lorg/lighttouch/android/IFirmware;
    .end local p2    # "this$0":Lorg/lighttouch/android/MainActivity;
    throw v1

    .line 804
    .restart local v0    # "died":Ljava/util/concurrent/CountDownLatch;
    .restart local v2    # "recipient":Landroid/os/IBinder$DeathRecipient;
    .restart local p0    # "$oldBinder":Landroid/os/IBinder;
    .restart local p1    # "$old":Lorg/lighttouch/android/IFirmware;
    .restart local p2    # "this$0":Lorg/lighttouch/android/MainActivity;
    :cond_3
    :goto_3
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda100;

    invoke-direct {v4, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda100;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 806
    :try_start_5
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z
    :try_end_5
    .catch Ljava/util/NoSuchElementException; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_4

    :catch_2
    move-exception v1

    goto :goto_4

    :catchall_0
    move-exception v1

    goto :goto_5

    .line 805
    :catch_3
    move-exception v1

    .local v1, "e":Ljava/lang/Exception;
    :try_start_6
    iget-object v4, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v5, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda101;

    invoke-direct {v5, p2, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda101;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 806
    .end local v1    # "e":Ljava/lang/Exception;
    :try_start_7
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z
    :try_end_7
    .catch Ljava/util/NoSuchElementException; {:try_start_7 .. :try_end_7} :catch_2

    .line 807
    :goto_4
    return-void

    .line 806
    :goto_5
    :try_start_8
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z
    :try_end_8
    .catch Ljava/util/NoSuchElementException; {:try_start_8 .. :try_end_8} :catch_4

    goto :goto_6

    :catch_4
    move-exception v3

    :goto_6
    throw v1
.end method

.method private static final restartFirmwareForPreparation$lambda$156$lambda$152(Ljava/util/concurrent/CountDownLatch;)V
    .locals 0
    .param p0, "$died"    # Ljava/util/concurrent/CountDownLatch;

    .line 797
    invoke-virtual {p0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    return-void
.end method

.method private static final restartFirmwareForPreparation$lambda$156$lambda$154(Lorg/lighttouch/android/MainActivity;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 804
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmware:Lorg/lighttouch/android/IFirmware;

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindFirmware()V

    return-void
.end method

.method private static final restartFirmwareForPreparation$lambda$156$lambda$155(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 805
    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pendingFirmwareStart:Z

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setFirmwareRestarting(Z)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, "\u56fa\u4ef6\u5de5\u4f5c\u8fdb\u7a0b\u91cd\u542f\u5931\u8d25"

    :cond_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    return-void
.end method

.method private final restartGuestForStart(Lorg/lighttouch/android/IEngine;)V
    .locals 4
    .param p1, "old"    # Lorg/lighttouch/android/IEngine;

    .line 1054
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    invoke-virtual {v0}, Lorg/lighttouch/android/SessionDeliveryGate;->advance()J

    .line 1055
    const/4 v0, 0x1

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineRestarting:Z

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineExpectedExit:Z

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestStart:Z

    const-string v0, "stopping"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    .line 1056
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->bound:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->connection:Lorg/lighttouch/android/MainActivity$connection$1;

    check-cast v0, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->bound:Z

    .line 1057
    :cond_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    .line 1058
    .local v0, "binder":Landroid/os/IBinder;
    new-instance v1, Ljava/lang/Thread;

    .line 1069
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda61;

    invoke-direct {v2, v0, p1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda61;-><init>(Landroid/os/IBinder;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V

    .line 1058
    const-string v3, "guest-worker-restart"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1069
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 1070
    return-void
.end method

.method private static final restartGuestForStart$lambda$222(Landroid/os/IBinder;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V
    .locals 7
    .param p0, "$binder"    # Landroid/os/IBinder;
    .param p1, "$old"    # Lorg/lighttouch/android/IEngine;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1059
    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    .local v0, "died":Ljava/util/concurrent/CountDownLatch;
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda84;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda84;-><init>(Ljava/util/concurrent/CountDownLatch;)V

    .line 1060
    .local v2, "recipient":Landroid/os/IBinder$DeathRecipient;
    nop

    .line 1061
    const/4 v3, 0x0

    :try_start_0
    invoke-interface {p0}, Landroid/os/IBinder;->isBinderAlive()Z

    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v4, :cond_3

    .line 1062
    :try_start_1
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_1
    .catch Landroid/os/DeadObjectException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v4

    .local v4, "<unused var>":Landroid/os/DeadObjectException;
    :try_start_2
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 1063
    .end local v4    # "<unused var>":Landroid/os/DeadObjectException;
    :goto_0
    :try_start_3
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->stop()V
    :try_end_3
    .catch Landroid/os/DeadObjectException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    :catch_1
    move-exception v4

    .restart local v4    # "<unused var>":Landroid/os/DeadObjectException;
    :try_start_4
    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 1064
    .end local v4    # "<unused var>":Landroid/os/DeadObjectException;
    :goto_1
    invoke-interface {p0}, Landroid/os/IBinder;->isBinderAlive()Z

    move-result v4

    if-eqz v4, :cond_1

    sget-object v4, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v5, 0x2d

    invoke-virtual {v0, v5, v6, v4}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_2

    :cond_0
    move v1, v3

    :cond_1
    :goto_2
    if-eqz v1, :cond_2

    goto :goto_3

    .line 1369
    :cond_2
    const/4 v1, 0x0

    .line 1064
    .local v1, "$i$a$-check-MainActivity$restartGuestForStart$1$3\\1\\1064\\0":I
    const-string v4, "\u4e0a\u4e00\u4e2a\u5ba2\u6237\u673a\u5de5\u4f5c\u8fdb\u7a0b\u5c1a\u672a\u9000\u51fa\uff0c\u8bf7\u5f85\u5176\u505c\u6b62\u540e\u91cd\u8bd5\u3002"

    .end local v1    # "$i$a$-check-MainActivity$restartGuestForStart$1$3\\1\\1064\\0":I
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "died":Ljava/util/concurrent/CountDownLatch;
    .end local v2    # "recipient":Landroid/os/IBinder$DeathRecipient;
    .end local p0    # "$binder":Landroid/os/IBinder;
    .end local p1    # "$old":Lorg/lighttouch/android/IEngine;
    .end local p2    # "this$0":Lorg/lighttouch/android/MainActivity;
    throw v1

    .line 1066
    .restart local v0    # "died":Ljava/util/concurrent/CountDownLatch;
    .restart local v2    # "recipient":Landroid/os/IBinder$DeathRecipient;
    .restart local p0    # "$binder":Landroid/os/IBinder;
    .restart local p1    # "$old":Lorg/lighttouch/android/IEngine;
    .restart local p2    # "this$0":Lorg/lighttouch/android/MainActivity;
    :cond_3
    :goto_3
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda95;

    invoke-direct {v4, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda95;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 1068
    :try_start_5
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z
    :try_end_5
    .catch Ljava/util/NoSuchElementException; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_4

    :catch_2
    move-exception v1

    goto :goto_4

    :catchall_0
    move-exception v1

    goto :goto_5

    .line 1067
    :catch_3
    move-exception v1

    .local v1, "failure":Ljava/lang/Exception;
    :try_start_6
    iget-object v4, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v5, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda106;

    invoke-direct {v5, p2, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda106;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 1068
    .end local v1    # "failure":Ljava/lang/Exception;
    :try_start_7
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z
    :try_end_7
    .catch Ljava/util/NoSuchElementException; {:try_start_7 .. :try_end_7} :catch_2

    .line 1069
    :goto_4
    return-void

    .line 1068
    :goto_5
    :try_start_8
    invoke-interface {p0, v2, v3}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z
    :try_end_8
    .catch Ljava/util/NoSuchElementException; {:try_start_8 .. :try_end_8} :catch_4

    goto :goto_6

    :catch_4
    move-exception v3

    :goto_6
    throw v1
.end method

.method private static final restartGuestForStart$lambda$222$lambda$218(Ljava/util/concurrent/CountDownLatch;)V
    .locals 0
    .param p0, "$died"    # Ljava/util/concurrent/CountDownLatch;

    .line 1059
    invoke-virtual {p0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    return-void
.end method

.method private static final restartGuestForStart$lambda$222$lambda$220(Lorg/lighttouch/android/MainActivity;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1066
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setEngine(Lorg/lighttouch/android/IEngine;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setSessionOwned(Z)V

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineRestarting:Z

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindWorker()V

    return-void
.end method

.method private static final restartGuestForStart$lambda$222$lambda$221(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$failure"    # Ljava/lang/Exception;

    .line 1067
    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineRestarting:Z

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestStart:Z

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const-string v0, "\u5ba2\u6237\u673a\u5de5\u4f5c\u8fdb\u7a0b\u91cd\u542f\u5931\u8d25"

    :cond_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    const-string v0, "failed"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    return-void
.end method

.method private final resumePreparation()V
    .locals 9

    .line 673
    sget-object v0, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PreparationNote;->read(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 674
    .local v0, "note":Lorg/json/JSONObject;
    :cond_0
    const-string v1, "destination"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 675
    .local v1, "job":Ljava/lang/String;
    const-string v2, "firmwareId"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object v3, v2

    .line 1369
    .local v3, "it\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 675
    .local v4, "$i$a$-takeIf-MainActivity$resumePreparation$1\\1\\675\\0":I
    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v5, v3

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-lez v5, :cond_1

    move v5, v7

    goto :goto_0

    :cond_1
    move v5, v6

    .end local v3    # "it\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-takeIf-MainActivity$resumePreparation$1\\1\\675\\0":I
    :goto_0
    const/4 v3, 0x0

    if-eqz v5, :cond_2

    goto :goto_1

    :cond_2
    move-object v2, v3

    :goto_1
    if-eqz v2, :cond_3

    .line 1369
    .local v2, "it\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 675
    .local v4, "$i$a$-let-MainActivity$resumePreparation$2\\2\\675\\0":I
    iget-object v5, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v5, v2}, Lorg/lighttouch/android/PrepareState;->setFirmwareId(Ljava/lang/String;)V

    .line 681
    .end local v2    # "it\\2":Ljava/lang/String;
    .end local v4    # "$i$a$-let-MainActivity$resumePreparation$2\\2\\675\\0":I
    :cond_3
    const-string v2, "state"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_b

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_0

    goto/16 :goto_3

    :sswitch_0
    const-string v3, "complete"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4

    goto/16 :goto_3

    .line 691
    :cond_4
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_5

    new-instance v2, Ljava/io/File;

    const-string v3, "device.lock.json"

    invoke-direct {v2, v1, v3}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    move-result v2

    if-eqz v2, :cond_5

    .line 692
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    iput-object v1, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    iput-boolean v7, p0, Lorg/lighttouch/android/MainActivity;->addRetainedWhenReady:Z

    .line 693
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->retainedPreparation()Landroid/os/Bundle;

    move-result-object v3

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    .line 694
    invoke-direct {p0, v7}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindFirmware()V

    goto/16 :goto_4

    .line 695
    :cond_5
    sget-object v2, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v3, p0

    check-cast v3, Landroid/content/Context;

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/PreparationNote;->clear(Landroid/content/Context;)V

    goto/16 :goto_4

    .line 681
    :sswitch_1
    const-string v4, "preparing"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6

    goto/16 :goto_3

    .line 683
    :cond_6
    const-string v2, "pid"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    .line 684
    .local v2, "pid":I
    :try_start_0
    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "/proc/"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "/cmdline"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {v4, v3, v7, v3}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    const-string v5, ":firmware"

    check-cast v5, Ljava/lang/CharSequence;

    const/4 v8, 0x2

    invoke-static {v4, v5, v6, v8, v3}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v3

    .line 685
    .local v6, "alive":Z
    :goto_2
    if-eqz v6, :cond_7

    invoke-direct {p0, v7}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindFirmware()V

    goto :goto_4

    .line 687
    :cond_7
    new-instance v3, Ljava/lang/Thread;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda94;

    invoke-direct {v4, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda94;-><init>(Ljava/lang/String;)V

    const-string v5, "stale-preparation"

    invoke-direct {v3, v4, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 688
    const-string v3, "Android \u5728\u51c6\u5907\u5b8c\u6210\u524d\u7ec8\u6b62\u4e86\u8fdb\u7a0b\uff0c\u8bf7\u91cd\u8bd5\u3002"

    invoke-static {p0, v3}, Lorg/lighttouch/android/MainActivity;->resumePreparation$failed(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .end local v2    # "pid":I
    .end local v6    # "alive":Z
    goto :goto_4

    .line 681
    :sswitch_2
    const-string v3, "failed"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_8

    goto :goto_3

    .line 696
    :cond_8
    const-string v2, "error"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-nez v3, :cond_9

    move v6, v7

    :cond_9
    if-eqz v6, :cond_a

    .line 1369
    const/4 v2, 0x0

    .line 696
    .local v2, "$i$a$-ifEmpty-MainActivity$resumePreparation$4\\3\\696\\0":I
    nop

    .end local v2    # "$i$a$-ifEmpty-MainActivity$resumePreparation$4\\3\\696\\0":I
    const-string v2, "\u56fa\u4ef6\u51c6\u5907\u5931\u8d25"

    :cond_a
    const-string v3, "ifEmpty(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Ljava/lang/String;

    invoke-static {p0, v2}, Lorg/lighttouch/android/MainActivity;->resumePreparation$failed(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    goto :goto_4

    .line 697
    :cond_b
    :goto_3
    sget-object v2, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v3, p0

    check-cast v3, Landroid/content/Context;

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/PreparationNote;->clear(Landroid/content/Context;)V

    .line 699
    :goto_4
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        -0x4c696bc3 -> :sswitch_2
        -0x3c48fbfc -> :sswitch_1
        -0x23bacec7 -> :sswitch_0
    .end sparse-switch
.end method

.method private static final resumePreparation$failed(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 6
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "error"    # Ljava/lang/String;

    .line 677
    sget-object v0, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PreparationNote;->clear(Landroid/content/Context;)V

    .line 678
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 1369
    move-object v2, v1

    .local v2, "$this$resumePreparation_u24failed_u24lambda_u24113\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 678
    .local v3, "$i$a$-apply-MainActivity$resumePreparation$failed$1\\1\\678\\0":I
    const-string v4, "state"

    const-string v5, "failed"

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v4, "error"

    invoke-virtual {v2, v4, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v4, "consumed"

    const/4 v5, 0x1

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .end local v2    # "$this$resumePreparation_u24failed_u24lambda_u24113\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-MainActivity$resumePreparation$failed$1\\1\\678\\0":I
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    .line 679
    invoke-direct {p0, v5}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    .line 680
    return-void
.end method

.method private static final resumePreparation$lambda$117(Ljava/lang/String;)V
    .locals 9
    .param p0, "$job"    # Ljava/lang/String;

    .line 687
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .line 1369
    .local v1, "it\\1":Ljava/io/File;
    const/4 v2, 0x0

    .line 687
    .local v2, "$i$a$-takeIf-MainActivity$resumePreparation$3$1\\1\\687\\0":I
    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v1

    .end local v1    # "it\\1":Ljava/io/File;
    .end local v2    # "$i$a$-takeIf-MainActivity$resumePreparation$3$1\\1\\687\\0":I
    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_2

    .line 1369
    .local v0, "dir\\2":Ljava/io/File;
    const/4 v1, 0x0

    .line 687
    .local v1, "$i$a$-let-MainActivity$resumePreparation$3$2\\2\\687\\0":I
    invoke-static {v0}, Lkotlin/io/FilesKt;->walkTopDown(Ljava/io/File;)Lkotlin/io/FileTreeWalk;

    move-result-object v2

    check-cast v2, Lkotlin/sequences/Sequence;

    .local v2, "$this$forEach\\3":Lkotlin/sequences/Sequence;
    const/4 v3, 0x0

    .line 1527
    .local v3, "$i$f$forEach\\3\\687":I
    invoke-interface {v2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\3":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Ljava/io/File;

    .local v6, "it\\4":Ljava/io/File;
    const/4 v7, 0x0

    .line 687
    .local v7, "$i$a$-forEach-MainActivity$resumePreparation$3$2$1\\4\\1527\\2":I
    const/4 v8, 0x1

    invoke-virtual {v6, v8, v8}, Ljava/io/File;->setWritable(ZZ)Z

    .line 1527
    .end local v6    # "it\\4":Ljava/io/File;
    .end local v7    # "$i$a$-forEach-MainActivity$resumePreparation$3$2$1\\4\\1527\\2":I
    nop

    .end local v5    # "element\\3":Ljava/lang/Object;
    goto :goto_1

    .line 1528
    :cond_1
    nop

    .line 687
    .end local v2    # "$this$forEach\\3":Lkotlin/sequences/Sequence;
    .end local v3    # "$i$f$forEach\\3\\687":I
    invoke-static {v0}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .end local v0    # "dir\\2":Ljava/io/File;
    .end local v1    # "$i$a$-let-MainActivity$resumePreparation$3$2\\2\\687\\0":I
    :cond_2
    return-void
.end method

.method private final retainedPreparation()Landroid/os/Bundle;
    .locals 9

    .line 662
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v1, v0

    .local v1, "$this$retainedPreparation_u24lambda_u24110\\1":Landroid/os/Bundle;
    const/4 v2, 0x0

    .line 663
    .local v2, "$i$a$-apply-MainActivity$retainedPreparation$1\\1\\662\\0":I
    const-string v3, "state"

    const-string v4, "complete"

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v3, "stage"

    const-string v4, "\u5df2\u4fdd\u7559\u51c6\u5907\u4ea7\u7269"

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 664
    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    const-string v4, "destination"

    invoke-virtual {v1, v4, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v3}, Lorg/lighttouch/android/PrepareState;->getFirmwareId()Ljava/lang/String;

    move-result-object v3

    const-string v5, "firmwareId"

    invoke-virtual {v1, v5, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 665
    const-string v3, "consumed"

    const/4 v5, 0x0

    invoke-virtual {v1, v3, v5}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 666
    sget-object v3, Lorg/lighttouch/android/PreparationNote;->INSTANCE:Lorg/lighttouch/android/PreparationNote;

    move-object v5, p0

    check-cast v5, Landroid/content/Context;

    invoke-virtual {v3, v5}, Lorg/lighttouch/android/PreparationNote;->read(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v5, "timings"

    if-eqz v3, :cond_1

    .line 1369
    move-object v6, v3

    .local v6, "it\\2":Lorg/json/JSONObject;
    const/4 v7, 0x0

    .line 666
    .local v7, "$i$a$-takeIf-MainActivity$retainedPreparation$1$1\\2\\666\\1":I
    invoke-virtual {v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v8, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .end local v6    # "it\\2":Lorg/json/JSONObject;
    .end local v7    # "$i$a$-takeIf-MainActivity$retainedPreparation$1$1\\2\\666\\1":I
    if-eqz v4, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    if-eqz v3, :cond_1

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    :cond_1
    const-string v3, ""

    :cond_2
    invoke-virtual {v1, v5, v3}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 667
    nop

    .line 662
    .end local v1    # "$this$retainedPreparation_u24lambda_u24110\\1":Landroid/os/Bundle;
    .end local v2    # "$i$a$-apply-MainActivity$retainedPreparation$1\\1\\662\\0":I
    nop

    .line 667
    return-object v0
.end method

.method private final saveHitch(JJ)V
    .locals 8
    .param p1, "from"    # J
    .param p3, "to"    # J

    .line 512
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getHitchData()Lorg/lighttouch/android/HitchData;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    move-object v3, v0

    .line 513
    .local v3, "data":Lorg/lighttouch/android/HitchData;
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchSaving(Z)V

    .line 514
    new-instance v0, Ljava/lang/Thread;

    .line 519
    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda82;

    move-object v2, p0

    move-wide v4, p1

    move-wide v6, p3

    .end local p1    # "from":J
    .end local p3    # "to":J
    .local v4, "from":J
    .local v6, "to":J
    invoke-direct/range {v1 .. v7}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda82;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;JJ)V

    .line 514
    const-string p1, "hitch-report"

    invoke-direct {v0, v1, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 519
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 520
    return-void
.end method

.method private static final saveHitch$lambda$59(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/HitchData;JJ)V
    .locals 6
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$data"    # Lorg/lighttouch/android/HitchData;
    .param p2, "$from"    # J
    .param p4, "$to"    # J

    .line 515
    nop

    .line 516
    :try_start_0
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "getApplicationContext(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-object v1, p1

    move-wide v2, p2

    move-wide v4, p4

    .end local p1    # "$data":Lorg/lighttouch/android/HitchData;
    .end local p2    # "$from":J
    .end local p4    # "$to":J
    .local v1, "$data":Lorg/lighttouch/android/HitchData;
    .local v2, "$from":J
    .local v4, "$to":J
    :try_start_1
    invoke-static/range {v0 .. v5}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport(Landroid/content/Context;Lorg/lighttouch/android/HitchData;JJ)Landroid/net/Uri;

    move-result-object p1

    .line 517
    .local p1, "uri":Landroid/net/Uri;
    iget-object p2, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance p3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda108;

    invoke-direct {p3, p0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda108;-><init>(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .end local p1    # "uri":Landroid/net/Uri;
    goto :goto_1

    .line 518
    :catch_0
    move-exception v0

    move-object p1, v0

    goto :goto_0

    .end local v1    # "$data":Lorg/lighttouch/android/HitchData;
    .end local v2    # "$from":J
    .end local v4    # "$to":J
    .local p1, "$data":Lorg/lighttouch/android/HitchData;
    .restart local p2    # "$from":J
    .restart local p4    # "$to":J
    :catch_1
    move-exception v0

    move-object v1, p1

    move-wide v2, p2

    move-wide v4, p4

    move-object p1, v0

    .end local p2    # "$from":J
    .end local p4    # "$to":J
    .restart local v1    # "$data":Lorg/lighttouch/android/HitchData;
    .restart local v2    # "$from":J
    .restart local v4    # "$to":J
    .local p1, "e":Ljava/lang/Exception;
    :goto_0
    iget-object p2, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance p3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda109;

    invoke-direct {p3, p0, p1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda109;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 519
    .end local p1    # "e":Ljava/lang/Exception;
    :goto_1
    return-void
.end method

.method private static final saveHitch$lambda$59$lambda$57(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$uri"    # Landroid/net/Uri;

    .line 517
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchSaving(Z)V

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setHitchReport(Landroid/net/Uri;)V

    const-string v0, "\u5df2\u4fdd\u5b58\u5230 Download/LightTouch"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchNotice(Ljava/lang/String;)V

    return-void
.end method

.method private static final saveHitch$lambda$59$lambda$58(Lorg/lighttouch/android/MainActivity;Ljava/lang/Exception;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 518
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchSaving(Z)V

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Could not save: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setHitchNotice(Ljava/lang/String;)V

    return-void
.end method

.method private final scanFolder(Landroid/net/Uri;Lkotlin/jvm/functions/Function0;)V
    .locals 4
    .param p1, "tree"    # Landroid/net/Uri;
    .param p2, "onFound"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 531
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-static {v0, p1}, Landroidx/documentfile/provider/DocumentFile;->fromTreeUri(Landroid/content/Context;Landroid/net/Uri;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 532
    .local v0, "root":Landroidx/documentfile/provider/DocumentFile;
    :cond_0
    new-instance v1, Ljava/lang/Thread;

    .line 554
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda67;

    invoke-direct {v2, v0, p0, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda67;-><init>(Landroidx/documentfile/provider/DocumentFile;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function0;)V

    .line 532
    const-string v3, "setup-scan"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 554
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 555
    return-void
.end method

.method static synthetic scanFolder$default(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)V
    .locals 0

    .line 530
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x0

    :cond_0
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->scanFolder(Landroid/net/Uri;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method private static final scanFolder$lambda$79(Landroidx/documentfile/provider/DocumentFile;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function0;)V
    .locals 26
    .param p0, "$root"    # Landroidx/documentfile/provider/DocumentFile;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p2, "$onFound"    # Lkotlin/jvm/functions/Function0;

    .line 534
    move-object/from16 v3, p1

    invoke-virtual/range {p0 .. p0}, Landroidx/documentfile/provider/DocumentFile;->listFiles()[Landroidx/documentfile/provider/DocumentFile;

    move-result-object v0

    const-string v1, "listFiles(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, [Ljava/lang/Object;

    invoke-static {v0}, Lkotlin/collections/ArraysKt;->toList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-virtual/range {p0 .. p0}, Landroidx/documentfile/provider/DocumentFile;->listFiles()[Landroidx/documentfile/provider/DocumentFile;

    move-result-object v2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, [Ljava/lang/Object;

    .local v2, "$this$filter\\1":[Ljava/lang/Object;
    const/4 v4, 0x0

    .line 1486
    .local v4, "$i$f$filter\\1\\534":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\2":Ljava/util/Collection;
    move-object v6, v2

    .local v6, "$this$filterTo\\2":[Ljava/lang/Object;
    const/4 v7, 0x0

    .line 1487
    .local v7, "$i$f$filterTo\\2\\1486":I
    array-length v8, v6

    const/4 v10, 0x0

    :goto_0
    if-ge v10, v8, :cond_1

    aget-object v11, v6, v10

    .local v11, "element\\2":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Landroidx/documentfile/provider/DocumentFile;

    .local v12, "it\\3":Landroidx/documentfile/provider/DocumentFile;
    const/4 v13, 0x0

    .line 534
    .local v13, "$i$a$-filter-MainActivity$scanFolder$1$candidates$1\\3\\1487\\0":I
    invoke-virtual {v12}, Landroidx/documentfile/provider/DocumentFile;->isDirectory()Z

    move-result v12

    .line 1487
    .end local v12    # "it\\3":Landroidx/documentfile/provider/DocumentFile;
    .end local v13    # "$i$a$-filter-MainActivity$scanFolder$1$candidates$1\\3\\1487\\0":I
    if-eqz v12, :cond_0

    invoke-interface {v5, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v11    # "element\\2":Ljava/lang/Object;
    :cond_0
    add-int/lit8 v10, v10, 0x1

    goto :goto_0

    .line 1488
    :cond_1
    nop

    .end local v5    # "destination\\2":Ljava/util/Collection;
    .end local v6    # "$this$filterTo\\2":[Ljava/lang/Object;
    .end local v7    # "$i$f$filterTo\\2\\1486":I
    check-cast v5, Ljava/util/List;

    .line 1486
    nop

    .end local v2    # "$this$filter\\1":[Ljava/lang/Object;
    .end local v4    # "$i$f$filter\\1\\534":I
    check-cast v5, Ljava/lang/Iterable;

    .line 534
    nop

    .local v5, "$this$flatMap\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1489
    .local v2, "$i$f$flatMap\\4\\534":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\5":Ljava/util/Collection;
    move-object v6, v5

    .local v6, "$this$flatMapTo\\5":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1490
    .local v7, "$i$f$flatMapTo\\5\\1489":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 1491
    .local v10, "element\\5":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Landroidx/documentfile/provider/DocumentFile;

    .local v11, "it\\6":Landroidx/documentfile/provider/DocumentFile;
    const/4 v12, 0x0

    .line 534
    .local v12, "$i$a$-flatMap-MainActivity$scanFolder$1$candidates$2\\6\\1491\\0":I
    invoke-virtual {v11}, Landroidx/documentfile/provider/DocumentFile;->listFiles()[Landroidx/documentfile/provider/DocumentFile;

    move-result-object v13

    invoke-static {v13, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v13, [Ljava/lang/Object;

    invoke-static {v13}, Lkotlin/collections/ArraysKt;->toList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v13

    check-cast v13, Ljava/lang/Iterable;

    .line 1491
    .end local v11    # "it\\6":Landroidx/documentfile/provider/DocumentFile;
    .end local v12    # "$i$a$-flatMap-MainActivity$scanFolder$1$candidates$2\\6\\1491\\0":I
    nop

    .line 1492
    .local v13, "list\\5":Ljava/lang/Iterable;
    invoke-static {v4, v13}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .end local v13    # "list\\5":Ljava/lang/Iterable;
    goto :goto_1

    .line 1494
    .end local v10    # "element\\5":Ljava/lang/Object;
    :cond_2
    nop

    .end local v4    # "destination\\5":Ljava/util/Collection;
    .end local v6    # "$this$flatMapTo\\5":Ljava/lang/Iterable;
    .end local v7    # "$i$f$flatMapTo\\5\\1489":I
    check-cast v4, Ljava/util/List;

    .line 1489
    nop

    .end local v2    # "$i$f$flatMap\\4\\534":I
    .end local v5    # "$this$flatMap\\4":Ljava/lang/Iterable;
    check-cast v4, Ljava/lang/Iterable;

    .line 534
    invoke-static {v0, v4}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v6

    .line 535
    .local v6, "candidates":Ljava/util/List;
    move-object v0, v6

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\7":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1495
    .local v2, "$i$f$filter\\7\\535":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\8":Ljava/util/Collection;
    move-object v5, v0

    .local v5, "$this$filterTo\\8":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1496
    .local v7, "$i$f$filterTo\\8\\1495":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_3
    :goto_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_4

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\8":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Landroidx/documentfile/provider/DocumentFile;

    .local v11, "it\\9":Landroidx/documentfile/provider/DocumentFile;
    const/4 v12, 0x0

    .line 535
    .local v12, "$i$a$-filter-MainActivity$scanFolder$1$files$1\\9\\1496\\0":I
    invoke-virtual {v11}, Landroidx/documentfile/provider/DocumentFile;->isFile()Z

    move-result v11

    .line 1496
    .end local v11    # "it\\9":Landroidx/documentfile/provider/DocumentFile;
    .end local v12    # "$i$a$-filter-MainActivity$scanFolder$1$files$1\\9\\1496\\0":I
    if-eqz v11, :cond_3

    invoke-interface {v4, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 1497
    .end local v10    # "element\\8":Ljava/lang/Object;
    :cond_4
    nop

    .end local v4    # "destination\\8":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\8":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filterTo\\8\\1495":I
    check-cast v4, Ljava/util/List;

    .line 1495
    nop

    .line 535
    .end local v0    # "$this$filter\\7":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\7\\535":I
    move-object v7, v4

    .line 537
    .local v7, "files":Ljava/util/List;
    invoke-static/range {p0 .. p0}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/util/Collection;

    invoke-virtual/range {p0 .. p0}, Landroidx/documentfile/provider/DocumentFile;->listFiles()[Landroidx/documentfile/provider/DocumentFile;

    move-result-object v2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v1, v2

    check-cast v1, [Ljava/lang/Object;

    .local v1, "$this$filter\\10":[Ljava/lang/Object;
    const/4 v2, 0x0

    .line 1498
    .local v2, "$i$f$filter\\10\\537":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\11":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$filterTo\\11":[Ljava/lang/Object;
    const/4 v8, 0x0

    .line 1499
    .local v8, "$i$f$filterTo\\11\\1498":I
    array-length v10, v5

    const/4 v11, 0x0

    :goto_3
    if-ge v11, v10, :cond_6

    aget-object v12, v5, v11

    .local v12, "element\\11":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Landroidx/documentfile/provider/DocumentFile;

    .local v13, "it\\12":Landroidx/documentfile/provider/DocumentFile;
    const/4 v14, 0x0

    .line 537
    .local v14, "$i$a$-filter-MainActivity$scanFolder$1$folders$1\\12\\1499\\0":I
    invoke-virtual {v13}, Landroidx/documentfile/provider/DocumentFile;->isDirectory()Z

    move-result v13

    .line 1499
    .end local v13    # "it\\12":Landroidx/documentfile/provider/DocumentFile;
    .end local v14    # "$i$a$-filter-MainActivity$scanFolder$1$folders$1\\12\\1499\\0":I
    if-eqz v13, :cond_5

    invoke-interface {v4, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v12    # "element\\11":Ljava/lang/Object;
    :cond_5
    add-int/lit8 v11, v11, 0x1

    goto :goto_3

    .line 1500
    :cond_6
    nop

    .end local v4    # "destination\\11":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\11":[Ljava/lang/Object;
    .end local v8    # "$i$f$filterTo\\11\\1498":I
    check-cast v4, Ljava/util/List;

    .line 1498
    nop

    .end local v1    # "$this$filter\\10":[Ljava/lang/Object;
    .end local v2    # "$i$f$filter\\10\\537":I
    check-cast v4, Ljava/lang/Iterable;

    .line 537
    invoke-static {v0, v4}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v8

    .line 542
    .local v8, "folders":Ljava/util/List;
    move-object v0, v8

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\13":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1501
    .local v1, "$i$f$firstOrNull\\13\\542":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const-string v5, "files"

    const/4 v11, 0x1

    if-eqz v4, :cond_a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\13":Ljava/lang/Object;
    move-object v12, v4

    check-cast v12, Landroidx/documentfile/provider/DocumentFile;

    .local v12, "it\\14":Landroidx/documentfile/provider/DocumentFile;
    const/4 v13, 0x0

    .line 542
    .local v13, "$i$a$-firstOrNull-MainActivity$scanFolder$1$system$1\\14\\1501\\0":I
    const-string v14, "index.json"

    invoke-virtual {v12, v14}, Landroidx/documentfile/provider/DocumentFile;->findFile(Ljava/lang/String;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v14

    if-eqz v14, :cond_9

    invoke-virtual {v12, v5}, Landroidx/documentfile/provider/DocumentFile;->findFile(Ljava/lang/String;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v14

    if-eqz v14, :cond_8

    invoke-virtual {v14}, Landroidx/documentfile/provider/DocumentFile;->isDirectory()Z

    move-result v14

    if-ne v14, v11, :cond_8

    move v14, v11

    goto :goto_4

    :cond_8
    const/4 v14, 0x0

    :goto_4
    if-eqz v14, :cond_9

    move v12, v11

    goto :goto_5

    :cond_9
    const/4 v12, 0x0

    .line 1501
    .end local v12    # "it\\14":Landroidx/documentfile/provider/DocumentFile;
    .end local v13    # "$i$a$-firstOrNull-MainActivity$scanFolder$1$system$1\\14\\1501\\0":I
    :goto_5
    if-eqz v12, :cond_7

    goto :goto_6

    .line 1502
    .end local v4    # "element\\13":Ljava/lang/Object;
    :cond_a
    const/4 v4, 0x0

    .line 542
    .end local v0    # "$this$firstOrNull\\13":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\13\\542":I
    :goto_6
    check-cast v4, Landroidx/documentfile/provider/DocumentFile;

    .line 543
    const-string v0, ""

    const-string v1, "folder"

    const-string v2, "/"

    const-string v12, "device.lock.json"

    const-string v13, "getUri(...)"

    if-eqz v4, :cond_d

    .line 542
    nop

    .line 543
    nop

    .line 1369
    .local v4, "it\\15":Landroidx/documentfile/provider/DocumentFile;
    const/4 v14, 0x0

    .line 543
    .local v14, "$i$a$-let-MainActivity$scanFolder$1$system$2\\15\\543\\0":I
    new-instance v15, Lorg/lighttouch/android/PickedFile;

    invoke-virtual {v4}, Landroidx/documentfile/provider/DocumentFile;->getUri()Landroid/net/Uri;

    move-result-object v9

    invoke-static {v9, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v17

    if-nez v17, :cond_b

    goto :goto_7

    :cond_b
    move-object/from16 v1, v17

    :goto_7
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v5}, Landroidx/documentfile/provider/DocumentFile;->findFile(Ljava/lang/String;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v2

    if-eqz v2, :cond_c

    invoke-virtual {v2, v12}, Landroidx/documentfile/provider/DocumentFile;->findFile(Ljava/lang/String;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v2

    goto :goto_8

    :cond_c
    const/4 v2, 0x0

    :goto_8
    invoke-static {v3, v2}, Lorg/lighttouch/android/MainActivity;->scanFolder$lambda$79$board(Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v15, v9, v1, v11, v2}, Lorg/lighttouch/android/PickedFile;-><init>(Landroid/net/Uri;Ljava/lang/String;ZLjava/lang/String;)V

    .line 542
    .end local v4    # "it\\15":Landroidx/documentfile/provider/DocumentFile;
    .end local v14    # "$i$a$-let-MainActivity$scanFolder$1$system$2\\15\\543\\0":I
    move-object/from16 v18, v0

    move-object v1, v15

    goto/16 :goto_f

    .line 544
    :cond_d
    move-object v4, v7

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$firstOrNull\\16":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1503
    .local v5, "$i$f$firstOrNull\\16\\544":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_9
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_11

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\16":Ljava/lang/Object;
    move-object v14, v10

    check-cast v14, Landroidx/documentfile/provider/DocumentFile;

    .local v14, "it\\17":Landroidx/documentfile/provider/DocumentFile;
    const/4 v15, 0x0

    .line 544
    .local v15, "$i$a$-firstOrNull-MainActivity$scanFolder$1$system$3\\17\\1503\\0":I
    invoke-virtual {v14}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_e

    move-object/from16 v18, v0

    const-string v0, ".itbase"

    move-object/from16 v19, v1

    const/4 v1, 0x1

    invoke-static {v11, v0, v1}, Lkotlin/text/StringsKt;->endsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-ne v0, v1, :cond_f

    const/4 v0, 0x1

    goto :goto_a

    :cond_e
    move-object/from16 v18, v0

    move-object/from16 v19, v1

    :cond_f
    const/4 v0, 0x0

    .line 1503
    .end local v14    # "it\\17":Landroidx/documentfile/provider/DocumentFile;
    .end local v15    # "$i$a$-firstOrNull-MainActivity$scanFolder$1$system$3\\17\\1503\\0":I
    :goto_a
    if-eqz v0, :cond_10

    goto :goto_b

    :cond_10
    move-object/from16 v0, v18

    move-object/from16 v1, v19

    const/4 v11, 0x1

    goto :goto_9

    .line 1504
    .end local v10    # "element\\16":Ljava/lang/Object;
    :cond_11
    move-object/from16 v18, v0

    move-object/from16 v19, v1

    const/4 v10, 0x0

    .line 544
    .end local v4    # "$this$firstOrNull\\16":Ljava/lang/Iterable;
    .end local v5    # "$i$f$firstOrNull\\16\\544":I
    :goto_b
    check-cast v10, Landroidx/documentfile/provider/DocumentFile;

    if-eqz v10, :cond_13

    .line 1369
    .local v10, "it\\18":Landroidx/documentfile/provider/DocumentFile;
    const/4 v0, 0x0

    .line 544
    .local v0, "$i$a$-let-MainActivity$scanFolder$1$system$4\\18\\544\\0":I
    new-instance v19, Lorg/lighttouch/android/PickedFile;

    invoke-virtual {v10}, Landroidx/documentfile/provider/DocumentFile;->getUri()Landroid/net/Uri;

    move-result-object v1

    invoke-static {v1, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v10}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_12

    move-object/from16 v21, v18

    goto :goto_c

    :cond_12
    move-object/from16 v21, v2

    :goto_c
    const/16 v24, 0xc

    const/16 v25, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v20, v1

    invoke-direct/range {v19 .. v25}, Lorg/lighttouch/android/PickedFile;-><init>(Landroid/net/Uri;Ljava/lang/String;ZLjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v1, v19

    .end local v0    # "$i$a$-let-MainActivity$scanFolder$1$system$4\\18\\544\\0":I
    .end local v10    # "it\\18":Landroidx/documentfile/provider/DocumentFile;
    goto :goto_f

    .line 542
    :cond_13
    nop

    .line 546
    nop

    .line 545
    move-object v0, v8

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\19":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1505
    .local v1, "$i$f$firstOrNull\\19\\545":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_14
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_16

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\19":Ljava/lang/Object;
    move-object v9, v5

    check-cast v9, Landroidx/documentfile/provider/DocumentFile;

    .local v9, "it\\20":Landroidx/documentfile/provider/DocumentFile;
    const/4 v10, 0x0

    .line 545
    .local v10, "$i$a$-firstOrNull-MainActivity$scanFolder$1$system$5\\20\\1505\\0":I
    invoke-virtual {v9, v12}, Landroidx/documentfile/provider/DocumentFile;->findFile(Ljava/lang/String;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v11

    if-eqz v11, :cond_15

    const/4 v9, 0x1

    goto :goto_d

    :cond_15
    const/4 v9, 0x0

    .line 1505
    .end local v9    # "it\\20":Landroidx/documentfile/provider/DocumentFile;
    .end local v10    # "$i$a$-firstOrNull-MainActivity$scanFolder$1$system$5\\20\\1505\\0":I
    :goto_d
    if-eqz v9, :cond_14

    goto :goto_e

    .line 1506
    .end local v5    # "element\\19":Ljava/lang/Object;
    :cond_16
    const/4 v5, 0x0

    .line 545
    .end local v0    # "$this$firstOrNull\\19":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\19\\545":I
    :goto_e
    check-cast v5, Landroidx/documentfile/provider/DocumentFile;

    .line 546
    if-eqz v5, :cond_18

    .line 545
    nop

    .line 546
    nop

    .line 1369
    .local v5, "it\\21":Landroidx/documentfile/provider/DocumentFile;
    const/4 v0, 0x0

    .line 546
    .local v0, "$i$a$-let-MainActivity$scanFolder$1$system$6\\21\\546\\0":I
    new-instance v15, Lorg/lighttouch/android/PickedFile;

    invoke-virtual {v5}, Landroidx/documentfile/provider/DocumentFile;->getUri()Landroid/net/Uri;

    move-result-object v1

    invoke-static {v1, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v5}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_17

    move-object/from16 v4, v19

    :cond_17
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v12}, Landroidx/documentfile/provider/DocumentFile;->findFile(Ljava/lang/String;)Landroidx/documentfile/provider/DocumentFile;

    move-result-object v4

    invoke-static {v3, v4}, Lorg/lighttouch/android/MainActivity;->scanFolder$lambda$79$board(Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    invoke-direct {v15, v1, v2, v9, v4}, Lorg/lighttouch/android/PickedFile;-><init>(Landroid/net/Uri;Ljava/lang/String;ZLjava/lang/String;)V

    move-object v1, v15

    .end local v0    # "$i$a$-let-MainActivity$scanFolder$1$system$6\\21\\546\\0":I
    .end local v5    # "it\\21":Landroidx/documentfile/provider/DocumentFile;
    goto :goto_f

    :cond_18
    const/4 v1, 0x0

    .line 542
    :goto_f
    nop

    .line 547
    .local v1, "system":Lorg/lighttouch/android/PickedFile;
    move-object v0, v7

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\22":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 1507
    .local v2, "$i$f$firstOrNull\\22\\547":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_10
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\22":Ljava/lang/Object;
    move-object v9, v5

    check-cast v9, Landroidx/documentfile/provider/DocumentFile;

    .local v9, "it\\23":Landroidx/documentfile/provider/DocumentFile;
    const/4 v10, 0x0

    .line 547
    .local v10, "$i$a$-firstOrNull-MainActivity$scanFolder$1$rom$1\\23\\1507\\0":I
    invoke-virtual {v9}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_19

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v11, v12}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "toLowerCase(...)"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    if-eqz v11, :cond_19

    const-string v12, "bootrom"

    const/4 v14, 0x2

    move-object/from16 v16, v0

    const/4 v0, 0x0

    const/4 v15, 0x0

    .end local v0    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    .local v16, "$this$firstOrNull\\22":Ljava/lang/Iterable;
    invoke-static {v11, v12, v15, v14, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v11

    const/4 v12, 0x1

    if-ne v11, v12, :cond_1a

    move v9, v12

    goto :goto_11

    .end local v16    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    .restart local v0    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    :cond_19
    move-object/from16 v16, v0

    const/4 v0, 0x0

    const/4 v12, 0x1

    const/4 v15, 0x0

    .end local v0    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    .restart local v16    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    :cond_1a
    move v9, v15

    .line 1507
    .end local v9    # "it\\23":Landroidx/documentfile/provider/DocumentFile;
    .end local v10    # "$i$a$-firstOrNull-MainActivity$scanFolder$1$rom$1\\23\\1507\\0":I
    :goto_11
    if-eqz v9, :cond_1b

    goto :goto_12

    :cond_1b
    move-object/from16 v0, v16

    goto :goto_10

    .line 1508
    .end local v5    # "element\\22":Ljava/lang/Object;
    .end local v16    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    .restart local v0    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    :cond_1c
    move-object/from16 v16, v0

    const/4 v0, 0x0

    .end local v0    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    .restart local v16    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    move-object v5, v0

    .line 547
    .end local v2    # "$i$f$firstOrNull\\22\\547":I
    .end local v16    # "$this$firstOrNull\\22":Ljava/lang/Iterable;
    :goto_12
    check-cast v5, Landroidx/documentfile/provider/DocumentFile;

    if-eqz v5, :cond_1e

    .line 1369
    .local v5, "it\\24":Landroidx/documentfile/provider/DocumentFile;
    const/4 v0, 0x0

    .line 547
    .local v0, "$i$a$-let-MainActivity$scanFolder$1$rom$2\\24\\547\\0":I
    new-instance v19, Lorg/lighttouch/android/PickedFile;

    invoke-virtual {v5}, Landroidx/documentfile/provider/DocumentFile;->getUri()Landroid/net/Uri;

    move-result-object v2

    invoke-static {v2, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v5}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_1d

    move-object/from16 v21, v18

    goto :goto_13

    :cond_1d
    move-object/from16 v21, v4

    :goto_13
    const/16 v24, 0xc

    const/16 v25, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v25}, Lorg/lighttouch/android/PickedFile;-><init>(Landroid/net/Uri;Ljava/lang/String;ZLjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v2, v19

    .end local v0    # "$i$a$-let-MainActivity$scanFolder$1$rom$2\\24\\547\\0":I
    .end local v5    # "it\\24":Landroidx/documentfile/provider/DocumentFile;
    goto :goto_14

    :cond_1e
    move-object v2, v0

    .line 548
    .local v2, "rom":Lorg/lighttouch/android/PickedFile;
    :goto_14
    iget-object v9, v3, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v0, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda7;

    move-object/from16 v4, p0

    move-object/from16 v5, p2

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v9, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 554
    return-void
.end method

.method private static final scanFolder$lambda$79$board(Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;)Ljava/lang/String;
    .locals 11
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "lock"    # Landroidx/documentfile/provider/DocumentFile;

    .line 539
    nop

    .line 540
    const-string v0, ""

    if-eqz p1, :cond_3

    move-object v1, p1

    .line 1369
    .local v1, "it\\1":Landroidx/documentfile/provider/DocumentFile;
    const/4 v2, 0x0

    .line 540
    .local v2, "$i$a$-let-MainActivity$scanFolder$1$board$1\\1\\540\\0":I
    :try_start_0
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    invoke-virtual {v1}, Landroidx/documentfile/provider/DocumentFile;->getUri()Landroid/net/Uri;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    check-cast v3, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    move-object v5, v3

    check-cast v5, Ljava/io/InputStream;

    .line 1369
    .local v5, "s\\2":Ljava/io/InputStream;
    const/4 v6, 0x0

    .line 540
    .local v6, "$i$a$-use-MainActivity$scanFolder$1$board$1$1\\2\\540\\1":I
    new-instance v7, Lorg/json/JSONObject;

    sget-object v8, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v9, Ljava/io/InputStreamReader;

    invoke-direct {v9, v5, v8}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v9, Ljava/io/Reader;

    instance-of v8, v9, Ljava/io/BufferedReader;

    if-eqz v8, :cond_0

    check-cast v9, Ljava/io/BufferedReader;

    goto :goto_0

    :cond_0
    new-instance v8, Ljava/io/BufferedReader;

    const/16 v10, 0x2000

    invoke-direct {v8, v9, v10}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v9, v8

    :goto_0
    check-cast v9, Ljava/io/Reader;

    invoke-static {v9}, Lkotlin/io/TextStreamsKt;->readText(Ljava/io/Reader;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v8, "board"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v5    # "s\\2":Ljava/io/InputStream;
    .end local v6    # "$i$a$-use-MainActivity$scanFolder$1$board$1$1\\2\\540\\1":I
    :try_start_2
    invoke-static {v3, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    move-object v4, v7

    goto :goto_1

    :catchall_0
    move-exception v4

    .end local v1    # "it\\1":Landroidx/documentfile/provider/DocumentFile;
    .end local v2    # "$i$a$-let-MainActivity$scanFolder$1$board$1\\1\\540\\0":I
    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "lock":Landroidx/documentfile/provider/DocumentFile;
    :try_start_3
    throw v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .restart local v1    # "it\\1":Landroidx/documentfile/provider/DocumentFile;
    .restart local v2    # "$i$a$-let-MainActivity$scanFolder$1$board$1\\1\\540\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "lock":Landroidx/documentfile/provider/DocumentFile;
    :catchall_1
    move-exception v5

    :try_start_4
    invoke-static {v3, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p1    # "lock":Landroidx/documentfile/provider/DocumentFile;
    throw v5
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .end local v1    # "it\\1":Landroidx/documentfile/provider/DocumentFile;
    .end local v2    # "$i$a$-let-MainActivity$scanFolder$1$board$1\\1\\540\\0":I
    .restart local p0    # "this$0":Lorg/lighttouch/android/MainActivity;
    .restart local p1    # "lock":Landroidx/documentfile/provider/DocumentFile;
    :cond_1
    :goto_1
    if-nez v4, :cond_2

    goto :goto_2

    :cond_2
    move-object v0, v4

    goto :goto_2

    .line 541
    :catch_0
    move-exception v1

    :cond_3
    :goto_2
    return-object v0
.end method

.method private static final scanFolder$lambda$79$lambda$78(Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/PickedFile;Lorg/lighttouch/android/MainActivity;Landroidx/documentfile/provider/DocumentFile;Lkotlin/jvm/functions/Function0;)V
    .locals 12
    .param p0, "$system"    # Lorg/lighttouch/android/PickedFile;
    .param p1, "$rom"    # Lorg/lighttouch/android/PickedFile;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p3, "$root"    # Landroidx/documentfile/provider/DocumentFile;
    .param p4, "$onFound"    # Lkotlin/jvm/functions/Function0;

    .line 549
    if-eqz p0, :cond_0

    move-object v0, p0

    .line 1369
    .local v0, "it\\1":Lorg/lighttouch/android/PickedFile;
    const/4 v1, 0x0

    .line 549
    .local v1, "$i$a$-let-MainActivity$scanFolder$1$1$1\\1\\549\\0":I
    iget-object v2, p2, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v2, v0}, Lorg/lighttouch/android/SetupState;->setSystem(Lorg/lighttouch/android/PickedFile;)V

    .end local v0    # "it\\1":Lorg/lighttouch/android/PickedFile;
    .end local v1    # "$i$a$-let-MainActivity$scanFolder$1$1$1\\1\\549\\0":I
    :cond_0
    if-eqz p1, :cond_1

    move-object v0, p1

    .line 1369
    .local v0, "it\\2":Lorg/lighttouch/android/PickedFile;
    const/4 v1, 0x0

    .line 549
    .local v1, "$i$a$-let-MainActivity$scanFolder$1$1$2\\2\\549\\0":I
    iget-object v2, p2, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {v2, v0}, Lorg/lighttouch/android/SetupState;->setRom(Lorg/lighttouch/android/PickedFile;)V

    .line 550
    .end local v0    # "it\\2":Lorg/lighttouch/android/PickedFile;
    .end local v1    # "$i$a$-let-MainActivity$scanFolder$1$1$2\\2\\549\\0":I
    :cond_1
    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    .line 1369
    const-string v1, "iOS \u7cfb\u7edf"

    move-object v2, v1

    .local v2, "it\\3":Ljava/lang/String;
    const/4 v3, 0x0

    .line 550
    .local v3, "$i$a$-takeIf-MainActivity$scanFolder$1$1$found$1\\3\\550\\0":I
    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p0, :cond_2

    move v2, v4

    goto :goto_0

    :cond_2
    move v2, v5

    .end local v2    # "it\\3":Ljava/lang/String;
    .end local v3    # "$i$a$-takeIf-MainActivity$scanFolder$1$1$found$1\\3\\550\\0":I
    :goto_0
    const/4 v3, 0x0

    if-eqz v2, :cond_3

    goto :goto_1

    :cond_3
    move-object v1, v3

    :goto_1
    aput-object v1, v0, v5

    .line 1369
    const-string v1, "\u5f15\u5bfc\u6587\u4ef6"

    move-object v2, v1

    .local v2, "it\\4":Ljava/lang/String;
    const/4 v6, 0x0

    .line 550
    .local v6, "$i$a$-takeIf-MainActivity$scanFolder$1$1$found$2\\4\\550\\0":I
    if-eqz p1, :cond_4

    move v5, v4

    .end local v2    # "it\\4":Ljava/lang/String;
    .end local v6    # "$i$a$-takeIf-MainActivity$scanFolder$1$1$found$2\\4\\550\\0":I
    :cond_4
    if-eqz v5, :cond_5

    move-object v3, v1

    :cond_5
    aput-object v3, v0, v4

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .line 551
    .local v0, "found":Ljava/util/List;
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-virtual {p3}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Nothing found in "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    goto :goto_2

    :cond_6
    move-object v3, v0

    check-cast v3, Ljava/lang/Iterable;

    const-string v2, ", "

    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    const/16 v10, 0x3e

    const/4 v11, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v3 .. v11}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p3}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u627e\u5230 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " in "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    :goto_2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/SetupState;->setScanned(Ljava/lang/String;)V

    .line 552
    if-eqz p4, :cond_8

    if-eqz p0, :cond_7

    invoke-interface/range {p4 .. p4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    goto :goto_3

    :cond_7
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->setup:Lorg/lighttouch/android/SetupState;

    invoke-virtual {p3}, Landroidx/documentfile/provider/DocumentFile;->getName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "No prepared iOS system in "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/lighttouch/android/SetupState;->setError(Ljava/lang/String;)V

    .line 553
    :cond_8
    :goto_3
    return-void
.end method

.method private static final selectDevice$lambda$46(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$id"    # Ljava/lang/String;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 467
    if-eqz p0, :cond_0

    :try_start_0
    invoke-interface {p0, p1}, Lorg/lighttouch/android/IEngine;->select(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_2

    :cond_0
    const-string v0, "\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528"
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .local v0, "e":Landroid/os/RemoteException;
    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1

    const-string v1, "\u8bbe\u5907\u9009\u62e9\u5931\u8d25"

    :cond_1
    move-object v0, v1

    .line 468
    .local v0, "result":Ljava/lang/String;
    :cond_2
    :goto_0
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda14;

    invoke-direct {v2, p2, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda14;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 469
    return-void
.end method

.method private static final selectDevice$lambda$46$lambda$45(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$result"    # Ljava/lang/String;

    .line 468
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, v1, v2}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    return-void
.end method

.method private final selectedRecordId()Ljava/lang/String;
    .locals 7

    .line 1204
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1474
    .local v1, "$i$f$firstOrNull\\1\\1204":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Landroid/os/Bundle;

    .local v4, "it\\2":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 1204
    .local v5, "$i$a$-firstOrNull-MainActivity$selectedRecordId$1\\2\\1474\\0":I
    const-string v6, "selected"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v4

    .line 1474
    .end local v4    # "it\\2":Landroid/os/Bundle;
    .end local v5    # "$i$a$-firstOrNull-MainActivity$selectedRecordId$1\\2\\1474\\0":I
    if-eqz v4, :cond_0

    goto :goto_0

    .line 1475
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_1
    const/4 v3, 0x0

    .line 1204
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\1204":I
    :goto_0
    check-cast v3, Landroid/os/Bundle;

    if-eqz v3, :cond_2

    const-string v0, "id"

    invoke-virtual {v3, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_3

    :cond_2
    const-string v0, ""

    :cond_3
    return-object v0
.end method

.method private final sendButton(IZ)V
    .locals 3
    .param p1, "id"    # I
    .param p2, "down"    # Z

    .line 1188
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 1189
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->buttonCalls:Ljava/util/concurrent/ExecutorService;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda63;

    invoke-direct {v2, v0, p1, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda63;-><init>(Lorg/lighttouch/android/IEngine;IZ)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    .line 1190
    return-void
.end method

.method private static final sendButton$lambda$253(Lorg/lighttouch/android/IEngine;IZ)V
    .locals 1
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$id"    # I
    .param p2, "$down"    # Z

    .line 1189
    :try_start_0
    invoke-interface {p0, p1, p2}, Lorg/lighttouch/android/IEngine;->button(IZ)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    :goto_0
    return-void
.end method

.method private static final sensorThread_delegate$lambda$249()Landroid/os/HandlerThread;
    .locals 3

    .line 1166
    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "guest-motion"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .line 1369
    .local v1, "$this$sensorThread_delegate_u24lambda_u24249_u24lambda_u24248\\1":Landroid/os/HandlerThread;
    const/4 v2, 0x0

    .line 1166
    .local v2, "$i$a$-apply-MainActivity$sensorThread$2$1\\1\\1166\\0":I
    invoke-virtual {v1}, Landroid/os/HandlerThread;->start()V

    .end local v1    # "$this$sensorThread_delegate_u24lambda_u24249_u24lambda_u24248\\1":Landroid/os/HandlerThread;
    .end local v2    # "$i$a$-apply-MainActivity$sensorThread$2$1\\1\\1166\\0":I
    return-object v0
.end method

.method private static final sensors_delegate$lambda$21(Lorg/lighttouch/android/MainActivity;)Landroid/hardware/SensorManager;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 187
    const-class v0, Landroid/hardware/SensorManager;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/SensorManager;

    return-object v0
.end method

.method private final setAppServicesError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 81
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->appServicesError$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1325
    .local v2, "$i$f$setValue\\1\\81":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1326
    nop

    .line 81
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\81":I
    return-void
.end method

.method private final setBase(Lorg/lighttouch/android/Screen;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/Screen;

    .line 109
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->base$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1343
    .local v2, "$i$f$setValue\\1\\109":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1344
    nop

    .line 109
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\109":I
    return-void
.end method

.method private setBusy(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 54
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->busy$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1289
    .local v3, "$i$f$setValue\\1\\54":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1290
    nop

    .line 54
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\54":I
    return-void
.end method

.method private final setCatalogVersion(I)V
    .locals 3
    .param p1, "<set-?>"    # I

    .line 95
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->catalogVersion$delegate:Landroidx/compose/runtime/MutableIntState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableIntState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1328
    .local v2, "$i$f$setValue\\1\\95":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    .line 1329
    nop

    .line 95
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableIntState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\95":I
    return-void
.end method

.method private final setDebugEnv(Ljava/lang/String;Ljava/lang/String;)V
    .locals 30
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/String;

    .line 433
    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v0, "\n"

    :try_start_0
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object/from16 v3, p0

    check-cast v3, Lorg/lighttouch/android/MainActivity;

    .local v3, "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    const/4 v4, 0x0

    .line 434
    .local v4, "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    new-instance v5, Ljava/io/File;

    invoke-virtual {v3}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v6

    const-string v7, "debug-env"

    invoke-direct {v5, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 435
    .local v5, "file\\1":Ljava/io/File;
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const-string v8, "="

    const/4 v9, 0x0

    if-eqz v6, :cond_4

    const/4 v6, 0x1

    :try_start_1
    invoke-static {v5, v9, v6, v9}, Lkotlin/io/FilesKt;->readLines$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v10

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$filter\\2":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 1393
    .local v11, "$i$f$filter\\2\\435":I
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\3":Ljava/util/Collection;
    move-object v13, v10

    .local v13, "$this$filterTo\\3":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 1394
    .local v14, "$i$f$filterTo\\3\\1393":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_0
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_3

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v17, v16

    .local v17, "element\\3":Ljava/lang/Object;
    move-object/from16 v16, v17

    check-cast v16, Ljava/lang/String;

    move-object/from16 v18, v16

    .local v18, "it\\4":Ljava/lang/String;
    const/16 v16, 0x0

    .line 435
    .local v16, "$i$a$-filter-MainActivity$setDebugEnv$1$kept$1\\4\\1394\\1":I
    move-object/from16 v19, v18

    check-cast v19, Ljava/lang/CharSequence;

    invoke-static/range {v19 .. v19}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v19

    if-nez v19, :cond_0

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    move-object/from16 v20, v3

    move-object/from16 v3, v18

    move/from16 v18, v4

    const/4 v4, 0x0

    .end local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .local v3, "it\\4":Ljava/lang/String;
    .local v18, "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .local v20, "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    invoke-static {v3, v6, v4, v7, v9}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    const/4 v6, 0x1

    goto :goto_1

    .end local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .local v3, "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .restart local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .local v18, "it\\4":Ljava/lang/String;
    :cond_0
    move-object/from16 v20, v3

    move-object/from16 v3, v18

    move/from16 v18, v4

    const/4 v4, 0x0

    .end local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .local v3, "it\\4":Ljava/lang/String;
    .local v18, "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .restart local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    :cond_1
    move v6, v4

    .line 1394
    .end local v3    # "it\\4":Ljava/lang/String;
    .end local v16    # "$i$a$-filter-MainActivity$setDebugEnv$1$kept$1\\4\\1394\\1":I
    :goto_1
    if-eqz v6, :cond_2

    move-object/from16 v3, v17

    .end local v17    # "element\\3":Ljava/lang/Object;
    .local v3, "element\\3":Ljava/lang/Object;
    invoke-interface {v12, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .end local v3    # "element\\3":Ljava/lang/Object;
    .restart local v17    # "element\\3":Ljava/lang/Object;
    :cond_2
    move-object/from16 v3, v17

    .end local v17    # "element\\3":Ljava/lang/Object;
    .restart local v3    # "element\\3":Ljava/lang/Object;
    :goto_2
    move/from16 v4, v18

    move-object/from16 v3, v20

    const/4 v6, 0x1

    goto :goto_0

    .line 1395
    .end local v18    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .end local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .local v3, "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .restart local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    :cond_3
    move-object/from16 v20, v3

    move/from16 v18, v4

    .end local v3    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .end local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .end local v12    # "destination\\3":Ljava/util/Collection;
    .end local v13    # "$this$filterTo\\3":Ljava/lang/Iterable;
    .end local v14    # "$i$f$filterTo\\3\\1393":I
    .restart local v18    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .restart local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    move-object v3, v12

    check-cast v3, Ljava/util/List;

    .line 1393
    nop

    .end local v10    # "$this$filter\\2":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filter\\2\\435":I
    goto :goto_3

    .line 435
    .end local v18    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .end local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .restart local v3    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .restart local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    :cond_4
    move-object/from16 v20, v3

    move/from16 v18, v4

    .end local v3    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    .end local v4    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .restart local v18    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .restart local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v3

    :goto_3
    nop

    .line 436
    .local v3, "kept\\1":Ljava/util/List;
    move-object v4, v3

    check-cast v4, Ljava/util/Collection;

    if-nez v2, :cond_5

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v6

    goto :goto_4

    :cond_5
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    :goto_4
    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v4, v6}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v4

    .line 437
    .local v4, "lines\\1":Ljava/util/List;
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    goto :goto_5

    :cond_6
    move-object/from16 v21, v4

    check-cast v21, Ljava/lang/Iterable;

    move-object/from16 v22, v0

    check-cast v22, Ljava/lang/CharSequence;

    const/16 v28, 0x3e

    const/16 v29, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    invoke-static/range {v21 .. v29}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0, v9, v7, v9}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 433
    .end local v3    # "kept\\1":Ljava/util/List;
    .end local v4    # "lines\\1":Ljava/util/List;
    .end local v5    # "file\\1":Ljava/io/File;
    .end local v18    # "$i$a$-runCatching-MainActivity$setDebugEnv$1\\1\\433\\0":I
    .end local v20    # "$this$setDebugEnv_u24lambda_u2443\\1":Lorg/lighttouch/android/MainActivity;
    :goto_5
    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_6

    :catchall_0
    move-exception v0

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 439
    :goto_6
    return-void
.end method

.method private final setDetail(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 39
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->detail$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1274
    .local v2, "$i$f$setValue\\1\\39":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1275
    nop

    .line 39
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\39":I
    return-void
.end method

.method private final setDetailsDevice(Lorg/lighttouch/android/DeviceSummary;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/DeviceSummary;

    .line 79
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->detailsDevice$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1319
    .local v2, "$i$f$setValue\\1\\79":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1320
    nop

    .line 79
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\79":I
    return-void
.end method

.method private final setDevicesOpen(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 78
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->devicesOpen$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1316
    .local v3, "$i$f$setValue\\1\\78":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1317
    nop

    .line 78
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\78":I
    return-void
.end method

.method private setDisplayAsleep(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 40
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayAsleep$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1277
    .local v3, "$i$f$setValue\\1\\40":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1278
    nop

    .line 40
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\40":I
    return-void
.end method

.method private final setEngine(Lorg/lighttouch/android/IEngine;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/IEngine;

    .line 36
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->engine$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1268
    .local v2, "$i$f$setValue\\1\\36":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1269
    nop

    .line 36
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\36":I
    return-void
.end method

.method private setError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 42
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->error$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1280
    .local v2, "$i$f$setValue\\1\\42":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1281
    nop

    .line 42
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\42":I
    return-void
.end method

.method private setFaithfulScaler(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 68
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->faithfulScaler$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1310
    .local v3, "$i$f$setValue\\1\\68":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1311
    nop

    .line 68
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\68":I
    return-void
.end method

.method private final setFirmwareRestarting(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 125
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareRestarting$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1364
    .local v3, "$i$f$setValue\\1\\125":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1365
    nop

    .line 125
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\125":I
    return-void
.end method

.method private final setHitchData(Lorg/lighttouch/android/HitchData;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/HitchData;

    .line 113
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchData$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1349
    .local v2, "$i$f$setValue\\1\\113":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1350
    nop

    .line 113
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\113":I
    return-void
.end method

.method private final setHitchError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 114
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchError$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1352
    .local v2, "$i$f$setValue\\1\\114":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1353
    nop

    .line 114
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\114":I
    return-void
.end method

.method private final setHitchNotice(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 116
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchNotice$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1358
    .local v2, "$i$f$setValue\\1\\116":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1359
    nop

    .line 116
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\116":I
    return-void
.end method

.method private final setHitchReport(Landroid/net/Uri;)V
    .locals 3
    .param p1, "<set-?>"    # Landroid/net/Uri;

    .line 117
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchReport$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1361
    .local v2, "$i$f$setValue\\1\\117":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1362
    nop

    .line 117
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\117":I
    return-void
.end method

.method private final setHitchSaving(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 115
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->hitchSaving$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1355
    .local v3, "$i$f$setValue\\1\\115":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1356
    nop

    .line 115
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\115":I
    return-void
.end method

.method private final setLicensesOpen(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 77
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->licensesOpen$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1313
    .local v3, "$i$f$setValue\\1\\77":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1314
    nop

    .line 77
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\77":I
    return-void
.end method

.method private final setMuxSocket(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 80
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->muxSocket$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1322
    .local v2, "$i$f$setValue\\1\\80":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1323
    nop

    .line 80
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\80":I
    return-void
.end method

.method private final setNotice(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 57
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->notice$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1292
    .local v2, "$i$f$setValue\\1\\57":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1293
    nop

    .line 57
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\57":I
    return-void
.end method

.method private final setOverlay(Lorg/lighttouch/android/Screen;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/Screen;

    .line 111
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->overlay$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1346
    .local v2, "$i$f$setValue\\1\\111":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1347
    nop

    .line 111
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\111":I
    return-void
.end method

.method private final setPreparationOpen(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 130
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->preparationOpen$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1367
    .local v3, "$i$f$setValue\\1\\130":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1368
    nop

    .line 130
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\130":I
    return-void
.end method

.method private setProfileAutomatic(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 60
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileAutomatic$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1298
    .local v3, "$i$f$setValue\\1\\60":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1299
    nop

    .line 60
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\60":I
    return-void
.end method

.method private setProfileBusy(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 62
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileBusy$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1301
    .local v3, "$i$f$setValue\\1\\62":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1302
    nop

    .line 62
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\62":I
    return-void
.end method

.method private setProfileNotice(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 64
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileNotice$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1304
    .local v2, "$i$f$setValue\\1\\64":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1305
    nop

    .line 64
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\64":I
    return-void
.end method

.method private setProfileRecording(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 58
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileRecording$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1295
    .local v3, "$i$f$setValue\\1\\58":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1296
    nop

    .line 58
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\58":I
    return-void
.end method

.method private final setRecords(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/os/Bundle;",
            ">;)V"
        }
    .end annotation

    .line 98
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->records$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1331
    .local v2, "$i$f$setValue\\1\\98":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1332
    nop

    .line 98
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\98":I
    return-void
.end method

.method private final setRecordsLoaded(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 99
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->recordsLoaded$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1334
    .local v3, "$i$f$setValue\\1\\99":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1335
    nop

    .line 99
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\99":I
    return-void
.end method

.method private setSessionOwned(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 46
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->sessionOwned$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1286
    .local v3, "$i$f$setValue\\1\\46":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1287
    nop

    .line 46
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\46":I
    return-void
.end method

.method private setStatus(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 37
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->status$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1271
    .local v2, "$i$f$setValue\\1\\37":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1272
    nop

    .line 37
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\37":I
    return-void
.end method

.method private final setWorkerPid(I)V
    .locals 3
    .param p1, "<set-?>"    # I

    .line 45
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerPid$delegate:Landroidx/compose/runtime/MutableIntState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableIntState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1283
    .local v2, "$i$f$setValue\\1\\45":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableIntState;->setIntValue(I)V

    .line 1284
    nop

    .line 45
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableIntState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\45":I
    return-void
.end method

.method private static final settings_delegate$lambda$10(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/AppSettings;
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 102
    new-instance v0, Lorg/lighttouch/android/AppSettings;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1}, Lorg/lighttouch/android/AppSettings;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method private final shareReport(Landroid/net/Uri;)V
    .locals 3
    .param p1, "uri"    # Landroid/net/Uri;

    .line 522
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.SEND"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "application/zip"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "android.intent.extra.STREAM"

    move-object v2, p1

    check-cast v2, Landroid/os/Parcelable;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object v0

    .line 523
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "\u5206\u4eab\u5361\u987f\u62a5\u544a"

    check-cast v1, Ljava/lang/CharSequence;

    .line 522
    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->startActivity(Landroid/content/Intent;)V

    .line 524
    return-void
.end method

.method private final startGuest(ZLorg/lighttouch/android/MainActivity$GuestStartRequest;)V
    .locals 6
    .param p1, "coldRecovery"    # Z
    .param p2, "retainedRequest"    # Lorg/lighttouch/android/MainActivity$GuestStartRequest;

    .line 999
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineRestarting:Z

    if-eqz v0, :cond_0

    return-void

    .line 1000
    :cond_0
    if-nez p2, :cond_3

    .line 1001
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSelected()Lorg/lighttouch/android/DeviceSummary;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lorg/lighttouch/android/DeviceSummary;->getId()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 1000
    :cond_1
    new-instance v1, Lorg/lighttouch/android/MainActivity$GuestStartRequest;

    invoke-direct {v1, v0, p1}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;-><init>(Ljava/lang/String;Z)V

    goto :goto_1

    .line 1001
    :cond_2
    :goto_0
    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/MainActivity;

    .line 1369
    .local v0, "$this$startGuest_u24lambda_u24210\\1":Lorg/lighttouch/android/MainActivity;
    const/4 v1, 0x0

    .line 1001
    .local v1, "$i$a$-run-MainActivity$startGuest$request$1\\1\\1001\\0":I
    const-string v2, "\u9009\u62e9\u8bbe\u5907"

    invoke-direct {v0, v2}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    const-string v2, "stopped"

    invoke-direct {v0, v2}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    return-void

    .line 1000
    .end local v0    # "$this$startGuest_u24lambda_u24210\\1":Lorg/lighttouch/android/MainActivity;
    .end local v1    # "$i$a$-run-MainActivity$startGuest$request$1\\1\\1001\\0":I
    :cond_3
    move-object v1, p2

    .line 1004
    .local v1, "request":Lorg/lighttouch/android/MainActivity$GuestStartRequest;
    :goto_1
    iput-object v1, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestRequest:Lorg/lighttouch/android/MainActivity$GuestStartRequest;

    .line 1005
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    .line 1006
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    const-string v2, "starting"

    const/4 v3, 0x1

    if-nez v0, :cond_4

    iput-boolean v3, p0, Lorg/lighttouch/android/MainActivity;->pendingGuestStart:Z

    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindWorker()V

    return-void

    .line 1007
    :cond_4
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSessionOwned()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->restartGuestForStart(Lorg/lighttouch/android/IEngine;)V

    return-void

    .line 1008
    :cond_5
    iget-object v4, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    invoke-virtual {v4}, Lorg/lighttouch/android/SessionDeliveryGate;->advance()J

    .line 1009
    const/4 v4, 0x0

    iput-boolean v4, p0, Lorg/lighttouch/android/MainActivity;->engineExpectedExit:Z

    iput-boolean v3, p0, Lorg/lighttouch/android/MainActivity;->guestStartRequested:Z

    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    .line 1010
    new-instance v2, Landroid/content/Intent;

    move-object v3, p0

    check-cast v3, Landroid/content/Context;

    const-class v4, Lorg/lighttouch/android/EngineService;

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 1011
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getGraphicsProvider()Lorg/lighttouch/android/GraphicsProvider;

    move-result-object v2

    .line 1012
    .local v2, "graphicsProvider":Lorg/lighttouch/android/GraphicsProvider;
    new-instance v3, Ljava/lang/Thread;

    .line 1041
    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda60;

    invoke-direct {v4, v0, v2, p0, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda60;-><init>(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$GuestStartRequest;)V

    .line 1012
    const-string v5, "guest-start"

    invoke-direct {v3, v4, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1041
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 1042
    return-void
.end method

.method static synthetic startGuest$default(Lorg/lighttouch/android/MainActivity;ZLorg/lighttouch/android/MainActivity$GuestStartRequest;ILjava/lang/Object;)V
    .locals 0

    .line 998
    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    const/4 p1, 0x0

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    const/4 p2, 0x0

    :cond_1
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->startGuest(ZLorg/lighttouch/android/MainActivity$GuestStartRequest;)V

    return-void
.end method

.method private static final startGuest$lambda$215(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$GuestStartRequest;)V
    .locals 7
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$graphicsProvider"    # Lorg/lighttouch/android/GraphicsProvider;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p3, "$request"    # Lorg/lighttouch/android/MainActivity$GuestStartRequest;

    .line 1013
    const-string v0, "LightTouch"

    .line 1014
    :try_start_0
    sget-boolean v1, Lorg/lighttouch/android/BuildConfig;->DEBUG:Z

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    .line 1015
    invoke-virtual {p1}, Lorg/lighttouch/android/GraphicsProvider;->getNativeChoice()I

    move-result v1

    invoke-interface {p0, v1}, Lorg/lighttouch/android/IEngine;->debugSelectGraphicsProvider(I)Ljava/lang/String;

    move-result-object v1

    .line 1016
    .local v1, "providerError":Ljava/lang/String;
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, v1

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_0

    move v4, v2

    goto :goto_0

    :cond_0
    move v4, v3

    :goto_0
    if-eqz v4, :cond_1

    .line 1017
    iget-object v0, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda4;

    invoke-direct {v2, p2, p0, p1, v1}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 1024
    return-void

    .line 1028
    .end local v1    # "providerError":Ljava/lang/String;
    :cond_1
    :try_start_1
    sget-object v1, Lorg/lighttouch/android/GuestTools;->INSTANCE:Lorg/lighttouch/android/GuestTools;

    move-object v4, p2

    check-cast v4, Landroid/content/Context;

    invoke-virtual {p3}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;->getRecordId()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v4, v5}, Lorg/lighttouch/android/GuestTools;->newerFor(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    if-eqz v1, :cond_4

    .local v1, "tools\\1":Ljava/io/File;
    const/4 v4, 0x0

    .line 1029
    .local v4, "$i$a$-let-MainActivity$startGuest$1$2\\1\\1028\\0":I
    invoke-virtual {p3}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;->getRecordId()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v6

    invoke-interface {p0, v5, v6}, Lorg/lighttouch/android/IEngine;->setGuestPackage(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 1030
    .local v5, "result\\1":Ljava/lang/String;
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-nez v6, :cond_2

    goto :goto_1

    :cond_2
    move v2, v3

    :goto_1
    if-eqz v2, :cond_3

    invoke-virtual {p3}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;->getRecordId()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Guest tools updated for "

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    goto :goto_2

    :cond_3
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Guest tools not updated: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    :goto_2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 1028
    .end local v1    # "tools\\1":Ljava/io/File;
    .end local v4    # "$i$a$-let-MainActivity$startGuest$1$2\\1\\1028\\0":I
    .end local v5    # "result\\1":Ljava/lang/String;
    :cond_4
    goto :goto_3

    .line 1031
    :catch_0
    move-exception v1

    .local v1, "failure":Ljava/lang/Exception;
    :try_start_2
    const-string v2, "\u5ba2\u6237\u673a\u5de5\u5177\u672a\u66f4\u65b0"

    move-object v3, v1

    check-cast v3, Ljava/lang/Throwable;

    invoke-static {v0, v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 1032
    .end local v1    # "failure":Ljava/lang/Exception;
    :goto_3
    invoke-virtual {p3}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;->getColdRecovery()Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-virtual {p3}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;->getRecordId()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Lorg/lighttouch/android/IEngine;->recoverStart(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    goto :goto_4

    :cond_5
    invoke-virtual {p3}, Lorg/lighttouch/android/MainActivity$GuestStartRequest;->getRecordId()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, v0}, Lorg/lighttouch/android/IEngine;->start(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    .line 1033
    .local v0, "b":Landroid/os/Bundle;
    :goto_4
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda5;

    invoke-direct {v2, p2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .end local v0    # "b":Landroid/os/Bundle;
    goto :goto_5

    .line 1035
    :catch_1
    move-exception v0

    .local v0, "failure":Ljava/lang/Exception;
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda6;

    invoke-direct {v2, p2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Ljava/lang/Exception;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1041
    .end local v0    # "failure":Ljava/lang/Exception;
    :goto_5
    return-void
.end method

.method private static final startGuest$lambda$215$lambda$211(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/GraphicsProvider;Ljava/lang/String;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "$graphicsProvider"    # Lorg/lighttouch/android/GraphicsProvider;
    .param p3, "$providerError"    # Ljava/lang/String;

    .line 1018
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1019
    invoke-virtual {p2}, Lorg/lighttouch/android/GraphicsProvider;->getLabel()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " graphics provider unavailable: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ". Restart LightTouch to reset the graphics driver."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 1020
    const-string v0, "failed"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    .line 1021
    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->guestStartRequested:Z

    .line 1023
    :cond_1
    return-void
.end method

.method private static final startGuest$lambda$215$lambda$213(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "$b"    # Landroid/os/Bundle;

    .line 1033
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "error"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, ""

    :cond_1
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    :cond_2
    return-void
.end method

.method private static final startGuest$lambda$215$lambda$214(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Ljava/lang/Exception;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "$failure"    # Ljava/lang/Exception;

    .line 1036
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 1037
    invoke-virtual {p2}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "\u5de5\u4f5c\u8fdb\u7a0b\u5df2\u9000\u51fa"

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Guest start failed: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ". Writable state and private diagnostics retained."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 1038
    const-string v0, "failed"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    .line 1040
    :cond_2
    return-void
.end method

.method private final startSensors()V
    .locals 8

    .line 1171
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1470
    .local v1, "$i$f$firstOrNull\\1\\1171":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Landroid/os/Bundle;

    .local v4, "it\\2":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 1171
    .local v5, "$i$a$-firstOrNull-MainActivity$startSensors$record$1\\2\\1470\\0":I
    const-string v6, "selected"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v4

    .line 1470
    .end local v4    # "it\\2":Landroid/os/Bundle;
    .end local v5    # "$i$a$-firstOrNull-MainActivity$startSensors$record$1\\2\\1470\\0":I
    if-eqz v4, :cond_0

    goto :goto_0

    .line 1471
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_1
    const/4 v3, 0x0

    .line 1171
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\1171":I
    :goto_0
    move-object v0, v3

    check-cast v0, Landroid/os/Bundle;

    .line 1172
    .local v0, "record":Landroid/os/Bundle;
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getTilt()Z

    move-result v1

    if-eqz v1, :cond_6

    iget-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->listening:Z

    if-nez v1, :cond_6

    if-nez v0, :cond_2

    goto :goto_2

    .line 1173
    :cond_2
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v1

    iput-object v1, p0, Lorg/lighttouch/android/MainActivity;->motionWorker:Lorg/lighttouch/android/IEngine;

    .line 1174
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getDisplay()Landroid/view/Display;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/view/Display;->getRotation()I

    move-result v1

    goto :goto_1

    :cond_3
    const/4 v1, 0x0

    :goto_1
    mul-int/lit8 v1, v1, 0x5a

    iput v1, p0, Lorg/lighttouch/android/MainActivity;->displayRotation:I

    .line 1175
    new-instance v1, Landroid/os/Handler;

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getSensorThread()Landroid/os/HandlerThread;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 1178
    .local v1, "thread":Landroid/os/Handler;
    const-string v2, "acceleration"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v2

    const/16 v3, 0x2710

    const/4 v4, 0x1

    if-eqz v2, :cond_4

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getSensors()Landroid/hardware/SensorManager;

    move-result-object v2

    invoke-virtual {v2, v4}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object v2

    if-eqz v2, :cond_4

    .line 1369
    .local v2, "it\\3":Landroid/hardware/Sensor;
    const/4 v5, 0x0

    .line 1178
    .local v5, "$i$a$-let-MainActivity$startSensors$1\\3\\1178\\0":I
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getSensors()Landroid/hardware/SensorManager;

    move-result-object v6

    move-object v7, p0

    check-cast v7, Landroid/hardware/SensorEventListener;

    invoke-virtual {v6, v7, v2, v3, v1}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;ILandroid/os/Handler;)Z

    .line 1179
    .end local v2    # "it\\3":Landroid/hardware/Sensor;
    .end local v5    # "$i$a$-let-MainActivity$startSensors$1\\3\\1178\\0":I
    :cond_4
    const-string v2, "gyro"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getSensors()Landroid/hardware/SensorManager;

    move-result-object v2

    const/4 v5, 0x4

    invoke-virtual {v2, v5}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object v2

    if-eqz v2, :cond_5

    .line 1369
    .local v2, "it\\4":Landroid/hardware/Sensor;
    const/4 v5, 0x0

    .line 1179
    .local v5, "$i$a$-let-MainActivity$startSensors$2\\4\\1179\\0":I
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getSensors()Landroid/hardware/SensorManager;

    move-result-object v6

    move-object v7, p0

    check-cast v7, Landroid/hardware/SensorEventListener;

    invoke-virtual {v6, v7, v2, v3, v1}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;ILandroid/os/Handler;)Z

    .line 1180
    .end local v2    # "it\\4":Landroid/hardware/Sensor;
    .end local v5    # "$i$a$-let-MainActivity$startSensors$2\\4\\1179\\0":I
    :cond_5
    iput-boolean v4, p0, Lorg/lighttouch/android/MainActivity;->listening:Z

    .line 1181
    return-void

    .line 1172
    .end local v1    # "thread":Landroid/os/Handler;
    :cond_6
    :goto_2
    return-void
.end method

.method private static final stockIpsw$lambda$13(Lorg/lighttouch/android/MainActivity;Landroid/net/Uri;)V
    .locals 0
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "uri"    # Landroid/net/Uri;

    .line 159
    if-eqz p1, :cond_0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->importStockIpsw(Landroid/net/Uri;)V

    :cond_0
    return-void
.end method

.method private final stopGuest()V
    .locals 4

    .line 1044
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 1045
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->engineExpectedExit:Z

    const-string v1, "stopping"

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopSensors()V

    .line 1046
    new-instance v1, Ljava/lang/Thread;

    .line 1051
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda80;

    invoke-direct {v2, v0, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda80;-><init>(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V

    .line 1046
    const-string v3, "guest-stop-request"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1051
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 1052
    return-void
.end method

.method private static final stopGuest$lambda$217(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V
    .locals 3
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 1047
    :try_start_0
    invoke-interface {p0}, Lorg/lighttouch/android/IEngine;->stop()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1048
    :catch_0
    move-exception v0

    .local v0, "failure":Landroid/os/RemoteException;
    iget-object v1, p1, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda107;

    invoke-direct {v2, p1, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda107;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/RemoteException;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1051
    .end local v0    # "failure":Landroid/os/RemoteException;
    :goto_0
    return-void
.end method

.method private static final stopGuest$lambda$217$lambda$216(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/RemoteException;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "$failure"    # Landroid/os/RemoteException;

    .line 1049
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p2}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "\u5de5\u4f5c\u8fdb\u7a0b\u5df2\u9000\u51fa"

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Stop admission failed; writable state retained: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 1050
    :cond_2
    return-void
.end method

.method private final stopSensors()V
    .locals 2

    .line 1182
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getSensors()Landroid/hardware/SensorManager;

    move-result-object v0

    move-object v1, p0

    check-cast v1, Landroid/hardware/SensorEventListener;

    invoke-virtual {v0, v1}, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->listening:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->motionWorker:Lorg/lighttouch/android/IEngine;

    return-void
.end method

.method private static final store_delegate$lambda$4(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreModel;
    .locals 4
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 83
    new-instance v0, Lorg/lighttouch/android/StoreModel;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda98;

    invoke-direct {v2, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda98;-><init>(Lorg/lighttouch/android/MainActivity;)V

    new-instance v3, Lorg/lighttouch/android/MainActivity$store$2$2;

    invoke-direct {v3, p0}, Lorg/lighttouch/android/MainActivity$store$2$2;-><init>(Ljava/lang/Object;)V

    check-cast v3, Lkotlin/jvm/functions/Function0;

    invoke-direct {v0, v1, v2, v3}, Lorg/lighttouch/android/StoreModel;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    return-object v0
.end method

.method private static final store_delegate$lambda$4$lambda$3(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 83
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getMuxSocket()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_1

    .line 1369
    const/4 v0, 0x0

    .line 83
    .local v0, "$i$a$-ifEmpty-MainActivity$store$2$1$1\\1\\83\\0":I
    nop

    .end local v0    # "$i$a$-ifEmpty-MainActivity$store$2$1$1\\1\\83\\0":I
    const/4 v0, 0x0

    :cond_1
    check-cast v0, Ljava/lang/String;

    return-object v0
.end method

.method private static final toggleProfile$lambda$20(Lorg/lighttouch/android/IEngine;ZLorg/lighttouch/android/MainActivity;)V
    .locals 6
    .param p0, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$recording"    # Z
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 170
    :try_start_0
    invoke-interface {p0, p1}, Lorg/lighttouch/android/IEngine;->profile(Z)Landroid/os/Bundle;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 171
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    move-object v2, v1

    .line 1369
    .local v2, "$this$toggleProfile_u24lambda_u2420_u24lambda_u2416\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 171
    .local v3, "$i$a$-apply-MainActivity$toggleProfile$1$result$1\\1\\171\\0":I
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_0

    const-string v4, "\u6027\u80fd\u8bb0\u5f55\u5931\u8d25"

    :cond_0
    const-string v5, "profileError"

    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v1

    .line 170
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v2    # "$this$toggleProfile_u24lambda_u2420_u24lambda_u2416\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-MainActivity$toggleProfile$1$result$1\\1\\171\\0":I
    :goto_0
    nop

    .line 172
    .local v0, "result":Landroid/os/Bundle;
    iget-object v1, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda10;

    invoke-direct {v2, p2, p0, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 180
    return-void
.end method

.method private static final toggleProfile$lambda$20$lambda$19(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Landroid/os/Bundle;)V
    .locals 6
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "$result"    # Landroid/os/Bundle;

    .line 173
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, v1

    :goto_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_4

    .line 174
    const-string v0, "profileRecording"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setProfileRecording(Z)V

    .line 175
    const-string v0, "profileNotice"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, ""

    :cond_1
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setProfileNotice(Ljava/lang/String;)V

    .line 176
    const-string v0, "profileError"

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_4

    move-object v3, v0

    .line 1369
    .local v3, "it\\1":Ljava/lang/String;
    const/4 v4, 0x0

    .line 176
    .local v4, "$i$a$-takeIf-MainActivity$toggleProfile$1$1$1\\1\\176\\0":I
    move-object v5, v3

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_2

    const/4 v5, 0x1

    goto :goto_1

    :cond_2
    move v5, v2

    .end local v3    # "it\\1":Ljava/lang/String;
    .end local v4    # "$i$a$-takeIf-MainActivity$toggleProfile$1$1$1\\1\\176\\0":I
    :goto_1
    if-eqz v5, :cond_3

    move-object v1, v0

    :cond_3
    if-eqz v1, :cond_4

    .line 1369
    .local v1, "it\\2":Ljava/lang/String;
    const/4 v0, 0x0

    .line 176
    .local v0, "$i$a$-let-MainActivity$toggleProfile$1$1$2\\2\\176\\0":I
    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 178
    .end local v0    # "$i$a$-let-MainActivity$toggleProfile$1$1$2\\2\\176\\0":I
    .end local v1    # "it\\2":Ljava/lang/String;
    :cond_4
    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setProfileBusy(Z)V

    .line 179
    return-void
.end method

.method private final watchImport(Lorg/lighttouch/android/IEngine;Lkotlin/jvm/functions/Function2;)Lkotlin/jvm/functions/Function0;
    .locals 4
    .param p1, "worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "show"    # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/IEngine;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/String;",
            "-",
            "Ljava/lang/Float;",
            "Lkotlin/Unit;",
            ">;)",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    .line 566
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 567
    .local v0, "running":Ljava/util/concurrent/atomic/AtomicBoolean;
    new-instance v1, Ljava/lang/Thread;

    .line 577
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda12;

    invoke-direct {v2, v0, p1, p0, p2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda12;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function2;)V

    .line 567
    const-string v3, "import-progress"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 577
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 578
    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda13;

    invoke-direct {v1, v0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda13;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;)V

    return-object v1
.end method

.method private static final watchImport$lambda$81(Ljava/util/concurrent/atomic/AtomicBoolean;Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;Lkotlin/jvm/functions/Function2;)V
    .locals 9
    .param p0, "$running"    # Ljava/util/concurrent/atomic/AtomicBoolean;
    .param p1, "$worker"    # Lorg/lighttouch/android/IEngine;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p3, "$show"    # Lkotlin/jvm/functions/Function2;

    .line 568
    nop

    :goto_0
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 569
    :try_start_0
    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->importProgress()Landroid/os/Bundle;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    const/4 v1, 0x0

    move-object v0, v1

    .line 570
    .local v0, "p":Landroid/os/Bundle;
    :goto_1
    if-eqz v0, :cond_2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 571
    const-string v1, "done"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v1

    .local v1, "done":J
    const-string v3, "total"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    .line 572
    .local v3, "total":J
    const-string v5, "phase"

    invoke-virtual {v0, v5}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_0

    const-string v5, ""

    :cond_0
    invoke-direct {p2, v5}, Lorg/lighttouch/android/MainActivity;->importPhaseText(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .local v5, "text":Ljava/lang/String;
    const-wide/16 v6, 0x0

    cmp-long v6, v3, v6

    if-lez v6, :cond_1

    long-to-float v6, v1

    long-to-float v7, v3

    div-float/2addr v6, v7

    goto :goto_2

    :cond_1
    const/high16 v6, -0x40800000    # -1.0f

    .line 573
    .local v6, "fraction":F
    :goto_2
    iget-object v7, p2, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v8, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda64;

    invoke-direct {v8, p0, p3, v5, v6}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda64;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Lkotlin/jvm/functions/Function2;Ljava/lang/String;F)V

    invoke-virtual {v7, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 575
    .end local v1    # "done":J
    .end local v3    # "total":J
    .end local v5    # "text":Ljava/lang/String;
    .end local v6    # "fraction":F
    :cond_2
    const-wide/16 v1, 0xfa

    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V

    .end local v0    # "p":Landroid/os/Bundle;
    goto :goto_0

    .line 577
    :cond_3
    return-void
.end method

.method private static final watchImport$lambda$81$lambda$80(Ljava/util/concurrent/atomic/AtomicBoolean;Lkotlin/jvm/functions/Function2;Ljava/lang/String;F)V
    .locals 1
    .param p0, "$running"    # Ljava/util/concurrent/atomic/AtomicBoolean;
    .param p1, "$show"    # Lkotlin/jvm/functions/Function2;
    .param p2, "$text"    # Ljava/lang/String;
    .param p3, "$fraction"    # F

    .line 573
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-interface {p1, p2, v0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method private static final watchImport$lambda$82(Ljava/util/concurrent/atomic/AtomicBoolean;)Lkotlin/Unit;
    .locals 1
    .param p0, "$running"    # Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 578
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final workerExited()V
    .locals 10

    .line 974
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getWorkerPid()I

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v3

    goto :goto_1

    :cond_1
    :goto_0
    move v1, v2

    :goto_1
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/SessionDeliveryGate;->retire(Z)Ljava/lang/Long;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    move-wide v8, v0

    .line 975
    .local v8, "evidenceGeneration":J
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->engineExpectedExit:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->guestStartRequested:Z

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSessionOwned()Z

    move-result v0

    if-nez v0, :cond_2

    const/4 v0, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "running"

    aput-object v1, v0, v3

    const-string v1, "starting"

    aput-object v1, v0, v2

    const/4 v1, 0x2

    const-string v4, "paused"

    aput-object v4, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    :cond_2
    move v7, v2

    goto :goto_2

    :cond_3
    move v7, v3

    .line 976
    .local v7, "unexpected":Z
    :goto_2
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getWorkerPid()I

    move-result v6

    .line 977
    .local v6, "exitedPid":I
    invoke-direct {p0, v3}, Lorg/lighttouch/android/MainActivity;->setProfileRecording(Z)V

    invoke-direct {p0, v3}, Lorg/lighttouch/android/MainActivity;->setProfileBusy(Z)V

    .line 978
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setEngine(Lorg/lighttouch/android/IEngine;)V

    invoke-direct {p0, v3}, Lorg/lighttouch/android/MainActivity;->setWorkerPid(I)V

    invoke-direct {p0, v3}, Lorg/lighttouch/android/MainActivity;->setSessionOwned(Z)V

    invoke-direct {p0, v3}, Lorg/lighttouch/android/MainActivity;->setDisplayAsleep(Z)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopSensors()V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v0, :cond_4

    invoke-virtual {v0, v3}, Lorg/lighttouch/android/GuestDisplay;->setKeepScreenOn(Z)V

    .line 979
    :cond_4
    if-eqz v7, :cond_5

    const-string v0, "failed"

    goto :goto_3

    :cond_5
    const-string v0, "stopped"

    :goto_3
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setStatus(Ljava/lang/String;)V

    .line 980
    const-string v0, ""

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setDetail(Ljava/lang/String;)V

    .line 981
    if-eqz v7, :cond_6

    const-string v0, "\u5ba2\u6237\u673a\u5de5\u4f5c\u8fdb\u7a0b\u610f\u5916\u9000\u51fa\uff1b\u53ef\u5199\u72b6\u6001\u5df2\u4fdd\u7559\u3002\u542f\u52a8\u4f1a\u521b\u5efa\u65b0\u7684\u5de5\u4f5c\u8fdb\u7a0b\uff0c\u79c1\u6709\u8bca\u65ad\u4fe1\u606f\u4e5f\u5df2\u4fdd\u7559\u3002"

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 982
    :cond_6
    new-instance v0, Ljava/lang/Thread;

    .line 996
    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda114;

    move-object v5, p0

    invoke-direct/range {v4 .. v9}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda114;-><init>(Lorg/lighttouch/android/MainActivity;IZJ)V

    .line 982
    const-string v1, "worker-retained-error"

    invoke-direct {v0, v4, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 996
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 997
    return-void

    .line 974
    .end local v6    # "exitedPid":I
    .end local v7    # "unexpected":Z
    .end local v8    # "evidenceGeneration":J
    :cond_7
    return-void
.end method

.method private static final workerExited$lambda$209(Lorg/lighttouch/android/MainActivity;IZJ)V
    .locals 8
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$exitedPid"    # I
    .param p2, "$unexpected"    # Z
    .param p3, "$evidenceGeneration"    # J

    .line 983
    sget-object v0, Lorg/lighttouch/android/WorkerExitEvidence;->INSTANCE:Lorg/lighttouch/android/WorkerExitEvidence;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "getApplicationContext(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1, p1}, Lorg/lighttouch/android/WorkerExitEvidence;->capture(Landroid/content/Context;I)V

    .line 984
    nop

    .line 985
    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    :try_start_0
    new-instance v3, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "worker-shutdown-"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".json"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 986
    .local v3, "file":Ljava/io/File;
    move-object v4, v3

    .line 1369
    .local v4, "it\\1":Ljava/io/File;
    const/4 v5, 0x0

    .line 986
    .local v5, "$i$a$-takeIf-MainActivity$workerExited$1$terminal$1\\1\\986\\0":I
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v6

    .end local v4    # "it\\1":Ljava/io/File;
    .end local v5    # "$i$a$-takeIf-MainActivity$workerExited$1$terminal$1\\1\\986\\0":I
    if-eqz v6, :cond_0

    move-object v4, v3

    goto :goto_0

    :cond_0
    move-object v4, v2

    :goto_0
    if-eqz v4, :cond_2

    invoke-static {v4, v2, v1, v2}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_2

    .line 1369
    .local v4, "it\\2":Ljava/lang/String;
    const/4 v5, 0x0

    .line 986
    .local v5, "$i$a$-let-MainActivity$workerExited$1$terminal$2\\2\\986\\0":I
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .end local v4    # "it\\2":Ljava/lang/String;
    .end local v5    # "$i$a$-let-MainActivity$workerExited$1$terminal$2\\2\\986\\0":I
    move-object v4, v6

    .line 1369
    .local v4, "it\\3":Lorg/json/JSONObject;
    const/4 v5, 0x0

    .line 986
    .local v5, "$i$a$-takeIf-MainActivity$workerExited$1$terminal$3\\3\\986\\0":I
    const-string v7, "workerPid"

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-ne v7, p1, :cond_1

    move v4, v1

    goto :goto_1

    :cond_1
    move v4, v0

    .end local v4    # "it\\3":Lorg/json/JSONObject;
    .end local v5    # "$i$a$-takeIf-MainActivity$workerExited$1$terminal$3\\3\\986\\0":I
    :goto_1
    if-eqz v4, :cond_2

    goto :goto_2

    :cond_2
    move-object v6, v2

    goto :goto_2

    .line 987
    .end local v3    # "file":Ljava/io/File;
    :catch_0
    move-exception v3

    move-object v6, v2

    .line 984
    :goto_2
    nop

    .line 988
    .local v6, "terminal":Lorg/json/JSONObject;
    :try_start_1
    new-instance v3, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "worker-stop-error-"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, ".txt"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v4, v3

    .line 1369
    .local v4, "it\\4":Ljava/io/File;
    const/4 v5, 0x0

    .line 988
    .local v5, "$i$a$-takeIf-MainActivity$workerExited$1$retained$1\\4\\988\\0":I
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v7

    .end local v4    # "it\\4":Ljava/io/File;
    .end local v5    # "$i$a$-takeIf-MainActivity$workerExited$1$retained$1\\4\\988\\0":I
    if-eqz v7, :cond_3

    goto :goto_3

    :cond_3
    move-object v3, v2

    :goto_3
    if-eqz v3, :cond_4

    invoke-static {v3, v2, v1, v2}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v3
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_4

    :cond_4
    move-object v3, v2

    goto :goto_4

    :catch_1
    move-exception v3

    move-object v3, v2

    .line 989
    .local v3, "retained":Ljava/lang/String;
    :goto_4
    if-eqz v6, :cond_7

    .line 990
    const-string v2, "error"

    invoke-virtual {v6, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 991
    .local v2, "reported":Ljava/lang/String;
    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_5

    move v0, v1

    :cond_5
    if-eqz v0, :cond_6

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda89;

    invoke-direct {v1, p0, p3, p4, v2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda89;-><init>(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_5

    .line 992
    :cond_6
    if-nez p2, :cond_a

    const-string v0, "reason"

    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "native-terminal"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    const-string v0, "nativeTerminalState"

    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "stopped"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 993
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda90;

    invoke-direct {v1, p0, p3, p4}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda90;-><init>(Lorg/lighttouch/android/MainActivity;J)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_5

    .line 995
    .end local v2    # "reported":Ljava/lang/String;
    :cond_7
    if-eqz v3, :cond_a

    move-object v4, v3

    .line 1369
    .local v4, "it\\5":Ljava/lang/String;
    const/4 v5, 0x0

    .line 995
    .local v5, "$i$a$-takeIf-MainActivity$workerExited$1$3\\5\\995\\0":I
    move-object v7, v4

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_8

    move v0, v1

    .end local v4    # "it\\5":Ljava/lang/String;
    .end local v5    # "$i$a$-takeIf-MainActivity$workerExited$1$3\\5\\995\\0":I
    :cond_8
    if-eqz v0, :cond_9

    move-object v2, v3

    :cond_9
    if-eqz v2, :cond_a

    .line 1369
    .local v2, "it\\6":Ljava/lang/String;
    const/4 v0, 0x0

    .line 995
    .local v0, "$i$a$-let-MainActivity$workerExited$1$4\\6\\995\\0":I
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda91;

    invoke-direct {v4, p0, p3, p4, v2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda91;-><init>(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V

    invoke-virtual {v1, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 996
    .end local v0    # "$i$a$-let-MainActivity$workerExited$1$4\\6\\995\\0":I
    .end local v2    # "it\\6":Ljava/lang/String;
    :cond_a
    :goto_5
    return-void
.end method

.method private static final workerExited$lambda$209$lambda$202(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$evidenceGeneration"    # J
    .param p3, "$reported"    # Ljava/lang/String;

    .line 991
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda81;

    invoke-direct {v1, p0, p3}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda81;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v0, p1, p2, v1}, Lorg/lighttouch/android/SessionDeliveryGate;->deliver(JLkotlin/jvm/functions/Function0;)Z

    return-void
.end method

.method private static final workerExited$lambda$209$lambda$202$lambda$201(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$reported"    # Ljava/lang/String;

    .line 991
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final workerExited$lambda$209$lambda$204(Lorg/lighttouch/android/MainActivity;J)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$evidenceGeneration"    # J

    .line 993
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/MainActivity;)V

    invoke-virtual {v0, p1, p2, v1}, Lorg/lighttouch/android/SessionDeliveryGate;->deliver(JLkotlin/jvm/functions/Function0;)Z

    return-void
.end method

.method private static final workerExited$lambda$209$lambda$204$lambda$203(Lorg/lighttouch/android/MainActivity;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;

    .line 993
    const-string v0, ""

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final workerExited$lambda$209$lambda$208$lambda$207(Lorg/lighttouch/android/MainActivity;JLjava/lang/String;)V
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$evidenceGeneration"    # J
    .param p3, "$it"    # Ljava/lang/String;

    .line 995
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p3}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v0, p1, p2, v1}, Lorg/lighttouch/android/SessionDeliveryGate;->deliver(JLkotlin/jvm/functions/Function0;)Z

    return-void
.end method

.method private static final workerExited$lambda$209$lambda$208$lambda$207$lambda$206(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$it"    # Ljava/lang/String;

    .line 995
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final workerExitedRun()Landroid/os/Bundle;
    .locals 5

    .line 158
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v1, v0

    .line 1369
    .local v1, "$this$workerExitedRun_u24lambda_u2412\\1":Landroid/os/Bundle;
    const/4 v2, 0x0

    .line 158
    .local v2, "$i$a$-apply-MainActivity$workerExitedRun$1\\1\\158\\0":I
    const-string v3, "state"

    const-string v4, "failed"

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v3, "error"

    const-string v4, "\u51c6\u5907\u5de5\u4f5c\u8fdb\u7a0b\u610f\u5916\u505c\u6b62\uff0c\u8bf7\u91cd\u8bd5\u3002"

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .end local v1    # "$this$workerExitedRun_u24lambda_u2412\\1":Landroid/os/Bundle;
    .end local v2    # "$i$a$-apply-MainActivity$workerExitedRun$1\\1\\158\\0":I
    return-object v0
.end method


# virtual methods
.method public addDevice()V
    .locals 0

    .line 422
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->openPreparation()V

    return-void
.end method

.method public applySettings()V
    .locals 6

    .line 458
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/AppSettings;->getTilt()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopSensors()V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v0

    const-string v1, "running"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->startSensors()V

    .line 459
    :cond_1
    :goto_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_2

    return-void

    .line 460
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_2
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getScaling()Lorg/lighttouch/android/ScreenScaling;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/ScreenScaling;->getNative()I

    move-result v1

    .local v1, "scale":I
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/AppSettings;->getDetailedTiming()Z

    move-result v2

    .line 461
    .local v2, "detailed":Z
    new-instance v3, Ljava/lang/Thread;

    new-instance v4, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda15;

    invoke-direct {v4, v0, v1, v2}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda15;-><init>(Lorg/lighttouch/android/IEngine;IZ)V

    const-string v5, "apply-settings"

    invoke-direct {v3, v4, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    .line 462
    return-void
.end method

.method public button(IZ)V
    .locals 0
    .param p1, "id"    # I
    .param p2, "down"    # Z

    .line 410
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/MainActivity;->sendButton(IZ)V

    return-void
.end method

.method public deleteDevice(Ljava/lang/String;)V
    .locals 4
    .param p1, "id"    # Ljava/lang/String;

    const-string v0, "id"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 479
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 480
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    const/4 v1, 0x1

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    .line 481
    new-instance v1, Ljava/lang/Thread;

    .line 484
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda93;

    invoke-direct {v2, v0, p1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda93;-><init>(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V

    .line 481
    const-string v3, "device-delete"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 484
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 485
    return-void
.end method

.method public dismissError()V
    .locals 1

    .line 399
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getError()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/MainActivity;->dismissedError:Ljava/lang/String;

    const-string v0, ""

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    return-void
.end method

.method public getBusy()Z
    .locals 3

    .line 54
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->busy$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1288
    .local v2, "$i$f$getValue\\1\\54":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\54":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 54
    return v0
.end method

.method public getCanSaveState()Z
    .locals 1

    .line 107
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->canSaveState:Z

    return v0
.end method

.method public getDevices()Ljava/util/List;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/DeviceSummary;",
            ">;"
        }
    .end annotation

    .line 100
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getCatalogVersion()I

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getRecords()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1336
    .local v1, "$i$f$map\\1\\100":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 1337
    .local v4, "$i$f$mapTo\\2\\1336":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 1338
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Landroid/os/Bundle;

    .local v7, "it\\3":Landroid/os/Bundle;
    const/4 v8, 0x0

    .line 100
    .local v8, "$i$a$-map-MainActivity$devices$1\\3\\1338\\0":I
    sget-object v9, Lorg/lighttouch/android/DeviceSummary;->Companion:Lorg/lighttouch/android/DeviceSummary$Companion;

    iget-object v10, p0, Lorg/lighttouch/android/MainActivity;->firmwareTargets:Ljava/util/Map;

    invoke-virtual {v9, v7, v10}, Lorg/lighttouch/android/DeviceSummary$Companion;->of(Landroid/os/Bundle;Ljava/util/Map;)Lorg/lighttouch/android/DeviceSummary;

    move-result-object v7

    .line 1338
    .end local v7    # "it\\3":Landroid/os/Bundle;
    .end local v8    # "$i$a$-map-MainActivity$devices$1\\3\\1338\\0":I
    invoke-interface {v2, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 1339
    .end local v6    # "item\\2":Ljava/lang/Object;
    :cond_0
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\1336":I
    check-cast v2, Ljava/util/List;

    .line 1336
    nop

    .line 100
    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\100":I
    return-object v2
.end method

.method public getDisplayAsleep()Z
    .locals 3

    .line 40
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayAsleep$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1276
    .local v2, "$i$f$getValue\\1\\40":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\40":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 40
    return v0
.end method

.method public getError()Ljava/lang/String;
    .locals 3

    .line 42
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->error$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1279
    .local v2, "$i$f$getValue\\1\\42":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\42":I
    check-cast v0, Ljava/lang/String;

    .line 42
    return-object v0
.end method

.method public getFaithfulScaler()Z
    .locals 3

    .line 68
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->faithfulScaler$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1309
    .local v2, "$i$f$getValue\\1\\68":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\68":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 68
    return v0
.end method

.method public getMicrophone()Z
    .locals 1

    .line 71
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/AppSettings;->getMicrophone()Z

    move-result v0

    return v0
.end method

.method public getPerf()Lorg/lighttouch/android/PerfSnapshot;
    .locals 1

    .line 104
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->monitor:Lorg/lighttouch/android/PerformanceMonitor;

    invoke-virtual {v0}, Lorg/lighttouch/android/PerformanceMonitor;->getSnapshot()Lorg/lighttouch/android/PerfSnapshot;

    move-result-object v0

    return-object v0
.end method

.method public getPresentAsync()Z
    .locals 3

    .line 67
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->presentAsync$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1306
    .local v2, "$i$f$getValue\\1\\67":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\67":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 67
    return v0
.end method

.method public getProfileAutomatic()Z
    .locals 3

    .line 60
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileAutomatic$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1297
    .local v2, "$i$f$getValue\\1\\60":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\60":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 60
    return v0
.end method

.method public getProfileBusy()Z
    .locals 3

    .line 62
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileBusy$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1300
    .local v2, "$i$f$getValue\\1\\62":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\62":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 62
    return v0
.end method

.method public getProfileNotice()Ljava/lang/String;
    .locals 3

    .line 64
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileNotice$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1303
    .local v2, "$i$f$getValue\\1\\64":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\64":I
    check-cast v0, Ljava/lang/String;

    .line 64
    return-object v0
.end method

.method public getProfileRecording()Z
    .locals 3

    .line 58
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->profileRecording$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1294
    .local v2, "$i$f$getValue\\1\\58":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\58":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 58
    return v0
.end method

.method public getSelected()Lorg/lighttouch/android/DeviceSummary;
    .locals 6

    .line 101
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getDevices()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 1340
    .local v1, "$i$f$firstOrNull\\1\\101":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lorg/lighttouch/android/DeviceSummary;

    .local v4, "it\\2":Lorg/lighttouch/android/DeviceSummary;
    const/4 v5, 0x0

    .line 101
    .local v5, "$i$a$-firstOrNull-MainActivity$selected$1\\2\\1340\\0":I
    invoke-virtual {v4}, Lorg/lighttouch/android/DeviceSummary;->getSelected()Z

    move-result v4

    .line 1340
    .end local v4    # "it\\2":Lorg/lighttouch/android/DeviceSummary;
    .end local v5    # "$i$a$-firstOrNull-MainActivity$selected$1\\2\\1340\\0":I
    if-eqz v4, :cond_0

    goto :goto_0

    .line 1341
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_1
    const/4 v3, 0x0

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\101":I
    :goto_0
    check-cast v3, Lorg/lighttouch/android/DeviceSummary;

    .line 101
    return-object v3
.end method

.method public getSessionOwned()Z
    .locals 3

    .line 46
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->sessionOwned$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1285
    .local v2, "$i$f$getValue\\1\\46":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\46":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 46
    return v0
.end method

.method public getSettings()Lorg/lighttouch/android/AppSettings;
    .locals 1

    .line 102
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->settings$delegate:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/AppSettings;

    return-object v0
.end method

.method public getStatus()Ljava/lang/String;
    .locals 3

    .line 37
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->status$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 1270
    .local v2, "$i$f$getValue\\1\\37":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\37":I
    check-cast v0, Ljava/lang/String;

    .line 37
    return-object v0
.end method

.method public getStoreInstalling()Z
    .locals 1

    .line 105
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getStore()Lorg/lighttouch/android/StoreModel;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreModel;->getInstalling()Z

    move-result v0

    return v0
.end method

.method public navigate(Lorg/lighttouch/android/Screen;)V
    .locals 2
    .param p1, "screen"    # Lorg/lighttouch/android/Screen;

    const-string v0, "screen"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 413
    sget-object v0, Lorg/lighttouch/android/MainActivity$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p1}, Lorg/lighttouch/android/Screen;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    .line 416
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    goto :goto_0

    .line 415
    :pswitch_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->openStore()V

    goto :goto_0

    .line 414
    :pswitch_1
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setBase(Lorg/lighttouch/android/Screen;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 418
    :goto_0
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onAccuracyChanged(Landroid/hardware/Sensor;I)V
    .locals 1
    .param p1, "sensor"    # Landroid/hardware/Sensor;
    .param p2, "accuracy"    # I

    const-string v0, "sensor"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1211
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 14
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 295
    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onCreate(Landroid/os/Bundle;)V

    .line 297
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->setRequestedOrientation(I)V

    .line 298
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroidx/core/view/WindowCompat;->setDecorFitsSystemWindows(Landroid/view/Window;Z)V

    .line 300
    move-object v1, p0

    check-cast v1, Lorg/lighttouch/android/MainActivity;

    .line 1369
    .local v1, "$this$onCreate_u24lambda_u2430\\1":Lorg/lighttouch/android/MainActivity;
    const/4 v3, 0x0

    .line 300
    .local v3, "$i$a$-run-MainActivity$onCreate$1\\1\\300\\0":I
    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/view/Window;->setStatusBarColor(I)V

    invoke-virtual {v1}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 301
    .end local v1    # "$this$onCreate_u24lambda_u2430\\1":Lorg/lighttouch/android/MainActivity;
    .end local v3    # "$i$a$-run-MainActivity$onCreate$1\\1\\300\\0":I
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/view/Window;->setNavigationBarContrastEnforced(Z)V

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/view/Window;->setStatusBarContrastEnforced(Z)V

    .line 302
    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->preferSixtyHertz(Z)V

    .line 303
    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "debug-env"

    invoke-direct {v1, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 1369
    nop

    .local v1, "f\\2":Ljava/io/File;
    const/4 v3, 0x0

    .line 303
    .local v3, "$i$a$-let-MainActivity$onCreate$2\\2\\303\\0":I
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_3

    invoke-static {v1, v6, v0, v6}, Lkotlin/io/FilesKt;->readLines$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$any\\3":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1387
    .local v7, "$i$f$any\\3\\303":I
    instance-of v8, v5, Ljava/util/Collection;

    if-eqz v8, :cond_0

    move-object v8, v5

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_0

    move v5, v2

    goto :goto_0

    .line 1388
    :cond_0
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_2

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\3":Ljava/lang/Object;
    move-object v10, v9

    check-cast v10, Ljava/lang/String;

    .local v10, "it\\4":Ljava/lang/String;
    const/4 v11, 0x0

    .line 303
    .local v11, "$i$a$-any-MainActivity$onCreate$2$1\\4\\1388\\2":I
    move-object v12, v10

    check-cast v12, Ljava/lang/CharSequence;

    invoke-static {v12}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v12

    const-string v13, "LT_PRESENT_ASYNC=off"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    .line 1388
    .end local v10    # "it\\4":Ljava/lang/String;
    .end local v11    # "$i$a$-any-MainActivity$onCreate$2$1\\4\\1388\\2":I
    if-eqz v10, :cond_1

    move v5, v0

    goto :goto_0

    .line 1389
    .end local v9    # "element\\3":Ljava/lang/Object;
    :cond_2
    move v5, v2

    .line 303
    .end local v5    # "$this$any\\3":Ljava/lang/Iterable;
    .end local v7    # "$i$f$any\\3\\303":I
    :goto_0
    if-eqz v5, :cond_3

    move v1, v0

    goto :goto_1

    :cond_3
    move v1, v2

    .end local v1    # "f\\2":Ljava/io/File;
    .end local v3    # "$i$a$-let-MainActivity$onCreate$2\\2\\303\\0":I
    :goto_1
    xor-int/2addr v1, v0

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/MainActivity;->setPresentAsync(Z)V

    .line 304
    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getFilesDir()Ljava/io/File;

    move-result-object v3

    invoke-direct {v1, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 1369
    nop

    .local v1, "f\\5":Ljava/io/File;
    const/4 v3, 0x0

    .line 304
    .local v3, "$i$a$-let-MainActivity$onCreate$3\\5\\304\\0":I
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_7

    invoke-static {v1, v6, v0, v6}, Lkotlin/io/FilesKt;->readLines$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$any\\6":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 1390
    .local v5, "$i$f$any\\6\\304":I
    instance-of v7, v4, Ljava/util/Collection;

    if-eqz v7, :cond_4

    move-object v7, v4

    check-cast v7, Ljava/util/Collection;

    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_4

    move v4, v2

    goto :goto_2

    .line 1391
    :cond_4
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_6

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\6":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Ljava/lang/String;

    .local v9, "it\\7":Ljava/lang/String;
    const/4 v10, 0x0

    .line 304
    .local v10, "$i$a$-any-MainActivity$onCreate$3$1\\7\\1391\\5":I
    move-object v11, v9

    check-cast v11, Ljava/lang/CharSequence;

    invoke-static {v11}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v11

    const-string v12, "LT_SCALER_TIME_NS=0"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    .line 1391
    .end local v9    # "it\\7":Ljava/lang/String;
    .end local v10    # "$i$a$-any-MainActivity$onCreate$3$1\\7\\1391\\5":I
    if-eqz v9, :cond_5

    move v4, v0

    goto :goto_2

    .line 1392
    .end local v8    # "element\\6":Ljava/lang/Object;
    :cond_6
    move v4, v2

    .line 304
    .end local v4    # "$this$any\\6":Ljava/lang/Iterable;
    .end local v5    # "$i$f$any\\6\\304":I
    :goto_2
    if-eqz v4, :cond_7

    move v1, v0

    goto :goto_3

    :cond_7
    move v1, v2

    .end local v1    # "f\\5":Ljava/io/File;
    .end local v3    # "$i$a$-let-MainActivity$onCreate$3\\5\\304\\0":I
    :goto_3
    xor-int/2addr v1, v0

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setFaithfulScaler(Z)V

    .line 305
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getInstaller()Lorg/lighttouch/android/StoreInstaller;

    move-result-object v1

    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->idleHook:Lkotlin/jvm/functions/Function0;

    invoke-virtual {v1, v3}, Lorg/lighttouch/android/StoreInstaller;->setOnIdle(Lkotlin/jvm/functions/Function0;)V

    .line 308
    new-instance v1, Ljava/lang/Thread;

    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda27;

    invoke-direct {v3, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda27;-><init>(Lorg/lighttouch/android/MainActivity;)V

    const-string v4, "previous-worker-exit"

    invoke-direct {v1, v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 309
    const-string v1, "preparation-imports"

    invoke-virtual {p0, v1, v2}, Lorg/lighttouch/android/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 310
    .local v1, "imports":Landroid/content/SharedPreferences;
    const-string v3, "ipsw"

    const-string v4, ""

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_a

    move-object v5, v3

    .line 1369
    .local v5, "it\\8":Ljava/lang/String;
    const/4 v7, 0x0

    .line 310
    .local v7, "$i$a$-takeIf-MainActivity$onCreate$5\\8\\310\\0":I
    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8}, Ljava/io/File;->isFile()Z

    move-result v5

    .end local v5    # "it\\8":Ljava/lang/String;
    .end local v7    # "$i$a$-takeIf-MainActivity$onCreate$5\\8\\310\\0":I
    if-eqz v5, :cond_8

    goto :goto_4

    :cond_8
    move-object v3, v6

    :goto_4
    if-eqz v3, :cond_a

    .line 1369
    .local v3, "it\\9":Ljava/lang/String;
    const/4 v5, 0x0

    .line 310
    .local v5, "$i$a$-let-MainActivity$onCreate$6\\9\\310\\0":I
    iget-object v7, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v7, v3}, Lorg/lighttouch/android/PrepareState;->setIpswPath(Ljava/lang/String;)V

    iget-object v7, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v8, "ipswFor"

    invoke-interface {v1, v8, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_9

    move-object v8, v4

    :cond_9
    invoke-virtual {v7, v8}, Lorg/lighttouch/android/PrepareState;->setIpswFor(Ljava/lang/String;)V

    .line 311
    .end local v3    # "it\\9":Ljava/lang/String;
    .end local v5    # "$i$a$-let-MainActivity$onCreate$6\\9\\310\\0":I
    :cond_a
    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v5, "firmwareId"

    invoke-interface {v1, v5, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_b

    move-object v5, v4

    :cond_b
    invoke-virtual {v3, v5}, Lorg/lighttouch/android/PrepareState;->setFirmwareId(Ljava/lang/String;)V

    .line 312
    const-string v3, "preparedImported"

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_c

    move-object v3, v4

    :cond_c
    iput-object v3, p0, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    .line 313
    const-string v3, "pendingPrepared"

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_d

    goto :goto_5

    :cond_d
    move-object v4, v3

    :goto_5
    iput-object v4, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    .line 314
    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_e

    move v2, v0

    :cond_e
    if-eqz v2, :cond_f

    .line 315
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->retainedPreparation()Landroid/os/Bundle;

    move-result-object v3

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/PrepareState;->setPreparation(Landroid/os/Bundle;)V

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->retainedPreparedOutput:Ljava/lang/String;

    iput-object v2, p0, Lorg/lighttouch/android/MainActivity;->preparedImported:Ljava/lang/String;

    .line 316
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    const-string v3, "\u5df2\u51c6\u5907\u7684\u8bbe\u5907\u4ecd\u7136\u4fdd\u7559\uff0c\u8bf7\u91cd\u65b0\u6dfb\u52a0\u3002"

    invoke-virtual {v2, v3}, Lorg/lighttouch/android/PrepareState;->setImportError(Ljava/lang/String;)V

    goto :goto_6

    .line 317
    :cond_f
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->resumePreparation()V

    .line 318
    :goto_6
    new-instance v2, Ljava/lang/Thread;

    .line 326
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda28;

    invoke-direct {v3, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda28;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 318
    const-string v4, "store-targets"

    invoke-direct {v2, v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 326
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 327
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindWorker()V

    .line 328
    move-object v2, p0

    check-cast v2, Landroidx/activity/ComponentActivity;

    new-instance v3, Lorg/lighttouch/android/MainActivity$onCreate$8;

    invoke-direct {v3, p0}, Lorg/lighttouch/android/MainActivity$onCreate$8;-><init>(Lorg/lighttouch/android/MainActivity;)V

    const v4, -0x5e9d4912

    invoke-static {v4, v0, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function2;

    invoke-static {v2, v6, v3, v0, v6}, Landroidx/activity/compose/ComponentActivityKt;->setContent$default(Landroidx/activity/ComponentActivity;Landroidx/compose/runtime/CompositionContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)V

    .line 394
    return-void
.end method

.method protected onDestroy()V
    .locals 5

    .line 1264
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getInstaller()Lorg/lighttouch/android/StoreInstaller;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreInstaller;->getOnIdle()Lkotlin/jvm/functions/Function0;

    move-result-object v0

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->idleHook:Lkotlin/jvm/functions/Function0;

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getInstaller()Lorg/lighttouch/android/StoreInstaller;

    move-result-object v0

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/StoreInstaller;->setOnIdle(Lkotlin/jvm/functions/Function0;)V

    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->buttonCalls:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->monitor:Lorg/lighttouch/android/PerformanceMonitor;

    invoke-virtual {v0}, Lorg/lighttouch/android/PerformanceMonitor;->close()V

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestDisplay;->retireDisplay$app_debug()V

    :cond_1
    sget-object v0, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v0}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v0

    iget-wide v3, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    invoke-virtual {v0, p0, v3, v4}, Lorg/lighttouch/android/ActiveDisplayOwner;->stopped(Ljava/lang/Object;J)Z

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->workerEvidenceDelivery:Lorg/lighttouch/android/SessionDeliveryGate;

    invoke-virtual {v0}, Lorg/lighttouch/android/SessionDeliveryGate;->advance()J

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopSensors()V

    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->bound:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->connection:Lorg/lighttouch/android/MainActivity$connection$1;

    check-cast v0, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_2
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareBound:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->firmwareConnection:Lorg/lighttouch/android/MainActivity$firmwareConnection$1;

    check-cast v0, Landroid/content/ServiceConnection;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_3
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onDestroy()V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "keyCode"    # I
    .param p2, "event"    # Landroid/view/KeyEvent;

    const-string v0, "event"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 649
    packed-switch p1, :pswitch_data_0

    const/4 v0, -0x1

    goto :goto_0

    :pswitch_0
    const/4 v0, 0x3

    goto :goto_0

    :pswitch_1
    const/4 v0, 0x2

    .line 650
    .local v0, "volume":I
    :goto_0
    if-ltz v0, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getVolumeKeys()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v1

    const-string v2, "running"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v1

    if-nez v1, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getDevicesOpen()Z

    move-result v1

    if-nez v1, :cond_1

    .line 651
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result v1

    const/4 v2, 0x1

    if-nez v1, :cond_0

    invoke-direct {p0, v0, v2}, Lorg/lighttouch/android/MainActivity;->sendButton(IZ)V

    .line 652
    :cond_0
    return v2

    .line 654
    :cond_1
    invoke-super {p0, p1, p2}, Landroidx/activity/ComponentActivity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result v1

    return v1

    nop

    :pswitch_data_0
    .packed-switch 0x18
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 3
    .param p1, "keyCode"    # I
    .param p2, "event"    # Landroid/view/KeyEvent;

    const-string v0, "event"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 657
    packed-switch p1, :pswitch_data_0

    const/4 v0, -0x1

    goto :goto_0

    :pswitch_0
    const/4 v0, 0x3

    goto :goto_0

    :pswitch_1
    const/4 v0, 0x2

    .line 658
    .local v0, "volume":I
    :goto_0
    if-ltz v0, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getVolumeKeys()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v1

    const-string v2, "running"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v1

    if-nez v1, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getDevicesOpen()Z

    move-result v1

    if-nez v1, :cond_0

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lorg/lighttouch/android/MainActivity;->sendButton(IZ)V

    const/4 v1, 0x1

    return v1

    .line 659
    :cond_0
    invoke-super {p0, p1, p2}, Landroidx/activity/ComponentActivity;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result v1

    return v1

    :pswitch_data_0
    .packed-switch 0x18
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method protected onPause()V
    .locals 1

    .line 1236
    const/4 v0, 0x0

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->displayResumed:Z

    sget-object v0, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v0}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v0

    invoke-virtual {v0, p0}, Lorg/lighttouch/android/ActiveDisplayOwner;->paused(Ljava/lang/Object;)V

    .line 1237
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestDisplay;->cancelOwnedGesture$app_debug()V

    :cond_0
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onPause()V

    .line 1238
    return-void
.end method

.method protected onPostResume()V
    .locals 4

    .line 1219
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onPostResume()V

    .line 1220
    sget-object v0, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v0}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->hasWindowFocus()Z

    move-result v1

    invoke-virtual {v0, p0, v1}, Lorg/lighttouch/android/ActiveDisplayOwner;->focusChanged(Ljava/lang/Object;Z)J

    move-result-wide v0

    iput-wide v0, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    .line 1221
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestDisplay;->attachActiveSurface$app_debug()V

    .line 1223
    :cond_0
    iget-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->pausedByBackground:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/AppSettings;->getAutoResume()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda66;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda66;-><init>(Lorg/lighttouch/android/MainActivity;)V

    .line 1226
    nop

    .line 1223
    const-wide/16 v2, 0x12c

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 1227
    :cond_1
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 1214
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onResume()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->displayResumed:Z

    .line 1215
    sget-object v0, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v0}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->hasWindowFocus()Z

    move-result v1

    invoke-virtual {v0, p0, v1}, Lorg/lighttouch/android/ActiveDisplayOwner;->resumed(Ljava/lang/Object;Z)J

    move-result-wide v0

    iput-wide v0, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    .line 1216
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestDisplay;->attachActiveSurface$app_debug()V

    .line 1217
    :cond_0
    return-void
.end method

.method public onSensorChanged(Landroid/hardware/SensorEvent;)V
    .locals 7
    .param p1, "event"    # Landroid/hardware/SensorEvent;

    const-string v0, "event"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1184
    iget-object v0, p1, Landroid/hardware/SensorEvent;->sensor:Landroid/hardware/Sensor;

    invoke-virtual {v0}, Landroid/hardware/Sensor;->getType()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_0

    const/4 v0, 0x2

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    :goto_0
    move v2, v0

    .line 1185
    .local v2, "kind":I
    :try_start_0
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->motionWorker:Lorg/lighttouch/android/IEngine;

    if-eqz v1, :cond_1

    iget-wide v3, p1, Landroid/hardware/SensorEvent;->timestamp:J

    iget-object v0, p1, Landroid/hardware/SensorEvent;->values:[F

    const-string v5, "values"

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x3

    invoke-static {v0, v5}, Ljava/util/Arrays;->copyOf([FI)[F

    move-result-object v5

    const-string v0, "copyOf(...)"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iget v6, p0, Lorg/lighttouch/android/MainActivity;->displayRotation:I

    invoke-interface/range {v1 .. v6}, Lorg/lighttouch/android/IEngine;->motion(IJ[FI)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .line 1186
    :cond_1
    :goto_1
    return-void
.end method

.method protected onStart()V
    .locals 5

    .line 1212
    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onStart()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getInstaller()Lorg/lighttouch/android/StoreInstaller;

    move-result-object v1

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/StoreInstaller;->setVisible(Z)V

    sget-object v1, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v1}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v1

    invoke-virtual {v1, p0}, Lorg/lighttouch/android/ActiveDisplayOwner;->started(Ljava/lang/Object;)V

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v1, :cond_0

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "starting"

    aput-object v4, v2, v3

    const-string v3, "running"

    aput-object v3, v2, v0

    const/4 v0, 0x2

    const-string v3, "stopping"

    aput-object v3, v2, v0

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/GuestDisplay;->setKeepScreenOn(Z)V

    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->poll:Lorg/lighttouch/android/MainActivity$poll$1;

    check-cast v1, Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method protected onStop()V
    .locals 7

    .line 1240
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->ownsDisplay()Z

    move-result v0

    .line 1241
    .local v0, "wasOwner":Z
    const/4 v1, 0x0

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->active:Z

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v2, :cond_0

    invoke-virtual {v2, v1}, Lorg/lighttouch/android/GuestDisplay;->setKeepScreenOn(Z)V

    :cond_0
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopSensors()V

    .line 1244
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getInstaller()Lorg/lighttouch/android/StoreInstaller;

    move-result-object v2

    invoke-virtual {v2, v1}, Lorg/lighttouch/android/StoreInstaller;->setVisible(Z)V

    .line 1245
    if-eqz v0, :cond_5

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSessionOwned()Z

    move-result v2

    const-string v3, "running"

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/String;

    const-string v6, "stopping"

    aput-object v6, v2, v1

    const-string v6, "stopped"

    aput-object v6, v2, v5

    const-string v6, "failed"

    aput-object v6, v2, v4

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v2, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    :cond_1
    new-array v2, v4, [Ljava/lang/String;

    aput-object v3, v2, v1

    const-string v4, "starting"

    aput-object v4, v2, v5

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 1247
    :cond_2
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getInstaller()Lorg/lighttouch/android/StoreInstaller;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue;->getActive()Z

    move-result v2

    if-eqz v2, :cond_3

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v2, :cond_6

    invoke-virtual {v2}, Lorg/lighttouch/android/GuestDisplay;->retireDisplay$app_debug()V

    goto :goto_1

    .line 1249
    :cond_3
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v2

    sget-object v3, Lorg/lighttouch/android/Screen;->HITCH:Lorg/lighttouch/android/Screen;

    if-eq v2, v3, :cond_4

    goto :goto_0

    :cond_4
    move v5, v1

    :goto_0
    iput-boolean v5, p0, Lorg/lighttouch/android/MainActivity;->pausedByBackground:Z

    .line 1250
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v2, :cond_6

    invoke-virtual {v2}, Lorg/lighttouch/android/GuestDisplay;->backgroundOwnedDisplay$app_debug()V

    goto :goto_1

    .line 1253
    :cond_5
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v2, :cond_6

    invoke-virtual {v2}, Lorg/lighttouch/android/GuestDisplay;->retireDisplay$app_debug()V

    .line 1254
    :cond_6
    :goto_1
    sget-object v2, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v2}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v2

    iget-wide v3, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    invoke-virtual {v2, p0, v3, v4}, Lorg/lighttouch/android/ActiveDisplayOwner;->stopped(Ljava/lang/Object;J)Z

    .line 1255
    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->handler:Landroid/os/Handler;

    iget-object v3, p0, Lorg/lighttouch/android/MainActivity;->poll:Lorg/lighttouch/android/MainActivity$poll$1;

    check-cast v3, Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lorg/lighttouch/android/MainActivity;->monitor:Lorg/lighttouch/android/PerformanceMonitor;

    invoke-virtual {v2, v1, v1}, Lorg/lighttouch/android/PerformanceMonitor;->setActive(ZZ)V

    invoke-super {p0}, Landroidx/activity/ComponentActivity;->onStop()V

    .line 1256
    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 4
    .param p1, "hasFocus"    # Z

    .line 1229
    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onWindowFocusChanged(Z)V

    .line 1230
    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getBase()Lorg/lighttouch/android/Screen;

    move-result-object v2

    sget-object v3, Lorg/lighttouch/android/Screen;->FULLSCREEN:Lorg/lighttouch/android/Screen;

    if-ne v2, v3, :cond_0

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getOverlay()Lorg/lighttouch/android/Screen;

    move-result-object v2

    if-nez v2, :cond_0

    move v2, v0

    goto :goto_0

    :cond_0
    move v2, v1

    :goto_0
    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->applyWindowMode(Z)V

    .line 1232
    :cond_1
    sget-object v2, Lorg/lighttouch/android/DisplayOwners;->INSTANCE:Lorg/lighttouch/android/DisplayOwners;

    invoke-virtual {v2}, Lorg/lighttouch/android/DisplayOwners;->getActive()Lorg/lighttouch/android/ActiveDisplayOwner;

    move-result-object v2

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->hasWindowFocus()Z

    move-result v3

    if-eqz v3, :cond_2

    goto :goto_1

    :cond_2
    move v0, v1

    :goto_1
    invoke-virtual {v2, p0, v0}, Lorg/lighttouch/android/ActiveDisplayOwner;->focusChanged(Ljava/lang/Object;Z)J

    move-result-wide v0

    iput-wide v0, p0, Lorg/lighttouch/android/MainActivity;->displayOwnerTicket:J

    .line 1233
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestDisplay;->attachActiveSurface$app_debug()V

    .line 1234
    :cond_3
    return-void
.end method

.method public openDetails(Lorg/lighttouch/android/DeviceSummary;)V
    .locals 1
    .param p1, "device"    # Lorg/lighttouch/android/DeviceSummary;

    const-string v0, "device"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 421
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setDetailsDevice(Lorg/lighttouch/android/DeviceSummary;)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setDevicesOpen(Z)V

    sget-object v0, Lorg/lighttouch/android/Screen;->DETAILS:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    return-void
.end method

.method public openDevices()V
    .locals 3

    .line 419
    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, v1, v2, v0}, Lorg/lighttouch/android/MainActivity;->refreshDevices$default(Lorg/lighttouch/android/MainActivity;ZILjava/lang/Object;)V

    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setDevicesOpen(Z)V

    return-void
.end method

.method public openHitch()V
    .locals 5

    .line 489
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 490
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "running"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v4, "paused"

    aput-object v4, v1, v2

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    return-void

    .line 491
    :cond_1
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->hitchResume:Z

    .line 492
    const/4 v1, 0x0

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setHitchData(Lorg/lighttouch/android/HitchData;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setHitchError(Ljava/lang/String;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setHitchNotice(Ljava/lang/String;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setHitchReport(Landroid/net/Uri;)V

    .line 493
    sget-object v1, Lorg/lighttouch/android/Screen;->HITCH:Lorg/lighttouch/android/Screen;

    invoke-direct {p0, v1}, Lorg/lighttouch/android/MainActivity;->setOverlay(Lorg/lighttouch/android/Screen;)V

    .line 494
    iget-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->hitchResume:Z

    .line 495
    .local v1, "running":Z
    new-instance v2, Ljava/lang/Thread;

    .line 505
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda92;

    invoke-direct {v3, v1, v0, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda92;-><init>(ZLorg/lighttouch/android/IEngine;Lorg/lighttouch/android/MainActivity;)V

    .line 495
    const-string v4, "hitch-snapshot"

    invoke-direct {v2, v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 505
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 506
    return-void
.end method

.method public openLicenses()V
    .locals 1

    .line 423
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setLicensesOpen(Z)V

    return-void
.end method

.method public openPreparation()V
    .locals 2

    .line 426
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->preparationActive()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v1, "state"

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "complete"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 427
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getFirmware()Lorg/lighttouch/android/CatalogFirmware;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->prep:Lorg/lighttouch/android/PrepareState;

    invoke-virtual {v1}, Lorg/lighttouch/android/PrepareState;->getIpswReady()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lorg/lighttouch/android/PrepareStep;->FILES:Lorg/lighttouch/android/PrepareStep;

    goto :goto_1

    :cond_1
    sget-object v1, Lorg/lighttouch/android/PrepareStep;->DEVICE:Lorg/lighttouch/android/PrepareStep;

    :goto_1
    invoke-virtual {v0, v1}, Lorg/lighttouch/android/PrepareState;->setStep(Lorg/lighttouch/android/PrepareStep;)V

    .line 428
    :cond_2
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setPreparationOpen(Z)V

    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->bindFirmware()V

    .line 429
    return-void
.end method

.method public pickGuestTools()V
    .locals 4

    .line 430
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->pickGuestToolsFile:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "application/octet-stream"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "*/*"

    aput-object v3, v1, v2

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    return-void
.end method

.method public pulse(I)V
    .locals 2
    .param p1, "id"    # I

    .line 1071
    const-wide/16 v0, 0x64

    invoke-direct {p0, p1, v0, v1}, Lorg/lighttouch/android/MainActivity;->pulse(IJ)V

    return-void
.end method

.method public recover()V
    .locals 3

    .line 401
    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0, v2, v0, v1, v0}, Lorg/lighttouch/android/MainActivity;->startGuest$default(Lorg/lighttouch/android/MainActivity;ZLorg/lighttouch/android/MainActivity$GuestStartRequest;ILjava/lang/Object;)V

    return-void
.end method

.method public renameDevice(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;

    const-string v0, "id"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 472
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 473
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    new-instance v1, Ljava/lang/Thread;

    .line 476
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda26;

    invoke-direct {v2, v0, p1, p2, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda26;-><init>(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V

    .line 473
    const-string v3, "device-rename"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 476
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 477
    return-void
.end method

.method public saveAndStop()V
    .locals 0

    .line 403
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopGuest()V

    return-void
.end method

.method public screenshot()V
    .locals 0

    .line 411
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->capture()V

    return-void
.end method

.method public selectDevice(Ljava/lang/String;)V
    .locals 4
    .param p1, "id"    # Ljava/lang/String;

    const-string v0, "id"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 464
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setBusy(Z)V

    .line 465
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    .line 466
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    new-instance v1, Ljava/lang/Thread;

    .line 469
    new-instance v2, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda112;

    invoke-direct {v2, v0, p1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda112;-><init>(Lorg/lighttouch/android/IEngine;Ljava/lang/String;Lorg/lighttouch/android/MainActivity;)V

    .line 466
    const-string v3, "device-selection"

    invoke-direct {v1, v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 469
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 470
    return-void
.end method

.method public setPaused(Z)V
    .locals 3
    .param p1, "paused"    # Z

    .line 405
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 406
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    if-eqz p1, :cond_1

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->displayView:Lorg/lighttouch/android/GuestDisplay;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Lorg/lighttouch/android/GuestDisplay;->cancelOwnedGesture$app_debug()V

    .line 407
    :cond_1
    const/4 v1, 0x0

    iput-boolean v1, p0, Lorg/lighttouch/android/MainActivity;->pausedByBackground:Z

    .line 408
    :try_start_0
    invoke-interface {v0, p1}, Lorg/lighttouch/android/IEngine;->pause(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    .local v1, "<unused var>":Landroid/os/RemoteException;
    const-string v2, "\u5ba2\u6237\u673a\u5de5\u4f5c\u8fdb\u7a0b\u4e0d\u53ef\u7528"

    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setError(Ljava/lang/String;)V

    .line 409
    .end local v1    # "<unused var>":Landroid/os/RemoteException;
    :goto_0
    return-void
.end method

.method public setPresentAsync(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 67
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity;->presentAsync$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 1307
    .local v3, "$i$f$setValue\\1\\67":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1308
    nop

    .line 67
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\67":I
    return-void
.end method

.method public start()V
    .locals 3

    .line 400
    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1, v0}, Lorg/lighttouch/android/MainActivity;->startGuest$default(Lorg/lighttouch/android/MainActivity;ZLorg/lighttouch/android/MainActivity$GuestStartRequest;ILjava/lang/Object;)V

    return-void
.end method

.method public stop()V
    .locals 0

    .line 402
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->stopGuest()V

    return-void
.end method

.method public toggleProfile()V
    .locals 5

    .line 166
    invoke-direct {p0}, Lorg/lighttouch/android/MainActivity;->getEngine()Lorg/lighttouch/android/IEngine;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 167
    .local v0, "worker":Lorg/lighttouch/android/IEngine;
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getProfileRecording()Z

    move-result v1

    const/4 v2, 0x1

    xor-int/2addr v1, v2

    .line 168
    .local v1, "recording":Z
    invoke-direct {p0, v2}, Lorg/lighttouch/android/MainActivity;->setProfileBusy(Z)V

    .line 169
    new-instance v2, Ljava/lang/Thread;

    .line 180
    new-instance v3, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda104;

    invoke-direct {v3, v0, v1, p0}, Lorg/lighttouch/android/MainActivity$$ExternalSyntheticLambda104;-><init>(Lorg/lighttouch/android/IEngine;ZLorg/lighttouch/android/MainActivity;)V

    .line 169
    const-string v4, "profile-control"

    invoke-direct {v2, v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 180
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 181
    return-void
.end method

.method public useFaithfulScaler(Z)V
    .locals 2
    .param p1, "on"    # Z

    .line 446
    if-eqz p1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const-string v0, "0"

    :goto_0
    const-string v1, "LT_SCALER_TIME_NS"

    invoke-direct {p0, v1, v0}, Lorg/lighttouch/android/MainActivity;->setDebugEnv(Ljava/lang/String;Ljava/lang/String;)V

    .line 447
    invoke-direct {p0, p1}, Lorg/lighttouch/android/MainActivity;->setFaithfulScaler(Z)V

    .line 448
    return-void
.end method

.method public useMicrophone(Z)V
    .locals 2
    .param p1, "on"    # Z

    .line 450
    if-eqz p1, :cond_0

    const-string v0, "android.permission.RECORD_AUDIO"

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_0

    .line 451
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity;->microphonePermission:Landroidx/activity/result/ActivityResultLauncher;

    invoke-virtual {v1, v0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 452
    return-void

    .line 454
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/AppSettings;->setMicrophone(Z)V

    .line 455
    if-eqz p1, :cond_1

    const-string v0, "\u4e0b\u6b21\u542f\u52a8\u540e\uff0c\u624b\u673a\u7684\u9ea6\u514b\u98ce\u5c06\u4f5c\u4e3a\u8bbe\u5907\u8f93\u5165"

    goto :goto_0

    :cond_1
    const-string v0, "\u4e0b\u6b21\u542f\u52a8\u540e\uff0c\u8bbe\u5907\u5c06\u6ca1\u6709\u9ea6\u514b\u98ce\u8f93\u5165"

    :goto_0
    invoke-direct {p0, v0}, Lorg/lighttouch/android/MainActivity;->setNotice(Ljava/lang/String;)V

    .line 456
    return-void
.end method

.method public usePresentAsync(Z)V
    .locals 2
    .param p1, "on"    # Z

    .line 442
    if-eqz p1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    const-string v0, "off"

    :goto_0
    const-string v1, "LT_PRESENT_ASYNC"

    invoke-direct {p0, v1, v0}, Lorg/lighttouch/android/MainActivity;->setDebugEnv(Ljava/lang/String;Ljava/lang/String;)V

    .line 443
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/MainActivity;->setPresentAsync(Z)V

    .line 444
    return-void
.end method

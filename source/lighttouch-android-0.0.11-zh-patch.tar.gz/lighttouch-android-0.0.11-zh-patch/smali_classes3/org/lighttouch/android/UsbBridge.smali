.class public final Lorg/lighttouch/android/UsbBridge;
.super Ljava/lang/Object;
.source "UsbBridge.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nUsbBridge.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UsbBridge.kt\norg/lighttouch/android/UsbBridge\n+ 2 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 5 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 6 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,81:1\n434#2:82\n507#2,5:83\n6590#3:88\n1869#4,2:89\n18#5:91\n1#6:92\n*S KotlinDebug\n*F\n+ 1 UsbBridge.kt\norg/lighttouch/android/UsbBridge\n*L\n28#1:82\n28#1:83,5\n32#1:88\n32#1:89,2\n66#1:91\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0002\u0008\u0001\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0014\u001a\u00020\u000fJ\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0007H\u0002J\u0008\u0010\u0018\u001a\u00020\u0019H\u0002J\u0006\u0010\u001a\u001a\u00020\u0019R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0008\u0010\tR\u0014\u0010\n\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u000b\u0010\tR\u0010\u0010\u000c\u001a\u0004\u0018\u00010\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\"\u0010\u0010\u001a\u0004\u0018\u00010\u000f2\u0008\u0010\u000e\u001a\u0004\u0018\u00010\u000f@BX\u0086\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0011\u0010\u0012\u00a8\u0006\u001b"
    }
    d2 = {
        "Lorg/lighttouch/android/UsbBridge;",
        "",
        "context",
        "Landroid/content/Context;",
        "<init>",
        "(Landroid/content/Context;)V",
        "daemonBinary",
        "Ljava/io/File;",
        "getDaemonBinary",
        "()Ljava/io/File;",
        "runRoot",
        "getRunRoot",
        "process",
        "Ljava/lang/Process;",
        "value",
        "",
        "muxSocket",
        "getMuxSocket",
        "()Ljava/lang/String;",
        "start",
        "recordId",
        "privateSocket",
        "",
        "file",
        "retireStale",
        "",
        "stop",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final context:Landroid/content/Context;

.field private volatile muxSocket:Ljava/lang/String;

.field private process:Ljava/lang/Process;


# direct methods
.method public static synthetic $r8$lambda$fTrAC4aOp6lwm5sQxAo9n18eQY4(Ljava/io/File;)Z
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/UsbBridge;->start$lambda$1(Ljava/io/File;)Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/UsbBridge;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/UsbBridge;->context:Landroid/content/Context;

    return-void
.end method

.method private final getDaemonBinary()Ljava/io/File;
    .locals 3

    .line 18
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lorg/lighttouch/android/UsbBridge;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    iget-object v1, v1, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;

    const-string v2, "libusbmuxd_qemu.so"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method private final getRunRoot()Ljava/io/File;
    .locals 3

    .line 19
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lorg/lighttouch/android/UsbBridge;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "usb-run"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method private final privateSocket(Ljava/io/File;)Z
    .locals 4
    .param p1, "file"    # Ljava/io/File;

    .line 59
    nop

    .line 60
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/system/Os;->lstat(Ljava/lang/String;)Landroid/system/StructStat;

    move-result-object v1

    .line 61
    .local v1, "st":Landroid/system/StructStat;
    iget v2, v1, Landroid/system/StructStat;->st_mode:I

    invoke-static {v2}, Landroid/system/OsConstants;->S_ISSOCK(I)Z

    move-result v2

    if-eqz v2, :cond_0

    iget v2, v1, Landroid/system/StructStat;->st_uid:I

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    if-ne v2, v3, :cond_0

    iget v2, v1, Landroid/system/StructStat;->st_mode:I
    :try_end_0
    .catch Landroid/system/ErrnoException; {:try_start_0 .. :try_end_0} :catch_0

    and-int/lit8 v2, v2, 0x3f

    if-nez v2, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    .line 62
    .end local v1    # "st":Landroid/system/StructStat;
    :catch_0
    move-exception v1

    :cond_0
    :goto_0
    return v0
.end method

.method private final retireStale()V
    .locals 11

    .line 66
    invoke-direct {p0}, Lorg/lighttouch/android/UsbBridge;->getRunRoot()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    .local v0, "$this$orEmpty\\1":[Ljava/lang/Object;
    const/4 v1, 0x0

    .line 91
    .local v1, "$i$f$orEmpty\\1\\66":I
    const/4 v2, 0x0

    if-nez v0, :cond_0

    new-array v3, v2, [Ljava/io/File;

    move-object v0, v3

    .line 66
    .end local v0    # "$this$orEmpty\\1":[Ljava/lang/Object;
    .end local v1    # "$i$f$orEmpty\\1\\66":I
    :cond_0
    array-length v1, v0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_7

    aget-object v4, v0, v3

    .line 67
    .local v4, "dir":Ljava/io/File;
    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_6

    .line 68
    new-instance v5, Ljava/io/File;

    const-string v6, "daemon.pid"

    invoke-direct {v5, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v5

    .line 92
    .local v6, "it\\2":Ljava/io/File;
    const/4 v7, 0x0

    .line 68
    .local v7, "$i$a$-takeIf-UsbBridge$retireStale$pid$1\\2\\68\\0":I
    invoke-virtual {v6}, Ljava/io/File;->isFile()Z

    move-result v6

    .end local v6    # "it\\2":Ljava/io/File;
    .end local v7    # "$i$a$-takeIf-UsbBridge$retireStale$pid$1\\2\\68\\0":I
    const/4 v7, 0x0

    if-eqz v6, :cond_1

    goto :goto_1

    :cond_1
    move-object v5, v7

    :goto_1
    const/4 v6, 0x1

    if-eqz v5, :cond_2

    invoke-static {v5, v7, v6, v7}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_2

    check-cast v5, Ljava/lang/CharSequence;

    invoke-static {v5}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-static {v5}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    goto :goto_2

    :cond_2
    move-object v5, v7

    .line 69
    .local v5, "pid":Ljava/lang/Integer;
    :goto_2
    if-eqz v5, :cond_5

    new-instance v8, Ljava/io/File;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "/proc/"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "/cmdline"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v9, v8

    .line 92
    .local v9, "it\\3":Ljava/io/File;
    const/4 v10, 0x0

    .line 69
    .local v10, "$i$a$-takeIf-UsbBridge$retireStale$1\\3\\69\\0":I
    invoke-virtual {v9}, Ljava/io/File;->exists()Z

    move-result v9

    .end local v9    # "it\\3":Ljava/io/File;
    .end local v10    # "$i$a$-takeIf-UsbBridge$retireStale$1\\3\\69\\0":I
    if-eqz v9, :cond_3

    goto :goto_3

    :cond_3
    move-object v8, v7

    :goto_3
    if-eqz v8, :cond_4

    invoke-static {v8, v7, v6, v7}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_4

    check-cast v8, Ljava/lang/CharSequence;

    const-string v9, "libusbmuxd_qemu"

    check-cast v9, Ljava/lang/CharSequence;

    const/4 v10, 0x2

    invoke-static {v8, v9, v2, v10, v7}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v7

    if-ne v7, v6, :cond_4

    goto :goto_4

    :cond_4
    move v6, v2

    :goto_4
    if-eqz v6, :cond_5

    .line 70
    :try_start_0
    sget-object v6, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v6, p0

    check-cast v6, Lorg/lighttouch/android/UsbBridge;

    .line 92
    .local v6, "$this$retireStale_u24lambda_u247\\4":Lorg/lighttouch/android/UsbBridge;
    const/4 v7, 0x0

    .line 70
    .local v7, "$i$a$-runCatching-UsbBridge$retireStale$2\\4\\70\\0":I
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v8

    sget v9, Landroid/system/OsConstants;->SIGTERM:I

    invoke-static {v8, v9}, Landroid/os/Process;->sendSignal(II)V

    .end local v6    # "$this$retireStale_u24lambda_u247\\4":Lorg/lighttouch/android/UsbBridge;
    .end local v7    # "$i$a$-runCatching-UsbBridge$retireStale$2\\4\\70\\0":I
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v6}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_5

    :catchall_0
    move-exception v6

    sget-object v7, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v6}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    :cond_5
    :goto_5
    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v4}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 66
    .end local v4    # "dir":Ljava/io/File;
    .end local v5    # "pid":Ljava/lang/Integer;
    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    .line 73
    :cond_7
    return-void
.end method

.method private static final start$lambda$1(Ljava/io/File;)Z
    .locals 5
    .param p0, "f"    # Ljava/io/File;

    .line 32
    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "getName(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v3, "usbmuxd-"

    const/4 v4, 0x0

    invoke-static {v0, v3, v4, v1, v2}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    return v0
.end method


# virtual methods
.method public final getMuxSocket()Ljava/lang/String;
    .locals 1

    .line 21
    iget-object v0, p0, Lorg/lighttouch/android/UsbBridge;->muxSocket:Ljava/lang/String;

    return-object v0
.end method

.method public final start(Ljava/lang/String;)Ljava/lang/String;
    .locals 17
    .param p1, "recordId"    # Ljava/lang/String;

    move-object/from16 v1, p0

    const-string v0, "recordId"

    move-object/from16 v2, p1

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    invoke-direct {v1}, Lorg/lighttouch/android/UsbBridge;->getDaemonBinary()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->canExecute()Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "\u6b64\u7248\u672c\u4e0d\u5305\u542b\u5ba2\u6237\u673a\u5e94\u7528\u670d\u52a1\u3002"

    return-object v0

    .line 26
    :cond_0
    invoke-direct {v1}, Lorg/lighttouch/android/UsbBridge;->retireStale()V

    .line 27
    new-instance v0, Ljava/io/File;

    invoke-direct {v1}, Lorg/lighttouch/android/UsbBridge;->getRunRoot()Ljava/io/File;

    move-result-object v3

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v3, v0

    .line 28
    .local v3, "directory":Ljava/io/File;
    iget-object v0, v1, Lorg/lighttouch/android/UsbBridge;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    move-object/from16 v4, p1

    .local v4, "$this$filter\\1":Ljava/lang/String;
    const/4 v5, 0x0

    .line 82
    .local v5, "$i$f$filter\\1\\28":I
    move-object v6, v4

    check-cast v6, Ljava/lang/CharSequence;

    .local v6, "$this$filterTo\\2":Ljava/lang/CharSequence;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    check-cast v7, Ljava/lang/Appendable;

    .local v7, "destination\\2":Ljava/lang/Appendable;
    const/4 v8, 0x0

    .line 83
    .local v8, "$i$f$filterTo\\2\\82":I
    const/4 v9, 0x0

    .local v9, "index\\2":I
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v10

    :goto_0
    if-ge v9, v10, :cond_2

    .line 84
    invoke-interface {v6, v9}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v11

    .line 85
    .local v11, "element\\2":C
    move v12, v11

    .local v12, "it\\3":C
    const/4 v13, 0x0

    .line 28
    .local v13, "$i$a$-filter-UsbBridge$start$pairing$1\\3\\85\\0":I
    invoke-static {v12}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v14

    .line 85
    .end local v12    # "it\\3":C
    .end local v13    # "$i$a$-filter-UsbBridge$start$pairing$1\\3\\85\\0":I
    if-eqz v14, :cond_1

    invoke-interface {v7, v11}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    .line 83
    .end local v11    # "element\\2":C
    :cond_1
    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    .line 87
    .end local v9    # "index\\2":I
    :cond_2
    nop

    .end local v6    # "$this$filterTo\\2":Ljava/lang/CharSequence;
    .end local v7    # "destination\\2":Ljava/lang/Appendable;
    .end local v8    # "$i$f$filterTo\\2\\82":I
    move-object v6, v7

    check-cast v6, Ljava/lang/StringBuilder;

    .line 82
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .end local v4    # "$this$filter\\1":Ljava/lang/String;
    .end local v5    # "$i$f$filter\\1\\28":I
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "usb-pairing/"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 28
    new-instance v5, Ljava/io/File;

    invoke-direct {v5, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 29
    .local v5, "pairing":Ljava/io/File;
    new-instance v0, Ljava/io/File;

    iget-object v4, v1, Lorg/lighttouch/android/UsbBridge;->context:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const-string v6, "service-logs"

    invoke-direct {v0, v4, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v4, v0

    .line 30
    .local v4, "logs":Ljava/io/File;
    const/4 v0, 0x4

    new-array v6, v0, [Ljava/io/File;

    invoke-direct {v1}, Lorg/lighttouch/android/UsbBridge;->getRunRoot()Ljava/io/File;

    move-result-object v7

    const/4 v8, 0x0

    aput-object v7, v6, v8

    const/4 v7, 0x1

    aput-object v3, v6, v7

    const/4 v9, 0x2

    aput-object v5, v6, v9

    const/4 v10, 0x3

    aput-object v4, v6, v10

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/io/File;

    .local v11, "dir":Ljava/io/File;
    invoke-virtual {v11}, Ljava/io/File;->mkdirs()Z

    invoke-virtual {v11}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v12

    const/16 v13, 0x1c0

    invoke-static {v12, v13}, Landroid/system/Os;->chmod(Ljava/lang/String;I)V

    .end local v11    # "dir":Ljava/io/File;
    goto :goto_1

    .line 32
    :cond_3
    new-instance v6, Lorg/lighttouch/android/UsbBridge$$ExternalSyntheticLambda0;

    invoke-direct {v6}, Lorg/lighttouch/android/UsbBridge$$ExternalSyntheticLambda0;-><init>()V

    invoke-virtual {v4, v6}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v6

    const/4 v11, 0x7

    if-eqz v6, :cond_5

    .local v6, "$this$sortedByDescending\\4":[Ljava/lang/Object;
    const/4 v12, 0x0

    .line 88
    .local v12, "$i$f$sortedByDescending\\4\\32":I
    new-instance v13, Lorg/lighttouch/android/UsbBridge$start$$inlined$sortedByDescending$1;

    invoke-direct {v13}, Lorg/lighttouch/android/UsbBridge$start$$inlined$sortedByDescending$1;-><init>()V

    check-cast v13, Ljava/util/Comparator;

    invoke-static {v6, v13}, Lkotlin/collections/ArraysKt;->sortedWith([Ljava/lang/Object;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v6

    .line 32
    .end local v6    # "$this$sortedByDescending\\4":[Ljava/lang/Object;
    .end local v12    # "$i$f$sortedByDescending\\4\\32":I
    if-eqz v6, :cond_5

    check-cast v6, Ljava/lang/Iterable;

    invoke-static {v6, v11}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v6

    if-eqz v6, :cond_5

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$forEach\\5":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 89
    .local v12, "$i$f$forEach\\5\\32":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_2
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_4

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element\\5":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/io/File;

    .local v15, "it\\6":Ljava/io/File;
    const/16 v16, 0x0

    .line 32
    .local v16, "$i$a$-forEach-UsbBridge$start$3\\6\\89\\0":I
    invoke-virtual {v15}, Ljava/io/File;->delete()Z

    .line 89
    .end local v15    # "it\\6":Ljava/io/File;
    .end local v16    # "$i$a$-forEach-UsbBridge$start$3\\6\\89\\0":I
    nop

    .end local v14    # "element\\5":Ljava/lang/Object;
    goto :goto_2

    .line 90
    :cond_4
    nop

    .line 33
    .end local v6    # "$this$forEach\\5":Ljava/lang/Iterable;
    .end local v12    # "$i$f$forEach\\5\\32":I
    :cond_5
    new-instance v6, Ljava/io/File;

    const-string v12, "mux.sock"

    invoke-direct {v6, v3, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .local v6, "mux":Ljava/io/File;
    new-instance v12, Ljava/io/File;

    const-string v13, "qemu.sock"

    invoke-direct {v12, v3, v13}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 34
    .local v12, "qemu":Ljava/io/File;
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    invoke-virtual {v12}, Ljava/io/File;->delete()Z

    .line 35
    new-instance v13, Ljava/lang/ProcessBuilder;

    const/16 v14, 0x8

    new-array v14, v14, [Ljava/lang/String;

    invoke-direct {v1}, Lorg/lighttouch/android/UsbBridge;->getDaemonBinary()Ljava/io/File;

    move-result-object v15

    invoke-virtual {v15}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v15

    aput-object v15, v14, v8

    const-string v8, "-f"

    aput-object v8, v14, v7

    const-string v8, "-S"

    aput-object v8, v14, v9

    invoke-virtual {v6}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v14, v10

    const-string v8, "-C"

    aput-object v8, v14, v0

    const/4 v0, 0x5

    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v14, v0

    .line 36
    const-string v0, "-P"

    const/4 v8, 0x6

    aput-object v0, v14, v8

    .line 35
    nop

    .line 36
    new-instance v0, Ljava/io/File;

    const-string v8, "daemon.pid"

    invoke-direct {v0, v3, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    aput-object v0, v14, v11

    .line 35
    invoke-direct {v13, v14}, Ljava/lang/ProcessBuilder;-><init>([Ljava/lang/String;)V

    .line 37
    invoke-virtual {v13, v7}, Ljava/lang/ProcessBuilder;->redirectErrorStream(Z)Ljava/lang/ProcessBuilder;

    move-result-object v0

    new-instance v8, Ljava/io/File;

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v9

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "usbmuxd-"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, ".log"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v4, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0, v8}, Ljava/lang/ProcessBuilder;->redirectOutput(Ljava/io/File;)Ljava/lang/ProcessBuilder;

    move-result-object v0

    .line 35
    move-object v8, v0

    .line 38
    .local v8, "builder":Ljava/lang/ProcessBuilder;
    invoke-virtual {v8}, Ljava/lang/ProcessBuilder;->environment()Ljava/util/Map;

    move-result-object v0

    .local v0, "$this$start_u24lambda_u244\\7":Ljava/util/Map;
    const/4 v9, 0x0

    .line 39
    .local v9, "$i$a$-apply-UsbBridge$start$4\\7\\38\\0":I
    const-string v10, "USBMUXD_QEMU_ADDR"

    invoke-virtual {v12}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v0, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    const-string v10, "LT_PARENT_DEATH_SIGNAL"

    const-string v11, "1"

    invoke-interface {v0, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v10

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    const-string v11, "LT_PARENT_PID"

    invoke-interface {v0, v11, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    nop

    .line 38
    .end local v0    # "$this$start_u24lambda_u244\\7":Ljava/util/Map;
    .end local v9    # "$i$a$-apply-UsbBridge$start$4\\7\\38\\0":I
    nop

    .line 42
    :try_start_0
    invoke-virtual {v8}, Ljava/lang/ProcessBuilder;->start()Ljava/lang/Process;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    .local v0, "child":Ljava/lang/Process;
    iput-object v0, v1, Lorg/lighttouch/android/UsbBridge;->process:Ljava/lang/Process;

    .line 44
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v9

    const-wide v13, 0x12a05f200L

    add-long/2addr v9, v13

    .line 45
    .local v9, "deadline":J
    :goto_3
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v13

    cmp-long v11, v13, v9

    if-gez v11, :cond_8

    .line 46
    invoke-virtual {v0}, Ljava/lang/Process;->isAlive()Z

    move-result v11

    if-nez v11, :cond_6

    invoke-virtual {v0}, Ljava/lang/Process;->exitValue()I

    move-result v7

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "Guest USB bridge exited ("

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v11, "); see service-logs."

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    return-object v7

    .line 47
    :cond_6
    invoke-direct {v1, v6}, Lorg/lighttouch/android/UsbBridge;->privateSocket(Ljava/io/File;)Z

    move-result v11

    if-eqz v11, :cond_7

    invoke-direct {v1, v12}, Lorg/lighttouch/android/UsbBridge;->privateSocket(Ljava/io/File;)Z

    move-result v11

    if-eqz v11, :cond_7

    .line 49
    const-string v11, "IT_USB_TCP"

    invoke-virtual {v12}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v13

    invoke-static {v11, v13, v7}, Landroid/system/Os;->setenv(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 50
    invoke-virtual {v6}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v7

    iput-object v7, v1, Lorg/lighttouch/android/UsbBridge;->muxSocket:Ljava/lang/String;

    .line 51
    const/4 v7, 0x0

    return-object v7

    .line 53
    :cond_7
    const-wide/16 v13, 0x19

    invoke-static {v13, v14}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_3

    .line 55
    :cond_8
    invoke-virtual {v1}, Lorg/lighttouch/android/UsbBridge;->stop()V

    .line 56
    const-string v7, "Guest USB bridge did not create its sockets within 5 seconds."

    return-object v7

    .line 42
    .end local v0    # "child":Ljava/lang/Process;
    .end local v9    # "deadline":J
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/io/IOException;
    invoke-virtual {v0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v7

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Guest USB bridge could not start: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    return-object v7
.end method

.method public final stop()V
    .locals 6

    .line 76
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/UsbBridge;->muxSocket:Ljava/lang/String;

    .line 77
    iget-object v1, p0, Lorg/lighttouch/android/UsbBridge;->process:Ljava/lang/Process;

    if-eqz v1, :cond_0

    .line 92
    .local v1, "it\\1":Ljava/lang/Process;
    const/4 v2, 0x0

    .line 77
    .local v2, "$i$a$-let-UsbBridge$stop$1\\1\\77\\0":I
    invoke-virtual {v1}, Ljava/lang/Process;->destroy()V

    const-wide/16 v3, 0x2

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v1, v3, v4, v5}, Ljava/lang/Process;->waitFor(JLjava/util/concurrent/TimeUnit;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v1}, Ljava/lang/Process;->destroyForcibly()Ljava/lang/Process;

    .line 78
    .end local v1    # "it\\1":Ljava/lang/Process;
    .end local v2    # "$i$a$-let-UsbBridge$stop$1\\1\\77\\0":I
    :cond_0
    iput-object v0, p0, Lorg/lighttouch/android/UsbBridge;->process:Ljava/lang/Process;

    .line 79
    return-void
.end method

.class final Lorg/lighttouch/android/HomeScreenKt$Dock$1;
.super Ljava/lang/Object;
.source "HomeScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/HomeScreenKt;->Dock(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function2<",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHomeScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt$Dock$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,192:1\n149#2:193\n99#3:194\n97#3,5:195\n102#3:228\n106#3:256\n79#4,6:200\n86#4,4:215\n90#4,2:225\n94#4:255\n368#5,9:206\n377#5:227\n378#5,2:253\n4034#6,6:219\n1225#7,6:229\n1225#7,6:235\n1225#7,6:241\n1225#7,6:247\n*S KotlinDebug\n*F\n+ 1 HomeScreen.kt\norg/lighttouch/android/HomeScreenKt$Dock$1\n*L\n152#1:193\n152#1:194\n152#1:195,5\n152#1:228\n152#1:256\n152#1:200,6\n152#1:215,4\n152#1:225,2\n152#1:255\n152#1:206,9\n152#1:227\n152#1:253,2\n152#1:219,6\n155#1:229,6\n156#1:235,6\n157#1:241,6\n158#1:247,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $host:Lorg/lighttouch/android/GuestHost;

.field final synthetic $onStop:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$FwDX83k3l13UVOhzZ8ZNiBYoibs(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->invoke$lambda$6$lambda$3$lambda$2(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JYnP5ou_04Tfc1yyHVEN9MEc-Qw(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->invoke$lambda$6$lambda$1$lambda$0(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->$host:Lorg/lighttouch/android/GuestHost;

    iput-object p2, p0, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->$onStop:Lkotlin/jvm/functions/Function0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$6$lambda$1$lambda$0(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 155
    invoke-static {p0}, Lorg/lighttouch/android/ShellKt;->getPaused(Lorg/lighttouch/android/GuestHost;)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-interface {p0, v0}, Lorg/lighttouch/android/GuestHost;->setPaused(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final invoke$lambda$6$lambda$3$lambda$2(Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 156
    sget-object v0, Lorg/lighttouch/android/Screen;->FULLSCREEN:Lorg/lighttouch/android/Screen;

    invoke-interface {p0, v0}, Lorg/lighttouch/android/GuestHost;->navigate(Lorg/lighttouch/android/Screen;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;

    .line 151
    move-object v0, p1

    check-cast v0, Landroidx/compose/runtime/Composer;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->invoke(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/runtime/Composer;I)V
    .locals 44
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    const-string v3, "C151@9208L1084:HomeScreen.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 256
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_f

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.Dock.<anonymous> (HomeScreen.kt:151)"

    const v6, 0x4d01cb09    # 1.3609794E8f

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 152
    :cond_2
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x8

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 193
    .local v6, "$i$f$getDp\\1\\152":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 152
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\152":I
    const/4 v6, 0x4

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 193
    .local v7, "$i$f$getDp\\2\\152":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 152
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\152":I
    invoke-static {v3, v5, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceEvenly()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v5

    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v5, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-object v6, v0, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->$host:Lorg/lighttouch/android/GuestHost;

    iget-object v9, v0, Lorg/lighttouch/android/HomeScreenKt$Dock$1;->$onStop:Lkotlin/jvm/functions/Function0;

    const/16 v7, 0x36

    .local v7, "$changed\\3":I
    move/from16 v18, v7

    .end local v7    # "$changed\\3":I
    .local v18, "$changed\\3":I
    const/16 v19, 0x0

    .line 194
    .local v19, "$i$f$Row\\3\\152":I
    const v7, 0x2952b718

    const-string v8, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v1, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 195
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 198
    .local v7, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v8, v18, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v10, v18, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v8, v10

    invoke-static {v5, v7, v1, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v18, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 199
    move/from16 v20, v10

    .local v20, "$changed\\4":I
    const/16 v21, 0x0

    .line 200
    .local v21, "$i$f$Layout\\4\\199":I
    const v10, -0x4ee9b9da

    const-string v11, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 201
    const/4 v10, 0x0

    invoke-static {v1, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v22

    .line 202
    .local v22, "compositeKeyHash\\4":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 203
    .local v11, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 205
    .local v12, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v20, 0x6

    and-int/lit16 v14, v14, 0x380

    or-int/lit8 v14, v14, 0x6

    .line 204
    nop

    .local v13, "factory\\5":Lkotlin/jvm/functions/Function0;
    move/from16 v23, v14

    .local v23, "$changed\\5":I
    const/16 v24, 0x0

    .line 206
    .local v24, "$i$f$ReusableComposeNode\\5\\204":I
    const v14, -0x2942ffcf

    const-string v15, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 207
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 208
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 209
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_4

    .line 210
    invoke-interface {v1, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 212
    :cond_4
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 214
    :goto_1
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 215
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\214\\4":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v17, v10

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v14, v8, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 216
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    invoke-static {v14, v11, v10}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 218
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    .local v10, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 219
    .local v16, "$i$f$set-impl\\7\\218":I
    move-object/from16 v25, v14

    .local v25, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 220
    .local v26, "$i$a$-with-Updater$set$1\\8\\219\\7":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_6

    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v4, v25

    goto :goto_3

    .line 221
    :cond_6
    :goto_2
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v4, v25

    .end local v25    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 222
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v14, v0, v10}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    :goto_3
    nop

    .line 219
    .end local v4    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\8\\219\\7":I
    nop

    .line 224
    nop

    .line 225
    .end local v10    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\7\\218":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v14, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 226
    nop

    .line 214
    .end local v14    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\214\\4":I
    nop

    .line 227
    shr-int/lit8 v0, v23, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object/from16 v4, p1

    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 228
    .local v25, "$i$a$-Layout-RowKt$Row$1\\9\\227\\3":I
    const v10, -0x184f2606

    const-string v14, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v4, v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v10, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v14, v18, 0x6

    and-int/lit8 v14, v14, 0x70

    or-int/lit8 v26, v14, 0x6

    .local v26, "$changed\\10":I
    check-cast v10, Landroidx/compose/foundation/layout/RowScope;

    .local v10, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object v15, v4

    .local v15, "$composer\\10":Landroidx/compose/runtime/Composer;
    move-object/from16 v28, v10

    .end local v10    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v28, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v39, 0x0

    .line 153
    .local v39, "$i$a$-Row-HomeScreenKt$Dock$1$1\\10\\228\\0":I
    const v10, 0x7f2e0565

    const-string v14, "C154@9518L32,153@9401L214,155@9674L36,155@9628L131,156@9813L16,156@9772L128,158@10078L204:HomeScreen.kt#o13vsk"

    invoke-static {v15, v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v10, 0x2

    new-array v10, v10, [Ljava/lang/String;

    const-string v14, "running"

    aput-object v14, v10, v17

    const-string v14, "paused"

    const/16 v16, 0x1

    aput-object v14, v10, v16

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v14

    invoke-interface {v10, v14}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v10

    .line 154
    .local v10, "canControl\\10":Z
    invoke-static {v6}, Lorg/lighttouch/android/ShellKt;->getPaused(Lorg/lighttouch/android/GuestHost;)Z

    move-result v14

    if-eqz v14, :cond_7

    sget-object v14, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v14}, Lorg/lighttouch/android/LtIcons;->getPlay()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v14

    goto :goto_4

    :cond_7
    sget-object v14, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v14}, Lorg/lighttouch/android/LtIcons;->getPause()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v14

    :goto_4
    invoke-static {v6}, Lorg/lighttouch/android/ShellKt;->getPaused(Lorg/lighttouch/android/GuestHost;)Z

    move-result v27

    if-eqz v27, :cond_8

    const-string v27, "\u7ee7\u7eed"

    goto :goto_5

    :cond_8
    const-string v27, "\u6682\u505c"

    :goto_5
    move/from16 v40, v0

    .end local v0    # "$changed\\9":I
    .local v40, "$changed\\9":I
    const v0, 0x4c5de2

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):HomeScreen.kt#9igjgp"

    invoke-static {v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v29

    .line 155
    nop

    .local v29, "invalid\\11":Z
    move-object/from16 v30, v15

    .local v30, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 229
    .local v31, "$i$f$cache\\11\\155":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\11":Ljava/lang/Object;
    const/16 v32, 0x0

    .line 230
    .local v32, "$i$a$-let-ComposerKt$cache$1\\12\\229\\11":I
    if-nez v29, :cond_a

    sget-object v33, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v33 .. v33}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_9

    goto :goto_6

    .line 234
    :cond_9
    move-object/from16 v33, v1

    move-object/from16 v2, v30

    goto :goto_7

    .line 231
    :cond_a
    :goto_6
    const/4 v2, 0x0

    .line 155
    .local v2, "$i$a$-cache-HomeScreenKt$Dock$1$1$1\\13\\231\\10":I
    move-object/from16 v33, v1

    .end local v1    # "it\\11":Ljava/lang/Object;
    .local v33, "it\\11":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/HomeScreenKt$Dock$1$$ExternalSyntheticLambda0;

    invoke-direct {v1, v6}, Lorg/lighttouch/android/HomeScreenKt$Dock$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 231
    .end local v2    # "$i$a$-cache-HomeScreenKt$Dock$1$1$1\\13\\231\\10":I
    nop

    .line 232
    .local v1, "value\\12":Ljava/lang/Object;
    move-object/from16 v2, v30

    .end local v30    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .local v2, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 233
    nop

    .line 230
    .end local v1    # "value\\12":Ljava/lang/Object;
    :goto_7
    nop

    .line 229
    .end local v32    # "$i$a$-let-ComposerKt$cache$1\\12\\229\\11":I
    .end local v33    # "it\\11":Ljava/lang/Object;
    nop

    .line 155
    .end local v2    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v29    # "invalid\\11":Z
    .end local v31    # "$i$f$cache\\11\\155":I
    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v2

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000    # 1.0f

    const/16 v31, 0x0

    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    .line 154
    move-object/from16 v2, v28

    .end local v28    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v2, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const-wide/16 v33, 0x0

    const-string v35, "pause_guest"

    const/high16 v37, 0x180000

    const/16 v38, 0x20

    move-object/from16 v30, v1

    move/from16 v32, v10

    move-object/from16 v28, v14

    move-object/from16 v36, v15

    move-object/from16 v29, v27

    .end local v10    # "canControl\\10":Z
    .end local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v32, "canControl\\10":Z
    .local v36, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v38}, Lorg/lighttouch/android/ShellKt;->DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 156
    move/from16 v1, v32

    .end local v32    # "canControl\\10":Z
    .end local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v1, "canControl\\10":Z
    .restart local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v10, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v10}, Lorg/lighttouch/android/LtIcons;->getFullscreen()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v10

    const v14, 0x4c5de2

    invoke-interface {v15, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v14

    .local v14, "invalid\\14":Z
    move-object/from16 v27, v15

    .local v27, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 235
    .local v28, "$i$f$cache\\14\\156":I
    move/from16 v41, v1

    .end local v1    # "canControl\\10":Z
    .local v41, "canControl\\10":Z
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\14":Ljava/lang/Object;
    const/16 v29, 0x0

    .line 236
    .local v29, "$i$a$-let-ComposerKt$cache$1\\15\\235\\14":I
    if-nez v14, :cond_c

    sget-object v30, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v31, v2

    .end local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v31, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_b

    goto :goto_8

    .line 240
    :cond_b
    move-object/from16 v30, v1

    move-object/from16 v2, v27

    goto :goto_9

    .line 236
    .end local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    :cond_c
    move-object/from16 v31, v2

    .line 237
    .end local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    :goto_8
    const/4 v2, 0x0

    .line 156
    .local v2, "$i$a$-cache-HomeScreenKt$Dock$1$1$2\\16\\237\\10":I
    move-object/from16 v30, v1

    .end local v1    # "it\\14":Ljava/lang/Object;
    .local v30, "it\\14":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/HomeScreenKt$Dock$1$$ExternalSyntheticLambda1;

    invoke-direct {v1, v6}, Lorg/lighttouch/android/HomeScreenKt$Dock$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/GuestHost;)V

    .line 237
    .end local v2    # "$i$a$-cache-HomeScreenKt$Dock$1$1$2\\16\\237\\10":I
    nop

    .line 238
    .local v1, "value\\15":Ljava/lang/Object;
    move-object/from16 v2, v27

    .end local v27    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .local v2, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 239
    nop

    .line 236
    .end local v1    # "value\\15":Ljava/lang/Object;
    :goto_9
    nop

    .line 235
    .end local v29    # "$i$a$-let-ComposerKt$cache$1\\15\\235\\14":I
    .end local v30    # "it\\14":Ljava/lang/Object;
    nop

    .line 156
    .end local v2    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v14    # "invalid\\14":Z
    .end local v28    # "$i$f$cache\\14\\156":I
    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v2

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000    # 1.0f

    move-object/from16 v28, v31

    .end local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v28, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v31, 0x0

    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    move-object/from16 v2, v28

    .end local v28    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v2, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const v37, 0x180030

    const/16 v38, 0x30

    const-string v29, "\u5168\u5c4f"

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const-string v35, "fullscreen_button"

    move-object/from16 v30, v1

    move-object/from16 v28, v10

    move-object/from16 v36, v15

    .end local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v38}, Lorg/lighttouch/android/ShellKt;->DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 157
    .end local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getCamera()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    const v14, 0x4c5de2

    invoke-interface {v15, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    .local v10, "invalid\\17":Z
    move-object v14, v15

    .local v14, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 241
    .local v27, "$i$f$cache\\17\\157":I
    move-object/from16 v34, v1

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\17":Ljava/lang/Object;
    const/16 v28, 0x0

    .line 242
    .local v28, "$i$a$-let-ComposerKt$cache$1\\18\\241\\17":I
    if-nez v10, :cond_e

    sget-object v29, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v31, v2

    .end local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-virtual/range {v29 .. v29}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_d

    goto :goto_a

    .line 246
    :cond_d
    move-object/from16 v29, v1

    goto :goto_b

    .line 242
    .end local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    :cond_e
    move-object/from16 v31, v2

    .line 243
    .end local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    :goto_a
    const/4 v2, 0x0

    .line 157
    .local v2, "$i$a$-cache-HomeScreenKt$Dock$1$1$3\\19\\243\\10":I
    move-object/from16 v29, v1

    .end local v1    # "it\\17":Ljava/lang/Object;
    .local v29, "it\\17":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/HomeScreenKt$Dock$1$1$3$1;

    invoke-direct {v1, v6}, Lorg/lighttouch/android/HomeScreenKt$Dock$1$1$3$1;-><init>(Ljava/lang/Object;)V

    check-cast v1, Lkotlin/reflect/KFunction;

    .line 243
    .end local v2    # "$i$a$-cache-HomeScreenKt$Dock$1$1$3\\19\\243\\10":I
    nop

    .line 244
    .local v1, "value\\18":Ljava/lang/Object;
    invoke-interface {v14, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 245
    nop

    .line 242
    .end local v1    # "value\\18":Ljava/lang/Object;
    :goto_b
    nop

    .line 241
    .end local v28    # "$i$a$-let-ComposerKt$cache$1\\18\\241\\17":I
    .end local v29    # "it\\17":Ljava/lang/Object;
    nop

    .line 157
    .end local v10    # "invalid\\17":Z
    .end local v14    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$f$cache\\17\\157":I
    check-cast v1, Lkotlin/reflect/KFunction;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    check-cast v1, Lkotlin/jvm/functions/Function0;

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v2

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000    # 1.0f

    move-object/from16 v28, v31

    .end local v31    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v28, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const/16 v31, 0x0

    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    move-object/from16 v2, v28

    .end local v28    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v2, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const v37, 0x180030

    const/16 v38, 0x20

    const-string v29, "\u622a\u5c4f"

    move-object/from16 v28, v34

    const-wide/16 v33, 0x0

    const-string v35, "screenshot_button"

    move-object/from16 v30, v1

    move-object/from16 v36, v15

    move/from16 v32, v41

    .end local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v41    # "canControl\\10":Z
    .restart local v32    # "canControl\\10":Z
    .restart local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v38}, Lorg/lighttouch/android/ShellKt;->DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    move/from16 v1, v32

    .end local v32    # "canControl\\10":Z
    .end local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v1, "canControl\\10":Z
    .restart local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    const v10, 0x462b0c3d

    invoke-interface {v15, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "157@9984L15,157@9944L121"

    invoke-static {v15, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 158
    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v10

    invoke-virtual {v10}, Lorg/lighttouch/android/AppSettings;->getHitchButton()Z

    move-result v10

    if-eqz v10, :cond_11

    sget-object v10, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v10}, Lorg/lighttouch/android/LtIcons;->getTimeline()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v10

    const v14, 0x4c5de2

    invoke-interface {v15, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\20":Z
    move-object v14, v15

    .local v14, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 247
    .local v27, "$i$f$cache\\20\\158":I
    move/from16 v28, v0

    .end local v0    # "invalid\\20":Z
    .local v28, "invalid\\20":Z
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\20":Ljava/lang/Object;
    const/16 v29, 0x0

    .line 248
    .local v29, "$i$a$-let-ComposerKt$cache$1\\21\\247\\20":I
    if-nez v28, :cond_10

    sget-object v30, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v41, v1

    .end local v1    # "canControl\\10":Z
    .restart local v41    # "canControl\\10":Z
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_f

    goto :goto_c

    .line 252
    :cond_f
    move-object/from16 v30, v0

    goto :goto_d

    .line 248
    .end local v41    # "canControl\\10":Z
    .restart local v1    # "canControl\\10":Z
    :cond_10
    move/from16 v41, v1

    .line 249
    .end local v1    # "canControl\\10":Z
    .restart local v41    # "canControl\\10":Z
    :goto_c
    const/4 v1, 0x0

    .line 158
    .local v1, "$i$a$-cache-HomeScreenKt$Dock$1$1$4\\22\\249\\10":I
    move-object/from16 v30, v0

    .end local v0    # "it\\20":Ljava/lang/Object;
    .local v30, "it\\20":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/HomeScreenKt$Dock$1$1$4$1;

    invoke-direct {v0, v6}, Lorg/lighttouch/android/HomeScreenKt$Dock$1$1$4$1;-><init>(Ljava/lang/Object;)V

    check-cast v0, Lkotlin/reflect/KFunction;

    .line 249
    .end local v1    # "$i$a$-cache-HomeScreenKt$Dock$1$1$4\\22\\249\\10":I
    nop

    .line 250
    .local v0, "value\\21":Ljava/lang/Object;
    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 251
    nop

    .line 248
    .end local v0    # "value\\21":Ljava/lang/Object;
    :goto_d
    nop

    .line 247
    .end local v29    # "$i$a$-let-ComposerKt$cache$1\\21\\247\\20":I
    .end local v30    # "it\\20":Ljava/lang/Object;
    nop

    .line 158
    .end local v14    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$f$cache\\20\\158":I
    .end local v28    # "invalid\\20":Z
    check-cast v0, Lkotlin/reflect/KFunction;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    check-cast v0, Lkotlin/jvm/functions/Function0;

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v1

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000    # 1.0f

    const/16 v31, 0x0

    move-object/from16 v28, v2

    .end local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v28, "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v31

    .end local v28    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    const v37, 0x180030

    const/16 v38, 0x20

    const-string v29, "\u68c0\u67e5"

    const-wide/16 v33, 0x0

    const-string v35, "hitch_button"

    move-object/from16 v30, v0

    move-object/from16 v28, v10

    move-object/from16 v36, v15

    move/from16 v32, v41

    .end local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v41    # "canControl\\10":Z
    .restart local v32    # "canControl\\10":Z
    .restart local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v38}, Lorg/lighttouch/android/ShellKt;->DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    move/from16 v1, v32

    .end local v32    # "canControl\\10":Z
    .end local v36    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v1, "canControl\\10":Z
    .restart local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_11
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 159
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getStop()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    sget-object v10, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v29, v10

    check-cast v29, Landroidx/compose/ui/Modifier;

    const/16 v32, 0x2

    const/16 v33, 0x0

    const/high16 v30, 0x3f800000    # 1.0f

    const/16 v31, 0x0

    move-object/from16 v28, v2

    .end local v2    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .restart local v28    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v28 .. v33}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 160
    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getSessionOwned()Z

    move-result v2

    if-eqz v2, :cond_12

    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v2

    const-string v14, "stopping"

    invoke-static {v2, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_12

    invoke-interface {v6}, Lorg/lighttouch/android/GuestHost;->getStoreInstalling()Z

    move-result v2

    if-nez v2, :cond_12

    goto :goto_e

    :cond_12
    move/from16 v16, v17

    :goto_e
    sget-object v2, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v29

    .line 159
    move-object v2, v8

    .end local v8    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v2, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    const-string v8, "\u505c\u6b62"

    const-string v14, "stop_guest"

    move-object v6, v11

    move/from16 v11, v16

    .end local v11    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v6, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    const v16, 0x1b0030

    const/16 v17, 0x0

    move-object/from16 v27, v7

    move-object v7, v0

    move-object/from16 v0, v27

    move-object/from16 v27, v12

    move-wide/from16 v42, v29

    move-object/from16 v29, v13

    move-wide/from16 v12, v42

    .end local v7    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v12    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v13    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v0, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v27, "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v29, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v7 .. v17}, Lorg/lighttouch/android/ShellKt;->DockButton-cd68TDI(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZJLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 153
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 161
    .end local v1    # "canControl\\10":Z
    nop

    .line 228
    .end local v15    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v26    # "$changed\\10":I
    .end local v28    # "$this$invoke_u24lambda_u246\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v39    # "$i$a$-Row-HomeScreenKt$Dock$1$1\\10\\228\\0":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 227
    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-Layout-RowKt$Row$1\\9\\227\\3":I
    .end local v40    # "$changed\\9":I
    nop

    .line 253
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 206
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 254
    nop

    .line 200
    .end local v23    # "$changed\\5":I
    .end local v24    # "$i$f$ReusableComposeNode\\5\\204":I
    .end local v29    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 255
    nop

    .line 194
    .end local v6    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v20    # "$changed\\4":I
    .end local v21    # "$i$f$Layout\\4\\199":I
    .end local v22    # "compositeKeyHash\\4":I
    .end local v27    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static/range {p1 .. p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 256
    nop

    .end local v0    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v2    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v3    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v5    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v18    # "$changed\\3":I
    .end local v19    # "$i$f$Row\\3\\152":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 162
    :cond_13
    :goto_f
    return-void
.end method

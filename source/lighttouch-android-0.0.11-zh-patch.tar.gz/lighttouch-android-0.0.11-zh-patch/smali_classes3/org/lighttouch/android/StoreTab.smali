.class public final enum Lorg/lighttouch/android/StoreTab;
.super Ljava/lang/Enum;
.source "StoreBrowse.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lorg/lighttouch/android/StoreTab;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u000b\u0008\u0080\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0011\u0008\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007j\u0002\u0008\u0008j\u0002\u0008\tj\u0002\u0008\nj\u0002\u0008\u000bj\u0002\u0008\u000cj\u0002\u0008\r\u00a8\u0006\u000e"
    }
    d2 = {
        "Lorg/lighttouch/android/StoreTab;",
        "",
        "title",
        "",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;)V",
        "getTitle",
        "()Ljava/lang/String;",
        "DEVICE",
        "INSTALLED",
        "FEATURED",
        "CHARTS",
        "CATEGORIES",
        "COLLECTIONS",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lorg/lighttouch/android/StoreTab;

.field public static final enum CATEGORIES:Lorg/lighttouch/android/StoreTab;

.field public static final enum CHARTS:Lorg/lighttouch/android/StoreTab;

.field public static final enum COLLECTIONS:Lorg/lighttouch/android/StoreTab;

.field public static final enum DEVICE:Lorg/lighttouch/android/StoreTab;

.field public static final enum FEATURED:Lorg/lighttouch/android/StoreTab;

.field public static final enum INSTALLED:Lorg/lighttouch/android/StoreTab;


# instance fields
.field private final title:Ljava/lang/String;


# direct methods
.method private static final synthetic $values()[Lorg/lighttouch/android/StoreTab;
    .locals 6

    sget-object v0, Lorg/lighttouch/android/StoreTab;->DEVICE:Lorg/lighttouch/android/StoreTab;

    sget-object v1, Lorg/lighttouch/android/StoreTab;->INSTALLED:Lorg/lighttouch/android/StoreTab;

    sget-object v2, Lorg/lighttouch/android/StoreTab;->FEATURED:Lorg/lighttouch/android/StoreTab;

    sget-object v3, Lorg/lighttouch/android/StoreTab;->CHARTS:Lorg/lighttouch/android/StoreTab;

    sget-object v4, Lorg/lighttouch/android/StoreTab;->CATEGORIES:Lorg/lighttouch/android/StoreTab;

    sget-object v5, Lorg/lighttouch/android/StoreTab;->COLLECTIONS:Lorg/lighttouch/android/StoreTab;

    filled-new-array/range {v0 .. v5}, [Lorg/lighttouch/android/StoreTab;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 4

    .line 34
    new-instance v0, Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x0

    const-string v2, "\u6b64\u8bbe\u5907"

    const-string v3, "DEVICE"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/StoreTab;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/StoreTab;->DEVICE:Lorg/lighttouch/android/StoreTab;

    new-instance v0, Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x1

    const-string v2, "\u5df2\u5b89\u88c5"

    const-string v3, "INSTALLED"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/StoreTab;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/StoreTab;->INSTALLED:Lorg/lighttouch/android/StoreTab;

    new-instance v0, Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x2

    const-string v2, "\u7cbe\u9009"

    const-string v3, "FEATURED"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/StoreTab;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/StoreTab;->FEATURED:Lorg/lighttouch/android/StoreTab;

    new-instance v0, Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x3

    const-string v2, "\u6392\u884c\u699c"

    const-string v3, "CHARTS"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/StoreTab;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/StoreTab;->CHARTS:Lorg/lighttouch/android/StoreTab;

    new-instance v0, Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x4

    const-string v2, "\u5206\u7c7b"

    const-string v3, "CATEGORIES"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/StoreTab;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/StoreTab;->CATEGORIES:Lorg/lighttouch/android/StoreTab;

    new-instance v0, Lorg/lighttouch/android/StoreTab;

    const/4 v1, 0x5

    const-string v2, "\u5408\u96c6"

    const-string v3, "COLLECTIONS"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/StoreTab;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/StoreTab;->COLLECTIONS:Lorg/lighttouch/android/StoreTab;

    invoke-static {}, Lorg/lighttouch/android/StoreTab;->$values()[Lorg/lighttouch/android/StoreTab;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/StoreTab;->$VALUES:[Lorg/lighttouch/android/StoreTab;

    sget-object v0, Lorg/lighttouch/android/StoreTab;->$VALUES:[Lorg/lighttouch/android/StoreTab;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/StoreTab;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .param p3, "title"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 33
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lorg/lighttouch/android/StoreTab;->title:Ljava/lang/String;

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lorg/lighttouch/android/StoreTab;",
            ">;"
        }
    .end annotation

    sget-object v0, Lorg/lighttouch/android/StoreTab;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 35
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lorg/lighttouch/android/StoreTab;
    .locals 1
    .param p0, "value"    # Ljava/lang/String;

    const-class v0, Lorg/lighttouch/android/StoreTab;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    .line 35
    check-cast v0, Lorg/lighttouch/android/StoreTab;

    return-object v0
.end method

.method public static values()[Lorg/lighttouch/android/StoreTab;
    .locals 1

    sget-object v0, Lorg/lighttouch/android/StoreTab;->$VALUES:[Lorg/lighttouch/android/StoreTab;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    .line 35
    check-cast v0, [Lorg/lighttouch/android/StoreTab;

    return-object v0
.end method


# virtual methods
.method public final getTitle()Ljava/lang/String;
    .locals 1

    .line 33
    iget-object v0, p0, Lorg/lighttouch/android/StoreTab;->title:Ljava/lang/String;

    return-object v0
.end method

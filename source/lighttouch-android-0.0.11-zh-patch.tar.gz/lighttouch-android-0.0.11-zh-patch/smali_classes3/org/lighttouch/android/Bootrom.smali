.class public final enum Lorg/lighttouch/android/Bootrom;
.super Ljava/lang/Enum;
.source "FirmwareCatalog.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/Bootrom$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lorg/lighttouch/android/Bootrom;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFirmwareCatalog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FirmwareCatalog.kt\norg/lighttouch/android/Bootrom\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,239:1\n1563#2:240\n1634#2,3:241\n1#3:244\n*S KotlinDebug\n*F\n+ 1 FirmwareCatalog.kt\norg/lighttouch/android/Bootrom\n*L\n93#1:240\n93#1:241,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0008\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0080\u0081\u0002\u0018\u0000 \u00182\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0018B\'\u0008\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u000c\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0006\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013J\u000e\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0017R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\nR\u0014\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00030\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u000e\u001a\u00020\u00038F\u00a2\u0006\u0006\u001a\u0004\u0008\u000f\u0010\nj\u0002\u0008\u000cj\u0002\u0008\r\u00a8\u0006\u0019"
    }
    d2 = {
        "Lorg/lighttouch/android/Bootrom;",
        "",
        "label",
        "",
        "sha256",
        "links",
        "",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/List;)V",
        "getLabel",
        "()Ljava/lang/String;",
        "getSha256",
        "S5L8720",
        "S5L8900",
        "sources",
        "getSources",
        "matches",
        "",
        "bytes",
        "",
        "fetch",
        "",
        "target",
        "Ljava/io/File;",
        "Companion",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lorg/lighttouch/android/Bootrom;

.field public static final Companion:Lorg/lighttouch/android/Bootrom$Companion;

.field public static final enum S5L8720:Lorg/lighttouch/android/Bootrom;

.field public static final enum S5L8900:Lorg/lighttouch/android/Bootrom;


# instance fields
.field private final label:Ljava/lang/String;

.field private final links:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final sha256:Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$BPmXeerQ3D6jRViaGiF-eITdRTE(B)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/Bootrom;->matches$lambda$1(B)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method private static final synthetic $values()[Lorg/lighttouch/android/Bootrom;
    .locals 2

    sget-object v0, Lorg/lighttouch/android/Bootrom;->S5L8720:Lorg/lighttouch/android/Bootrom;

    sget-object v1, Lorg/lighttouch/android/Bootrom;->S5L8900:Lorg/lighttouch/android/Bootrom;

    filled-new-array {v0, v1}, [Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 7

    .line 85
    new-instance v0, Lorg/lighttouch/android/Bootrom;

    .line 86
    const/4 v1, 0x3

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "https://securerom.fun/resources/APROM/SecureROM%20for%20s5l8720xsi%2C%20iBoot-240.4"

    aput-object v3, v1, v2

    .line 87
    const-string v2, "https://github.com/hekapooios/hekapooios.github.io/raw/master/resources/APROM/SecureROM%20for%20s5l8720xsi%2C%20iBoot-240.4"

    const/4 v3, 0x1

    aput-object v2, v1, v3

    .line 86
    nop

    .line 88
    const-string v2, "https://github.com/devos50/qemu-ios/releases/download/n72ap_v1/bootrom_240_4"

    const/4 v3, 0x2

    aput-object v2, v1, v3

    .line 86
    nop

    .line 85
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v1, "S5L8720"

    const/4 v2, 0x0

    const-string v3, "iBoot-240.4"

    const-string v4, "55f4d8ea2791ba51dd89934168f38f0fb21ce8762ff614c1e742407c0d3ca054"

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/Bootrom;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    sput-object v0, Lorg/lighttouch/android/Bootrom;->S5L8720:Lorg/lighttouch/android/Bootrom;

    .line 89
    new-instance v1, Lorg/lighttouch/android/Bootrom;

    .line 90
    nop

    .line 89
    const-string v0, "https://github.com/devos50/qemu-ios/releases/download/n45ap_v1/bootrom_s5l8900"

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    const-string v2, "S5L8900"

    const/4 v3, 0x1

    const-string v4, "S5L8900"

    const-string v5, "220027d6f8ea24603f8c5ad5e920ab553d85a9cd809d79c7e6f6f0eefdc2bc95"

    invoke-direct/range {v1 .. v6}, Lorg/lighttouch/android/Bootrom;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    sput-object v1, Lorg/lighttouch/android/Bootrom;->S5L8900:Lorg/lighttouch/android/Bootrom;

    invoke-static {}, Lorg/lighttouch/android/Bootrom;->$values()[Lorg/lighttouch/android/Bootrom;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/Bootrom;->$VALUES:[Lorg/lighttouch/android/Bootrom;

    sget-object v0, Lorg/lighttouch/android/Bootrom;->$VALUES:[Lorg/lighttouch/android/Bootrom;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/Bootrom;->$ENTRIES:Lkotlin/enums/EnumEntries;

    new-instance v0, Lorg/lighttouch/android/Bootrom$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lorg/lighttouch/android/Bootrom$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lorg/lighttouch/android/Bootrom;->Companion:Lorg/lighttouch/android/Bootrom$Companion;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .param p3, "label"    # Ljava/lang/String;
    .param p4, "sha256"    # Ljava/lang/String;
    .param p5, "links"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 84
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lorg/lighttouch/android/Bootrom;->label:Ljava/lang/String;

    iput-object p4, p0, Lorg/lighttouch/android/Bootrom;->sha256:Ljava/lang/String;

    iput-object p5, p0, Lorg/lighttouch/android/Bootrom;->links:Ljava/util/List;

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lorg/lighttouch/android/Bootrom;",
            ">;"
        }
    .end annotation

    sget-object v0, Lorg/lighttouch/android/Bootrom;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 124
    return-object v0
.end method

.method private static final matches$lambda$1(B)Ljava/lang/CharSequence;
    .locals 2
    .param p0, "it"    # B

    .line 94
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02x"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lorg/lighttouch/android/Bootrom;
    .locals 1
    .param p0, "value"    # Ljava/lang/String;

    const-class v0, Lorg/lighttouch/android/Bootrom;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    .line 124
    check-cast v0, Lorg/lighttouch/android/Bootrom;

    return-object v0
.end method

.method public static values()[Lorg/lighttouch/android/Bootrom;
    .locals 1

    sget-object v0, Lorg/lighttouch/android/Bootrom;->$VALUES:[Lorg/lighttouch/android/Bootrom;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    .line 124
    check-cast v0, [Lorg/lighttouch/android/Bootrom;

    return-object v0
.end method


# virtual methods
.method public final fetch(Ljava/io/File;)V
    .locals 8
    .param p1, "target"    # Ljava/io/File;

    const-string v0, "target"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    const-string v0, ""

    .line 99
    .local v0, "failure":Ljava/lang/String;
    iget-object v1, p0, Lorg/lighttouch/android/Bootrom;->links:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 100
    .local v2, "link":Ljava/lang/String;
    nop

    .line 101
    :try_start_0
    new-instance v3, Ljava/net/URL;

    invoke-direct {v3, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    const-string v4, "null cannot be cast to non-null type java.net.HttpURLConnection"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Ljava/net/HttpURLConnection;

    .line 102
    .local v3, "connection":Ljava/net/HttpURLConnection;
    const/16 v4, 0x3a98

    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    const/16 v4, 0x7530

    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 103
    nop

    .line 104
    :try_start_1
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    const/16 v5, 0xc8

    if-ne v4, v5, :cond_0

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    const/4 v4, 0x0

    :goto_1
    if-eqz v4, :cond_3

    .line 105
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    check-cast v4, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v5, v4

    check-cast v5, Ljava/io/InputStream;

    .line 244
    .local v5, "it\\2":Ljava/io/InputStream;
    const/4 v6, 0x0

    .line 105
    .local v6, "$i$a$-use-Bootrom$fetch$bytes$2\\2\\105\\0":I
    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v5}, Lkotlin/io/ByteStreamsKt;->readBytes(Ljava/io/InputStream;)[B

    move-result-object v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v5    # "it\\2":Ljava/io/InputStream;
    .end local v6    # "$i$a$-use-Bootrom$fetch$bytes$2\\2\\105\\0":I
    const/4 v5, 0x0

    :try_start_3
    invoke-static {v4, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 106
    :try_start_4
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 103
    nop

    .line 107
    .local v7, "bytes":[B
    invoke-virtual {p0, v7}, Lorg/lighttouch/android/Bootrom;->matches([B)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 108
    new-instance v4, Ljava/io/File;

    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".partial"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .local v4, "partial":Ljava/io/File;
    invoke-static {v4, v7}, Lkotlin/io/FilesKt;->writeBytes(Ljava/io/File;[B)V

    .line 109
    invoke-virtual {v4, p1}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 110
    return-void

    .line 244
    :cond_1
    const/4 v5, 0x0

    .line 109
    .local v5, "$i$a$-check-Bootrom$fetch$2\\4\\109\\0":I
    const-string v6, "\u65e0\u6cd5\u4fdd\u5b58"

    .end local v5    # "$i$a$-check-Bootrom$fetch$2\\4\\109\\0":I
    new-instance v5, Ljava/lang/IllegalStateException;

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "failure":Ljava/lang/String;
    .end local v2    # "link":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .end local p1    # "target":Ljava/io/File;
    throw v5

    .line 244
    .end local v4    # "partial":Ljava/io/File;
    .restart local v0    # "failure":Ljava/lang/String;
    .restart local v2    # "link":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .restart local p1    # "target":Ljava/io/File;
    :cond_2
    const/4 v4, 0x0

    .line 107
    .local v4, "$i$a$-check-Bootrom$fetch$1\\3\\107\\0":I
    const-string v5, "\u6587\u4ef6\u4e0d\u5339\u914d"

    .end local v4    # "$i$a$-check-Bootrom$fetch$1\\3\\107\\0":I
    new-instance v4, Ljava/lang/IllegalStateException;

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "failure":Ljava/lang/String;
    .end local v2    # "link":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .end local p1    # "target":Ljava/io/File;
    throw v4
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 105
    .end local v7    # "bytes":[B
    .restart local v0    # "failure":Ljava/lang/String;
    .restart local v2    # "link":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .restart local p1    # "target":Ljava/io/File;
    :catchall_0
    move-exception v5

    .end local v0    # "failure":Ljava/lang/String;
    .end local v2    # "link":Ljava/lang/String;
    .end local v3    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .end local p1    # "target":Ljava/io/File;
    :try_start_5
    throw v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v0    # "failure":Ljava/lang/String;
    .restart local v2    # "link":Ljava/lang/String;
    .restart local v3    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .restart local p1    # "target":Ljava/io/File;
    :catchall_1
    move-exception v6

    :try_start_6
    invoke-static {v4, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "failure":Ljava/lang/String;
    .end local v2    # "link":Ljava/lang/String;
    .end local v3    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .end local p1    # "target":Ljava/io/File;
    throw v6

    .line 244
    .restart local v0    # "failure":Ljava/lang/String;
    .restart local v2    # "link":Ljava/lang/String;
    .restart local v3    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .restart local p1    # "target":Ljava/io/File;
    :cond_3
    const/4 v4, 0x0

    .line 104
    .local v4, "$i$a$-check-Bootrom$fetch$bytes$1\\1\\104\\0":I
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "HTTP "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .end local v4    # "$i$a$-check-Bootrom$fetch$bytes$1\\1\\104\\0":I
    new-instance v4, Ljava/lang/IllegalStateException;

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "failure":Ljava/lang/String;
    .end local v2    # "link":Ljava/lang/String;
    .end local v3    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .end local p1    # "target":Ljava/io/File;
    throw v4
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 106
    .restart local v0    # "failure":Ljava/lang/String;
    .restart local v2    # "link":Ljava/lang/String;
    .restart local v3    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .restart local p1    # "target":Ljava/io/File;
    :catchall_2
    move-exception v4

    :try_start_7
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .end local v0    # "failure":Ljava/lang/String;
    .end local v2    # "link":Ljava/lang/String;
    .end local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .end local p1    # "target":Ljava/io/File;
    throw v4
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    .line 111
    .end local v3    # "connection":Ljava/net/HttpURLConnection;
    .restart local v0    # "failure":Ljava/lang/String;
    .restart local v2    # "link":Ljava/lang/String;
    .restart local p0    # "this":Lorg/lighttouch/android/Bootrom;
    .restart local p1    # "target":Ljava/io/File;
    :catch_0
    move-exception v3

    .local v3, "e":Ljava/lang/Exception;
    new-instance v4, Ljava/net/URL;

    invoke-direct {v4, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, ": "

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v2    # "link":Ljava/lang/String;
    .end local v3    # "e":Ljava/lang/Exception;
    goto/16 :goto_0

    .line 113
    :cond_4
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 1

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/Bootrom;->label:Ljava/lang/String;

    return-object v0
.end method

.method public final getSha256()Ljava/lang/String;
    .locals 1

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/Bootrom;->sha256:Ljava/lang/String;

    return-object v0
.end method

.method public final getSources()Ljava/lang/String;
    .locals 10

    .line 93
    iget-object v0, p0, Lorg/lighttouch/android/Bootrom;->links:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 240
    .local v1, "$i$f$map\\1\\93":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\2":Ljava/util/Collection;
    move-object v3, v0

    .local v3, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 241
    .local v4, "$i$f$mapTo\\2\\240":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .line 242
    .local v6, "item\\2":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Ljava/lang/String;

    .local v7, "it\\3":Ljava/lang/String;
    const/4 v8, 0x0

    .line 93
    .local v8, "$i$a$-map-Bootrom$sources$1\\3\\242\\0":I
    new-instance v9, Ljava/net/URL;

    invoke-direct {v9, v7}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v7

    .line 242
    .end local v7    # "it\\3":Ljava/lang/String;
    .end local v8    # "$i$a$-map-Bootrom$sources$1\\3\\242\\0":I
    invoke-interface {v2, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 243
    .end local v6    # "item\\2":Ljava/lang/Object;
    :cond_0
    nop

    .end local v2    # "destination\\2":Ljava/util/Collection;
    .end local v3    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapTo\\2\\240":I
    check-cast v2, Ljava/util/List;

    .line 240
    nop

    .end local v0    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map\\1\\93":I
    check-cast v2, Ljava/lang/Iterable;

    .line 93
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    const-string v0, " or "

    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    const/16 v8, 0x3e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final matches([B)Z
    .locals 10
    .param p1, "bytes"    # [B

    const-string v0, "bytes"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v1

    const-string v0, "digest(...)"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, ""

    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v7, Lorg/lighttouch/android/Bootrom$$ExternalSyntheticLambda0;

    invoke-direct {v7}, Lorg/lighttouch/android/Bootrom$$ExternalSyntheticLambda0;-><init>()V

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lorg/lighttouch/android/Bootrom;->sha256:Ljava/lang/String;

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.class public final Lorg/lighttouch/android/IpaPreflight;
.super Ljava/lang/Object;
.source "IpaPreflight.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/IpaPreflight$Entry;,
        Lorg/lighttouch/android/IpaPreflight$Zip;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nIpaPreflight.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IpaPreflight.kt\norg/lighttouch/android/IpaPreflight\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,285:1\n295#2,2:286\n1617#2,9:288\n1869#2:297\n1870#2:299\n1626#2:300\n774#2:302\n865#2,2:303\n295#2,2:305\n774#2:307\n865#2,2:308\n774#2:310\n865#2,2:311\n1617#2,9:313\n1869#2:322\n1870#2:324\n1626#2:325\n1869#2,2:326\n2746#2,3:328\n1563#2:331\n1634#2,3:332\n1193#2,2:335\n1267#2,4:337\n1#3:298\n1#3:301\n1#3:323\n1#3:341\n*S KotlinDebug\n*F\n+ 1 IpaPreflight.kt\norg/lighttouch/android/IpaPreflight\n*L\n62#1:286,2\n188#1:288,9\n188#1:297\n188#1:299\n188#1:300\n243#1:302\n243#1:303,2\n250#1:305,2\n254#1:307\n254#1:308,2\n259#1:310\n259#1:311,2\n259#1:313,9\n259#1:322\n259#1:324\n259#1:325\n259#1:326,2\n268#1:328,3\n144#1:331\n144#1:332,3\n145#1:335,2\n145#1:337,4\n188#1:298\n259#1:323\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0012\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u0002\u001d\u001eB\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0010\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\nH\u0002J\u001e\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\r\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u000c2\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J*\u0010\u0012\u001a\u001c\u0012\u0018\u0012\u0016\u0012\u0004\u0012\u00020\u0015\u0012\u000c\u0012\n\u0012\u0004\u0012\u00020\u0015\u0018\u00010\u00130\u00140\u00132\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J$\u0010\u0016\u001a\u0016\u0012\u0004\u0012\u00020\u0015\u0012\u000c\u0012\n\u0012\u0004\u0012\u00020\u0015\u0018\u00010\u00130\u00142\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J\u001e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\n2\u0006\u0010\u001a\u001a\u00020\n2\u0006\u0010\u001b\u001a\u00020\u001cR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"
    }
    d2 = {
        "Lorg/lighttouch/android/IpaPreflight;",
        "",
        "<init>",
        "()V",
        "MAX_IPA",
        "",
        "MAX_UNPACKED",
        "openZip",
        "Lorg/lighttouch/android/IpaPreflight$Zip;",
        "path",
        "Ljava/io/File;",
        "plist",
        "",
        "",
        "data",
        "",
        "binaryPlist",
        "xmlPlist",
        "armSlices",
        "",
        "Lkotlin/Pair;",
        "",
        "armSlice",
        "prepare",
        "Lorg/lighttouch/android/IpaInfo;",
        "source",
        "destination",
        "target",
        "Lorg/lighttouch/android/StoreTarget;",
        "Entry",
        "Zip",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I = 0x0

.field public static final INSTANCE:Lorg/lighttouch/android/IpaPreflight;

.field private static final MAX_IPA:J = 0x80000000L

.field private static final MAX_UNPACKED:J = 0x200000000L


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lorg/lighttouch/android/IpaPreflight;

    invoke-direct {v0}, Lorg/lighttouch/android/IpaPreflight;-><init>()V

    sput-object v0, Lorg/lighttouch/android/IpaPreflight;->INSTANCE:Lorg/lighttouch/android/IpaPreflight;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final armSlice([B)Lkotlin/Pair;
    .locals 23
    .param p1, "data"    # [B
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;>;"
        }
    .end annotation

    .line 198
    move-object/from16 v0, p1

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v1

    sget-object v2, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v1, v2}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v1

    .line 199
    .local v1, "b":Ljava/nio/ByteBuffer;
    array-length v2, v0

    const/16 v3, 0x1c

    if-lt v2, v3, :cond_c

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v3

    const v4, -0x1120532

    if-ne v3, v4, :cond_c

    .line 200
    const/4 v3, 0x4

    invoke-virtual {v1, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v3

    .local v3, "cpu":I
    const/16 v4, 0x8

    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v5

    const v6, 0xffffff

    and-int/2addr v5, v6

    .local v5, "subtype":I
    const/16 v6, 0xc

    invoke-virtual {v1, v6}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v7

    .line 201
    .local v7, "fileType":I
    const/16 v8, 0x10

    invoke-virtual {v1, v8}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v9

    .local v9, "commands":I
    const/16 v10, 0x14

    invoke-virtual {v1, v10}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v11

    .line 202
    .local v11, "size":I
    if-ne v3, v6, :cond_a

    const/4 v6, 0x2

    if-ne v7, v6, :cond_a

    if-ltz v9, :cond_0

    const v13, 0x10001

    if-ge v9, v13, :cond_0

    const/4 v13, 0x1

    goto :goto_0

    :cond_0
    move v13, v2

    :goto_0
    if-eqz v13, :cond_a

    const-wide/16 v13, 0x1c

    move v15, v2

    move/from16 v16, v3

    .end local v3    # "cpu":I
    .local v16, "cpu":I
    int-to-long v2, v11

    add-long/2addr v2, v13

    array-length v13, v0

    int-to-long v13, v13

    cmp-long v2, v2, v13

    if-gtz v2, :cond_b

    .line 203
    const/4 v2, 0x0

    .local v2, "cursor":I
    const/16 v2, 0x1c

    const/4 v3, 0x0

    .line 204
    .local v3, "minimum":Ljava/lang/Object;
    move v13, v15

    :goto_1
    if-ge v13, v9, :cond_9

    move v14, v13

    .local v14, "it\\1":I
    const/16 v17, 0x0

    .line 205
    .local v17, "$i$a$-repeat-IpaPreflight$armSlice$1\\1\\204\\0":I
    move/from16 v18, v8

    add-int/lit8 v8, v2, 0x8

    const/16 v19, 0x1

    add-int/lit8 v12, v11, 0x1c

    move/from16 v20, v15

    const-string v15, "\u53ef\u6267\u884c\u6587\u4ef6\u52a0\u8f7d\u547d\u4ee4\u65e0\u6548\u3002"

    if-gt v8, v12, :cond_8

    .line 206
    invoke-virtual {v1, v2}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v8

    .local v8, "command\\1":I
    add-int/lit8 v12, v2, 0x4

    invoke-virtual {v1, v12}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v12

    .line 207
    .local v12, "length\\1":I
    if-lt v12, v4, :cond_7

    move/from16 v21, v4

    add-int v4, v2, v12

    add-int/lit8 v6, v11, 0x1c

    if-gt v4, v6, :cond_7

    .line 208
    const/16 v4, 0x21

    if-ne v8, v4, :cond_2

    if-lt v12, v10, :cond_1

    add-int/lit8 v4, v2, 0x10

    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    if-nez v4, :cond_1

    goto :goto_2

    :cond_1
    new-instance v4, Lorg/lighttouch/android/IpaError;

    const-string v6, "\u6b64\u5e94\u7528\u5df2\u52a0\u5bc6\uff0c\u8bf7\u9009\u62e9\u5df2\u89e3\u5bc6\u7684 IPA\u3002"

    invoke-direct {v4, v6}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 209
    :cond_2
    :goto_2
    sparse-switch v8, :sswitch_data_0

    const/4 v4, 0x0

    goto :goto_4

    :sswitch_0
    add-int/lit8 v4, v2, 0x8

    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    const/4 v6, 0x2

    if-ne v4, v6, :cond_3

    add-int/lit8 v4, v2, 0xc

    goto :goto_3

    :cond_3
    new-instance v4, Lorg/lighttouch/android/IpaError;

    const-string v6, "\u5e94\u7528\u53ef\u6267\u884c\u6587\u4ef6\u9762\u5411\u4e0d\u53d7\u652f\u6301\u7684\u5e73\u53f0\u3002"

    invoke-direct {v4, v6}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v4

    :sswitch_1
    add-int/lit8 v4, v2, 0x8

    :goto_3
    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    .line 210
    .local v4, "packed\\1":Ljava/lang/Integer;
    :goto_4
    if-eqz v4, :cond_5

    .line 211
    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v15

    ushr-int/lit8 v15, v15, 0x10

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v6, v20

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v15

    ushr-int/lit8 v15, v15, 0x8

    and-int/lit16 v15, v15, 0xff

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    aput-object v15, v6, v19

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v15

    and-int/lit16 v15, v15, 0xff

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    const/16 v22, 0x2

    aput-object v15, v6, v22

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 212
    .local v6, "v\\1":Ljava/util/List;
    if-eqz v3, :cond_4

    sget-object v15, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v15, v6, v3}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v15

    if-eqz v15, :cond_6

    :cond_4
    move-object v3, v6

    goto :goto_5

    .line 210
    .end local v6    # "v\\1":Ljava/util/List;
    :cond_5
    const/16 v22, 0x2

    .line 214
    :cond_6
    :goto_5
    add-int/2addr v2, v12

    .line 215
    nop

    .line 204
    .end local v4    # "packed\\1":Ljava/lang/Integer;
    .end local v8    # "command\\1":I
    .end local v12    # "length\\1":I
    .end local v14    # "it\\1":I
    .end local v17    # "$i$a$-repeat-IpaPreflight$armSlice$1\\1\\204\\0":I
    add-int/lit8 v13, v13, 0x1

    move/from16 v8, v18

    move/from16 v15, v20

    move/from16 v4, v21

    move/from16 v6, v22

    goto/16 :goto_1

    .line 207
    .restart local v8    # "command\\1":I
    .restart local v12    # "length\\1":I
    .restart local v14    # "it\\1":I
    .restart local v17    # "$i$a$-repeat-IpaPreflight$armSlice$1\\1\\204\\0":I
    :cond_7
    new-instance v4, Lorg/lighttouch/android/IpaError;

    invoke-direct {v4, v15}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 205
    .end local v8    # "command\\1":I
    .end local v12    # "length\\1":I
    :cond_8
    new-instance v4, Lorg/lighttouch/android/IpaError;

    invoke-direct {v4, v15}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 216
    .end local v14    # "it\\1":I
    .end local v17    # "$i$a$-repeat-IpaPreflight$armSlice$1\\1\\204\\0":I
    :cond_9
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v4, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v4

    return-object v4

    .line 202
    .end local v2    # "cursor":I
    .end local v16    # "cpu":I
    .local v3, "cpu":I
    :cond_a
    move/from16 v16, v3

    .end local v3    # "cpu":I
    .restart local v16    # "cpu":I
    :cond_b
    new-instance v2, Lorg/lighttouch/android/IpaError;

    const-string v3, "\u6b64 IPA \u4e0d\u5305\u542b\u53d7\u652f\u6301\u7684 ARM \u53ef\u6267\u884c\u6587\u4ef6\u3002"

    invoke-direct {v2, v3}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v2

    .line 199
    .end local v5    # "subtype":I
    .end local v7    # "fileType":I
    .end local v9    # "commands":I
    .end local v11    # "size":I
    .end local v16    # "cpu":I
    :cond_c
    new-instance v2, Lorg/lighttouch/android/IpaError;

    const-string v3, "\u6b64 IPA \u9700\u8981\u4e0d\u53d7\u652f\u6301\u7684\u53ef\u6267\u884c\u6587\u4ef6\u683c\u5f0f\u3002"

    invoke-direct {v2, v3}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v2

    :sswitch_data_0
    .sparse-switch
        0x25 -> :sswitch_1
        0x32 -> :sswitch_0
    .end sparse-switch
.end method

.method private final armSlices([B)Ljava/util/List;
    .locals 23
    .param p1, "data"    # [B
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)",
            "Ljava/util/List<",
            "Lkotlin/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;>;>;"
        }
    .end annotation

    .line 183
    move-object/from16 v0, p1

    array-length v1, v0

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_9

    .line 184
    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v1

    sget-object v3, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v1, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v1

    .line 185
    .local v1, "big":Ljava/nio/ByteBuffer;
    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    const v5, -0x35014542    # -8346975.0f

    if-ne v4, v5, :cond_8

    .line 186
    const/4 v4, 0x4

    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    .line 187
    .local v4, "count":I
    const/4 v5, 0x1

    if-gt v5, v4, :cond_0

    const/16 v6, 0x21

    if-ge v4, v6, :cond_0

    goto :goto_0

    :cond_0
    move v5, v3

    :goto_0
    if-eqz v5, :cond_7

    array-length v5, v0

    mul-int/lit8 v6, v4, 0x14

    add-int/lit8 v6, v6, 0x8

    if-lt v5, v6, :cond_7

    .line 188
    invoke-static {v3, v4}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 288
    .local v5, "$i$f$mapNotNull\\1\\188":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\2":Ljava/util/Collection;
    move-object v7, v3

    .local v7, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 296
    .local v8, "$i$f$mapNotNullTo\\2\\288":I
    move-object v9, v7

    .local v9, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 297
    .local v10, "$i$f$forEach\\3\\296":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_5

    move-object v12, v11

    check-cast v12, Lkotlin/collections/IntIterator;

    invoke-virtual {v12}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v12

    .local v12, "element\\3":I
    move v13, v12

    .local v13, "element\\4":I
    const/4 v14, 0x0

    .line 296
    .local v14, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\297\\2":I
    move v15, v13

    .local v15, "i\\6":I
    const/16 v16, 0x0

    .line 189
    .local v16, "$i$a$-mapNotNull-IpaPreflight$armSlices$1\\6\\296\\0":I
    mul-int/lit8 v17, v15, 0x14

    add-int/lit8 v2, v17, 0x8

    invoke-virtual {v1, v2}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v2

    .local v2, "cpu\\6":I
    mul-int/lit8 v17, v15, 0x14

    move-object/from16 v18, v3

    .end local v3    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .local v18, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    add-int/lit8 v3, v17, 0x10

    invoke-virtual {v1, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v3

    .local v3, "offset\\6":I
    mul-int/lit8 v17, v15, 0x14

    move/from16 v19, v4

    .end local v4    # "count":I
    .local v19, "count":I
    add-int/lit8 v4, v17, 0x14

    invoke-virtual {v1, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    .line 190
    .local v4, "size\\6":I
    mul-int/lit8 v17, v19, 0x14

    move-object/from16 v20, v1

    .end local v1    # "big":Ljava/nio/ByteBuffer;
    .local v20, "big":Ljava/nio/ByteBuffer;
    add-int/lit8 v1, v17, 0x8

    if-lt v3, v1, :cond_3

    const/16 v1, 0x1c

    if-lt v4, v1, :cond_3

    move/from16 v17, v2

    .end local v2    # "cpu\\6":I
    .local v17, "cpu\\6":I
    int-to-long v1, v3

    move-wide/from16 v21, v1

    int-to-long v1, v4

    add-long v1, v21, v1

    move-wide/from16 v21, v1

    array-length v1, v0

    int-to-long v1, v1

    cmp-long v1, v21, v1

    if-gtz v1, :cond_4

    .line 191
    const/16 v1, 0xc

    move/from16 v2, v17

    .end local v17    # "cpu\\6":I
    .restart local v2    # "cpu\\6":I
    if-ne v2, v1, :cond_1

    sget-object v1, Lorg/lighttouch/android/IpaPreflight;->INSTANCE:Lorg/lighttouch/android/IpaPreflight;

    move/from16 v17, v2

    .end local v2    # "cpu\\6":I
    .restart local v17    # "cpu\\6":I
    add-int v2, v3, v4

    invoke-static {v0, v3, v2}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/lighttouch/android/IpaPreflight;->armSlice([B)Lkotlin/Pair;

    move-result-object v1

    goto :goto_2

    .end local v17    # "cpu\\6":I
    .restart local v2    # "cpu\\6":I
    :cond_1
    move/from16 v17, v2

    .end local v2    # "cpu\\6":I
    .restart local v17    # "cpu\\6":I
    const/4 v1, 0x0

    .line 296
    .end local v3    # "offset\\6":I
    .end local v4    # "size\\6":I
    .end local v15    # "i\\6":I
    .end local v16    # "$i$a$-mapNotNull-IpaPreflight$armSlices$1\\6\\296\\0":I
    .end local v17    # "cpu\\6":I
    :goto_2
    if-eqz v1, :cond_2

    .line 298
    .local v1, "it\\4":Ljava/lang/Object;
    const/4 v2, 0x0

    .line 296
    .local v2, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\298\\4":I
    invoke-interface {v6, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 297
    .end local v1    # "it\\4":Ljava/lang/Object;
    .end local v2    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\298\\4":I
    .end local v13    # "element\\4":I
    .end local v14    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\297\\2":I
    :cond_2
    move-object/from16 v3, v18

    move/from16 v4, v19

    move-object/from16 v1, v20

    const/16 v2, 0x1c

    .end local v12    # "element\\3":I
    goto :goto_1

    .line 190
    .local v2, "cpu\\6":I
    .restart local v3    # "offset\\6":I
    .restart local v4    # "size\\6":I
    .restart local v12    # "element\\3":I
    .restart local v13    # "element\\4":I
    .restart local v14    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\297\\2":I
    .restart local v15    # "i\\6":I
    .restart local v16    # "$i$a$-mapNotNull-IpaPreflight$armSlices$1\\6\\296\\0":I
    :cond_3
    move/from16 v17, v2

    .end local v2    # "cpu\\6":I
    .restart local v17    # "cpu\\6":I
    :cond_4
    new-instance v1, Lorg/lighttouch/android/IpaError;

    const-string v2, "\u901a\u7528\u53ef\u6267\u884c\u6587\u4ef6\u7684\u5206\u7247\u65e0\u6548\u3002"

    invoke-direct {v1, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 299
    .end local v12    # "element\\3":I
    .end local v13    # "element\\4":I
    .end local v14    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\297\\2":I
    .end local v15    # "i\\6":I
    .end local v16    # "$i$a$-mapNotNull-IpaPreflight$armSlices$1\\6\\296\\0":I
    .end local v17    # "cpu\\6":I
    .end local v18    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v19    # "count":I
    .end local v20    # "big":Ljava/nio/ByteBuffer;
    .local v1, "big":Ljava/nio/ByteBuffer;
    .local v3, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .local v4, "count":I
    :cond_5
    move-object/from16 v20, v1

    move-object/from16 v18, v3

    move/from16 v19, v4

    .line 300
    .end local v1    # "big":Ljava/nio/ByteBuffer;
    .end local v3    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v4    # "count":I
    .end local v9    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\3\\296":I
    .restart local v18    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .restart local v19    # "count":I
    .restart local v20    # "big":Ljava/nio/ByteBuffer;
    nop

    .end local v6    # "destination\\2":Ljava/util/Collection;
    .end local v7    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapNotNullTo\\2\\288":I
    move-object v1, v6

    check-cast v1, Ljava/util/List;

    .line 288
    nop

    .end local v5    # "$i$f$mapNotNull\\1\\188":I
    .end local v18    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    check-cast v1, Ljava/util/Collection;

    .line 192
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_6

    check-cast v1, Ljava/util/List;

    .line 188
    return-object v1

    .line 301
    :cond_6
    const/4 v1, 0x0

    .line 192
    .local v1, "$i$a$-ifEmpty-IpaPreflight$armSlices$2\\7\\192\\0":I
    new-instance v2, Lorg/lighttouch/android/IpaError;

    const-string v3, "\u6b64 IPA \u4e0d\u5305\u542b\u53d7\u652f\u6301\u7684 ARM \u53ef\u6267\u884c\u6587\u4ef6\u3002"

    invoke-direct {v2, v3}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v2

    .line 187
    .end local v19    # "count":I
    .end local v20    # "big":Ljava/nio/ByteBuffer;
    .local v1, "big":Ljava/nio/ByteBuffer;
    .restart local v4    # "count":I
    :cond_7
    move-object/from16 v20, v1

    move/from16 v19, v4

    .end local v1    # "big":Ljava/nio/ByteBuffer;
    .end local v4    # "count":I
    .restart local v19    # "count":I
    .restart local v20    # "big":Ljava/nio/ByteBuffer;
    new-instance v1, Lorg/lighttouch/android/IpaError;

    const-string v2, "\u901a\u7528\u53ef\u6267\u884c\u6587\u4ef6\u65e0\u6548\u3002"

    invoke-direct {v1, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 194
    .end local v19    # "count":I
    .end local v20    # "big":Ljava/nio/ByteBuffer;
    .restart local v1    # "big":Ljava/nio/ByteBuffer;
    :cond_8
    move-object/from16 v20, v1

    .end local v1    # "big":Ljava/nio/ByteBuffer;
    .restart local v20    # "big":Ljava/nio/ByteBuffer;
    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/IpaPreflight;->armSlice([B)Lkotlin/Pair;

    move-result-object v1

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    return-object v1

    .line 183
    .end local v20    # "big":Ljava/nio/ByteBuffer;
    :cond_9
    new-instance v1, Lorg/lighttouch/android/IpaError;

    const-string v2, "\u5e94\u7528\u53ef\u6267\u884c\u6587\u4ef6\u4e0d\u5b8c\u6574\u3002"

    invoke-direct {v1, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private final binaryPlist([B)Ljava/lang/Object;
    .locals 11
    .param p1, "data"    # [B

    .line 119
    invoke-static {p1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    sget-object v1, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v4

    .line 120
    .local v4, "b":Ljava/nio/ByteBuffer;
    array-length v0, p1

    add-int/lit8 v1, v0, -0x20

    .line 121
    .local v1, "trailer":I
    add-int/lit8 v0, v1, 0x6

    aget-byte v6, p1, v0

    .local v6, "offsetSize":I
    add-int/lit8 v0, v1, 0x7

    aget-byte v7, p1, v0

    .line 122
    .local v7, "refSize":I
    add-int/lit8 v0, v1, 0x8

    invoke-virtual {v4, v0}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v2

    long-to-int v2, v2

    .local v2, "objects":I
    add-int/lit8 v0, v1, 0x10

    invoke-virtual {v4, v0}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v8

    long-to-int v8, v8

    .local v8, "top":I
    add-int/lit8 v0, v1, 0x18

    invoke-virtual {v4, v0}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v9

    long-to-int v5, v9

    .line 152
    .local v5, "table":I
    const/4 v9, 0x0

    move-object v3, p1

    .end local p1    # "data":[B
    .local v3, "data":[B
    :try_start_0
    invoke-static/range {v2 .. v9}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$parse(I[BLjava/nio/ByteBuffer;IIIII)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception v0

    move-object p1, v0

    .local p1, "e":Ljava/lang/IndexOutOfBoundsException;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v9, "\u5e94\u7528\u7684 Info.plist \u5df2\u635f\u574f\u3002"

    invoke-direct {v0, v9}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static final binaryPlist$offset(II[BI)I
    .locals 1
    .param p0, "table"    # I
    .param p1, "offsetSize"    # I
    .param p2, "$data"    # [B
    .param p3, "ref"    # I

    .line 124
    mul-int v0, p3, p1

    add-int/2addr v0, p0

    invoke-static {p2, v0, p1}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$uint([BII)I

    move-result v0

    return v0
.end method

.method private static final binaryPlist$parse(I[BLjava/nio/ByteBuffer;IIIII)Ljava/lang/Object;
    .locals 24
    .param p0, "objects"    # I
    .param p1, "$data"    # [B
    .param p2, "b"    # Ljava/nio/ByteBuffer;
    .param p3, "table"    # I
    .param p4, "offsetSize"    # I
    .param p5, "refSize"    # I
    .param p6, "ref"    # I
    .param p7, "depth"    # I

    .line 126
    move-object/from16 v1, p1

    move/from16 v5, p5

    move/from16 v8, p6

    move/from16 v9, p7

    const/4 v0, 0x0

    const/4 v2, 0x1

    if-ltz v8, :cond_0

    move/from16 v3, p0

    if-ge v8, v3, :cond_1

    move v4, v2

    goto :goto_0

    :cond_0
    move/from16 v3, p0

    :cond_1
    move v4, v0

    :goto_0
    const-string v10, "\u5e94\u7528\u7684 Info.plist \u5df2\u635f\u574f\u3002"

    if-eqz v4, :cond_9

    const/16 v4, 0x20

    if-gt v9, v4, :cond_9

    .line 127
    const/4 v4, 0x0

    move/from16 v6, p3

    move v7, v4

    move/from16 v4, p4

    .local v7, "at":I
    invoke-static {v6, v4, v1, v8}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$offset(II[BI)I

    move-result v7

    .line 128
    aget-byte v11, v1, v7

    and-int/lit16 v11, v11, 0xff

    .line 129
    .local v11, "marker":I
    shr-int/lit8 v12, v11, 0x4

    .line 130
    .local v12, "type":I
    const/4 v13, 0x0

    .local v13, "count":I
    and-int/lit8 v13, v11, 0xf

    .line 131
    add-int/2addr v7, v2

    .line 132
    const/4 v14, 0x5

    new-array v15, v14, [Ljava/lang/Integer;

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v15, v0

    const/4 v14, 0x6

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    aput-object v14, v15, v2

    const/16 v14, 0xa

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    const/16 v17, 0x2

    aput-object v16, v15, v17

    const/16 v16, 0xd

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    move/from16 v17, v2

    const/4 v2, 0x3

    aput-object v16, v15, v2

    const/16 v16, 0x4

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v18

    aput-object v18, v15, v16

    invoke-static {v15}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v15

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v15, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/16 v2, 0xf

    if-ne v13, v2, :cond_2

    .line 133
    aget-byte v2, v1, v7

    and-int/lit16 v2, v2, 0xff

    .line 134
    .local v2, "intMarker":I
    and-int/lit8 v15, v2, 0xf

    shl-int v15, v17, v15

    .line 135
    .local v15, "bytes":I
    add-int/lit8 v14, v7, 0x1

    invoke-static {v1, v14, v15}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$uint([BII)I

    move-result v13

    add-int/lit8 v14, v15, 0x1

    add-int/2addr v7, v14

    move v14, v13

    move v13, v7

    goto :goto_1

    .line 137
    .end local v2    # "intMarker":I
    .end local v15    # "bytes":I
    :cond_2
    move v14, v13

    move v13, v7

    .end local v7    # "at":I
    .local v13, "at":I
    .local v14, "count":I
    :goto_1
    packed-switch v12, :pswitch_data_0

    .line 149
    :pswitch_0
    move-object/from16 v2, p2

    const/4 v15, 0x0

    goto/16 :goto_7

    .line 145
    :pswitch_1
    invoke-static {v0, v14}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$associate\\4":Ljava/lang/Iterable;
    const/16 v16, 0x0

    .line 335
    .local v16, "$i$f$associate\\4\\145":I
    const/16 v2, 0xa

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-static {v2}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v2

    const/16 v7, 0x10

    invoke-static {v2, v7}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    .line 336
    .local v2, "capacity\\4":I
    new-instance v7, Ljava/util/LinkedHashMap;

    invoke-direct {v7, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v7, Ljava/util/Map;

    .local v7, "destination\\5":Ljava/util/Map;
    move-object/from16 v17, v0

    .local v17, "$this$associateTo\\5":Ljava/lang/Iterable;
    const/16 v18, 0x0

    .line 337
    .local v18, "$i$f$associateTo\\5\\336":I
    invoke-interface/range {v17 .. v17}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v19

    :goto_2
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_5

    move-object/from16 v20, v19

    check-cast v20, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v20 .. v20}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v20

    .line 338
    .local v20, "element\\5":I
    move/from16 v21, v20

    .local v21, "it\\6":I
    const/16 v22, 0x0

    .line 146
    .local v22, "$i$a$-associate-IpaPreflight$binaryPlist$parse$2\\6\\338\\0":I
    mul-int v23, v21, v5

    add-int v15, v13, v23

    invoke-static {v1, v15, v5}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$uint([BII)I

    move-result v15

    move-object/from16 v23, v7

    .end local v7    # "destination\\5":Ljava/util/Map;
    .local v23, "destination\\5":Ljava/util/Map;
    add-int/lit8 v7, v9, 0x1

    move v8, v15

    move-object v15, v0

    move v0, v3

    move v3, v6

    move v6, v8

    move-object/from16 v8, v23

    move/from16 v23, v2

    move-object/from16 v2, p2

    .end local v0    # "$this$associate\\4":Ljava/lang/Iterable;
    .end local v2    # "capacity\\4":I
    .local v8, "destination\\5":Ljava/util/Map;
    .local v15, "$this$associate\\4":Ljava/lang/Iterable;
    .local v23, "capacity\\4":I
    invoke-static/range {v0 .. v7}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$parse(I[BLjava/nio/ByteBuffer;IIIII)Ljava/lang/Object;

    move-result-object v6

    instance-of v0, v6, Ljava/lang/String;

    if-eqz v0, :cond_3

    check-cast v6, Ljava/lang/String;

    goto :goto_3

    :cond_3
    const/4 v6, 0x0

    :goto_3
    if-eqz v6, :cond_4

    .line 147
    add-int v0, v14, v21

    mul-int/2addr v0, v5

    add-int/2addr v0, v13

    invoke-static {v1, v0, v5}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$uint([BII)I

    move-result v0

    add-int/lit8 v7, v9, 0x1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move-object v9, v6

    move v6, v0

    move/from16 v0, p0

    invoke-static/range {v0 .. v7}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$parse(I[BLjava/nio/ByteBuffer;IIIII)Ljava/lang/Object;

    move-result-object v6

    .line 146
    invoke-static {v9, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    .line 147
    nop

    .line 338
    .end local v21    # "it\\6":I
    .end local v22    # "$i$a$-associate-IpaPreflight$binaryPlist$parse$2\\6\\338\\0":I
    invoke-virtual {v0}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v8, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v3, p0

    move/from16 v6, p3

    move/from16 v9, p7

    move-object v7, v8

    move-object v0, v15

    move/from16 v2, v23

    move/from16 v8, p6

    goto :goto_2

    .line 146
    .restart local v21    # "it\\6":I
    .restart local v22    # "$i$a$-associate-IpaPreflight$binaryPlist$parse$2\\6\\338\\0":I
    :cond_4
    new-instance v0, Lorg/lighttouch/android/IpaError;

    invoke-direct {v0, v10}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 340
    .end local v8    # "destination\\5":Ljava/util/Map;
    .end local v15    # "$this$associate\\4":Ljava/lang/Iterable;
    .end local v20    # "element\\5":I
    .end local v21    # "it\\6":I
    .end local v22    # "$i$a$-associate-IpaPreflight$binaryPlist$parse$2\\6\\338\\0":I
    .end local v23    # "capacity\\4":I
    .restart local v0    # "$this$associate\\4":Ljava/lang/Iterable;
    .restart local v2    # "capacity\\4":I
    .restart local v7    # "destination\\5":Ljava/util/Map;
    :cond_5
    move-object v15, v0

    move/from16 v23, v2

    move-object v8, v7

    .line 336
    .end local v0    # "$this$associate\\4":Ljava/lang/Iterable;
    .end local v2    # "capacity\\4":I
    .end local v7    # "destination\\5":Ljava/util/Map;
    .end local v17    # "$this$associateTo\\5":Ljava/lang/Iterable;
    .end local v18    # "$i$f$associateTo\\5\\336":I
    .restart local v15    # "$this$associate\\4":Ljava/lang/Iterable;
    .restart local v23    # "capacity\\4":I
    move-object/from16 v2, p2

    move-object v15, v8

    .end local v15    # "$this$associate\\4":Ljava/lang/Iterable;
    .end local v16    # "$i$f$associate\\4\\145":I
    .end local v23    # "capacity\\4":I
    goto/16 :goto_7

    .line 144
    :pswitch_2
    invoke-static {v0, v14}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 331
    .local v9, "$i$f$map\\1\\144":I
    new-instance v0, Ljava/util/ArrayList;

    const/16 v2, 0xa

    invoke-static {v8, v2}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v0, Ljava/util/Collection;

    .local v0, "destination\\2":Ljava/util/Collection;
    move-object v10, v8

    .local v10, "$this$mapTo\\2":Ljava/lang/Iterable;
    move-object v15, v0

    .end local v0    # "destination\\2":Ljava/util/Collection;
    .local v15, "destination\\2":Ljava/util/Collection;
    const/16 v16, 0x0

    .line 332
    .local v16, "$i$f$mapTo\\2\\331":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_4
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_6

    move-object/from16 v0, v17

    check-cast v0, Lkotlin/collections/IntIterator;

    invoke-virtual {v0}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v18

    .line 333
    .local v18, "item\\2":I
    move/from16 v19, v18

    .local v19, "it\\3":I
    const/16 v20, 0x0

    .line 144
    .local v20, "$i$a$-map-IpaPreflight$binaryPlist$parse$1\\3\\333\\0":I
    mul-int v0, v19, v5

    add-int/2addr v0, v13

    invoke-static {v1, v0, v5}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$uint([BII)I

    move-result v6

    add-int/lit8 v7, p7, 0x1

    move/from16 v0, p0

    move-object/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    invoke-static/range {v0 .. v7}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist$parse(I[BLjava/nio/ByteBuffer;IIIII)Ljava/lang/Object;

    move-result-object v6

    .line 333
    .end local v19    # "it\\3":I
    .end local v20    # "$i$a$-map-IpaPreflight$binaryPlist$parse$1\\3\\333\\0":I
    invoke-interface {v15, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move/from16 v5, p5

    goto :goto_4

    .line 334
    .end local v18    # "item\\2":I
    :cond_6
    move-object/from16 v2, p2

    .end local v10    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v15    # "destination\\2":Ljava/util/Collection;
    .end local v16    # "$i$f$mapTo\\2\\331":I
    check-cast v15, Ljava/util/List;

    .line 331
    nop

    .end local v8    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v9    # "$i$f$map\\1\\144":I
    goto/16 :goto_7

    .line 142
    :pswitch_3
    move-object/from16 v2, p2

    new-instance v15, Ljava/lang/String;

    .line 143
    mul-int/lit8 v0, v14, 0x2

    sget-object v3, Lkotlin/text/Charsets;->UTF_16BE:Ljava/nio/charset/Charset;

    invoke-direct {v15, v1, v13, v0, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    goto :goto_7

    .line 141
    :pswitch_4
    move-object/from16 v2, p2

    new-instance v15, Ljava/lang/String;

    .line 142
    sget-object v0, Lkotlin/text/Charsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v15, v1, v13, v14, v0}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    goto :goto_7

    .line 141
    :pswitch_5
    move-object/from16 v2, p2

    add-int v0, v13, v14

    invoke-static {v1, v13, v0}, Lkotlin/collections/ArraysKt;->copyOfRange([BII)[B

    move-result-object v15

    goto :goto_7

    .line 140
    :pswitch_6
    move-object/from16 v2, p2

    and-int/lit8 v0, v11, 0xf

    const/4 v3, 0x3

    if-ne v0, v3, :cond_7

    invoke-virtual {v2, v13}, Ljava/nio/ByteBuffer;->getDouble(I)D

    move-result-wide v3

    goto :goto_5

    :cond_7
    invoke-virtual {v2, v13}, Ljava/nio/ByteBuffer;->getFloat(I)F

    move-result v0

    float-to-double v3, v0

    :goto_5
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v15

    goto :goto_7

    .line 139
    :pswitch_7
    move-object/from16 v2, p2

    and-int/lit8 v0, v11, 0xf

    shl-int v0, v17, v0

    .local v0, "bytes":I
    const-wide/16 v3, 0x0

    .local v3, "v":J
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_6
    if-ge v5, v0, :cond_8

    const/16 v6, 0x8

    shl-long v6, v3, v6

    add-int v8, v13, v5

    aget-byte v8, v1, v8

    int-to-long v8, v8

    const-wide/16 v15, 0xff

    and-long/2addr v8, v15

    or-long v3, v6, v8

    add-int/lit8 v5, v5, 0x1

    goto :goto_6

    .end local v0    # "bytes":I
    .end local v3    # "v":J
    .end local v5    # "i":I
    :cond_8
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v15

    goto :goto_7

    .line 138
    :pswitch_8
    move-object/from16 v2, p2

    packed-switch v11, :pswitch_data_1

    const/4 v15, 0x0

    goto :goto_7

    :pswitch_9
    invoke-static/range {v17 .. v17}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    goto :goto_7

    :pswitch_a
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    .line 137
    :goto_7
    return-object v15

    .line 126
    .end local v11    # "marker":I
    .end local v12    # "type":I
    .end local v13    # "at":I
    .end local v14    # "count":I
    :cond_9
    move-object/from16 v2, p2

    new-instance v0, Lorg/lighttouch/android/IpaError;

    invoke-direct {v0, v10}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_0
        :pswitch_1
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x8
        :pswitch_a
        :pswitch_9
    .end packed-switch
.end method

.method private static final binaryPlist$uint([BII)I
    .locals 9
    .param p0, "$data"    # [B
    .param p1, "at"    # I
    .param p2, "size"    # I

    .line 123
    const-wide/16 v0, 0x0

    .local v0, "v":J
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_0
    if-ge v2, p2, :cond_0

    const/16 v3, 0x8

    shl-long v3, v0, v3

    add-int v5, p1, v2

    aget-byte v5, p0, v5

    int-to-long v5, v5

    const-wide/16 v7, 0xff

    and-long/2addr v5, v7

    or-long v0, v3, v5

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .end local v2    # "i":I
    :cond_0
    long-to-int v2, v0

    return v2
.end method

.method private final openZip(Ljava/io/File;)Lorg/lighttouch/android/IpaPreflight$Zip;
    .locals 51
    .param p1, "path"    # Ljava/io/File;

    .line 56
    new-instance v0, Ljava/io/RandomAccessFile;

    const-string v1, "r"

    move-object/from16 v2, p1

    invoke-direct {v0, v2, v1}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v1, v0

    .line 57
    .local v1, "file":Ljava/io/RandomAccessFile;
    nop

    .line 58
    :try_start_0
    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->length()J

    move-result-wide v3

    .line 59
    .local v3, "length":J
    const-wide/32 v5, 0x10015

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v5

    long-to-int v0, v5

    new-array v0, v0, [B

    .line 60
    .local v0, "tail":[B
    array-length v5, v0

    int-to-long v5, v5

    sub-long v5, v3, v5

    invoke-virtual {v1, v5, v6}, Ljava/io/RandomAccessFile;->seek(J)V

    invoke-virtual {v1, v0}, Ljava/io/RandomAccessFile;->readFully([B)V

    .line 61
    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v5

    sget-object v6, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v5

    .line 62
    .local v5, "t":Ljava/nio/ByteBuffer;
    array-length v6, v0

    add-int/lit8 v6, v6, -0x16

    const/4 v7, 0x0

    invoke-static {v6, v7}, Lkotlin/ranges/RangesKt;->downTo(II)Lkotlin/ranges/IntProgression;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 286
    .local v8, "$i$f$firstOrNull\\1\\62":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\1":Ljava/lang/Object;
    move-object v12, v10

    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    move-result v12

    .local v12, "it\\2":I
    const/4 v13, 0x0

    .line 62
    .local v13, "$i$a$-firstOrNull-IpaPreflight$openZip$eocd$1\\2\\286\\0":I
    invoke-virtual {v5, v12}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v14

    const v15, 0x6054b50

    if-ne v14, v15, :cond_1

    const/4 v12, 0x1

    goto :goto_0

    :cond_1
    move v12, v7

    .line 286
    .end local v12    # "it\\2":I
    .end local v13    # "$i$a$-firstOrNull-IpaPreflight$openZip$eocd$1\\2\\286\\0":I
    :goto_0
    if-eqz v12, :cond_0

    goto :goto_1

    .line 287
    .end local v10    # "element\\1":Ljava/lang/Object;
    :cond_2
    const/4 v10, 0x0

    .line 62
    .end local v6    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v8    # "$i$f$firstOrNull\\1\\62":I
    :goto_1
    check-cast v10, Ljava/lang/Integer;

    if-eqz v10, :cond_f

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v6

    .line 63
    .local v6, "eocd":I
    add-int/lit8 v8, v6, 0xa

    invoke-virtual {v5, v8}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v8

    const v9, 0xffff

    and-int/2addr v8, v9

    int-to-long v12, v8

    .line 64
    .local v12, "count":J
    add-int/lit8 v8, v6, 0xc

    invoke-virtual {v5, v8}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v8

    int-to-long v14, v8

    const-wide v16, 0xffffffffL

    and-long v14, v14, v16

    .line 65
    .local v14, "cdSize":J
    const-wide/16 v18, 0x0

    .local v18, "cdOffset":J
    add-int/lit8 v8, v6, 0x10

    invoke-virtual {v5, v8}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v8
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move/from16 v20, v9

    int-to-long v9, v8

    and-long v8, v9, v16

    .line 66
    .end local v18    # "cdOffset":J
    .local v8, "cdOffset":J
    const-wide/32 v18, 0xffff

    cmp-long v10, v12, v18

    if-eqz v10, :cond_4

    cmp-long v10, v8, v16

    if-eqz v10, :cond_4

    cmp-long v10, v14, v16

    if-nez v10, :cond_3

    goto :goto_2

    :cond_3
    move-object/from16 v21, v0

    move-wide/from16 v22, v3

    move v3, v7

    goto :goto_3

    .line 68
    :cond_4
    :goto_2
    add-int/lit8 v10, v6, -0x14

    .line 69
    .local v10, "locator":I
    const-string v11, "IPA \u7684 ZIP64 \u76ee\u5f55\u5df2\u635f\u574f\u3002"

    if-ltz v10, :cond_e

    :try_start_1
    invoke-virtual {v5, v10}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v7

    move-object/from16 v21, v0

    .end local v0    # "tail":[B
    .local v21, "tail":[B
    const v0, 0x7064b50

    if-ne v7, v0, :cond_d

    .line 70
    const/16 v0, 0x38

    new-array v0, v0, [B

    .local v0, "record":[B
    add-int/lit8 v7, v10, 0x8

    move-wide/from16 v22, v3

    .end local v3    # "length":J
    .local v22, "length":J
    invoke-virtual {v5, v7}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/io/RandomAccessFile;->seek(J)V

    invoke-virtual {v1, v0}, Ljava/io/RandomAccessFile;->readFully([B)V

    .line 71
    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v2

    sget-object v3, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v2

    .line 72
    .local v2, "r":Ljava/nio/ByteBuffer;
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    const v7, 0x6064b50

    if-ne v4, v7, :cond_c

    .line 73
    const/16 v4, 0x20

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v24

    move-wide/from16 v12, v24

    const/16 v4, 0x28

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v24

    move-wide/from16 v14, v24

    const/16 v4, 0x30

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v24

    move-wide/from16 v8, v24

    .line 75
    .end local v0    # "record":[B
    .end local v2    # "r":Ljava/nio/ByteBuffer;
    .end local v10    # "locator":I
    :goto_3
    const-wide/32 v10, 0x186a0

    cmp-long v0, v12, v10

    if-gtz v0, :cond_b

    const-wide/32 v10, 0x4000000

    cmp-long v0, v14, v10

    if-gtz v0, :cond_b

    add-long v10, v8, v14

    cmp-long v0, v10, v22

    if-gtz v0, :cond_b

    .line 76
    long-to-int v0, v14

    new-array v0, v0, [B

    .local v0, "cd":[B
    invoke-virtual {v1, v8, v9}, Ljava/io/RandomAccessFile;->seek(J)V

    invoke-virtual {v1, v0}, Ljava/io/RandomAccessFile;->readFully([B)V

    .line 77
    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v2

    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v2

    .line 78
    .local v2, "c":Ljava/nio/ByteBuffer;
    new-instance v4, Ljava/util/ArrayList;

    long-to-int v7, v12

    invoke-direct {v4, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 79
    .local v4, "entries":Ljava/util/ArrayList;
    const/4 v7, 0x0

    .line 80
    .local v7, "at":I
    long-to-int v10, v12

    move/from16 v50, v7

    move v7, v3

    move/from16 v3, v50

    .end local v7    # "at":I
    .local v3, "at":I
    :goto_4
    if-ge v7, v10, :cond_a

    move v11, v7

    .local v11, "it\\3":I
    const/16 v19, 0x0

    .line 81
    .local v19, "$i$a$-repeat-IpaPreflight$openZip$1\\3\\80\\0":I
    move-object/from16 v24, v4

    .end local v4    # "entries":Ljava/util/ArrayList;
    .local v24, "entries":Ljava/util/ArrayList;
    add-int/lit8 v4, v3, 0x2e

    move-object/from16 v25, v5

    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .local v25, "t":Ljava/nio/ByteBuffer;
    array-length v5, v0

    if-gt v4, v5, :cond_9

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    const v5, 0x2014b50

    if-ne v4, v5, :cond_9

    .line 82
    add-int/lit8 v4, v3, 0x1c

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v4

    and-int v4, v4, v20

    .line 83
    .local v4, "nameLength\\3":I
    add-int/lit8 v5, v3, 0x1e

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v5

    and-int v5, v5, v20

    .line 84
    .local v5, "extraLength\\3":I
    move/from16 v26, v5

    .end local v5    # "extraLength\\3":I
    .local v26, "extraLength\\3":I
    add-int/lit8 v5, v3, 0x20

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v5

    and-int v5, v5, v20

    .line 85
    .local v5, "commentLength\\3":I
    move/from16 v27, v5

    .end local v5    # "commentLength\\3":I
    .local v27, "commentLength\\3":I
    add-int/lit8 v5, v3, 0x14

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v5

    move/from16 v28, v6

    .end local v6    # "eocd":I
    .local v28, "eocd":I
    int-to-long v5, v5

    and-long v5, v5, v16

    .line 86
    .local v5, "compressed\\3":J
    move-wide/from16 v29, v5

    .end local v5    # "compressed\\3":J
    .local v29, "compressed\\3":J
    add-int/lit8 v5, v3, 0x18

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v5

    int-to-long v5, v5

    and-long v5, v5, v16

    .line 87
    .local v5, "size\\3":J
    move-wide/from16 v31, v5

    .end local v5    # "size\\3":J
    .local v31, "size\\3":J
    add-int/lit8 v5, v3, 0x2a

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v5

    int-to-long v5, v5

    and-long v5, v5, v16

    .line 88
    .local v5, "local\\3":J
    add-int/lit8 v33, v3, 0x2e

    add-int v33, v33, v4

    .line 89
    .local v33, "extra\\3":I
    move-wide/from16 v34, v5

    .end local v5    # "local\\3":J
    .local v34, "local\\3":J
    add-int v5, v33, v26

    move-wide/from16 v40, v29

    move-wide/from16 v42, v31

    move/from16 v6, v33

    move-wide/from16 v44, v34

    .line 90
    .end local v29    # "compressed\\3":J
    .end local v31    # "size\\3":J
    .end local v33    # "extra\\3":I
    .end local v34    # "local\\3":J
    .local v5, "extraEnd\\3":I
    .local v6, "extra\\3":I
    .local v40, "compressed\\3":J
    .local v42, "size\\3":J
    .local v44, "local\\3":J
    :goto_5
    move/from16 v29, v7

    add-int/lit8 v7, v6, 0x4

    if-gt v7, v5, :cond_8

    .line 91
    invoke-virtual {v2, v6}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v7

    and-int v7, v7, v20

    .local v7, "id\\3":I
    move/from16 v30, v5

    .end local v5    # "extraEnd\\3":I
    .local v30, "extraEnd\\3":I
    add-int/lit8 v5, v6, 0x2

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v5

    and-int v5, v5, v20

    .line 92
    .local v5, "len\\3":I
    move/from16 v31, v5

    const/4 v5, 0x1

    .end local v5    # "len\\3":I
    .local v31, "len\\3":I
    if-ne v7, v5, :cond_7

    .line 93
    add-int/lit8 v5, v6, 0x4

    .line 94
    .local v5, "p\\3":I
    cmp-long v32, v42, v16

    if-nez v32, :cond_5

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v32

    move-wide/from16 v42, v32

    add-int/lit8 v5, v5, 0x8

    .line 95
    :cond_5
    cmp-long v32, v40, v16

    if-nez v32, :cond_6

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v32

    move-wide/from16 v40, v32

    add-int/lit8 v5, v5, 0x8

    .line 96
    :cond_6
    cmp-long v32, v44, v16

    if-nez v32, :cond_7

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->getLong(I)J

    move-result-wide v32

    move-wide/from16 v44, v32

    .line 98
    .end local v5    # "p\\3":I
    :cond_7
    add-int/lit8 v5, v31, 0x4

    add-int/2addr v6, v5

    move/from16 v7, v29

    move/from16 v5, v30

    .end local v7    # "id\\3":I
    .end local v31    # "len\\3":I
    goto :goto_5

    .line 100
    .end local v30    # "extraEnd\\3":I
    .local v5, "extraEnd\\3":I
    :cond_8
    move/from16 v30, v5

    .end local v5    # "extraEnd\\3":I
    .restart local v30    # "extraEnd\\3":I
    move-object/from16 v5, v24

    check-cast v5, Ljava/util/Collection;

    new-instance v36, Lorg/lighttouch/android/IpaPreflight$Entry;

    new-instance v7, Ljava/lang/String;

    move/from16 v31, v6

    .end local v6    # "extra\\3":I
    .local v31, "extra\\3":I
    add-int/lit8 v6, v3, 0x2e

    move-wide/from16 v32, v8

    .end local v8    # "cdOffset":J
    .local v32, "cdOffset":J
    sget-object v8, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v7, v0, v6, v4, v8}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    add-int/lit8 v6, v3, 0xa

    invoke-virtual {v2, v6}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v6

    and-int v38, v6, v20

    .line 101
    add-int/lit8 v6, v3, 0x8

    invoke-virtual {v2, v6}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v6

    and-int v39, v6, v20

    add-int/lit8 v6, v3, 0x26

    invoke-virtual {v2, v6}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v6

    int-to-long v8, v6

    and-long v46, v8, v16

    int-to-long v8, v3

    add-long v48, v32, v8

    .line 100
    move-object/from16 v37, v7

    invoke-direct/range {v36 .. v49}, Lorg/lighttouch/android/IpaPreflight$Entry;-><init>(Ljava/lang/String;IIJJJJJ)V

    move-object/from16 v6, v36

    invoke-interface {v5, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 102
    add-int v3, v30, v27

    .line 103
    nop

    .line 80
    .end local v4    # "nameLength\\3":I
    .end local v11    # "it\\3":I
    .end local v19    # "$i$a$-repeat-IpaPreflight$openZip$1\\3\\80\\0":I
    .end local v26    # "extraLength\\3":I
    .end local v27    # "commentLength\\3":I
    .end local v30    # "extraEnd\\3":I
    .end local v31    # "extra\\3":I
    .end local v40    # "compressed\\3":J
    .end local v42    # "size\\3":J
    .end local v44    # "local\\3":J
    add-int/lit8 v7, v29, 0x1

    move-object/from16 v4, v24

    move-object/from16 v5, v25

    move/from16 v6, v28

    move-wide/from16 v8, v32

    goto/16 :goto_4

    .line 81
    .end local v28    # "eocd":I
    .end local v32    # "cdOffset":J
    .local v6, "eocd":I
    .restart local v8    # "cdOffset":J
    .restart local v11    # "it\\3":I
    .restart local v19    # "$i$a$-repeat-IpaPreflight$openZip$1\\3\\80\\0":I
    :cond_9
    move/from16 v28, v6

    move-wide/from16 v32, v8

    .end local v6    # "eocd":I
    .end local v8    # "cdOffset":J
    .restart local v28    # "eocd":I
    .restart local v32    # "cdOffset":J
    new-instance v4, Lorg/lighttouch/android/IpaError;

    const-string v5, "IPA \u76ee\u5f55\u5df2\u635f\u574f\u3002"

    invoke-direct {v4, v5}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "path":Ljava/io/File;
    throw v4

    .line 104
    .end local v11    # "it\\3":I
    .end local v19    # "$i$a$-repeat-IpaPreflight$openZip$1\\3\\80\\0":I
    .end local v24    # "entries":Ljava/util/ArrayList;
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .end local v28    # "eocd":I
    .end local v32    # "cdOffset":J
    .restart local v1    # "file":Ljava/io/RandomAccessFile;
    .local v4, "entries":Ljava/util/ArrayList;
    .local v5, "t":Ljava/nio/ByteBuffer;
    .restart local v6    # "eocd":I
    .restart local v8    # "cdOffset":J
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "path":Ljava/io/File;
    :cond_a
    move-object/from16 v24, v4

    move-object/from16 v25, v5

    move/from16 v28, v6

    move-wide/from16 v32, v8

    .end local v4    # "entries":Ljava/util/ArrayList;
    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .end local v6    # "eocd":I
    .end local v8    # "cdOffset":J
    .restart local v24    # "entries":Ljava/util/ArrayList;
    .restart local v25    # "t":Ljava/nio/ByteBuffer;
    .restart local v28    # "eocd":I
    .restart local v32    # "cdOffset":J
    new-instance v4, Lorg/lighttouch/android/IpaPreflight$Zip;

    move-object/from16 v5, v24

    check-cast v5, Ljava/util/List;

    invoke-direct {v4, v1, v5}, Lorg/lighttouch/android/IpaPreflight$Zip;-><init>(Ljava/io/RandomAccessFile;Ljava/util/List;)V

    return-object v4

    .line 75
    .end local v0    # "cd":[B
    .end local v2    # "c":Ljava/nio/ByteBuffer;
    .end local v3    # "at":I
    .end local v24    # "entries":Ljava/util/ArrayList;
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .end local v28    # "eocd":I
    .end local v32    # "cdOffset":J
    .restart local v5    # "t":Ljava/nio/ByteBuffer;
    .restart local v6    # "eocd":I
    .restart local v8    # "cdOffset":J
    :cond_b
    move-object/from16 v25, v5

    move/from16 v28, v6

    move-wide/from16 v32, v8

    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .end local v6    # "eocd":I
    .end local v8    # "cdOffset":J
    .restart local v25    # "t":Ljava/nio/ByteBuffer;
    .restart local v28    # "eocd":I
    .restart local v32    # "cdOffset":J
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v2, "IPA \u76ee\u5f55\u8fc7\u5927\u6216\u5df2\u635f\u574f\u3002"

    invoke-direct {v0, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "path":Ljava/io/File;
    throw v0

    .line 72
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .end local v28    # "eocd":I
    .end local v32    # "cdOffset":J
    .local v0, "record":[B
    .restart local v1    # "file":Ljava/io/RandomAccessFile;
    .local v2, "r":Ljava/nio/ByteBuffer;
    .restart local v5    # "t":Ljava/nio/ByteBuffer;
    .restart local v6    # "eocd":I
    .restart local v8    # "cdOffset":J
    .restart local v10    # "locator":I
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "path":Ljava/io/File;
    :cond_c
    move-object/from16 v25, v5

    move/from16 v28, v6

    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .end local v6    # "eocd":I
    .restart local v25    # "t":Ljava/nio/ByteBuffer;
    .restart local v28    # "eocd":I
    new-instance v3, Lorg/lighttouch/android/IpaError;

    invoke-direct {v3, v11}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "path":Ljava/io/File;
    throw v3

    .line 69
    .end local v0    # "record":[B
    .end local v2    # "r":Ljava/nio/ByteBuffer;
    .end local v22    # "length":J
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .end local v28    # "eocd":I
    .restart local v1    # "file":Ljava/io/RandomAccessFile;
    .local v3, "length":J
    .restart local v5    # "t":Ljava/nio/ByteBuffer;
    .restart local v6    # "eocd":I
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "path":Ljava/io/File;
    :cond_d
    move-wide/from16 v22, v3

    move-object/from16 v25, v5

    move/from16 v28, v6

    .end local v3    # "length":J
    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .end local v6    # "eocd":I
    .restart local v22    # "length":J
    .restart local v25    # "t":Ljava/nio/ByteBuffer;
    .restart local v28    # "eocd":I
    goto :goto_6

    .end local v21    # "tail":[B
    .end local v22    # "length":J
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .end local v28    # "eocd":I
    .local v0, "tail":[B
    .restart local v3    # "length":J
    .restart local v5    # "t":Ljava/nio/ByteBuffer;
    .restart local v6    # "eocd":I
    :cond_e
    move-object/from16 v21, v0

    move-wide/from16 v22, v3

    move-object/from16 v25, v5

    move/from16 v28, v6

    .end local v0    # "tail":[B
    .end local v3    # "length":J
    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .end local v6    # "eocd":I
    .restart local v21    # "tail":[B
    .restart local v22    # "length":J
    .restart local v25    # "t":Ljava/nio/ByteBuffer;
    .restart local v28    # "eocd":I
    :goto_6
    new-instance v0, Lorg/lighttouch/android/IpaError;

    invoke-direct {v0, v11}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "path":Ljava/io/File;
    throw v0

    .line 62
    .end local v8    # "cdOffset":J
    .end local v10    # "locator":I
    .end local v12    # "count":J
    .end local v14    # "cdSize":J
    .end local v21    # "tail":[B
    .end local v22    # "length":J
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .end local v28    # "eocd":I
    .restart local v0    # "tail":[B
    .restart local v1    # "file":Ljava/io/RandomAccessFile;
    .restart local v3    # "length":J
    .restart local v5    # "t":Ljava/nio/ByteBuffer;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "path":Ljava/io/File;
    :cond_f
    move-object/from16 v21, v0

    move-wide/from16 v22, v3

    move-object/from16 v25, v5

    .end local v0    # "tail":[B
    .end local v3    # "length":J
    .end local v5    # "t":Ljava/nio/ByteBuffer;
    .restart local v21    # "tail":[B
    .restart local v22    # "length":J
    .restart local v25    # "t":Ljava/nio/ByteBuffer;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v2, "\u6b64\u6587\u4ef6\u4e0d\u662f ZIP \u538b\u7f29\u5305\u3002"

    invoke-direct {v0, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v1    # "file":Ljava/io/RandomAccessFile;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "path":Ljava/io/File;
    throw v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 105
    .end local v21    # "tail":[B
    .end local v22    # "length":J
    .end local v25    # "t":Ljava/nio/ByteBuffer;
    .restart local v1    # "file":Ljava/io/RandomAccessFile;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "path":Ljava/io/File;
    :catch_0
    move-exception v0

    .line 106
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->close()V

    .line 107
    instance-of v2, v0, Lorg/lighttouch/android/IpaError;

    if-eqz v2, :cond_10

    move-object v2, v0

    check-cast v2, Ljava/lang/Throwable;

    goto :goto_7

    :cond_10
    new-instance v2, Lorg/lighttouch/android/IpaError;

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "The IPA is incomplete or damaged: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    check-cast v2, Ljava/lang/Throwable;

    :goto_7
    throw v2
.end method

.method private final plist([B)Ljava/util/Map;
    .locals 4
    .param p1, "data"    # [B
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .line 113
    array-length v0, p1

    const/16 v1, 0x8

    if-lt v0, v1, :cond_0

    new-instance v0, Ljava/lang/String;

    const/4 v2, 0x0

    sget-object v3, Lkotlin/text/Charsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v0, p1, v2, v1, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const-string v1, "bplist00"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0, p1}, Lorg/lighttouch/android/IpaPreflight;->binaryPlist([B)Ljava/lang/Object;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1}, Lorg/lighttouch/android/IpaPreflight;->xmlPlist([B)Ljava/lang/Object;

    move-result-object v0

    .line 115
    .local v0, "root":Ljava/lang/Object;
    :goto_0
    instance-of v1, v0, Ljava/util/Map;

    if-eqz v1, :cond_1

    move-object v1, v0

    check-cast v1, Ljava/util/Map;

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_1
    if-eqz v1, :cond_2

    return-object v1

    :cond_2
    new-instance v1, Lorg/lighttouch/android/IpaError;

    const-string v2, "\u5e94\u7528\u7684 Info.plist \u4e0d\u662f\u5b57\u5178\u7ed3\u6784\u3002"

    invoke-direct {v1, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method private final xmlPlist([B)Ljava/lang/Object;
    .locals 4
    .param p1, "data"    # [B

    .line 156
    invoke-static {}, Landroid/util/Xml;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;

    move-result-object v0

    .line 157
    .local v0, "parser":Lorg/xmlpull/v1/XmlPullParser;
    const-string v1, "http://xmlpull.org/v1/doc/features.html#process-docdecl"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Lorg/xmlpull/v1/XmlPullParser;->setFeature(Ljava/lang/String;Z)V

    .line 158
    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    check-cast v1, Ljava/io/InputStream;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/InputStream;Ljava/lang/String;)V

    .line 177
    :cond_0
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v1

    const/4 v3, 0x2

    if-ne v1, v3, :cond_2

    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v3, "plist"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    .line 178
    :cond_1
    invoke-static {v0}, Lorg/lighttouch/android/IpaPreflight;->xmlPlist$value(Lorg/xmlpull/v1/XmlPullParser;)Ljava/lang/Object;

    move-result-object v1

    return-object v1

    .line 177
    :cond_2
    :goto_0
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v1

    const/4 v3, 0x1

    if-ne v1, v3, :cond_0

    return-object v2
.end method

.method private static final xmlPlist$value(Lorg/xmlpull/v1/XmlPullParser;)Ljava/lang/Object;
    .locals 7
    .param p0, "parser"    # Lorg/xmlpull/v1/XmlPullParser;

    .line 160
    nop

    :goto_0
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    goto :goto_0

    .line 161
    :cond_0
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_c

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v3, 0x3

    const-string v4, "nextText(...)"

    sparse-switch v2, :sswitch_data_0

    goto/16 :goto_3

    :sswitch_0
    const-string v1, "integer"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto/16 :goto_3

    .line 170
    :cond_1
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    goto/16 :goto_4

    .line 161
    :sswitch_1
    const-string v1, "false"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto/16 :goto_3

    .line 173
    :cond_2
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    goto/16 :goto_4

    .line 161
    :sswitch_2
    const-string v2, "array"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto/16 :goto_3

    .line 168
    :cond_3
    invoke-static {}, Lkotlin/collections/CollectionsKt;->createListBuilder()Ljava/util/List;

    move-result-object v0

    move-object v2, v0

    .line 341
    .local v2, "$this$xmlPlist_u24value_u24lambda_u245\\2":Ljava/util/List;
    const/4 v4, 0x0

    .line 168
    .local v4, "$i$a$-buildList-IpaPreflight$xmlPlist$value$2\\2\\168\\0":I
    :cond_4
    :goto_1
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v5

    if-eq v5, v3, :cond_5

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v5

    if-ne v5, v1, :cond_4

    invoke-static {p0}, Lorg/lighttouch/android/IpaPreflight;->xmlPlist$value(Lorg/xmlpull/v1/XmlPullParser;)Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v2, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .end local v2    # "$this$xmlPlist_u24value_u24lambda_u245\\2":Ljava/util/List;
    .end local v4    # "$i$a$-buildList-IpaPreflight$xmlPlist$value$2\\2\\168\\0":I
    :cond_5
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->build(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    goto/16 :goto_4

    .line 161
    :sswitch_3
    const-string v1, "true"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto/16 :goto_3

    .line 172
    :cond_6
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    goto :goto_4

    .line 161
    :sswitch_4
    const-string v1, "real"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_3

    .line 171
    :cond_7
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->toDoubleOrNull(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v0

    goto :goto_4

    .line 161
    :sswitch_5
    const-string v2, "dict"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_3

    .line 162
    :cond_8
    invoke-static {}, Lkotlin/collections/MapsKt;->createMapBuilder()Ljava/util/Map;

    move-result-object v0

    move-object v2, v0

    .local v2, "$this$xmlPlist_u24value_u24lambda_u244\\1":Ljava/util/Map;
    const/4 v4, 0x0

    .line 163
    .local v4, "$i$a$-buildMap-IpaPreflight$xmlPlist$value$1\\1\\162\\0":I
    :cond_9
    :goto_2
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v5

    if-eq v5, v3, :cond_a

    .line 164
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v5

    if-ne v5, v1, :cond_9

    .line 165
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v5

    .local v5, "key\\1":Ljava/lang/String;
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    invoke-static {p0}, Lorg/lighttouch/android/IpaPreflight;->xmlPlist$value(Lorg/xmlpull/v1/XmlPullParser;)Ljava/lang/Object;

    move-result-object v6

    invoke-interface {v2, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    .line 167
    .end local v5    # "key\\1":Ljava/lang/String;
    :cond_a
    nop

    .line 162
    .end local v2    # "$this$xmlPlist_u24value_u24lambda_u244\\1":Ljava/util/Map;
    .end local v4    # "$i$a$-buildMap-IpaPreflight$xmlPlist$value$1\\1\\162\\0":I
    invoke-static {v0}, Lkotlin/collections/MapsKt;->build(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    goto :goto_4

    .line 161
    :sswitch_6
    const-string v1, "string"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_3

    .line 169
    :cond_b
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    move-result-object v0

    goto :goto_4

    .line 174
    :cond_c
    :goto_3
    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->nextText()Ljava/lang/String;

    const/4 v0, 0x0

    .line 161
    :goto_4
    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x352a9fef -> :sswitch_6
        0x2f0bb6 -> :sswitch_5
        0x35599e -> :sswitch_4
        0x36758e -> :sswitch_3
        0x58c7259 -> :sswitch_2
        0x5cb1923 -> :sswitch_1
        0x74b5813e -> :sswitch_0
    .end sparse-switch
.end method


# virtual methods
.method public final prepare(Ljava/io/File;Ljava/io/File;Lorg/lighttouch/android/StoreTarget;)Lorg/lighttouch/android/IpaInfo;
    .locals 47
    .param p1, "source"    # Ljava/io/File;
    .param p2, "destination"    # Ljava/io/File;
    .param p3, "target"    # Lorg/lighttouch/android/StoreTarget;

    move-object/from16 v2, p2

    const-string v0, "source"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "destination"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    move-object/from16 v7, p3

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 221
    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    move-result v0

    if-eqz v0, :cond_3e

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v3

    const-wide/16 v5, 0x1

    cmp-long v0, v5, v3

    if-gtz v0, :cond_0

    const-wide v5, 0x80000001L

    cmp-long v0, v3, v5

    if-gez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_3e

    .line 222
    invoke-direct/range {p0 .. p1}, Lorg/lighttouch/android/IpaPreflight;->openZip(Ljava/io/File;)Lorg/lighttouch/android/IpaPreflight$Zip;

    move-result-object v10

    .line 223
    .local v10, "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    invoke-virtual {v10}, Lorg/lighttouch/android/IpaPreflight$Zip;->getFile()Ljava/io/RandomAccessFile;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v3

    check-cast v0, Ljava/io/RandomAccessFile;

    .local v0, "it\\1":Ljava/io/RandomAccessFile;
    const/4 v4, 0x0

    .line 224
    .local v4, "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    invoke-virtual {v10}, Lorg/lighttouch/android/IpaPreflight$Zip;->getEntries()Ljava/util/List;

    move-result-object v5

    .line 225
    .local v5, "entries\\1":Ljava/util/List;
    move-object v6, v5

    check-cast v6, Ljava/lang/Iterable;

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    const-wide/16 v11, 0x0

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lorg/lighttouch/android/IpaPreflight$Entry;

    .line 301
    nop

    .local v13, "it\\2":Lorg/lighttouch/android/IpaPreflight$Entry;
    const/4 v14, 0x0

    .line 225
    .local v14, "$i$a$-sumOfLong-IpaPreflight$prepare$1$1\\2\\225\\1":I
    invoke-virtual {v13}, Lorg/lighttouch/android/IpaPreflight$Entry;->getSize()J

    move-result-wide v15

    .end local v13    # "it\\2":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v14    # "$i$a$-sumOfLong-IpaPreflight$prepare$1$1\\2\\225\\1":I
    add-long/2addr v11, v15

    goto :goto_1

    :cond_1
    const-wide v13, 0x200000000L

    cmp-long v6, v11, v13

    if-gtz v6, :cond_3d

    .line 226
    new-instance v6, Ljava/util/HashSet;

    invoke-direct {v6}, Ljava/util/HashSet;-><init>()V

    .line 227
    .local v6, "names\\1":Ljava/util/HashSet;
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_2
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const-string v13, ".app"

    const-string v14, "Payload"

    const-string v15, ".."

    const/16 v16, 0x0

    const-string v9, "/"

    const-string v8, "."

    move/from16 v18, v4

    .end local v4    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .local v18, "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    move-object/from16 v20, v5

    .end local v5    # "entries\\1":Ljava/util/List;
    .local v20, "entries\\1":Ljava/util/List;
    const/16 v21, 0x2f

    if-eqz v12, :cond_d

    :try_start_1
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lorg/lighttouch/android/IpaPreflight$Entry;

    .line 228
    .local v12, "entry\\1":Lorg/lighttouch/android/IpaPreflight$Entry;
    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v22

    move-object/from16 v23, v22

    check-cast v23, Ljava/lang/CharSequence;

    const/4 v4, 0x1

    new-array v5, v4, [C

    aput-char v21, v5, v16

    const/16 v27, 0x6

    const/16 v28, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    move-object/from16 v24, v5

    invoke-static/range {v23 .. v28}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 229
    .local v4, "parts\\1":Ljava/util/List;
    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_b

    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v5

    move-object/from16 v23, v0

    move/from16 v2, v16

    const/4 v0, 0x2

    const/4 v1, 0x0

    .end local v0    # "it\\1":Ljava/io/RandomAccessFile;
    .local v23, "it\\1":Ljava/io/RandomAccessFile;
    invoke-static {v5, v9, v2, v0, v1}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_a

    invoke-interface {v4, v15}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    const/16 v1, 0x5c

    move-object/from16 v24, v6

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    .end local v6    # "names\\1":Ljava/util/HashSet;
    .local v24, "names\\1":Ljava/util/HashSet;
    invoke-static {v0, v1, v6, v2, v5}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_c

    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getFlags()I

    move-result v0

    const/16 v17, 0x1

    and-int/lit8 v0, v0, 0x1

    if-nez v0, :cond_c

    .line 231
    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getSymlink()Z

    move-result v0

    if-eqz v0, :cond_9

    .line 232
    const-wide/16 v5, 0x1000

    invoke-virtual {v10, v12, v5, v6}, Lorg/lighttouch/android/IpaPreflight$Zip;->read(Lorg/lighttouch/android/IpaPreflight$Entry;J)[B

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->decodeToString([B)Ljava/lang/String;

    move-result-object v0

    .line 233
    .local v0, "link\\1":Ljava/lang/String;
    const/4 v2, 0x1

    invoke-static {v4, v2}, Lkotlin/collections/CollectionsKt;->dropLast(Ljava/util/List;I)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/util/Collection;

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->toMutableList(Ljava/util/Collection;)Ljava/util/List;

    move-result-object v2

    .line 234
    .local v2, "resolved\\1":Ljava/util/List;
    move-object v5, v0

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-nez v5, :cond_2

    const/4 v5, 0x1

    goto :goto_3

    :cond_2
    const/4 v5, 0x0

    :goto_3
    if-nez v5, :cond_7

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v9, v1, v5, v6}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7

    move-object v9, v0

    check-cast v9, Ljava/lang/CharSequence;

    move-object/from16 v25, v0

    const/16 v0, 0x5c

    .end local v0    # "link\\1":Ljava/lang/String;
    .local v25, "link\\1":Ljava/lang/String;
    invoke-static {v9, v0, v1, v5, v6}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    move-object/from16 v0, v25

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0, v1, v1, v5, v6}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x3

    if-lt v0, v5, :cond_8

    invoke-interface {v4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    invoke-interface {v4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const/4 v0, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v13, v6, v0, v5}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    .line 236
    move-object/from16 v30, v25

    check-cast v30, Ljava/lang/CharSequence;

    const/4 v0, 0x1

    new-array v1, v0, [C

    const/16 v16, 0x0

    aput-char v21, v1, v16

    const/16 v34, 0x6

    const/16 v35, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    move-object/from16 v31, v1

    invoke-static/range {v30 .. v35}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .local v1, "component\\1":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v5

    sparse-switch v5, :sswitch_data_0

    :goto_5
    goto :goto_6

    :sswitch_0
    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_3

    goto :goto_5

    .line 237
    :cond_3
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    const/4 v6, 0x2

    if-le v5, v6, :cond_4

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->getLastIndex(Ljava/util/List;)I

    move-result v5

    invoke-interface {v2, v5}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    goto :goto_7

    :cond_4
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v5, "IPA \u5305\u542b\u6307\u5411\u5e94\u7528\u5916\u90e8\u7684\u7b26\u53f7\u94fe\u63a5\u3002"

    invoke-direct {v0, v5}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 236
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :sswitch_1
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_5

    :sswitch_2
    const-string v5, ""

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    goto :goto_5

    .line 238
    :cond_5
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_7

    .line 239
    :goto_6
    move-object v5, v2

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_7
    goto :goto_4

    .line 236
    .end local v1    # "component\\1":Ljava/lang/String;
    :cond_6
    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v4, v18

    move-object/from16 v5, v20

    move-object/from16 v0, v23

    move-object/from16 v6, v24

    goto/16 :goto_2

    .line 234
    .end local v25    # "link\\1":Ljava/lang/String;
    .restart local v0    # "link\\1":Ljava/lang/String;
    :cond_7
    move-object/from16 v25, v0

    .line 235
    .end local v0    # "link\\1":Ljava/lang/String;
    .restart local v25    # "link\\1":Ljava/lang/String;
    :cond_8
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v1, "IPA \u5305\u542b\u4e0d\u5b89\u5168\u7684\u7b26\u53f7\u94fe\u63a5\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 231
    .end local v2    # "resolved\\1":Ljava/util/List;
    .end local v25    # "link\\1":Ljava/lang/String;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_9
    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v4, v18

    move-object/from16 v5, v20

    move-object/from16 v0, v23

    move-object/from16 v6, v24

    goto/16 :goto_2

    .line 229
    .end local v24    # "names\\1":Ljava/util/HashSet;
    .restart local v6    # "names\\1":Ljava/util/HashSet;
    :cond_a
    move-object/from16 v24, v6

    .end local v6    # "names\\1":Ljava/util/HashSet;
    .restart local v24    # "names\\1":Ljava/util/HashSet;
    goto :goto_8

    .end local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v24    # "names\\1":Ljava/util/HashSet;
    .local v0, "it\\1":Ljava/io/RandomAccessFile;
    .restart local v6    # "names\\1":Ljava/util/HashSet;
    :cond_b
    move-object/from16 v23, v0

    move-object/from16 v24, v6

    .line 230
    .end local v0    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v6    # "names\\1":Ljava/util/HashSet;
    .restart local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .restart local v24    # "names\\1":Ljava/util/HashSet;
    :cond_c
    :goto_8
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v1, "IPA \u5305\u542b\u4e0d\u5b89\u5168\u3001\u91cd\u590d\u6216\u52a0\u5bc6\u7684 ZIP \u6210\u5458\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 243
    .end local v4    # "parts\\1":Ljava/util/List;
    .end local v12    # "entry\\1":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v24    # "names\\1":Ljava/util/HashSet;
    .restart local v0    # "it\\1":Ljava/io/RandomAccessFile;
    .restart local v6    # "names\\1":Ljava/util/HashSet;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_d
    move-object/from16 v23, v0

    move-object/from16 v24, v6

    .end local v0    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v6    # "names\\1":Ljava/util/HashSet;
    .restart local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .restart local v24    # "names\\1":Ljava/util/HashSet;
    move-object/from16 v0, v20

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\3":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 302
    .local v1, "$i$f$filter\\3\\243":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination\\4":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$filterTo\\4":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 303
    .local v5, "$i$f$filterTo\\4\\302":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_9
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_11

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\4":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/IpaPreflight$Entry;

    .local v12, "it\\5":Lorg/lighttouch/android/IpaPreflight$Entry;
    const/16 v25, 0x0

    .line 243
    .local v25, "$i$a$-filter-IpaPreflight$prepare$1$candidates$1\\5\\303\\1":I
    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v26

    move-object/from16 v30, v26

    check-cast v30, Ljava/lang/CharSequence;

    move-object/from16 v26, v0

    move/from16 v27, v1

    const/4 v0, 0x1

    .end local v0    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\3\\243":I
    .local v26, "$this$filter\\3":Ljava/lang/Iterable;
    .local v27, "$i$f$filter\\3\\243":I
    new-array v1, v0, [C

    const/16 v16, 0x0

    aput-char v21, v1, v16

    const/16 v34, 0x6

    const/16 v35, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    move-object/from16 v31, v1

    invoke-static/range {v30 .. v35}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .local v0, "p\\5":Ljava/util/List;
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    move-object/from16 v28, v4

    const/4 v4, 0x3

    .end local v4    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .local v28, "$this$filterTo\\4":Ljava/lang/Iterable;
    if-ne v1, v4, :cond_e

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    const/4 v4, 0x1

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    move/from16 v30, v5

    move-object/from16 v31, v6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    .end local v5    # "$i$f$filterTo\\4\\302":I
    .local v30, "$i$f$filterTo\\4\\302":I
    invoke-static {v1, v13, v6, v4, v5}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const-string v4, "Info.plist"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_f

    const/4 v0, 0x1

    goto :goto_a

    .end local v30    # "$i$f$filterTo\\4\\302":I
    .restart local v5    # "$i$f$filterTo\\4\\302":I
    :cond_e
    move/from16 v30, v5

    move-object/from16 v31, v6

    .end local v5    # "$i$f$filterTo\\4\\302":I
    .restart local v30    # "$i$f$filterTo\\4\\302":I
    :cond_f
    const/4 v0, 0x0

    .line 303
    .end local v0    # "p\\5":Ljava/util/List;
    .end local v12    # "it\\5":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v25    # "$i$a$-filter-IpaPreflight$prepare$1$candidates$1\\5\\303\\1":I
    :goto_a
    if-eqz v0, :cond_10

    invoke-interface {v2, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_10
    move-object/from16 v0, v26

    move/from16 v1, v27

    move-object/from16 v4, v28

    move/from16 v5, v30

    move-object/from16 v6, v31

    goto :goto_9

    .line 304
    .end local v11    # "element\\4":Ljava/lang/Object;
    .end local v26    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v27    # "$i$f$filter\\3\\243":I
    .end local v28    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .end local v30    # "$i$f$filterTo\\4\\302":I
    .local v0, "$this$filter\\3":Ljava/lang/Iterable;
    .restart local v1    # "$i$f$filter\\3\\243":I
    .restart local v4    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .restart local v5    # "$i$f$filterTo\\4\\302":I
    :cond_11
    move-object/from16 v26, v0

    move/from16 v27, v1

    move-object/from16 v28, v4

    move/from16 v30, v5

    .end local v0    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter\\3\\243":I
    .end local v2    # "destination\\4":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo\\4\\302":I
    .restart local v26    # "$this$filter\\3":Ljava/lang/Iterable;
    .restart local v27    # "$i$f$filter\\3\\243":I
    move-object v0, v2

    check-cast v0, Ljava/util/List;

    .line 302
    nop

    .line 243
    .end local v26    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v27    # "$i$f$filter\\3\\243":I
    nop

    .line 244
    .local v0, "candidates\\1":Ljava/util/List;
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x1

    if-ne v1, v4, :cond_3c

    .line 245
    sget-object v1, Lorg/lighttouch/android/IpaPreflight;->INSTANCE:Lorg/lighttouch/android/IpaPreflight;

    const/4 v6, 0x0

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/IpaPreflight$Entry;

    const-wide/32 v4, 0x100000

    invoke-virtual {v10, v2, v4, v5}, Lorg/lighttouch/android/IpaPreflight$Zip;->read(Lorg/lighttouch/android/IpaPreflight$Entry;J)[B

    move-result-object v2

    invoke-direct {v1, v2}, Lorg/lighttouch/android/IpaPreflight;->plist([B)Ljava/util/Map;

    move-result-object v1

    .line 246
    .local v1, "info\\1":Ljava/util/Map;
    const-string v2, "CFBundleIdentifier"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    instance-of v4, v2, Ljava/lang/String;

    if-eqz v4, :cond_12

    check-cast v2, Ljava/lang/String;

    goto :goto_b

    :cond_12
    const/4 v2, 0x0

    :goto_b
    move-object/from16 v31, v2

    .line 247
    .local v31, "bundle\\1":Ljava/lang/String;
    const-string v2, "CFBundleExecutable"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    instance-of v4, v2, Ljava/lang/String;

    if-eqz v4, :cond_13

    check-cast v2, Ljava/lang/String;

    goto :goto_c

    :cond_13
    const/4 v2, 0x0

    .line 248
    .local v2, "executableName\\1":Ljava/lang/String;
    :goto_c
    move-object/from16 v4, v31

    check-cast v4, Ljava/lang/CharSequence;

    if-eqz v4, :cond_15

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_14

    goto :goto_d

    :cond_14
    const/4 v4, 0x0

    goto :goto_e

    :cond_15
    :goto_d
    const/4 v4, 0x1

    :goto_e
    if-nez v4, :cond_3b

    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    if-eqz v4, :cond_17

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_16

    goto :goto_f

    :cond_16
    const/4 v4, 0x0

    goto :goto_10

    :cond_17
    :goto_f
    const/4 v4, 0x1

    :goto_10
    if-nez v4, :cond_3b

    move-object v4, v2

    check-cast v4, Ljava/lang/CharSequence;

    move/from16 v5, v21

    const/4 v6, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v4, v5, v12, v6, v11}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3b

    invoke-static {v2, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3b

    invoke-static {v2, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3b

    .line 250
    move-object/from16 v4, v20

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$firstOrNull\\6":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 305
    .local v5, "$i$f$firstOrNull\\6\\250":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_11
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_19

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\6":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/IpaPreflight$Entry;

    .local v12, "it\\7":Lorg/lighttouch/android/IpaPreflight$Entry;
    const/4 v13, 0x0

    .line 250
    .local v13, "$i$a$-firstOrNull-IpaPreflight$prepare$1$executable$1\\7\\305\\1":I
    invoke-virtual {v12}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x0

    invoke-interface {v0, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v25

    check-cast v25, Lorg/lighttouch/android/IpaPreflight$Entry;

    invoke-virtual/range {v25 .. v25}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v15

    move-object/from16 v25, v0

    move-object/from16 v21, v4

    move/from16 v26, v5

    const/16 v0, 0x2f

    const/4 v4, 0x2

    const/4 v5, 0x0

    .end local v0    # "candidates\\1":Ljava/util/List;
    .end local v4    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .end local v5    # "$i$f$firstOrNull\\6\\250":I
    .local v21, "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .local v25, "candidates\\1":Ljava/util/List;
    .local v26, "$i$f$firstOrNull\\6\\250":I
    invoke-static {v15, v0, v5, v4, v5}, Lkotlin/text/StringsKt;->substringBeforeLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v15

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v14, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .line 305
    .end local v12    # "it\\7":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v13    # "$i$a$-firstOrNull-IpaPreflight$prepare$1$executable$1\\7\\305\\1":I
    if-eqz v4, :cond_18

    goto :goto_12

    :cond_18
    move-object/from16 v4, v21

    move-object/from16 v0, v25

    move/from16 v5, v26

    goto :goto_11

    .line 306
    .end local v11    # "element\\6":Ljava/lang/Object;
    .end local v21    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .end local v25    # "candidates\\1":Ljava/util/List;
    .end local v26    # "$i$f$firstOrNull\\6\\250":I
    .restart local v0    # "candidates\\1":Ljava/util/List;
    .restart local v4    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .restart local v5    # "$i$f$firstOrNull\\6\\250":I
    :cond_19
    move-object/from16 v25, v0

    move-object/from16 v21, v4

    move/from16 v26, v5

    .end local v0    # "candidates\\1":Ljava/util/List;
    .end local v4    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .end local v5    # "$i$f$firstOrNull\\6\\250":I
    .restart local v21    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .restart local v25    # "candidates\\1":Ljava/util/List;
    .restart local v26    # "$i$f$firstOrNull\\6\\250":I
    const/4 v11, 0x0

    .line 250
    .end local v21    # "$this$firstOrNull\\6":Ljava/lang/Iterable;
    .end local v26    # "$i$f$firstOrNull\\6\\250":I
    :goto_12
    check-cast v11, Lorg/lighttouch/android/IpaPreflight$Entry;

    if-eqz v11, :cond_3a

    .line 252
    .local v11, "executable\\1":Lorg/lighttouch/android/IpaPreflight$Entry;
    invoke-virtual {v11}, Lorg/lighttouch/android/IpaPreflight$Entry;->getSymlink()Z

    move-result v0

    if-nez v0, :cond_39

    .line 253
    invoke-virtual {v7}, Lorg/lighttouch/android/StoreTarget;->getArch()Ljava/lang/String;

    move-result-object v0

    const-string v4, "armv6"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    if-eqz v0, :cond_1a

    const/4 v0, 0x2

    new-array v5, v0, [Ljava/lang/Integer;

    const/16 v16, 0x0

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v5, v16

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/16 v17, 0x1

    aput-object v0, v5, v17

    invoke-static {v5}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x3

    const/16 v29, 0x2

    goto :goto_13

    :cond_1a
    const/4 v5, 0x3

    new-array v0, v5, [Ljava/lang/Integer;

    const/16 v16, 0x0

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v0, v16

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/16 v17, 0x1

    aput-object v4, v0, v17

    const/16 v4, 0x9

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/16 v29, 0x2

    aput-object v4, v0, v29

    invoke-static {v0}, Lkotlin/collections/SetsKt;->setOf([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    .line 254
    .local v0, "supported\\1":Ljava/util/Set;
    :goto_13
    sget-object v4, Lorg/lighttouch/android/IpaPreflight;->INSTANCE:Lorg/lighttouch/android/IpaPreflight;

    const-wide/32 v12, 0x10000000

    invoke-virtual {v10, v11, v12, v13}, Lorg/lighttouch/android/IpaPreflight$Zip;->read(Lorg/lighttouch/android/IpaPreflight$Entry;J)[B

    move-result-object v6

    invoke-direct {v4, v6}, Lorg/lighttouch/android/IpaPreflight;->armSlices([B)Ljava/util/List;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$filter\\8":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 307
    .local v6, "$i$f$filter\\8\\254":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\9":Ljava/util/Collection;
    move-object v12, v4

    .local v12, "$this$filterTo\\9":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 308
    .local v13, "$i$f$filterTo\\9\\307":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_14
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_1c

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .local v15, "element\\9":Ljava/lang/Object;
    move-object/from16 v19, v15

    check-cast v19, Lkotlin/Pair;

    .local v19, "it\\10":Lkotlin/Pair;
    const/16 v21, 0x0

    .line 254
    .local v21, "$i$a$-filter-IpaPreflight$prepare$1$matching$1\\10\\308\\1":I
    invoke-virtual/range {v19 .. v19}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v5

    invoke-interface {v0, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    .line 308
    .end local v19    # "it\\10":Lkotlin/Pair;
    .end local v21    # "$i$a$-filter-IpaPreflight$prepare$1$matching$1\\10\\308\\1":I
    if-eqz v5, :cond_1b

    invoke-interface {v9, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_1b
    const/4 v5, 0x3

    goto :goto_14

    .line 309
    .end local v15    # "element\\9":Ljava/lang/Object;
    :cond_1c
    nop

    .end local v9    # "destination\\9":Ljava/util/Collection;
    .end local v12    # "$this$filterTo\\9":Ljava/lang/Iterable;
    .end local v13    # "$i$f$filterTo\\9\\307":I
    move-object v5, v9

    check-cast v5, Ljava/util/List;

    .line 307
    nop

    .line 254
    .end local v4    # "$this$filter\\8":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filter\\8\\254":I
    nop

    .line 255
    .local v5, "matching\\1":Ljava/util/List;
    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_38

    .line 257
    move-object v4, v5

    check-cast v4, Ljava/lang/Iterable;

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_37

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lkotlin/Pair;

    .line 301
    .local v6, "it\\11":Lkotlin/Pair;
    const/4 v9, 0x0

    .line 257
    .local v9, "$i$a$-maxOf-IpaPreflight$prepare$1$best$1\\11\\257\\1":I
    invoke-virtual {v6}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    move-result v12

    .end local v6    # "it\\11":Lkotlin/Pair;
    .end local v9    # "$i$a$-maxOf-IpaPreflight$prepare$1$best$1\\11\\257\\1":I
    :cond_1d
    :goto_15
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1e

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lkotlin/Pair;

    .line 301
    .local v6, "it\\12":Lkotlin/Pair;
    const/4 v9, 0x0

    .line 257
    .local v9, "$i$a$-maxOf-IpaPreflight$prepare$1$best$1\\12\\257\\1":I
    invoke-virtual {v6}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Number;

    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    move-result v13

    .end local v6    # "it\\12":Lkotlin/Pair;
    .end local v9    # "$i$a$-maxOf-IpaPreflight$prepare$1$best$1\\12\\257\\1":I
    if-ge v12, v13, :cond_1d

    move v12, v13

    goto :goto_15

    .line 258
    .local v12, "best\\1":I
    :cond_1e
    sget-object v4, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v7}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_36

    .line 259
    .local v4, "guest\\1":Ljava/util/List;
    move-object v6, v5

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$filter\\13":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 310
    .local v9, "$i$f$filter\\13\\259":I
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    check-cast v13, Ljava/util/Collection;

    .local v13, "destination\\14":Ljava/util/Collection;
    move-object v14, v6

    .local v14, "$this$filterTo\\14":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 311
    .local v15, "$i$f$filterTo\\14\\310":I
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v19

    :goto_16
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_21

    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v27, v21

    .local v27, "element\\14":Ljava/lang/Object;
    move-object/from16 v21, v27

    check-cast v21, Lkotlin/Pair;

    .local v21, "it\\15":Lkotlin/Pair;
    const/16 v28, 0x0

    .line 259
    .local v28, "$i$a$-filter-IpaPreflight$prepare$1$2\\15\\311\\1":I
    invoke-virtual/range {v21 .. v21}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v30

    check-cast v30, Ljava/lang/Number;

    move-object/from16 v37, v0

    .end local v0    # "supported\\1":Ljava/util/Set;
    .local v37, "supported\\1":Ljava/util/Set;
    invoke-virtual/range {v30 .. v30}, Ljava/lang/Number;->intValue()I

    move-result v0

    if-ne v0, v12, :cond_1f

    const/4 v0, 0x1

    goto :goto_17

    :cond_1f
    const/4 v0, 0x0

    .line 311
    .end local v21    # "it\\15":Lkotlin/Pair;
    .end local v28    # "$i$a$-filter-IpaPreflight$prepare$1$2\\15\\311\\1":I
    :goto_17
    if-eqz v0, :cond_20

    move-object/from16 v0, v27

    .end local v27    # "element\\14":Ljava/lang/Object;
    .local v0, "element\\14":Ljava/lang/Object;
    invoke-interface {v13, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_18

    .end local v0    # "element\\14":Ljava/lang/Object;
    .restart local v27    # "element\\14":Ljava/lang/Object;
    :cond_20
    move-object/from16 v0, v27

    .end local v27    # "element\\14":Ljava/lang/Object;
    .restart local v0    # "element\\14":Ljava/lang/Object;
    :goto_18
    move-object/from16 v0, v37

    goto :goto_16

    .line 312
    .end local v37    # "supported\\1":Ljava/util/Set;
    .local v0, "supported\\1":Ljava/util/Set;
    :cond_21
    move-object/from16 v37, v0

    .end local v0    # "supported\\1":Ljava/util/Set;
    .end local v13    # "destination\\14":Ljava/util/Collection;
    .end local v14    # "$this$filterTo\\14":Ljava/lang/Iterable;
    .end local v15    # "$i$f$filterTo\\14\\310":I
    .restart local v37    # "supported\\1":Ljava/util/Set;
    move-object v0, v13

    check-cast v0, Ljava/util/List;

    .line 310
    nop

    .end local v6    # "$this$filter\\13":Ljava/lang/Iterable;
    .end local v9    # "$i$f$filter\\13\\259":I
    check-cast v0, Ljava/lang/Iterable;

    .line 259
    nop

    .local v0, "$this$mapNotNull\\16":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 313
    .local v6, "$i$f$mapNotNull\\16\\259":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\17":Ljava/util/Collection;
    move-object v13, v0

    .local v13, "$this$mapNotNullTo\\17":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 321
    .local v14, "$i$f$mapNotNullTo\\17\\313":I
    move-object v15, v13

    .local v15, "$this$forEach\\18":Ljava/lang/Iterable;
    const/16 v19, 0x0

    .line 322
    .local v19, "$i$f$forEach\\18\\321":I
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v21

    :goto_19
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->hasNext()Z

    move-result v27

    if-eqz v27, :cond_23

    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v27

    .local v27, "element\\18":Ljava/lang/Object;
    move-object/from16 v28, v27

    .local v28, "element\\19":Ljava/lang/Object;
    const/16 v30, 0x0

    .line 321
    .local v30, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\19\\322\\17":I
    move-object/from16 v32, v28

    check-cast v32, Lkotlin/Pair;

    .local v32, "it\\20":Lkotlin/Pair;
    const/16 v33, 0x0

    .line 259
    .local v33, "$i$a$-mapNotNull-IpaPreflight$prepare$1$3\\20\\321\\1":I
    invoke-virtual/range {v32 .. v32}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v34

    check-cast v34, Ljava/util/List;

    .line 321
    .end local v32    # "it\\20":Lkotlin/Pair;
    .end local v33    # "$i$a$-mapNotNull-IpaPreflight$prepare$1$3\\20\\321\\1":I
    if-eqz v34, :cond_22

    move-object/from16 v32, v34

    .line 323
    .local v32, "it\\19":Ljava/lang/Object;
    const/16 v33, 0x0

    .line 321
    .local v33, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\21\\323\\19":I
    move-object/from16 v34, v0

    move-object/from16 v0, v32

    .end local v32    # "it\\19":Ljava/lang/Object;
    .local v0, "it\\19":Ljava/lang/Object;
    .local v34, "$this$mapNotNull\\16":Ljava/lang/Iterable;
    invoke-interface {v9, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v0    # "it\\19":Ljava/lang/Object;
    .end local v33    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\21\\323\\19":I
    goto :goto_1a

    .end local v34    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    .local v0, "$this$mapNotNull\\16":Ljava/lang/Iterable;
    :cond_22
    move-object/from16 v34, v0

    .line 322
    .end local v0    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    .end local v28    # "element\\19":Ljava/lang/Object;
    .end local v30    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\19\\322\\17":I
    .restart local v34    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    :goto_1a
    move-object/from16 v0, v34

    .end local v27    # "element\\18":Ljava/lang/Object;
    goto :goto_19

    .line 324
    .end local v34    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    .restart local v0    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    :cond_23
    move-object/from16 v34, v0

    .line 325
    .end local v0    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    .end local v15    # "$this$forEach\\18":Ljava/lang/Iterable;
    .end local v19    # "$i$f$forEach\\18\\321":I
    .restart local v34    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    nop

    .end local v9    # "destination\\17":Ljava/util/Collection;
    .end local v13    # "$this$mapNotNullTo\\17":Ljava/lang/Iterable;
    .end local v14    # "$i$f$mapNotNullTo\\17\\313":I
    move-object v0, v9

    check-cast v0, Ljava/util/List;

    .line 313
    nop

    .end local v6    # "$i$f$mapNotNull\\16\\259":I
    .end local v34    # "$this$mapNotNull\\16":Ljava/lang/Iterable;
    check-cast v0, Ljava/lang/Iterable;

    .line 259
    nop

    .local v0, "$this$forEach\\22":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 326
    .local v6, "$i$f$forEach\\22\\259":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1b
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_25

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\22":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Ljava/util/List;

    .local v14, "it\\23":Ljava/util/List;
    const/4 v15, 0x0

    .line 260
    .local v15, "$i$a$-forEach-IpaPreflight$prepare$1$4\\23\\326\\1":I
    move-object/from16 v19, v0

    .end local v0    # "$this$forEach\\22":Ljava/lang/Iterable;
    .local v19, "$this$forEach\\22":Ljava/lang/Iterable;
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v0, v14, v4}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v0

    if-nez v0, :cond_24

    .line 261
    nop

    .line 326
    .end local v14    # "it\\23":Ljava/util/List;
    .end local v15    # "$i$a$-forEach-IpaPreflight$prepare$1$4\\23\\326\\1":I
    move-object/from16 v0, v19

    .end local v13    # "element\\22":Ljava/lang/Object;
    goto :goto_1b

    .line 260
    .restart local v13    # "element\\22":Ljava/lang/Object;
    .restart local v14    # "it\\23":Ljava/util/List;
    .restart local v15    # "$i$a$-forEach-IpaPreflight$prepare$1$4\\23\\326\\1":I
    :cond_24
    new-instance v0, Lorg/lighttouch/android/IpaError;

    move-object/from16 v38, v14

    check-cast v38, Ljava/lang/Iterable;

    move-object/from16 v39, v8

    check-cast v39, Ljava/lang/CharSequence;

    const/16 v45, 0x3e

    const/16 v46, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    invoke-static/range {v38 .. v46}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    move-object/from16 v21, v2

    .end local v2    # "executableName\\1":Ljava/lang/String;
    .local v21, "executableName\\1":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v27, v5

    .end local v5    # "matching\\1":Ljava/util/List;
    .local v27, "matching\\1":Ljava/util/List;
    const-string v5, "The app executable requires iOS "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 327
    .end local v13    # "element\\22":Ljava/lang/Object;
    .end local v14    # "it\\23":Ljava/util/List;
    .end local v15    # "$i$a$-forEach-IpaPreflight$prepare$1$4\\23\\326\\1":I
    .end local v19    # "$this$forEach\\22":Ljava/lang/Iterable;
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v27    # "matching\\1":Ljava/util/List;
    .restart local v0    # "$this$forEach\\22":Ljava/lang/Iterable;
    .restart local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v5    # "matching\\1":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_25
    move-object/from16 v19, v0

    move-object/from16 v21, v2

    move-object/from16 v27, v5

    .line 262
    .end local v0    # "$this$forEach\\22":Ljava/lang/Iterable;
    .end local v2    # "executableName\\1":Ljava/lang/String;
    .end local v5    # "matching\\1":Ljava/util/List;
    .end local v6    # "$i$f$forEach\\22\\259":I
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    .restart local v27    # "matching\\1":Ljava/util/List;
    const-string v0, "MinimumOSVersion"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Ljava/lang/String;

    if-eqz v2, :cond_26

    check-cast v0, Ljava/lang/String;

    move-object/from16 v34, v0

    goto :goto_1c

    :cond_26
    const/16 v34, 0x0

    :goto_1c
    move-object/from16 v0, v34

    .line 263
    .local v0, "minimum\\1":Ljava/lang/String;
    if-eqz v0, :cond_29

    .line 264
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2, v0}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    if-eqz v2, :cond_28

    .line 265
    .local v2, "need\\1":Ljava/util/List;
    sget-object v5, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v5, v2, v4}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v5

    if-nez v5, :cond_27

    goto :goto_1d

    :cond_27
    new-instance v5, Lorg/lighttouch/android/IpaError;

    invoke-virtual {v7}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v6

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "This app requires iOS "

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v13, "; the guest runs "

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v5

    .line 264
    .end local v2    # "need\\1":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_28
    new-instance v2, Lorg/lighttouch/android/IpaError;

    const-string v5, "\u65e0\u6cd5\u786e\u8ba4\u6700\u4f4e iOS \u7248\u672c\u8981\u6c42\u3002"

    invoke-direct {v2, v5}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v2

    .line 267
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_29
    :goto_1d
    const-string v2, "UIDeviceFamily"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    instance-of v5, v2, Ljava/util/List;

    if-eqz v5, :cond_2a

    check-cast v2, Ljava/util/List;

    goto :goto_1e

    :cond_2a
    const/4 v2, 0x0

    :goto_1e
    if-eqz v2, :cond_30

    .local v2, "families\\24":Ljava/util/List;
    const/4 v5, 0x0

    .line 268
    .local v5, "$i$a$-let-IpaPreflight$prepare$1$5\\24\\267\\1":I
    move-object v6, v2

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_2f

    move-object v6, v2

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$none\\25":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 328
    .local v8, "$i$f$none\\25\\268":I
    instance-of v9, v6, Ljava/util/Collection;

    if-eqz v9, :cond_2b

    move-object v9, v6

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_2b

    move-object/from16 v34, v0

    move-object/from16 v19, v2

    const/4 v0, 0x1

    goto :goto_20

    .line 329
    :cond_2b
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1f
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_2d

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\25":Ljava/lang/Object;
    move-object v14, v13

    .local v14, "it\\26":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 268
    .local v15, "$i$a$-none-IpaPreflight$prepare$1$5$1\\26\\329\\24":I
    move-object/from16 v34, v0

    .end local v0    # "minimum\\1":Ljava/lang/String;
    .local v34, "minimum\\1":Ljava/lang/String;
    invoke-static {v14}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v19, v2

    .end local v2    # "families\\24":Ljava/util/List;
    .local v19, "families\\24":Ljava/util/List;
    invoke-virtual {v7}, Lorg/lighttouch/android/StoreTarget;->getFamily()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    .line 329
    .end local v14    # "it\\26":Ljava/lang/Object;
    .end local v15    # "$i$a$-none-IpaPreflight$prepare$1$5$1\\26\\329\\24":I
    if-eqz v0, :cond_2c

    const/4 v0, 0x0

    goto :goto_20

    :cond_2c
    move-object/from16 v2, v19

    move-object/from16 v0, v34

    goto :goto_1f

    .line 330
    .end local v13    # "element\\25":Ljava/lang/Object;
    .end local v19    # "families\\24":Ljava/util/List;
    .end local v34    # "minimum\\1":Ljava/lang/String;
    .restart local v0    # "minimum\\1":Ljava/lang/String;
    .restart local v2    # "families\\24":Ljava/util/List;
    :cond_2d
    move-object/from16 v34, v0

    move-object/from16 v19, v2

    .end local v0    # "minimum\\1":Ljava/lang/String;
    .end local v2    # "families\\24":Ljava/util/List;
    .restart local v19    # "families\\24":Ljava/util/List;
    .restart local v34    # "minimum\\1":Ljava/lang/String;
    const/4 v0, 0x1

    .line 268
    .end local v6    # "$this$none\\25":Ljava/lang/Iterable;
    .end local v8    # "$i$f$none\\25\\268":I
    :goto_20
    if-nez v0, :cond_2e

    goto :goto_21

    :cond_2e
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v2, "\u6b64\u5e94\u7528\u5e76\u975e\u9762\u5411\u5ba2\u6237\u673a\u7684\u8bbe\u5907\u7c7b\u578b\u3002"

    invoke-direct {v0, v2}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .end local v19    # "families\\24":Ljava/util/List;
    .end local v34    # "minimum\\1":Ljava/lang/String;
    .restart local v0    # "minimum\\1":Ljava/lang/String;
    .restart local v2    # "families\\24":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_2f
    move-object/from16 v34, v0

    move-object/from16 v19, v2

    .line 269
    .end local v0    # "minimum\\1":Ljava/lang/String;
    .end local v2    # "families\\24":Ljava/util/List;
    .restart local v19    # "families\\24":Ljava/util/List;
    .restart local v34    # "minimum\\1":Ljava/lang/String;
    :goto_21
    nop

    .end local v5    # "$i$a$-let-IpaPreflight$prepare$1$5\\24\\267\\1":I
    .end local v19    # "families\\24":Ljava/util/List;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 267
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_22

    .end local v34    # "minimum\\1":Ljava/lang/String;
    .restart local v0    # "minimum\\1":Ljava/lang/String;
    :cond_30
    move-object/from16 v34, v0

    .line 270
    .end local v0    # "minimum\\1":Ljava/lang/String;
    .restart local v34    # "minimum\\1":Ljava/lang/String;
    :goto_22
    new-instance v30, Lorg/lighttouch/android/IpaInfo;

    const-string v0, "CFBundleDisplayName"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Ljava/lang/String;

    if-eqz v2, :cond_31

    check-cast v0, Ljava/lang/String;

    goto :goto_23

    :cond_31
    const/4 v0, 0x0

    :goto_23
    if-nez v0, :cond_33

    const-string v0, "CFBundleName"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Ljava/lang/String;

    if-eqz v2, :cond_32

    check-cast v0, Ljava/lang/String;

    goto :goto_24

    :cond_32
    const/4 v0, 0x0

    :goto_24
    if-nez v0, :cond_33

    move-object/from16 v32, v31

    goto :goto_25

    :cond_33
    move-object/from16 v32, v0

    .line 271
    :goto_25
    const-string v0, "CFBundleVersion"

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Ljava/lang/String;

    if-eqz v2, :cond_34

    check-cast v0, Ljava/lang/String;

    move-object/from16 v33, v0

    goto :goto_26

    :cond_34
    const/16 v33, 0x0

    :goto_26
    invoke-virtual/range {p1 .. p1}, Ljava/io/File;->length()J

    move-result-wide v35

    .line 270
    invoke-direct/range {v30 .. v36}, Lorg/lighttouch/android/IpaInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    move-object/from16 v0, v30

    .line 271
    nop

    .line 270
    invoke-static {v0, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 271
    nop

    .line 223
    .end local v1    # "info\\1":Ljava/util/Map;
    .end local v4    # "guest\\1":Ljava/util/List;
    .end local v11    # "executable\\1":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v12    # "best\\1":I
    .end local v18    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .end local v20    # "entries\\1":Ljava/util/List;
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v24    # "names\\1":Ljava/util/HashSet;
    .end local v25    # "candidates\\1":Ljava/util/List;
    .end local v27    # "matching\\1":Ljava/util/List;
    .end local v31    # "bundle\\1":Ljava/lang/String;
    .end local v34    # "minimum\\1":Ljava/lang/String;
    .end local v37    # "supported\\1":Ljava/util/Set;
    const/4 v5, 0x0

    invoke-static {v3, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v1

    move-object v8, v1

    check-cast v8, Lorg/lighttouch/android/IpaInfo;

    .local v8, "info":Lorg/lighttouch/android/IpaInfo;
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lorg/lighttouch/android/IpaPreflight$Entry;

    .line 273
    .local v9, "executable":Lorg/lighttouch/android/IpaPreflight$Entry;
    move-object/from16 v22, v5

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v11, v22

    const/4 v0, 0x3

    invoke-static/range {v1 .. v6}, Lkotlin/io/FilesKt;->copyTo$default(Ljava/io/File;Ljava/io/File;ZIILjava/lang/Object;)Ljava/io/File;

    .line 274
    invoke-virtual {v9}, Lorg/lighttouch/android/IpaPreflight$Entry;->getMode()I

    move-result v1

    and-int/lit8 v1, v1, 0x49

    if-nez v1, :cond_35

    new-instance v1, Ljava/io/RandomAccessFile;

    const-string v3, "rw"

    invoke-direct {v1, v2, v3}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    check-cast v1, Ljava/io/Closeable;

    :try_start_2
    move-object v3, v1

    check-cast v3, Ljava/io/RandomAccessFile;

    .local v3, "out\\27":Ljava/io/RandomAccessFile;
    const/4 v4, 0x0

    .line 276
    .local v4, "$i$a$-use-IpaPreflight$prepare$2\\27\\274\\0":I
    invoke-virtual {v9}, Lorg/lighttouch/android/IpaPreflight$Entry;->getCentralOffset()J

    move-result-wide v5

    const/4 v12, 0x5

    int-to-long v12, v12

    add-long/2addr v5, v12

    invoke-virtual {v3, v5, v6}, Ljava/io/RandomAccessFile;->seek(J)V

    invoke-virtual {v3, v0}, Ljava/io/RandomAccessFile;->write(I)V

    .line 277
    invoke-virtual {v9}, Lorg/lighttouch/android/IpaPreflight$Entry;->getExternalAttr()J

    move-result-wide v5

    const-wide/32 v12, 0xffff

    and-long/2addr v5, v12

    const-wide v12, 0x81ed0000L

    or-long/2addr v5, v12

    long-to-int v5, v5

    .line 278
    .local v5, "attr\\27":I
    invoke-virtual {v9}, Lorg/lighttouch/android/IpaPreflight$Entry;->getCentralOffset()J

    move-result-wide v12

    const/16 v6, 0x26

    int-to-long v14, v6

    add-long/2addr v12, v14

    invoke-virtual {v3, v12, v13}, Ljava/io/RandomAccessFile;->seek(J)V

    .line 279
    int-to-byte v6, v5

    ushr-int/lit8 v12, v5, 0x8

    int-to-byte v12, v12

    ushr-int/lit8 v13, v5, 0x10

    int-to-byte v13, v13

    ushr-int/lit8 v14, v5, 0x18

    int-to-byte v14, v14

    const/4 v15, 0x4

    new-array v15, v15, [B

    const/16 v16, 0x0

    aput-byte v6, v15, v16

    const/16 v17, 0x1

    aput-byte v12, v15, v17

    aput-byte v13, v15, v29

    aput-byte v14, v15, v0

    invoke-virtual {v3, v15}, Ljava/io/RandomAccessFile;->write([B)V

    .line 280
    invoke-virtual {v3}, Ljava/io/RandomAccessFile;->getFD()Ljava/io/FileDescriptor;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/FileDescriptor;->sync()V

    .line 281
    nop

    .end local v3    # "out\\27":Ljava/io/RandomAccessFile;
    .end local v4    # "$i$a$-use-IpaPreflight$prepare$2\\27\\274\\0":I
    .end local v5    # "attr\\27":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 274
    invoke-static {v1, v11}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_27

    :catchall_0
    move-exception v0

    move-object v3, v0

    .end local v8    # "info":Lorg/lighttouch/android/IpaInfo;
    .end local v9    # "executable":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :try_start_3
    throw v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .restart local v8    # "info":Lorg/lighttouch/android/IpaInfo;
    .restart local v9    # "executable":Lorg/lighttouch/android/IpaPreflight$Entry;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :catchall_1
    move-exception v0

    invoke-static {v1, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 282
    :cond_35
    :goto_27
    return-object v8

    .line 258
    .end local v8    # "info":Lorg/lighttouch/android/IpaInfo;
    .end local v9    # "executable":Lorg/lighttouch/android/IpaPreflight$Entry;
    .local v0, "supported\\1":Ljava/util/Set;
    .restart local v1    # "info\\1":Ljava/util/Map;
    .local v2, "executableName\\1":Ljava/lang/String;
    .local v5, "matching\\1":Ljava/util/List;
    .restart local v11    # "executable\\1":Lorg/lighttouch/android/IpaPreflight$Entry;
    .restart local v12    # "best\\1":I
    .restart local v18    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .restart local v20    # "entries\\1":Ljava/util/List;
    .restart local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .restart local v24    # "names\\1":Ljava/util/HashSet;
    .restart local v25    # "candidates\\1":Ljava/util/List;
    .restart local v31    # "bundle\\1":Ljava/lang/String;
    :cond_36
    move-object/from16 v37, v0

    move-object/from16 v21, v2

    move-object/from16 v27, v5

    move-object/from16 v2, p2

    .end local v0    # "supported\\1":Ljava/util/Set;
    .end local v2    # "executableName\\1":Ljava/lang/String;
    .end local v5    # "matching\\1":Ljava/util/List;
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    .restart local v27    # "matching\\1":Ljava/util/List;
    .restart local v37    # "supported\\1":Ljava/util/Set;
    :try_start_4
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v4, "\u5ba2\u6237\u673a iOS \u7248\u672c\u65e0\u6548\u3002"

    invoke-direct {v0, v4}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 257
    .end local v12    # "best\\1":I
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v27    # "matching\\1":Ljava/util/List;
    .end local v37    # "supported\\1":Ljava/util/Set;
    .restart local v0    # "supported\\1":Ljava/util/Set;
    .restart local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v5    # "matching\\1":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_37
    move-object/from16 v37, v0

    move-object/from16 v21, v2

    move-object/from16 v27, v5

    move-object/from16 v2, p2

    .end local v0    # "supported\\1":Ljava/util/Set;
    .end local v2    # "executableName\\1":Ljava/lang/String;
    .end local v5    # "matching\\1":Ljava/util/List;
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    .restart local v27    # "matching\\1":Ljava/util/List;
    .restart local v37    # "supported\\1":Ljava/util/Set;
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 255
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v27    # "matching\\1":Ljava/util/List;
    .end local v37    # "supported\\1":Ljava/util/Set;
    .restart local v0    # "supported\\1":Ljava/util/Set;
    .restart local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v5    # "matching\\1":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_38
    move-object/from16 v37, v0

    move-object/from16 v21, v2

    move-object/from16 v27, v5

    move-object/from16 v2, p2

    .end local v0    # "supported\\1":Ljava/util/Set;
    .end local v2    # "executableName\\1":Ljava/lang/String;
    .end local v5    # "matching\\1":Ljava/util/List;
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    .restart local v27    # "matching\\1":Ljava/util/List;
    .restart local v37    # "supported\\1":Ljava/util/Set;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v4, "\u6b64\u5e94\u7528\u9700\u8981\u6bd4\u5ba2\u6237\u673a\u66f4\u65b0\u7684\u5904\u7406\u5668\u3002"

    invoke-direct {v0, v4}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 252
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v27    # "matching\\1":Ljava/util/List;
    .end local v37    # "supported\\1":Ljava/util/Set;
    .restart local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_39
    move-object/from16 v21, v2

    move-object/from16 v2, p2

    .end local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v4, "\u5e94\u7528\u53ef\u6267\u884c\u6587\u4ef6\u4e0d\u53d7\u652f\u6301\u3002"

    invoke-direct {v0, v4}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 251
    .end local v11    # "executable\\1":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .restart local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_3a
    move-object/from16 v21, v2

    move-object/from16 v2, p2

    .end local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v4, "\u5e94\u7528\u7684\u53ef\u6267\u884c\u6587\u4ef6\u7f3a\u5931\u3002"

    invoke-direct {v0, v4}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 248
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v25    # "candidates\\1":Ljava/util/List;
    .local v0, "candidates\\1":Ljava/util/List;
    .restart local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_3b
    move-object/from16 v25, v0

    move-object/from16 v21, v2

    move-object/from16 v2, p2

    .line 249
    .end local v0    # "candidates\\1":Ljava/util/List;
    .end local v2    # "executableName\\1":Ljava/lang/String;
    .restart local v21    # "executableName\\1":Ljava/lang/String;
    .restart local v25    # "candidates\\1":Ljava/util/List;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v4, "\u5e94\u7528\u7684 bundle \u6216\u53ef\u6267\u884c\u6587\u4ef6\u5143\u6570\u636e\u65e0\u6548\u3002"

    invoke-direct {v0, v4}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 244
    .end local v1    # "info\\1":Ljava/util/Map;
    .end local v21    # "executableName\\1":Ljava/lang/String;
    .end local v25    # "candidates\\1":Ljava/util/List;
    .end local v31    # "bundle\\1":Ljava/lang/String;
    .restart local v0    # "candidates\\1":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :cond_3c
    move-object/from16 v2, p2

    move-object/from16 v25, v0

    .end local v0    # "candidates\\1":Ljava/util/List;
    .restart local v25    # "candidates\\1":Ljava/util/List;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v1, "\u8bf7\u9009\u62e9\u53ea\u5305\u542b\u4e00\u4e2a Payload \u5e94\u7528\u548c Info.plist \u7684 IPA\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0

    .line 223
    .end local v18    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .end local v20    # "entries\\1":Ljava/util/List;
    .end local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v24    # "names\\1":Ljava/util/HashSet;
    .end local v25    # "candidates\\1":Ljava/util/List;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :catchall_2
    move-exception v0

    move-object/from16 v2, p2

    goto :goto_28

    .line 225
    .local v0, "it\\1":Ljava/io/RandomAccessFile;
    .local v4, "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .local v5, "entries\\1":Ljava/util/List;
    :cond_3d
    move-object/from16 v23, v0

    move/from16 v18, v4

    move-object/from16 v20, v5

    .end local v0    # "it\\1":Ljava/io/RandomAccessFile;
    .end local v4    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .end local v5    # "entries\\1":Ljava/util/List;
    .restart local v18    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .restart local v20    # "entries\\1":Ljava/util/List;
    .restart local v23    # "it\\1":Ljava/io/RandomAccessFile;
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v1, "\u89e3\u5305\u540e\u7684 IPA \u8d85\u51fa\u652f\u6301\u7684\u5927\u5c0f\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 223
    .end local v18    # "$i$a$-use-IpaPreflight$prepare$1\\1\\223\\0":I
    .end local v20    # "entries\\1":Ljava/util/List;
    .end local v23    # "it\\1":Ljava/io/RandomAccessFile;
    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :catchall_3
    move-exception v0

    :goto_28
    move-object v1, v0

    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .end local p1    # "source":Ljava/io/File;
    .end local p2    # "destination":Ljava/io/File;
    .end local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :try_start_5
    throw v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .restart local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight;
    .restart local p1    # "source":Ljava/io/File;
    .restart local p2    # "destination":Ljava/io/File;
    .restart local p3    # "target":Lorg/lighttouch/android/StoreTarget;
    :catchall_4
    move-exception v0

    invoke-static {v3, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    .line 221
    .end local v10    # "zip":Lorg/lighttouch/android/IpaPreflight$Zip;
    :cond_3e
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v1, "\u8bf7\u9009\u62e9\u5c0f\u4e8e 2 GiB \u7684\u666e\u901a IPA\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v0

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_2
        0x2e -> :sswitch_1
        0x5c0 -> :sswitch_0
    .end sparse-switch
.end method

.class public final Lorg/lighttouch/android/TcgProbeService$binder$1;
.super Lorg/lighttouch/android/ITcgProbe$Stub;
.source "TcgProbeService.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/TcgProbeService;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nTcgProbeService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TcgProbeService.kt\norg/lighttouch/android/TcgProbeService$binder$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,44:1\n1#2:45\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016J\u0008\u0010\u0004\u001a\u00020\u0003H\u0016J\u0008\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\u0007"
    }
    d2 = {
        "org/lighttouch/android/TcgProbeService$binder$1",
        "Lorg/lighttouch/android/ITcgProbe$Stub;",
        "start",
        "Landroid/os/Bundle;",
        "status",
        "finish",
        "",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lorg/lighttouch/android/TcgProbeService;


# direct methods
.method public static synthetic $r8$lambda$B2--5yjvvH7uPlB9EXw3U7fPMZ4(Lorg/lighttouch/android/TcgProbeService;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/TcgProbeService$binder$1;->start$lambda$1(Lorg/lighttouch/android/TcgProbeService;)V

    return-void
.end method

.method public static synthetic $r8$lambda$mNc-VLKcnEi-qF18ZH82UWIaQ98(Lorg/lighttouch/android/TcgProbeService;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/TcgProbeService$binder$1;->finish$lambda$3(Lorg/lighttouch/android/TcgProbeService;)V

    return-void
.end method

.method constructor <init>(Lorg/lighttouch/android/TcgProbeService;)V
    .locals 0
    .param p1, "$receiver"    # Lorg/lighttouch/android/TcgProbeService;

    iput-object p1, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    .line 17
    invoke-direct {p0}, Lorg/lighttouch/android/ITcgProbe$Stub;-><init>()V

    return-void
.end method

.method private static final finish$lambda$3(Lorg/lighttouch/android/TcgProbeService;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/TcgProbeService;

    .line 36
    invoke-virtual {p0}, Lorg/lighttouch/android/TcgProbeService;->stopSelf()V

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    return-void
.end method

.method private static final start$lambda$1(Lorg/lighttouch/android/TcgProbeService;)V
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/TcgProbeService;

    .line 27
    :try_start_0
    sget-object v0, Lorg/lighttouch/android/TcgProbeNative;->INSTANCE:Lorg/lighttouch/android/TcgProbeNative;

    invoke-static {p0}, Lorg/lighttouch/android/TcgProbeService;->access$getDirectory$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/io/File;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, "directory"

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v1, 0x0

    :cond_0
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const-string v2, "getAbsolutePath(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/TcgProbeNative;->run(Ljava/lang/String;)I

    move-result v0

    invoke-static {p0, v0}, Lorg/lighttouch/android/TcgProbeService;->access$setExitCode$p(Lorg/lighttouch/android/TcgProbeService;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 28
    :catchall_0
    move-exception v0

    .local v0, "e":Ljava/lang/Throwable;
    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p0, v1}, Lorg/lighttouch/android/TcgProbeService;->access$setFailure$p(Lorg/lighttouch/android/TcgProbeService;Ljava/lang/String;)V

    const/4 v1, -0x1

    invoke-static {p0, v1}, Lorg/lighttouch/android/TcgProbeService;->access$setExitCode$p(Lorg/lighttouch/android/TcgProbeService;I)V

    .line 29
    .end local v0    # "e":Ljava/lang/Throwable;
    :goto_0
    return-void
.end method


# virtual methods
.method public finish()V
    .locals 5

    .line 36
    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    invoke-virtual {v1}, Lorg/lighttouch/android/TcgProbeService;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iget-object v1, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    new-instance v2, Lorg/lighttouch/android/TcgProbeService$binder$1$$ExternalSyntheticLambda1;

    invoke-direct {v2, v1}, Lorg/lighttouch/android/TcgProbeService$binder$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/TcgProbeService;)V

    const-wide/16 v3, 0x64

    invoke-virtual {v0, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public start()Landroid/os/Bundle;
    .locals 8

    .line 19
    iget-object v0, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    invoke-static {v0}, Lorg/lighttouch/android/TcgProbeService;->access$getConsumed$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 20
    iget-object v0, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    new-instance v3, Ljava/io/File;

    iget-object v4, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    invoke-virtual {v4}, Lorg/lighttouch/android/TcgProbeService;->getFilesDir()Ljava/io/File;

    move-result-object v4

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "tcg-"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0, v3}, Lorg/lighttouch/android/TcgProbeService;->access$setDirectory$p(Lorg/lighttouch/android/TcgProbeService;Ljava/io/File;)V

    .line 21
    iget-object v0, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    invoke-static {v0}, Lorg/lighttouch/android/TcgProbeService;->access$getDirectory$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x0

    const-string v4, "directory"

    if-nez v0, :cond_0

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v3

    :cond_0
    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 23
    const/16 v0, 0x10

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    sget-object v5, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v0, v5}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v0

    .line 24
    .local v0, "code":Ljava/nio/ByteBuffer;
    const/4 v5, 0x4

    new-array v5, v5, [Ljava/lang/Integer;

    const v6, -0x1c5fffd6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    aput-object v6, v5, v1

    const v1, -0x1c5feeff

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    aput-object v1, v5, v2

    const v1, -0x1a7eff00

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x2

    aput-object v1, v5, v2

    const v1, -0x15000002

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v2, 0x3

    aput-object v1, v5, v2

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    .local v2, "word":I
    invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    goto :goto_0

    .line 25
    .end local v2    # "word":I
    :cond_1
    new-instance v1, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    invoke-static {v2}, Lorg/lighttouch/android/TcgProbeService;->access$getDirectory$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/io/File;

    move-result-object v2

    if-nez v2, :cond_2

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_1

    :cond_2
    move-object v3, v2

    :goto_1
    const-string v2, "guest.bin"

    invoke-direct {v1, v3, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    const-string v3, "array(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, v2}, Lkotlin/io/FilesKt;->writeBytes(Ljava/io/File;[B)V

    .line 26
    new-instance v1, Ljava/lang/Thread;

    .line 29
    iget-object v2, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    new-instance v3, Lorg/lighttouch/android/TcgProbeService$binder$1$$ExternalSyntheticLambda0;

    invoke-direct {v3, v2}, Lorg/lighttouch/android/TcgProbeService$binder$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/TcgProbeService;)V

    .line 26
    const-string v2, "tcg-probe"

    invoke-direct {v1, v3, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 29
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 30
    invoke-virtual {p0}, Lorg/lighttouch/android/TcgProbeService$binder$1;->status()Landroid/os/Bundle;

    move-result-object v1

    return-object v1

    .line 21
    .end local v0    # "code":Ljava/nio/ByteBuffer;
    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "\u68c0\u67e5\u5931\u8d25\u3002"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 45
    :cond_4
    const/4 v0, 0x0

    .line 19
    .local v0, "$i$a$-check-TcgProbeService$binder$1$start$1\\1\\19\\0":I
    nop

    .end local v0    # "$i$a$-check-TcgProbeService$binder$1$start$1\\1\\19\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "A fresh probe worker is required"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public status()Landroid/os/Bundle;
    .locals 6

    .line 32
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, Lorg/lighttouch/android/TcgProbeService$binder$1;->this$0:Lorg/lighttouch/android/TcgProbeService;

    move-object v2, v0

    .local v2, "$this$status_u24lambda_u242\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 33
    .local v3, "$i$a$-apply-TcgProbeService$binder$1$status$1\\1\\32\\0":I
    invoke-static {v1}, Lorg/lighttouch/android/TcgProbeService;->access$getDirectory$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/io/File;

    move-result-object v4

    const-string v5, "directory"

    if-eqz v4, :cond_1

    invoke-static {v1}, Lorg/lighttouch/android/TcgProbeService;->access$getDirectory$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/io/File;

    move-result-object v4

    if-nez v4, :cond_0

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v4, 0x0

    :cond_0
    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    goto :goto_0

    :cond_1
    const-string v4, ""

    :goto_0
    invoke-virtual {v2, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 34
    const-string v4, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v4, "uid"

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v4, "exitCode"

    invoke-static {v1}, Lorg/lighttouch/android/TcgProbeService;->access$getExitCode$p(Lorg/lighttouch/android/TcgProbeService;)I

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v4, "error"

    invoke-static {v1}, Lorg/lighttouch/android/TcgProbeService;->access$getFailure$p(Lorg/lighttouch/android/TcgProbeService;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v4, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    nop

    .line 32
    .end local v2    # "$this$status_u24lambda_u242\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-TcgProbeService$binder$1$status$1\\1\\32\\0":I
    nop

    .line 35
    return-object v0
.end method

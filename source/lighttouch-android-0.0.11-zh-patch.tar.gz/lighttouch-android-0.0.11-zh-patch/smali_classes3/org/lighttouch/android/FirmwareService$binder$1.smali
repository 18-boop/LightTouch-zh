.class public final Lorg/lighttouch/android/FirmwareService$binder$1;
.super Lorg/lighttouch/android/IFirmware$Stub;
.source "FirmwareService.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/FirmwareService;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFirmwareService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FirmwareService.kt\norg/lighttouch/android/FirmwareService$binder$1\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,181:1\n1761#2,3:182\n1#3:185\n*S KotlinDebug\n*F\n+ 1 FirmwareService.kt\norg/lighttouch/android/FirmwareService$binder$1\n*L\n34#1:182,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\'\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u0002\n\u0002\u0008\u0002*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J(\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0008\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u0005H\u0016J\u0008\u0010\u000b\u001a\u00020\u0007H\u0016J\u0008\u0010\u000c\u001a\u00020\rH\u0016J\u0008\u0010\u000e\u001a\u00020\rH\u0016\u00a8\u0006\u000f"
    }
    d2 = {
        "org/lighttouch/android/FirmwareService$binder$1",
        "Lorg/lighttouch/android/IFirmware$Stub;",
        "supports",
        "",
        "firmwareId",
        "",
        "start",
        "Landroid/os/Bundle;",
        "ipswPath",
        "trustedToolsRoot",
        "bootromPath",
        "status",
        "cancel",
        "",
        "finish",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lorg/lighttouch/android/FirmwareService;


# direct methods
.method public static synthetic $r8$lambda$Y8whs2fWnN14B_MwKrBFo4XDbBI(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/FirmwareService$binder$1;->start$lambda$3(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sxcXOWsOAN5k23Q4qyFQw8BISE4(Lorg/lighttouch/android/FirmwareService;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/FirmwareService$binder$1;->finish$lambda$6(Lorg/lighttouch/android/FirmwareService;)V

    return-void
.end method

.method constructor <init>(Lorg/lighttouch/android/FirmwareService;)V
    .locals 0
    .param p1, "$receiver"    # Lorg/lighttouch/android/FirmwareService;

    iput-object p1, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    .line 31
    invoke-direct {p0}, Lorg/lighttouch/android/IFirmware$Stub;-><init>()V

    return-void
.end method

.method private static final finish$lambda$6(Lorg/lighttouch/android/FirmwareService;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/FirmwareService;

    .line 62
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/FirmwareService;->stopForeground(I)V

    invoke-virtual {p0}, Lorg/lighttouch/android/FirmwareService;->stopSelf()V

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V

    return-void
.end method

.method private static final start$lambda$3(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/FirmwareService;
    .param p1, "$firmwareId"    # Ljava/lang/String;
    .param p2, "$ipswPath"    # Ljava/lang/String;
    .param p3, "$trustedToolsRoot"    # Ljava/lang/String;
    .param p4, "$bootromPath"    # Ljava/lang/String;

    .line 44
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {p0, p1, p2, v0, p4}, Lorg/lighttouch/android/FirmwareService;->access$prepare(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 2

    .line 59
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lorg/lighttouch/android/FirmwareService;->access$setCancelling$p(Lorg/lighttouch/android/FirmwareService;Z)V

    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-static {v0}, Lorg/lighttouch/android/FirmwareService;->access$getProcess$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/Process;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Process;->destroy()V

    :cond_0
    return-void
.end method

.method public finish()V
    .locals 5

    .line 61
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-static {v0}, Lorg/lighttouch/android/FirmwareService;->access$getState$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "preparing"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 62
    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-virtual {v1}, Lorg/lighttouch/android/FirmwareService;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iget-object v1, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    new-instance v2, Lorg/lighttouch/android/FirmwareService$binder$1$$ExternalSyntheticLambda1;

    invoke-direct {v2, v1}, Lorg/lighttouch/android/FirmwareService$binder$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/FirmwareService;)V

    const-wide/16 v3, 0xc8

    invoke-virtual {v0, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 63
    return-void

    .line 185
    :cond_0
    const/4 v0, 0x0

    .line 61
    .local v0, "$i$a$-check-FirmwareService$binder$1$finish$1\\1\\61\\0":I
    nop

    .end local v0    # "$i$a$-check-FirmwareService$binder$1$finish$1\\1\\61\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cancel preparation and wait for a terminal result before closing the worker"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public start(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/os/Bundle;
    .locals 9
    .param p1, "firmwareId"    # Ljava/lang/String;
    .param p2, "ipswPath"    # Ljava/lang/String;
    .param p3, "trustedToolsRoot"    # Ljava/lang/String;
    .param p4, "bootromPath"    # Ljava/lang/String;

    const-string v0, "firmwareId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "ipswPath"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "trustedToolsRoot"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bootromPath"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-static {v0}, Lorg/lighttouch/android/FirmwareService;->access$getConsumed$p(Lorg/lighttouch/android/FirmwareService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 37
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    const/4 v1, 0x0

    invoke-static {v0, v1, v2, v1}, Lorg/lighttouch/android/FirmwareService;->foreground$default(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;ILjava/lang/Object;)V

    .line 38
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-static {v0, p1}, Lorg/lighttouch/android/FirmwareService;->access$setCurrentFirmwareId$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V

    .line 39
    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    const-string v1, "preparing"

    invoke-static {v0, v1}, Lorg/lighttouch/android/FirmwareService;->access$setState$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    const-string v2, "\u6b63\u5728\u542f\u52a8"

    invoke-static {v0, v2}, Lorg/lighttouch/android/FirmwareService;->access$setStage$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V

    .line 40
    new-instance v0, Ljava/io/File;

    iget-object v2, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-virtual {v2}, Lorg/lighttouch/android/FirmwareService;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const-string v3, "prepared"

    invoke-direct {v0, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v2, v0

    .line 185
    .local v2, "$this$start_u24lambda_u242\\2":Ljava/io/File;
    const/4 v3, 0x0

    .line 40
    .local v3, "$i$a$-apply-FirmwareService$binder$1$start$parent$1\\2\\40\\0":I
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 41
    .end local v2    # "$this$start_u24lambda_u242\\2":Ljava/io/File;
    .end local v3    # "$i$a$-apply-FirmwareService$binder$1$start$parent$1\\2\\40\\0":I
    .local v0, "parent":Ljava/io/File;
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object v2

    .line 42
    .local v2, "job":Ljava/lang/String;
    iget-object v3, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "job-"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v0, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    const-string v5, "getAbsolutePath(...)"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3, v4}, Lorg/lighttouch/android/FirmwareService;->access$setDestination$p(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V

    .line 43
    iget-object v3, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-static {v3, v1}, Lorg/lighttouch/android/FirmwareService;->access$note(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;)V

    .line 44
    new-instance v1, Ljava/lang/Thread;

    iget-object v4, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    new-instance v3, Lorg/lighttouch/android/FirmwareService$binder$1$$ExternalSyntheticLambda0;

    move-object v5, p1

    move-object v6, p2

    move-object v7, p3

    move-object v8, p4

    .end local p1    # "firmwareId":Ljava/lang/String;
    .end local p2    # "ipswPath":Ljava/lang/String;
    .end local p3    # "trustedToolsRoot":Ljava/lang/String;
    .end local p4    # "bootromPath":Ljava/lang/String;
    .local v5, "firmwareId":Ljava/lang/String;
    .local v6, "ipswPath":Ljava/lang/String;
    .local v7, "trustedToolsRoot":Ljava/lang/String;
    .local v8, "bootromPath":Ljava/lang/String;
    invoke-direct/range {v3 .. v8}, Lorg/lighttouch/android/FirmwareService$binder$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/FirmwareService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "firmwarekit"

    invoke-direct {v1, v3, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 45
    invoke-virtual {p0}, Lorg/lighttouch/android/FirmwareService$binder$1;->status()Landroid/os/Bundle;

    move-result-object p1

    return-object p1

    .line 185
    .end local v0    # "parent":Ljava/io/File;
    .end local v2    # "job":Ljava/lang/String;
    .end local v5    # "firmwareId":Ljava/lang/String;
    .end local v6    # "ipswPath":Ljava/lang/String;
    .end local v7    # "trustedToolsRoot":Ljava/lang/String;
    .end local v8    # "bootromPath":Ljava/lang/String;
    .restart local p1    # "firmwareId":Ljava/lang/String;
    .restart local p2    # "ipswPath":Ljava/lang/String;
    .restart local p3    # "trustedToolsRoot":Ljava/lang/String;
    .restart local p4    # "bootromPath":Ljava/lang/String;
    :cond_0
    move-object v5, p1

    move-object v6, p2

    .end local p1    # "firmwareId":Ljava/lang/String;
    .end local p2    # "ipswPath":Ljava/lang/String;
    .restart local v5    # "firmwareId":Ljava/lang/String;
    .restart local v6    # "ipswPath":Ljava/lang/String;
    const/4 p1, 0x0

    .line 36
    .local p1, "$i$a$-check-FirmwareService$binder$1$start$1\\1\\36\\0":I
    nop

    .end local p1    # "$i$a$-check-FirmwareService$binder$1$start$1\\1\\36\\0":I
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "A fresh firmware worker is required"

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public status()Landroid/os/Bundle;
    .locals 10

    .line 47
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    move-object v2, v0

    .local v2, "$this$status_u24lambda_u244\\1":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 48
    .local v3, "$i$a$-apply-FirmwareService$binder$1$status$1\\1\\47\\0":I
    nop

    .line 49
    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getFailure$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-lez v4, :cond_0

    move v4, v6

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    if-eqz v4, :cond_1

    const-string v4, "failed"

    goto :goto_1

    .line 50
    :cond_1
    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getCancelling$p(Lorg/lighttouch/android/FirmwareService;)Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getState$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v4

    const-string v7, "preparing"

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const-string v4, "cancelling"

    goto :goto_1

    .line 51
    :cond_2
    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getState$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v4

    .line 48
    :goto_1
    nop

    .line 53
    .local v4, "phase\\1":Ljava/lang/String;
    const-string v7, "state"

    invoke-virtual {v2, v7, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v7, "stage"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getStage$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v7, v8}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 54
    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getConsumed$p(Lorg/lighttouch/android/FirmwareService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v7

    const-string v8, "consumed"

    invoke-virtual {v2, v8, v7}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 55
    const-string v7, "done"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getDone$p(Lorg/lighttouch/android/FirmwareService;)J

    move-result-wide v8

    invoke-virtual {v2, v7, v8, v9}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    const-string v7, "total"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getTotal$p(Lorg/lighttouch/android/FirmwareService;)J

    move-result-wide v8

    invoke-virtual {v2, v7, v8, v9}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getFailure$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-nez v7, :cond_3

    move v5, v6

    :cond_3
    xor-int/2addr v5, v6

    const-string v6, "code"

    invoke-virtual {v2, v6, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    .line 56
    const-string v5, "error"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getFailure$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, "destination"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getDestination$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v5, "timings"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getTimings$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 57
    const-string v5, "uid"

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v6

    invoke-virtual {v2, v5, v6}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v5, "pid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v6

    invoke-virtual {v2, v5, v6}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v5, "firmwareId"

    invoke-static {v1}, Lorg/lighttouch/android/FirmwareService;->access$getCurrentFirmwareId$p(Lorg/lighttouch/android/FirmwareService;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v5, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 58
    nop

    .line 47
    .end local v2    # "$this$status_u24lambda_u244\\1":Landroid/os/Bundle;
    .end local v3    # "$i$a$-apply-FirmwareService$binder$1$status$1\\1\\47\\0":I
    .end local v4    # "phase\\1":Ljava/lang/String;
    nop

    .line 58
    return-object v0
.end method

.method public supports(Ljava/lang/String;)Z
    .locals 9
    .param p1, "firmwareId"    # Ljava/lang/String;

    const-string v0, "firmwareId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    invoke-virtual {v1}, Lorg/lighttouch/android/FirmwareService;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    iget-object v1, v1, Landroid/content/pm/ApplicationInfo;->nativeLibraryDir:Ljava/lang/String;

    const-string v2, "libfirmwarekit.so"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->canExecute()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    .line 34
    sget-object v0, Lorg/lighttouch/android/FirmwareCatalog;->INSTANCE:Lorg/lighttouch/android/FirmwareCatalog;

    iget-object v2, p0, Lorg/lighttouch/android/FirmwareService$binder$1;->this$0:Lorg/lighttouch/android/FirmwareService;

    check-cast v2, Landroid/content/Context;

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/FirmwareCatalog;->load(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 182
    .local v2, "$i$f$any\\1\\34":I
    instance-of v3, v0, Ljava/util/Collection;

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    move-object v3, v0

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    move v0, v1

    goto :goto_0

    .line 183
    :cond_0
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\1":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lorg/lighttouch/android/CatalogFirmware;

    .local v6, "it\\2":Lorg/lighttouch/android/CatalogFirmware;
    const/4 v7, 0x0

    .line 34
    .local v7, "$i$a$-any-FirmwareService$binder$1$supports$1\\2\\183\\0":I
    invoke-virtual {v6}, Lorg/lighttouch/android/CatalogFirmware;->getId()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    .line 183
    .end local v6    # "it\\2":Lorg/lighttouch/android/CatalogFirmware;
    .end local v7    # "$i$a$-any-FirmwareService$binder$1$supports$1\\2\\183\\0":I
    if-eqz v6, :cond_1

    move v0, v4

    goto :goto_0

    .line 184
    .end local v5    # "element\\1":Ljava/lang/Object;
    :cond_2
    move v0, v1

    .line 34
    .end local v0    # "$this$any\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$any\\1\\34":I
    :goto_0
    if-eqz v0, :cond_3

    move v1, v4

    goto :goto_1

    :cond_3
    nop

    :goto_1
    return v1
.end method

.class final Lorg/lighttouch/android/IpaPreflight$Zip;
.super Ljava/lang/Object;
.source "IpaPreflight.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/lighttouch/android/IpaPreflight;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Zip"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u0012\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0000\u0008\u0002\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u0016\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u0011R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0017\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000b\u0010\u000c\u00a8\u0006\u0012"
    }
    d2 = {
        "Lorg/lighttouch/android/IpaPreflight$Zip;",
        "",
        "file",
        "Ljava/io/RandomAccessFile;",
        "entries",
        "",
        "Lorg/lighttouch/android/IpaPreflight$Entry;",
        "<init>",
        "(Ljava/io/RandomAccessFile;Ljava/util/List;)V",
        "getFile",
        "()Ljava/io/RandomAccessFile;",
        "getEntries",
        "()Ljava/util/List;",
        "read",
        "",
        "entry",
        "limit",
        "",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final entries:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lorg/lighttouch/android/IpaPreflight$Entry;",
            ">;"
        }
    .end annotation
.end field

.field private final file:Ljava/io/RandomAccessFile;


# direct methods
.method public constructor <init>(Ljava/io/RandomAccessFile;Ljava/util/List;)V
    .locals 1
    .param p1, "file"    # Ljava/io/RandomAccessFile;
    .param p2, "entries"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/RandomAccessFile;",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/IpaPreflight$Entry;",
            ">;)V"
        }
    .end annotation

    const-string v0, "file"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "entries"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->file:Ljava/io/RandomAccessFile;

    iput-object p2, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->entries:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final getEntries()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/IpaPreflight$Entry;",
            ">;"
        }
    .end annotation

    .line 31
    iget-object v0, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->entries:Ljava/util/List;

    return-object v0
.end method

.method public final getFile()Ljava/io/RandomAccessFile;
    .locals 1

    .line 31
    iget-object v0, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->file:Ljava/io/RandomAccessFile;

    return-object v0
.end method

.method public final read(Lorg/lighttouch/android/IpaPreflight$Entry;J)[B
    .locals 11
    .param p1, "entry"    # Lorg/lighttouch/android/IpaPreflight$Entry;
    .param p2, "limit"    # J

    const-string v0, "entry"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getSize()J

    move-result-wide v0

    cmp-long v0, v0, p2

    if-gtz v0, :cond_5

    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getFlags()I

    move-result v0

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-nez v0, :cond_5

    .line 34
    const/16 v0, 0x1e

    new-array v2, v0, [B

    .line 35
    .local v2, "header":[B
    iget-object v3, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->file:Ljava/io/RandomAccessFile;

    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getLocalOffset()J

    move-result-wide v4

    invoke-virtual {v3, v4, v5}, Ljava/io/RandomAccessFile;->seek(J)V

    iget-object v3, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->file:Ljava/io/RandomAccessFile;

    invoke-virtual {v3, v2}, Ljava/io/RandomAccessFile;->readFully([B)V

    .line 36
    invoke-static {v2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3

    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v3

    .line 37
    .local v3, "b":Ljava/nio/ByteBuffer;
    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    const v5, 0x4034b50

    if-ne v4, v5, :cond_4

    .line 38
    iget-object v4, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->file:Ljava/io/RandomAccessFile;

    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getLocalOffset()J

    move-result-wide v5

    int-to-long v7, v0

    add-long/2addr v5, v7

    const/16 v0, 0x1a

    invoke-virtual {v3, v0}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v0

    const v7, 0xffff

    and-int/2addr v0, v7

    int-to-long v8, v0

    add-long/2addr v5, v8

    const/16 v0, 0x1c

    invoke-virtual {v3, v0}, Ljava/nio/ByteBuffer;->getShort(I)S

    move-result v0

    and-int/2addr v0, v7

    int-to-long v7, v0

    add-long/2addr v5, v7

    invoke-virtual {v4, v5, v6}, Ljava/io/RandomAccessFile;->seek(J)V

    .line 39
    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getCompressed()J

    move-result-wide v4

    long-to-int v0, v4

    new-array v0, v0, [B

    .local v0, "raw":[B
    iget-object v4, p0, Lorg/lighttouch/android/IpaPreflight$Zip;->file:Ljava/io/RandomAccessFile;

    invoke-virtual {v4, v0}, Ljava/io/RandomAccessFile;->readFully([B)V

    .line 40
    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getMethod()I

    move-result v4

    sparse-switch v4, :sswitch_data_0

    .line 50
    new-instance v1, Lorg/lighttouch/android/IpaError;

    const-string v4, "IPA \u4f7f\u7528\u4e86\u4e0d\u652f\u6301\u7684\u538b\u7f29\u65b9\u5f0f\u3002"

    invoke-direct {v1, v4}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v1

    .line 42
    :sswitch_0
    new-instance v4, Ljava/util/zip/Inflater;

    invoke-direct {v4, v1}, Ljava/util/zip/Inflater;-><init>(Z)V

    .local v4, "$this$read_u24lambda_u240\\1":Ljava/util/zip/Inflater;
    const/4 v1, 0x0

    .line 43
    .local v1, "$i$a$-run-IpaPreflight$Zip$read$1\\1\\42\\0":I
    nop

    .line 44
    :try_start_0
    invoke-virtual {v4, v0}, Ljava/util/zip/Inflater;->setInput([B)V

    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getSize()J

    move-result-wide v5

    long-to-int v5, v5

    new-array v5, v5, [B

    .local v5, "out\\1":[B
    const/4 v6, 0x0

    .line 45
    .local v6, "done\\1":I
    :goto_0
    array-length v7, v5

    if-ge v6, v7, :cond_2

    invoke-virtual {v4}, Ljava/util/zip/Inflater;->finished()Z

    move-result v7

    if-nez v7, :cond_2

    array-length v7, v5

    sub-int/2addr v7, v6

    invoke-virtual {v4, v5, v6, v7}, Ljava/util/zip/Inflater;->inflate([BII)I

    move-result v7

    .local v7, "n\\1":I
    if-nez v7, :cond_1

    invoke-virtual {v4}, Ljava/util/zip/Inflater;->needsInput()Z

    move-result v8

    if-nez v8, :cond_0

    invoke-virtual {v4}, Ljava/util/zip/Inflater;->needsDictionary()Z

    move-result v8

    if-eqz v8, :cond_1

    :cond_0
    goto :goto_1

    :cond_1
    add-int/2addr v6, v7

    .end local v7    # "n\\1":I
    goto :goto_0

    .line 46
    :cond_2
    :goto_1
    array-length v7, v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ne v6, v7, :cond_3

    .line 47
    nop

    .line 48
    .end local v5    # "out\\1":[B
    .end local v6    # "done\\1":I
    invoke-virtual {v4}, Ljava/util/zip/Inflater;->end()V

    .line 42
    .end local v1    # "$i$a$-run-IpaPreflight$Zip$read$1\\1\\42\\0":I
    .end local v4    # "$this$read_u24lambda_u240\\1":Ljava/util/zip/Inflater;
    goto :goto_2

    .line 46
    .restart local v1    # "$i$a$-run-IpaPreflight$Zip$read$1\\1\\42\\0":I
    .restart local v4    # "$this$read_u24lambda_u240\\1":Ljava/util/zip/Inflater;
    .restart local v6    # "done\\1":I
    :cond_3
    :try_start_1
    new-instance v7, Lorg/lighttouch/android/IpaError;

    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "The IPA member "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " is truncated."

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    .end local v0    # "raw":[B
    .end local v1    # "$i$a$-run-IpaPreflight$Zip$read$1\\1\\42\\0":I
    .end local v2    # "header":[B
    .end local v3    # "b":Ljava/nio/ByteBuffer;
    .end local v4    # "$this$read_u24lambda_u240\\1":Ljava/util/zip/Inflater;
    .end local p0    # "this":Lorg/lighttouch/android/IpaPreflight$Zip;
    .end local p1    # "entry":Lorg/lighttouch/android/IpaPreflight$Entry;
    .end local p2    # "limit":J
    throw v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 48
    .end local v6    # "done\\1":I
    .restart local v0    # "raw":[B
    .restart local v1    # "$i$a$-run-IpaPreflight$Zip$read$1\\1\\42\\0":I
    .restart local v2    # "header":[B
    .restart local v3    # "b":Ljava/nio/ByteBuffer;
    .restart local v4    # "$this$read_u24lambda_u240\\1":Ljava/util/zip/Inflater;
    .restart local p0    # "this":Lorg/lighttouch/android/IpaPreflight$Zip;
    .restart local p1    # "entry":Lorg/lighttouch/android/IpaPreflight$Entry;
    .restart local p2    # "limit":J
    :catchall_0
    move-exception v5

    invoke-virtual {v4}, Ljava/util/zip/Inflater;->end()V

    throw v5

    .line 41
    .end local v1    # "$i$a$-run-IpaPreflight$Zip$read$1\\1\\42\\0":I
    .end local v4    # "$this$read_u24lambda_u240\\1":Ljava/util/zip/Inflater;
    :sswitch_1
    move-object v5, v0

    .line 40
    :goto_2
    return-object v5

    .line 37
    .end local v0    # "raw":[B
    :cond_4
    new-instance v0, Lorg/lighttouch/android/IpaError;

    const-string v1, "IPA \u7684\u6210\u5458\u5934\u90e8\u5df2\u635f\u574f\u3002"

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v0

    .line 33
    .end local v2    # "header":[B
    .end local v3    # "b":Ljava/nio/ByteBuffer;
    :cond_5
    new-instance v0, Lorg/lighttouch/android/IpaError;

    invoke-virtual {p1}, Lorg/lighttouch/android/IpaPreflight$Entry;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "The IPA contains an unsupported or oversized member: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/lighttouch/android/IpaError;-><init>(Ljava/lang/String;)V

    throw v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_1
        0x8 -> :sswitch_0
    .end sparse-switch
.end method

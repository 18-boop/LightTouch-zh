.class public final enum Lorg/lighttouch/android/OverlayLevel;
.super Ljava/lang/Enum;
.source "AppSettings.kt"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lorg/lighttouch/android/OverlayLevel;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\t\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0011\u0008\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\u0008\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007j\u0002\u0008\u0008j\u0002\u0008\tj\u0002\u0008\nj\u0002\u0008\u000b\u00a8\u0006\u000c"
    }
    d2 = {
        "Lorg/lighttouch/android/OverlayLevel;",
        "",
        "label",
        "",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;)V",
        "getLabel",
        "()Ljava/lang/String;",
        "OFF",
        "FPS",
        "COMPACT",
        "FULL",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lorg/lighttouch/android/OverlayLevel;

.field public static final enum COMPACT:Lorg/lighttouch/android/OverlayLevel;

.field public static final enum FPS:Lorg/lighttouch/android/OverlayLevel;

.field public static final enum FULL:Lorg/lighttouch/android/OverlayLevel;

.field public static final enum OFF:Lorg/lighttouch/android/OverlayLevel;


# instance fields
.field private final label:Ljava/lang/String;


# direct methods
.method private static final synthetic $values()[Lorg/lighttouch/android/OverlayLevel;
    .locals 4

    sget-object v0, Lorg/lighttouch/android/OverlayLevel;->OFF:Lorg/lighttouch/android/OverlayLevel;

    sget-object v1, Lorg/lighttouch/android/OverlayLevel;->FPS:Lorg/lighttouch/android/OverlayLevel;

    sget-object v2, Lorg/lighttouch/android/OverlayLevel;->COMPACT:Lorg/lighttouch/android/OverlayLevel;

    sget-object v3, Lorg/lighttouch/android/OverlayLevel;->FULL:Lorg/lighttouch/android/OverlayLevel;

    filled-new-array {v0, v1, v2, v3}, [Lorg/lighttouch/android/OverlayLevel;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 4

    .line 9
    new-instance v0, Lorg/lighttouch/android/OverlayLevel;

    const/4 v1, 0x0

    const-string v2, "\u5df2\u5173\u95ed"

    const-string v3, "OFF"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/OverlayLevel;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/OverlayLevel;->OFF:Lorg/lighttouch/android/OverlayLevel;

    new-instance v0, Lorg/lighttouch/android/OverlayLevel;

    const-string v1, "FPS"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2, v1}, Lorg/lighttouch/android/OverlayLevel;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/OverlayLevel;->FPS:Lorg/lighttouch/android/OverlayLevel;

    new-instance v0, Lorg/lighttouch/android/OverlayLevel;

    const/4 v1, 0x2

    const-string v2, "Basic"

    const-string v3, "COMPACT"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/OverlayLevel;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/OverlayLevel;->COMPACT:Lorg/lighttouch/android/OverlayLevel;

    new-instance v0, Lorg/lighttouch/android/OverlayLevel;

    const/4 v1, 0x3

    const-string v2, "Full"

    const-string v3, "FULL"

    invoke-direct {v0, v3, v1, v2}, Lorg/lighttouch/android/OverlayLevel;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lorg/lighttouch/android/OverlayLevel;->FULL:Lorg/lighttouch/android/OverlayLevel;

    invoke-static {}, Lorg/lighttouch/android/OverlayLevel;->$values()[Lorg/lighttouch/android/OverlayLevel;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/OverlayLevel;->$VALUES:[Lorg/lighttouch/android/OverlayLevel;

    sget-object v0, Lorg/lighttouch/android/OverlayLevel;->$VALUES:[Lorg/lighttouch/android/OverlayLevel;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/OverlayLevel;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .param p3, "label"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 9
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lorg/lighttouch/android/OverlayLevel;->label:Ljava/lang/String;

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lorg/lighttouch/android/OverlayLevel;",
            ">;"
        }
    .end annotation

    sget-object v0, Lorg/lighttouch/android/OverlayLevel;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 9
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lorg/lighttouch/android/OverlayLevel;
    .locals 1
    .param p0, "value"    # Ljava/lang/String;

    const-class v0, Lorg/lighttouch/android/OverlayLevel;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    .line 9
    check-cast v0, Lorg/lighttouch/android/OverlayLevel;

    return-object v0
.end method

.method public static values()[Lorg/lighttouch/android/OverlayLevel;
    .locals 1

    sget-object v0, Lorg/lighttouch/android/OverlayLevel;->$VALUES:[Lorg/lighttouch/android/OverlayLevel;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    .line 9
    check-cast v0, [Lorg/lighttouch/android/OverlayLevel;

    return-object v0
.end method


# virtual methods
.method public final getLabel()Ljava/lang/String;
    .locals 1

    .line 9
    iget-object v0, p0, Lorg/lighttouch/android/OverlayLevel;->label:Ljava/lang/String;

    return-object v0
.end method

.class public final Lorg/lighttouch/android/PerformanceOverlayKt;
.super Ljava/lang/Object;
.source "PerformanceOverlay.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/PerformanceOverlayKt$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nPerformanceOverlay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PerformanceOverlay.kt\norg/lighttouch/android/PerformanceOverlayKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 AnnotatedString.kt\nandroidx/compose/ui/text/AnnotatedStringKt\n+ 8 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 9 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 10 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,113:1\n169#2:114\n169#2:115\n149#2:165\n169#2:166\n149#2:167\n169#2:168\n149#2:192\n86#3:116\n83#3,6:117\n89#3:151\n93#3:173\n79#4,6:123\n86#4,4:138\n90#4,2:148\n94#4:172\n368#5,9:129\n377#5:150\n378#5,2:170\n4034#6,6:142\n1242#7:152\n1041#7,6:153\n1041#7,6:159\n1242#7:180\n1041#7,6:181\n1#8:169\n1225#9,6:174\n1878#10,3:187\n1878#10,2:190\n1880#10:193\n*S KotlinDebug\n*F\n+ 1 PerformanceOverlay.kt\norg/lighttouch/android/PerformanceOverlayKt\n*L\n37#1:114\n38#1:115\n51#1:165\n51#1:166\n56#1:167\n56#1:168\n105#1:192\n36#1:116\n36#1:117,6\n36#1:151\n36#1:173\n36#1:123,6\n36#1:138,4\n36#1:148,2\n36#1:172\n36#1:129,9\n36#1:150\n36#1:170,2\n36#1:142,6\n45#1:152\n46#1:153,6\n47#1:159,6\n39#1:180\n40#1:181,6\n85#1:174,6\n97#1:187,3\n105#1:190,2\n105#1:193\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000P\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0014\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0010\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002\u001a\u0010\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0002\u001aI\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u000f2\u0008\u0008\u0002\u0010\u0010\u001a\u00020\u00112\u0008\u0008\u0002\u0010\u0012\u001a\u00020\u0003H\u0001\u00a2\u0006\u0002\u0010\u0013\u001a%\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\u0010\u001a\u00020\u0011H\u0001\u00a2\u0006\u0002\u0010\u0017\u001a\u0014\u0010\u0018\u001a\u00020\u0019*\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0000\u00a8\u0006\u001d"
    }
    d2 = {
        "f1",
        "",
        "value",
        "",
        "f0",
        "PerformanceOverlay",
        "",
        "snapshot",
        "Lorg/lighttouch/android/PerfSnapshot;",
        "level",
        "Lorg/lighttouch/android/OverlayLevel;",
        "graph",
        "Lorg/lighttouch/android/OverlayGraph;",
        "opacity",
        "detailedTiming",
        "",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "scale",
        "(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FLandroidx/compose/runtime/Composer;II)V",
        "FrameGraph",
        "intervals",
        "",
        "([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V",
        "of",
        "Landroidx/compose/ui/Alignment;",
        "Landroidx/compose/ui/Alignment$Companion;",
        "corner",
        "Lorg/lighttouch/android/OverlayCorner;",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$33HGBe4t5Bky2EO5h93xNHWz42k(Lorg/lighttouch/android/OverlayGraph;[FLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph$lambda$19$lambda$18(Lorg/lighttouch/android/OverlayGraph;[FLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$YUZ4EO-_dAAgwhQ-YuvccnoGbo8([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph$lambda$20([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fq7ha6t2-4kHumLZ6f5oGdjlxF4(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$0(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tBVaXvePn6Y1pEC_ukOCbUfhbWE(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p10}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$15(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final FrameGraph([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V
    .locals 8
    .param p0, "intervals"    # [F
    .param p1, "graph"    # Lorg/lighttouch/android/OverlayGraph;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "intervals"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "graph"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "modifier"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    const v0, 0x446ba64f

    invoke-interface {p3, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object p3

    const-string v1, "C(FrameGraph)P(1)84@4869L1291,84@4852L1308:PerformanceOverlay.kt#o13vsk"

    invoke-static {p3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move v1, p4

    .local v1, "$dirty":I
    and-int/lit8 v2, p4, 0x6

    if-nez v2, :cond_1

    invoke-interface {p3, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    :goto_0
    or-int/2addr v1, v2

    :cond_1
    and-int/lit8 v2, p4, 0x30

    const/16 v3, 0x20

    if-nez v2, :cond_3

    move-object v2, p1

    check-cast v2, Ljava/lang/Enum;

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    invoke-interface {p3, v2}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v2

    if-eqz v2, :cond_2

    move v2, v3

    goto :goto_1

    :cond_2
    const/16 v2, 0x10

    :goto_1
    or-int/2addr v1, v2

    :cond_3
    and-int/lit16 v2, p4, 0x180

    if-nez v2, :cond_5

    invoke-interface {p3, p2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    const/16 v2, 0x100

    goto :goto_2

    :cond_4
    const/16 v2, 0x80

    :goto_2
    or-int/2addr v1, v2

    :cond_5
    and-int/lit16 v2, v1, 0x93

    const/16 v4, 0x92

    if-ne v2, v4, :cond_7

    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_6

    goto :goto_3

    .line 85
    :cond_6
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto :goto_7

    .line 84
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8

    const/4 v2, -0x1

    const-string v4, "org.lighttouch.android.FrameGraph (PerformanceOverlay.kt:83)"

    invoke-static {v0, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 85
    :cond_8
    const v0, -0x615d173a

    invoke-interface {p3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):PerformanceOverlay.kt#9igjgp"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v1, 0x70

    if-ne v0, v3, :cond_9

    const/4 v0, 0x1

    goto :goto_4

    :cond_9
    const/4 v0, 0x0

    :goto_4
    invoke-interface {p3, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v0, v2

    .local v0, "invalid\\1":Z
    move-object v2, p3

    .local v2, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 174
    .local v3, "$i$f$cache\\1\\85":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 175
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\174\\1":I
    if-nez v0, :cond_b

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_a

    goto :goto_5

    .line 179
    :cond_a
    move-object v7, v4

    goto :goto_6

    .line 176
    :cond_b
    :goto_5
    const/4 v6, 0x0

    .line 85
    .local v6, "$i$a$-cache-PerformanceOverlayKt$FrameGraph$1\\3\\176\\0":I
    new-instance v7, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda0;

    invoke-direct {v7, p1, p0}, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/OverlayGraph;[F)V

    .line 176
    .end local v6    # "$i$a$-cache-PerformanceOverlayKt$FrameGraph$1\\3\\176\\0":I
    nop

    .line 177
    .local v7, "value\\2":Ljava/lang/Object;
    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 178
    nop

    .line 175
    .end local v7    # "value\\2":Ljava/lang/Object;
    :goto_6
    nop

    .line 174
    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\174\\1":I
    nop

    .line 85
    .end local v0    # "invalid\\1":Z
    .end local v2    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\1\\85":I
    check-cast v7, Lkotlin/jvm/functions/Function1;

    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    shr-int/lit8 v0, v1, 0x6

    and-int/lit8 v0, v0, 0xe

    invoke-static {p2, v7, p3, v0}, Landroidx/compose/foundation/CanvasKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_c
    :goto_7
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_d

    new-instance v2, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, p1, p2, p4}, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda1;-><init>([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;I)V

    invoke-interface {v0, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 107
    :cond_d
    return-void
.end method

.method private static final FrameGraph$lambda$19$lambda$18(Lorg/lighttouch/android/OverlayGraph;[FLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .locals 32
    .param p0, "$graph"    # Lorg/lighttouch/android/OverlayGraph;
    .param p1, "$intervals"    # [F
    .param p2, "$this$Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const-string v2, "$this$Canvas"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    sget-object v2, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v3

    const/16 v9, 0xe

    const/4 v10, 0x0

    const v5, 0x3e3851ec    # 0.18f

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v3 .. v10}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v2

    .line 87
    .local v2, "guide":J
    sget-object v4, Lorg/lighttouch/android/OverlayGraph;->FRAME_TIME:Lorg/lighttouch/android/OverlayGraph;

    const/4 v5, 0x0

    const/4 v6, 0x1

    move-object/from16 v7, p0

    if-ne v7, v4, :cond_0

    move v4, v6

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    move/from16 v16, v4

    .line 88
    .local v16, "frameTime":Z
    const/high16 v17, 0x42480000    # 50.0f

    const/high16 v4, 0x42700000    # 60.0f

    if-eqz v16, :cond_1

    move/from16 v8, v17

    goto :goto_1

    :cond_1
    move v8, v4

    .line 90
    .local v8, "top":F
    :goto_1
    const/4 v9, 0x2

    if-eqz v16, :cond_2

    new-array v4, v9, [Ljava/lang/Float;

    const v10, 0x4185999a    # 16.7f

    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v10

    aput-object v10, v4, v5

    const v5, 0x42053333    # 33.3f

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    aput-object v5, v4, v6

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    goto :goto_2

    :cond_2
    new-array v10, v9, [Ljava/lang/Float;

    const/high16 v11, 0x41f00000    # 30.0f

    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    aput-object v11, v10, v5

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    aput-object v4, v10, v6

    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    :goto_2
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_3
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_3

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    .local v4, "g":F
    invoke-static {v1, v8, v4}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph$lambda$19$lambda$18$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v10

    invoke-static {v5, v10}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v10

    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v12

    invoke-static {v12, v13}, Landroidx/compose/ui/geometry/Size;->getWidth-impl(J)F

    move-result v5

    invoke-static {v1, v8, v4}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph$lambda$19$lambda$18$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v12

    invoke-static {v5, v12}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v12

    const/16 v14, 0x1f0

    const/4 v15, 0x0

    move v5, v8

    .end local v8    # "top":F
    .local v5, "top":F
    const/high16 v8, 0x3f800000    # 1.0f

    move/from16 v19, v9

    const/4 v9, 0x0

    move/from16 v20, v4

    move-wide/from16 v30, v10

    move v11, v5

    move-wide/from16 v4, v30

    .end local v4    # "g":F
    .end local v5    # "top":F
    .local v11, "top":F
    .local v20, "g":F
    const/4 v10, 0x0

    move/from16 v21, v11

    .end local v11    # "top":F
    .local v21, "top":F
    const/4 v11, 0x0

    move-wide/from16 v30, v12

    move v13, v6

    move-wide/from16 v6, v30

    const/4 v12, 0x0

    move/from16 v22, v13

    const/4 v13, 0x0

    move/from16 v23, v21

    .end local v21    # "top":F
    .local v23, "top":F
    invoke-static/range {v1 .. v15}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawLine-NGM6Ib0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFILandroidx/compose/ui/graphics/PathEffect;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v9, 0x2

    move-object/from16 v7, p0

    move/from16 v8, v23

    .end local v2    # "guide":J
    .end local v20    # "g":F
    .local v13, "guide":J
    goto :goto_3

    .line 91
    .end local v13    # "guide":J
    .end local v23    # "top":F
    .restart local v2    # "guide":J
    .restart local v8    # "top":F
    :cond_3
    move-wide v13, v2

    move/from16 v23, v8

    .end local v2    # "guide":J
    .end local v8    # "top":F
    .restart local v13    # "guide":J
    .restart local v23    # "top":F
    array-length v2, v0

    const/4 v3, 0x2

    if-ge v2, v3, :cond_4

    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2

    .line 92
    :cond_4
    const/16 v2, 0xf0

    invoke-static {v0, v2}, Lkotlin/collections/ArraysKt;->takeLast([FI)Ljava/util/List;

    move-result-object v15

    .line 94
    .local v15, "shown":Ljava/util/List;
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getWidth-impl(J)F

    move-result v2

    invoke-interface {v15}, Ljava/util/List;->size()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    invoke-static {v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v3

    int-to-float v3, v3

    div-float v18, v2, v3

    .line 95
    .local v18, "step":F
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPath_androidKt;->Path()Landroidx/compose/ui/graphics/Path;

    move-result-object v2

    .line 96
    .local v2, "line":Landroidx/compose/ui/graphics/Path;
    const/4 v3, 0x0

    .line 97
    .local v3, "pen":Z
    move-object v4, v15

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 187
    .local v6, "$i$f$forEachIndexed\\1\\97":I
    const/4 v7, 0x0

    .line 188
    .local v7, "index\\1":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move/from16 v19, v3

    .end local v3    # "pen":Z
    .local v19, "pen":Z
    :goto_4
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/high16 v20, 0x447a0000    # 1000.0f

    if-eqz v3, :cond_a

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "item\\1":Ljava/lang/Object;
    add-int/lit8 v9, v7, 0x1

    .end local v7    # "index\\1":I
    .local v9, "index\\1":I
    if-gez v7, :cond_5

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_5
    move-object v10, v3

    check-cast v10, Ljava/lang/Number;

    invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F

    move-result v10

    .local v7, "i\\2":I
    .local v10, "ms\\2":F
    const/4 v11, 0x0

    .line 98
    .local v11, "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$1\\2\\188\\0":I
    cmpl-float v12, v10, v20

    if-ltz v12, :cond_6

    const/4 v12, 0x0

    move/from16 v19, v12

    move/from16 v11, v23

    .end local v19    # "pen":Z
    .local v12, "pen":Z
    goto :goto_7

    .line 99
    .end local v12    # "pen":Z
    .restart local v19    # "pen":Z
    :cond_6
    if-eqz v16, :cond_7

    move/from16 v20, v10

    goto :goto_5

    :cond_7
    cmpl-float v12, v10, v5

    if-lez v12, :cond_8

    div-float v20, v20, v10

    goto :goto_5

    :cond_8
    move/from16 v20, v5

    :goto_5
    move/from16 v12, v20

    .line 100
    .local v12, "v\\2":F
    if-nez v19, :cond_9

    int-to-float v5, v7

    mul-float v5, v5, v18

    move/from16 v22, v11

    move/from16 v11, v23

    .end local v23    # "top":F
    .local v11, "top":F
    .local v22, "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$1\\2\\188\\0":I
    invoke-static {v1, v11, v12}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph$lambda$19$lambda$18$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v0

    invoke-interface {v2, v5, v0}, Landroidx/compose/ui/graphics/Path;->moveTo(FF)V

    goto :goto_6

    .end local v22    # "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$1\\2\\188\\0":I
    .local v11, "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$1\\2\\188\\0":I
    .restart local v23    # "top":F
    :cond_9
    move/from16 v22, v11

    move/from16 v11, v23

    .end local v23    # "top":F
    .local v11, "top":F
    .restart local v22    # "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$1\\2\\188\\0":I
    int-to-float v0, v7

    mul-float v0, v0, v18

    invoke-static {v1, v11, v12}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph$lambda$19$lambda$18$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F

    move-result v5

    invoke-interface {v2, v0, v5}, Landroidx/compose/ui/graphics/Path;->lineTo(FF)V

    .line 101
    :goto_6
    const/4 v0, 0x1

    .line 102
    .end local v19    # "pen":Z
    .local v0, "pen":Z
    move/from16 v19, v0

    .line 188
    .end local v0    # "pen":Z
    .end local v7    # "i\\2":I
    .end local v10    # "ms\\2":F
    .end local v12    # "v\\2":F
    .end local v22    # "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$1\\2\\188\\0":I
    .restart local v19    # "pen":Z
    :goto_7
    move-object/from16 v0, p1

    move v7, v9

    move/from16 v23, v11

    const/4 v5, 0x0

    .end local v3    # "item\\1":Ljava/lang/Object;
    goto :goto_4

    .line 189
    .end local v9    # "index\\1":I
    .end local v11    # "top":F
    .local v7, "index\\1":I
    .restart local v23    # "top":F
    :cond_a
    move/from16 v11, v23

    .line 103
    .end local v4    # "$this$forEachIndexed\\1":Ljava/lang/Iterable;
    .end local v6    # "$i$f$forEachIndexed\\1\\97":I
    .end local v7    # "index\\1":I
    .end local v23    # "top":F
    .restart local v11    # "top":F
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayGpu-0d7_KjU()J

    move-result-wide v3

    new-instance v21, Landroidx/compose/ui/graphics/drawscope/Stroke;

    const/16 v27, 0x1e

    const/16 v28, 0x0

    const/high16 v22, 0x3fc00000    # 1.5f

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    invoke-direct/range {v21 .. v28}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIILandroidx/compose/ui/graphics/PathEffect;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v6, v21

    check-cast v6, Landroidx/compose/ui/graphics/drawscope/DrawStyle;

    const/16 v9, 0x34

    const/4 v10, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v1 .. v10}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawPath-LG529CI$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Path;JFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    .line 105
    move-object v0, v2

    .end local v2    # "line":Landroidx/compose/ui/graphics/Path;
    .local v0, "line":Landroidx/compose/ui/graphics/Path;
    if-eqz v16, :cond_e

    move-object/from16 v21, v15

    check-cast v21, Ljava/lang/Iterable;

    .local v21, "$this$forEachIndexed\\3":Ljava/lang/Iterable;
    const/16 v22, 0x0

    .line 190
    .local v22, "$i$f$forEachIndexed\\3\\105":I
    const/4 v2, 0x0

    .line 191
    .local v2, "index\\3":I
    invoke-interface/range {v21 .. v21}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v23

    :goto_8
    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_d

    invoke-interface/range {v23 .. v23}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v24

    .local v24, "item\\3":Ljava/lang/Object;
    add-int/lit8 v25, v2, 0x1

    .end local v2    # "index\\3":I
    .local v25, "index\\3":I
    if-gez v2, :cond_b

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_b
    move-object/from16 v3, v24

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    move-result v26

    .local v2, "i\\4":I
    .local v26, "ms\\4":F
    const/16 v27, 0x0

    .line 105
    .local v27, "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$2\\4\\191\\0":I
    cmpl-float v3, v26, v17

    if-lez v3, :cond_c

    cmpg-float v3, v26, v20

    if-gez v3, :cond_c

    sget-object v3, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v3}, Lorg/lighttouch/android/LtColors;->getDanger-0d7_KjU()J

    move-result-wide v3

    const/4 v5, 0x2

    .local v5, "$this$dp\\5":I
    const/4 v6, 0x0

    .line 192
    .local v6, "$i$f$getDp\\5\\105":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 105
    .end local v5    # "$this$dp\\5":I
    .end local v6    # "$i$f$getDp\\5\\105":I
    invoke-interface {v1, v5}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v5

    int-to-float v6, v2

    mul-float v6, v6, v18

    const/4 v7, 0x2

    .local v7, "$this$dp\\6":I
    const/4 v8, 0x0

    .line 192
    .local v8, "$i$f$getDp\\6\\105":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 105
    .end local v7    # "$this$dp\\6":I
    .end local v8    # "$i$f$getDp\\6\\105":I
    invoke-interface {v1, v7}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v7

    invoke-static {v6, v7}, Landroidx/compose/ui/geometry/OffsetKt;->Offset(FF)J

    move-result-wide v6

    move v8, v11

    .end local v11    # "top":F
    .local v8, "top":F
    const/16 v11, 0x78

    const/4 v12, 0x0

    move v9, v2

    move-wide v2, v3

    move v4, v5

    move-wide v5, v6

    .end local v2    # "i\\4":I
    .local v9, "i\\4":I
    const/4 v7, 0x0

    move v10, v8

    .end local v8    # "top":F
    .local v10, "top":F
    const/4 v8, 0x0

    move/from16 v28, v9

    .end local v9    # "i\\4":I
    .local v28, "i\\4":I
    const/4 v9, 0x0

    move/from16 v29, v10

    .end local v10    # "top":F
    .local v29, "top":F
    const/4 v10, 0x0

    invoke-static/range {v1 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    goto :goto_9

    .end local v28    # "i\\4":I
    .end local v29    # "top":F
    .restart local v2    # "i\\4":I
    .restart local v11    # "top":F
    :cond_c
    move/from16 v28, v2

    move/from16 v29, v11

    .line 191
    .end local v2    # "i\\4":I
    .end local v11    # "top":F
    .end local v26    # "ms\\4":F
    .end local v27    # "$i$a$-forEachIndexed-PerformanceOverlayKt$FrameGraph$1$1$2\\4\\191\\0":I
    .restart local v29    # "top":F
    :goto_9
    move-object/from16 v1, p2

    move/from16 v2, v25

    move/from16 v11, v29

    .end local v24    # "item\\3":Ljava/lang/Object;
    goto :goto_8

    .line 193
    .end local v25    # "index\\3":I
    .end local v29    # "top":F
    .local v2, "index\\3":I
    .restart local v11    # "top":F
    :cond_d
    move/from16 v29, v11

    .end local v11    # "top":F
    .restart local v29    # "top":F
    goto :goto_a

    .line 105
    .end local v2    # "index\\3":I
    .end local v21    # "$this$forEachIndexed\\3":Ljava/lang/Iterable;
    .end local v22    # "$i$f$forEachIndexed\\3\\105":I
    .end local v29    # "top":F
    .restart local v11    # "top":F
    :cond_e
    move/from16 v29, v11

    .line 106
    .end local v11    # "top":F
    .restart local v29    # "top":F
    :goto_a
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final FrameGraph$lambda$19$lambda$18$y(Landroidx/compose/ui/graphics/drawscope/DrawScope;FF)F
    .locals 4
    .param p0, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p1, "top"    # F
    .param p2, "v"    # F

    .line 89
    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v0

    invoke-static {v0, v1}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v0

    const/4 v1, 0x0

    invoke-static {p2, v1, p1}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v1

    div-float/2addr v1, p1

    invoke-interface {p0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->getHeight-impl(J)F

    move-result v2

    mul-float/2addr v1, v2

    sub-float/2addr v0, v1

    return v0
.end method

.method private static final FrameGraph$lambda$20([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final PerformanceOverlay(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FLandroidx/compose/runtime/Composer;II)V
    .locals 80
    .param p0, "snapshot"    # Lorg/lighttouch/android/PerfSnapshot;
    .param p1, "level"    # Lorg/lighttouch/android/OverlayLevel;
    .param p2, "graph"    # Lorg/lighttouch/android/OverlayGraph;
    .param p3, "opacity"    # F
    .param p4, "detailedTiming"    # Z
    .param p5, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p6, "scale"    # F
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v5, p4

    move/from16 v8, p8

    const-string v0, "snapshot"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "level"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "graph"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 33
    const v0, 0x221a97e8

    move-object/from16 v4, p7

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(PerformanceOverlay)P(6,2,1,4)35@1607L3034:PerformanceOverlay.kt#o13vsk"

    invoke-static {v10, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p8

    .local v4, "$dirty":I
    and-int/lit8 v6, p9, 0x1

    const/4 v7, 0x4

    if-eqz v6, :cond_0

    or-int/lit8 v4, v4, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v6, v8, 0x6

    if-nez v6, :cond_2

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    move v6, v7

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v4, v6

    :cond_2
    :goto_1
    and-int/lit8 v6, p9, 0x2

    if-eqz v6, :cond_3

    or-int/lit8 v4, v4, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v6, v8, 0x30

    if-nez v6, :cond_5

    move-object v6, v2

    check-cast v6, Ljava/lang/Enum;

    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_4

    const/16 v6, 0x20

    goto :goto_2

    :cond_4
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v4, v6

    :cond_5
    :goto_3
    and-int/lit8 v6, p9, 0x4

    if-eqz v6, :cond_6

    or-int/lit16 v4, v4, 0x180

    goto :goto_5

    :cond_6
    and-int/lit16 v6, v8, 0x180

    if-nez v6, :cond_8

    move-object v6, v3

    check-cast v6, Ljava/lang/Enum;

    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_7

    const/16 v6, 0x100

    goto :goto_4

    :cond_7
    const/16 v6, 0x80

    :goto_4
    or-int/2addr v4, v6

    :cond_8
    :goto_5
    and-int/lit8 v6, p9, 0x8

    if-eqz v6, :cond_9

    or-int/lit16 v4, v4, 0xc00

    move/from16 v13, p3

    goto :goto_7

    :cond_9
    and-int/lit16 v6, v8, 0xc00

    if-nez v6, :cond_b

    move/from16 v13, p3

    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v6

    if-eqz v6, :cond_a

    const/16 v6, 0x800

    goto :goto_6

    :cond_a
    const/16 v6, 0x400

    :goto_6
    or-int/2addr v4, v6

    goto :goto_7

    :cond_b
    move/from16 v13, p3

    :goto_7
    and-int/lit8 v6, p9, 0x10

    if-eqz v6, :cond_c

    or-int/lit16 v4, v4, 0x6000

    goto :goto_9

    :cond_c
    and-int/lit16 v6, v8, 0x6000

    if-nez v6, :cond_e

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_d

    const/16 v6, 0x4000

    goto :goto_8

    :cond_d
    const/16 v6, 0x2000

    :goto_8
    or-int/2addr v4, v6

    :cond_e
    :goto_9
    and-int/lit8 v6, p9, 0x20

    const/high16 v11, 0x30000

    if-eqz v6, :cond_f

    or-int/2addr v4, v11

    move-object/from16 v11, p5

    goto :goto_b

    :cond_f
    and-int/2addr v11, v8

    if-nez v11, :cond_11

    move-object/from16 v11, p5

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_10

    const/high16 v12, 0x20000

    goto :goto_a

    :cond_10
    const/high16 v12, 0x10000

    :goto_a
    or-int/2addr v4, v12

    goto :goto_b

    :cond_11
    move-object/from16 v11, p5

    :goto_b
    and-int/lit8 v12, p9, 0x40

    const/high16 v14, 0x180000

    if-eqz v12, :cond_12

    or-int/2addr v4, v14

    move/from16 v14, p6

    goto :goto_d

    :cond_12
    and-int/2addr v14, v8

    if-nez v14, :cond_14

    move/from16 v14, p6

    invoke-interface {v10, v14}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v15

    if-eqz v15, :cond_13

    const/high16 v15, 0x100000

    goto :goto_c

    :cond_13
    const/high16 v15, 0x80000

    :goto_c
    or-int/2addr v4, v15

    goto :goto_d

    :cond_14
    move/from16 v14, p6

    :goto_d
    move v15, v4

    .end local v4    # "$dirty":I
    .local v15, "$dirty":I
    const v4, 0x92493

    and-int/2addr v4, v15

    const v9, 0x92492

    if-ne v4, v9, :cond_16

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_15

    goto :goto_e

    .line 173
    :cond_15
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v6, v11

    move v7, v14

    move/from16 v19, v15

    goto/16 :goto_1f

    .line 33
    :cond_16
    :goto_e
    if-eqz v6, :cond_17

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    move-object v6, v4

    .end local p5    # "modifier":Landroidx/compose/ui/Modifier;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_f

    .end local v4    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p5    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_17
    move-object v6, v11

    .end local p5    # "modifier":Landroidx/compose/ui/Modifier;
    .local v6, "modifier":Landroidx/compose/ui/Modifier;
    :goto_f
    if-eqz v12, :cond_18

    const/high16 v4, 0x3f800000    # 1.0f

    move v14, v4

    .end local p6    # "scale":F
    .local v14, "scale":F
    :cond_18
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_19

    const/4 v4, -0x1

    const-string v9, "org.lighttouch.android.PerformanceOverlay (PerformanceOverlay.kt:32)"

    invoke-static {v0, v15, v4, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 34
    :cond_19
    sget-object v0, Lorg/lighttouch/android/OverlayLevel;->OFF:Lorg/lighttouch/android/OverlayLevel;

    if-ne v2, v0, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1a
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_1b

    new-instance v0, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda2;

    move/from16 v9, p9

    move v4, v13

    move v7, v14

    .end local v14    # "scale":F
    .local v7, "scale":F
    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FII)V

    move v4, v7

    .end local v7    # "scale":F
    .local v4, "scale":F
    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_10

    .end local v4    # "scale":F
    .restart local v14    # "scale":F
    :cond_1b
    move v4, v14

    .end local v14    # "scale":F
    .restart local v4    # "scale":F
    :goto_10
    return-void

    .line 35
    .end local v4    # "scale":F
    .restart local v14    # "scale":F
    :cond_1c
    move v4, v14

    .end local v14    # "scale":F
    .restart local v4    # "scale":F
    invoke-static {}, Lorg/lighttouch/android/ThemeKt;->getMonoStyle()Landroidx/compose/ui/text/TextStyle;

    move-result-object v16

    const/16 v0, 0xb

    int-to-float v0, v0

    mul-float/2addr v0, v4

    invoke-static {v0}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(F)J

    move-result-wide v19

    const/16 v0, 0xe

    int-to-float v1, v0

    mul-float/2addr v1, v4

    invoke-static {v1}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(F)J

    move-result-wide v38

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v17

    const v46, 0xfdfffc

    const/16 v47, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const-wide/16 v26, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    invoke-static/range {v16 .. v47}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/graphics/drawscope/DrawStyle;IIJLandroidx/compose/ui/text/style/TextIndent;Landroidx/compose/ui/text/PlatformTextStyle;Landroidx/compose/ui/text/style/LineHeightStyle;IILandroidx/compose/ui/text/style/TextMotion;ILjava/lang/Object;)Landroidx/compose/ui/text/TextStyle;

    move-result-object v48

    .line 36
    .local v48, "text":Landroidx/compose/ui/text/TextStyle;
    const-string v1, "performance_overlay"

    invoke-static {v6, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 37
    sget-object v2, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/graphics/Color$Companion;->getBlack-0d7_KjU()J

    move-result-wide v11

    const/16 v17, 0xe

    const/16 v18, 0x0

    const/4 v14, 0x0

    move v2, v15

    .end local v15    # "$dirty":I
    .local v2, "$dirty":I
    const/4 v15, 0x0

    const/16 v16, 0x0

    move/from16 v13, p3

    move/from16 v19, v2

    .end local v2    # "$dirty":I
    .local v19, "$dirty":I
    invoke-static/range {v11 .. v18}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v8

    const/4 v2, 0x6

    int-to-float v5, v2

    mul-float v14, v5, v4

    .local v14, "$this$dp\\1":F
    const/4 v11, 0x0

    .line 114
    .local v11, "$i$f$getDp\\1\\37":I
    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 37
    .end local v11    # "$i$f$getDp\\1\\37":I
    .end local v14    # "$this$dp\\1":F
    invoke-static {v11}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v11

    check-cast v11, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v8, v9, v11}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 38
    mul-float/2addr v5, v4

    .local v5, "$this$dp\\2":F
    const/4 v8, 0x0

    .line 115
    .local v8, "$i$f$getDp\\2\\38":I
    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 38
    .end local v5    # "$this$dp\\2":F
    .end local v8    # "$i$f$getDp\\2\\38":I
    int-to-float v7, v7

    mul-float/2addr v7, v4

    .local v7, "$this$dp\\3":F
    const/4 v8, 0x0

    .line 115
    .local v8, "$i$f$getDp\\3\\38":I
    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 38
    .end local v7    # "$this$dp\\3":F
    .end local v8    # "$i$f$getDp\\3\\38":I
    invoke-static {v1, v5, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 36
    const/4 v5, 0x0

    move v7, v5

    .local v1, "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v7, "$changed\\4":I
    const/4 v8, 0x0

    .line 116
    .local v8, "$i$f$Column\\4\\36":I
    const v9, -0x1cd0f17e

    const-string v11, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v9, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 117
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 118
    .local v9, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v11

    .line 121
    .local v11, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v12, v7, 0x3

    and-int/2addr v12, v0

    shr-int/lit8 v13, v7, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v9, v11, v10, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v7, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 122
    nop

    .local v13, "$changed\\5":I
    const/4 v14, 0x0

    .line 123
    .local v14, "$i$f$Layout\\5\\122":I
    const v15, -0x4ee9b9da

    move/from16 p5, v0

    const-string v0, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 124
    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v15

    .line 125
    .local v15, "compositeKeyHash\\5":I
    move/from16 p6, v2

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 126
    .local v2, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 128
    .local v5, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v0, v13, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 127
    move/from16 v18, v0

    .local v18, "$changed\\6":I
    move-object/from16 v20, v16

    .local v20, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 129
    .local v16, "$i$f$ReusableComposeNode\\6\\127":I
    const v0, -0x2942ffcf

    move-object/from16 v21, v1

    .end local v1    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v21, "modifier\\4":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 130
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_1d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 131
    :cond_1d
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 132
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_1e

    .line 133
    move-object/from16 v1, v20

    .end local v20    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_11

    .line 135
    .end local v1    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :cond_1e
    move-object/from16 v1, v20

    .end local v20    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 137
    :goto_11
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 138
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\137\\5":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v1

    .end local v1    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 139
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v2, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 141
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 142
    .local v22, "$i$f$set-impl\\8\\141":I
    move-object/from16 v24, v0

    .local v24, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 143
    .local v25, "$i$a$-with-Updater$set$1\\9\\142\\8":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_20

    move-object/from16 v26, v2

    .end local v2    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v26, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v27, v4

    .end local v4    # "scale":F
    .local v27, "scale":F
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1f

    goto :goto_12

    :cond_1f
    move-object/from16 v4, v24

    goto :goto_13

    .end local v26    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v27    # "scale":F
    .restart local v2    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "scale":F
    :cond_20
    move-object/from16 v26, v2

    move/from16 v27, v4

    .line 144
    .end local v2    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "scale":F
    .restart local v26    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v27    # "scale":F
    :goto_12
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 145
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 147
    :goto_13
    nop

    .line 142
    .end local v4    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\9\\142\\8":I
    nop

    .line 147
    nop

    .line 148
    .end local v1    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\8\\141":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 149
    nop

    .line 137
    .end local v0    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\137\\5":I
    nop

    .line 150
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v1, v0, 0xe

    .local v1, "$changed\\10":I
    move-object v2, v10

    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 151
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\10\\150\\4":I
    const v0, -0x16ef5699

    move/from16 p5, v1

    .end local v1    # "$changed\\10":I
    .local p5, "$changed\\10":I
    const-string v1, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v1, v7, 0x6

    and-int/lit8 v1, v1, 0x70

    or-int/lit8 v1, v1, 0x6

    .local v1, "$changed\\11":I
    move-object/from16 v20, v0

    check-cast v20, Landroidx/compose/foundation/layout/ColumnScope;

    .local v20, "$this$PerformanceOverlay_u24lambda_u2414\\11":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v53, v2

    .local v53, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 39
    .local v22, "$i$a$-Column-PerformanceOverlayKt$PerformanceOverlay$2\\11\\151\\0":I
    const v0, 0x6ff2196f

    move/from16 p6, v1

    .end local v1    # "$changed\\11":I
    .local p6, "$changed\\11":I
    const-string v1, "C:PerformanceOverlay.kt#o13vsk"

    move-object/from16 v24, v2

    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v24, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 43
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getFps()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    const-string v25, "\u2013"

    if-lez v0, :cond_21

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getFps()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->f0(F)Ljava/lang/String;

    move-result-object v0

    goto :goto_14

    :cond_21
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getIdle()Z

    move-result v0

    if-eqz v0, :cond_22

    const-string v0, "idle"

    goto :goto_14

    :cond_22
    move-object/from16 v0, v25

    :goto_14
    move-object/from16 v28, v0

    .line 44
    .local v28, "fps\\11":Ljava/lang/String;
    sget-object v0, Lorg/lighttouch/android/PerformanceOverlayKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/OverlayLevel;->ordinal()I

    move-result v29

    aget v0, v0, v29

    move/from16 v29, v1

    const-string v1, "  "

    move/from16 v30, v0

    const-string v0, " \u6beb\u79d2"

    move/from16 v31, v4

    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\10\\150\\4":I
    .local v31, "$i$a$-Layout-ColumnKt$Column$1\\10\\150\\4":I
    const/4 v4, 0x1

    packed-switch v30, :pswitch_data_0

    .line 53
    move-object/from16 v17, v5

    move/from16 v30, v7

    move-object/from16 v5, v28

    move-object/from16 v28, v6

    move-object v6, v0

    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v7    # "$changed\\4":I
    .local v5, "fps\\11":Ljava/lang/String;
    .local v17, "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v28, "modifier":Landroidx/compose/ui/Modifier;
    .local v30, "$changed\\4":I
    const v7, 0x7000b31c

    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "53@2843L81,54@2941L139,55@3097L112,56@3226L319,61@3562L93,71@4298L223,*75@4561L48"

    invoke-static {v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 54
    sget-object v7, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v7}, Lorg/lighttouch/android/LtColors;->getOverlayFps-0d7_KjU()J

    move-result-wide v50

    move-object/from16 v53, v2

    move/from16 v35, v8

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v7, 0x2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$Column\\4\\36":I
    .local v35, "$i$f$Column\\4\\36":I
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v2, v4, v7, v0}, Lkotlin/text/StringsKt;->padStart$default(Ljava/lang/String;ICILjava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getFrameMs()F

    move-result v2

    invoke-static {v2}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "FPS"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 55
    sget-object v1, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtColors;->getOverlayFps-0d7_KjU()J

    move-result-wide v50

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getLowFps()F

    move-result v1

    cmpl-float v1, v1, v29

    if-lez v1, :cond_23

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getLowFps()F

    move-result v1

    invoke-static {v1}, Lorg/lighttouch/android/PerformanceOverlayKt;->f0(F)Ljava/lang/String;

    move-result-object v1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v7, 0x2

    invoke-static {v1, v2, v4, v7, v0}, Lkotlin/text/StringsKt;->padStart$default(Ljava/lang/String;ICILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getMaxFrameMs()F

    move-result v0

    invoke-static {v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "  \u6700\u5927 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_15

    .line 49
    .end local v17    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v30    # "$changed\\4":I
    .end local v35    # "$i$f$Column\\4\\36":I
    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v5, "materialized\\5":Landroidx/compose/ui/Modifier;
    .restart local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v7    # "$changed\\4":I
    .restart local v8    # "$i$f$Column\\4\\36":I
    .local v28, "fps\\11":Ljava/lang/String;
    :pswitch_0
    const v4, 0x6ffc0e17

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "49@2585L81,50@2683L107"

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 50
    sget-object v4, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v4}, Lorg/lighttouch/android/LtColors;->getOverlayFps-0d7_KjU()J

    move-result-wide v50

    move-object/from16 v53, v2

    move-object/from16 v17, v5

    move/from16 v30, v7

    move-object/from16 v4, v28

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x3

    move-object/from16 v28, v6

    move-object v6, v0

    const/4 v0, 0x0

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v5    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v7    # "$changed\\4":I
    .local v4, "fps\\11":Ljava/lang/String;
    .restart local v17    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v28, "modifier":Landroidx/compose/ui/Modifier;
    .restart local v30    # "$changed\\4":I
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v7, v0, v5, v2}, Lkotlin/text/StringsKt;->padStart$default(Ljava/lang/String;ICILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getFrameMs()F

    move-result v2

    invoke-static {v2}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "FPS"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 51
    move-object/from16 v2, v53

    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getIntervals()[F

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v1

    check-cast v32, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x2

    .local v1, "$this$dp\\18":I
    const/4 v5, 0x0

    .line 165
    .local v5, "$i$f$getDp\\18\\51":I
    int-to-float v6, v1

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v34

    .line 51
    .end local v1    # "$this$dp\\18":I
    .end local v5    # "$i$f$getDp\\18\\51":I
    const/16 v37, 0xd

    const/16 v38, 0x0

    const/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    invoke-static/range {v32 .. v38}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v5, 0x84

    int-to-float v5, v5

    mul-float v5, v5, v27

    .local v5, "$this$dp\\19":F
    const/4 v6, 0x0

    .line 166
    .local v6, "$i$f$getDp\\19\\51":I
    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 51
    .end local v5    # "$this$dp\\19":F
    .end local v6    # "$i$f$getDp\\19\\51":I
    const/16 v6, 0x1a

    int-to-float v6, v6

    mul-float v6, v6, v27

    .local v6, "$this$dp\\20":F
    const/4 v7, 0x0

    .line 166
    .local v7, "$i$f$getDp\\20\\51":I
    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 51
    .end local v6    # "$this$dp\\20":F
    .end local v7    # "$i$f$getDp\\20\\51":I
    invoke-static {v1, v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    shr-int/lit8 v5, v19, 0x3

    and-int/lit8 v5, v5, 0x70

    invoke-static {v0, v3, v1, v2, v5}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 49
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    move-object/from16 v29, v4

    move/from16 v35, v8

    goto/16 :goto_1e

    .line 45
    .end local v4    # "fps\\11":Ljava/lang/String;
    .end local v17    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v30    # "$changed\\4":I
    .local v5, "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v6, "modifier":Landroidx/compose/ui/Modifier;
    .local v7, "$changed\\4":I
    .local v28, "fps\\11":Ljava/lang/String;
    :pswitch_1
    move-object/from16 v17, v5

    move/from16 v30, v7

    move-object/from16 v5, v28

    move-object/from16 v28, v6

    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v7    # "$changed\\4":I
    .local v5, "fps\\11":Ljava/lang/String;
    .restart local v17    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v28, "modifier":Landroidx/compose/ui/Modifier;
    .restart local v30    # "$changed\\4":I
    const v1, 0x4def335a    # 5.0164E8f

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "44@2246L284"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v1, 0x0

    .line 152
    .local v1, "$i$f$buildAnnotatedString\\12\\45":I
    new-instance v6, Landroidx/compose/ui/text/AnnotatedString$Builder;

    const/4 v0, 0x0

    const/4 v7, 0x0

    invoke-direct {v6, v7, v4, v0}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v4, v6

    .local v4, "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245\\13":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/4 v7, 0x0

    .line 46
    .local v7, "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$1\\13\\152\\11":I
    new-instance v49, Landroidx/compose/ui/text/SpanStyle;

    sget-object v0, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v54

    const v70, 0xfffb

    const/16 v71, 0x0

    const-wide/16 v50, 0x0

    const-wide/16 v52, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const-wide/16 v59, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    invoke-direct/range {v49 .. v71}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/text/PlatformSpanStyle;Landroidx/compose/ui/graphics/drawscope/DrawStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 p7, v49

    .local p7, "style\\14":Landroidx/compose/ui/text/SpanStyle;
    move-object/from16 v25, v4

    .local v25, "$this$withStyle\\14":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/16 v29, 0x0

    .line 153
    .local v29, "$i$f$withStyle\\14\\46":I
    move-object/from16 v32, v25

    move-object/from16 v25, v2

    move-object/from16 v2, v32

    move/from16 v32, v1

    move-object/from16 v1, p7

    move-object/from16 p7, v4

    .end local v4    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245\\13":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .local v1, "style\\14":Landroidx/compose/ui/text/SpanStyle;
    .local v2, "$this$withStyle\\14":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .local v25, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v32, "$i$f$buildAnnotatedString\\12\\45":I
    .local p7, "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245\\13":Landroidx/compose/ui/text/AnnotatedString$Builder;
    invoke-virtual {v2, v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    move-result v4

    .line 154
    .local v4, "index\\14":I
    nop

    .line 155
    move-object v0, v2

    .local v0, "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245_u24lambda_u243\\15":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/16 v33, 0x0

    .line 46
    .local v33, "$i$a$-withStyle-PerformanceOverlayKt$PerformanceOverlay$2$1$1\\15\\155\\13":I
    :try_start_0
    invoke-virtual {v0, v5}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .end local v0    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245_u24lambda_u243\\15":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v33    # "$i$a$-withStyle-PerformanceOverlayKt$PerformanceOverlay$2$1$1\\15\\155\\13":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 155
    nop

    .line 157
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 158
    nop

    .line 154
    nop

    .line 47
    .end local v1    # "style\\14":Landroidx/compose/ui/text/SpanStyle;
    .end local v2    # "$this$withStyle\\14":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v4    # "index\\14":I
    .end local v29    # "$i$f$withStyle\\14\\46":I
    new-instance v49, Landroidx/compose/ui/text/SpanStyle;

    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayFps-0d7_KjU()J

    move-result-wide v50

    const/16 v0, 0x9

    int-to-float v0, v0

    mul-float v0, v0, v27

    invoke-static {v0}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(F)J

    move-result-wide v52

    const v70, 0xfffc

    const/16 v71, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const-wide/16 v59, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    invoke-direct/range {v49 .. v71}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/text/PlatformSpanStyle;Landroidx/compose/ui/graphics/drawscope/DrawStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object/from16 v1, v49

    .local v1, "style\\16":Landroidx/compose/ui/text/SpanStyle;
    move-object/from16 v2, p7

    .local v2, "$this$withStyle\\16":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/4 v4, 0x0

    .line 159
    .local v4, "$i$f$withStyle\\16\\47":I
    move/from16 v29, v4

    .end local v4    # "$i$f$withStyle\\16\\47":I
    .local v29, "$i$f$withStyle\\16\\47":I
    invoke-virtual {v2, v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    move-result v4

    .line 160
    .local v4, "index\\16":I
    nop

    .line 161
    move-object v0, v2

    .local v0, "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245_u24lambda_u244\\17":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/16 v33, 0x0

    .line 47
    .local v33, "$i$a$-withStyle-PerformanceOverlayKt$PerformanceOverlay$2$1$2\\17\\161\\13":I
    move-object/from16 v34, v1

    .end local v1    # "style\\16":Landroidx/compose/ui/text/SpanStyle;
    .local v34, "style\\16":Landroidx/compose/ui/text/SpanStyle;
    :try_start_1
    const-string v1, " FPS"

    invoke-virtual {v0, v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .end local v0    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245_u24lambda_u244\\17":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v33    # "$i$a$-withStyle-PerformanceOverlayKt$PerformanceOverlay$2$1$2\\17\\161\\13":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 161
    nop

    .line 163
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 164
    nop

    .line 160
    nop

    .line 48
    .end local v2    # "$this$withStyle\\16":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v4    # "index\\16":I
    .end local v29    # "$i$f$withStyle\\16\\47":I
    .end local v34    # "style\\16":Landroidx/compose/ui/text/SpanStyle;
    nop

    .line 152
    .end local v7    # "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$1\\13\\152\\11":I
    .end local p7    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245\\13":Landroidx/compose/ui/text/AnnotatedString$Builder;
    invoke-virtual {v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    move-result-object v0

    .line 48
    .end local v32    # "$i$f$buildAnnotatedString\\12\\45":I
    const/16 v1, 0xd

    int-to-float v1, v1

    mul-float v1, v1, v27

    invoke-static {v1}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(F)J

    move-result-wide v51

    const v78, 0xfffffd

    const/16 v79, 0x0

    const-wide/16 v49, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const-wide/16 v58, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const-wide/16 v63, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const-wide/16 v70, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    invoke-static/range {v48 .. v79}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/graphics/drawscope/DrawStyle;IIJLandroidx/compose/ui/text/style/TextIndent;Landroidx/compose/ui/text/PlatformTextStyle;Landroidx/compose/ui/text/style/LineHeightStyle;IILandroidx/compose/ui/text/style/TextMotion;ILjava/lang/Object;)Landroidx/compose/ui/text/TextStyle;

    move-result-object v70

    .line 45
    const/16 v50, 0x0

    const-wide/16 v51, 0x0

    const-wide/16 v53, 0x0

    const-wide/16 v62, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const v74, 0x1fffe

    move-object/from16 v49, v0

    move-object/from16 v71, v25

    .end local v25    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v49 .. v74}, Landroidx/compose/material3/TextKt;->Text-IbK3jfQ(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v53, v71

    .end local v71    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    move-object/from16 v29, v5

    move/from16 v35, v8

    goto/16 :goto_1e

    .line 163
    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$this$withStyle\\16":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .restart local v4    # "index\\16":I
    .restart local v7    # "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$1\\13\\152\\11":I
    .restart local v25    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$i$f$withStyle\\16\\47":I
    .restart local v32    # "$i$f$buildAnnotatedString\\12\\45":I
    .restart local v34    # "style\\16":Landroidx/compose/ui/text/SpanStyle;
    .restart local p7    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245\\13":Landroidx/compose/ui/text/AnnotatedString$Builder;
    :catchall_0
    move-exception v0

    move-object/from16 v53, v25

    .end local v25    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    throw v0

    .line 157
    .end local v34    # "style\\16":Landroidx/compose/ui/text/SpanStyle;
    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v1, "style\\14":Landroidx/compose/ui/text/SpanStyle;
    .local v2, "$this$withStyle\\14":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .local v4, "index\\14":I
    .restart local v25    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v29, "$i$f$withStyle\\14\\46":I
    :catchall_1
    move-exception v0

    move-object/from16 v53, v25

    .end local v25    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    throw v0

    .line 55
    .end local v1    # "style\\14":Landroidx/compose/ui/text/SpanStyle;
    .end local v2    # "$this$withStyle\\14":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v4    # "index\\14":I
    .end local v7    # "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$1\\13\\152\\11":I
    .end local v8    # "$i$f$Column\\4\\36":I
    .end local v29    # "$i$f$withStyle\\14\\46":I
    .end local v32    # "$i$f$buildAnnotatedString\\12\\45":I
    .end local p7    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u245\\13":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .restart local v35    # "$i$f$Column\\4\\36":I
    :cond_23
    const-string v0, "  \u2013"

    :goto_15
    move-object/from16 v52, v0

    const/16 v54, 0x36

    const-string v49, "1%"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 56
    move-object/from16 v2, v53

    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getIntervals()[F

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    .local v4, "$this$dp\\21":I
    const/4 v7, 0x0

    .line 167
    .local v7, "$i$f$getDp\\21\\56":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 56
    .end local v4    # "$this$dp\\21":I
    .end local v7    # "$i$f$getDp\\21\\56":I
    move/from16 v8, v29

    const/4 v7, 0x0

    move-object/from16 v29, v5

    const/4 v5, 0x1

    .end local v5    # "fps\\11":Ljava/lang/String;
    .local v29, "fps\\11":Ljava/lang/String;
    invoke-static {v1, v8, v4, v5, v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v4, 0xa8

    int-to-float v4, v4

    mul-float v4, v4, v27

    .local v4, "$this$dp\\22":F
    const/4 v5, 0x0

    .line 168
    .local v5, "$i$f$getDp\\22\\56":I
    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 56
    .end local v4    # "$this$dp\\22":F
    .end local v5    # "$i$f$getDp\\22\\56":I
    const/16 v5, 0x22

    int-to-float v5, v5

    mul-float v5, v5, v27

    .local v5, "$this$dp\\23":F
    const/4 v7, 0x0

    .line 168
    .local v7, "$i$f$getDp\\23\\56":I
    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 56
    .end local v5    # "$this$dp\\23":F
    .end local v7    # "$i$f$getDp\\23\\56":I
    invoke-static {v1, v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->size-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    shr-int/lit8 v4, v19, 0x3

    and-int/lit8 v4, v4, 0x70

    invoke-static {v0, v3, v1, v2, v4}, Lorg/lighttouch/android/PerformanceOverlayKt;->FrameGraph([FLorg/lighttouch/android/OverlayGraph;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 57
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayCpu-0d7_KjU()J

    move-result-wide v50

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object v1, v0

    .local v1, "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u248\\24":Ljava/lang/StringBuilder;
    const/4 v4, 0x0

    .line 58
    .local v4, "$i$a$-buildString-PerformanceOverlayKt$PerformanceOverlay$2$2\\24\\57\\11":I
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getVcpuPercent()Ljava/lang/Float;

    move-result-object v5

    if-eqz v5, :cond_24

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    move-result v5

    .line 169
    nop

    .local v5, "it\\25":F
    const/4 v7, 0x0

    .line 58
    .local v7, "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$2$1\\25\\58\\24":I
    invoke-static {v5}, Lorg/lighttouch/android/PerformanceOverlayKt;->f0(F)Ljava/lang/String;

    move-result-object v8

    move-object/from16 p7, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v8, "%"

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v5    # "it\\25":F
    .end local v7    # "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$2$1\\25\\58\\24":I
    if-nez v0, :cond_25

    goto :goto_16

    :cond_24
    move-object/from16 p7, v0

    :goto_16
    move-object/from16 v0, v25

    :cond_25
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u5ba2\u6237\u673a "

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getVcpuCore()Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_26

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getVcpuCore()Ljava/lang/Integer;

    move-result-object v0

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " \u00b7 CPU"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    :cond_26
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getVcpuMHz()Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_27

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    .line 169
    .local v0, "it\\26":I
    const/4 v5, 0x0

    .line 60
    .local v5, "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$2$2\\26\\60\\24":I
    int-to-float v7, v0

    const/high16 v8, 0x447a0000    # 1000.0f

    div-float/2addr v7, v8

    invoke-static {v7}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v33, v0

    .end local v0    # "it\\26":I
    .local v33, "it\\26":I
    const-string v0, " "

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v7, "GHz"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .end local v5    # "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$2$2\\26\\60\\24":I
    .end local v33    # "it\\26":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 61
    :cond_27
    nop

    .end local v1    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u248\\24":Ljava/lang/StringBuilder;
    .end local v4    # "$i$a$-buildString-PerformanceOverlayKt$PerformanceOverlay$2$2\\24\\57\\11":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 57
    invoke-virtual/range {p7 .. p7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "CPU"

    move-object/from16 v53, v2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 62
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayCpu-0d7_KjU()J

    move-result-wide v50

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getWorkerPercent()Ljava/lang/Float;

    move-result-object v0

    if-eqz v0, :cond_28

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    .line 169
    nop

    .local v0, "it\\27":F
    const/4 v1, 0x0

    .line 62
    .local v1, "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$3\\27\\62\\11":I
    invoke-static {v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->f0(F)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "%"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v0    # "it\\27":F
    .end local v1    # "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$3\\27\\62\\11":I
    if-nez v0, :cond_29

    :cond_28
    move-object/from16 v0, v25

    :cond_29
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u5f15\u64ce "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, ""

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 63
    move-object/from16 v2, v53

    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getDetailedAvailable()Z

    move-result v0

    if-eqz v0, :cond_2d

    const v0, 0x700d4efc

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "63@3726L81,64@3828L84,65@3933L81"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 64
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayGpu-0d7_KjU()J

    move-result-wide v50

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getGlMsPerFrame()Ljava/lang/Float;

    move-result-object v0

    if-eqz v0, :cond_2a

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    goto :goto_17

    :cond_2a
    const/4 v0, 0x0

    :goto_17
    invoke-static {v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "GL "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ms/frame"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "GPU"

    move-object/from16 v53, v2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 65
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayGpu-0d7_KjU()J

    move-result-wide v50

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getBqlMsPerFrame()Ljava/lang/Float;

    move-result-object v0

    if-eqz v0, :cond_2b

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    goto :goto_18

    :cond_2b
    const/4 v0, 0x0

    :goto_18
    invoke-static {v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "BQL "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " ms/frame"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "LOCK"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 66
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayCpu-0d7_KjU()J

    move-result-wide v50

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getRunPercent()Ljava/lang/Float;

    move-result-object v0

    if-eqz v0, :cond_2c

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v1

    goto :goto_19

    :cond_2c
    const/4 v1, 0x0

    :goto_19
    invoke-static {v1}, Lorg/lighttouch/android/PerformanceOverlayKt;->f0(F)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "vCPU "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u5360\u5b9e\u9645\u65f6\u95f4 %"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "RUN"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 63
    move-object/from16 v2, v53

    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_1b

    .line 67
    :cond_2d
    const v0, 0x4df01331    # 5.034737E8f

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "66@4038L243"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayGpu-0d7_KjU()J

    move-result-wide v50

    .line 68
    if-nez p4, :cond_2e

    const-string v0, "\u8be6\u7ec6\u8ba1\u65f6\u5df2\u5173\u95ed"

    move-object/from16 v52, v0

    goto :goto_1a

    .line 69
    :cond_2e
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getDetailedError()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_2f

    const-string v0, "\u8ba1\u65f6\u4e0d\u53ef\u7528"

    move-object/from16 v52, v0

    goto :goto_1a

    .line 70
    :cond_2f
    const-string v0, "\u7b49\u5f85\u5e27\u6570\u636e\u2026"

    move-object/from16 v52, v0

    :goto_1a
    nop

    .line 67
    const-string v49, "GPU"

    const/16 v54, 0x36

    move-object/from16 v53, v2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 72
    :goto_1b
    sget-object v0, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtColors;->getOverlayLabel-0d7_KjU()J

    move-result-wide v50

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    move-object v1, v0

    .local v1, "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u2412\\28":Ljava/lang/StringBuilder;
    const/4 v2, 0x0

    .line 73
    .local v2, "$i$a$-buildString-PerformanceOverlayKt$PerformanceOverlay$2$4\\28\\72\\11":I
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getPresentMs()Ljava/lang/Float;

    move-result-object v4

    if-eqz v4, :cond_30

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    .line 169
    nop

    .local v4, "it\\29":F
    const/4 v5, 0x0

    .line 73
    .local v5, "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$4$1\\29\\73\\28":I
    invoke-static {v4}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .end local v4    # "it\\29":F
    .end local v5    # "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$4$1\\29\\73\\28":I
    if-nez v4, :cond_31

    :cond_30
    move-object/from16 v4, v25

    :cond_31
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getLatencyMs()Ljava/lang/Float;

    move-result-object v4

    if-eqz v4, :cond_32

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    move-result v4

    .line 169
    .local v4, "it\\30":F
    const/4 v5, 0x0

    .line 74
    .local v5, "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$4$2\\30\\74\\28":I
    invoke-static {v4}, Lorg/lighttouch/android/PerformanceOverlayKt;->f1(F)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 p7, v0

    const-string v0, " \u00b7 \u5ef6\u8fdf "

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .end local v4    # "it\\30":F
    .end local v5    # "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$4$2\\30\\74\\28":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    goto :goto_1c

    :cond_32
    move-object/from16 p7, v0

    .line 75
    :goto_1c
    nop

    .end local v1    # "$this$PerformanceOverlay_u24lambda_u2414_u24lambda_u2412\\28":Ljava/lang/StringBuilder;
    .end local v2    # "$i$a$-buildString-PerformanceOverlayKt$PerformanceOverlay$2$4\\28\\72\\11":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 72
    invoke-virtual/range {p7 .. p7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "PRES"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 76
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/PerfSnapshot;->getPssMiB()Ljava/lang/Float;

    move-result-object v0

    if-nez v0, :cond_33

    goto :goto_1d

    :cond_33
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    .line 169
    .local v0, "it\\31":F
    const/4 v1, 0x0

    .line 76
    .local v1, "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$5\\31\\76\\11":I
    sget-object v2, Lorg/lighttouch/android/LtColors;->INSTANCE:Lorg/lighttouch/android/LtColors;

    invoke-virtual {v2}, Lorg/lighttouch/android/LtColors;->getOverlayMem-0d7_KjU()J

    move-result-wide v50

    invoke-static {v0}, Lorg/lighttouch/android/PerformanceOverlayKt;->f0(F)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " MiB"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v52

    const/16 v54, 0x36

    const-string v49, "MEM"

    invoke-static/range {v48 .. v54}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .end local v0    # "it\\31":F
    .end local v1    # "$i$a$-let-PerformanceOverlayKt$PerformanceOverlay$2$5\\31\\76\\11":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 53
    :goto_1d
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 39
    :goto_1e
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 79
    .end local v29    # "fps\\11":Ljava/lang/String;
    nop

    .line 151
    .end local v20    # "$this$PerformanceOverlay_u24lambda_u2414\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v22    # "$i$a$-Column-PerformanceOverlayKt$PerformanceOverlay$2\\11\\151\\0":I
    .end local v53    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local p6    # "$changed\\11":I
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 150
    .end local v24    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-Layout-ColumnKt$Column$1\\10\\150\\4":I
    .end local p5    # "$changed\\10":I
    nop

    .line 170
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 129
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 171
    nop

    .line 123
    .end local v16    # "$i$f$ReusableComposeNode\\6\\127":I
    .end local v18    # "$changed\\6":I
    .end local v23    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 172
    nop

    .line 116
    .end local v13    # "$changed\\5":I
    .end local v14    # "$i$f$Layout\\5\\122":I
    .end local v15    # "compositeKeyHash\\5":I
    .end local v17    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v26    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 173
    nop

    .end local v9    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v11    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v12    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v21    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v30    # "$changed\\4":I
    .end local v35    # "$i$f$Column\\4\\36":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_34

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v48    # "text":Landroidx/compose/ui/text/TextStyle;
    :cond_34
    move/from16 v7, v27

    move-object/from16 v6, v28

    .end local v27    # "scale":F
    .end local v28    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .local v7, "scale":F
    :goto_1f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_35

    new-instance v0, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda3;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v8, p8

    move/from16 v9, p9

    invoke-direct/range {v0 .. v9}, Lorg/lighttouch/android/PerformanceOverlayKt$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FII)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 80
    :cond_35
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static final PerformanceOverlay$lambda$0(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move v5, p4

    move-object/from16 v6, p5

    move/from16 v7, p6

    move/from16 v10, p8

    move-object/from16 v8, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PerformanceOverlay$lambda$14$row(Landroidx/compose/ui/text/TextStyle;Ljava/lang/String;JLjava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 31
    .param p0, "text"    # Landroidx/compose/ui/text/TextStyle;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "color"    # J
    .param p4, "value"    # Ljava/lang/String;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v1, p5

    const v0, -0x55c074bd

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "C(row)P(1,0:c#ui.graphics.Color)38@1895L198:PerformanceOverlay.kt#o13vsk"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.PerformanceOverlay.<anonymous>.row (PerformanceOverlay.kt:38)"

    move/from16 v4, p6

    invoke-static {v0, v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    goto :goto_0

    :cond_0
    move/from16 v4, p6

    .line 39
    :goto_0
    const/4 v2, 0x0

    .line 180
    .local v2, "$i$f$buildAnnotatedString\\1\\39":I
    new-instance v0, Landroidx/compose/ui/text/AnnotatedString$Builder;

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v0, v5, v3, v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    move-object v3, v0

    .local v3, "$this$PerformanceOverlay_u24lambda_u2414_u24row_u24lambda_u242\\2":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/4 v7, 0x0

    .line 40
    .local v7, "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$row$1\\2\\180\\0":I
    new-instance v8, Landroidx/compose/ui/text/SpanStyle;

    sget-object v9, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v13

    const v29, 0xfffa

    const/16 v30, 0x0

    const-wide/16 v11, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const-wide/16 v18, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const-wide/16 v23, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    move-wide/from16 v9, p2

    invoke-direct/range {v8 .. v30}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/text/PlatformSpanStyle;Landroidx/compose/ui/graphics/drawscope/DrawStyle;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .local v8, "style\\3":Landroidx/compose/ui/text/SpanStyle;
    move-object v9, v3

    .local v9, "$this$withStyle\\3":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/4 v10, 0x0

    .line 181
    .local v10, "$i$f$withStyle\\3\\40":I
    invoke-virtual {v9, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    move-result v11

    .line 182
    .local v11, "index\\3":I
    nop

    .line 183
    move-object v12, v9

    .local v12, "$this$PerformanceOverlay_u24lambda_u2414_u24row_u24lambda_u242_u24lambda_u241\\4":Landroidx/compose/ui/text/AnnotatedString$Builder;
    const/4 v13, 0x0

    .line 40
    .local v13, "$i$a$-withStyle-PerformanceOverlayKt$PerformanceOverlay$2$row$1$1\\4\\183\\2":I
    const/4 v14, 0x5

    const/4 v15, 0x2

    move-object/from16 v1, p1

    :try_start_0
    invoke-static {v1, v14, v5, v15, v6}, Lkotlin/text/StringsKt;->padEnd$default(Ljava/lang/String;ICILjava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v12, v5}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .end local v12    # "$this$PerformanceOverlay_u24lambda_u2414_u24row_u24lambda_u242_u24lambda_u241\\4":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v13    # "$i$a$-withStyle-PerformanceOverlayKt$PerformanceOverlay$2$row$1$1\\4\\183\\2":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 183
    nop

    .line 185
    invoke-virtual {v9, v11}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 186
    nop

    .line 182
    nop

    .line 41
    .end local v8    # "style\\3":Landroidx/compose/ui/text/SpanStyle;
    .end local v9    # "$this$withStyle\\3":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v10    # "$i$f$withStyle\\3\\40":I
    .end local v11    # "index\\3":I
    move-object/from16 v5, p4

    invoke-virtual {v3, v5}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 42
    nop

    .line 180
    .end local v3    # "$this$PerformanceOverlay_u24lambda_u2414_u24row_u24lambda_u242\\2":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .end local v7    # "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$row$1\\2\\180\\0":I
    invoke-virtual {v0}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    move-result-object v0

    .line 39
    .end local v2    # "$i$f$buildAnnotatedString\\1\\39":I
    nop

    .line 42
    nop

    .line 39
    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v9, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x1

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x0

    const/16 v24, 0xc00

    const v25, 0x1dffe

    move-object/from16 v21, p0

    move-object/from16 v22, p5

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-IbK3jfQ(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 42
    return-void

    .line 185
    .restart local v2    # "$i$f$buildAnnotatedString\\1\\39":I
    .restart local v3    # "$this$PerformanceOverlay_u24lambda_u2414_u24row_u24lambda_u242\\2":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .restart local v7    # "$i$a$-buildAnnotatedString-PerformanceOverlayKt$PerformanceOverlay$2$row$1\\2\\180\\0":I
    .restart local v8    # "style\\3":Landroidx/compose/ui/text/SpanStyle;
    .restart local v9    # "$this$withStyle\\3":Landroidx/compose/ui/text/AnnotatedString$Builder;
    .restart local v10    # "$i$f$withStyle\\3\\40":I
    .restart local v11    # "index\\3":I
    :catchall_0
    move-exception v0

    invoke-virtual {v9, v11}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    throw v0
.end method

.method private static final PerformanceOverlay$lambda$15(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 11

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move v5, p4

    move-object/from16 v6, p5

    move/from16 v7, p6

    move/from16 v10, p8

    move-object/from16 v8, p9

    invoke-static/range {v1 .. v10}, Lorg/lighttouch/android/PerformanceOverlayKt;->PerformanceOverlay(Lorg/lighttouch/android/PerfSnapshot;Lorg/lighttouch/android/OverlayLevel;Lorg/lighttouch/android/OverlayGraph;FZLandroidx/compose/ui/Modifier;FLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final f0(F)Ljava/lang/String;
    .locals 3
    .param p0, "value"    # F

    .line 25
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.0f"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method private static final f1(F)Ljava/lang/String;
    .locals 3
    .param p0, "value"    # F

    .line 24
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.1f"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.method public static final of(Landroidx/compose/ui/Alignment$Companion;Lorg/lighttouch/android/OverlayCorner;)Landroidx/compose/ui/Alignment;
    .locals 2
    .param p0, "$this$of"    # Landroidx/compose/ui/Alignment$Companion;
    .param p1, "corner"    # Lorg/lighttouch/android/OverlayCorner;

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "corner"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    sget-object v0, Lorg/lighttouch/android/PerformanceOverlayKt$WhenMappings;->$EnumSwitchMapping$1:[I

    invoke-virtual {p1}, Lorg/lighttouch/android/OverlayCorner;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    .line 111
    :pswitch_0
    invoke-virtual {p0}, Landroidx/compose/ui/Alignment$Companion;->getBottomEnd()Landroidx/compose/ui/Alignment;

    move-result-object v0

    goto :goto_0

    :pswitch_1
    invoke-virtual {p0}, Landroidx/compose/ui/Alignment$Companion;->getBottomStart()Landroidx/compose/ui/Alignment;

    move-result-object v0

    goto :goto_0

    .line 110
    :pswitch_2
    invoke-virtual {p0}, Landroidx/compose/ui/Alignment$Companion;->getTopEnd()Landroidx/compose/ui/Alignment;

    move-result-object v0

    goto :goto_0

    :pswitch_3
    invoke-virtual {p0}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v0

    .line 112
    :goto_0
    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

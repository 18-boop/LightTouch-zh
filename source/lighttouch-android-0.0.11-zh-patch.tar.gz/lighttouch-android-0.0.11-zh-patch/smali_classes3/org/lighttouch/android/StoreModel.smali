.class public final Lorg/lighttouch/android/StoreModel;
.super Ljava/lang/Object;
.source "StoreScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreModel\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,586:1\n81#2:587\n107#2,2:588\n81#2:590\n107#2,2:591\n81#2:593\n107#2,2:594\n81#2:596\n107#2,2:597\n81#2:599\n107#2,2:600\n81#2:602\n107#2,2:603\n81#2:605\n107#2,2:606\n81#2:608\n107#2,2:609\n81#2:611\n107#2,2:612\n81#2:614\n107#2,2:615\n81#2:617\n107#2,2:618\n81#2:620\n107#2,2:621\n81#2:623\n107#2,2:624\n81#2:626\n107#2,2:627\n81#2:629\n107#2,2:630\n81#2:632\n107#2,2:633\n81#2:635\n107#2,2:636\n81#2:638\n107#2,2:639\n1761#3,3:641\n295#3,2:645\n295#3,2:647\n1193#3,2:649\n1267#3,4:651\n295#3,2:655\n360#3,7:657\n785#3:664\n796#3:665\n1878#3,2:666\n797#3,2:668\n1880#3:670\n799#3:671\n1#4:644\n*S KotlinDebug\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreModel\n*L\n81#1:587\n81#1:588,2\n82#1:590\n82#1:591,2\n83#1:593\n83#1:594,2\n84#1:596\n84#1:597,2\n85#1:599\n85#1:600,2\n86#1:602\n86#1:603,2\n87#1:605\n87#1:606,2\n88#1:608\n88#1:609,2\n89#1:611\n89#1:612,2\n90#1:614\n90#1:615,2\n91#1:617\n91#1:618,2\n92#1:620\n92#1:621,2\n94#1:623\n94#1:624,2\n101#1:626\n101#1:627,2\n102#1:629\n102#1:630,2\n103#1:632\n103#1:633,2\n104#1:635\n104#1:636,2\n105#1:638\n105#1:639,2\n110#1:641,3\n198#1:645,2\n225#1:647,2\n96#1:649,2\n96#1:651,4\n183#1:655,2\n246#1:657,7\n247#1:664\n247#1:665\n247#1:666,2\n247#1:668,2\n247#1:670\n247#1:671\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00b0\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000b\n\u0002\u0008\u000c\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0018\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0002\u0008\u000e\n\u0002\u0010$\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008!\n\u0002\u0018\u0002\n\u0002\u0008\t\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\t\n\u0002\u0008\u0004\u0008\u0001\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000e\u0010\u0004\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005\u0012\u000e\u0008\u0002\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0005\u00a2\u0006\u0004\u0008\t\u0010\nJ!\u0010\u0084\u0001\u001a\u00020\u00082\u0007\u0010\u0085\u0001\u001a\u00020\u00062\r\u0010\u0086\u0001\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0005H\u0002J\u0018\u0010\u0087\u0001\u001a\u00020\u001a2\r\u0010\u0086\u0001\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0005H\u0002J\u001b\u0010\u0089\u0001\u001a\u00020\u00082\u0007\u0010\u008a\u0001\u001a\u00020\u00062\t\u0010\u008b\u0001\u001a\u0004\u0018\u00010\u0012J\u0007\u0010\u008c\u0001\u001a\u00020\u0008J\u0007\u0010\u008d\u0001\u001a\u00020\u0008J\u0007\u0010\u008e\u0001\u001a\u00020\u0008J\u0010\u0010\u008f\u0001\u001a\u00020\u00082\u0007\u0010\u0090\u0001\u001a\u00020(J\u0007\u0010\u0091\u0001\u001a\u00020\u0008J\u0011\u0010\u0092\u0001\u001a\u00020\u00082\u0008\u0010\u0090\u0001\u001a\u00030\u0093\u0001J\u0012\u0010\u0094\u0001\u001a\u0004\u0018\u00010q2\u0007\u0010\u0095\u0001\u001a\u00020\u0006J\u0010\u0010\u0096\u0001\u001a\u00020\u00082\u0007\u0010\u0097\u0001\u001a\u00020FJ\u0012\u0010\u0098\u0001\u001a\u00020\u00062\u0007\u0010\u0090\u0001\u001a\u00020(H\u0002J\u0012\u0010\u0099\u0001\u001a\u0004\u0018\u00010q2\u0007\u0010\u0090\u0001\u001a\u00020(J%\u0010\u009a\u0001\u001a\u00020\u00082\u0007\u0010\u009b\u0001\u001a\u00020\u00062\u0007\u0010\u0085\u0001\u001a\u00020\u00062\u0008\u0010\u009c\u0001\u001a\u00030\u009d\u0001H\u0002J\u0010\u0010\u009e\u0001\u001a\u00020\u00082\u0007\u0010\u0090\u0001\u001a\u00020(J\u0011\u0010\u009f\u0001\u001a\u00020\u00082\u0008\u0010\u00a0\u0001\u001a\u00030\u00a1\u0001J\u0007\u0010\u00a2\u0001\u001a\u00020\u0008J\u0007\u0010\u00a3\u0001\u001a\u00020\u0008J\u0011\u0010\u00a4\u0001\u001a\u00020\u00082\u0008\u0010\u008a\u0001\u001a\u00030\u00a5\u0001J\u0011\u0010\u00a6\u0001\u001a\u00020\u00082\u0008\u0010\u008a\u0001\u001a\u00030\u00a5\u0001J\u0011\u0010\u00a7\u0001\u001a\u00020\u00082\u0008\u0010\u008a\u0001\u001a\u00030\u00a5\u0001J\u0007\u0010\u00a8\u0001\u001a\u00020\u0008R\u0016\u0010\u0004\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R/\u0010\u0013\u001a\u0004\u0018\u00010\u00122\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u00128F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u0018\u0010\u0019\u001a\u0004\u0008\u0014\u0010\u0015\"\u0004\u0008\u0016\u0010\u0017R+\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u001a8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008 \u0010\u0019\u001a\u0004\u0008\u001c\u0010\u001d\"\u0004\u0008\u001e\u0010\u001fR+\u0010!\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00068F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008&\u0010\u0019\u001a\u0004\u0008\"\u0010#\"\u0004\u0008$\u0010%R7\u0010)\u001a\u0008\u0012\u0004\u0012\u00020(0\'2\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020(0\'8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008.\u0010\u0019\u001a\u0004\u0008*\u0010+\"\u0004\u0008,\u0010-R+\u0010/\u001a\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u001a8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u00082\u0010\u0019\u001a\u0004\u00080\u0010\u001d\"\u0004\u00081\u0010\u001fR+\u00103\u001a\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u001a8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u00086\u0010\u0019\u001a\u0004\u00084\u0010\u001d\"\u0004\u00085\u0010\u001fR+\u00107\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00068F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008:\u0010\u0019\u001a\u0004\u00088\u0010#\"\u0004\u00089\u0010%R/\u0010;\u001a\u0004\u0018\u00010(2\u0008\u0010\u0011\u001a\u0004\u0018\u00010(8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008@\u0010\u0019\u001a\u0004\u0008<\u0010=\"\u0004\u0008>\u0010?R;\u0010B\u001a\n\u0012\u0004\u0012\u00020A\u0018\u00010\'2\u000e\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020A\u0018\u00010\'8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008E\u0010\u0019\u001a\u0004\u0008C\u0010+\"\u0004\u0008D\u0010-R/\u0010G\u001a\u0004\u0018\u00010F2\u0008\u0010\u0011\u001a\u0004\u0018\u00010F8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008L\u0010\u0019\u001a\u0004\u0008H\u0010I\"\u0004\u0008J\u0010KR/\u0010M\u001a\u0004\u0018\u00010\u00062\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u00068F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008P\u0010\u0019\u001a\u0004\u0008N\u0010#\"\u0004\u0008O\u0010%R/\u0010Q\u001a\u0004\u0018\u00010(2\u0008\u0010\u0011\u001a\u0004\u0018\u00010(8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008T\u0010\u0019\u001a\u0004\u0008R\u0010=\"\u0004\u0008S\u0010?RC\u0010V\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060U2\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060U8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008[\u0010\u0019\u001a\u0004\u0008W\u0010X\"\u0004\u0008Y\u0010ZR\u0011\u0010\\\u001a\u00020]\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008^\u0010_R\u0011\u0010`\u001a\u00020a\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008b\u0010cR\u0011\u0010d\u001a\u00020e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008f\u0010gR/\u0010h\u001a\u0004\u0018\u00010(2\u0008\u0010\u0011\u001a\u0004\u0018\u00010(8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008k\u0010\u0019\u001a\u0004\u0008i\u0010=\"\u0004\u0008j\u0010?R7\u0010m\u001a\u0008\u0012\u0004\u0012\u00020l0\'2\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020l0\'8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008p\u0010\u0019\u001a\u0004\u0008n\u0010+\"\u0004\u0008o\u0010-R7\u0010r\u001a\u0008\u0012\u0004\u0012\u00020q0\'2\u000c\u0010\u0011\u001a\u0008\u0012\u0004\u0012\u00020q0\'8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008u\u0010\u0019\u001a\u0004\u0008s\u0010+\"\u0004\u0008t\u0010-R+\u0010v\u001a\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u001a8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008y\u0010\u0019\u001a\u0004\u0008w\u0010\u001d\"\u0004\u0008x\u0010\u001fR/\u0010z\u001a\u0004\u0018\u00010\u00062\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u00068F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008}\u0010\u0019\u001a\u0004\u0008{\u0010#\"\u0004\u0008|\u0010%R\u000e\u0010~\u001a\u00020FX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u007f\u001a\u00020FX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0013\u0010\u0080\u0001\u001a\u00020\u001a8F\u00a2\u0006\u0007\u001a\u0005\u0008\u0081\u0001\u0010\u001dR\u0013\u0010\u0082\u0001\u001a\u00020\u001a8F\u00a2\u0006\u0007\u001a\u0005\u0008\u0083\u0001\u0010\u001dR\u000f\u0010\u0088\u0001\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u00a9\u0001"
    }
    d2 = {
        "Lorg/lighttouch/android/StoreModel;",
        "",
        "context",
        "Landroid/content/Context;",
        "muxSocket",
        "Lkotlin/Function0;",
        "",
        "askNotifications",
        "",
        "<init>",
        "(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V",
        "handler",
        "Landroid/os/Handler;",
        "apps",
        "Lorg/lighttouch/android/GuestApps;",
        "installer",
        "Lorg/lighttouch/android/StoreInstaller;",
        "<set-?>",
        "Lorg/lighttouch/android/StoreTarget;",
        "target",
        "getTarget",
        "()Lorg/lighttouch/android/StoreTarget;",
        "setTarget",
        "(Lorg/lighttouch/android/StoreTarget;)V",
        "target$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "",
        "targetConfirmed",
        "getTargetConfirmed",
        "()Z",
        "setTargetConfirmed",
        "(Z)V",
        "targetConfirmed$delegate",
        "query",
        "getQuery",
        "()Ljava/lang/String;",
        "setQuery",
        "(Ljava/lang/String;)V",
        "query$delegate",
        "",
        "Lorg/json/JSONObject;",
        "results",
        "getResults",
        "()Ljava/util/List;",
        "setResults",
        "(Ljava/util/List;)V",
        "results$delegate",
        "showIncompatible",
        "getShowIncompatible",
        "setShowIncompatible",
        "showIncompatible$delegate",
        "searching",
        "getSearching",
        "setSearching",
        "searching$delegate",
        "message",
        "getMessage",
        "setMessage",
        "message$delegate",
        "chosen",
        "getChosen",
        "()Lorg/json/JSONObject;",
        "setChosen",
        "(Lorg/json/JSONObject;)V",
        "chosen$delegate",
        "Lorg/lighttouch/android/StoreCopy;",
        "copies",
        "getCopies",
        "setCopies",
        "copies$delegate",
        "",
        "selected",
        "getSelected",
        "()Ljava/lang/Integer;",
        "setSelected",
        "(Ljava/lang/Integer;)V",
        "selected$delegate",
        "problem",
        "getProblem",
        "setProblem",
        "problem$delegate",
        "candidate",
        "getCandidate",
        "setCandidate",
        "candidate$delegate",
        "",
        "installed",
        "getInstalled",
        "()Ljava/util/Map;",
        "setInstalled",
        "(Ljava/util/Map;)V",
        "installed$delegate",
        "installedList",
        "Lorg/lighttouch/android/InstalledList;",
        "getInstalledList",
        "()Lorg/lighttouch/android/InstalledList;",
        "browser",
        "Lorg/lighttouch/android/StoreBrowser;",
        "getBrowser",
        "()Lorg/lighttouch/android/StoreBrowser;",
        "resultsList",
        "Landroidx/compose/foundation/lazy/LazyListState;",
        "getResultsList",
        "()Landroidx/compose/foundation/lazy/LazyListState;",
        "info",
        "getInfo",
        "setInfo",
        "info$delegate",
        "Lorg/lighttouch/android/StoreShot;",
        "shots",
        "getShots",
        "setShots",
        "shots$delegate",
        "Lorg/lighttouch/android/QueueItem;",
        "queue",
        "getQueue",
        "setQueue",
        "queue$delegate",
        "searchOpen",
        "getSearchOpen",
        "setSearchOpen",
        "searchOpen$delegate",
        "crash",
        "getCrash",
        "setCrash",
        "crash$delegate",
        "searchGeneration",
        "checkGeneration",
        "servicesAvailable",
        "getServicesAvailable",
        "installing",
        "getInstalling",
        "background",
        "name",
        "work",
        "post",
        "recordId",
        "useRecord",
        "id",
        "next",
        "guestChanged",
        "refreshGuest",
        "search",
        "open",
        "app",
        "close",
        "openInstalled",
        "Lorg/lighttouch/android/InstalledApp;",
        "queuedBundle",
        "bundleId",
        "choose",
        "ipaId",
        "queueKey",
        "queued",
        "enqueue",
        "key",
        "request",
        "Lorg/lighttouch/android/InstallRequest;",
        "install",
        "installLocal",
        "uri",
        "Landroid/net/Uri;",
        "showLastCrash",
        "closeSearch",
        "cancel",
        "",
        "retry",
        "dismiss",
        "clearFinished",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final apps:Lorg/lighttouch/android/GuestApps;

.field private final askNotifications:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final browser:Lorg/lighttouch/android/StoreBrowser;

.field private final candidate$delegate:Landroidx/compose/runtime/MutableState;

.field private checkGeneration:I

.field private final chosen$delegate:Landroidx/compose/runtime/MutableState;

.field private final copies$delegate:Landroidx/compose/runtime/MutableState;

.field private final crash$delegate:Landroidx/compose/runtime/MutableState;

.field private final handler:Landroid/os/Handler;

.field private final info$delegate:Landroidx/compose/runtime/MutableState;

.field private final installed$delegate:Landroidx/compose/runtime/MutableState;

.field private final installedList:Lorg/lighttouch/android/InstalledList;

.field private final installer:Lorg/lighttouch/android/StoreInstaller;

.field private final message$delegate:Landroidx/compose/runtime/MutableState;

.field private final muxSocket:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final problem$delegate:Landroidx/compose/runtime/MutableState;

.field private final query$delegate:Landroidx/compose/runtime/MutableState;

.field private final queue$delegate:Landroidx/compose/runtime/MutableState;

.field private recordId:Ljava/lang/String;

.field private final results$delegate:Landroidx/compose/runtime/MutableState;

.field private final resultsList:Landroidx/compose/foundation/lazy/LazyListState;

.field private searchGeneration:I

.field private final searchOpen$delegate:Landroidx/compose/runtime/MutableState;

.field private final searching$delegate:Landroidx/compose/runtime/MutableState;

.field private final selected$delegate:Landroidx/compose/runtime/MutableState;

.field private final shots$delegate:Landroidx/compose/runtime/MutableState;

.field private final showIncompatible$delegate:Landroidx/compose/runtime/MutableState;

.field private final target$delegate:Landroidx/compose/runtime/MutableState;

.field private final targetConfirmed$delegate:Landroidx/compose/runtime/MutableState;


# direct methods
.method public static synthetic $r8$lambda$3UnW5k390SD1KLoAXDIV-y0BlP8(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreModel;->open$lambda$33$lambda$32(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4-4Fxcu4r7PBhchER90KTQjt2mU(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->showLastCrash$lambda$50$lambda$49(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$5vw5PyCZ6H-qFB-wDnHi71U-1fg()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/StoreModel;->_init_$lambda$0()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$6KbmGv9tJSU8iyuQIZYZgDZw120(Lorg/lighttouch/android/StoreModel;Ljava/lang/Exception;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->refreshGuest$lambda$13$lambda$12(Lorg/lighttouch/android/StoreModel;Ljava/lang/Exception;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6hLQ4sPgYeYYNqCJE5lSAuGp5Og(Lorg/lighttouch/android/StoreModel;)Lorg/lighttouch/android/StoreTarget;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreModel;->browser$lambda$5(Lorg/lighttouch/android/StoreModel;)Lorg/lighttouch/android/StoreTarget;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9qieuSGIK3CxtqVZ1Wu4TZzYrWs(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreModel;->post$lambda$10(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$E8p_u_JqEX0iGou7DzAwpKVJCL8(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Ljava/util/List;Lorg/lighttouch/android/StoreTarget;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreModel;->refreshGuest$lambda$13$lambda$11(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Ljava/util/List;Lorg/lighttouch/android/StoreTarget;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JEXiupTkMqTeNuVICcemFpUtHpY(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreModel;->open$lambda$23$lambda$22$lambda$21(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ks0LZplpesgnpFj3tgV1SH53rhI(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->open$lambda$27(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ot-dBlWST7cMXd5G-DNwlt295C4(Lorg/lighttouch/android/StoreModel;)Z
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreModel;->installedList$lambda$2(Lorg/lighttouch/android/StoreModel;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$V3ujf5QOOlYhb03UNdfgwSJk_Ds(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->showLastCrash$lambda$50(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_0oXjpiudie8okRhTbZ2Hn0TFWM(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreModel;->choose$lambda$40$lambda$39(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dRnFPgeuMFSALWLXCb6EZxiV5YE(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreModel;->open$lambda$33(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jCP98QvH9Yrje2ZPXYPbukp77U4(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreModel;->background$lambda$9(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$jmOtfpq8g1EY9jwfpzSEIHMWHnU(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->open$lambda$23(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$k5ShXsASr6yhAYeoWnyQ6BBDVOo(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->_init_$lambda$7(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$lfSWYooLMgc8usnY0EeWEOG0uUA(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreModel;->search$lambda$19$lambda$18(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$m_LTZD6ofvQun3yKSSq8LQIxwuo(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Ljava/util/List;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreModel;->open$lambda$27$lambda$26$lambda$25(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$q0-SrEJ-DifLRHUWkz_DoCsgJJw(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->refreshGuest$lambda$13(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qXgrtzjguTUR-x3sQLJ2U9U9Yhc(Lorg/lighttouch/android/StoreModel;)Lorg/lighttouch/android/StoreTarget;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreModel;->installedList$lambda$1(Lorg/lighttouch/android/StoreModel;)Lorg/lighttouch/android/StoreTarget;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qome3lo5XooEhDlPlh0fGgKOPGQ(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreModel;->search$lambda$19(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rMhhLCaiD-0Ffi4x4SkCn1DUhKM(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->installedList$lambda$4(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rzAR4NwivphoqPRVbF_NOEj07Ow(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreModel;->_init_$lambda$8(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vhkp750q8dWeSQPNjLs-_5zFCSk(Lorg/lighttouch/android/StoreModel;ILorg/lighttouch/android/StoreTarget;Lorg/json/JSONObject;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreModel;->choose$lambda$40(Lorg/lighttouch/android/StoreModel;ILorg/lighttouch/android/StoreTarget;Lorg/json/JSONObject;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/StoreModel;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .locals 12
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "muxSocket"    # Lkotlin/jvm/functions/Function0;
    .param p3, "askNotifications"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "muxSocket"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "askNotifications"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 77
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Lorg/lighttouch/android/StoreModel;->askNotifications:Lkotlin/jvm/functions/Function0;

    .line 78
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreModel;->handler:Landroid/os/Handler;

    .line 79
    new-instance v0, Lorg/lighttouch/android/GuestApps;

    invoke-direct {v0, p1}, Lorg/lighttouch/android/GuestApps;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    .line 80
    sget-object v0, Lorg/lighttouch/android/StoreInstaller;->Companion:Lorg/lighttouch/android/StoreInstaller$Companion;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/StoreInstaller$Companion;->of(Landroid/content/Context;)Lorg/lighttouch/android/StoreInstaller;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    .line 81
    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/StoreModel;->target$delegate:Landroidx/compose/runtime/MutableState;

    .line 82
    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    iput-object v4, p0, Lorg/lighttouch/android/StoreModel;->targetConfirmed$delegate:Landroidx/compose/runtime/MutableState;

    .line 83
    const-string v4, ""

    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->query$delegate:Landroidx/compose/runtime/MutableState;

    .line 84
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v5

    invoke-static {v5, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->results$delegate:Landroidx/compose/runtime/MutableState;

    .line 85
    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->showIncompatible$delegate:Landroidx/compose/runtime/MutableState;

    .line 86
    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->searching$delegate:Landroidx/compose/runtime/MutableState;

    .line 87
    invoke-static {v4, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->message$delegate:Landroidx/compose/runtime/MutableState;

    .line 88
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->chosen$delegate:Landroidx/compose/runtime/MutableState;

    .line 89
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->copies$delegate:Landroidx/compose/runtime/MutableState;

    .line 90
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->selected$delegate:Landroidx/compose/runtime/MutableState;

    .line 91
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->problem$delegate:Landroidx/compose/runtime/MutableState;

    .line 92
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->candidate$delegate:Landroidx/compose/runtime/MutableState;

    .line 94
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v5

    invoke-static {v5, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v5

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->installed$delegate:Landroidx/compose/runtime/MutableState;

    .line 95
    new-instance v6, Lorg/lighttouch/android/InstalledList;

    iget-object v7, p0, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    iget-object v8, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    new-instance v9, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda17;

    invoke-direct {v9, p0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda17;-><init>(Lorg/lighttouch/android/StoreModel;)V

    new-instance v10, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda18;

    invoke-direct {v10, p0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda18;-><init>(Lorg/lighttouch/android/StoreModel;)V

    new-instance v11, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda19;

    invoke-direct {v11, p0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda19;-><init>(Lorg/lighttouch/android/StoreModel;)V

    invoke-direct/range {v6 .. v11}, Lorg/lighttouch/android/InstalledList;-><init>(Lorg/lighttouch/android/GuestApps;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V

    iput-object v6, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    .line 98
    new-instance v5, Lorg/lighttouch/android/StoreBrowser;

    new-instance v6, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda20;

    invoke-direct {v6, p0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda20;-><init>(Lorg/lighttouch/android/StoreModel;)V

    invoke-direct {v5, v6}, Lorg/lighttouch/android/StoreBrowser;-><init>(Lkotlin/jvm/functions/Function0;)V

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->browser:Lorg/lighttouch/android/StoreBrowser;

    .line 99
    new-instance v5, Landroidx/compose/foundation/lazy/LazyListState;

    const/4 v6, 0x3

    invoke-direct {v5, v2, v2, v6, v0}, Landroidx/compose/foundation/lazy/LazyListState;-><init>(IIILkotlin/jvm/internal/DefaultConstructorMarker;)V

    iput-object v5, p0, Lorg/lighttouch/android/StoreModel;->resultsList:Landroidx/compose/foundation/lazy/LazyListState;

    .line 101
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/StoreModel;->info$delegate:Landroidx/compose/runtime/MutableState;

    .line 102
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/StoreModel;->shots$delegate:Landroidx/compose/runtime/MutableState;

    .line 103
    iget-object v2, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v2

    invoke-virtual {v2}, Lorg/lighttouch/android/InstallQueue;->snapshot()Ljava/util/List;

    move-result-object v2

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/StoreModel;->queue$delegate:Landroidx/compose/runtime/MutableState;

    .line 104
    invoke-static {v3, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/StoreModel;->searchOpen$delegate:Landroidx/compose/runtime/MutableState;

    .line 105
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/StoreModel;->crash$delegate:Landroidx/compose/runtime/MutableState;

    .line 112
    nop

    .line 113
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda21;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda21;-><init>(Lorg/lighttouch/android/StoreModel;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/StoreInstaller;->setOnChanged(Lkotlin/jvm/functions/Function1;)V

    .line 114
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda22;

    invoke-direct {v1, p0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda22;-><init>(Lorg/lighttouch/android/StoreModel;)V

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/StoreInstaller;->setOnInstalled(Lkotlin/jvm/functions/Function1;)V

    .line 115
    nop

    .line 121
    iput-object v4, p0, Lorg/lighttouch/android/StoreModel;->recordId:Ljava/lang/String;

    .line 77
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 77
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    new-instance p3, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda7;

    invoke-direct {p3}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda7;-><init>()V

    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreModel;-><init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method private static final _init_$lambda$0()Lkotlin/Unit;
    .locals 1

    .line 77
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final _init_$lambda$7(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "it"    # Ljava/util/List;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 113
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreModel;->setQueue(Ljava/util/List;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final _init_$lambda$8(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "it"    # Ljava/util/List;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 114
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/InstalledList;->set(Ljava/util/List;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 2
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "work"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 117
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda5;

    invoke-direct {v1, p2}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda5;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-direct {v0, v1, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static final background$lambda$9(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 117
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private static final browser$lambda$5(Lorg/lighttouch/android/StoreModel;)Lorg/lighttouch/android/StoreTarget;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;

    .line 98
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    return-object v0
.end method

.method private static final choose$lambda$40(Lorg/lighttouch/android/StoreModel;ILorg/lighttouch/android/StoreTarget;Lorg/json/JSONObject;I)Lkotlin/Unit;
    .locals 8
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$ipaId"    # I
    .param p2, "$t"    # Lorg/lighttouch/android/StoreTarget;
    .param p3, "$app"    # Lorg/json/JSONObject;
    .param p4, "$generation"    # I

    .line 207
    const-string v0, "bundle_id"

    :try_start_0
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    .local v1, "$this$choose_u24lambda_u2440_u24lambda_u2436\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v2, 0x0

    .line 208
    .local v2, "$i$a$-runCatching-StoreModel$choose$1$outcome$1\\1\\207\\0":I
    sget-object v3, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v3, p1, p2}, Lorg/lighttouch/android/LegacyStore;->compatibleCopy(ILorg/lighttouch/android/StoreTarget;)Lorg/json/JSONObject;

    move-result-object v3

    .line 210
    .local v3, "found\\1":Lorg/json/JSONObject;
    invoke-static {p3, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    if-eqz v4, :cond_0

    .line 644
    .local v4, "it\\2":Ljava/lang/String;
    const/4 v6, 0x0

    .line 210
    .local v6, "$i$a$-let-StoreModel$choose$1$outcome$1$1\\2\\210\\1":I
    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    .end local v4    # "it\\2":Ljava/lang/String;
    .end local v6    # "$i$a$-let-StoreModel$choose$1$outcome$1$1\\2\\210\\1":I
    const/4 v4, 0x1

    xor-int/2addr v0, v4

    if-ne v0, v4, :cond_0

    goto :goto_0

    :cond_0
    move v4, v5

    :goto_0
    if-nez v4, :cond_1

    .line 211
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    sget-object v4, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v4, p1}, Lorg/lighttouch/android/LegacyStore;->copyDetails(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v0, v4, v3, p2}, Lorg/lighttouch/android/LegacyStore;->checkCopy(Lorg/json/JSONObject;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;)V

    .line 212
    nop

    .line 207
    .end local v1    # "$this$choose_u24lambda_u2440_u24lambda_u2436\\1":Lorg/lighttouch/android/StoreModel;
    .end local v2    # "$i$a$-runCatching-StoreModel$choose$1$outcome$1\\1\\207\\0":I
    .end local v3    # "found\\1":Lorg/json/JSONObject;
    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1

    .line 210
    .restart local v1    # "$this$choose_u24lambda_u2440_u24lambda_u2436\\1":Lorg/lighttouch/android/StoreModel;
    .restart local v2    # "$i$a$-runCatching-StoreModel$choose$1$outcome$1\\1\\207\\0":I
    .restart local v3    # "found\\1":Lorg/json/JSONObject;
    :cond_1
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v4, "\u6b64\u526f\u672c\u5c5e\u4e8e\u5176\u4ed6\u5e94\u7528\u3002"

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {v0, v4, v5, v6, v7}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local p0    # "this$0":Lorg/lighttouch/android/StoreModel;
    .end local p1    # "$ipaId":I
    .end local p2    # "$t":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "$app":Lorg/json/JSONObject;
    .end local p4    # "$generation":I
    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 207
    .end local v1    # "$this$choose_u24lambda_u2440_u24lambda_u2436\\1":Lorg/lighttouch/android/StoreModel;
    .end local v2    # "$i$a$-runCatching-StoreModel$choose$1$outcome$1\\1\\207\\0":I
    .end local v3    # "found\\1":Lorg/json/JSONObject;
    .restart local p0    # "this$0":Lorg/lighttouch/android/StoreModel;
    .restart local p1    # "$ipaId":I
    .restart local p2    # "$t":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "$app":Lorg/json/JSONObject;
    .restart local p4    # "$generation":I
    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 214
    .local v0, "outcome":Ljava/lang/Object;
    :goto_1
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda0;

    invoke-direct {v1, p4, p0, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda0;-><init>(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 218
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final choose$lambda$40$lambda$39(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)Lkotlin/Unit;
    .locals 3
    .param p0, "$generation"    # I
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$outcome"    # Ljava/lang/Object;

    .line 215
    iget v0, p1, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 216
    :cond_0
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    move-object v0, p2

    check-cast v0, Lorg/json/JSONObject;

    .line 644
    .local v0, "it\\1":Lorg/json/JSONObject;
    const/4 v1, 0x0

    .line 216
    .local v1, "$i$a$-onSuccess-StoreModel$choose$1$1$1\\1\\216\\0":I
    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreModel;->setCandidate(Lorg/json/JSONObject;)V

    .end local v0    # "it\\1":Lorg/json/JSONObject;
    .end local v1    # "$i$a$-onSuccess-StoreModel$choose$1$1$1\\1\\216\\0":I
    :cond_1
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 644
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 216
    .local v1, "$i$a$-onFailure-StoreModel$choose$1$1$2\\3\\216\\0":I
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->setProblem(Ljava/lang/String;)V

    .line 217
    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreModel$choose$1$1$2\\3\\216\\0":I
    :cond_2
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final enqueue(Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/InstallRequest;)V
    .locals 3
    .param p1, "key"    # Ljava/lang/String;
    .param p2, "name"    # Ljava/lang/String;
    .param p3, "request"    # Lorg/lighttouch/android/InstallRequest;

    .line 228
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_0

    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/StoreModel;

    .line 644
    .local v0, "$this$enqueue_u24lambda_u2443\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 228
    .local v1, "$i$a$-run-StoreModel$enqueue$socket$1\\1\\228\\0":I
    const-string v2, "\u542f\u52a8\u5ba2\u6237\u673a\u4ee5\u5b89\u88c5\u5e94\u7528\u3002"

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/StoreModel;->setMessage(Ljava/lang/String;)V

    return-void

    .line 229
    .end local v1    # "$i$a$-run-StoreModel$enqueue$socket$1\\1\\228\\0":I
    .local v0, "socket":Ljava/lang/String;
    :cond_0
    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v1, v0}, Lorg/lighttouch/android/StoreInstaller;->setSocket(Ljava/lang/String;)V

    .line 230
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getInstalling()Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->askNotifications:Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 231
    :cond_1
    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v1}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v1

    invoke-virtual {v1, p1, p2, p3}, Lorg/lighttouch/android/InstallQueue;->enqueue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Z

    .line 232
    return-void
.end method

.method private static final installedList$lambda$1(Lorg/lighttouch/android/StoreModel;)Lorg/lighttouch/android/StoreTarget;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;

    .line 95
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    return-object v0
.end method

.method private static final installedList$lambda$2(Lorg/lighttouch/android/StoreModel;)Z
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;

    .line 95
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTargetConfirmed()Z

    move-result v0

    return v0
.end method

.method private static final installedList$lambda$4(Lorg/lighttouch/android/StoreModel;Ljava/util/List;)Lkotlin/Unit;
    .locals 12
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "list"    # Ljava/util/List;

    const-string v0, "list"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 96
    move-object v0, p1

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$associate\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 649
    .local v1, "$i$f$associate\\1\\96":I
    const/16 v2, 0xa

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v2

    invoke-static {v2}, Lkotlin/collections/MapsKt;->mapCapacity(I)I

    move-result v2

    const/16 v3, 0x10

    invoke-static {v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v2

    .line 650
    .local v2, "capacity\\1":I
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    check-cast v3, Ljava/util/Map;

    .local v3, "destination\\2":Ljava/util/Map;
    move-object v4, v0

    .local v4, "$this$associateTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 651
    .local v5, "$i$f$associateTo\\2\\650":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 652
    .local v7, "element\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lorg/lighttouch/android/InstalledApp;

    .local v8, "it\\3":Lorg/lighttouch/android/InstalledApp;
    const/4 v9, 0x0

    .line 96
    .local v9, "$i$a$-associate-StoreModel$installedList$3$1\\3\\652\\0":I
    invoke-virtual {v8}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8}, Lorg/lighttouch/android/InstalledApp;->getVersion()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_0

    const-string v11, "unknown"

    :cond_0
    invoke-static {v10, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v8

    .line 652
    .end local v8    # "it\\3":Lorg/lighttouch/android/InstalledApp;
    .end local v9    # "$i$a$-associate-StoreModel$installedList$3$1\\3\\652\\0":I
    invoke-virtual {v8}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v8}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v3, v9, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 654
    .end local v7    # "element\\2":Ljava/lang/Object;
    :cond_1
    nop

    .line 650
    .end local v3    # "destination\\2":Ljava/util/Map;
    .end local v4    # "$this$associateTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$associateTo\\2\\650":I
    nop

    .line 96
    .end local v0    # "$this$associate\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$associate\\1\\96":I
    .end local v2    # "capacity\\1":I
    invoke-virtual {p0, v3}, Lorg/lighttouch/android/StoreModel;->setInstalled(Ljava/util/Map;)V

    .line 97
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final open$lambda$23(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/json/JSONObject;

    .line 174
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 644
    .local v0, "$this$open_u24lambda_u2423_u24lambda_u2420\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 174
    .local v1, "$i$a$-runCatching-StoreModel$open$1$1\\1\\174\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2, p1}, Lorg/lighttouch/android/LegacyStore;->appInfo(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v2

    .end local v0    # "$this$open_u24lambda_u2423_u24lambda_u2420\\1":Lorg/lighttouch/android/StoreModel;
    .end local v1    # "$i$a$-runCatching-StoreModel$open$1$1\\1\\174\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v0, 0x0

    :cond_0
    check-cast v0, Lorg/json/JSONObject;

    if-eqz v0, :cond_1

    .line 644
    .local v0, "found\\2":Lorg/json/JSONObject;
    const/4 v1, 0x0

    .line 174
    .local v1, "$i$a$-let-StoreModel$open$1$2\\2\\174\\0":I
    new-instance v2, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda15;

    invoke-direct {v2, p0, p1, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda15;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/json/JSONObject;)V

    invoke-direct {p0, v2}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .end local v0    # "found\\2":Lorg/json/JSONObject;
    .end local v1    # "$i$a$-let-StoreModel$open$1$2\\2\\174\\0":I
    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final open$lambda$23$lambda$22$lambda$21(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/json/JSONObject;
    .param p2, "$found"    # Lorg/json/JSONObject;

    .line 174
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getChosen()Lorg/json/JSONObject;

    move-result-object v0

    if-ne v0, p1, :cond_0

    invoke-virtual {p0, p2}, Lorg/lighttouch/android/StoreModel;->setInfo(Lorg/json/JSONObject;)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final open$lambda$27(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/json/JSONObject;

    .line 175
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 644
    .local v0, "$this$open_u24lambda_u2427_u24lambda_u2424\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 175
    .local v1, "$i$a$-runCatching-StoreModel$open$2$1\\1\\175\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2, p1}, Lorg/lighttouch/android/LegacyStore;->screenshots(Lorg/json/JSONObject;)Ljava/util/List;

    move-result-object v2

    .end local v0    # "$this$open_u24lambda_u2427_u24lambda_u2424\\1":Lorg/lighttouch/android/StoreModel;
    .end local v1    # "$i$a$-runCatching-StoreModel$open$2$1\\1\\175\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v0, 0x0

    :cond_0
    check-cast v0, Ljava/util/List;

    if-eqz v0, :cond_1

    .line 644
    .local v0, "found\\2":Ljava/util/List;
    const/4 v1, 0x0

    .line 175
    .local v1, "$i$a$-let-StoreModel$open$2$2\\2\\175\\0":I
    new-instance v2, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda13;

    invoke-direct {v2, p0, p1, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda13;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Ljava/util/List;)V

    invoke-direct {p0, v2}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .end local v0    # "found\\2":Ljava/util/List;
    .end local v1    # "$i$a$-let-StoreModel$open$2$2\\2\\175\\0":I
    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final open$lambda$27$lambda$26$lambda$25(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Ljava/util/List;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/json/JSONObject;
    .param p2, "$found"    # Ljava/util/List;

    .line 175
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getChosen()Lorg/json/JSONObject;

    move-result-object v0

    if-ne v0, p1, :cond_0

    invoke-virtual {p0, p2}, Lorg/lighttouch/android/StoreModel;->setShots(Ljava/util/List;)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final open$lambda$33(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;I)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/json/JSONObject;
    .param p2, "$t"    # Lorg/lighttouch/android/StoreTarget;
    .param p3, "$generation"    # I

    .line 177
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 644
    .local v0, "$this$open_u24lambda_u2433_u24lambda_u2428\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 177
    .local v1, "$i$a$-runCatching-StoreModel$open$3$outcome$1\\1\\177\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2, p1, p2}, Lorg/lighttouch/android/LegacyStore;->versions(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;

    move-result-object v2

    .end local v0    # "$this$open_u24lambda_u2433_u24lambda_u2428\\1":Lorg/lighttouch/android/StoreModel;
    .end local v1    # "$i$a$-runCatching-StoreModel$open$3$outcome$1\\1\\177\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 178
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda11;

    invoke-direct {v1, p3, p0, v0, p1}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda11;-><init>(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;Lorg/json/JSONObject;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 186
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final open$lambda$33$lambda$32(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 12
    .param p0, "$generation"    # I
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$outcome"    # Ljava/lang/Object;
    .param p3, "$app"    # Lorg/json/JSONObject;

    .line 179
    iget v0, p1, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 180
    :cond_0
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    move-object v0, p2

    check-cast v0, Ljava/util/List;

    .local v0, "rows\\1":Ljava/util/List;
    const/4 v1, 0x0

    .line 181
    .local v1, "$i$a$-onSuccess-StoreModel$open$3$1$1\\1\\180\\0":I
    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreModel;->setCopies(Ljava/util/List;)V

    .line 182
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    const-string v2, "\u6b64\u5e94\u7528\u6ca1\u6709\u80fd\u5728\u8be5\u8bbe\u5907\u4e0a\u8fd0\u884c\u7684\u7248\u672c\u3002"

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->setProblem(Ljava/lang/String;)V

    goto :goto_3

    .line 183
    :cond_1
    move-object v2, v0

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$firstOrNull\\2":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 655
    .local v3, "$i$f$firstOrNull\\2\\183":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_4

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\2":Ljava/lang/Object;
    move-object v7, v5

    check-cast v7, Lorg/lighttouch/android/StoreCopy;

    .local v7, "it\\3":Lorg/lighttouch/android/StoreCopy;
    const/4 v8, 0x0

    .line 183
    .local v8, "$i$a$-firstOrNull-StoreModel$open$3$1$1$1\\3\\655\\1":I
    invoke-virtual {v7}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v9

    sget-object v10, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    const-string v11, "ipa_id"

    invoke-virtual {p3, v11}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Lorg/lighttouch/android/LegacyStore;->preferred(I)I

    move-result v10

    if-ne v9, v10, :cond_3

    const/4 v9, 0x1

    goto :goto_0

    :cond_3
    move v9, v6

    .line 655
    .end local v7    # "it\\3":Lorg/lighttouch/android/StoreCopy;
    .end local v8    # "$i$a$-firstOrNull-StoreModel$open$3$1$1$1\\3\\655\\1":I
    :goto_0
    if-eqz v9, :cond_2

    goto :goto_1

    .line 656
    .end local v5    # "element\\2":Ljava/lang/Object;
    :cond_4
    const/4 v5, 0x0

    .line 183
    .end local v2    # "$this$firstOrNull\\2":Ljava/lang/Iterable;
    .end local v3    # "$i$f$firstOrNull\\2\\183":I
    :goto_1
    check-cast v5, Lorg/lighttouch/android/StoreCopy;

    if-eqz v5, :cond_5

    invoke-virtual {v5}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v2

    goto :goto_2

    :cond_5
    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/StoreCopy;

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v2

    :goto_2
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->choose(I)V

    .line 184
    :goto_3
    nop

    .line 180
    .end local v0    # "rows\\1":Ljava/util/List;
    .end local v1    # "$i$a$-onSuccess-StoreModel$open$3$1$1\\1\\180\\0":I
    :cond_6
    nop

    .line 184
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_7

    .line 644
    .local v0, "it\\5":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 184
    .local v1, "$i$a$-onFailure-StoreModel$open$3$1$2\\5\\184\\0":I
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->setCopies(Ljava/util/List;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Couldn\'t load versions: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->setProblem(Ljava/lang/String;)V

    .line 185
    .end local v0    # "it\\5":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreModel$open$3$1$2\\5\\184\\0":I
    :cond_7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final post(Lkotlin/jvm/functions/Function0;)Z
    .locals 2
    .param p1, "work"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 118
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda1;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda1;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v0

    return v0
.end method

.method private static final post$lambda$10(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 118
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private final queueKey(Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 5
    .param p1, "app"    # Lorg/json/JSONObject;

    .line 222
    const-string v0, "bundle_id"

    invoke-static {p1, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "app_store_id"

    invoke-static {p1, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "app_url"

    invoke-static {p1, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    new-array v2, v2, [C

    const/4 v3, 0x0

    const/16 v4, 0x2f

    aput-char v4, v2, v3

    invoke-static {v0, v2}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-static {v0, v4, v1, v2, v1}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, v1

    :goto_0
    if-nez v0, :cond_1

    const-string v0, "ipa_id"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u5e94\u7528\uff1a"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final refreshGuest$lambda$13(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$socket"    # Ljava/lang/String;

    .line 142
    nop

    .line 143
    :try_start_0
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/GuestApps;->target(Ljava/lang/String;)Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    .line 144
    .local v0, "exact":Lorg/lighttouch/android/StoreTarget;
    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v1, p1}, Lorg/lighttouch/android/GuestApps;->installedApps(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    .line 145
    .local v1, "list":Ljava/util/List;
    new-instance v2, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0, p1, v1, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Ljava/util/List;Lorg/lighttouch/android/StoreTarget;)V

    invoke-direct {p0, v2}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v0    # "exact":Lorg/lighttouch/android/StoreTarget;
    .end local v1    # "list":Ljava/util/List;
    goto :goto_0

    .line 150
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/StoreModel;Ljava/lang/Exception;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 151
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final refreshGuest$lambda$13$lambda$11(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Ljava/util/List;Lorg/lighttouch/android/StoreTarget;)Lkotlin/Unit;
    .locals 2
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$socket"    # Ljava/lang/String;
    .param p2, "$list"    # Ljava/util/List;
    .param p3, "$exact"    # Lorg/lighttouch/android/StoreTarget;

    .line 146
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 147
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0, p2}, Lorg/lighttouch/android/InstalledList;->set(Ljava/util/List;)V

    .line 148
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_1

    invoke-virtual {p0, p3}, Lorg/lighttouch/android/StoreModel;->setTarget(Lorg/lighttouch/android/StoreTarget;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setTargetConfirmed(Z)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->forgetLookups()V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->lookUp()V

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->search()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setTargetConfirmed(Z)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->lookUp()V

    .line 149
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final refreshGuest$lambda$13$lambda$12(Lorg/lighttouch/android/StoreModel;Ljava/lang/Exception;)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$e"    # Ljava/lang/Exception;

    .line 150
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getInstalling()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Guest app services: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setMessage(Ljava/lang/String;)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final search$lambda$19(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;I)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$q"    # Ljava/lang/String;
    .param p2, "$t"    # Lorg/lighttouch/android/StoreTarget;
    .param p3, "$generation"    # I

    .line 160
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 644
    .local v0, "$this$search_u24lambda_u2419_u24lambda_u2415\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 160
    .local v1, "$i$a$-runCatching-StoreModel$search$1$outcome$1\\1\\160\\0":I
    sget-object v2, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v2, p1, p2}, Lorg/lighttouch/android/LegacyStore;->search(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;

    move-result-object v2

    .end local v0    # "$this$search_u24lambda_u2419_u24lambda_u2415\\1":Lorg/lighttouch/android/StoreModel;
    .end local v1    # "$i$a$-runCatching-StoreModel$search$1$outcome$1\\1\\160\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 161
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda12;

    invoke-direct {v1, p3, p0, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda12;-><init>(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 167
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final search$lambda$19$lambda$18(ILorg/lighttouch/android/StoreModel;Ljava/lang/Object;)Lkotlin/Unit;
    .locals 3
    .param p0, "$generation"    # I
    .param p1, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$outcome"    # Ljava/lang/Object;

    .line 162
    iget v0, p1, Lorg/lighttouch/android/StoreModel;->searchGeneration:I

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 163
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreModel;->setSearching(Z)V

    .line 164
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    move-object v0, p2

    check-cast v0, Ljava/util/List;

    .line 644
    .local v0, "it\\1":Ljava/util/List;
    const/4 v1, 0x0

    .line 164
    .local v1, "$i$a$-onSuccess-StoreModel$search$1$1$1\\1\\164\\0":I
    invoke-virtual {p1, v0}, Lorg/lighttouch/android/StoreModel;->setResults(Ljava/util/List;)V

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    const-string v2, "\u672a\u627e\u5230\u5e94\u7528\u3002"

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->setMessage(Ljava/lang/String;)V

    .line 165
    .end local v0    # "it\\1":Ljava/util/List;
    .end local v1    # "$i$a$-onSuccess-StoreModel$search$1$1$1\\1\\164\\0":I
    :cond_1
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_3

    .line 644
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 165
    .local v1, "$i$a$-onFailure-StoreModel$search$1$1$2\\3\\165\\0":I
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_2

    const-string v2, "\u641c\u7d22\u5931\u8d25"

    :cond_2
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/StoreModel;->setMessage(Ljava/lang/String;)V

    .line 166
    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-StoreModel$search$1$1$2\\3\\165\\0":I
    :cond_3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final showLastCrash$lambda$50(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 34
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$socket"    # Ljava/lang/String;

    .line 242
    move-object/from16 v1, p0

    .line 243
    :try_start_0
    iget-object v0, v1, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    move-object/from16 v2, p1

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/GuestApps;->lastCrash(Ljava/lang/String;)Lkotlin/Pair;

    move-result-object v0

    if-eqz v0, :cond_b

    const/4 v3, 0x0

    .local v3, "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "name\\1":Ljava/lang/String;
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 244
    .local v0, "body\\1":Ljava/lang/String;
    new-instance v5, Lkotlin/text/Regex;

    const-string v6, "^(Process|Date/Time|OS Version|Exception Type|Exception Codes|Crashed Thread|Dyld Error Message|  Symbol not found|  Referenced from|  Expected in|Termination Reason|Application Specific Information)"

    invoke-direct {v5, v6}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    .line 245
    .local v5, "keep\\1":Lkotlin/text/Regex;
    move-object v6, v0

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6}, Lkotlin/text/StringsKt;->lines(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v6

    .line 246
    .local v6, "lines\\1":Ljava/util/List;
    move-object v7, v6

    .local v7, "$this$indexOfFirst\\2":Ljava/util/List;
    const/4 v8, 0x0

    .line 657
    .local v8, "$i$f$indexOfFirst\\2\\246":I
    const/4 v9, 0x0

    .line 658
    .local v9, "index\\2":I
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    const/4 v12, 0x0

    if-eqz v11, :cond_1

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .line 659
    .local v11, "item\\2":Ljava/lang/Object;
    move-object v13, v11

    check-cast v13, Ljava/lang/String;

    .local v13, "it\\3":Ljava/lang/String;
    const/4 v14, 0x0

    .line 246
    .local v14, "$i$a$-indexOfFirst-StoreModel$showLastCrash$1$text$1$dyld$1\\3\\659\\1":I
    const-string v15, "Dyld Error Message"

    const/4 v2, 0x2

    move/from16 v16, v3

    .end local v3    # "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    .local v16, "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    const/4 v3, 0x0

    invoke-static {v13, v15, v12, v2, v3}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    .line 659
    .end local v13    # "it\\3":Ljava/lang/String;
    .end local v14    # "$i$a$-indexOfFirst-StoreModel$showLastCrash$1$text$1$dyld$1\\3\\659\\1":I
    if-eqz v2, :cond_0

    .line 660
    goto :goto_1

    .line 661
    :cond_0
    nop

    .end local v11    # "item\\2":Ljava/lang/Object;
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v2, p1

    move/from16 v3, v16

    goto :goto_0

    .line 663
    .end local v16    # "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    .restart local v3    # "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    :cond_1
    move/from16 v16, v3

    .end local v3    # "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    .restart local v16    # "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    const/4 v2, -0x1

    move v9, v2

    .line 246
    .end local v7    # "$this$indexOfFirst\\2":Ljava/util/List;
    .end local v8    # "$i$f$indexOfFirst\\2\\246":I
    .end local v9    # "index\\2":I
    :goto_1
    nop

    .line 247
    .local v9, "dyld\\1":I
    move-object v2, v6

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filterIndexed\\4":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 664
    .local v3, "$i$f$filterIndexed\\4\\247":I
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    check-cast v7, Ljava/util/Collection;

    .local v7, "destination\\5":Ljava/util/Collection;
    move-object v8, v2

    .local v8, "$this$filterIndexedTo\\5":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 665
    .local v10, "$i$f$filterIndexedTo\\5\\664":I
    move-object v11, v8

    .local v11, "$this$forEachIndexed\\6":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 666
    .local v13, "$i$f$forEachIndexed\\6\\665":I
    const/4 v14, 0x0

    .line 667
    .local v14, "index\\6":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_2
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    const/16 v18, 0x1

    if-eqz v17, :cond_8

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "item\\6":Ljava/lang/Object;
    add-int/lit8 v19, v14, 0x1

    .end local v14    # "index\\6":I
    .local v19, "index\\6":I
    if-gez v14, :cond_2

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    .local v14, "index\\7":I
    :cond_2
    move-object/from16 v20, v17

    .local v20, "element\\7":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 668
    .local v21, "$i$a$-forEachIndexed-CollectionsKt___CollectionsKt$filterIndexedTo$1\\7\\667\\5":I
    move-object/from16 v22, v20

    check-cast v22, Ljava/lang/String;

    move/from16 v23, v14

    .local v22, "l\\8":Ljava/lang/String;
    .local v23, "i\\8":I
    move/from16 v24, v23

    .end local v23    # "i\\8":I
    .local v24, "i\\8":I
    const/16 v23, 0x0

    .line 247
    .local v23, "$i$a$-filterIndexed-StoreModel$showLastCrash$1$text$1$1\\8\\668\\1":I
    move-object/from16 v12, v22

    check-cast v12, Ljava/lang/CharSequence;

    invoke-virtual {v5, v12}, Lkotlin/text/Regex;->containsMatchIn(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_6

    if-ltz v9, :cond_4

    add-int/lit8 v12, v9, 0x1

    move-object/from16 v25, v2

    .end local v2    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .local v25, "$this$filterIndexed\\4":Ljava/lang/Iterable;
    add-int/lit8 v2, v9, 0x3

    move/from16 v26, v3

    move/from16 v3, v24

    .end local v24    # "i\\8":I
    .local v3, "i\\8":I
    .local v26, "$i$f$filterIndexed\\4\\247":I
    if-gt v3, v2, :cond_3

    if-gt v12, v3, :cond_3

    move/from16 v2, v18

    goto :goto_3

    :cond_3
    const/4 v2, 0x0

    :goto_3
    if-eqz v2, :cond_5

    goto :goto_4

    .end local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v26    # "$i$f$filterIndexed\\4\\247":I
    .restart local v2    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .local v3, "$i$f$filterIndexed\\4\\247":I
    .restart local v24    # "i\\8":I
    :cond_4
    move-object/from16 v25, v2

    move/from16 v26, v3

    move/from16 v3, v24

    .end local v2    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v24    # "i\\8":I
    .local v3, "i\\8":I
    .restart local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .restart local v26    # "$i$f$filterIndexed\\4\\247":I
    :cond_5
    const/16 v18, 0x0

    goto :goto_4

    .end local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v26    # "$i$f$filterIndexed\\4\\247":I
    .restart local v2    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .local v3, "$i$f$filterIndexed\\4\\247":I
    .restart local v24    # "i\\8":I
    :cond_6
    move-object/from16 v25, v2

    move/from16 v26, v3

    move/from16 v3, v24

    .line 668
    .end local v2    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filterIndexed\\4\\247":I
    .end local v22    # "l\\8":Ljava/lang/String;
    .end local v23    # "$i$a$-filterIndexed-StoreModel$showLastCrash$1$text$1$1\\8\\668\\1":I
    .end local v24    # "i\\8":I
    .restart local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .restart local v26    # "$i$f$filterIndexed\\4\\247":I
    :goto_4
    if-eqz v18, :cond_7

    move-object/from16 v2, v20

    .end local v20    # "element\\7":Ljava/lang/Object;
    .local v2, "element\\7":Ljava/lang/Object;
    invoke-interface {v7, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_5

    .end local v2    # "element\\7":Ljava/lang/Object;
    .restart local v20    # "element\\7":Ljava/lang/Object;
    :cond_7
    move-object/from16 v2, v20

    .line 669
    .end local v20    # "element\\7":Ljava/lang/Object;
    .restart local v2    # "element\\7":Ljava/lang/Object;
    :goto_5
    nop

    .line 667
    .end local v2    # "element\\7":Ljava/lang/Object;
    .end local v14    # "index\\7":I
    .end local v21    # "$i$a$-forEachIndexed-CollectionsKt___CollectionsKt$filterIndexedTo$1\\7\\667\\5":I
    move/from16 v14, v19

    move-object/from16 v2, v25

    move/from16 v3, v26

    const/4 v12, 0x0

    .end local v17    # "item\\6":Ljava/lang/Object;
    goto :goto_2

    .line 670
    .end local v19    # "index\\6":I
    .end local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v26    # "$i$f$filterIndexed\\4\\247":I
    .local v2, "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .restart local v3    # "$i$f$filterIndexed\\4\\247":I
    .local v14, "index\\6":I
    :cond_8
    move-object/from16 v25, v2

    move/from16 v26, v3

    .line 671
    .end local v2    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filterIndexed\\4\\247":I
    .end local v11    # "$this$forEachIndexed\\6":Ljava/lang/Iterable;
    .end local v13    # "$i$f$forEachIndexed\\6\\665":I
    .end local v14    # "index\\6":I
    .restart local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .restart local v26    # "$i$f$filterIndexed\\4\\247":I
    nop

    .end local v7    # "destination\\5":Ljava/util/Collection;
    .end local v8    # "$this$filterIndexedTo\\5":Ljava/lang/Iterable;
    .end local v10    # "$i$f$filterIndexedTo\\5\\664":I
    move-object v2, v7

    check-cast v2, Ljava/util/List;

    .line 664
    nop

    .end local v25    # "$this$filterIndexed\\4":Ljava/lang/Iterable;
    .end local v26    # "$i$f$filterIndexed\\4\\247":I
    check-cast v2, Ljava/lang/Iterable;

    .line 248
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    move-object/from16 v25, v2

    check-cast v25, Ljava/lang/Iterable;

    const-string v2, "\n"

    move-object/from16 v26, v2

    check-cast v26, Ljava/lang/CharSequence;

    const/16 v32, 0x3e

    const/16 v33, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    invoke-static/range {v25 .. v33}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-nez v3, :cond_9

    move/from16 v12, v18

    goto :goto_6

    :cond_9
    const/4 v12, 0x0

    :goto_6
    if-eqz v12, :cond_a

    .line 644
    const/4 v2, 0x0

    .line 248
    .local v2, "$i$a$-ifEmpty-StoreModel$showLastCrash$1$text$1$2\\9\\248\\1":I
    const/16 v3, 0x5dc

    invoke-static {v0, v3}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    move-object v2, v3

    .end local v2    # "$i$a$-ifEmpty-StoreModel$showLastCrash$1$text$1$2\\9\\248\\1":I
    :cond_a
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v7, "\n\n"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 243
    .end local v0    # "body\\1":Ljava/lang/String;
    .end local v4    # "name\\1":Ljava/lang/String;
    .end local v5    # "keep\\1":Lkotlin/text/Regex;
    .end local v6    # "lines\\1":Ljava/util/List;
    .end local v9    # "dyld\\1":I
    .end local v16    # "$i$a$-let-StoreModel$showLastCrash$1$text$1\\1\\243\\0":I
    if-nez v2, :cond_c

    .line 249
    :cond_b
    const-string v2, "\u5ba2\u6237\u673a\u6ca1\u6709\u5d29\u6e83\u62a5\u544a\u3002"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_c
    goto :goto_7

    .line 250
    :catch_0
    move-exception v0

    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Could not read crash reports: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 242
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_7
    nop

    .line 251
    .local v2, "text":Ljava/lang/String;
    new-instance v0, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda2;

    invoke-direct {v0, v1, v2}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)V

    invoke-direct {v1, v0}, Lorg/lighttouch/android/StoreModel;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 252
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final showLastCrash$lambda$50$lambda$49(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "this$0"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$text"    # Ljava/lang/String;

    .line 251
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreModel;->setCrash(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public final cancel(J)V
    .locals 1
    .param p1, "id"    # J

    .line 261
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/InstallQueue;->cancel(J)V

    return-void
.end method

.method public final choose(I)V
    .locals 7
    .param p1, "ipaId"    # I

    .line 202
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    move-object v4, v0

    .line 203
    .local v4, "t":Lorg/lighttouch/android/StoreTarget;
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getChosen()Lorg/json/JSONObject;

    move-result-object v5

    if-nez v5, :cond_1

    return-void

    .line 204
    .local v5, "app":Lorg/json/JSONObject;
    :cond_1
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setSelected(Ljava/lang/Integer;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setProblem(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setCandidate(Lorg/json/JSONObject;)V

    .line 205
    iget v0, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    iget v6, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    .line 206
    .local v6, "generation":I
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda16;

    move-object v2, p0

    move v3, p1

    .end local p1    # "ipaId":I
    .local v3, "ipaId":I
    invoke-direct/range {v1 .. v6}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda16;-><init>(Lorg/lighttouch/android/StoreModel;ILorg/lighttouch/android/StoreTarget;Lorg/json/JSONObject;I)V

    const-string p1, "store-copy-check"

    invoke-direct {p0, p1, v1}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 219
    return-void
.end method

.method public final clearFinished()V
    .locals 1

    .line 264
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/InstallQueue;->clearFinished()V

    return-void
.end method

.method public final close()V
    .locals 1

    .line 189
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setChosen(Lorg/json/JSONObject;)V

    iget v0, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    return-void
.end method

.method public final closeSearch()V
    .locals 1

    .line 257
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setSearchOpen(Z)V

    .line 258
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getQuery()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, ""

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setQuery(Ljava/lang/String;)V

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->search()V

    .line 259
    :cond_0
    return-void
.end method

.method public final dismiss(J)V
    .locals 1
    .param p1, "id"    # J

    .line 263
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/InstallQueue;->dismiss(J)V

    return-void
.end method

.method public final getBrowser()Lorg/lighttouch/android/StoreBrowser;
    .locals 1

    .line 98
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->browser:Lorg/lighttouch/android/StoreBrowser;

    return-object v0
.end method

.method public final getCandidate()Lorg/json/JSONObject;
    .locals 3

    .line 92
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->candidate$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 620
    .local v2, "$i$f$getValue\\1\\92":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\92":I
    check-cast v0, Lorg/json/JSONObject;

    .line 92
    return-object v0
.end method

.method public final getChosen()Lorg/json/JSONObject;
    .locals 3

    .line 88
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->chosen$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 608
    .local v2, "$i$f$getValue\\1\\88":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\88":I
    check-cast v0, Lorg/json/JSONObject;

    .line 88
    return-object v0
.end method

.method public final getCopies()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCopy;",
            ">;"
        }
    .end annotation

    .line 89
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->copies$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 611
    .local v2, "$i$f$getValue\\1\\89":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\89":I
    check-cast v0, Ljava/util/List;

    .line 89
    return-object v0
.end method

.method public final getCrash()Ljava/lang/String;
    .locals 3

    .line 105
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->crash$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 638
    .local v2, "$i$f$getValue\\1\\105":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\105":I
    check-cast v0, Ljava/lang/String;

    .line 105
    return-object v0
.end method

.method public final getInfo()Lorg/json/JSONObject;
    .locals 3

    .line 101
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->info$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 626
    .local v2, "$i$f$getValue\\1\\101":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\101":I
    check-cast v0, Lorg/json/JSONObject;

    .line 101
    return-object v0
.end method

.method public final getInstalled()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 94
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installed$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 623
    .local v2, "$i$f$getValue\\1\\94":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\94":I
    check-cast v0, Ljava/util/Map;

    .line 94
    return-object v0
.end method

.method public final getInstalledList()Lorg/lighttouch/android/InstalledList;
    .locals 1

    .line 95
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    return-object v0
.end method

.method public final getInstalling()Z
    .locals 7

    .line 110
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getQueue()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 641
    .local v1, "$i$f$any\\1\\110":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    .line 642
    :cond_0
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\1":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lorg/lighttouch/android/QueueItem;

    .local v5, "it\\2":Lorg/lighttouch/android/QueueItem;
    const/4 v6, 0x0

    .line 110
    .local v6, "$i$a$-any-StoreModel$installing$1\\2\\642\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v5

    .line 642
    .end local v5    # "it\\2":Lorg/lighttouch/android/QueueItem;
    .end local v6    # "$i$a$-any-StoreModel$installing$1\\2\\642\\0":I
    if-eqz v5, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    .line 643
    .end local v4    # "element\\1":Ljava/lang/Object;
    :cond_2
    nop

    .line 110
    .end local v0    # "$this$any\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any\\1\\110":I
    :goto_0
    return v3
.end method

.method public final getMessage()Ljava/lang/String;
    .locals 3

    .line 87
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->message$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 605
    .local v2, "$i$f$getValue\\1\\87":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\87":I
    check-cast v0, Ljava/lang/String;

    .line 87
    return-object v0
.end method

.method public final getProblem()Ljava/lang/String;
    .locals 3

    .line 91
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->problem$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 617
    .local v2, "$i$f$getValue\\1\\91":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\91":I
    check-cast v0, Ljava/lang/String;

    .line 91
    return-object v0
.end method

.method public final getQuery()Ljava/lang/String;
    .locals 3

    .line 83
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->query$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 593
    .local v2, "$i$f$getValue\\1\\83":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\83":I
    check-cast v0, Ljava/lang/String;

    .line 83
    return-object v0
.end method

.method public final getQueue()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;"
        }
    .end annotation

    .line 103
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->queue$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 632
    .local v2, "$i$f$getValue\\1\\103":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\103":I
    check-cast v0, Ljava/util/List;

    .line 103
    return-object v0
.end method

.method public final getResults()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->results$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 596
    .local v2, "$i$f$getValue\\1\\84":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\84":I
    check-cast v0, Ljava/util/List;

    .line 84
    return-object v0
.end method

.method public final getResultsList()Landroidx/compose/foundation/lazy/LazyListState;
    .locals 1

    .line 99
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->resultsList:Landroidx/compose/foundation/lazy/LazyListState;

    return-object v0
.end method

.method public final getSearchOpen()Z
    .locals 3

    .line 104
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->searchOpen$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 635
    .local v2, "$i$f$getValue\\1\\104":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\104":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 104
    return v0
.end method

.method public final getSearching()Z
    .locals 3

    .line 86
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->searching$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 602
    .local v2, "$i$f$getValue\\1\\86":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\86":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 86
    return v0
.end method

.method public final getSelected()Ljava/lang/Integer;
    .locals 3

    .line 90
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->selected$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 614
    .local v2, "$i$f$getValue\\1\\90":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\90":I
    check-cast v0, Ljava/lang/Integer;

    .line 90
    return-object v0
.end method

.method public final getServicesAvailable()Z
    .locals 1

    .line 109
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v0}, Lorg/lighttouch/android/GuestApps;->getAvailable()Z

    move-result v0

    return v0
.end method

.method public final getShots()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreShot;",
            ">;"
        }
    .end annotation

    .line 102
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->shots$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 629
    .local v2, "$i$f$getValue\\1\\102":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\102":I
    check-cast v0, Ljava/util/List;

    .line 102
    return-object v0
.end method

.method public final getShowIncompatible()Z
    .locals 3

    .line 85
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->showIncompatible$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 599
    .local v2, "$i$f$getValue\\1\\85":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\85":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 85
    return v0
.end method

.method public final getTarget()Lorg/lighttouch/android/StoreTarget;
    .locals 3

    .line 81
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->target$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 587
    .local v2, "$i$f$getValue\\1\\81":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\81":I
    check-cast v0, Lorg/lighttouch/android/StoreTarget;

    .line 81
    return-object v0
.end method

.method public final getTargetConfirmed()Z
    .locals 3

    .line 82
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->targetConfirmed$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 590
    .local v2, "$i$f$getValue\\1\\82":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\82":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 82
    return v0
.end method

.method public final guestChanged()V
    .locals 2

    .line 135
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setInstalled(Ljava/util/Map;)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->guestChanged()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setTargetConfirmed(Z)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/StoreInstaller;->setSocket(Ljava/lang/String;)V

    return-void
.end method

.method public final install(Lorg/json/JSONObject;)V
    .locals 3
    .param p1, "app"    # Lorg/json/JSONObject;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    invoke-direct {p0, p1}, Lorg/lighttouch/android/StoreModel;->queueKey(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "name"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "optString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Lorg/lighttouch/android/InstallRequest$Catalog;

    invoke-direct {v2, p1}, Lorg/lighttouch/android/InstallRequest$Catalog;-><init>(Lorg/json/JSONObject;)V

    check-cast v2, Lorg/lighttouch/android/InstallRequest;

    invoke-direct {p0, v0, v1, v2}, Lorg/lighttouch/android/StoreModel;->enqueue(Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/InstallRequest;)V

    return-void
.end method

.method public final installLocal(Landroid/net/Uri;)V
    .locals 3
    .param p1, "uri"    # Landroid/net/Uri;

    const-string v0, "uri"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "local:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lorg/lighttouch/android/InstallRequest$Local;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/InstallRequest$Local;-><init>(Landroid/net/Uri;)V

    check-cast v1, Lorg/lighttouch/android/InstallRequest;

    const-string v2, "\u672c\u5730 IPA"

    invoke-direct {p0, v0, v2, v1}, Lorg/lighttouch/android/StoreModel;->enqueue(Ljava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/InstallRequest;)V

    return-void
.end method

.method public final open(Lorg/json/JSONObject;)V
    .locals 4
    .param p1, "app"    # Lorg/json/JSONObject;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 171
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 172
    .local v0, "t":Lorg/lighttouch/android/StoreTarget;
    :cond_0
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreModel;->setChosen(Lorg/json/JSONObject;)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setCopies(Ljava/util/List;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setSelected(Ljava/lang/Integer;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setProblem(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setCandidate(Lorg/json/JSONObject;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setInfo(Lorg/json/JSONObject;)V

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v1

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setShots(Ljava/util/List;)V

    .line 173
    iget v1, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    iget v1, p0, Lorg/lighttouch/android/StoreModel;->checkGeneration:I

    .line 174
    .local v1, "generation":I
    new-instance v2, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda8;

    invoke-direct {v2, p0, p1}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)V

    const-string v3, "store-info"

    invoke-direct {p0, v3, v2}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 175
    new-instance v2, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda9;

    invoke-direct {v2, p0, p1}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda9;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)V

    const-string v3, "store-shots"

    invoke-direct {p0, v3, v2}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 176
    new-instance v2, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda10;

    invoke-direct {v2, p0, p1, v0, v1}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;I)V

    const-string v3, "store-versions"

    invoke-direct {p0, v3, v2}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 187
    return-void
.end method

.method public final openInstalled(Lorg/lighttouch/android/InstalledApp;)V
    .locals 3
    .param p1, "app"    # Lorg/lighttouch/android/InstalledApp;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 193
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->getLookups()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {p1}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lorg/lighttouch/android/Lookup$Found;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    check-cast v0, Lorg/lighttouch/android/Lookup$Found;

    goto :goto_0

    :cond_0
    move-object v0, v2

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lorg/lighttouch/android/Lookup$Found;->getKnown()Lorg/lighttouch/android/LegacyStore$Known;

    move-result-object v2

    .line 194
    .local v2, "found":Lorg/lighttouch/android/LegacyStore$Known;
    :cond_1
    if-eqz v2, :cond_2

    invoke-virtual {v2}, Lorg/lighttouch/android/LegacyStore$Known;->getApp()Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->open(Lorg/json/JSONObject;)V

    goto :goto_1

    :cond_2
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/InstalledList;->setPlain(Lorg/lighttouch/android/InstalledApp;)V

    .line 195
    :goto_1
    return-void
.end method

.method public final queued(Lorg/json/JSONObject;)Lorg/lighttouch/android/QueueItem;
    .locals 9
    .param p1, "app"    # Lorg/json/JSONObject;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 225
    invoke-direct {p0, p1}, Lorg/lighttouch/android/StoreModel;->queueKey(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    .line 644
    .local v0, "key\\1":Ljava/lang/String;
    const/4 v1, 0x0

    .line 225
    .local v1, "$i$a$-let-StoreModel$queued$1\\1\\225\\0":I
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getQueue()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$firstOrNull\\2":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 647
    .local v3, "$i$f$firstOrNull\\2\\225":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\2":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Lorg/lighttouch/android/QueueItem;

    .local v6, "it\\3":Lorg/lighttouch/android/QueueItem;
    const/4 v7, 0x0

    .line 225
    .local v7, "$i$a$-firstOrNull-StoreModel$queued$1$1\\3\\647\\1":I
    invoke-virtual {v6}, Lorg/lighttouch/android/QueueItem;->getKey()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    .line 647
    .end local v6    # "it\\3":Lorg/lighttouch/android/QueueItem;
    .end local v7    # "$i$a$-firstOrNull-StoreModel$queued$1$1\\3\\647\\1":I
    if-eqz v6, :cond_0

    goto :goto_0

    .line 648
    .end local v5    # "element\\2":Ljava/lang/Object;
    :cond_1
    const/4 v5, 0x0

    .end local v2    # "$this$firstOrNull\\2":Ljava/lang/Iterable;
    .end local v3    # "$i$f$firstOrNull\\2\\225":I
    :goto_0
    check-cast v5, Lorg/lighttouch/android/QueueItem;

    .line 225
    nop

    .end local v0    # "key\\1":Ljava/lang/String;
    .end local v1    # "$i$a$-let-StoreModel$queued$1\\1\\225\\0":I
    return-object v5
.end method

.method public final queuedBundle(Ljava/lang/String;)Lorg/lighttouch/android/QueueItem;
    .locals 9
    .param p1, "bundleId"    # Ljava/lang/String;

    const-string v0, "bundleId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 198
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getQueue()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 645
    .local v1, "$i$f$firstOrNull\\1\\198":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element\\1":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Lorg/lighttouch/android/QueueItem;

    .local v4, "it\\2":Lorg/lighttouch/android/QueueItem;
    const/4 v5, 0x0

    .line 198
    .local v5, "$i$a$-firstOrNull-StoreModel$queuedBundle$1\\2\\645\\0":I
    invoke-virtual {v4}, Lorg/lighttouch/android/QueueItem;->getKey()Ljava/lang/String;

    move-result-object v6

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "\u5e94\u7528\uff1a"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    .line 645
    .end local v4    # "it\\2":Lorg/lighttouch/android/QueueItem;
    .end local v5    # "$i$a$-firstOrNull-StoreModel$queuedBundle$1\\2\\645\\0":I
    if-eqz v4, :cond_0

    goto :goto_0

    .line 646
    .end local v3    # "element\\1":Ljava/lang/Object;
    :cond_1
    const/4 v3, 0x0

    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull\\1\\198":I
    :goto_0
    check-cast v3, Lorg/lighttouch/android/QueueItem;

    .line 198
    return-object v3
.end method

.method public final refreshGuest()V
    .locals 3

    .line 139
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    .line 140
    .local v0, "socket":Ljava/lang/String;
    :cond_0
    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v1}, Lorg/lighttouch/android/GuestApps;->getAvailable()Z

    move-result v1

    if-nez v1, :cond_1

    return-void

    .line 141
    :cond_1
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda14;

    invoke-direct {v1, p0, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda14;-><init>(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)V

    const-string v2, "store-guest"

    invoke-direct {p0, v2, v1}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 152
    return-void
.end method

.method public final retry(J)V
    .locals 2
    .param p1, "id"    # J

    .line 262
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    iget-object v1, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/StoreInstaller;->setSocket(Ljava/lang/String;)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installer:Lorg/lighttouch/android/StoreInstaller;

    invoke-virtual {v0}, Lorg/lighttouch/android/StoreInstaller;->getQueue()Lorg/lighttouch/android/InstallQueue;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/InstallQueue;->retry(J)V

    return-void
.end method

.method public final search()V
    .locals 6

    .line 155
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    if-nez v0, :cond_0

    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/StoreModel;

    .line 644
    .local v0, "$this$search_u24lambda_u2414\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 155
    .local v1, "$i$a$-run-StoreModel$search$t$1\\1\\155\\0":I
    const-string v2, "\u8bf7\u5148\u9009\u62e9\u8bbe\u5907\u3002"

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/StoreModel;->setMessage(Ljava/lang/String;)V

    return-void

    .line 156
    .end local v1    # "$i$a$-run-StoreModel$search$t$1\\1\\155\\0":I
    .local v0, "t":Lorg/lighttouch/android/StoreTarget;
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getQuery()Ljava/lang/String;

    move-result-object v1

    .local v1, "q":Ljava/lang/String;
    iget v2, p0, Lorg/lighttouch/android/StoreModel;->searchGeneration:I

    const/4 v3, 0x1

    add-int/2addr v2, v3

    iput v2, p0, Lorg/lighttouch/android/StoreModel;->searchGeneration:I

    iget v2, p0, Lorg/lighttouch/android/StoreModel;->searchGeneration:I

    .line 157
    .local v2, "generation":I
    iget-object v4, p0, Lorg/lighttouch/android/StoreModel;->browser:Lorg/lighttouch/android/StoreBrowser;

    sget-object v5, Lorg/lighttouch/android/StoreTab;->DEVICE:Lorg/lighttouch/android/StoreTab;

    invoke-virtual {v4, v5}, Lorg/lighttouch/android/StoreBrowser;->setTab(Lorg/lighttouch/android/StoreTab;)V

    .line 158
    invoke-virtual {p0, v3}, Lorg/lighttouch/android/StoreModel;->setSearching(Z)V

    const-string v3, ""

    invoke-virtual {p0, v3}, Lorg/lighttouch/android/StoreModel;->setMessage(Ljava/lang/String;)V

    .line 159
    new-instance v3, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda6;

    invoke-direct {v3, p0, v1, v0, v2}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;I)V

    const-string v4, "store-search"

    invoke-direct {p0, v4, v3}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 168
    return-void
.end method

.method public final setCandidate(Lorg/json/JSONObject;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/json/JSONObject;

    .line 92
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->candidate$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 621
    .local v2, "$i$f$setValue\\1\\92":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 622
    nop

    .line 92
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\92":I
    return-void
.end method

.method public final setChosen(Lorg/json/JSONObject;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/json/JSONObject;

    .line 88
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->chosen$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 609
    .local v2, "$i$f$setValue\\1\\88":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 610
    nop

    .line 88
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\88":I
    return-void
.end method

.method public final setCopies(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCopy;",
            ">;)V"
        }
    .end annotation

    .line 89
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->copies$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 612
    .local v2, "$i$f$setValue\\1\\89":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 613
    nop

    .line 89
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\89":I
    return-void
.end method

.method public final setCrash(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 105
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->crash$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 639
    .local v2, "$i$f$setValue\\1\\105":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 640
    nop

    .line 105
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\105":I
    return-void
.end method

.method public final setInfo(Lorg/json/JSONObject;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/json/JSONObject;

    .line 101
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->info$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 627
    .local v2, "$i$f$setValue\\1\\101":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 628
    nop

    .line 101
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\101":I
    return-void
.end method

.method public final setInstalled(Ljava/util/Map;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 94
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installed$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 624
    .local v2, "$i$f$setValue\\1\\94":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 625
    nop

    .line 94
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\94":I
    return-void
.end method

.method public final setMessage(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 87
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->message$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 606
    .local v2, "$i$f$setValue\\1\\87":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 607
    nop

    .line 87
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\87":I
    return-void
.end method

.method public final setProblem(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 91
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->problem$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 618
    .local v2, "$i$f$setValue\\1\\91":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 619
    nop

    .line 91
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\91":I
    return-void
.end method

.method public final setQuery(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 83
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->query$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 594
    .local v2, "$i$f$setValue\\1\\83":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 595
    nop

    .line 83
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\83":I
    return-void
.end method

.method public final setQueue(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->queue$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 633
    .local v2, "$i$f$setValue\\1\\103":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 634
    nop

    .line 103
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\103":I
    return-void
.end method

.method public final setResults(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lorg/json/JSONObject;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->results$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 597
    .local v2, "$i$f$setValue\\1\\84":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 598
    nop

    .line 84
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\84":I
    return-void
.end method

.method public final setSearchOpen(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 104
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->searchOpen$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 636
    .local v3, "$i$f$setValue\\1\\104":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 637
    nop

    .line 104
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\104":I
    return-void
.end method

.method public final setSearching(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 86
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->searching$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 603
    .local v3, "$i$f$setValue\\1\\86":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 604
    nop

    .line 86
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\86":I
    return-void
.end method

.method public final setSelected(Ljava/lang/Integer;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/Integer;

    .line 90
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->selected$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 615
    .local v2, "$i$f$setValue\\1\\90":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 616
    nop

    .line 90
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\90":I
    return-void
.end method

.method public final setShots(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreShot;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->shots$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 630
    .local v2, "$i$f$setValue\\1\\102":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 631
    nop

    .line 102
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\102":I
    return-void
.end method

.method public final setShowIncompatible(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 85
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->showIncompatible$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 600
    .local v3, "$i$f$setValue\\1\\85":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 601
    nop

    .line 85
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\85":I
    return-void
.end method

.method public final setTarget(Lorg/lighttouch/android/StoreTarget;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/StoreTarget;

    .line 81
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->target$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 588
    .local v2, "$i$f$setValue\\1\\81":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 589
    nop

    .line 81
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\81":I
    return-void
.end method

.method public final setTargetConfirmed(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 82
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->targetConfirmed$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 591
    .local v3, "$i$f$setValue\\1\\82":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 592
    nop

    .line 82
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\82":I
    return-void
.end method

.method public final showLastCrash()V
    .locals 3

    .line 239
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_0

    move-object v0, p0

    check-cast v0, Lorg/lighttouch/android/StoreModel;

    .line 644
    .local v0, "$this$showLastCrash_u24lambda_u2444\\1":Lorg/lighttouch/android/StoreModel;
    const/4 v1, 0x0

    .line 239
    .local v1, "$i$a$-run-StoreModel$showLastCrash$socket$1\\1\\239\\0":I
    const-string v2, "\u542f\u52a8\u5ba2\u6237\u673a\u4ee5\u8bfb\u53d6\u5176\u5d29\u6e83\u62a5\u544a\u3002"

    invoke-virtual {v0, v2}, Lorg/lighttouch/android/StoreModel;->setCrash(Ljava/lang/String;)V

    return-void

    .line 240
    .end local v1    # "$i$a$-run-StoreModel$showLastCrash$socket$1\\1\\239\\0":I
    .local v0, "socket":Ljava/lang/String;
    :cond_0
    const-string v1, "\u6b63\u5728\u8bfb\u53d6\u5ba2\u6237\u673a\u7684\u5d29\u6e83\u62a5\u544a\u2026"

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setCrash(Ljava/lang/String;)V

    .line 241
    new-instance v1, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda23;

    invoke-direct {v1, p0, v0}, Lorg/lighttouch/android/StoreModel$$ExternalSyntheticLambda23;-><init>(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)V

    const-string v2, "store-crash"

    invoke-direct {p0, v2, v1}, Lorg/lighttouch/android/StoreModel;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 253
    return-void
.end method

.method public final useRecord(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)V
    .locals 4
    .param p1, "id"    # Ljava/lang/String;
    .param p2, "next"    # Lorg/lighttouch/android/StoreTarget;

    const-string v0, "id"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 128
    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->recordId:Ljava/lang/String;

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    iput-object p1, p0, Lorg/lighttouch/android/StoreModel;->recordId:Ljava/lang/String;

    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setInstalled(Ljava/util/Map;)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->reset()V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setTargetConfirmed(Z)V

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreModel;->setTarget(Lorg/lighttouch/android/StoreTarget;)V

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setResults(Ljava/util/List;)V

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreModel;->setChosen(Lorg/json/JSONObject;)V

    .line 129
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTargetConfirmed()Z

    move-result v0

    if-eqz v0, :cond_3

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Lorg/lighttouch/android/StoreTarget;->getProductType()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    move-object v0, v2

    :goto_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Lorg/lighttouch/android/StoreTarget;->getProductType()Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :cond_2
    move-object v3, v2

    :goto_1
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_2

    .line 130
    :cond_3
    invoke-virtual {p0, p2}, Lorg/lighttouch/android/StoreModel;->setTarget(Lorg/lighttouch/android/StoreTarget;)V

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/StoreModel;->setTargetConfirmed(Z)V

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setResults(Ljava/util/List;)V

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/StoreModel;->setChosen(Lorg/json/JSONObject;)V

    iget-object v0, p0, Lorg/lighttouch/android/StoreModel;->installedList:Lorg/lighttouch/android/InstalledList;

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->forgetLookups()V

    .line 131
    if-eqz p2, :cond_4

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->search()V

    .line 132
    :cond_4
    return-void

    .line 129
    :cond_5
    :goto_2
    return-void
.end method

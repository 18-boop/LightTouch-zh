.class public final Lorg/lighttouch/android/StoreScreenKt;
.super Ljava/lang/Object;
.source "StoreScreen.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/StoreScreenKt$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 5 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n+ 9 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 10 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 11 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 12 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 13 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 14 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt\n*L\n1#1,586:1\n1#2:587\n1225#3,6:588\n1225#3,6:636\n1225#3,6:642\n1225#3,6:685\n1225#3,6:701\n1225#3,6:707\n1225#3,6:790\n1225#3,6:833\n1225#3,6:839\n1225#3,6:854\n1225#3,6:860\n1225#3,6:866\n1225#3,6:874\n1225#3,6:880\n1225#3,6:1008\n1225#3,6:1296\n1225#3,6:1303\n1225#3,6:1319\n1225#3,6:1331\n1225#3,6:1379\n1225#3,6:1427\n1225#3,6:1433\n1225#3,6:1440\n1225#3,6:1451\n1225#3,6:1573\n1225#3,6:1579\n149#4:594\n169#4:595\n149#4:648\n149#4:695\n149#4:696\n149#4:700\n149#4:713\n149#4:872\n149#4:873\n149#4:886\n149#4:919\n149#4:920\n149#4:925\n149#4:1007\n149#4:1050\n149#4:1091\n149#4:1136\n149#4:1173\n149#4:1210\n149#4:1256\n149#4:1257\n149#4:1294\n149#4:1295\n149#4:1302\n149#4:1313\n149#4:1316\n149#4:1317\n149#4:1318\n149#4:1325\n149#4:1330\n149#4:1337\n149#4:1338\n149#4:1391\n149#4:1439\n149#4:1450\n149#4:1457\n149#4:1458\n149#4:1459\n71#5:596\n68#5,6:597\n74#5:631\n78#5:635\n71#5:796\n67#5,7:797\n74#5:832\n78#5:848\n71#5:1051\n68#5,6:1052\n74#5:1086\n78#5:1090\n71#5:1392\n69#5,5:1393\n74#5:1426\n78#5:1449\n79#6,6:603\n86#6,4:618\n90#6,2:628\n94#6:634\n79#6,6:656\n86#6,4:671\n90#6,2:681\n94#6:693\n79#6,6:721\n86#6,4:736\n90#6,2:746\n79#6,6:757\n86#6,4:772\n90#6,2:782\n94#6:788\n79#6,6:804\n86#6,4:819\n90#6,2:829\n94#6:847\n94#6:851\n79#6,6:890\n86#6,4:905\n90#6,2:915\n94#6:923\n79#6,6:933\n86#6,4:948\n90#6,2:958\n79#6,6:970\n86#6,4:985\n90#6,2:995\n94#6:1001\n94#6:1005\n79#6,6:1021\n86#6,4:1036\n90#6,2:1046\n79#6,6:1058\n86#6,4:1073\n90#6,2:1083\n94#6:1089\n79#6,6:1099\n86#6,4:1114\n90#6,2:1124\n94#6:1130\n94#6:1134\n79#6,6:1144\n86#6,4:1159\n90#6,2:1169\n79#6,6:1181\n86#6,4:1196\n90#6,2:1206\n79#6,6:1219\n86#6,4:1234\n90#6,2:1244\n94#6:1250\n94#6:1254\n79#6,6:1265\n86#6,4:1280\n90#6,2:1290\n94#6:1311\n94#6:1328\n79#6,6:1346\n86#6,4:1361\n90#6,2:1371\n94#6:1377\n79#6,6:1398\n86#6,4:1413\n90#6,2:1423\n94#6:1448\n79#6,6:1467\n86#6,4:1482\n90#6,2:1492\n79#6,6:1504\n86#6,4:1519\n90#6,2:1529\n79#6,6:1540\n86#6,4:1555\n90#6,2:1565\n94#6:1571\n94#6:1587\n94#6:1591\n368#7,9:609\n377#7:630\n378#7,2:632\n368#7,9:662\n377#7:683\n378#7,2:691\n368#7,9:727\n377#7:748\n368#7,9:763\n377#7:784\n378#7,2:786\n368#7,9:810\n377#7:831\n378#7,2:845\n378#7,2:849\n368#7,9:896\n377#7:917\n378#7,2:921\n368#7,9:939\n377#7:960\n368#7,9:976\n377#7:997\n378#7,2:999\n378#7,2:1003\n368#7,9:1027\n377#7:1048\n368#7,9:1064\n377#7:1085\n378#7,2:1087\n368#7,9:1105\n377#7:1126\n378#7,2:1128\n378#7,2:1132\n368#7,9:1150\n377#7:1171\n368#7,9:1187\n377#7:1208\n368#7,9:1225\n377#7:1246\n378#7,2:1248\n378#7,2:1252\n368#7,9:1271\n377#7:1292\n378#7,2:1309\n378#7,2:1326\n368#7,9:1352\n377#7:1373\n378#7,2:1375\n368#7,9:1404\n377#7:1425\n378#7,2:1446\n368#7,9:1473\n377#7:1494\n368#7,9:1510\n377#7:1531\n368#7,9:1546\n377#7:1567\n378#7,2:1569\n378#7,2:1585\n378#7,2:1589\n4034#8,6:622\n4034#8,6:675\n4034#8,6:740\n4034#8,6:776\n4034#8,6:823\n4034#8,6:909\n4034#8,6:952\n4034#8,6:989\n4034#8,6:1040\n4034#8,6:1077\n4034#8,6:1118\n4034#8,6:1163\n4034#8,6:1200\n4034#8,6:1238\n4034#8,6:1284\n4034#8,6:1365\n4034#8,6:1417\n4034#8,6:1486\n4034#8,6:1523\n4034#8,6:1559\n99#9:649\n96#9,6:650\n102#9:684\n106#9:694\n99#9:714\n96#9,6:715\n102#9:749\n106#9:852\n99#9:926\n96#9,6:927\n102#9:961\n106#9:1006\n99#9:1014\n96#9,6:1015\n102#9:1049\n106#9:1135\n99#9:1174\n96#9,6:1175\n102#9:1209\n106#9:1255\n99#9:1496\n95#9,7:1497\n102#9:1532\n106#9:1588\n774#10:697\n865#10,2:698\n295#10,2:1314\n1761#10,3:1385\n1761#10,3:1388\n86#11:750\n83#11,6:751\n89#11:785\n93#11:789\n86#11,3:887\n89#11:918\n93#11:924\n86#11:962\n82#11,7:963\n89#11:998\n93#11:1002\n86#11:1092\n83#11,6:1093\n89#11:1127\n93#11:1131\n86#11:1137\n83#11,6:1138\n89#11:1172\n86#11:1211\n82#11,7:1212\n89#11:1247\n93#11:1251\n86#11:1258\n83#11,6:1259\n89#11:1293\n93#11:1312\n93#11:1329\n86#11:1339\n83#11,6:1340\n89#11:1374\n93#11:1378\n86#11:1460\n83#11,6:1461\n89#11:1495\n86#11:1533\n83#11,6:1534\n89#11:1568\n93#11:1572\n93#11:1592\n77#12:853\n81#13:1593\n81#13:1606\n107#13,2:1607\n81#13:1621\n81#13:1634\n107#13,2:1635\n143#14,12:1594\n143#14,12:1609\n143#14,12:1622\n*S KotlinDebug\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt\n*L\n269#1:588,6\n286#1:636,6\n288#1:642,6\n330#1:685,6\n338#1:701,6\n345#1:707,6\n356#1:790,6\n360#1:833,6\n361#1:839,6\n375#1:854,6\n376#1:860,6\n377#1:866,6\n385#1:874,6\n378#1:880,6\n413#1:1008,6\n461#1:1296,6\n462#1:1303,6\n491#1:1319,6\n501#1:1331,6\n536#1:1379,6\n540#1:1427,6\n543#1:1433,6\n544#1:1440,6\n567#1:1451,6\n580#1:1573,6\n581#1:1579,6\n270#1:594\n270#1:595\n329#1:648\n333#1:695\n334#1:696\n338#1:700\n347#1:713\n378#1:872\n379#1:873\n390#1:886\n391#1:919\n392#1:920\n403#1:925\n413#1:1007\n415#1:1050\n417#1:1091\n439#1:1136\n440#1:1173\n442#1:1210\n454#1:1256\n456#1:1257\n457#1:1294\n458#1:1295\n462#1:1302\n476#1:1313\n489#1:1316\n491#1:1317\n492#1:1318\n495#1:1325\n501#1:1330\n514#1:1337\n515#1:1338\n539#1:1391\n543#1:1439\n552#1:1450\n567#1:1457\n568#1:1458\n573#1:1459\n270#1:596\n270#1:597,6\n270#1:631\n270#1:635\n359#1:796\n359#1:797,7\n359#1:832\n359#1:848\n416#1:1051\n416#1:1052,6\n416#1:1086\n416#1:1090\n539#1:1392\n539#1:1393,5\n539#1:1426\n539#1:1449\n270#1:603,6\n270#1:618,4\n270#1:628,2\n270#1:634\n329#1:656,6\n329#1:671,4\n329#1:681,2\n329#1:693\n347#1:721,6\n347#1:736,4\n347#1:746,2\n351#1:757,6\n351#1:772,4\n351#1:782,2\n351#1:788\n359#1:804,6\n359#1:819,4\n359#1:829,2\n359#1:847\n347#1:851\n390#1:890,6\n390#1:905,4\n390#1:915,2\n390#1:923\n403#1:933,6\n403#1:948,4\n403#1:958,2\n404#1:970,6\n404#1:985,4\n404#1:995,2\n404#1:1001\n403#1:1005\n413#1:1021,6\n413#1:1036,4\n413#1:1046,2\n416#1:1058,6\n416#1:1073,4\n416#1:1083,2\n416#1:1089\n418#1:1099,6\n418#1:1114,4\n418#1:1124,2\n418#1:1130\n413#1:1134\n439#1:1144,6\n439#1:1159,4\n439#1:1169,2\n440#1:1181,6\n440#1:1196,4\n440#1:1206,2\n443#1:1219,6\n443#1:1234,4\n443#1:1244,2\n443#1:1250\n440#1:1254\n456#1:1265,6\n456#1:1280,4\n456#1:1290,2\n456#1:1311\n439#1:1328\n514#1:1346,6\n514#1:1361,4\n514#1:1371,2\n514#1:1377\n539#1:1398,6\n539#1:1413,4\n539#1:1423,2\n539#1:1448\n573#1:1467,6\n573#1:1482,4\n573#1:1492,2\n574#1:1504,6\n574#1:1519,4\n574#1:1529,2\n575#1:1540,6\n575#1:1555,4\n575#1:1565,2\n575#1:1571\n574#1:1587\n573#1:1591\n270#1:609,9\n270#1:630\n270#1:632,2\n329#1:662,9\n329#1:683\n329#1:691,2\n347#1:727,9\n347#1:748\n351#1:763,9\n351#1:784\n351#1:786,2\n359#1:810,9\n359#1:831\n359#1:845,2\n347#1:849,2\n390#1:896,9\n390#1:917\n390#1:921,2\n403#1:939,9\n403#1:960\n404#1:976,9\n404#1:997\n404#1:999,2\n403#1:1003,2\n413#1:1027,9\n413#1:1048\n416#1:1064,9\n416#1:1085\n416#1:1087,2\n418#1:1105,9\n418#1:1126\n418#1:1128,2\n413#1:1132,2\n439#1:1150,9\n439#1:1171\n440#1:1187,9\n440#1:1208\n443#1:1225,9\n443#1:1246\n443#1:1248,2\n440#1:1252,2\n456#1:1271,9\n456#1:1292\n456#1:1309,2\n439#1:1326,2\n514#1:1352,9\n514#1:1373\n514#1:1375,2\n539#1:1404,9\n539#1:1425\n539#1:1446,2\n573#1:1473,9\n573#1:1494\n574#1:1510,9\n574#1:1531\n575#1:1546,9\n575#1:1567\n575#1:1569,2\n574#1:1585,2\n573#1:1589,2\n270#1:622,6\n329#1:675,6\n347#1:740,6\n351#1:776,6\n359#1:823,6\n390#1:909,6\n403#1:952,6\n404#1:989,6\n413#1:1040,6\n416#1:1077,6\n418#1:1118,6\n439#1:1163,6\n440#1:1200,6\n443#1:1238,6\n456#1:1284,6\n514#1:1365,6\n539#1:1417,6\n573#1:1486,6\n574#1:1523,6\n575#1:1559,6\n329#1:649\n329#1:650,6\n329#1:684\n329#1:694\n347#1:714\n347#1:715,6\n347#1:749\n347#1:852\n403#1:926\n403#1:927,6\n403#1:961\n403#1:1006\n413#1:1014\n413#1:1015,6\n413#1:1049\n413#1:1135\n440#1:1174\n440#1:1175,6\n440#1:1209\n440#1:1255\n574#1:1496\n574#1:1497,7\n574#1:1532\n574#1:1588\n336#1:697\n336#1:698,2\n482#1:1314,2\n537#1:1385,3\n538#1:1388,3\n351#1:750\n351#1:751,6\n351#1:785\n351#1:789\n390#1:887,3\n390#1:918\n390#1:924\n404#1:962\n404#1:963,7\n404#1:998\n404#1:1002\n418#1:1092\n418#1:1093,6\n418#1:1127\n418#1:1131\n439#1:1137\n439#1:1138,6\n439#1:1172\n443#1:1211\n443#1:1212,7\n443#1:1247\n443#1:1251\n456#1:1258\n456#1:1259,6\n456#1:1293\n456#1:1312\n439#1:1329\n514#1:1339\n514#1:1340,6\n514#1:1374\n514#1:1378\n573#1:1460\n573#1:1461,6\n573#1:1495\n575#1:1533\n575#1:1534,6\n575#1:1568\n575#1:1572\n573#1:1592\n374#1:853\n269#1:1593\n345#1:1606\n345#1:1607,2\n503#1:1621\n536#1:1634\n536#1:1635,2\n339#1:1594,12\n463#1:1609,12\n502#1:1622,12\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000x\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u000c\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\r\n\u0002\u0018\u0002\n\u0000\u001a\u0016\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0000\u001a\u0010\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0000\u001a\u0010\u0010\u0006\u001a\u00020\u00012\u0006\u0010\u0007\u001a\u00020\u0008H\u0000\u001a-\u0010\t\u001a\u00020\n2\u0008\u0010\u000b\u001a\u0004\u0018\u00010\u00012\u0008\u0008\u0002\u0010\u000c\u001a\u00020\r2\n\u0008\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0001H\u0001\u00a2\u0006\u0002\u0010\u000f\u001a9\u0010\u0010\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u000c\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\n0\u00162\u000c\u0010\u0017\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016H\u0001\u00a2\u0006\u0002\u0010\u0018\u001a\u0019\u0010\u0019\u001a\u00020\n*\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u0012H\u0003\u00a2\u0006\u0002\u0010\u001b\u001aA\u0010\u001c\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u000c\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\n0\u00162\u0006\u0010\u001d\u001a\u00020\u00142\u000c\u0010\u001e\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016H\u0003\u00a2\u0006\u0002\u0010\u001f\u001a\u001d\u0010 \u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010!\u001a\u00020\"H\u0003\u00a2\u0006\u0002\u0010#\u001a\u0019\u0010$\u001a\u00020\n*\u00020\u001a2\u0006\u0010%\u001a\u00020\u0014H\u0003\u00a2\u0006\u0002\u0010&\u001a)\u0010\'\u001a\u00020\n2\u0006\u0010(\u001a\u00020\u00022\u0006\u0010\u0011\u001a\u00020\u00122\n\u0008\u0002\u0010)\u001a\u0004\u0018\u00010\rH\u0001\u00a2\u0006\u0002\u0010*\u001a)\u0010+\u001a\u00020\n*\u00020\u001a2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010(\u001a\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0014H\u0003\u00a2\u0006\u0002\u0010,\u001a\u001b\u0010-\u001a\u00020\n2\u000c\u0010.\u001a\u0008\u0012\u0004\u0012\u0002000/H\u0003\u00a2\u0006\u0002\u00101\u001a5\u00102\u001a\u00020\n2\u0008\u0008\u0002\u0010!\u001a\u00020\"2\u001c\u00103\u001a\u0018\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\n04\u00a2\u0006\u0002\u00085\u00a2\u0006\u0002\u00086H\u0003\u00a2\u0006\u0002\u00107\u001a\u0016\u00108\u001a\u0002092\u000c\u0010:\u001a\u0008\u0012\u0004\u0012\u00020;0/H\u0000\u001a\u0015\u0010<\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u0012H\u0003\u00a2\u0006\u0002\u0010=\u001a+\u0010>\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010?\u001a\u00020\u00142\u000c\u0010@\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0016H\u0003\u00a2\u0006\u0002\u0010A\u001a\u0015\u0010B\u001a\u00020\n2\u0006\u0010C\u001a\u00020;H\u0003\u00a2\u0006\u0002\u0010D\u001a\u001d\u0010E\u001a\u00020\n2\u0006\u0010C\u001a\u00020;2\u0006\u0010\u0011\u001a\u00020\u0012H\u0003\u00a2\u0006\u0002\u0010F\u00a8\u0006G\u00b2\u0006\u000c\u0010H\u001a\u0004\u0018\u00010IX\u008a\u0084\u0002\u00b2\u0006\n\u0010J\u001a\u00020\u0014X\u008a\u008e\u0002\u00b2\u0006\u000c\u0010H\u001a\u0004\u0018\u00010IX\u008a\u0084\u0002\u00b2\u0006\n\u0010?\u001a\u00020\u0014X\u008a\u008e\u0002"
    }
    d2 = {
        "text",
        "",
        "Lorg/json/JSONObject;",
        "key",
        "productName",
        "productType",
        "byteSize",
        "bytes",
        "",
        "AppIcon",
        "",
        "url",
        "size",
        "",
        "fallback",
        "(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V",
        "StoreScreen",
        "model",
        "Lorg/lighttouch/android/StoreModel;",
        "running",
        "",
        "onPickLocal",
        "Lkotlin/Function0;",
        "onClose",
        "(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "DeviceTab",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V",
        "StoreTopBar",
        "canSearch",
        "onBack",
        "(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "SearchField",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V",
        "EmptyResults",
        "filtered",
        "(Landroidx/compose/foundation/layout/ColumnScope;ZLandroidx/compose/runtime/Composer;I)V",
        "ResultRow",
        "app",
        "rank",
        "(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;Landroidx/compose/runtime/Composer;II)V",
        "StoreDetails",
        "(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZLandroidx/compose/runtime/Composer;I)V",
        "Screenshots",
        "shots",
        "",
        "Lorg/lighttouch/android/StoreShot;",
        "(Ljava/util/List;Landroidx/compose/runtime/Composer;I)V",
        "StoreCard",
        "content",
        "Lkotlin/Function1;",
        "Landroidx/compose/runtime/Composable;",
        "Lkotlin/ExtensionFunctionType;",
        "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V",
        "queueFraction",
        "",
        "items",
        "Lorg/lighttouch/android/QueueItem;",
        "QueueButton",
        "(Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V",
        "QueueMenu",
        "open",
        "onDismiss",
        "(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "QueueProgress",
        "item",
        "(Lorg/lighttouch/android/QueueItem;Landroidx/compose/runtime/Composer;I)V",
        "QueueRow",
        "(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "bitmap",
        "Landroid/graphics/Bitmap;",
        "menu"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$-BvAc4btzmF7sfUITxSuRADYJt4(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$31$lambda$25$lambda$24(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$1BCVUEmePJ6mS9KlRYQLmmoyCa4(Ljava/util/List;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->Screenshots$lambda$94$lambda$93(Ljava/util/List;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6rzJJM1oSPAes48r6trUnmmRgFU(Lorg/lighttouch/android/QueueItem;)F
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->QueueProgress$lambda$114$lambda$113(Lorg/lighttouch/android/QueueItem;)F

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$79C1tXzhwrRuU9Dfcy_kXtb1slw(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/StoreScreenKt;->ResultRow$lambda$46(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7l61Jrq9gIHTS2YzfL09Um2cdYg(Lorg/lighttouch/android/StoreCopy;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$lambda$67(Lorg/lighttouch/android/StoreCopy;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7xF8NKlQN2fxL0JZAuR7Vqf-iBI(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/text/KeyboardActionScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->SearchField$lambda$38$lambda$37(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/text/KeyboardActionScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8uNLaZYqDLsqjY1qOdB-l0ZM7-U(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/StoreScreenKt;->ResultRow$lambda$58(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$94aaPCL1IRwBbrhbuEZkHtp6Mb8(Ljava/util/List;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->Screenshots$lambda$95(Ljava/util/List;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9kjzerYzWhT-zwAHRKAIMehzh0A(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->QueueRow$lambda$122$lambda$121$lambda$120$lambda$119(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$AqAHQ191nNun68l11xhXOTphATc(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->ResultRow$lambda$48$lambda$47(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Bv15KN4A5pIMJ44_4g4aKfQYtUQ(Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$111(Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$CrHh-cuQx7-XjLHfizSXL78g0R8(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$110$lambda$109$lambda$108(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$DcWPUYwCkFcoYbLBi4N6daHxvQ8(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$31$lambda$30$lambda$27$lambda$26(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$EUiL6G8WcBzrHIiRWoqM-1qYugw(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreScreenKt;->QueueRow$lambda$123(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FGIq11NOpcHicx522ts4-sKb8qM(Lorg/lighttouch/android/StoreShot;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->Screenshots$lambda$94$lambda$93$lambda$87(Lorg/lighttouch/android/StoreShot;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$FwvuOjwwR_NxrSUi76366SIGNU0(Ljava/lang/String;ILjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon$lambda$5(Ljava/lang/String;ILjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$JQdj9t7bWCSEgwjEPz_DmYs29SY(Lorg/lighttouch/android/QueueItem;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->QueueProgress$lambda$115(Lorg/lighttouch/android/QueueItem;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$N3TsRque6uUUMvxLE0AmeKfxjCQ(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$31$lambda$30$lambda$29$lambda$28(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Nc4zH3n-Jj48uopgjG4bFVsSXV8(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/StoreScreenKt;->StoreDetails$lambda$86(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NxXdbMenoQgBXI5nOYy-Z0uq5aA(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->StoreScreen$lambda$8$lambda$7(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$O-7FkQj9uK8Z8YxImJALDgiVCto(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->DeviceTab$lambda$12$lambda$11$lambda$10(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$T-E9t8mx9TsMzSkTdta-WVyhgBQ(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->QueueRow$lambda$122$lambda$121$lambda$118$lambda$117(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TzqRYgwNpIx-UAOiDOyRPcfZGtA(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$110$lambda$105$lambda$104(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$VVJwb8dAga0mbh-0AtbzPQHHmh0(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreScreenKt;->DeviceTab$lambda$17$lambda$16(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$WA6NJvG3yPXqLic3tWzBwPY58DI(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/StoreScreenKt;->StoreScreen$lambda$9(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$WdM1ETsHNpsb6B5J20ZuWKOyQgg(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreScreenKt;->SearchField$lambda$41(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_PrWeZgCvK7n8N9QRXH2Mz2pzZk(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->SearchField$lambda$40$lambda$39(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$co8T6nOfNQaCtaot0AeBFkxW5Uo(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/StoreScreenKt;->StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dMA8Fq6o2w_c0yy6uSfI7hgg8F0(Landroidx/compose/foundation/layout/ColumnScope;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreScreenKt;->EmptyResults$lambda$43(Landroidx/compose/foundation/layout/ColumnScope;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dSjmzbTk7oDD6jIcl4ZwAyd5Bc0(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/platform/SoftwareKeyboardController;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->SearchField$lambda$36$lambda$35(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/platform/SoftwareKeyboardController;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fM3uRDINWAijIASCOg9vBbYMzGg(Lorg/json/JSONObject;)Ljava/lang/Object;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->DeviceTab$lambda$17$lambda$16$lambda$14(Lorg/json/JSONObject;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$gtl-NjVdb3T5s-MUvnir9X-0rDU(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->StoreDetails$lambda$85$lambda$84$lambda$83(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$hFdU4oUVhsnnYLtuRoraa4IgVhM(Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$98(Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$hjxvVQlB5tBA_WbRMhqkjBeANOs(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreScreenKt;->DeviceTab$lambda$18(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$kdbUzlLr1V1pWLrpPzMp-ivT2gc(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$32(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$nvYw3HTLoJk8zaoQFXycWHKLRRM(Ljava/util/List;)F
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$110$lambda$107$lambda$106(Ljava/util/List;)F

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$pQgWAi2uGbs8JSC_Pg1GRowrw_g(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/StoreScreenKt;->StoreCard$lambda$96(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tBoMdz1Ax7xP95IGT99mEMr0xyQ(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/StoreScreenKt;->QueueMenu$lambda$112(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final AppIcon(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V
    .locals 53
    .param p0, "url"    # Ljava/lang/String;
    .param p1, "size"    # I
    .param p2, "fallback"    # Ljava/lang/String;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    .line 268
    move-object/from16 v1, p0

    move/from16 v4, p4

    const v0, -0x2afd8930

    move-object/from16 v2, p3

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(AppIcon)P(2,1)268@13973L77,268@13940L110,269@14150L11,269@14055L669:StoreScreen.kt#o13vsk"

    invoke-static {v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p4

    .local v2, "$dirty":I
    and-int/lit8 v3, p5, 0x1

    const/4 v5, 0x4

    if-eqz v3, :cond_0

    or-int/lit8 v2, v2, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v3, v4, 0x6

    if-nez v3, :cond_2

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    move v3, v5

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_2
    :goto_1
    and-int/lit8 v3, p5, 0x2

    if-eqz v3, :cond_3

    or-int/lit8 v2, v2, 0x30

    move/from16 v7, p1

    goto :goto_3

    :cond_3
    and-int/lit8 v7, v4, 0x30

    if-nez v7, :cond_5

    move/from16 v7, p1

    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v8

    if-eqz v8, :cond_4

    const/16 v8, 0x20

    goto :goto_2

    :cond_4
    const/16 v8, 0x10

    :goto_2
    or-int/2addr v2, v8

    goto :goto_3

    :cond_5
    move/from16 v7, p1

    :goto_3
    and-int/lit8 v8, p5, 0x4

    if-eqz v8, :cond_6

    or-int/lit16 v2, v2, 0x180

    move-object/from16 v9, p2

    goto :goto_5

    :cond_6
    and-int/lit16 v9, v4, 0x180

    if-nez v9, :cond_8

    move-object/from16 v9, p2

    invoke-interface {v6, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_7

    const/16 v10, 0x100

    goto :goto_4

    :cond_7
    const/16 v10, 0x80

    :goto_4
    or-int/2addr v2, v10

    goto :goto_5

    :cond_8
    move-object/from16 v9, p2

    :goto_5
    move v10, v2

    .end local v2    # "$dirty":I
    .local v10, "$dirty":I
    and-int/lit16 v2, v10, 0x93

    const/16 v11, 0x92

    if-ne v2, v11, :cond_a

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_9

    goto :goto_6

    .line 635
    :cond_9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v2, v7

    move-object v3, v9

    goto/16 :goto_14

    .line 268
    :cond_a
    :goto_6
    if-eqz v3, :cond_b

    const/16 v2, 0x30

    .end local p1    # "size":I
    .local v2, "size":I
    goto :goto_7

    .end local v2    # "size":I
    .restart local p1    # "size":I
    :cond_b
    move v2, v7

    .end local p1    # "size":I
    .restart local v2    # "size":I
    :goto_7
    if-eqz v8, :cond_c

    const/4 v3, 0x0

    .end local p2    # "fallback":Ljava/lang/String;
    .local v3, "fallback":Ljava/lang/String;
    goto :goto_8

    .end local v3    # "fallback":Ljava/lang/String;
    .restart local p2    # "fallback":Ljava/lang/String;
    :cond_c
    move-object v3, v9

    .end local p2    # "fallback":Ljava/lang/String;
    .restart local v3    # "fallback":Ljava/lang/String;
    :goto_8
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_d

    const/4 v7, -0x1

    const-string v8, "org.lighttouch.android.AppIcon (StoreScreen.kt:267)"

    invoke-static {v0, v10, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 269
    :cond_d
    const v0, 0x4c5de2

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v10, 0xe

    const/4 v7, 0x0

    if-ne v0, v5, :cond_e

    const/4 v0, 0x1

    goto :goto_9

    :cond_e
    move v0, v7

    .local v0, "invalid\\1":Z
    :goto_9
    move-object v5, v6

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 588
    .local v9, "$i$f$cache\\1\\269":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 589
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\588\\1":I
    const/4 v13, 0x0

    if-nez v0, :cond_10

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v11, v14, :cond_f

    goto :goto_a

    .line 593
    :cond_f
    move-object v15, v11

    goto :goto_b

    .line 590
    :cond_10
    :goto_a
    const/4 v14, 0x0

    .line 269
    .local v14, "$i$a$-cache-StoreScreenKt$AppIcon$bitmap$2\\3\\590\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreScreenKt$AppIcon$bitmap$2$1;

    invoke-direct {v15, v1, v13}, Lorg/lighttouch/android/StoreScreenKt$AppIcon$bitmap$2$1;-><init>(Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    check-cast v15, Lkotlin/jvm/functions/Function2;

    .line 590
    .end local v14    # "$i$a$-cache-StoreScreenKt$AppIcon$bitmap$2\\3\\590\\0":I
    nop

    .line 591
    .local v15, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 592
    nop

    .line 589
    .end local v15    # "value\\2":Ljava/lang/Object;
    :goto_b
    nop

    .line 588
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\588\\1":I
    nop

    .line 269
    .end local v0    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\1\\269":I
    check-cast v15, Lkotlin/jvm/functions/Function2;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    shl-int/lit8 v0, v10, 0x3

    and-int/lit8 v0, v0, 0x70

    or-int/lit8 v0, v0, 0x6

    invoke-static {v13, v1, v15, v6, v0}, Landroidx/compose/runtime/SnapshotStateKt;->produceState(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/State;

    move-result-object v0

    .line 270
    .local v0, "bitmap$delegate":Landroidx/compose/runtime/State;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    move v9, v2

    .local v9, "$this$dp\\4":I
    const/4 v11, 0x0

    .line 594
    .local v11, "$i$f$getDp\\4\\270":I
    int-to-float v12, v9

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 270
    .end local v9    # "$this$dp\\4":I
    .end local v11    # "$i$f$getDp\\4\\270":I
    invoke-static {v5, v9}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    int-to-float v9, v2

    const/high16 v11, 0x40900000    # 4.5f

    div-float/2addr v9, v11

    .local v9, "$this$dp\\5":F
    const/4 v11, 0x0

    .line 595
    .local v11, "$i$f$getDp\\5\\270":I
    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 270
    .end local v9    # "$this$dp\\5":F
    .end local v11    # "$i$f$getDp\\5\\270":I
    invoke-static {v9}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v9

    check-cast v9, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v5, v9}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v6, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHighest-0d7_KjU()J

    move-result-wide v15

    const/16 v18, 0x2

    const/16 v19, 0x0

    const/16 v17, 0x0

    invoke-static/range {v14 .. v19}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\6":Landroidx/compose/ui/Modifier;
    const/4 v9, 0x0

    .local v9, "$changed\\6":I
    const/4 v11, 0x0

    .line 596
    .local v11, "$i$f$Box\\6\\270":I
    const v12, 0x2bb5b5d7

    const-string v14, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v6, v12, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 597
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v12

    .line 598
    .local v12, "contentAlignment\\6":Landroidx/compose/ui/Alignment;
    const/4 v14, 0x0

    .line 601
    .local v14, "propagateMinConstraints\\6":Z
    invoke-static {v12, v14}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v9, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 602
    nop

    .local v16, "$changed\\7":I
    const/16 v17, 0x0

    .line 603
    .local v17, "$i$f$Layout\\7\\602":I
    const v8, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v6, v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 604
    invoke-static {v6, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v8

    .line 605
    .local v8, "compositeKeyHash\\7":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 606
    .local v13, "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 608
    .local v7, "materialized\\7":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v19, v0

    .end local v0    # "bitmap$delegate":Landroidx/compose/runtime/State;
    .local v19, "bitmap$delegate":Landroidx/compose/runtime/State;
    shl-int/lit8 v0, v16, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 607
    move-object/from16 v20, v18

    .local v0, "$changed\\8":I
    .local v20, "factory\\8":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 609
    .local v18, "$i$f$ReusableComposeNode\\8\\607":I
    move/from16 v21, v0

    .end local v0    # "$changed\\8":I
    .local v21, "$changed\\8":I
    const v0, -0x2942ffcf

    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 610
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 611
    :cond_11
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 612
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_12

    .line 613
    move-object/from16 v0, v20

    .end local v20    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 615
    .end local v0    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\8":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v0, v20

    .end local v20    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 617
    :goto_c
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 618
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\9\\617\\7":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v0

    .end local v0    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 619
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 621
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\10":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 622
    .local v22, "$i$f$set-impl\\10\\621":I
    move-object/from16 v24, v1

    .local v24, "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 623
    .local v25, "$i$a$-with-Updater$set$1\\11\\622\\10":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_14

    move-object/from16 v26, v3

    .end local v3    # "fallback":Ljava/lang/String;
    .local v26, "fallback":Ljava/lang/String;
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_13

    goto :goto_d

    :cond_13
    move-object/from16 v4, v24

    goto :goto_e

    .end local v26    # "fallback":Ljava/lang/String;
    .restart local v3    # "fallback":Ljava/lang/String;
    :cond_14
    move-object/from16 v26, v3

    .line 624
    .end local v3    # "fallback":Ljava/lang/String;
    .restart local v26    # "fallback":Ljava/lang/String;
    :goto_d
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 625
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 627
    :goto_e
    nop

    .line 622
    .end local v4    # "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\11\\622\\10":I
    nop

    .line 627
    nop

    .line 628
    .end local v0    # "block\\10":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\10\\621":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 629
    nop

    .line 617
    .end local v1    # "$this$Layout_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\9\\617\\7":I
    nop

    .line 630
    shr-int/lit8 v0, v21, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\12":I
    move-object v1, v6

    .local v1, "$composer\\12":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 631
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\12\\630\\6":I
    const v4, -0x7ff519f7    # -1.000876E-39f

    move/from16 v20, v0

    .end local v0    # "$changed\\12":I
    .local v20, "$changed\\12":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v4, v9, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\13":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$AppIcon_u24lambda_u244\\13":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v35, v1

    .local v35, "$composer\\13":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 271
    .local v22, "$i$a$-Box-StoreScreenKt$AppIcon$1\\13\\631\\0":I
    move-object/from16 v24, v1

    .end local v1    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v24, "$composer\\12":Landroidx/compose/runtime/Composer;
    const v1, 0x48ddb425

    move/from16 v25, v3

    .end local v3    # "$i$a$-Layout-BoxKt$Box$1\\12\\630\\6":I
    .local v25, "$i$a$-Layout-BoxKt$Box$1\\12\\630\\6":I
    const-string v3, "C:StoreScreen.kt#o13vsk"

    move/from16 v52, v4

    move-object/from16 v4, v35

    .end local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v52, "$changed\\13":I
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static/range {v19 .. v19}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon$lambda$2(Landroidx/compose/runtime/State;)Landroid/graphics/Bitmap;

    move-result-object v1

    const v3, 0x446a3eea

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*270@14212L76"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v1, :cond_15

    move-object/from16 p2, v5

    goto :goto_f

    .line 587
    .local v1, "it\\14":Landroid/graphics/Bitmap;
    :cond_15
    const/4 v3, 0x0

    .line 271
    .local v3, "$i$a$-let-StoreScreenKt$AppIcon$1$1\\14\\271\\13":I
    invoke-static {v1}, Landroidx/compose/ui/graphics/AndroidImageBitmap_androidKt;->asImageBitmap(Landroid/graphics/Bitmap;)Landroidx/compose/ui/graphics/ImageBitmap;

    move-result-object v27

    sget-object v28, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v38, v1

    .end local v1    # "it\\14":Landroid/graphics/Bitmap;
    .local v38, "it\\14":Landroid/graphics/Bitmap;
    move-object/from16 v1, v28

    check-cast v1, Landroidx/compose/ui/Modifier;

    move/from16 v39, v3

    .end local v3    # "$i$a$-let-StoreScreenKt$AppIcon$1$1\\14\\271\\13":I
    .local v39, "$i$a$-let-StoreScreenKt$AppIcon$1$1\\14\\271\\13":I
    const/4 v3, 0x0

    move-object/from16 v35, v4

    move-object/from16 p2, v5

    const/4 v4, 0x0

    const/4 v5, 0x1

    .end local v4    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local v5    # "modifier\\6":Landroidx/compose/ui/Modifier;
    .restart local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local p2, "modifier\\6":Landroidx/compose/ui/Modifier;
    invoke-static {v1, v3, v5, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    const/16 v36, 0x1b0

    const/16 v37, 0xf8

    const/16 v28, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    invoke-static/range {v27 .. v37}, Landroidx/compose/foundation/ImageKt;->Image-5h-nEew(Landroidx/compose/ui/graphics/ImageBitmap;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;Landroidx/compose/ui/layout/ContentScale;FLandroidx/compose/ui/graphics/ColorFilter;ILandroidx/compose/runtime/Composer;II)V

    move-object/from16 v4, v35

    .end local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local v38    # "it\\14":Landroid/graphics/Bitmap;
    .end local v39    # "$i$a$-let-StoreScreenKt$AppIcon$1$1\\14\\271\\13":I
    .restart local v4    # "$composer\\13":Landroidx/compose/runtime/Composer;
    :goto_f
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v1, 0x446a594a

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "273@14689L11,272@14474L244"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 273
    invoke-static/range {v19 .. v19}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon$lambda$2(Landroidx/compose/runtime/State;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-nez v1, :cond_19

    if-nez p0, :cond_19

    move-object/from16 v1, v26

    check-cast v1, Ljava/lang/CharSequence;

    if-eqz v1, :cond_17

    invoke-static {v1}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_16

    goto :goto_10

    :cond_16
    const/4 v1, 0x0

    goto :goto_11

    :cond_17
    :goto_10
    const/4 v1, 0x1

    :goto_11
    if-nez v1, :cond_19

    move-object/from16 v1, v26

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    invoke-static {v1, v5}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v3}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "toUpperCase(...)"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v5

    invoke-interface {v0, v3, v5}, Landroidx/compose/foundation/layout/BoxScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;)Landroidx/compose/ui/Modifier;

    move-result-object v28

    .line 274
    const/16 v3, 0x40

    if-lt v2, v3, :cond_18

    const v3, 0x446a7143

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "273@14600L10"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getHeadlineSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v3

    goto :goto_12

    :cond_18
    const v3, 0x446a76c0

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "273@14644L10"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v3

    :goto_12
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v47, v3

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v29

    .line 273
    nop

    .line 274
    nop

    .line 273
    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const v51, 0xfff8

    move-object/from16 v27, v1

    move-object/from16 v48, v4

    .end local v4    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\13":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v51}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v35, v48

    .end local v48    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .restart local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    goto :goto_13

    .end local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\13":Landroidx/compose/runtime/Composer;
    :cond_19
    move-object/from16 v35, v4

    .end local v4    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .restart local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    :goto_13
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 271
    invoke-static/range {v35 .. v35}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 275
    nop

    .line 631
    .end local v0    # "$this$AppIcon_u24lambda_u244\\13":Landroidx/compose/foundation/layout/BoxScope;
    .end local v22    # "$i$a$-Box-StoreScreenKt$AppIcon$1\\13\\631\\0":I
    .end local v35    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local v52    # "$changed\\13":I
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 630
    .end local v20    # "$changed\\12":I
    .end local v24    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-Layout-BoxKt$Box$1\\12\\630\\6":I
    nop

    .line 632
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 609
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 633
    nop

    .line 603
    .end local v18    # "$i$f$ReusableComposeNode\\8\\607":I
    .end local v21    # "$changed\\8":I
    .end local v23    # "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 634
    nop

    .line 596
    .end local v7    # "materialized\\7":Landroidx/compose/ui/Modifier;
    .end local v8    # "compositeKeyHash\\7":I
    .end local v13    # "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16    # "$changed\\7":I
    .end local v17    # "$i$f$Layout\\7\\602":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 635
    nop

    .end local v9    # "$changed\\6":I
    .end local v11    # "$i$f$Box\\6\\270":I
    .end local v12    # "contentAlignment\\6":Landroidx/compose/ui/Alignment;
    .end local v14    # "propagateMinConstraints\\6":Z
    .end local v15    # "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local p2    # "modifier\\6":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v19    # "bitmap$delegate":Landroidx/compose/runtime/State;
    :cond_1a
    move-object/from16 v3, v26

    .end local v26    # "fallback":Ljava/lang/String;
    .local v3, "fallback":Ljava/lang/String;
    :goto_14
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_1b

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda30;

    move-object/from16 v1, p0

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda30;-><init>(Ljava/lang/String;ILjava/lang/String;II)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 276
    :cond_1b
    return-void
.end method

.method private static final AppIcon$lambda$2(Landroidx/compose/runtime/State;)Landroid/graphics/Bitmap;
    .locals 4
    .param p0, "$bitmap$delegate"    # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Landroid/graphics/Bitmap;",
            ">;)",
            "Landroid/graphics/Bitmap;"
        }
    .end annotation

    .line 269
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1593
    .local v3, "$i$f$getValue\\1\\269":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3    # "$i$f$getValue\\1\\269":I
    check-cast v0, Landroid/graphics/Bitmap;

    .line 269
    return-object v0
.end method

.method private static final AppIcon$lambda$5(Ljava/lang/String;ILjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move v6, p4

    move-object v4, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final DeviceTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 51
    .param p0, "$this$DeviceTab"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 328
    move-object/from16 v0, p0

    move-object/from16 v6, p1

    move/from16 v7, p3

    const v1, -0xf8f586e

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(DeviceTab)328@17851L367:StoreScreen.kt#o13vsk"

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v3, v7, 0x6

    const/4 v4, 0x2

    if-nez v3, :cond_1

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    move v3, v4

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v7, 0x30

    if-nez v3, :cond_3

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    and-int/lit8 v3, v2, 0x13

    const/16 v5, 0x12

    if-ne v3, v5, :cond_5

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    .line 338
    :cond_4
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v33, v2

    move-object/from16 v29, v15

    goto/16 :goto_10

    .line 328
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_6

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.DeviceTab (StoreScreen.kt:327)"

    invoke-static {v1, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 329
    :cond_6
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x10

    .local v3, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 648
    .local v5, "$i$f$getDp\\1\\329":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 329
    .end local v3    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\329":I
    const/4 v5, 0x0

    const/4 v8, 0x0

    invoke-static {v1, v3, v5, v4, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .local v3, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v4, 0x186

    .local v4, "$changed\\2":I
    const/4 v9, 0x0

    .line 649
    .local v9, "$i$f$Row\\2\\329":I
    const v10, 0x2952b718

    const-string v11, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v15, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 650
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v10

    .line 654
    .local v10, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v10, v3, v15, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 655
    nop

    .local v12, "$changed\\3":I
    const/4 v13, 0x0

    .line 656
    .local v13, "$i$f$Layout\\3\\655":I
    const v14, -0x4ee9b9da

    const-string v5, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v15, v14, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 657
    const/4 v5, 0x0

    invoke-static {v15, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v14

    .line 658
    .local v14, "compositeKeyHash\\3":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 659
    .local v5, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v15, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 661
    .local v8, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 v18, v1

    .end local v1    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\2":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v12, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 660
    move-object/from16 v19, v17

    .local v1, "$changed\\4":I
    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 662
    .local v17, "$i$f$ReusableComposeNode\\4\\660":I
    move/from16 v20, v1

    .end local v1    # "$changed\\4":I
    .local v20, "$changed\\4":I
    const v1, -0x2942ffcf

    move/from16 v33, v2

    .end local v2    # "$dirty":I
    .local v33, "$dirty":I
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v15, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 663
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 664
    :cond_7
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 665
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_8

    .line 666
    move-object/from16 v1, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 668
    .end local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v1, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 670
    :goto_3
    invoke-static {v15}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 671
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\670\\3":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v1

    .end local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 672
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 674
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 675
    .local v21, "$i$f$set-impl\\6\\674":I
    move-object/from16 v23, v2

    .local v23, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 676
    .local v24, "$i$a$-with-Updater$set$1\\7\\675\\6":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_a

    move-object/from16 v25, v3

    .end local v3    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v25, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v26, v4

    .end local v4    # "$changed\\2":I
    .local v26, "$changed\\2":I
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v4, v23

    goto :goto_5

    .end local v25    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v26    # "$changed\\2":I
    .restart local v3    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v4    # "$changed\\2":I
    :cond_a
    move-object/from16 v25, v3

    move/from16 v26, v4

    .line 677
    .end local v3    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v4    # "$changed\\2":I
    .restart local v25    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v26    # "$changed\\2":I
    :goto_4
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 678
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 680
    :goto_5
    nop

    .line 675
    .end local v4    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\7\\675\\6":I
    nop

    .line 680
    nop

    .line 681
    .end local v1    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\6\\674":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v8, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 682
    nop

    .line 670
    .end local v2    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\670\\3":I
    nop

    .line 683
    shr-int/lit8 v1, v20, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object v2, v15

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 684
    .local v3, "$i$a$-Layout-RowKt$Row$1\\8\\683\\2":I
    const v4, -0x184f2606

    move/from16 v19, v1

    .end local v1    # "$changed\\8":I
    .local v19, "$changed\\8":I
    const-string v1, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v26, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$DeviceTab_u24lambda_u2412\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v46, v2

    .local v46, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 330
    .local v21, "$i$a$-Row-StoreScreenKt$DeviceTab$1\\9\\684\\0":I
    move-object/from16 v23, v1

    .end local v1    # "$this$DeviceTab_u24lambda_u2412\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v23, "$this$DeviceTab_u24lambda_u2412\\9":Landroidx/compose/foundation/layout/RowScope;
    const v1, 0x56b61cf0

    move-object/from16 v24, v2

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v24, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v2, "C329@17986L52,329@17951L261:StoreScreen.kt#o13vsk"

    move/from16 v27, v3

    move-object/from16 v3, v46

    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v27, "$i$a$-Layout-RowKt$Row$1\\8\\683\\2":I
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getShowIncompatible()Z

    move-result v34

    const v1, 0x4c5de2

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\10":Z
    move-object/from16 v28, v3

    .local v28, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 685
    .local v29, "$i$f$cache\\10\\330":I
    move-object/from16 v50, v1

    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\10":Ljava/lang/Object;
    const/16 v30, 0x0

    .line 686
    .local v30, "$i$a$-let-ComposerKt$cache$1\\11\\685\\10":I
    if-nez v2, :cond_c

    sget-object v31, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v32, v2

    .end local v2    # "invalid\\10":Z
    .local v32, "invalid\\10":Z
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_b

    goto :goto_6

    .line 690
    :cond_b
    move-object/from16 v31, v1

    move-object/from16 v2, v28

    goto :goto_7

    .line 686
    .end local v32    # "invalid\\10":Z
    .restart local v2    # "invalid\\10":Z
    :cond_c
    move/from16 v32, v2

    .line 687
    .end local v2    # "invalid\\10":Z
    .restart local v32    # "invalid\\10":Z
    :goto_6
    const/4 v2, 0x0

    .line 330
    .local v2, "$i$a$-cache-StoreScreenKt$DeviceTab$1$1\\12\\687\\9":I
    move-object/from16 v31, v1

    .end local v1    # "it\\10":Ljava/lang/Object;
    .local v31, "it\\10":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda23;

    invoke-direct {v1, v6}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda23;-><init>(Lorg/lighttouch/android/StoreModel;)V

    .line 687
    .end local v2    # "$i$a$-cache-StoreScreenKt$DeviceTab$1$1\\12\\687\\9":I
    nop

    .line 688
    .local v1, "value\\11":Ljava/lang/Object;
    move-object/from16 v2, v28

    .end local v28    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .local v2, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 689
    nop

    .line 686
    .end local v1    # "value\\11":Ljava/lang/Object;
    :goto_7
    nop

    .line 685
    .end local v30    # "$i$a$-let-ComposerKt$cache$1\\11\\685\\10":I
    .end local v31    # "it\\10":Ljava/lang/Object;
    nop

    .line 330
    .end local v2    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$f$cache\\10\\330":I
    .end local v32    # "invalid\\10":Z
    move-object/from16 v35, v1

    check-cast v35, Lkotlin/jvm/functions/Function0;

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$-1167375653$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v36

    .line 331
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getShowIncompatible()Z

    move-result v1

    if-eqz v1, :cond_d

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$1005866621$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    move-object/from16 v39, v1

    goto :goto_8

    :cond_d
    const/16 v39, 0x0

    .line 330
    :goto_8
    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v47, 0x180

    const/16 v48, 0x0

    const/16 v49, 0xfd8

    move-object/from16 v46, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v49}, Landroidx/compose/material3/ChipKt;->FilterChip(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/SelectableChipColors;Landroidx/compose/material3/SelectableChipElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;III)V

    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 332
    nop

    .line 684
    .end local v4    # "$changed\\9":I
    .end local v21    # "$i$a$-Row-StoreScreenKt$DeviceTab$1\\9\\684\\0":I
    .end local v23    # "$this$DeviceTab_u24lambda_u2412\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 683
    .end local v19    # "$changed\\8":I
    .end local v24    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-Layout-RowKt$Row$1\\8\\683\\2":I
    nop

    .line 691
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 662
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 692
    nop

    .line 656
    .end local v17    # "$i$f$ReusableComposeNode\\4\\660":I
    .end local v20    # "$changed\\4":I
    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 693
    nop

    .line 649
    .end local v5    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v12    # "$changed\\3":I
    .end local v13    # "$i$f$Layout\\3\\655":I
    .end local v14    # "compositeKeyHash\\3":I
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 694
    nop

    .end local v9    # "$i$f$Row\\2\\329":I
    .end local v10    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v11    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v25    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v26    # "$changed\\2":I
    const v1, -0x691abd1c

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "332@18244L93"

    invoke-static {v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 333
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getSearching()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_e

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v3, v2, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v3, 0x10

    .local v3, "$this$dp\\13":I
    const/4 v4, 0x0

    .line 695
    .local v4, "$i$f$getDp\\13\\333":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 333
    .end local v3    # "$this$dp\\13":I
    .end local v4    # "$i$f$getDp\\13\\333":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\14":I
    const/4 v5, 0x0

    .line 695
    .local v5, "$i$f$getDp\\14\\333":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 333
    .end local v4    # "$this$dp\\14":I
    .end local v5    # "$i$f$getDp\\14\\333":I
    invoke-static {v1, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v16, 0x6

    const/16 v17, 0x1e

    const-wide/16 v9, 0x0

    const-wide/16 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v8 .. v17}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    :cond_e
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v1, -0x691aade7

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "334@18479L10,334@18523L11,333@18374L167"

    invoke-static {v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 334
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getMessage()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-lez v1, :cond_f

    move v1, v2

    goto :goto_9

    :cond_f
    const/4 v1, 0x0

    :goto_9
    if-eqz v1, :cond_10

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getMessage()Ljava/lang/String;

    move-result-object v8

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x10

    .local v3, "$this$dp\\15":I
    const/4 v4, 0x0

    .line 696
    .local v4, "$i$f$getDp\\15\\334":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 334
    .end local v3    # "$this$dp\\15":I
    .end local v4    # "$i$f$getDp\\15\\334":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\16":I
    const/4 v5, 0x0

    .line 696
    .local v5, "$i$f$getDp\\16\\334":I
    int-to-float v9, v4

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 334
    .end local v4    # "$this$dp\\16":I
    .end local v5    # "$i$f$getDp\\16\\334":I
    invoke-static {v1, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 335
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v15, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v28

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v15, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v10

    .line 334
    nop

    .line 335
    nop

    .line 334
    const-wide/16 v12, 0x0

    const/4 v14, 0x0

    move-object/from16 v29, v15

    .end local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .local v29, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    const/16 v16, 0x0

    const-wide/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const-wide/16 v21, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v30, 0x30

    const/16 v31, 0x0

    const v32, 0xfff8

    invoke-static/range {v8 .. v32}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v15, v29

    .end local v29    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v15    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_10
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 336
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getShowIncompatible()Z

    move-result v1

    if-eqz v1, :cond_11

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getResults()Ljava/util/List;

    move-result-object v1

    goto :goto_c

    :cond_11
    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getResults()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter\\17":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 697
    .local v3, "$i$f$filter\\17\\336":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\18":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$filterTo\\18":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 698
    .local v8, "$i$f$filterTo\\18\\697":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_12
    :goto_a
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_14

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element\\18":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/json/JSONObject;

    .local v11, "it\\19":Lorg/json/JSONObject;
    const/4 v12, 0x0

    .line 336
    .local v12, "$i$a$-filter-StoreScreenKt$DeviceTab$rows$1\\19\\698\\0":I
    sget-object v13, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v13, v11}, Lorg/lighttouch/android/LegacyStore;->incompatibility(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_13

    move v11, v2

    goto :goto_b

    :cond_13
    const/4 v11, 0x0

    .line 698
    .end local v11    # "it\\19":Lorg/json/JSONObject;
    .end local v12    # "$i$a$-filter-StoreScreenKt$DeviceTab$rows$1\\19\\698\\0":I
    :goto_b
    if-eqz v11, :cond_12

    invoke-interface {v4, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_a

    .line 699
    .end local v10    # "element\\18":Ljava/lang/Object;
    :cond_14
    nop

    .end local v4    # "destination\\18":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\18":Ljava/lang/Iterable;
    .end local v8    # "$i$f$filterTo\\18\\697":I
    check-cast v4, Ljava/util/List;

    .line 697
    move-object v1, v4

    .line 336
    .end local v1    # "$this$filter\\17":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter\\17\\336":I
    :goto_c
    move-object v8, v1

    .line 337
    .local v8, "rows":Ljava/util/List;
    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_15

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getSearching()Z

    move-result v1

    if-nez v1, :cond_15

    const v1, -0x691a8026

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "336@18713L40"

    invoke-static {v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getResults()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    xor-int/2addr v1, v2

    and-int/lit8 v2, v33, 0xe

    invoke-static {v0, v1, v15, v2}, Lorg/lighttouch/android/StoreScreenKt;->EmptyResults(Landroidx/compose/foundation/layout/ColumnScope;ZLandroidx/compose/runtime/Composer;I)V

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v1, v8

    move-object/from16 v29, v15

    goto/16 :goto_f

    .line 338
    :cond_15
    const v1, -0x691a791b

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "337@18915L91,337@18763L243"

    invoke-static {v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    move-object/from16 v9, v50

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "store_results"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreModel;->getResultsList()Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v2

    const/16 v3, 0x8

    .local v3, "$this$dp\\20":I
    const/4 v4, 0x0

    .line 700
    .local v4, "$i$f$getDp\\20\\338":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 338
    .end local v3    # "$this$dp\\20":I
    .end local v4    # "$i$f$getDp\\20\\338":I
    const/4 v4, 0x4

    .local v4, "$this$dp\\21":I
    const/4 v5, 0x0

    .line 700
    .local v5, "$i$f$getDp\\21\\338":I
    int-to-float v10, v4

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 338
    .end local v4    # "$this$dp\\21":I
    .end local v5    # "$i$f$getDp\\21\\338":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v10

    const v3, -0x615d173a

    invoke-interface {v15, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v15, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v15, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    .local v3, "invalid\\22":Z
    move-object v4, v15

    .local v4, "$this$cache\\22":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 701
    .local v5, "$i$f$cache\\22\\338":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\22":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 702
    .local v11, "$i$a$-let-ComposerKt$cache$1\\23\\701\\22":I
    if-nez v3, :cond_17

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v9, v12, :cond_16

    goto :goto_d

    .line 706
    :cond_16
    move-object v13, v9

    goto :goto_e

    .line 703
    :cond_17
    :goto_d
    const/4 v12, 0x0

    .line 338
    .local v12, "$i$a$-cache-StoreScreenKt$DeviceTab$2\\24\\703\\0":I
    new-instance v13, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda24;

    invoke-direct {v13, v8, v6}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda24;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    .line 703
    .end local v12    # "$i$a$-cache-StoreScreenKt$DeviceTab$2\\24\\703\\0":I
    nop

    .line 704
    .local v13, "value\\23":Ljava/lang/Object;
    invoke-interface {v4, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 705
    nop

    .line 702
    .end local v13    # "value\\23":Ljava/lang/Object;
    :goto_e
    nop

    .line 701
    .end local v9    # "it\\22":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\23\\701\\22":I
    nop

    .line 338
    .end local v3    # "invalid\\22":Z
    .end local v4    # "$this$cache\\22":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\22\\338":I
    move-object/from16 v16, v13

    check-cast v16, Lkotlin/jvm/functions/Function1;

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v18, 0x180

    const/16 v19, 0xf8

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    move-object/from16 v29, v15

    .end local v15    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$composer":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    move-object v9, v8

    move-object v8, v1

    move-object v1, v9

    move-object v9, v2

    move-object/from16 v17, v29

    .end local v8    # "rows":Ljava/util/List;
    .end local v29    # "$composer":Landroidx/compose/runtime/Composer;
    .local v1, "rows":Ljava/util/List;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v8 .. v19}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_18

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "rows":Ljava/util/List;
    :cond_18
    :goto_10
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_19

    new-instance v2, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda25;

    invoke-direct {v2, v0, v6, v7}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda25;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 341
    :cond_19
    return-void
.end method

.method private static final DeviceTab$lambda$12$lambda$11$lambda$10(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;

    .line 330
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getShowIncompatible()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setShowIncompatible(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeviceTab$lambda$17$lambda$16(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 10
    .param p0, "$rows"    # Ljava/util/List;
    .param p1, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 339
    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda0;

    invoke-direct {v0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda0;-><init>()V

    .local v0, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object v1, p2

    .line 1594
    .local v1, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 1597
    sget-object v2, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$1;

    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 1594
    .local v2, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v3, 0x0

    .line 1599
    .local v3, "$i$f$items\\1\\339":I
    nop

    .line 1600
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v4

    .line 1601
    nop

    .line 1599
    new-instance v5, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$2;

    invoke-direct {v5, v0, p0}, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v5, Lkotlin/jvm/functions/Function1;

    new-instance v6, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$3;

    invoke-direct {v6, v2, p0}, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 1603
    new-instance v7, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$4;

    invoke-direct {v7, p0, p1}, Lorg/lighttouch/android/StoreScreenKt$DeviceTab$lambda$17$lambda$16$$inlined$items$default$4;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    const v8, -0x25b7f321

    const/4 v9, 0x1

    invoke-static {v8, v9, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function4;

    .line 1599
    invoke-interface {v1, v4, v5, v6, v7}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 1605
    nop

    .line 340
    .end local v0    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v1    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v2    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v3    # "$i$f$items\\1\\339":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeviceTab$lambda$17$lambda$16$lambda$14(Lorg/json/JSONObject;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/json/JSONObject;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 339
    const-string v0, "ipa_id"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0
.end method

.method private static final DeviceTab$lambda$18(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreScreenKt;->DeviceTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final EmptyResults(Landroidx/compose/foundation/layout/ColumnScope;ZLandroidx/compose/runtime/Composer;I)V
    .locals 51
    .param p0, "$this$EmptyResults"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "filtered"    # Z
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 389
    move-object/from16 v0, p0

    move/from16 v6, p1

    move/from16 v7, p3

    const v1, 0x3a78190a

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(EmptyResults)389@22309L756:StoreScreen.kt#o13vsk"

    invoke-static {v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p3

    .local v2, "$dirty":I
    and-int/lit8 v3, v7, 0x6

    if-nez v3, :cond_1

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    or-int/2addr v2, v3

    :cond_1
    and-int/lit8 v3, v7, 0x30

    if-nez v3, :cond_3

    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v3

    if-eqz v3, :cond_2

    const/16 v3, 0x20

    goto :goto_1

    :cond_2
    const/16 v3, 0x10

    :goto_1
    or-int/2addr v2, v3

    :cond_3
    move v9, v2

    .end local v2    # "$dirty":I
    .local v9, "$dirty":I
    and-int/lit8 v2, v9, 0x13

    const/16 v3, 0x12

    if-ne v2, v3, :cond_5

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_4

    goto :goto_2

    .line 924
    :cond_4
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_8

    .line 389
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_6

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.EmptyResults (StoreScreen.kt:388)"

    invoke-static {v1, v9, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 390
    :cond_6
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v4, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x20

    .local v2, "$this$dp\\1":I
    const/4 v3, 0x0

    .line 886
    .local v3, "$i$f$getDp\\1\\390":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 390
    .end local v2    # "$this$dp\\1":I
    .end local v3    # "$i$f$getDp\\1\\390":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v2

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getCenter()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    const/16 v4, 0x1b0

    .local v4, "$changed\\2":I
    const/4 v5, 0x0

    .line 887
    .local v5, "$i$f$Column\\2\\390":I
    const v10, -0x1cd0f17e

    const-string v11, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v8, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 888
    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    shr-int/lit8 v10, v4, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v3, v2, v8, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v2

    .local v2, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v3, v4, 0x3

    and-int/lit8 v3, v3, 0x70

    .line 889
    nop

    .local v3, "$changed\\3":I
    const/4 v10, 0x0

    .line 890
    .local v10, "$i$f$Layout\\3\\889":I
    const v11, -0x4ee9b9da

    const-string v12, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v8, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 891
    const/4 v11, 0x0

    invoke-static {v8, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v11

    .line 892
    .local v11, "compositeKeyHash\\3":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 893
    .local v12, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 895
    .local v1, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v3, 0x6

    and-int/lit16 v14, v14, 0x380

    const/4 v15, 0x6

    or-int/2addr v14, v15

    .line 894
    nop

    .local v13, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v14, "$changed\\4":I
    const/16 v16, 0x0

    .line 896
    .local v16, "$i$f$ReusableComposeNode\\4\\894":I
    move/from16 p2, v15

    const v15, -0x2942ffcf

    move/from16 v17, v3

    .end local v3    # "$changed\\3":I
    .local v17, "$changed\\3":I
    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v8, v15, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 897
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 898
    :cond_7
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 899
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_8

    .line 900
    invoke-interface {v8, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 902
    :cond_8
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 904
    :goto_3
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 905
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\904\\3":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v19, v4

    .end local v4    # "$changed\\2":I
    .local v19, "$changed\\2":I
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v2, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 906
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v12, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 908
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 909
    .local v18, "$i$f$set-impl\\6\\908":I
    move-object/from16 v20, v3

    .local v20, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 910
    .local v21, "$i$a$-with-Updater$set$1\\7\\909\\6":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_a

    move-object/from16 v22, v2

    .end local v2    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v22, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v23, v5

    .end local v5    # "$i$f$Column\\2\\390":I
    .local v23, "$i$f$Column\\2\\390":I
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v5, v20

    goto :goto_5

    .end local v22    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "$i$f$Column\\2\\390":I
    .restart local v2    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v5    # "$i$f$Column\\2\\390":I
    :cond_a
    move-object/from16 v22, v2

    move/from16 v23, v5

    .line 911
    .end local v2    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v5    # "$i$f$Column\\2\\390":I
    .restart local v22    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v23    # "$i$f$Column\\2\\390":I
    :goto_4
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v5, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 912
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v3, v2, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 914
    :goto_5
    nop

    .line 909
    .end local v5    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\7\\909\\6":I
    nop

    .line 914
    nop

    .line 915
    .end local v4    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\6\\908":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 916
    nop

    .line 904
    .end local v3    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\904\\3":I
    nop

    .line 917
    shr-int/lit8 v2, v14, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\8":I
    move-object v3, v8

    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 918
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\8\\917\\2":I
    const v5, -0x16ef5699

    const-string v15, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v5, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v15, v19, 0x6

    and-int/lit8 v15, v15, 0x70

    or-int/lit8 v15, v15, 0x6

    .local v15, "$changed\\9":I
    check-cast v5, Landroidx/compose/foundation/layout/ColumnScope;

    .local v5, "$this$EmptyResults_u24lambda_u2442\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v29, v3

    .local v29, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 391
    .local v18, "$i$a$-Column-StoreScreenKt$EmptyResults$1\\9\\918\\0":I
    move-object/from16 v20, v1

    .end local v1    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v20, "materialized\\3":Landroidx/compose/ui/Modifier;
    const v1, 0x5f9b44a3

    move/from16 v21, v2

    .end local v2    # "$changed\\8":I
    .local v21, "$changed\\8":I
    const-string v2, "C390@22538L11,390@22471L96,391@22576L30,392@22719L10,392@22615L127,394@22956L10,394@23000L11,393@22751L308:StoreScreen.kt#o13vsk"

    move-object/from16 v49, v3

    .end local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getBag()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v24

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x28

    .local v2, "$this$dp\\10":I
    const/16 v25, 0x0

    .line 919
    .local v25, "$i$f$getDp\\10\\391":I
    move/from16 v50, v4

    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\8\\917\\2":I
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\8\\917\\2":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 391
    .end local v2    # "$this$dp\\10":I
    .end local v25    # "$i$f$getDp\\10\\391":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v26

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v27

    const/16 v30, 0x1b0

    const/16 v31, 0x0

    const/16 v25, 0x0

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v31}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 392
    .end local v29    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0xc

    .local v2, "$this$dp\\11":I
    const/4 v4, 0x0

    .line 920
    .local v4, "$i$f$getDp\\11\\392":I
    move/from16 v24, v4

    .end local v4    # "$i$f$getDp\\11\\392":I
    .local v24, "$i$f$getDp\\11\\392":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 392
    .end local v2    # "$this$dp\\11":I
    .end local v24    # "$i$f$getDp\\11\\392":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    move/from16 v2, p2

    invoke-static {v1, v3, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 393
    if-eqz v6, :cond_b

    const-string v1, "\u8fd9\u91cc\u6ca1\u6709\u80fd\u5728\u8be5\u8bbe\u5907\u8fd0\u884c\u7684\u5e94\u7528"

    goto :goto_6

    :cond_b
    const-string v1, "\u67e5\u627e\u5e94\u7528\u4e0e\u6e38\u620f"

    :goto_6
    move-object/from16 v24, v1

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v44

    const/16 v47, 0x0

    const v48, 0xfffe

    const/16 v25, 0x0

    const-wide/16 v26, 0x0

    const-wide/16 v28, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const-wide/16 v37, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v46, 0x0

    move-object/from16 v45, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v48}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 394
    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    if-eqz v6, :cond_c

    const-string v1, "\u5305\u542b\u65e0\u6cd5\u8fd0\u884c\u7684\u5e94\u7528\u4ee5\u67e5\u770b\u5168\u90e8\u7ed3\u679c\u3002"

    goto :goto_7

    :cond_c
    const-string v1, "\u641c\u7d22\u7ecf\u5178 iOS \u5e94\u7528\u5b58\u6863\uff0c\u4f1a\u81ea\u52a8\u6311\u9009\u9002\u5408\u6b64\u8bbe\u5907\u7684\u7248\u672c\u3002"

    :goto_7
    move-object/from16 v24, v1

    .line 395
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v44

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v26

    sget-object v1, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v1

    .line 394
    nop

    .line 395
    invoke-static {v1}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v36

    .line 394
    const/16 v25, 0x0

    const-wide/16 v28, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const-wide/16 v37, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const v48, 0xfdfa

    move-object/from16 v45, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v48}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 391
    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 396
    nop

    .line 918
    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v5    # "$this$EmptyResults_u24lambda_u2442\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v15    # "$changed\\9":I
    .end local v18    # "$i$a$-Column-StoreScreenKt$EmptyResults$1\\9\\918\\0":I
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 917
    .end local v21    # "$changed\\8":I
    .end local v49    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-ColumnKt$Column$1\\8\\917\\2":I
    nop

    .line 921
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 896
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 922
    nop

    .line 890
    .end local v13    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v14    # "$changed\\4":I
    .end local v16    # "$i$f$ReusableComposeNode\\4\\894":I
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 923
    nop

    .line 887
    .end local v10    # "$i$f$Layout\\3\\889":I
    .end local v11    # "compositeKeyHash\\3":I
    .end local v12    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "$changed\\3":I
    .end local v20    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 924
    nop

    .end local v19    # "$changed\\2":I
    .end local v22    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "$i$f$Column\\2\\390":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_d
    :goto_8
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_e

    new-instance v2, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda36;

    invoke-direct {v2, v0, v6, v7}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda36;-><init>(Landroidx/compose/foundation/layout/ColumnScope;ZI)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 397
    :cond_e
    return-void
.end method

.method private static final EmptyResults$lambda$43(Landroidx/compose/foundation/layout/ColumnScope;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreScreenKt;->EmptyResults(Landroidx/compose/foundation/layout/ColumnScope;ZLandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueButton(Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 46
    .param p0, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 533
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x4cfcd122

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(QueueButton)535@32988L34,538@33136L542:StoreScreen.kt#o13vsk"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_1

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    move v5, v6

    :goto_0
    or-int/2addr v4, v5

    :cond_1
    and-int/lit8 v5, v4, 0x3

    if-ne v5, v6, :cond_3

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_2

    goto :goto_1

    .line 1449
    :cond_2
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v26, v3

    move/from16 v18, v4

    goto/16 :goto_f

    .line 533
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_4

    const/4 v5, -0x1

    const-string v7, "org.lighttouch.android.QueueButton (StoreScreen.kt:532)"

    invoke-static {v2, v4, v5, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 534
    :cond_4
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreModel;->getQueue()Ljava/util/List;

    move-result-object v2

    .line 535
    .local v2, "items":Ljava/util/List;
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_5
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v5

    if-eqz v5, :cond_6

    new-instance v6, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda22;

    invoke-direct {v6, v0, v1}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda22;-><init>(Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v5, v6}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_6
    return-void

    :cond_7
    const v5, 0x6e3c21fe

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 536
    const/4 v7, 0x0

    move v8, v7

    .local v8, "invalid\\1":Z
    move-object v9, v3

    .local v9, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 1379
    .local v10, "$i$f$cache\\1\\536":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 1380
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\1379\\1":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_8

    .line 1381
    const/4 v13, 0x0

    .line 536
    .local v13, "$i$a$-cache-StoreScreenKt$QueueButton$open$2\\3\\1381\\0":I
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    const/4 v15, 0x0

    invoke-static {v14, v15, v6, v15}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v6

    .line 1381
    .end local v13    # "$i$a$-cache-StoreScreenKt$QueueButton$open$2\\3\\1381\\0":I
    nop

    .line 1382
    .local v6, "value\\2":Ljava/lang/Object;
    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1383
    nop

    .end local v6    # "value\\2":Ljava/lang/Object;
    goto :goto_2

    .line 1384
    :cond_8
    move-object v6, v11

    .line 1380
    :goto_2
    nop

    .line 1379
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\1379\\1":I
    nop

    .line 536
    .end local v8    # "invalid\\1":Z
    .end local v9    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\1\\536":I
    check-cast v6, Landroidx/compose/runtime/MutableState;

    .local v6, "open$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 537
    move-object v8, v2

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$any\\4":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 1385
    .local v9, "$i$f$any\\4\\537":I
    instance-of v10, v8, Ljava/util/Collection;

    if-eqz v10, :cond_9

    move-object v10, v8

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_9

    move v8, v7

    goto :goto_3

    .line 1386
    :cond_9
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_a
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\4":Ljava/lang/Object;
    move-object v13, v12

    check-cast v13, Lorg/lighttouch/android/QueueItem;

    .local v13, "it\\5":Lorg/lighttouch/android/QueueItem;
    const/4 v14, 0x0

    .line 537
    .local v14, "$i$a$-any-StoreScreenKt$QueueButton$busy$1\\5\\1386\\0":I
    invoke-virtual {v13}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v13

    .line 1386
    .end local v13    # "it\\5":Lorg/lighttouch/android/QueueItem;
    .end local v14    # "$i$a$-any-StoreScreenKt$QueueButton$busy$1\\5\\1386\\0":I
    if-eqz v13, :cond_a

    const/4 v8, 0x1

    goto :goto_3

    .line 1387
    .end local v12    # "element\\4":Ljava/lang/Object;
    :cond_b
    move v8, v7

    .line 537
    .end local v8    # "$this$any\\4":Ljava/lang/Iterable;
    .end local v9    # "$i$f$any\\4\\537":I
    :goto_3
    nop

    .line 538
    .local v8, "busy":Z
    if-nez v8, :cond_10

    move-object v9, v2

    check-cast v9, Ljava/lang/Iterable;

    .local v9, "$this$any\\6":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 1388
    .local v10, "$i$f$any\\6\\538":I
    instance-of v12, v9, Ljava/util/Collection;

    if-eqz v12, :cond_c

    move-object v12, v9

    check-cast v12, Ljava/util/Collection;

    invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_c

    goto :goto_6

    .line 1389
    :cond_c
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_4
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_f

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\6":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Lorg/lighttouch/android/QueueItem;

    .local v14, "it\\7":Lorg/lighttouch/android/QueueItem;
    const/4 v15, 0x0

    .line 538
    .local v15, "$i$a$-any-StoreScreenKt$QueueButton$failed$1\\7\\1389\\0":I
    invoke-virtual {v14}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v11

    sget-object v7, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    if-ne v11, v7, :cond_d

    const/4 v7, 0x1

    goto :goto_5

    :cond_d
    const/4 v7, 0x0

    .line 1389
    .end local v14    # "it\\7":Lorg/lighttouch/android/QueueItem;
    .end local v15    # "$i$a$-any-StoreScreenKt$QueueButton$failed$1\\7\\1389\\0":I
    :goto_5
    if-eqz v7, :cond_e

    const/4 v7, 0x1

    goto :goto_6

    :cond_e
    const/4 v7, 0x0

    goto :goto_4

    .line 1390
    .end local v13    # "element\\6":Ljava/lang/Object;
    :cond_f
    const/4 v7, 0x0

    .line 538
    .end local v9    # "$this$any\\6":Ljava/lang/Iterable;
    .end local v10    # "$i$f$any\\6\\538":I
    :goto_6
    if-eqz v7, :cond_10

    const/4 v7, 0x1

    goto :goto_7

    :cond_10
    const/4 v7, 0x0

    .line 539
    .local v7, "failed":Z
    :goto_7
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/16 v10, 0x30

    .local v10, "$this$dp\\8":I
    const/4 v11, 0x0

    .line 1391
    .local v11, "$i$f$getDp\\8\\539":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 539
    .end local v10    # "$this$dp\\8":I
    .end local v11    # "$i$f$getDp\\8\\539":I
    invoke-static {v9, v10}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .local v9, "modifier\\9":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v10

    .local v10, "contentAlignment\\9":Landroidx/compose/ui/Alignment;
    const/16 v11, 0x36

    .local v11, "$changed\\9":I
    const/4 v12, 0x0

    .line 1392
    .local v12, "$i$f$Box\\9\\539":I
    const v13, 0x2bb5b5d7

    const-string v14, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v3, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1393
    const/4 v13, 0x0

    .line 1396
    .local v13, "propagateMinConstraints\\9":Z
    invoke-static {v10, v13}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v11, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 1397
    nop

    .local v15, "$changed\\10":I
    const/16 v17, 0x0

    .line 1398
    .local v17, "$i$f$Layout\\10\\1397":I
    move/from16 v18, v4

    .end local v4    # "$dirty":I
    .local v18, "$dirty":I
    const v4, -0x4ee9b9da

    move-object/from16 v19, v10

    .end local v10    # "contentAlignment\\9":Landroidx/compose/ui/Alignment;
    .local v19, "contentAlignment\\9":Landroidx/compose/ui/Alignment;
    const-string v10, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v3, v4, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1399
    const/4 v4, 0x0

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v4

    .line 1400
    .local v4, "compositeKeyHash\\10":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 1401
    .local v10, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v16, v4

    .end local v4    # "compositeKeyHash\\10":I
    .local v16, "compositeKeyHash\\10":I
    invoke-static {v3, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 1403
    .local v4, "materialized\\10":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move-object/from16 v21, v9

    .end local v9    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .local v21, "modifier\\9":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v9, v15, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/lit8 v9, v9, 0x6

    .line 1402
    move-object/from16 v22, v20

    .local v9, "$changed\\11":I
    .local v22, "factory\\11":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 1404
    .local v20, "$i$f$ReusableComposeNode\\11\\1402":I
    move/from16 v23, v9

    .end local v9    # "$changed\\11":I
    .local v23, "$changed\\11":I
    const v9, -0x2942ffcf

    move/from16 v24, v11

    .end local v11    # "$changed\\9":I
    .local v24, "$changed\\9":I
    const-string v11, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v3, v9, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1405
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v9

    instance-of v9, v9, Landroidx/compose/runtime/Applier;

    if-nez v9, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1406
    :cond_11
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1407
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-eqz v9, :cond_12

    .line 1408
    move-object/from16 v9, v22

    .end local v22    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v9, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_8

    .line 1410
    .end local v9    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v9, v22

    .end local v22    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v9    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1412
    :goto_8
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .local v11, "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 1413
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\1412\\10":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v26, v3

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v26, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v11, v14, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1414
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v11, v10, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1416
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\13":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 1417
    .local v25, "$i$f$set-impl\\13\\1416":I
    move-object/from16 v27, v11

    .local v27, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 1418
    .local v28, "$i$a$-with-Updater$set$1\\14\\1417\\13":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v29

    if-nez v29, :cond_14

    move-object/from16 v29, v9

    .end local v9    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v29, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v30, v10

    .end local v10    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v30, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_13

    goto :goto_9

    :cond_13
    move-object/from16 v10, v27

    goto :goto_a

    .end local v29    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .end local v30    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v10    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_14
    move-object/from16 v29, v9

    move-object/from16 v30, v10

    .line 1419
    .end local v9    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .end local v10    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v29    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_9
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1420
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v11, v9, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1422
    :goto_a
    nop

    .line 1417
    .end local v10    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-with-Updater$set$1\\14\\1417\\13":I
    nop

    .line 1422
    nop

    .line 1423
    .end local v3    # "block\\13":Lkotlin/jvm/functions/Function2;
    .end local v25    # "$i$f$set-impl\\13\\1416":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v11, v4, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1424
    nop

    .line 1412
    .end local v11    # "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\1412\\10":I
    nop

    .line 1425
    shr-int/lit8 v3, v23, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\15":I
    move-object/from16 v9, v26

    .local v9, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 1426
    .local v10, "$i$a$-Layout-BoxKt$Box$1\\15\\1425\\9":I
    const v11, -0x7ff519f7    # -1.000876E-39f

    move/from16 v22, v3

    .end local v3    # "$changed\\15":I
    .local v22, "$changed\\15":I
    const-string v3, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v9, v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v11, v24, 0x6

    and-int/lit8 v11, v11, 0x70

    or-int/lit8 v11, v11, 0x6

    .local v11, "$changed\\16":I
    check-cast v3, Landroidx/compose/foundation/layout/BoxScope;

    .local v3, "$this$QueueButton_u24lambda_u24110\\16":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v37, v9

    .local v37, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 540
    .local v25, "$i$a$-Box-StoreScreenKt$QueueButton$2\\16\\1426\\0":I
    move-object/from16 v27, v3

    .end local v3    # "$this$QueueButton_u24lambda_u24110\\16":Landroidx/compose/foundation/layout/BoxScope;
    .local v27, "$this$QueueButton_u24lambda_u24110\\16":Landroidx/compose/foundation/layout/BoxScope;
    const v3, 0x3fc23e3c

    move-object/from16 v28, v4

    .end local v4    # "materialized\\10":Landroidx/compose/ui/Modifier;
    .local v28, "materialized\\10":Landroidx/compose/ui/Modifier;
    const-string v4, "C539@33230L15,539@33291L179,539@33209L261,543@33656L16,543@33633L39:StoreScreen.kt#o13vsk"

    move-object/from16 v43, v9

    .end local v37    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static {v9, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v3, 0x4c5de2

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\17":Z
    move-object/from16 v31, v9

    .local v31, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 1427
    .local v32, "$i$f$cache\\17\\540":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\17":Ljava/lang/Object;
    const/16 v33, 0x0

    .line 1428
    .local v33, "$i$a$-let-ComposerKt$cache$1\\18\\1427\\17":I
    sget-object v34, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v35, v4

    .end local v4    # "invalid\\17":Z
    .local v35, "invalid\\17":Z
    invoke-virtual/range {v34 .. v34}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_15

    .line 1429
    const/4 v4, 0x0

    .line 540
    .local v4, "$i$a$-cache-StoreScreenKt$QueueButton$2$1\\19\\1429\\16":I
    move-object/from16 v34, v3

    .end local v3    # "it\\17":Ljava/lang/Object;
    .local v34, "it\\17":Ljava/lang/Object;
    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda31;

    invoke-direct {v3, v6}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda31;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 1429
    .end local v4    # "$i$a$-cache-StoreScreenKt$QueueButton$2$1\\19\\1429\\16":I
    nop

    .line 1430
    .local v3, "value\\18":Ljava/lang/Object;
    move-object/from16 v4, v31

    .end local v31    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .local v4, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1431
    nop

    .end local v3    # "value\\18":Ljava/lang/Object;
    goto :goto_b

    .line 1432
    .end local v4    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v34    # "it\\17":Ljava/lang/Object;
    .local v3, "it\\17":Ljava/lang/Object;
    .restart local v31    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    :cond_15
    move-object/from16 v34, v3

    move-object/from16 v4, v31

    .line 1428
    .end local v3    # "it\\17":Ljava/lang/Object;
    .end local v31    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .restart local v34    # "it\\17":Ljava/lang/Object;
    :goto_b
    nop

    .line 1427
    .end local v33    # "$i$a$-let-ComposerKt$cache$1\\18\\1427\\17":I
    .end local v34    # "it\\17":Ljava/lang/Object;
    nop

    .line 540
    .end local v4    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$f$cache\\17\\540":I
    .end local v35    # "invalid\\17":Z
    move-object/from16 v31, v3

    check-cast v31, Lkotlin/jvm/functions/Function0;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const-string v4, "store_queue"

    invoke-static {v3, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v32

    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$QueueButton$2$2;

    invoke-direct {v3, v8, v7}, Lorg/lighttouch/android/StoreScreenKt$QueueButton$2$2;-><init>(ZZ)V

    const/16 v4, 0x36

    move/from16 v44, v7

    .end local v7    # "failed":Z
    .local v44, "failed":Z
    const v7, -0x79ea54e5

    move/from16 v45, v8

    const/4 v8, 0x1

    .end local v8    # "busy":Z
    .local v45, "busy":Z
    invoke-static {v7, v8, v3, v9, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    move-object/from16 v36, v3

    check-cast v36, Lkotlin/jvm/functions/Function2;

    const v38, 0x30036

    const/16 v39, 0x1c

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    move-object/from16 v37, v9

    .end local v9    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v37    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v39}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v4, v37

    .end local v37    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\16":Landroidx/compose/runtime/Composer;
    const v3, 0xa50b729

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "542@33526L44,542@33489L135"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 543
    if-eqz v45, :cond_18

    const v3, 0x4c5de2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\20":Z
    move-object v7, v4

    .local v7, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1433
    .local v8, "$i$f$cache\\20\\543":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\20":Ljava/lang/Object;
    const/16 v31, 0x0

    .line 1434
    .local v31, "$i$a$-let-ComposerKt$cache$1\\21\\1433\\20":I
    if-nez v3, :cond_17

    sget-object v32, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p1, v3

    .end local v3    # "invalid\\20":Z
    .local p1, "invalid\\20":Z
    invoke-virtual/range {v32 .. v32}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v9, v3, :cond_16

    goto :goto_c

    .line 1438
    :cond_16
    move-object v3, v9

    goto :goto_d

    .line 1434
    .end local p1    # "invalid\\20":Z
    .restart local v3    # "invalid\\20":Z
    :cond_17
    move/from16 p1, v3

    .line 1435
    .end local v3    # "invalid\\20":Z
    .restart local p1    # "invalid\\20":Z
    :goto_c
    const/4 v3, 0x0

    .line 543
    .local v3, "$i$a$-cache-StoreScreenKt$QueueButton$2$3\\22\\1435\\16":I
    move/from16 v32, v3

    .end local v3    # "$i$a$-cache-StoreScreenKt$QueueButton$2$3\\22\\1435\\16":I
    .local v32, "$i$a$-cache-StoreScreenKt$QueueButton$2$3\\22\\1435\\16":I
    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda32;

    invoke-direct {v3, v2}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda32;-><init>(Ljava/util/List;)V

    .line 1435
    .end local v32    # "$i$a$-cache-StoreScreenKt$QueueButton$2$3\\22\\1435\\16":I
    nop

    .line 1436
    .local v3, "value\\21":Ljava/lang/Object;
    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1437
    nop

    .line 1434
    .end local v3    # "value\\21":Ljava/lang/Object;
    :goto_d
    nop

    .line 1433
    .end local v9    # "it\\20":Ljava/lang/Object;
    .end local v31    # "$i$a$-let-ComposerKt$cache$1\\21\\1433\\20":I
    nop

    .line 543
    .end local v7    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\20\\543":I
    .end local p1    # "invalid\\20":Z
    move-object/from16 v31, v3

    check-cast v31, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x28

    .local v7, "$this$dp\\23":I
    const/4 v8, 0x0

    .line 1439
    .local v8, "$i$f$getDp\\23\\543":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 543
    .end local v7    # "$this$dp\\23":I
    .end local v8    # "$i$f$getDp\\23\\543":I
    invoke-static {v3, v7}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v32

    const/4 v3, 0x3

    .local v3, "$this$dp\\24":I
    const/4 v7, 0x0

    .line 1439
    .local v7, "$i$f$getDp\\24\\543":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v35

    .line 543
    .end local v3    # "$this$dp\\24":I
    .end local v7    # "$i$f$getDp\\24\\543":I
    const-wide/16 v33, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v41, 0xc30

    const/16 v42, 0x74

    move-object/from16 v40, v4

    .end local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v40, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v42}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-IyT6zlY(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JFJIFLandroidx/compose/runtime/Composer;II)V

    .end local v40    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :cond_18
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 544
    invoke-static {v6}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$100(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    const v7, 0x4c5de2

    invoke-interface {v4, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v5, 0x0

    .local v5, "invalid\\25":Z
    move-object v7, v4

    .local v7, "$this$cache\\25":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1440
    .local v8, "$i$f$cache\\25\\544":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\25":Ljava/lang/Object;
    const/16 v31, 0x0

    .line 1441
    .local v31, "$i$a$-let-ComposerKt$cache$1\\26\\1440\\25":I
    sget-object v32, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 p1, v2

    .end local v2    # "items":Ljava/util/List;
    .local p1, "items":Ljava/util/List;
    invoke-virtual/range {v32 .. v32}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v9, v2, :cond_19

    .line 1442
    const/4 v2, 0x0

    .line 544
    .local v2, "$i$a$-cache-StoreScreenKt$QueueButton$2$4\\27\\1442\\16":I
    move/from16 v32, v2

    .end local v2    # "$i$a$-cache-StoreScreenKt$QueueButton$2$4\\27\\1442\\16":I
    .local v32, "$i$a$-cache-StoreScreenKt$QueueButton$2$4\\27\\1442\\16":I
    new-instance v2, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda33;

    invoke-direct {v2, v6}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda33;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 1442
    .end local v32    # "$i$a$-cache-StoreScreenKt$QueueButton$2$4\\27\\1442\\16":I
    nop

    .line 1443
    .local v2, "value\\26":Ljava/lang/Object;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1444
    nop

    .end local v2    # "value\\26":Ljava/lang/Object;
    goto :goto_e

    .line 1445
    :cond_19
    move-object v2, v9

    .line 1441
    :goto_e
    nop

    .line 1440
    .end local v9    # "it\\25":Ljava/lang/Object;
    .end local v31    # "$i$a$-let-ComposerKt$cache$1\\26\\1440\\25":I
    nop

    .line 544
    .end local v5    # "invalid\\25":Z
    .end local v7    # "$this$cache\\25":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\25\\544":I
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    and-int/lit8 v5, v18, 0xe

    or-int/lit16 v5, v5, 0x180

    invoke-static {v0, v3, v2, v4, v5}, Lorg/lighttouch/android/StoreScreenKt;->QueueMenu(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .line 540
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 545
    nop

    .line 1426
    .end local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v11    # "$changed\\16":I
    .end local v25    # "$i$a$-Box-StoreScreenKt$QueueButton$2\\16\\1426\\0":I
    .end local v27    # "$this$QueueButton_u24lambda_u24110\\16":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1425
    .end local v10    # "$i$a$-Layout-BoxKt$Box$1\\15\\1425\\9":I
    .end local v22    # "$changed\\15":I
    .end local v43    # "$composer\\15":Landroidx/compose/runtime/Composer;
    nop

    .line 1446
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1404
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1447
    nop

    .line 1398
    .end local v20    # "$i$f$ReusableComposeNode\\11\\1402":I
    .end local v23    # "$changed\\11":I
    .end local v29    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1448
    nop

    .line 1392
    .end local v15    # "$changed\\10":I
    .end local v16    # "compositeKeyHash\\10":I
    .end local v17    # "$i$f$Layout\\10\\1397":I
    .end local v28    # "materialized\\10":Landroidx/compose/ui/Modifier;
    .end local v30    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1449
    nop

    .end local v12    # "$i$f$Box\\9\\539":I
    .end local v13    # "propagateMinConstraints\\9":Z
    .end local v14    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "contentAlignment\\9":Landroidx/compose/ui/Alignment;
    .end local v21    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .end local v24    # "$changed\\9":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v6    # "open$delegate":Landroidx/compose/runtime/MutableState;
    .end local v44    # "failed":Z
    .end local v45    # "busy":Z
    .end local p1    # "items":Ljava/util/List;
    :cond_1a
    :goto_f
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_1b

    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda34;

    invoke-direct {v3, v0, v1}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda34;-><init>(Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 546
    :cond_1b
    return-void
.end method

.method private static final QueueButton$lambda$100(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 536
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 1634
    .local v3, "$i$f$getValue\\1\\536":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\536":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 536
    return v0
.end method

.method private static final QueueButton$lambda$101(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 536
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 1635
    .local v4, "$i$f$setValue\\1\\536":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1636
    nop

    .line 536
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\536":I
    return-void
.end method

.method private static final QueueButton$lambda$110$lambda$105$lambda$104(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 540
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$101(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueButton$lambda$110$lambda$107$lambda$106(Ljava/util/List;)F
    .locals 3
    .param p0, "$items"    # Ljava/util/List;

    .line 543
    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->queueFraction(Ljava/util/List;)F

    move-result v0

    const v1, 0x3ca3d70a    # 0.02f

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    return v0
.end method

.method private static final QueueButton$lambda$110$lambda$109$lambda$108(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$open$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 544
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton$lambda$101(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueButton$lambda$111(Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton(Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueButton$lambda$98(Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton(Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueMenu(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 21
    .param p0, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "open"    # Z
    .param p2, "onDismiss"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/StoreModel;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 550
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p4

    const v4, 0x4bf5ceb9    # 3.2218482E7f

    move-object/from16 v5, p3

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(QueueMenu)P(!1,2)551@34017L6,552@34070L11,552@34104L610,551@33919L795:StoreScreen.kt#o13vsk"

    invoke-static {v15, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p4

    .local v5, "$dirty":I
    and-int/lit8 v6, v3, 0x6

    if-nez v6, :cond_1

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v5, v6

    :cond_1
    and-int/lit8 v6, v3, 0x30

    if-nez v6, :cond_3

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_1

    :cond_2
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v5, v6

    :cond_3
    and-int/lit16 v6, v3, 0x180

    if-nez v6, :cond_5

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    const/16 v6, 0x100

    goto :goto_2

    :cond_4
    const/16 v6, 0x80

    :goto_2
    or-int/2addr v5, v6

    :cond_5
    and-int/lit16 v6, v5, 0x93

    const/16 v7, 0x92

    if-ne v6, v7, :cond_7

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_6

    goto :goto_3

    .line 552
    :cond_6
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v19, v5

    goto/16 :goto_4

    .line 550
    :cond_7
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_8

    const/4 v6, -0x1

    const-string v7, "org.lighttouch.android.QueueMenu (StoreScreen.kt:549)"

    invoke-static {v4, v5, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 551
    :cond_8
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreModel;->getQueue()Ljava/util/List;

    move-result-object v4

    .line 552
    .local v4, "items":Ljava/util/List;
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x12c

    .local v7, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 1450
    .local v8, "$i$f$getDp\\1\\552":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 552
    .end local v7    # "$this$dp\\1":I
    .end local v8    # "$i$f$getDp\\1\\552":I
    const/16 v8, 0x154

    .local v8, "$this$dp\\2":I
    const/4 v9, 0x0

    .line 1450
    .local v9, "$i$f$getDp\\2\\552":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 552
    .end local v8    # "$this$dp\\2":I
    .end local v9    # "$i$f$getDp\\2\\552":I
    invoke-static {v6, v7, v8}, Landroidx/compose/foundation/layout/SizeKt;->widthIn-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v6

    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v15, v8}, Landroidx/compose/material3/MaterialTheme;->getShapes(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Shapes;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/Shapes;->getLarge()Landroidx/compose/foundation/shape/CornerBasedShape;

    move-result-object v7

    move-object v8, v7

    check-cast v8, Landroidx/compose/ui/graphics/Shape;

    .line 553
    sget-object v7, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v7, v15, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v7

    invoke-virtual {v7}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v9

    new-instance v7, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;

    invoke-direct {v7, v4, v0}, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    const/16 v11, 0x36

    const v12, -0x76e1514c

    const/4 v13, 0x1

    invoke-static {v12, v13, v7, v15, v11}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    move-object v14, v7

    check-cast v14, Lkotlin/jvm/functions/Function3;

    shr-int/lit8 v7, v5, 0x3

    and-int/lit8 v7, v7, 0xe

    or-int/lit16 v7, v7, 0x180

    shr-int/lit8 v11, v5, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int v16, v7, v11

    .line 552
    move-object v11, v4

    move v7, v5

    .end local v4    # "items":Ljava/util/List;
    .end local v5    # "$dirty":I
    .local v7, "$dirty":I
    .local v11, "items":Ljava/util/List;
    const-wide/16 v4, 0x0

    move-object v3, v6

    const/4 v6, 0x0

    move v12, v7

    .end local v7    # "$dirty":I
    .local v12, "$dirty":I
    const/4 v7, 0x0

    move-object v13, v11

    .end local v11    # "items":Ljava/util/List;
    .local v13, "items":Ljava/util/List;
    const/4 v11, 0x0

    move/from16 v17, v12

    .end local v12    # "$dirty":I
    .local v17, "$dirty":I
    const/4 v12, 0x0

    move-object/from16 v18, v13

    .end local v13    # "items":Ljava/util/List;
    .local v18, "items":Ljava/util/List;
    const/4 v13, 0x0

    move/from16 v19, v17

    .end local v17    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v17, 0x30

    move-object/from16 v20, v18

    .end local v18    # "items":Ljava/util/List;
    .local v20, "items":Ljava/util/List;
    const/16 v18, 0x738

    invoke-static/range {v1 .. v18}, Landroidx/compose/material3/AndroidMenu_androidKt;->DropdownMenu-IlH_yew(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/ScrollState;Landroidx/compose/ui/window/PopupProperties;Landroidx/compose/ui/graphics/Shape;JFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v20    # "items":Ljava/util/List;
    :cond_9
    :goto_4
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_a

    new-instance v4, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda11;

    move/from16 v5, p4

    invoke-direct {v4, v0, v1, v2, v5}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda11;-><init>(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;I)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_5

    :cond_a
    move/from16 v5, p4

    .line 563
    :goto_5
    return-void
.end method

.method private static final QueueMenu$lambda$112(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueMenu(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueProgress(Lorg/lighttouch/android/QueueItem;Landroidx/compose/runtime/Composer;I)V
    .locals 23
    .param p0, "item"    # Lorg/lighttouch/android/QueueItem;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 566
    move-object/from16 v0, p0

    move/from16 v1, p2

    const v2, -0x65959e71

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(QueueProgress):StoreScreen.kt#o13vsk"

    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-nez v4, :cond_1

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    move v4, v5

    goto :goto_0

    :cond_0
    move v4, v6

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    move v15, v3

    .end local v3    # "$dirty":I
    .local v15, "$dirty":I
    and-int/lit8 v3, v15, 0x3

    if-ne v3, v6, :cond_3

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_2

    goto :goto_1

    .line 568
    :cond_2
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v12, v10

    goto/16 :goto_6

    .line 566
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_4

    const/4 v3, -0x1

    const-string v4, "org.lighttouch.android.QueueProgress (StoreScreen.kt:565)"

    invoke-static {v2, v15, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 567
    :cond_4
    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getProgress()Ljava/lang/Float;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x1

    if-eqz v2, :cond_8

    const v2, -0x56a7bab3

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "566@34841L34,566@34806L126"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v2, 0x4c5de2

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v15, 0xe

    if-ne v2, v5, :cond_5

    move v2, v6

    goto :goto_2

    :cond_5
    const/4 v2, 0x0

    .local v2, "invalid\\1":Z
    :goto_2
    move-object v5, v10

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1451
    .local v7, "$i$f$cache\\1\\567":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\1":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 1452
    .local v9, "$i$a$-let-ComposerKt$cache$1\\2\\1451\\1":I
    if-nez v2, :cond_7

    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v8, v11, :cond_6

    goto :goto_3

    .line 1456
    :cond_6
    move-object v12, v8

    goto :goto_4

    .line 1453
    :cond_7
    :goto_3
    const/4 v11, 0x0

    .line 567
    .local v11, "$i$a$-cache-StoreScreenKt$QueueProgress$1\\3\\1453\\0":I
    new-instance v12, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda37;

    invoke-direct {v12, v0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda37;-><init>(Lorg/lighttouch/android/QueueItem;)V

    .line 1453
    .end local v11    # "$i$a$-cache-StoreScreenKt$QueueProgress$1\\3\\1453\\0":I
    nop

    .line 1454
    .local v12, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1455
    nop

    .line 1452
    .end local v12    # "value\\2":Ljava/lang/Object;
    :goto_4
    nop

    .line 1451
    .end local v8    # "it\\1":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\2\\1451\\1":I
    nop

    .line 567
    .end local v2    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\1\\567":I
    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    invoke-static {v2, v4, v6, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    const/16 v2, 0x8

    .local v2, "$this$dp\\4":I
    const/4 v3, 0x0

    .line 1457
    .local v3, "$i$f$getDp\\4\\567":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v18

    .line 567
    .end local v2    # "$this$dp\\4":I
    .end local v3    # "$i$f$getDp\\4\\567":I
    const/16 v21, 0xd

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v13, 0x30

    const/16 v14, 0x7c

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    const/4 v9, 0x0

    move-object v3, v12

    move-object v12, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static/range {v3 .. v14}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-GJbTh5U(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JJIFLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_5

    .line 568
    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_8
    move-object v12, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer":Landroidx/compose/runtime/Composer;
    const v2, -0x56a7a9ed

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "567@34942L68"

    invoke-static {v12, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    invoke-static {v2, v4, v6, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v16

    const/16 v2, 0x8

    .local v2, "$this$dp\\5":I
    const/4 v3, 0x0

    .line 1458
    .local v3, "$i$f$getDp\\5\\568":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v18

    .line 568
    .end local v2    # "$this$dp\\5":I
    .end local v3    # "$i$f$getDp\\5\\568":I
    const/16 v21, 0xd

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v11, 0x6

    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    const/16 v12, 0x1e

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v3 .. v12}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object v12, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_9
    :goto_6
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_a

    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v3, v0, v1}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/QueueItem;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 569
    :cond_a
    return-void
.end method

.method private static final QueueProgress$lambda$114$lambda$113(Lorg/lighttouch/android/QueueItem;)F
    .locals 3
    .param p0, "$item"    # Lorg/lighttouch/android/QueueItem;

    .line 567
    invoke-virtual {p0}, Lorg/lighttouch/android/QueueItem;->getProgress()Ljava/lang/Float;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v0

    return v0
.end method

.method private static final QueueProgress$lambda$115(Lorg/lighttouch/android/QueueItem;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueProgress(Lorg/lighttouch/android/QueueItem;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueRow(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 97
    .param p0, "item"    # Lorg/lighttouch/android/QueueItem;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 572
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const v3, 0x653de4e4

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(QueueRow)572@35089L895:StoreScreen.kt#o13vsk"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    if-nez v6, :cond_1

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v5, v6

    :cond_1
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_3

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_1

    :cond_2
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v5, v6

    :cond_3
    and-int/lit8 v6, v5, 0x13

    const/16 v8, 0x12

    if-ne v6, v8, :cond_5

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_4

    goto :goto_2

    .line 1592
    :cond_4
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v25, v5

    goto/16 :goto_15

    .line 572
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, -0x1

    const-string v8, "org.lighttouch.android.QueueRow (StoreScreen.kt:571)"

    invoke-static {v3, v5, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 573
    :cond_6
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v3, v6, v9, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    const/16 v3, 0x8

    .local v3, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 1459
    .local v6, "$i$f$getDp\\1\\573":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 573
    .end local v3    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\573":I
    const/16 v15, 0xd

    const/16 v16, 0x0

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-static/range {v10 .. v16}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const-string v6, "store_job"

    invoke-static {v3, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v6, 0x6

    .local v6, "$changed\\2":I
    const/4 v8, 0x0

    .line 1460
    .local v8, "$i$f$Column\\2\\573":I
    const v10, -0x1cd0f17e

    const-string v11, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v4, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1461
    sget-object v12, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v12}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v12

    .line 1462
    .local v12, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 1465
    .local v13, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v14, v6, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v15, v6, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v14, v15

    invoke-static {v12, v13, v4, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v6, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 1466
    nop

    .local v15, "$changed\\3":I
    const/16 v16, 0x0

    .line 1467
    .local v16, "$i$f$Layout\\3\\1466":I
    const v9, -0x4ee9b9da

    const-string v7, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v4, v9, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1468
    const/4 v10, 0x0

    invoke-static {v4, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v18

    .line 1469
    .local v18, "compositeKeyHash\\3":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 1470
    .local v10, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 1472
    .local v9, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    move-object/from16 v22, v3

    .end local v3    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\2":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v15, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 1471
    move-object/from16 v23, v21

    .local v3, "$changed\\4":I
    .local v23, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v21, 0x0

    .line 1473
    .local v21, "$i$f$ReusableComposeNode\\4\\1471":I
    move/from16 v24, v3

    .end local v3    # "$changed\\4":I
    .local v24, "$changed\\4":I
    const v3, -0x2942ffcf

    move/from16 v25, v5

    .end local v5    # "$dirty":I
    .local v25, "$dirty":I
    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1474
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1475
    :cond_7
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1476
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_8

    .line 1477
    move-object/from16 v3, v23

    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3

    .line 1479
    .end local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_8
    move-object/from16 v3, v23

    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1481
    :goto_3
    move-object/from16 v23, v3

    .end local v3    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 1482
    .local v27, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1481\\3":I
    sget-object v28, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v29, v6

    .end local v6    # "$changed\\2":I
    .local v29, "$changed\\2":I
    invoke-virtual/range {v28 .. v28}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v14, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1483
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v10, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1485
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v28, 0x0

    .line 1486
    .local v28, "$i$f$set-impl\\6\\1485":I
    move-object/from16 v30, v3

    .local v30, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 1487
    .local v31, "$i$a$-with-Updater$set$1\\7\\1486\\6":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v32

    if-nez v32, :cond_a

    move/from16 v32, v8

    .end local v8    # "$i$f$Column\\2\\573":I
    .local v32, "$i$f$Column\\2\\573":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v33, v10

    .end local v10    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v33, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_9

    goto :goto_4

    :cond_9
    move-object/from16 v10, v30

    goto :goto_5

    .end local v32    # "$i$f$Column\\2\\573":I
    .end local v33    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "$i$f$Column\\2\\573":I
    .restart local v10    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_a
    move/from16 v32, v8

    move-object/from16 v33, v10

    .line 1488
    .end local v8    # "$i$f$Column\\2\\573":I
    .end local v10    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v32    # "$i$f$Column\\2\\573":I
    .restart local v33    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_4
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    move-object/from16 v10, v30

    .end local v30    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1489
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v3, v8, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1491
    :goto_5
    nop

    .line 1486
    .end local v10    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-with-Updater$set$1\\7\\1486\\6":I
    nop

    .line 1491
    nop

    .line 1492
    .end local v6    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v28    # "$i$f$set-impl\\6\\1485":I
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v9, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1493
    nop

    .line 1481
    .end local v3    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1481\\3":I
    nop

    .line 1494
    shr-int/lit8 v3, v24, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\8":I
    move-object v6, v4

    .local v6, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1495
    .local v8, "$i$a$-Layout-ColumnKt$Column$1\\8\\1494\\2":I
    const v10, -0x16ef5699

    move/from16 v27, v3

    .end local v3    # "$changed\\8":I
    .local v27, "$changed\\8":I
    const-string v3, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v6, v10, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v28, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v30, v29, 0x6

    and-int/lit8 v30, v30, 0x70

    or-int/lit8 v30, v30, 0x6

    .local v30, "$changed\\9":I
    check-cast v28, Landroidx/compose/foundation/layout/ColumnScope;

    .local v28, "$this$QueueRow_u24lambda_u24122\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v31, v6

    .local v31, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 574
    .local v34, "$i$a$-Column-StoreScreenKt$QueueRow$1\\9\\1495\\0":I
    const v10, -0x52fc73d

    move-object/from16 v36, v6

    .end local v6    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v36, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v6, "C573@35172L697:StoreScreen.kt#o13vsk"

    move/from16 v37, v8

    move-object/from16 v8, v31

    .end local v31    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v8, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v37, "$i$a$-Layout-ColumnKt$Column$1\\8\\1494\\2":I
    invoke-static {v8, v10, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    .local v6, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v10, 0x180

    .local v10, "$changed\\10":I
    const/16 v31, 0x0

    .line 1496
    .local v31, "$i$f$Row\\10\\574":I
    move-object/from16 v38, v9

    .end local v9    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v38, "materialized\\3":Landroidx/compose/ui/Modifier;
    const v9, 0x2952b718

    move/from16 v39, v10

    .end local v10    # "$changed\\10":I
    .local v39, "$changed\\10":I
    const-string v10, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v8, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1497
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    .line 1498
    .local v9, "modifier\\10":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v10

    .line 1502
    .local v10, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v40, v39, 0x3

    and-int/lit8 v40, v40, 0xe

    shr-int/lit8 v41, v39, 0x3

    and-int/lit8 v41, v41, 0x70

    move-object/from16 v42, v12

    .end local v12    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v42, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    or-int v12, v40, v41

    invoke-static {v10, v6, v8, v12}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v40, v39, 0x3

    and-int/lit8 v40, v40, 0x70

    .line 1503
    nop

    .local v40, "$changed\\11":I
    const/16 v41, 0x0

    .line 1504
    .local v41, "$i$f$Layout\\11\\1503":I
    move-object/from16 v43, v6

    const v6, -0x4ee9b9da

    .end local v6    # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .local v43, "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v8, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1505
    const/4 v6, 0x0

    invoke-static {v8, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v44

    .line 1506
    .local v44, "compositeKeyHash\\11":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v6

    .line 1507
    .local v6, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v45, v10

    .end local v10    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v45, "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v8, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 1509
    .local v10, "materialized\\11":Landroidx/compose/ui/Modifier;
    sget-object v46, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v46 .. v46}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v46

    move-object/from16 v47, v9

    .end local v9    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v47, "modifier\\10":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v9, v40, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/lit8 v9, v9, 0x6

    .line 1508
    nop

    .local v9, "$changed\\12":I
    move-object/from16 v48, v46

    .local v48, "factory\\12":Lkotlin/jvm/functions/Function0;
    const/16 v46, 0x0

    .line 1510
    .local v46, "$i$f$ReusableComposeNode\\12\\1508":I
    move/from16 v49, v9

    const v9, -0x2942ffcf

    .end local v9    # "$changed\\12":I
    .local v49, "$changed\\12":I
    invoke-static {v8, v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1511
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v9

    instance-of v9, v9, Landroidx/compose/runtime/Applier;

    if-nez v9, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1512
    :cond_b
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1513
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-eqz v9, :cond_c

    .line 1514
    move-object/from16 v9, v48

    .end local v48    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v9, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 1516
    .end local v9    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v48    # "factory\\12":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v9, v48

    .end local v48    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v9    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1518
    :goto_6
    move-object/from16 v48, v9

    .end local v9    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v48    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v50, 0x0

    .line 1519
    .local v50, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\1518\\11":I
    sget-object v51, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v52, v13

    .end local v13    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v52, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-virtual/range {v51 .. v51}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v9, v12, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1520
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v9, v6, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1522
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\14":Lkotlin/jvm/functions/Function2;
    const/16 v51, 0x0

    .line 1523
    .local v51, "$i$f$set-impl\\14\\1522":I
    move-object/from16 v53, v9

    .local v53, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 1524
    .local v54, "$i$a$-with-Updater$set$1\\15\\1523\\14":I
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v55

    if-nez v55, :cond_e

    move-object/from16 v55, v6

    .end local v6    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .local v55, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move-object/from16 v56, v12

    .end local v12    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v56, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v44 .. v44}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v6, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_d

    goto :goto_7

    :cond_d
    move-object/from16 v12, v53

    goto :goto_8

    .end local v55    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v56    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v6    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_e
    move-object/from16 v55, v6

    move-object/from16 v56, v12

    .line 1525
    .end local v6    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v55    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v56    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_7
    invoke-static/range {v44 .. v44}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v12, v53

    .end local v53    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1526
    invoke-static/range {v44 .. v44}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v9, v6, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1528
    :goto_8
    nop

    .line 1523
    .end local v12    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-with-Updater$set$1\\15\\1523\\14":I
    nop

    .line 1528
    nop

    .line 1529
    .end local v13    # "block\\14":Lkotlin/jvm/functions/Function2;
    .end local v51    # "$i$f$set-impl\\14\\1522":I
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v9, v10, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1530
    nop

    .line 1518
    .end local v9    # "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\1518\\11":I
    nop

    .line 1531
    shr-int/lit8 v6, v49, 0x6

    and-int/lit8 v6, v6, 0xe

    .local v6, "$changed\\16":I
    move-object v9, v8

    .local v9, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1532
    .local v12, "$i$a$-Layout-RowKt$Row$1\\16\\1531\\10":I
    const v13, -0x184f2606

    move/from16 v50, v6

    .end local v6    # "$changed\\16":I
    .local v50, "$changed\\16":I
    const-string v6, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v9, v13, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v13, v39, 0x6

    and-int/lit8 v13, v13, 0x70

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\17":I
    move-object/from16 v57, v6

    check-cast v57, Landroidx/compose/foundation/layout/RowScope;

    .local v57, "$this$QueueRow_u24lambda_u24122_u24lambda_u24121\\17":Landroidx/compose/foundation/layout/RowScope;
    move-object v6, v9

    .local v6, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 575
    .local v51, "$i$a$-Row-StoreScreenKt$QueueRow$1$1\\17\\1532\\9":I
    move-object/from16 v53, v9

    .end local v9    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v53, "$composer\\16":Landroidx/compose/runtime/Composer;
    const v9, 0xea576f8

    move-object/from16 v54, v10

    .end local v10    # "materialized\\11":Landroidx/compose/ui/Modifier;
    .local v54, "materialized\\11":Landroidx/compose/ui/Modifier;
    const-string v10, "C574@35238L406:StoreScreen.kt#o13vsk"

    invoke-static {v6, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v58, v9

    check-cast v58, Landroidx/compose/ui/Modifier;

    const/16 v61, 0x2

    const/16 v62, 0x0

    const/high16 v59, 0x3f800000    # 1.0f

    const/16 v60, 0x0

    invoke-static/range {v57 .. v62}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .local v9, "modifier\\18":Landroidx/compose/ui/Modifier;
    const/4 v10, 0x0

    .local v10, "$changed\\18":I
    const/16 v58, 0x0

    .line 1533
    .local v58, "$i$f$Column\\18\\575":I
    move/from16 v59, v10

    const v10, -0x1cd0f17e

    .end local v10    # "$changed\\18":I
    .local v59, "$changed\\18":I
    invoke-static {v6, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1534
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v10

    .line 1535
    .local v10, "verticalArrangement\\18":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v11

    .line 1538
    .local v11, "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v17, v59, 0x3

    and-int/lit8 v17, v17, 0xe

    shr-int/lit8 v60, v59, 0x3

    and-int/lit8 v60, v60, 0x70

    move/from16 v71, v12

    .end local v12    # "$i$a$-Layout-RowKt$Row$1\\16\\1531\\10":I
    .local v71, "$i$a$-Layout-RowKt$Row$1\\16\\1531\\10":I
    or-int v12, v17, v60

    invoke-static {v10, v11, v6, v12}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\18":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v59, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 1539
    nop

    .local v17, "$changed\\19":I
    const/16 v60, 0x0

    .line 1540
    .local v60, "$i$f$Layout\\19\\1539":I
    move-object/from16 v61, v10

    const v10, -0x4ee9b9da

    .end local v10    # "verticalArrangement\\18":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v61, "verticalArrangement\\18":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v6, v10, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1541
    const/4 v7, 0x0

    invoke-static {v6, v7}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v10

    .line 1542
    .local v10, "compositeKeyHash\\19":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 1543
    .local v7, "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v20, v10

    .end local v10    # "compositeKeyHash\\19":I
    .local v20, "compositeKeyHash\\19":I
    invoke-static {v6, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 1545
    .local v10, "materialized\\19":Landroidx/compose/ui/Modifier;
    sget-object v62, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v62 .. v62}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v62

    move-object/from16 v63, v9

    .end local v9    # "modifier\\18":Landroidx/compose/ui/Modifier;
    .local v63, "modifier\\18":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v9, v17, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/lit8 v9, v9, 0x6

    .line 1544
    move-object/from16 v64, v62

    .local v9, "$changed\\20":I
    .local v64, "factory\\20":Lkotlin/jvm/functions/Function0;
    const/16 v62, 0x0

    .line 1546
    .local v62, "$i$f$ReusableComposeNode\\20\\1544":I
    move/from16 v65, v9

    const v9, -0x2942ffcf

    .end local v9    # "$changed\\20":I
    .local v65, "$changed\\20":I
    invoke-static {v6, v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1547
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1548
    :cond_f
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1549
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_10

    .line 1550
    move-object/from16 v5, v64

    .end local v64    # "factory\\20":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\20":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 1552
    .end local v5    # "factory\\20":Lkotlin/jvm/functions/Function0;
    .restart local v64    # "factory\\20":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v5, v64

    .end local v64    # "factory\\20":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\20":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1554
    :goto_9
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 1555
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\21\\1554\\19":I
    sget-object v64, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v66, v5

    .end local v5    # "factory\\20":Lkotlin/jvm/functions/Function0;
    .local v66, "factory\\20":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v64 .. v64}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v9, v12, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1556
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v9, v7, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1558
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\22":Lkotlin/jvm/functions/Function2;
    const/16 v64, 0x0

    .line 1559
    .local v64, "$i$f$set-impl\\22\\1558":I
    move-object/from16 v67, v9

    .local v67, "$this$set_impl_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    const/16 v68, 0x0

    .line 1560
    .local v68, "$i$a$-with-Updater$set$1\\23\\1559\\22":I
    invoke-interface/range {v67 .. v67}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v69

    if-nez v69, :cond_12

    move-object/from16 v69, v7

    .end local v7    # "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    .local v69, "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v67 .. v67}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move-object/from16 v70, v11

    .end local v11    # "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    .local v70, "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v7, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_11

    goto :goto_a

    :cond_11
    move-object/from16 v11, v67

    goto :goto_b

    .end local v69    # "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v70    # "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v7    # "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v11    # "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_12
    move-object/from16 v69, v7

    move-object/from16 v70, v11

    .line 1561
    .end local v7    # "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v11    # "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v69    # "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v70    # "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    :goto_a
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v11, v67

    .end local v67    # "$this$set_impl_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .local v11, "$this$set_impl_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1562
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v9, v7, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1564
    :goto_b
    nop

    .line 1559
    .end local v11    # "$this$set_impl_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .end local v68    # "$i$a$-with-Updater$set$1\\23\\1559\\22":I
    nop

    .line 1564
    nop

    .line 1565
    .end local v5    # "block\\22":Lkotlin/jvm/functions/Function2;
    .end local v64    # "$i$f$set-impl\\22\\1558":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v9, v10, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1566
    nop

    .line 1554
    .end local v9    # "$this$Layout_u24lambda_u240\\21":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\21\\1554\\19":I
    nop

    .line 1567
    shr-int/lit8 v5, v65, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\24":I
    move-object v7, v6

    .local v7, "$composer\\24":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 1568
    .local v9, "$i$a$-Layout-ColumnKt$Column$1\\24\\1567\\18":I
    const v11, -0x16ef5699

    invoke-static {v7, v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v11, v59, 0x6

    and-int/lit8 v11, v11, 0x70

    or-int/lit8 v11, v11, 0x6

    .local v11, "$changed\\25":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$QueueRow_u24lambda_u24122_u24lambda_u24121_u24lambda_u24116\\25":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v93, v7

    .local v93, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 576
    .local v26, "$i$a$-Column-StoreScreenKt$QueueRow$1$1$1\\25\\1568\\17":I
    move-object/from16 v35, v3

    .end local v3    # "$this$QueueRow_u24lambda_u24122_u24lambda_u24121_u24lambda_u24116\\25":Landroidx/compose/foundation/layout/ColumnScope;
    .local v35, "$this$QueueRow_u24lambda_u24122_u24lambda_u24121_u24lambda_u24116\\25":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, 0x20e21275

    move/from16 v64, v5

    .end local v5    # "$changed\\24":I
    .local v64, "$changed\\24":I
    const-string v5, "C575@35322L10,575@35284L108,576@35462L10,576@35409L221:StoreScreen.kt#o13vsk"

    move-object/from16 v67, v7

    .end local v93    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\25":Landroidx/compose/runtime/Composer;
    .local v67, "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-static {v7, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getName()Ljava/lang/String;

    move-result-object v72

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v92

    sget-object v3, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v87

    const/16 v95, 0xc30

    const v96, 0xd7fe

    const/16 v73, 0x0

    const-wide/16 v74, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const-wide/16 v81, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const-wide/16 v85, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x1

    const/16 v90, 0x0

    const/16 v91, 0x0

    const/16 v94, 0x0

    .end local v7    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .restart local v93    # "$composer\\25":Landroidx/compose/runtime/Composer;
    invoke-static/range {v72 .. v96}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 577
    .end local v93    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\25":Landroidx/compose/runtime/Composer;
    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getError()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_13

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getPhase()Ljava/lang/String;

    move-result-object v3

    :cond_13
    move-object/from16 v72, v3

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v92

    .line 578
    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getError()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_14

    const v3, -0x59c70587

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "577@35564L11"

    invoke-static {v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v73

    goto :goto_c

    :cond_14
    const v3, -0x59c700dc

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "577@35601L11"

    invoke-static {v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v7, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v73

    :goto_c
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v74, v73

    .line 577
    nop

    .line 578
    nop

    .line 577
    const/16 v95, 0xc00

    const v96, 0xdffa

    const/16 v73, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const-wide/16 v81, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const-wide/16 v85, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x2

    const/16 v90, 0x0

    const/16 v91, 0x0

    const/16 v94, 0x0

    move-object/from16 v93, v7

    .end local v7    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .restart local v93    # "$composer\\25":Landroidx/compose/runtime/Composer;
    invoke-static/range {v72 .. v96}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 576
    invoke-static/range {v93 .. v93}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 579
    nop

    .line 1568
    .end local v11    # "$changed\\25":I
    .end local v26    # "$i$a$-Column-StoreScreenKt$QueueRow$1$1$1\\25\\1568\\17":I
    .end local v35    # "$this$QueueRow_u24lambda_u24122_u24lambda_u24121_u24lambda_u24116\\25":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v93    # "$composer\\25":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v67}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1567
    .end local v9    # "$i$a$-Layout-ColumnKt$Column$1\\24\\1567\\18":I
    .end local v64    # "$changed\\24":I
    .end local v67    # "$composer\\24":Landroidx/compose/runtime/Composer;
    nop

    .line 1569
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1546
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1570
    nop

    .line 1540
    .end local v62    # "$i$f$ReusableComposeNode\\20\\1544":I
    .end local v65    # "$changed\\20":I
    .end local v66    # "factory\\20":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1571
    nop

    .line 1533
    .end local v10    # "materialized\\19":Landroidx/compose/ui/Modifier;
    .end local v17    # "$changed\\19":I
    .end local v20    # "compositeKeyHash\\19":I
    .end local v60    # "$i$f$Layout\\19\\1539":I
    .end local v69    # "localMap\\19":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1572
    nop

    .end local v12    # "measurePolicy\\18":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v58    # "$i$f$Column\\18\\575":I
    .end local v59    # "$changed\\18":I
    .end local v61    # "verticalArrangement\\18":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v63    # "modifier\\18":Landroidx/compose/ui/Modifier;
    .end local v70    # "horizontalAlignment\\18":Landroidx/compose/ui/Alignment$Horizontal;
    const v3, 0x320588b6

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "579@35700L25,579@35679L66"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 580
    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getCancellable()Z

    move-result v3

    const-string v5, "CC(remember):StoreScreen.kt#9igjgp"

    const v7, -0x615d173a

    if-eqz v3, :cond_18

    invoke-interface {v6, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    and-int/lit8 v9, v25, 0xe

    const/4 v10, 0x4

    if-ne v9, v10, :cond_15

    const/4 v9, 0x1

    goto :goto_d

    :cond_15
    const/4 v9, 0x0

    :goto_d
    or-int/2addr v3, v9

    .local v3, "invalid\\26":Z
    move-object v9, v6

    .local v9, "$this$cache\\26":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 1573
    .local v10, "$i$f$cache\\26\\580":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\26":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 1574
    .local v12, "$i$a$-let-ComposerKt$cache$1\\27\\1573\\26":I
    if-nez v3, :cond_17

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v11, v7, :cond_16

    goto :goto_e

    .line 1578
    :cond_16
    move/from16 v17, v3

    move-object v3, v11

    goto :goto_f

    .line 1575
    :cond_17
    :goto_e
    const/4 v7, 0x0

    .line 580
    .local v7, "$i$a$-cache-StoreScreenKt$QueueRow$1$1$2\\28\\1575\\17":I
    move/from16 v17, v3

    .end local v3    # "invalid\\26":Z
    .local v17, "invalid\\26":Z
    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda13;

    invoke-direct {v3, v1, v0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda13;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)V

    .line 1575
    .end local v7    # "$i$a$-cache-StoreScreenKt$QueueRow$1$1$2\\28\\1575\\17":I
    nop

    .line 1576
    .local v3, "value\\27":Ljava/lang/Object;
    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1577
    nop

    .line 1574
    .end local v3    # "value\\27":Ljava/lang/Object;
    :goto_f
    nop

    .line 1573
    .end local v11    # "it\\26":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\27\\1573\\26":I
    nop

    .line 580
    .end local v9    # "$this$cache\\26":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\26\\580":I
    .end local v17    # "invalid\\26":Z
    move-object/from16 v58, v3

    check-cast v58, Lkotlin/jvm/functions/Function0;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v3}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$-1737579242$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v67

    const/high16 v69, 0x30000000

    const/16 v70, 0x1fe

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    move-object/from16 v68, v6

    .end local v6    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v68, "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v70}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v9, v68

    .end local v68    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\17":Landroidx/compose/runtime/Composer;
    goto :goto_10

    .end local v9    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\17":Landroidx/compose/runtime/Composer;
    :cond_18
    move-object v9, v6

    .end local v6    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\17":Landroidx/compose/runtime/Composer;
    :goto_10
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v3, 0x32059563

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "580@35816L24,580@35795L64"

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 581
    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v3

    sget-object v6, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    if-ne v3, v6, :cond_1c

    const v3, -0x615d173a

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    and-int/lit8 v5, v25, 0xe

    const/4 v10, 0x4

    if-ne v5, v10, :cond_19

    const/16 v19, 0x1

    goto :goto_11

    :cond_19
    const/16 v19, 0x0

    :goto_11
    or-int v3, v3, v19

    .local v3, "invalid\\29":Z
    move-object v5, v9

    .local v5, "$this$cache\\29":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1579
    .local v6, "$i$f$cache\\29\\581":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\29":Ljava/lang/Object;
    const/4 v10, 0x0

    .line 1580
    .local v10, "$i$a$-let-ComposerKt$cache$1\\30\\1579\\29":I
    if-nez v3, :cond_1b

    sget-object v11, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v11}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v7, v11, :cond_1a

    goto :goto_12

    .line 1584
    :cond_1a
    move-object v12, v7

    goto :goto_13

    .line 1581
    :cond_1b
    :goto_12
    const/4 v11, 0x0

    .line 581
    .local v11, "$i$a$-cache-StoreScreenKt$QueueRow$1$1$3\\31\\1581\\17":I
    new-instance v12, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v12, v1, v0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda14;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)V

    .line 1581
    .end local v11    # "$i$a$-cache-StoreScreenKt$QueueRow$1$1$3\\31\\1581\\17":I
    nop

    .line 1582
    .local v12, "value\\30":Ljava/lang/Object;
    invoke-interface {v5, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1583
    nop

    .line 1580
    .end local v12    # "value\\30":Ljava/lang/Object;
    :goto_13
    nop

    .line 1579
    .end local v7    # "it\\29":Ljava/lang/Object;
    .end local v10    # "$i$a$-let-ComposerKt$cache$1\\30\\1579\\29":I
    nop

    .line 581
    .end local v3    # "invalid\\29":Z
    .end local v5    # "$this$cache\\29":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\29\\581":I
    move-object/from16 v58, v12

    check-cast v58, Lkotlin/jvm/functions/Function0;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v3}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$-1312445043$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v67

    const/high16 v69, 0x30000000

    const/16 v70, 0x1fe

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    move-object/from16 v68, v9

    .end local v9    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v68    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v70}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    goto :goto_14

    .end local v68    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\17":Landroidx/compose/runtime/Composer;
    :cond_1c
    move-object/from16 v68, v9

    .end local v9    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v68    # "$composer\\17":Landroidx/compose/runtime/Composer;
    :goto_14
    invoke-interface/range {v68 .. v68}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 575
    invoke-static/range {v68 .. v68}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 582
    nop

    .line 1532
    .end local v13    # "$changed\\17":I
    .end local v51    # "$i$a$-Row-StoreScreenKt$QueueRow$1$1\\17\\1532\\9":I
    .end local v57    # "$this$QueueRow_u24lambda_u24122_u24lambda_u24121\\17":Landroidx/compose/foundation/layout/RowScope;
    .end local v68    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1531
    .end local v50    # "$changed\\16":I
    .end local v53    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v71    # "$i$a$-Layout-RowKt$Row$1\\16\\1531\\10":I
    nop

    .line 1585
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1510
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1586
    nop

    .line 1504
    .end local v46    # "$i$f$ReusableComposeNode\\12\\1508":I
    .end local v48    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .end local v49    # "$changed\\12":I
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1587
    nop

    .line 1496
    .end local v40    # "$changed\\11":I
    .end local v41    # "$i$f$Layout\\11\\1503":I
    .end local v44    # "compositeKeyHash\\11":I
    .end local v54    # "materialized\\11":Landroidx/compose/ui/Modifier;
    .end local v55    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1588
    nop

    .end local v31    # "$i$f$Row\\10\\574":I
    .end local v39    # "$changed\\10":I
    .end local v43    # "verticalAlignment\\10":Landroidx/compose/ui/Alignment$Vertical;
    .end local v45    # "horizontalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v47    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v56    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    const v3, 0x41e604be

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "582@35959L19"

    invoke-static {v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 583
    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v3

    sget-object v5, Lorg/lighttouch/android/QueueState;->DOWNLOADING:Lorg/lighttouch/android/QueueState;

    if-eq v3, v5, :cond_1d

    invoke-virtual {v0}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v3

    sget-object v5, Lorg/lighttouch/android/QueueState;->INSTALLING:Lorg/lighttouch/android/QueueState;

    if-ne v3, v5, :cond_1e

    :cond_1d
    and-int/lit8 v3, v25, 0xe

    invoke-static {v0, v8, v3}, Lorg/lighttouch/android/StoreScreenKt;->QueueProgress(Lorg/lighttouch/android/QueueItem;Landroidx/compose/runtime/Composer;I)V

    :cond_1e
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 574
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 584
    nop

    .line 1495
    .end local v8    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v28    # "$this$QueueRow_u24lambda_u24122\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v30    # "$changed\\9":I
    .end local v34    # "$i$a$-Column-StoreScreenKt$QueueRow$1\\9\\1495\\0":I
    invoke-static/range {v36 .. v36}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1494
    .end local v27    # "$changed\\8":I
    .end local v36    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v37    # "$i$a$-Layout-ColumnKt$Column$1\\8\\1494\\2":I
    nop

    .line 1589
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1473
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1590
    nop

    .line 1467
    .end local v21    # "$i$f$ReusableComposeNode\\4\\1471":I
    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v24    # "$changed\\4":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1591
    nop

    .line 1460
    .end local v15    # "$changed\\3":I
    .end local v16    # "$i$f$Layout\\3\\1466":I
    .end local v18    # "compositeKeyHash\\3":I
    .end local v33    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v38    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1592
    nop

    .end local v14    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v29    # "$changed\\2":I
    .end local v32    # "$i$f$Column\\2\\573":I
    .end local v42    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v52    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_1f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_1f
    :goto_15
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_20

    new-instance v5, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda15;

    invoke-direct {v5, v0, v1, v2}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda15;-><init>(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;I)V

    invoke-interface {v3, v5}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 585
    :cond_20
    return-void
.end method

.method private static final QueueRow$lambda$122$lambda$121$lambda$118$lambda$117(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)Lkotlin/Unit;
    .locals 2
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$item"    # Lorg/lighttouch/android/QueueItem;

    .line 580
    invoke-virtual {p1}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/StoreModel;->cancel(J)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueRow$lambda$122$lambda$121$lambda$120$lambda$119(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/QueueItem;)Lkotlin/Unit;
    .locals 2
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$item"    # Lorg/lighttouch/android/QueueItem;

    .line 581
    invoke-virtual {p1}, Lorg/lighttouch/android/QueueItem;->getId()J

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Lorg/lighttouch/android/StoreModel;->retry(J)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final QueueRow$lambda$123(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreScreenKt;->QueueRow(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final ResultRow(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;Landroidx/compose/runtime/Composer;II)V
    .locals 113
    .param p0, "app"    # Lorg/json/JSONObject;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "rank"    # Ljava/lang/Integer;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v4, p4

    const-string v0, "app"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "model"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 401
    const v0, -0x63a25626

    move-object/from16 v3, p3

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(ResultRow)412@24006L19,412@23936L1972:StoreScreen.kt#o13vsk"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p4

    .local v3, "$dirty":I
    and-int/lit8 v5, p5, 0x1

    if-eqz v5, :cond_0

    or-int/lit8 v3, v3, 0x6

    goto :goto_1

    :cond_0
    and-int/lit8 v5, v4, 0x6

    if-nez v5, :cond_2

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v3, v5

    :cond_2
    :goto_1
    and-int/lit8 v5, p5, 0x2

    if-eqz v5, :cond_3

    or-int/lit8 v3, v3, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v5, v4, 0x30

    if-nez v5, :cond_5

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    const/16 v5, 0x20

    goto :goto_2

    :cond_4
    const/16 v5, 0x10

    :goto_2
    or-int/2addr v3, v5

    :cond_5
    :goto_3
    and-int/lit8 v5, p5, 0x4

    if-eqz v5, :cond_6

    or-int/lit16 v3, v3, 0x180

    move-object/from16 v9, p2

    goto :goto_5

    :cond_6
    and-int/lit16 v9, v4, 0x180

    if-nez v9, :cond_8

    move-object/from16 v9, p2

    invoke-interface {v6, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_7

    const/16 v10, 0x100

    goto :goto_4

    :cond_7
    const/16 v10, 0x80

    :goto_4
    or-int/2addr v3, v10

    goto :goto_5

    :cond_8
    move-object/from16 v9, p2

    :goto_5
    move v10, v3

    .end local v3    # "$dirty":I
    .local v10, "$dirty":I
    and-int/lit16 v3, v10, 0x93

    const/16 v11, 0x92

    if-ne v3, v11, :cond_a

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_9

    goto :goto_6

    .line 1135
    :cond_9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v56, v6

    move-object v3, v9

    goto/16 :goto_27

    .line 401
    :cond_a
    :goto_6
    if-eqz v5, :cond_b

    const/4 v3, 0x0

    .end local p2    # "rank":Ljava/lang/Integer;
    .local v3, "rank":Ljava/lang/Integer;
    goto :goto_7

    .end local v3    # "rank":Ljava/lang/Integer;
    .restart local p2    # "rank":Ljava/lang/Integer;
    :cond_b
    move-object v3, v9

    .end local p2    # "rank":Ljava/lang/Integer;
    .restart local v3    # "rank":Ljava/lang/Integer;
    :goto_7
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_c

    const/4 v5, -0x1

    const-string v9, "org.lighttouch.android.ResultRow (StoreScreen.kt:400)"

    invoke-static {v0, v10, v5, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_c
    const v0, -0x46556a3

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "402@23333L455"

    invoke-static {v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 402
    const-string v0, "ghost"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    const-string v9, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    const v11, 0x2952b718

    const/high16 v12, 0x3f000000    # 0.5f

    const/4 v13, 0x0

    const-string v14, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    const/16 p3, 0x4

    const-string v7, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    const/16 v16, 0x2

    const v8, -0x4ee9b9da

    const/4 v15, 0x0

    const/16 v19, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_17

    .line 403
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    invoke-static {v0, v13, v5, v15}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {v0, v12}, Landroidx/compose/ui/draw/AlphaKt;->alpha(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v5, 0x8

    .local v5, "$this$dp\\1":I
    const/4 v12, 0x0

    .line 925
    .local v12, "$i$f$getDp\\1\\403":I
    int-to-float v13, v5

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 403
    .end local v5    # "$this$dp\\1":I
    .end local v12    # "$i$f$getDp\\1\\403":I
    const/16 v12, 0x8

    .local v12, "$this$dp\\2":I
    const/4 v13, 0x0

    .line 925
    .local v13, "$i$f$getDp\\2\\403":I
    int-to-float v15, v12

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 403
    .end local v12    # "$this$dp\\2":I
    .end local v13    # "$i$f$getDp\\2\\403":I
    invoke-static {v0, v5, v12}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v12, 0x186

    .local v12, "$changed\\3":I
    const/4 v13, 0x0

    .line 926
    .local v13, "$i$f$Row\\3\\403":I
    invoke-static {v6, v11, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 927
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v9

    .line 931
    .local v9, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v11, v12, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v15, v12, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v11, v15

    invoke-static {v9, v5, v6, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v12, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 932
    nop

    .local v15, "$changed\\4":I
    const/16 v16, 0x0

    .line 933
    .local v16, "$i$f$Layout\\4\\932":I
    invoke-static {v6, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 934
    const/4 v8, 0x0

    invoke-static {v6, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v21

    .line 935
    .local v21, "compositeKeyHash\\4":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 936
    .local v8, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 938
    .local v2, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v22

    move-object/from16 p3, v0

    .end local v0    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local p3, "modifier\\3":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v15, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 937
    nop

    .local v0, "$changed\\5":I
    move-object/from16 v23, v22

    .local v23, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v22, 0x0

    .line 939
    .local v22, "$i$f$ReusableComposeNode\\5\\937":I
    move/from16 v24, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\5":I
    .local v24, "$changed\\5":I
    invoke-static {v6, v0, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 940
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 941
    :cond_d
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 942
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 943
    move-object/from16 v0, v23

    .end local v23    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_8

    .line 945
    .end local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v23    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_e
    move-object/from16 v0, v23

    .end local v23    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 947
    :goto_8
    move-object/from16 v23, v0

    .end local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v23    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 948
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\947\\4":I
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v27, v3

    .end local v3    # "rank":Ljava/lang/Integer;
    .local v27, "rank":Ljava/lang/Integer;
    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v0, v11, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 949
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v0, v8, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 951
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v26, 0x0

    .line 952
    .local v26, "$i$f$set-impl\\7\\951":I
    move-object/from16 v28, v0

    .local v28, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 953
    .local v29, "$i$a$-with-Updater$set$1\\8\\952\\7":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_10

    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v30, v5

    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v30, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_f

    goto :goto_9

    :cond_f
    move-object/from16 v5, v28

    goto :goto_a

    .end local v30    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    :cond_10
    move-object/from16 v30, v5

    .line 954
    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v30    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    :goto_9
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v28

    .end local v28    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 955
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v0, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 957
    :goto_a
    nop

    .line 952
    .end local v5    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-with-Updater$set$1\\8\\952\\7":I
    nop

    .line 957
    nop

    .line 958
    .end local v3    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v26    # "$i$f$set-impl\\7\\951":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v0, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 959
    nop

    .line 947
    .end local v0    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\947\\4":I
    nop

    .line 960
    shr-int/lit8 v0, v24, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v3, v6

    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 961
    .local v4, "$i$a$-Layout-RowKt$Row$1\\9\\960\\3":I
    const-string v5, "C101@5126L9:Row.kt#2w3rfo"

    move/from16 v25, v0

    const v0, -0x184f2606

    .end local v0    # "$changed\\9":I
    .local v25, "$changed\\9":I
    invoke-static {v3, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v12, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$ResultRow_u24lambda_u2445\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 p2, v3

    .local p2, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 404
    .local v26, "$i$a$-Row-StoreScreenKt$ResultRow$1\\10\\961\\0":I
    move-object/from16 v28, v0

    .end local v0    # "$this$ResultRow_u24lambda_u2445\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v28, "$this$ResultRow_u24lambda_u2445\\10":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x58b348a0

    move-object/from16 v29, v2

    .end local v2    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v29, "materialized\\4":Landroidx/compose/ui/Modifier;
    const-string v2, "C403@23480L298:StoreScreen.kt#o13vsk"

    move-object/from16 v31, v3

    .end local p2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v31, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "$changed\\11":I
    const/4 v2, 0x0

    .line 962
    .local v2, "$i$f$Column\\11\\404":I
    move/from16 p2, v0

    .end local v0    # "$changed\\11":I
    .local p2, "$changed\\11":I
    const v0, -0x1cd0f17e

    move/from16 v32, v2

    .end local v2    # "$i$f$Column\\11\\404":I
    .local v32, "$i$f$Column\\11\\404":I
    const-string v2, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 963
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 964
    .local v0, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v2

    .line 965
    .local v2, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v33, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v34, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\9\\960\\3":I
    .local v34, "$i$a$-Layout-RowKt$Row$1\\9\\960\\3":I
    invoke-virtual/range {v33 .. v33}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 968
    .local v4, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v33, p2, 0x3

    and-int/lit8 v33, v33, 0xe

    shr-int/lit8 v35, p2, 0x3

    and-int/lit8 v35, v35, 0x70

    move/from16 v36, v5

    .end local v5    # "$changed\\10":I
    .local v36, "$changed\\10":I
    or-int v5, v33, v35

    invoke-static {v2, v4, v3, v5}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .local v5, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v33, p2, 0x3

    and-int/lit8 v33, v33, 0x70

    .line 969
    nop

    .local v33, "$changed\\12":I
    const/16 v35, 0x0

    .line 970
    .local v35, "$i$f$Layout\\12\\969":I
    move-object/from16 v37, v2

    const v2, -0x4ee9b9da

    .end local v2    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v37, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v3, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 971
    const/4 v2, 0x0

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v2

    .line 972
    .local v2, "compositeKeyHash\\12":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 973
    .local v7, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v18, v2

    .end local v2    # "compositeKeyHash\\12":I
    .local v18, "compositeKeyHash\\12":I
    invoke-static {v3, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 975
    .local v2, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move-object/from16 v38, v0

    .end local v0    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v38, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v33, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 974
    nop

    .local v0, "$changed\\13":I
    move-object/from16 v39, v20

    .local v39, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 976
    .local v20, "$i$f$ReusableComposeNode\\13\\974":I
    move/from16 v40, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\13":I
    .local v40, "$changed\\13":I
    invoke-static {v3, v0, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 977
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 978
    :cond_11
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 979
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_12

    .line 980
    move-object/from16 v0, v39

    .end local v39    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b

    .line 982
    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v39    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v0, v39

    .end local v39    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 984
    :goto_b
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 985
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\984\\12":I
    sget-object v39, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v41, v0

    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v41, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v14, v5, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 986
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v14, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 988
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v39, 0x0

    .line 989
    .local v39, "$i$f$set-impl\\15\\988":I
    move-object/from16 v42, v14

    .local v42, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 990
    .local v43, "$i$a$-with-Updater$set$1\\16\\989\\15":I
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_14

    move-object/from16 v44, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v45, v4

    .end local v4    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .local v45, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_13

    goto :goto_c

    :cond_13
    move-object/from16 v4, v42

    goto :goto_d

    .end local v44    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v45    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v4    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_14
    move-object/from16 v44, v3

    move-object/from16 v45, v4

    .line 991
    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v4    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v44    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v45    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    :goto_c
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v42

    .end local v42    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 992
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v14, v3, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 994
    :goto_d
    nop

    .line 989
    .end local v4    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\16\\989\\15":I
    nop

    .line 994
    nop

    .line 995
    .end local v0    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v39    # "$i$f$set-impl\\15\\988":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v14, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 996
    nop

    .line 984
    .end local v14    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\984\\12":I
    nop

    .line 997
    shr-int/lit8 v0, v40, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\17":I
    move-object/from16 v3, v44

    .local v3, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 998
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\17\\997\\11":I
    const v14, -0x16ef5699

    move/from16 v17, v0

    .end local v0    # "$changed\\17":I
    .local v17, "$changed\\17":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v3, v14, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v14, p2, 0x6

    and-int/lit8 v14, v14, 0x70

    or-int/lit8 v14, v14, 0x6

    .local v14, "$changed\\18":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$ResultRow_u24lambda_u2445_u24lambda_u2444\\18":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v67, v3

    .local v67, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 405
    .local v19, "$i$a$-Column-StoreScreenKt$ResultRow$1$1\\18\\998\\10":I
    move-object/from16 v39, v0

    .end local v0    # "$this$ResultRow_u24lambda_u2445_u24lambda_u2444\\18":Landroidx/compose/foundation/layout/ColumnScope;
    .local v39, "$this$ResultRow_u24lambda_u2445_u24lambda_u2444\\18":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x36034c71

    move-object/from16 v42, v2

    .end local v2    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .local v42, "materialized\\12":Landroidx/compose/ui/Modifier;
    const-string v2, "C404@23603L10,404@23505L120,405@23691L10,405@23735L11,405@23642L122:StoreScreen.kt#o13vsk"

    move-object/from16 v43, v3

    .end local v67    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v0, "name"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "optString(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v61

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v46, v0

    sget v0, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v0}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v66

    const/16 v69, 0xc30

    const v70, 0xd7fe

    const/16 v47, 0x0

    const-wide/16 v48, 0x0

    const-wide/16 v50, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const-wide/16 v55, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const-wide/16 v59, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x1

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v68, 0x0

    .end local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v67    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v70}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 406
    .end local v67    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v66

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v48

    const/16 v69, 0x0

    const v70, 0xfffa

    const-string v46, "\u4e0d\u5728\u5b58\u6863\u4e2d"

    const/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v68, 0x6

    .end local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v67    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v70}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 405
    .end local v67    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 407
    nop

    .line 998
    .end local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v14    # "$changed\\18":I
    .end local v19    # "$i$a$-Column-StoreScreenKt$ResultRow$1$1\\18\\998\\10":I
    .end local v39    # "$this$ResultRow_u24lambda_u2445_u24lambda_u2444\\18":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 997
    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\17\\997\\11":I
    .end local v17    # "$changed\\17":I
    .end local v43    # "$composer\\17":Landroidx/compose/runtime/Composer;
    nop

    .line 999
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 976
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1000
    nop

    .line 970
    .end local v20    # "$i$f$ReusableComposeNode\\13\\974":I
    .end local v40    # "$changed\\13":I
    .end local v41    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1001
    nop

    .line 962
    .end local v7    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v18    # "compositeKeyHash\\12":I
    .end local v33    # "$changed\\12":I
    .end local v35    # "$i$f$Layout\\12\\969":I
    .end local v42    # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1002
    nop

    .line 404
    .end local v5    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v32    # "$i$f$Column\\11\\404":I
    .end local v37    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v38    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v45    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .end local p2    # "$changed\\11":I
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 408
    nop

    .line 961
    .end local v26    # "$i$a$-Row-StoreScreenKt$ResultRow$1\\10\\961\\0":I
    .end local v28    # "$this$ResultRow_u24lambda_u2445\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v36    # "$changed\\10":I
    .end local v44    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 960
    .end local v25    # "$changed\\9":I
    .end local v31    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-Layout-RowKt$Row$1\\9\\960\\3":I
    nop

    .line 1003
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 939
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1004
    nop

    .line 933
    .end local v22    # "$i$f$ReusableComposeNode\\5\\937":I
    .end local v23    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v24    # "$changed\\5":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1005
    nop

    .line 926
    .end local v8    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "$changed\\4":I
    .end local v16    # "$i$f$Layout\\4\\932":I
    .end local v21    # "compositeKeyHash\\4":I
    .end local v29    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1006
    nop

    .end local v9    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v11    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v12    # "$changed\\3":I
    .end local v13    # "$i$f$Row\\3\\403":I
    .end local v30    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local p3    # "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_15
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_16

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda9;

    move-object/from16 v2, p1

    move/from16 v4, p4

    move/from16 v5, p5

    move-object/from16 v3, v27

    .end local v27    # "rank":Ljava/lang/Integer;
    .local v3, "rank":Ljava/lang/Integer;
    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda9;-><init>(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;II)V

    .end local v3    # "rank":Ljava/lang/Integer;
    .restart local v27    # "rank":Ljava/lang/Integer;
    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_e

    :cond_16
    move-object/from16 v2, p1

    .line 409
    :goto_e
    return-void

    .end local v27    # "rank":Ljava/lang/Integer;
    .restart local v3    # "rank":Ljava/lang/Integer;
    :cond_17
    move-object/from16 v27, v3

    .end local v3    # "rank":Ljava/lang/Integer;
    .restart local v27    # "rank":Ljava/lang/Integer;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 411
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v0, v1}, Lorg/lighttouch/android/LegacyStore;->incompatibility(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v28

    .line 412
    .local v28, "problem":Ljava/lang/String;
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getInstalled()Ljava/util/Map;

    move-result-object v0

    const-string v3, "bundle_id"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 413
    .local v0, "installedVersion":Ljava/lang/String;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    invoke-static {v3, v13, v5, v15}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v4, 0x10

    .local v4, "$this$dp\\19":I
    const/4 v8, 0x0

    .line 1007
    .local v8, "$i$f$getDp\\19\\413":I
    int-to-float v13, v4

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 413
    .end local v4    # "$this$dp\\19":I
    .end local v8    # "$i$f$getDp\\19\\413":I
    invoke-static {v4}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v4

    check-cast v4, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v4}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    const v3, -0x615d173a

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    .local v3, "invalid\\20":Z
    move-object v4, v6

    .local v4, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1008
    .local v8, "$i$f$cache\\20\\413":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\20":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 1009
    .local v21, "$i$a$-let-ComposerKt$cache$1\\21\\1008\\20":I
    if-nez v3, :cond_19

    sget-object v22, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v13, v12, :cond_18

    goto :goto_f

    .line 1013
    :cond_18
    move-object v15, v13

    goto :goto_10

    .line 1010
    :cond_19
    :goto_f
    const/4 v12, 0x0

    .line 413
    .local v12, "$i$a$-cache-StoreScreenKt$ResultRow$3\\22\\1010\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v15, v2, v1}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda10;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)V

    .line 1010
    .end local v12    # "$i$a$-cache-StoreScreenKt$ResultRow$3\\22\\1010\\0":I
    nop

    .line 1011
    .local v15, "value\\21":Ljava/lang/Object;
    invoke-interface {v4, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1012
    nop

    .line 1009
    .end local v15    # "value\\21":Ljava/lang/Object;
    :goto_10
    nop

    .line 1008
    .end local v13    # "it\\20":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\21\\1008\\20":I
    nop

    .line 413
    .end local v3    # "invalid\\20":Z
    .end local v4    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\20\\413":I
    move-object/from16 v33, v15

    check-cast v33, Lkotlin/jvm/functions/Function0;

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v34, 0x7

    const/16 v35, 0x0

    const/16 v30, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    invoke-static/range {v29 .. v35}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v4, 0x8

    .local v4, "$this$dp\\23":I
    const/4 v8, 0x0

    .line 1007
    .local v8, "$i$f$getDp\\23\\413":I
    int-to-float v12, v4

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 413
    .end local v4    # "$this$dp\\23":I
    .end local v8    # "$i$f$getDp\\23\\413":I
    const/16 v8, 0x8

    .local v8, "$this$dp\\24":I
    const/4 v12, 0x0

    .line 1007
    .local v12, "$i$f$getDp\\24\\413":I
    int-to-float v13, v8

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 413
    .end local v8    # "$this$dp\\24":I
    .end local v12    # "$i$f$getDp\\24\\413":I
    invoke-static {v3, v4, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 414
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v4

    .line 413
    const/16 v8, 0x180

    .local v3, "modifier\\25":Landroidx/compose/ui/Modifier;
    .local v4, "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .local v8, "$changed\\25":I
    const/4 v12, 0x0

    .line 1014
    .local v12, "$i$f$Row\\25\\413":I
    invoke-static {v6, v11, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1015
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v9

    .line 1019
    .local v9, "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v11, v8, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v13, v8, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v11, v13

    invoke-static {v9, v4, v6, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v8, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 1020
    nop

    .local v13, "$changed\\26":I
    const/4 v15, 0x0

    .line 1021
    .local v15, "$i$f$Layout\\26\\1020":I
    move/from16 v21, v5

    const v5, -0x4ee9b9da

    invoke-static {v6, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1022
    const/4 v5, 0x0

    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v24

    .line 1023
    .local v24, "compositeKeyHash\\26":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 1024
    .local v5, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v25, v4

    .end local v4    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .local v25, "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v6, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 1026
    .local v4, "materialized\\26":Landroidx/compose/ui/Modifier;
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v26

    move-object/from16 v53, v3

    .end local v3    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .local v53, "modifier\\25":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v13, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 1025
    nop

    .local v3, "$changed\\27":I
    move-object/from16 v54, v26

    .local v54, "factory\\27":Lkotlin/jvm/functions/Function0;
    const/16 v26, 0x0

    .line 1027
    .local v26, "$i$f$ReusableComposeNode\\27\\1025":I
    move/from16 v55, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\27":I
    .local v55, "$changed\\27":I
    invoke-static {v6, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1028
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_1a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1029
    :cond_1a
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1030
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_1b

    .line 1031
    move-object/from16 v3, v54

    .end local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_11

    .line 1033
    .end local v3    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    :cond_1b
    move-object/from16 v3, v54

    .end local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1035
    :goto_11
    move-object/from16 v54, v3

    .end local v3    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 1036
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\1035\\26":I
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v56, v6

    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .local v56, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v11, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1037
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v5, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1039
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\29":Lkotlin/jvm/functions/Function2;
    const/16 v30, 0x0

    .line 1040
    .local v30, "$i$f$set-impl\\29\\1039":I
    move-object/from16 v31, v3

    .local v31, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 1041
    .local v32, "$i$a$-with-Updater$set$1\\30\\1040\\29":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v33

    if-nez v33, :cond_1d

    move-object/from16 v57, v5

    .end local v5    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .local v57, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move/from16 v58, v8

    .end local v8    # "$changed\\25":I
    .local v58, "$changed\\25":I
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1c

    goto :goto_12

    :cond_1c
    move-object/from16 v8, v31

    goto :goto_13

    .end local v57    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v58    # "$changed\\25":I
    .restart local v5    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "$changed\\25":I
    :cond_1d
    move-object/from16 v57, v5

    move/from16 v58, v8

    .line 1042
    .end local v5    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8    # "$changed\\25":I
    .restart local v57    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v58    # "$changed\\25":I
    :goto_12
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v8, v31

    .end local v31    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1043
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v3, v5, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1045
    :goto_13
    nop

    .line 1040
    .end local v8    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-with-Updater$set$1\\30\\1040\\29":I
    nop

    .line 1045
    nop

    .line 1046
    .end local v6    # "block\\29":Lkotlin/jvm/functions/Function2;
    .end local v30    # "$i$f$set-impl\\29\\1039":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v4, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1047
    nop

    .line 1035
    .end local v3    # "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\1035\\26":I
    nop

    .line 1048
    shr-int/lit8 v3, v55, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\31":I
    move-object/from16 v5, v56

    .local v5, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1049
    .local v6, "$i$a$-Layout-RowKt$Row$1\\31\\1048\\25":I
    const-string v8, "C101@5126L9:Row.kt#2w3rfo"

    move/from16 v59, v3

    const v3, -0x184f2606

    .end local v3    # "$changed\\31":I
    .local v59, "$changed\\31":I
    invoke-static {v5, v3, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v8, v58, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\32":I
    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    .local v3, "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v81, v5

    .local v81, "$composer\\32":Landroidx/compose/runtime/Composer;
    move-object/from16 v29, v3

    .end local v3    # "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    .local v29, "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    const/4 v3, 0x0

    .line 415
    .local v3, "$i$a$-Row-StoreScreenKt$ResultRow$4\\32\\1049\\0":I
    move/from16 p2, v3

    .end local v3    # "$i$a$-Row-StoreScreenKt$ResultRow$4\\32\\1049\\0":I
    .local p2, "$i$a$-Row-StoreScreenKt$ResultRow$4\\32\\1049\\0":I
    const v3, -0x2df69d80

    move-object/from16 v85, v4

    .end local v4    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .local v85, "materialized\\26":Landroidx/compose/ui/Modifier;
    const-string v4, "C415@24307L114,416@24430L29,417@24468L1434:StoreScreen.kt#o13vsk"

    move-object/from16 v86, v5

    .end local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v86, "$composer\\31":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v3, -0x4bce2ba7

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*414@24214L10,414@24149L117,414@24268L28"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v27, :cond_1e

    move/from16 v87, v6

    goto/16 :goto_14

    :cond_1e
    move-object/from16 v3, v27

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 587
    .local v3, "it\\33":I
    const/4 v4, 0x0

    .line 415
    .local v4, "$i$a$-let-StoreScreenKt$ResultRow$4$1\\33\\415\\32":I
    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v60

    sget-object v30, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move/from16 v31, v3

    .end local v3    # "it\\33":I
    .local v31, "it\\33":I
    move-object/from16 v3, v30

    check-cast v3, Landroidx/compose/ui/Modifier;

    move/from16 v30, v4

    .end local v4    # "$i$a$-let-StoreScreenKt$ResultRow$4$1\\33\\415\\32":I
    .local v30, "$i$a$-let-StoreScreenKt$ResultRow$4$1\\33\\415\\32":I
    const/16 v4, 0x20

    .local v4, "$this$dp\\34":I
    const/16 v32, 0x0

    .line 1050
    .local v32, "$i$f$getDp\\34\\415":I
    move/from16 v87, v6

    .end local v6    # "$i$a$-Layout-RowKt$Row$1\\31\\1048\\25":I
    .local v87, "$i$a$-Layout-RowKt$Row$1\\31\\1048\\25":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 415
    .end local v4    # "$this$dp\\34":I
    .end local v32    # "$i$f$getDp\\34\\415":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v61

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v80

    sget-object v3, Landroidx/compose/ui/text/style/TextAlign;->Companion:Landroidx/compose/ui/text/style/TextAlign$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextAlign$Companion;->getCenter-e0LSkKk()I

    move-result v3

    invoke-static {v3}, Landroidx/compose/ui/text/style/TextAlign;->box-impl(I)Landroidx/compose/ui/text/style/TextAlign;

    move-result-object v72

    const/16 v83, 0x0

    const v84, 0xfdfc

    const-wide/16 v62, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const/16 v71, 0x0

    const-wide/16 v73, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v82, 0x30

    move-object/from16 v81, v5

    .end local v5    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v84}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\32":Landroidx/compose/runtime/Composer;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\35":I
    const/4 v6, 0x0

    .line 1050
    .local v6, "$i$f$getDp\\35\\415":I
    move/from16 v32, v6

    .end local v6    # "$i$f$getDp\\35\\415":I
    .local v32, "$i$f$getDp\\35\\415":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 415
    .end local v4    # "$this$dp\\35":I
    .end local v32    # "$i$f$getDp\\35\\415":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v4, v19

    invoke-static {v3, v5, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .end local v30    # "$i$a$-let-StoreScreenKt$ResultRow$4$1\\33\\415\\32":I
    .end local v31    # "it\\33":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_14
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 416
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    if-nez v28, :cond_1f

    const/high16 v4, 0x3f800000    # 1.0f

    goto :goto_15

    :cond_1f
    const/high16 v4, 0x3f000000    # 0.5f

    :goto_15
    invoke-static {v3, v4}, Landroidx/compose/ui/draw/AlphaKt;->alpha(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\36":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x0

    .local v4, "$changed\\36":I
    const/4 v6, 0x0

    .line 1051
    .local v6, "$i$f$Box\\36\\416":I
    move/from16 v23, v4

    .end local v4    # "$changed\\36":I
    .local v23, "$changed\\36":I
    const v4, 0x2bb5b5d7

    move/from16 v30, v6

    .end local v6    # "$i$f$Box\\36\\416":I
    .local v30, "$i$f$Box\\36\\416":I
    const-string v6, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v5, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1052
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 1053
    .local v4, "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    const/4 v6, 0x0

    .line 1056
    .local v6, "propagateMinConstraints\\36":Z
    move/from16 v60, v8

    .end local v8    # "$changed\\32":I
    .local v60, "$changed\\32":I
    invoke-static {v4, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v31, v23, 0x3

    and-int/lit8 v31, v31, 0x70

    .line 1057
    nop

    .local v31, "$changed\\37":I
    const/16 v32, 0x0

    .line 1058
    .local v32, "$i$f$Layout\\37\\1057":I
    move-object/from16 v33, v4

    const v4, -0x4ee9b9da

    .end local v4    # "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    .local v33, "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1059
    const/4 v4, 0x0

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v34

    .line 1060
    .local v34, "compositeKeyHash\\37":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 1061
    .local v4, "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v35, v6

    .end local v6    # "propagateMinConstraints\\36":Z
    .local v35, "propagateMinConstraints\\36":Z
    invoke-static {v5, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 1063
    .local v6, "materialized\\37":Landroidx/compose/ui/Modifier;
    sget-object v36, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v36

    move-object/from16 v37, v3

    .end local v3    # "modifier\\36":Landroidx/compose/ui/Modifier;
    .local v37, "modifier\\36":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v31, 0x6

    and-int/lit16 v3, v3, 0x380

    const/16 v19, 0x6

    or-int/lit8 v3, v3, 0x6

    .line 1062
    move-object/from16 v38, v36

    .local v3, "$changed\\38":I
    .local v38, "factory\\38":Lkotlin/jvm/functions/Function0;
    const/16 v36, 0x0

    .line 1064
    .local v36, "$i$f$ReusableComposeNode\\38\\1062":I
    move/from16 v39, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\38":I
    .local v39, "$changed\\38":I
    invoke-static {v5, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1065
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_20

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1066
    :cond_20
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1067
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_21

    .line 1068
    move-object/from16 v3, v38

    .end local v38    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_16

    .line 1070
    .end local v3    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v38    # "factory\\38":Lkotlin/jvm/functions/Function0;
    :cond_21
    move-object/from16 v3, v38

    .end local v38    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1072
    :goto_16
    move-object/from16 v38, v3

    .end local v3    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v38    # "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    const/16 v40, 0x0

    .line 1073
    .local v40, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\39\\1072\\37":I
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v61, v9

    .end local v9    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v61, "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1074
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v3, v4, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1076
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .local v9, "block\\40":Lkotlin/jvm/functions/Function2;
    const/16 v41, 0x0

    .line 1077
    .local v41, "$i$f$set-impl\\40\\1076":I
    move-object/from16 v42, v3

    .local v42, "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 1078
    .local v43, "$i$a$-with-Updater$set$1\\41\\1077\\40":I
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_23

    move-object/from16 v44, v4

    .end local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .local v44, "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v45, v8

    .end local v8    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v45, "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v4, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_22

    goto :goto_17

    :cond_22
    move-object/from16 v8, v42

    goto :goto_18

    .end local v44    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v45    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_23
    move-object/from16 v44, v4

    move-object/from16 v45, v8

    .line 1079
    .end local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v44    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v45    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_17
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v8, v42

    .end local v42    # "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1080
    invoke-static/range {v34 .. v34}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1082
    :goto_18
    nop

    .line 1077
    .end local v8    # "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\41\\1077\\40":I
    nop

    .line 1082
    nop

    .line 1083
    .end local v9    # "block\\40":Lkotlin/jvm/functions/Function2;
    .end local v41    # "$i$f$set-impl\\40\\1076":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v3, v6, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1084
    nop

    .line 1072
    .end local v3    # "$this$Layout_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .end local v40    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\39\\1072\\37":I
    nop

    .line 1085
    shr-int/lit8 v3, v39, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\42":I
    move-object v4, v5

    .local v4, "$composer\\42":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1086
    .local v8, "$i$a$-Layout-BoxKt$Box$1\\42\\1085\\36":I
    const v9, -0x7ff519f7    # -1.000876E-39f

    move/from16 v40, v3

    .end local v3    # "$changed\\42":I
    .local v40, "$changed\\42":I
    const-string v3, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v4, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v9, v23, 0x6

    and-int/lit8 v9, v9, 0x70

    const/16 v19, 0x6

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\43":I
    check-cast v3, Landroidx/compose/foundation/layout/BoxScope;

    .local v3, "$this$ResultRow_u24lambda_u2457_u24lambda_u2451\\43":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v49, v4

    .local v49, "$composer\\43":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 416
    .local v41, "$i$a$-Box-StoreScreenKt$ResultRow$4$2\\43\\1086\\32":I
    move-object/from16 v42, v3

    .end local v3    # "$this$ResultRow_u24lambda_u2457_u24lambda_u2451\\43":Landroidx/compose/foundation/layout/BoxScope;
    .local v42, "$this$ResultRow_u24lambda_u2457_u24lambda_u2451\\43":Landroidx/compose/foundation/layout/BoxScope;
    const v3, 0x455e75a8

    move-object/from16 v43, v4

    .end local v4    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .local v43, "$composer\\42":Landroidx/compose/runtime/Composer;
    const-string v4, "C415@24364L55:StoreScreen.kt#o13vsk"

    move-object/from16 v52, v6

    move-object/from16 v6, v49

    .end local v49    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v52, "materialized\\37":Landroidx/compose/ui/Modifier;
    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v3, "icon_url"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_24

    move/from16 v4, v21

    goto :goto_19

    :cond_24
    const/4 v4, 0x0

    :goto_19
    if-eqz v4, :cond_25

    .line 587
    const/4 v3, 0x0

    .line 416
    .local v3, "$i$a$-ifEmpty-StoreScreenKt$ResultRow$4$2$1\\44\\416\\43":I
    const/4 v3, 0x0

    .end local v3    # "$i$a$-ifEmpty-StoreScreenKt$ResultRow$4$2$1\\44\\416\\43":I
    :cond_25
    move-object/from16 v46, v3

    check-cast v46, Ljava/lang/String;

    const/16 v50, 0x30

    const/16 v51, 0x4

    const/16 v47, 0x34

    const/16 v48, 0x0

    move-object/from16 v49, v6

    .end local v6    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v49    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v51}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1086
    .end local v9    # "$changed\\43":I
    .end local v41    # "$i$a$-Box-StoreScreenKt$ResultRow$4$2\\43\\1086\\32":I
    .end local v42    # "$this$ResultRow_u24lambda_u2457_u24lambda_u2451\\43":Landroidx/compose/foundation/layout/BoxScope;
    .end local v49    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static/range {v43 .. v43}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1085
    .end local v8    # "$i$a$-Layout-BoxKt$Box$1\\42\\1085\\36":I
    .end local v40    # "$changed\\42":I
    .end local v43    # "$composer\\42":Landroidx/compose/runtime/Composer;
    nop

    .line 1087
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1064
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1088
    nop

    .line 1058
    .end local v36    # "$i$f$ReusableComposeNode\\38\\1062":I
    .end local v38    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .end local v39    # "$changed\\38":I
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1089
    nop

    .line 1051
    .end local v31    # "$changed\\37":I
    .end local v32    # "$i$f$Layout\\37\\1057":I
    .end local v34    # "compositeKeyHash\\37":I
    .end local v44    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v52    # "materialized\\37":Landroidx/compose/ui/Modifier;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1090
    nop

    .line 417
    .end local v23    # "$changed\\36":I
    .end local v30    # "$i$f$Box\\36\\416":I
    .end local v33    # "contentAlignment\\36":Landroidx/compose/ui/Alignment;
    .end local v35    # "propagateMinConstraints\\36":Z
    .end local v37    # "modifier\\36":Landroidx/compose/ui/Modifier;
    .end local v45    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xe

    .local v4, "$this$dp\\45":I
    const/4 v6, 0x0

    .line 1091
    .local v6, "$i$f$getDp\\45\\417":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 417
    .end local v4    # "$this$dp\\45":I
    .end local v6    # "$i$f$getDp\\45\\417":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v4, 0x6

    invoke-static {v3, v5, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 418
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v30, v3

    check-cast v30, Landroidx/compose/ui/Modifier;

    const/16 v33, 0x2

    const/16 v34, 0x0

    const/high16 v31, 0x3f800000    # 1.0f

    const/16 v32, 0x0

    invoke-static/range {v29 .. v34}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move-object/from16 v4, v29

    .end local v29    # "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    .local v3, "modifier\\46":Landroidx/compose/ui/Modifier;
    .local v4, "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    const/4 v6, 0x0

    .local v6, "$changed\\46":I
    const/4 v8, 0x0

    .line 1092
    .local v8, "$i$f$Column\\46\\418":I
    const v9, -0x1cd0f17e

    move-object/from16 v23, v4

    .end local v4    # "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    .local v23, "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    const-string v4, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v5, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1093
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 1094
    .local v4, "verticalArrangement\\46":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 1097
    .local v9, "horizontalAlignment\\46":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v29, v6, 0x3

    and-int/lit8 v29, v29, 0xe

    shr-int/lit8 v30, v6, 0x3

    and-int/lit8 v30, v30, 0x70

    move/from16 v62, v6

    .end local v6    # "$changed\\46":I
    .local v62, "$changed\\46":I
    or-int v6, v29, v30

    invoke-static {v4, v9, v5, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .local v6, "measurePolicy\\46":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v29, v62, 0x3

    and-int/lit8 v29, v29, 0x70

    .line 1098
    move/from16 v63, v29

    .local v63, "$changed\\47":I
    const/16 v64, 0x0

    .line 1099
    .local v64, "$i$f$Layout\\47\\1098":I
    move-object/from16 v65, v4

    const v4, -0x4ee9b9da

    .end local v4    # "verticalArrangement\\46":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v65, "verticalArrangement\\46":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1100
    const/4 v4, 0x0

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v7

    .line 1101
    .local v7, "compositeKeyHash\\47":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 1102
    .local v4, "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v20, v7

    .end local v7    # "compositeKeyHash\\47":I
    .local v20, "compositeKeyHash\\47":I
    invoke-static {v5, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 1104
    .local v7, "materialized\\47":Landroidx/compose/ui/Modifier;
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v29

    move-object/from16 v66, v3

    .end local v3    # "modifier\\46":Landroidx/compose/ui/Modifier;
    .local v66, "modifier\\46":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v63, 0x6

    and-int/lit16 v3, v3, 0x380

    const/16 v19, 0x6

    or-int/lit8 v3, v3, 0x6

    .line 1103
    move-object/from16 v67, v29

    .local v3, "$changed\\48":I
    .local v67, "factory\\48":Lkotlin/jvm/functions/Function0;
    const/16 v68, 0x0

    .line 1105
    .local v68, "$i$f$ReusableComposeNode\\48\\1103":I
    move/from16 v69, v3

    const v3, -0x2942ffcf

    .end local v3    # "$changed\\48":I
    .local v69, "$changed\\48":I
    invoke-static {v5, v3, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1106
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_26

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1107
    :cond_26
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1108
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_27

    .line 1109
    move-object/from16 v3, v67

    .end local v67    # "factory\\48":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\48":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1a

    .line 1111
    .end local v3    # "factory\\48":Lkotlin/jvm/functions/Function0;
    .restart local v67    # "factory\\48":Lkotlin/jvm/functions/Function0;
    :cond_27
    move-object/from16 v3, v67

    .end local v67    # "factory\\48":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\48":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1113
    :goto_1a
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\49":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 1114
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\49\\1113\\47":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v67, v3

    .end local v3    # "factory\\48":Lkotlin/jvm/functions/Function0;
    .restart local v67    # "factory\\48":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v14, v6, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1115
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v14, v4, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1117
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\50":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 1118
    .local v29, "$i$f$set-impl\\50\\1117":I
    move-object/from16 v30, v14

    .local v30, "$this$set_impl_u24lambda_u240\\50":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 1119
    .local v31, "$i$a$-with-Updater$set$1\\51\\1118\\50":I
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v32

    if-nez v32, :cond_29

    move-object/from16 v70, v4

    .end local v4    # "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    .local v70, "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v30 .. v30}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v81, v5

    .end local v5    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_28

    goto :goto_1b

    :cond_28
    move-object/from16 v5, v30

    goto :goto_1c

    .end local v70    # "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v4    # "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "$composer\\32":Landroidx/compose/runtime/Composer;
    :cond_29
    move-object/from16 v70, v4

    move-object/from16 v81, v5

    .line 1120
    .end local v4    # "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v70    # "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    :goto_1b
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v30

    .end local v30    # "$this$set_impl_u24lambda_u240\\50":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\50":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1121
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v14, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1123
    :goto_1c
    nop

    .line 1118
    .end local v5    # "$this$set_impl_u24lambda_u240\\50":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-with-Updater$set$1\\51\\1118\\50":I
    nop

    .line 1123
    nop

    .line 1124
    .end local v3    # "block\\50":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\50\\1117":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v14, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1125
    nop

    .line 1113
    .end local v14    # "$this$Layout_u24lambda_u240\\49":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\49\\1113\\47":I
    nop

    .line 1126
    shr-int/lit8 v3, v69, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\52":I
    move-object/from16 v4, v81

    .local v4, "$composer\\52":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 1127
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\52\\1126\\46":I
    const v14, -0x16ef5699

    move/from16 v17, v3

    .end local v3    # "$changed\\52":I
    .local v17, "$changed\\52":I
    const-string v3, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v14, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v14, v62, 0x6

    and-int/lit8 v14, v14, 0x70

    const/16 v19, 0x6

    or-int/lit8 v14, v14, 0x6

    .local v14, "$changed\\53":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$ResultRow_u24lambda_u2457_u24lambda_u2456\\53":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v109, v4

    .local v109, "$composer\\53":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 419
    .local v19, "$i$a$-Column-StoreScreenKt$ResultRow$4$3\\53\\1127\\32":I
    move-object/from16 v71, v3

    .end local v3    # "$this$ResultRow_u24lambda_u2457_u24lambda_u2456\\53":Landroidx/compose/foundation/layout/ColumnScope;
    .local v71, "$this$ResultRow_u24lambda_u2457_u24lambda_u2456\\53":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, -0x3d8fbd97

    move-object/from16 v72, v4

    .end local v4    # "$composer\\52":Landroidx/compose/runtime/Composer;
    .local v72, "$composer\\52":Landroidx/compose/runtime/Composer;
    const-string v4, "C418@24608L10,418@24510L232,423@25164L10,423@25208L11,420@24755L482:StoreScreen.kt#o13vsk"

    move/from16 v73, v5

    move-object/from16 v5, v109

    .end local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\53":Landroidx/compose/runtime/Composer;
    .local v73, "$i$a$-Layout-ColumnKt$Column$1\\52\\1126\\46":I
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v3, "name"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "optString(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v4, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v103

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v88, v3

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v5, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v108

    const v3, -0x65151a16

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "419@24713L11"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 420
    if-nez v28, :cond_2a

    sget-object v3, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/graphics/Color$Companion;->getUnspecified-0d7_KjU()J

    move-result-wide v3

    goto :goto_1d

    :cond_2a
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v3

    :goto_1d
    move-wide/from16 v90, v3

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 419
    nop

    .line 420
    nop

    .line 419
    const/16 v111, 0xc30

    const v112, 0xd7fa

    const/16 v89, 0x0

    const-wide/16 v92, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const-wide/16 v97, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const-wide/16 v101, 0x0

    const/16 v104, 0x0

    const/16 v105, 0x1

    const/16 v106, 0x0

    const/16 v107, 0x0

    const/16 v110, 0x0

    move-object/from16 v109, v5

    .end local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-static/range {v88 .. v112}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 421
    .end local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x5

    new-array v3, v3, [Ljava/lang/String;

    const-string v4, "developer"

    invoke-static {v1, v4}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v18, 0x0

    aput-object v4, v3, v18

    const-string v4, "version"

    invoke-static {v1, v4}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v21

    const-string v4, "label"

    invoke-static {v1, v4}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v3, v16

    .line 422
    const-string v4, "size"

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v29

    invoke-static/range {v29 .. v30}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    move-object/from16 v16, v4

    check-cast v16, Ljava/lang/Number;

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J

    move-result-wide v29

    .line 587
    nop

    .local v29, "it\\54":J
    const/16 v16, 0x0

    .line 422
    .local v16, "$i$a$-takeIf-StoreScreenKt$ResultRow$4$3$1\\54\\422\\53":I
    const-wide/16 v31, 0x0

    cmp-long v31, v29, v31

    if-lez v31, :cond_2b

    move/from16 v16, v21

    goto :goto_1e

    :cond_2b
    move/from16 v16, v18

    .end local v16    # "$i$a$-takeIf-StoreScreenKt$ResultRow$4$3$1\\54\\422\\53":I
    .end local v29    # "it\\54":J
    :goto_1e
    if-eqz v16, :cond_2c

    goto :goto_1f

    :cond_2c
    const/4 v4, 0x0

    :goto_1f
    if-eqz v4, :cond_2d

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v29

    .line 587
    nop

    .local v29, "p0\\55":J
    const/4 v4, 0x0

    .line 422
    .local v4, "$i$a$-let-StoreScreenKt$ResultRow$4$3$2\\55\\422\\53":I
    invoke-static/range {v29 .. v30}, Lorg/lighttouch/android/StoreScreenKt;->byteSize(J)Ljava/lang/String;

    move-result-object v4

    .end local v4    # "$i$a$-let-StoreScreenKt$ResultRow$4$3$2\\55\\422\\53":I
    .end local v29    # "p0\\55":J
    goto :goto_20

    :cond_2d
    const/4 v4, 0x0

    :goto_20
    const/16 v16, 0x3

    aput-object v4, v3, v16

    .line 421
    nop

    .line 423
    const-string v4, "version_count"

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v16, v4

    check-cast v16, Ljava/lang/Number;

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->intValue()I

    move-result v16

    .line 587
    nop

    .local v16, "it\\56":I
    const/16 v29, 0x0

    .line 423
    .local v29, "$i$a$-takeIf-StoreScreenKt$ResultRow$4$3$3\\56\\423\\53":I
    if-lez v16, :cond_2e

    move-object/from16 v30, v3

    const-string v3, "version"

    invoke-static {v1, v3}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2f

    move/from16 v18, v21

    goto :goto_21

    :cond_2e
    move-object/from16 v30, v3

    .end local v16    # "it\\56":I
    .end local v29    # "$i$a$-takeIf-StoreScreenKt$ResultRow$4$3$3\\56\\423\\53":I
    :cond_2f
    :goto_21
    if-eqz v18, :cond_30

    goto :goto_22

    :cond_30
    const/4 v4, 0x0

    :goto_22
    if-eqz v4, :cond_32

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v3

    .line 587
    nop

    .local v3, "it\\57":I
    const/4 v4, 0x0

    .line 423
    .local v4, "$i$a$-let-StoreScreenKt$ResultRow$4$3$4\\57\\423\\53":I
    move/from16 v16, v4

    move/from16 v4, v21

    .end local v4    # "$i$a$-let-StoreScreenKt$ResultRow$4$3$4\\57\\423\\53":I
    .local v16, "$i$a$-let-StoreScreenKt$ResultRow$4$3$4\\57\\423\\53":I
    if-ne v3, v4, :cond_31

    const-string v4, "1 \u4e2a\u7248\u672c"

    goto :goto_23

    :cond_31
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    move/from16 v18, v3

    .end local v3    # "it\\57":I
    .local v18, "it\\57":I
    const-string v3, " \u4e2a\u7248\u672c"

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_23

    .end local v16    # "$i$a$-let-StoreScreenKt$ResultRow$4$3$4\\57\\423\\53":I
    .end local v18    # "it\\57":I
    :cond_32
    const/4 v4, 0x0

    :goto_23
    aput-object v4, v30, p3

    .line 421
    invoke-static/range {v30 .. v30}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    move-object/from16 v29, v3

    check-cast v29, Ljava/lang/Iterable;

    .line 423
    const-string v3, " \u00b7 "

    move-object/from16 v30, v3

    check-cast v30, Ljava/lang/CharSequence;

    const/16 v36, 0x3e

    const/16 v37, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-static/range {v29 .. v37}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v88

    .line 424
    sget-object v3, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v103

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v108

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v90

    .line 423
    nop

    .line 424
    nop

    .line 421
    const/16 v89, 0x0

    const-wide/16 v92, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const-wide/16 v97, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const-wide/16 v101, 0x0

    const/16 v104, 0x0

    const/16 v105, 0x1

    const/16 v106, 0x0

    const/16 v107, 0x0

    const/16 v110, 0x0

    const/16 v111, 0xc30

    const v112, 0xd7fa

    move-object/from16 v109, v5

    .end local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-static/range {v88 .. v112}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 425
    .end local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-virtual {v2, v1}, Lorg/lighttouch/android/StoreModel;->queued(Lorg/json/JSONObject;)Lorg/lighttouch/android/QueueItem;

    move-result-object v3

    if-eqz v3, :cond_33

    move-object v4, v3

    .line 587
    .local v4, "it\\58":Lorg/lighttouch/android/QueueItem;
    const/16 v16, 0x0

    .line 425
    .local v16, "$i$a$-takeIf-StoreScreenKt$ResultRow$4$3$inQueue$1\\58\\425\\53":I
    invoke-virtual {v4}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v4

    .end local v4    # "it\\58":Lorg/lighttouch/android/QueueItem;
    .end local v16    # "$i$a$-takeIf-StoreScreenKt$ResultRow$4$3$inQueue$1\\58\\425\\53":I
    if-eqz v4, :cond_33

    move-object/from16 v22, v3

    goto :goto_24

    :cond_33
    const/16 v22, 0x0

    .line 426
    .local v22, "inQueue\\53":Lorg/lighttouch/android/QueueItem;
    :goto_24
    nop

    .line 427
    if-eqz v28, :cond_34

    const v3, -0x3d838162

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "426@25394L10,426@25438L11,426@25358L112"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v48

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v30

    const/16 v51, 0xc00

    const v52, 0xdffa

    const/16 v29, 0x0

    const-wide/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const-wide/16 v37, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const-wide/16 v41, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x2

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v50, 0x0

    move-object/from16 v49, v5

    .end local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v52}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v49    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_26

    .line 428
    :cond_34
    if-eqz v22, :cond_36

    const v3, -0x3d8138dd

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "427@25609L10,428@25675L11,427@25506L203"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {v22 .. v22}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v3

    sget-object v4, Lorg/lighttouch/android/QueueState;->PENDING:Lorg/lighttouch/android/QueueState;

    if-ne v3, v4, :cond_35

    const-string v3, "\u6392\u961f\u4e2d"

    goto :goto_25

    :cond_35
    invoke-virtual/range {v22 .. v22}, Lorg/lighttouch/android/QueueItem;->getPhase()Ljava/lang/String;

    move-result-object v3

    :goto_25
    move-object/from16 v88, v3

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v108

    .line 429
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v90

    .line 428
    nop

    .line 429
    nop

    .line 428
    const/16 v111, 0xc00

    const v112, 0xdffa

    const/16 v89, 0x0

    const-wide/16 v92, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const-wide/16 v97, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const-wide/16 v101, 0x0

    const/16 v103, 0x0

    const/16 v104, 0x0

    const/16 v105, 0x1

    const/16 v106, 0x0

    const/16 v107, 0x0

    const/16 v110, 0x0

    move-object/from16 v109, v5

    .end local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-static/range {v88 .. v112}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_26

    .line 430
    :cond_36
    if-eqz v0, :cond_37

    const v3, -0x3d7d816e

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "429@25812L10,429@25858L11,429@25754L124"

    invoke-static {v5, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u5df2\u5b89\u88c5 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v88

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v108

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v90

    const/16 v111, 0x0

    const v112, 0xfffa

    const/16 v89, 0x0

    const-wide/16 v92, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    const/16 v96, 0x0

    const-wide/16 v97, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const-wide/16 v101, 0x0

    const/16 v103, 0x0

    const/16 v104, 0x0

    const/16 v105, 0x0

    const/16 v106, 0x0

    const/16 v107, 0x0

    const/16 v110, 0x0

    move-object/from16 v109, v5

    .end local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-static/range {v88 .. v112}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v109    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_26

    .line 431
    :cond_37
    const v3, -0x3d7b79b2

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 419
    :goto_26
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 432
    .end local v22    # "inQueue\\53":Lorg/lighttouch/android/QueueItem;
    nop

    .line 1127
    .end local v5    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .end local v14    # "$changed\\53":I
    .end local v19    # "$i$a$-Column-StoreScreenKt$ResultRow$4$3\\53\\1127\\32":I
    .end local v71    # "$this$ResultRow_u24lambda_u2457_u24lambda_u2456\\53":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1126
    .end local v17    # "$changed\\52":I
    .end local v72    # "$composer\\52":Landroidx/compose/runtime/Composer;
    .end local v73    # "$i$a$-Layout-ColumnKt$Column$1\\52\\1126\\46":I
    nop

    .line 1128
    invoke-interface/range {v81 .. v81}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1105
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1129
    nop

    .line 1099
    .end local v67    # "factory\\48":Lkotlin/jvm/functions/Function0;
    .end local v68    # "$i$f$ReusableComposeNode\\48\\1103":I
    .end local v69    # "$changed\\48":I
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1130
    nop

    .line 1092
    .end local v7    # "materialized\\47":Landroidx/compose/ui/Modifier;
    .end local v20    # "compositeKeyHash\\47":I
    .end local v63    # "$changed\\47":I
    .end local v64    # "$i$f$Layout\\47\\1098":I
    .end local v70    # "localMap\\47":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1131
    nop

    .line 415
    .end local v6    # "measurePolicy\\46":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v8    # "$i$f$Column\\46\\418":I
    .end local v9    # "horizontalAlignment\\46":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v62    # "$changed\\46":I
    .end local v65    # "verticalArrangement\\46":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v66    # "modifier\\46":Landroidx/compose/ui/Modifier;
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 433
    nop

    .line 1049
    .end local v23    # "$this$ResultRow_u24lambda_u2457\\32":Landroidx/compose/foundation/layout/RowScope;
    .end local v60    # "$changed\\32":I
    .end local v81    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .end local p2    # "$i$a$-Row-StoreScreenKt$ResultRow$4\\32\\1049\\0":I
    invoke-static/range {v86 .. v86}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1048
    .end local v59    # "$changed\\31":I
    .end local v86    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local v87    # "$i$a$-Layout-RowKt$Row$1\\31\\1048\\25":I
    nop

    .line 1132
    invoke-interface/range {v56 .. v56}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1027
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1133
    nop

    .line 1021
    .end local v26    # "$i$f$ReusableComposeNode\\27\\1025":I
    .end local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .end local v55    # "$changed\\27":I
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1134
    nop

    .line 1014
    .end local v13    # "$changed\\26":I
    .end local v15    # "$i$f$Layout\\26\\1020":I
    .end local v24    # "compositeKeyHash\\26":I
    .end local v57    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v85    # "materialized\\26":Landroidx/compose/ui/Modifier;
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1135
    nop

    .end local v11    # "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v12    # "$i$f$Row\\25\\413":I
    .end local v25    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .end local v53    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .end local v58    # "$changed\\25":I
    .end local v61    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_38

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "installedVersion":Ljava/lang/String;
    .end local v28    # "problem":Ljava/lang/String;
    :cond_38
    move-object/from16 v3, v27

    .end local v27    # "rank":Ljava/lang/Integer;
    .local v3, "rank":Ljava/lang/Integer;
    :goto_27
    invoke-interface/range {v56 .. v56}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_39

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda12;

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda12;-><init>(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;II)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 434
    :cond_39
    return-void
.end method

.method private static final ResultRow$lambda$46(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v6, p4

    move-object v4, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/StoreScreenKt;->ResultRow(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final ResultRow$lambda$48$lambda$47(Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$app"    # Lorg/json/JSONObject;

    .line 413
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreModel;->open(Lorg/json/JSONObject;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ResultRow$lambda$58(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v6, p4

    move-object v4, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/StoreScreenKt;->ResultRow(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreModel;Ljava/lang/Integer;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final Screenshots(Ljava/util/List;Landroidx/compose/runtime/Composer;I)V
    .locals 13
    .param p0, "shots"    # Ljava/util/List;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreShot;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 500
    const v0, -0x23cae4f6

    invoke-interface {p1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string p1, "C(Screenshots)500@31215L594,500@31076L733:StoreScreen.kt#o13vsk"

    invoke-static {v10, p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move p1, p2

    .local p1, "$dirty":I
    and-int/lit8 v1, p2, 0x6

    const/4 v2, 0x2

    if-nez v1, :cond_1

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    or-int/2addr p1, v1

    :cond_1
    and-int/lit8 v1, p1, 0x3

    if-ne v1, v2, :cond_3

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_1

    .line 501
    :cond_2
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_4

    .line 500
    :cond_3
    :goto_1
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.Screenshots (StoreScreen.kt:499)"

    invoke-static {v0, p1, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 501
    :cond_4
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v4, 0x8

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 1330
    .local v5, "$i$f$getDp\\1\\501":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 501
    .end local v4    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\501":I
    invoke-static {v0, v1, v4, v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "store_screenshots"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v2, 0x8

    .local v2, "$this$dp\\2":I
    const/4 v3, 0x0

    .line 1330
    .local v3, "$i$f$getDp\\2\\501":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 501
    .end local v2    # "$this$dp\\2":I
    .end local v3    # "$i$f$getDp\\2\\501":I
    invoke-virtual {v0, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    const v0, 0x4c5de2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\3":Z
    move-object v2, v10

    .local v2, "$this$cache\\3":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 1331
    .local v3, "$i$f$cache\\3\\501":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\3":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 1332
    .local v6, "$i$a$-let-ComposerKt$cache$1\\4\\1331\\3":I
    if-nez v0, :cond_6

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_5

    goto :goto_2

    .line 1336
    :cond_5
    move-object v8, v4

    goto :goto_3

    .line 1333
    :cond_6
    :goto_2
    const/4 v7, 0x0

    .line 501
    .local v7, "$i$a$-cache-StoreScreenKt$Screenshots$1\\5\\1333\\0":I
    new-instance v8, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda16;

    invoke-direct {v8, p0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda16;-><init>(Ljava/util/List;)V

    .line 1333
    .end local v7    # "$i$a$-cache-StoreScreenKt$Screenshots$1\\5\\1333\\0":I
    nop

    .line 1334
    .local v8, "value\\4":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1335
    nop

    .line 1332
    .end local v8    # "value\\4":Ljava/lang/Object;
    :goto_3
    nop

    .line 1331
    .end local v4    # "it\\3":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\4\\1331\\3":I
    nop

    .line 501
    .end local v0    # "invalid\\3":Z
    .end local v2    # "$this$cache\\3":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\3\\501":I
    move-object v9, v8

    check-cast v9, Lkotlin/jvm/functions/Function1;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v11, 0x6006

    const/16 v12, 0xee

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v1 .. v12}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyRow(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_7
    :goto_4
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_8

    new-instance v1, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda17;

    invoke-direct {v1, p0, p2}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda17;-><init>(Ljava/util/List;I)V

    invoke-interface {v0, v1}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 510
    :cond_8
    return-void
.end method

.method private static final Screenshots$lambda$94$lambda$93(Ljava/util/List;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 10
    .param p0, "$shots"    # Ljava/util/List;
    .param p1, "$this$LazyRow"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyRow"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 502
    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda26;

    invoke-direct {v0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda26;-><init>()V

    .local v0, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object v1, p1

    .line 1622
    .local v1, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 1625
    sget-object v2, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$1;

    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 1622
    .local v2, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v3, 0x0

    .line 1627
    .local v3, "$i$f$items\\1\\502":I
    nop

    .line 1628
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v4

    .line 1629
    nop

    .line 1627
    new-instance v5, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$2;

    invoke-direct {v5, v0, p0}, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v5, Lkotlin/jvm/functions/Function1;

    new-instance v6, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$3;

    invoke-direct {v6, v2, p0}, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 1631
    new-instance v7, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$4;

    invoke-direct {v7, p0}, Lorg/lighttouch/android/StoreScreenKt$Screenshots$lambda$94$lambda$93$$inlined$items$default$4;-><init>(Ljava/util/List;)V

    const v8, -0x25b7f321

    const/4 v9, 0x1

    invoke-static {v8, v9, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function4;

    .line 1627
    invoke-interface {v1, v4, v5, v6, v7}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 1633
    nop

    .line 509
    .end local v0    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v1    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v2    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v3    # "$i$f$items\\1\\502":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Screenshots$lambda$94$lambda$93$lambda$87(Lorg/lighttouch/android/StoreShot;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/StoreShot;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 502
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreShot;->getUrl()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final Screenshots$lambda$94$lambda$93$lambda$92$lambda$89(Landroidx/compose/runtime/State;)Landroid/graphics/Bitmap;
    .locals 4
    .param p0, "$bitmap$delegate"    # Landroidx/compose/runtime/State;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/State<",
            "Landroid/graphics/Bitmap;",
            ">;)",
            "Landroid/graphics/Bitmap;"
        }
    .end annotation

    .line 503
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p0

    .local v2, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v3, 0x0

    .line 1621
    .local v3, "$i$f$getValue\\1\\503":I
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v3    # "$i$f$getValue\\1\\503":I
    check-cast v0, Landroid/graphics/Bitmap;

    .line 503
    return-object v0
.end method

.method private static final Screenshots$lambda$95(Ljava/util/List;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lorg/lighttouch/android/StoreScreenKt;->Screenshots(Ljava/util/List;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SearchField(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V
    .locals 106
    .param p0, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 373
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v8, p3

    const v2, -0x509e9206

    move-object/from16 v3, p2

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(SearchField)373@21172L7,374@21196L29,375@21251L24,375@21230L45,376@21293L86,383@21998L11,383@22068L11,382@21809L288,384@22217L12,377@21407L20,379@21638L134,377@21384L847:StoreScreen.kt#o13vsk"

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p3

    .local v3, "$dirty":I
    and-int/lit8 v4, v8, 0x6

    if-nez v4, :cond_1

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    :goto_0
    or-int/2addr v3, v4

    :cond_1
    and-int/lit8 v4, v8, 0x30

    if-nez v4, :cond_3

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/16 v4, 0x20

    goto :goto_1

    :cond_2
    const/16 v4, 0x10

    :goto_1
    or-int/2addr v3, v4

    :cond_3
    move v10, v3

    .end local v3    # "$dirty":I
    .local v10, "$dirty":I
    and-int/lit8 v3, v10, 0x13

    const/16 v4, 0x12

    if-ne v3, v4, :cond_5

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    .line 378
    :cond_4
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v95, v9

    move v5, v10

    goto/16 :goto_b

    .line 373
    :cond_5
    :goto_2
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_6

    const/4 v3, -0x1

    const-string v4, "org.lighttouch.android.SearchField (StoreScreen.kt:372)"

    invoke-static {v2, v10, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 374
    :cond_6
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalSoftwareKeyboardController()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    .local v2, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v3, 0x0

    .local v3, "$changed\\1":I
    const/4 v4, 0x0

    .line 853
    .local v4, "$i$f$getCurrent\\1\\374":I
    const v5, 0x789c5f52

    const-string v6, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v9, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v5

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 374
    .end local v2    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v3    # "$changed\\1":I
    .end local v4    # "$i$f$getCurrent\\1\\374":I
    move-object v11, v5

    check-cast v11, Landroidx/compose/ui/platform/SoftwareKeyboardController;

    .local v11, "keyboard":Landroidx/compose/ui/platform/SoftwareKeyboardController;
    const v2, 0x6e3c21fe

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 375
    move-object v2, v9

    .local v2, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .local v3, "invalid\\2":Z
    const/4 v4, 0x0

    .line 854
    .local v4, "$i$f$cache\\2\\375":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\2":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 855
    .local v6, "$i$a$-let-ComposerKt$cache$1\\3\\854\\2":I
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_7

    .line 856
    const/4 v7, 0x0

    .line 375
    .local v7, "$i$a$-cache-StoreScreenKt$SearchField$focus$1\\4\\856\\0":I
    new-instance v13, Landroidx/compose/ui/focus/FocusRequester;

    invoke-direct {v13}, Landroidx/compose/ui/focus/FocusRequester;-><init>()V

    .line 856
    .end local v7    # "$i$a$-cache-StoreScreenKt$SearchField$focus$1\\4\\856\\0":I
    nop

    .line 857
    .local v13, "value\\3":Ljava/lang/Object;
    invoke-interface {v2, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 858
    nop

    .end local v13    # "value\\3":Ljava/lang/Object;
    goto :goto_3

    .line 859
    :cond_7
    move-object v13, v5

    .line 855
    :goto_3
    nop

    .line 854
    .end local v5    # "it\\2":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\3\\854\\2":I
    nop

    .line 375
    .end local v2    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v3    # "invalid\\2":Z
    .end local v4    # "$i$f$cache\\2\\375":I
    check-cast v13, Landroidx/compose/ui/focus/FocusRequester;

    .local v13, "focus":Landroidx/compose/ui/focus/FocusRequester;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 376
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    const v14, 0x4c5de2

    invoke-interface {v9, v14}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\5":Z
    move-object v4, v9

    .local v4, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 860
    .local v5, "$i$f$cache\\5\\376":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\5":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 861
    .local v7, "$i$a$-let-ComposerKt$cache$1\\6\\860\\5":I
    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v6, v15, :cond_8

    .line 862
    const/4 v15, 0x0

    .line 376
    .local v15, "$i$a$-cache-StoreScreenKt$SearchField$1\\7\\862\\0":I
    new-instance v14, Lorg/lighttouch/android/StoreScreenKt$SearchField$1$1;

    const/4 v1, 0x0

    invoke-direct {v14, v13, v1}, Lorg/lighttouch/android/StoreScreenKt$SearchField$1$1;-><init>(Landroidx/compose/ui/focus/FocusRequester;Lkotlin/coroutines/Continuation;)V

    check-cast v14, Lkotlin/jvm/functions/Function2;

    .line 862
    .end local v15    # "$i$a$-cache-StoreScreenKt$SearchField$1\\7\\862\\0":I
    nop

    .line 863
    .local v14, "value\\6":Ljava/lang/Object;
    invoke-interface {v4, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 864
    nop

    .end local v14    # "value\\6":Ljava/lang/Object;
    goto :goto_4

    .line 865
    :cond_8
    move-object v14, v6

    .line 861
    :goto_4
    nop

    .line 860
    .end local v6    # "it\\5":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\6\\860\\5":I
    nop

    .line 376
    .end local v3    # "invalid\\5":Z
    .end local v4    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\5\\376":I
    check-cast v14, Lkotlin/jvm/functions/Function2;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v1, 0x6

    invoke-static {v2, v14, v9, v1}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    const v1, -0x615d173a

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v1, v2

    .line 377
    move-object v2, v9

    .local v1, "invalid\\8":Z
    .local v2, "$this$cache\\8":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 866
    .local v3, "$i$f$cache\\8\\377":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\8":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 867
    .local v5, "$i$a$-let-ComposerKt$cache$1\\9\\866\\8":I
    if-nez v1, :cond_a

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_9

    goto :goto_5

    .line 871
    :cond_9
    move-object v7, v4

    goto :goto_6

    .line 868
    :cond_a
    :goto_5
    const/4 v6, 0x0

    .line 377
    .local v6, "$i$a$-cache-StoreScreenKt$SearchField$search$1\\10\\868\\0":I
    new-instance v7, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda18;

    invoke-direct {v7, v0, v11}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda18;-><init>(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/platform/SoftwareKeyboardController;)V

    .line 868
    .end local v6    # "$i$a$-cache-StoreScreenKt$SearchField$search$1\\10\\868\\0":I
    nop

    .line 869
    .local v7, "value\\9":Ljava/lang/Object;
    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 870
    nop

    .line 867
    .end local v7    # "value\\9":Ljava/lang/Object;
    :goto_6
    nop

    .line 866
    .end local v4    # "it\\8":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\9\\866\\8":I
    nop

    .line 377
    .end local v1    # "invalid\\8":Z
    .end local v2    # "$this$cache\\8":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\8\\377":I
    move-object v14, v7

    check-cast v14, Lkotlin/jvm/functions/Function0;

    .local v14, "search":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 378
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreModel;->getQuery()Ljava/lang/String;

    move-result-object v103

    const/4 v1, 0x4

    .local v1, "$this$dp\\11":I
    const/4 v2, 0x0

    .line 872
    .local v2, "$i$f$getDp\\11\\378":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 378
    .end local v1    # "$this$dp\\11":I
    .end local v2    # "$i$f$getDp\\11\\378":I
    const/16 v6, 0xb

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object/from16 v1, p1

    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    invoke-static {v2, v13}, Landroidx/compose/ui/focus/FocusRequesterModifierKt;->focusRequester(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/focus/FocusRequester;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const-string v3, "store_query"

    invoke-static {v2, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 379
    const/16 v3, 0x1c

    .local v3, "$this$dp\\12":I
    const/4 v4, 0x0

    .line 873
    .local v4, "$i$f$getDp\\12\\379":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 379
    .end local v3    # "$this$dp\\12":I
    .end local v4    # "$i$f$getDp\\12\\379":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    .line 383
    sget-object v4, Landroidx/compose/material3/TextFieldDefaults;->INSTANCE:Landroidx/compose/material3/TextFieldDefaults;

    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v31

    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v33

    sget-object v5, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/graphics/Color$Companion;->getTransparent-0d7_KjU()J

    move-result-wide v35

    .line 384
    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v9, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v18

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v9, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v20

    .line 383
    nop

    .line 384
    nop

    .line 383
    const v101, 0x7fffc7cf

    const/16 v102, 0xfff

    move v5, v10

    move-object v6, v11

    .end local v10    # "$dirty":I
    .end local v11    # "keyboard":Landroidx/compose/ui/platform/SoftwareKeyboardController;
    .local v5, "$dirty":I
    .local v6, "keyboard":Landroidx/compose/ui/platform/SoftwareKeyboardController;
    const-wide/16 v10, 0x0

    move-object v15, v12

    move-object v7, v13

    .end local v13    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    .local v7, "focus":Landroidx/compose/ui/focus/FocusRequester;
    const-wide/16 v12, 0x0

    move-object/from16 v16, v14

    move-object/from16 v17, v15

    .end local v14    # "search":Lkotlin/jvm/functions/Function0;
    .local v16, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v14, 0x0

    move-object/from16 v22, v16

    move-object/from16 v23, v17

    .end local v16    # "search":Lkotlin/jvm/functions/Function0;
    .local v22, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v16, 0x0

    move-object/from16 v24, v22

    move-object/from16 v25, v23

    .end local v22    # "search":Lkotlin/jvm/functions/Function0;
    .local v24, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v22, 0x0

    move-object/from16 v26, v24

    move-object/from16 v27, v25

    .end local v24    # "search":Lkotlin/jvm/functions/Function0;
    .local v26, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v24, 0x0

    move-object/from16 v28, v26

    move-object/from16 v29, v27

    .end local v26    # "search":Lkotlin/jvm/functions/Function0;
    .local v28, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v26, 0x0

    move-object/from16 v30, v28

    move-object/from16 v37, v29

    .end local v28    # "search":Lkotlin/jvm/functions/Function0;
    .local v30, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v28, 0x0

    move-object/from16 v38, v30

    .end local v30    # "search":Lkotlin/jvm/functions/Function0;
    .local v38, "search":Lkotlin/jvm/functions/Function0;
    const/16 v30, 0x0

    move-object/from16 v40, v37

    move-object/from16 v39, v38

    .end local v38    # "search":Lkotlin/jvm/functions/Function0;
    .local v39, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v37, 0x0

    move-object/from16 v41, v39

    move-object/from16 v42, v40

    .end local v39    # "search":Lkotlin/jvm/functions/Function0;
    .local v41, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v39, 0x0

    move-object/from16 v43, v41

    move-object/from16 v44, v42

    .end local v41    # "search":Lkotlin/jvm/functions/Function0;
    .local v43, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v41, 0x0

    move-object/from16 v45, v43

    move-object/from16 v46, v44

    .end local v43    # "search":Lkotlin/jvm/functions/Function0;
    .local v45, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v43, 0x0

    move-object/from16 v47, v45

    move-object/from16 v48, v46

    .end local v45    # "search":Lkotlin/jvm/functions/Function0;
    .local v47, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v45, 0x0

    move-object/from16 v49, v47

    move-object/from16 v50, v48

    .end local v47    # "search":Lkotlin/jvm/functions/Function0;
    .local v49, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v47, 0x0

    move-object/from16 v51, v49

    move-object/from16 v52, v50

    .end local v49    # "search":Lkotlin/jvm/functions/Function0;
    .local v51, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v49, 0x0

    move-object/from16 v53, v51

    move-object/from16 v54, v52

    .end local v51    # "search":Lkotlin/jvm/functions/Function0;
    .local v53, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v51, 0x0

    move-object/from16 v55, v53

    move-object/from16 v56, v54

    .end local v53    # "search":Lkotlin/jvm/functions/Function0;
    .local v55, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v53, 0x0

    move-object/from16 v57, v55

    move-object/from16 v58, v56

    .end local v55    # "search":Lkotlin/jvm/functions/Function0;
    .local v57, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v55, 0x0

    move-object/from16 v59, v57

    move-object/from16 v60, v58

    .end local v57    # "search":Lkotlin/jvm/functions/Function0;
    .local v59, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v57, 0x0

    move-object/from16 v61, v59

    move-object/from16 v62, v60

    .end local v59    # "search":Lkotlin/jvm/functions/Function0;
    .local v61, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v59, 0x0

    move-object/from16 v63, v61

    move-object/from16 v64, v62

    .end local v61    # "search":Lkotlin/jvm/functions/Function0;
    .local v63, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v61, 0x0

    move-object/from16 v65, v63

    move-object/from16 v66, v64

    .end local v63    # "search":Lkotlin/jvm/functions/Function0;
    .local v65, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v63, 0x0

    move-object/from16 v67, v65

    move-object/from16 v68, v66

    .end local v65    # "search":Lkotlin/jvm/functions/Function0;
    .local v67, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v65, 0x0

    move-object/from16 v69, v67

    move-object/from16 v70, v68

    .end local v67    # "search":Lkotlin/jvm/functions/Function0;
    .local v69, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v67, 0x0

    move-object/from16 v71, v69

    move-object/from16 v72, v70

    .end local v69    # "search":Lkotlin/jvm/functions/Function0;
    .local v71, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v69, 0x0

    move-object/from16 v73, v71

    move-object/from16 v74, v72

    .end local v71    # "search":Lkotlin/jvm/functions/Function0;
    .local v73, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v71, 0x0

    move-object/from16 v75, v73

    move-object/from16 v76, v74

    .end local v73    # "search":Lkotlin/jvm/functions/Function0;
    .local v75, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v73, 0x0

    move-object/from16 v77, v75

    move-object/from16 v78, v76

    .end local v75    # "search":Lkotlin/jvm/functions/Function0;
    .local v77, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v75, 0x0

    move-object/from16 v79, v77

    move-object/from16 v80, v78

    .end local v77    # "search":Lkotlin/jvm/functions/Function0;
    .local v79, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v77, 0x0

    move-object/from16 v81, v79

    move-object/from16 v82, v80

    .end local v79    # "search":Lkotlin/jvm/functions/Function0;
    .local v81, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v79, 0x0

    move-object/from16 v83, v81

    move-object/from16 v84, v82

    .end local v81    # "search":Lkotlin/jvm/functions/Function0;
    .local v83, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v81, 0x0

    move-object/from16 v85, v83

    move-object/from16 v86, v84

    .end local v83    # "search":Lkotlin/jvm/functions/Function0;
    .local v85, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v83, 0x0

    move-object/from16 v87, v85

    move-object/from16 v88, v86

    .end local v85    # "search":Lkotlin/jvm/functions/Function0;
    .local v87, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v85, 0x0

    move-object/from16 v89, v87

    move-object/from16 v90, v88

    .end local v87    # "search":Lkotlin/jvm/functions/Function0;
    .local v89, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v87, 0x0

    move-object/from16 v91, v89

    move-object/from16 v92, v90

    .end local v89    # "search":Lkotlin/jvm/functions/Function0;
    .local v91, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v89, 0x0

    move-object/from16 v93, v91

    move-object/from16 v94, v92

    .end local v91    # "search":Lkotlin/jvm/functions/Function0;
    .local v93, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v91, 0x0

    move-object/from16 v95, v93

    move-object/from16 v96, v94

    .end local v93    # "search":Lkotlin/jvm/functions/Function0;
    .local v95, "search":Lkotlin/jvm/functions/Function0;
    const-wide/16 v93, 0x0

    move-object/from16 v97, v96

    const/16 v96, 0x0

    move-object/from16 v98, v97

    const/16 v97, 0xdb0

    move-object/from16 v99, v98

    const/16 v98, 0x0

    move-object/from16 v100, v99

    const/16 v99, 0x0

    move-object/from16 v104, v100

    const/16 v100, 0xc00

    move-object/from16 p2, v9

    move-object v9, v4

    move-object/from16 v4, v95

    move-object/from16 v95, p2

    move-object/from16 p2, v2

    move-object/from16 v105, v104

    const v2, 0x4c5de2

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "search":Lkotlin/jvm/functions/Function0;
    .local v95, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v9 .. v102}, Landroidx/compose/material3/TextFieldDefaults;->colors-0hiis_0(JJJJJJJJJJLandroidx/compose/foundation/text/selection/TextSelectionColors;JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJLandroidx/compose/runtime/Composer;IIIIIII)Landroidx/compose/material3/TextFieldColors;

    move-result-object v31

    .line 385
    move-object/from16 v9, v95

    .end local v95    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer":Landroidx/compose/runtime/Composer;
    new-instance v24, Landroidx/compose/foundation/text/KeyboardOptions;

    sget-object v10, Landroidx/compose/ui/text/input/ImeAction;->Companion:Landroidx/compose/ui/text/input/ImeAction$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/text/input/ImeAction$Companion;->getSearch-eUduSuo()I

    move-result v14

    const/16 v18, 0x77

    const/16 v19, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v10, v24

    invoke-direct/range {v10 .. v19}, Landroidx/compose/foundation/text/KeyboardOptions;-><init>(ILjava/lang/Boolean;IILandroidx/compose/ui/text/input/PlatformImeOptions;Ljava/lang/Boolean;Landroidx/compose/ui/text/intl/LocaleList;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    move-object/from16 v15, v105

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    .local v10, "invalid\\13":Z
    move-object v11, v9

    .local v11, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 874
    .local v12, "$i$f$cache\\13\\385":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\13":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 875
    .local v14, "$i$a$-let-ComposerKt$cache$1\\14\\874\\13":I
    if-nez v10, :cond_c

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v13, v2, :cond_b

    goto :goto_7

    .line 879
    :cond_b
    move-object v2, v13

    goto :goto_8

    .line 876
    :cond_c
    :goto_7
    const/4 v2, 0x0

    .line 385
    .local v2, "$i$a$-cache-StoreScreenKt$SearchField$2\\15\\876\\0":I
    move/from16 v16, v2

    .end local v2    # "$i$a$-cache-StoreScreenKt$SearchField$2\\15\\876\\0":I
    .local v16, "$i$a$-cache-StoreScreenKt$SearchField$2\\15\\876\\0":I
    new-instance v2, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda19;

    invoke-direct {v2, v4}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda19;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 876
    .end local v16    # "$i$a$-cache-StoreScreenKt$SearchField$2\\15\\876\\0":I
    nop

    .line 877
    .local v2, "value\\14":Ljava/lang/Object;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 878
    nop

    .line 875
    .end local v2    # "value\\14":Ljava/lang/Object;
    :goto_8
    nop

    .line 874
    .end local v13    # "it\\13":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\14\\874\\13":I
    nop

    .line 385
    .end local v10    # "invalid\\13":Z
    .end local v11    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\13\\385":I
    move-object/from16 v37, v2

    check-cast v37, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v32, Landroidx/compose/foundation/text/KeyboardActions;

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x2f

    const/16 v40, 0x0

    invoke-direct/range {v32 .. v40}, Landroidx/compose/foundation/text/KeyboardActions;-><init>(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 378
    const v2, 0x4c5de2

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\16":Z
    move-object v10, v9

    .local v10, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 880
    .local v11, "$i$f$cache\\16\\378":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\16":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 881
    .local v13, "$i$a$-let-ComposerKt$cache$1\\17\\880\\16":I
    if-nez v2, :cond_e

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v12, v14, :cond_d

    goto :goto_9

    .line 885
    :cond_d
    move-object v15, v12

    goto :goto_a

    .line 882
    :cond_e
    :goto_9
    const/4 v14, 0x0

    .line 378
    .local v14, "$i$a$-cache-StoreScreenKt$SearchField$3\\18\\882\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda20;

    invoke-direct {v15, v0}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda20;-><init>(Lorg/lighttouch/android/StoreModel;)V

    .line 882
    .end local v14    # "$i$a$-cache-StoreScreenKt$SearchField$3\\18\\882\\0":I
    nop

    .line 883
    .local v15, "value\\17":Ljava/lang/Object;
    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 884
    nop

    .line 881
    .end local v15    # "value\\17":Ljava/lang/Object;
    :goto_a
    nop

    .line 880
    .end local v12    # "it\\16":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\17\\880\\16":I
    nop

    .line 378
    .end local v2    # "invalid\\16":Z
    .end local v10    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\16\\378":I
    move-object v10, v15

    check-cast v10, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$204945845$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v16

    .line 380
    new-instance v2, Lorg/lighttouch/android/StoreScreenKt$SearchField$4;

    invoke-direct {v2, v0}, Lorg/lighttouch/android/StoreScreenKt$SearchField$4;-><init>(Lorg/lighttouch/android/StoreModel;)V

    const/16 v11, 0x36

    const v12, 0x5f062b73

    const/4 v13, 0x1

    invoke-static {v12, v13, v2, v9, v11}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object/from16 v18, v2

    check-cast v18, Lkotlin/jvm/functions/Function2;

    .line 385
    nop

    .line 379
    move-object/from16 v30, v3

    check-cast v30, Landroidx/compose/ui/graphics/Shape;

    .line 383
    nop

    .line 378
    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v17, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v26, 0x1

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/high16 v33, 0x30c00000

    const/high16 v34, 0xc30000

    const/16 v35, 0x0

    const v36, 0x1c7d78

    move-object/from16 v11, p2

    move-object/from16 v25, v32

    move-object/from16 v32, v9

    move-object/from16 v9, v103

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v32, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v9 .. v36}, Landroidx/compose/material3/TextFieldKt;->TextField(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/text/TextStyle;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLandroidx/compose/ui/text/input/VisualTransformation;Landroidx/compose/foundation/text/KeyboardOptions;Landroidx/compose/foundation/text/KeyboardActions;ZIILandroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/TextFieldColors;Landroidx/compose/runtime/Composer;IIII)V

    move-object/from16 v95, v32

    .end local v32    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v95    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v4    # "search":Lkotlin/jvm/functions/Function0;
    .end local v6    # "keyboard":Landroidx/compose/ui/platform/SoftwareKeyboardController;
    .end local v7    # "focus":Landroidx/compose/ui/focus/FocusRequester;
    :cond_f
    :goto_b
    invoke-interface/range {v95 .. v95}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_10

    new-instance v3, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda21;

    invoke-direct {v3, v0, v1, v8}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda21;-><init>(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 386
    :cond_10
    return-void
.end method

.method private static final SearchField$lambda$36$lambda$35(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/platform/SoftwareKeyboardController;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "$keyboard"    # Landroidx/compose/ui/platform/SoftwareKeyboardController;

    .line 377
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getSearching()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v0

    if-eqz v0, :cond_1

    if-eqz p1, :cond_0

    invoke-interface {p1}, Landroidx/compose/ui/platform/SoftwareKeyboardController;->hide()V

    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->search()V

    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SearchField$lambda$38$lambda$37(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/text/KeyboardActionScope;)Lkotlin/Unit;
    .locals 1
    .param p0, "$search"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$this$KeyboardActions"    # Landroidx/compose/foundation/text/KeyboardActionScope;

    const-string v0, "$this$KeyboardActions"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 385
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SearchField$lambda$40$lambda$39(Lorg/lighttouch/android/StoreModel;Ljava/lang/String;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 378
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/StoreModel;->setQuery(Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SearchField$lambda$41(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/StoreScreenKt;->SearchField(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreCard(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V
    .locals 26
    .param p0, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p1, "content"    # Lkotlin/jvm/functions/Function3;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    .line 514
    move-object/from16 v0, p1

    move/from16 v1, p3

    move/from16 v2, p4

    const v3, 0x5f30cf7f

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(StoreCard)P(1)513@32042L11,513@31929L221:StoreScreen.kt#o13vsk"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p3

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x1

    if-eqz v6, :cond_0

    or-int/lit8 v5, v5, 0x6

    move-object/from16 v7, p0

    goto :goto_1

    :cond_0
    and-int/lit8 v7, v1, 0x6

    if-nez v7, :cond_2

    move-object/from16 v7, p0

    invoke-interface {v4, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    const/4 v8, 0x4

    goto :goto_0

    :cond_1
    const/4 v8, 0x2

    :goto_0
    or-int/2addr v5, v8

    goto :goto_1

    :cond_2
    move-object/from16 v7, p0

    :goto_1
    and-int/lit8 v8, v2, 0x2

    if-eqz v8, :cond_3

    or-int/lit8 v5, v5, 0x30

    goto :goto_3

    :cond_3
    and-int/lit8 v8, v1, 0x30

    if-nez v8, :cond_5

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_4

    const/16 v8, 0x20

    goto :goto_2

    :cond_4
    const/16 v8, 0x10

    :goto_2
    or-int/2addr v5, v8

    :cond_5
    :goto_3
    and-int/lit8 v8, v5, 0x13

    const/16 v9, 0x12

    if-ne v8, v9, :cond_7

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v8

    if-nez v8, :cond_6

    goto :goto_4

    .line 1378
    :cond_6
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v24, v4

    move/from16 p2, v5

    goto/16 :goto_9

    .line 514
    :cond_7
    :goto_4
    if-eqz v6, :cond_8

    .line 513
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .local v6, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_5

    .line 514
    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p0    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_8
    move-object v6, v7

    .line 513
    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v6    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_9

    const/4 v7, -0x1

    const-string v8, "org.lighttouch.android.StoreCard (StoreScreen.kt:513)"

    invoke-static {v3, v5, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 514
    :cond_9
    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v6, v3, v7, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    const/4 v10, 0x6

    .local v10, "$this$dp\\1":I
    const/4 v11, 0x0

    .line 1337
    .local v11, "$i$f$getDp\\1\\514":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 514
    .end local v10    # "$this$dp\\1":I
    .end local v11    # "$i$f$getDp\\1\\514":I
    invoke-static {v9, v3, v10, v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v7, 0x14

    .local v7, "$this$dp\\2":I
    const/4 v8, 0x0

    .line 1337
    .local v8, "$i$f$getDp\\2\\514":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 514
    .end local v7    # "$this$dp\\2":I
    .end local v8    # "$i$f$getDp\\2\\514":I
    invoke-static {v7}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v7

    check-cast v7, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v7}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v4, v7}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainerHigh-0d7_KjU()J

    move-result-wide v9

    const/4 v12, 0x2

    const/4 v13, 0x0

    const/4 v11, 0x0

    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 515
    const/16 v7, 0x10

    .local v7, "$this$dp\\3":I
    const/4 v8, 0x0

    .line 1338
    .local v8, "$i$f$getDp\\3\\515":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 515
    .end local v7    # "$this$dp\\3":I
    .end local v8    # "$i$f$getDp\\3\\515":I
    const/16 v8, 0xc

    .local v8, "$this$dp\\4":I
    const/4 v9, 0x0

    .line 1338
    .local v9, "$i$f$getDp\\4\\515":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 515
    .end local v8    # "$this$dp\\4":I
    .end local v9    # "$i$f$getDp\\4\\515":I
    invoke-static {v3, v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v3

    shl-int/lit8 v7, v5, 0x6

    and-int/lit16 v7, v7, 0x1c00

    .line 514
    nop

    .local v3, "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v7, "$changed\\5":I
    const/4 v8, 0x0

    .line 1339
    .local v8, "$i$f$Column\\5\\514":I
    const v9, -0x1cd0f17e

    const-string v10, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v4, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1340
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 1341
    .local v9, "verticalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    .line 1344
    .local v10, "horizontalAlignment\\5":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v11, v7, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v7, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v9, v10, v4, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v7, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 1345
    nop

    .local v12, "$changed\\6":I
    const/4 v13, 0x0

    .line 1346
    .local v13, "$i$f$Layout\\6\\1345":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v4, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1347
    const/4 v14, 0x0

    invoke-static {v4, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v14

    .line 1348
    .local v14, "compositeKeyHash\\6":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 1349
    .local v15, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p2, v5

    .end local v5    # "$dirty":I
    .local p2, "$dirty":I
    invoke-static {v4, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 1351
    .local v5, "materialized\\6":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 p0, v3

    .end local v3    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local p0, "modifier\\5":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v12, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 1350
    move-object/from16 v17, v16

    .local v3, "$changed\\7":I
    .local v17, "factory\\7":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 1352
    .local v16, "$i$f$ReusableComposeNode\\7\\1350":I
    move/from16 v18, v3

    .end local v3    # "$changed\\7":I
    .local v18, "$changed\\7":I
    const v3, -0x2942ffcf

    move-object/from16 v19, v6

    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .local v19, "modifier":Landroidx/compose/ui/Modifier;
    const-string v6, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v4, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1353
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1354
    :cond_a
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1355
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_b

    .line 1356
    move-object/from16 v3, v17

    .end local v17    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 1358
    .end local v3    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v17    # "factory\\7":Lkotlin/jvm/functions/Function0;
    :cond_b
    move-object/from16 v3, v17

    .end local v17    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1360
    :goto_6
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .local v6, "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 1361
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\1360\\6":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v21, v3

    .end local v3    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v21, "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v6, v11, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1362
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v6, v15, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1364
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\9":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 1365
    .local v20, "$i$f$set-impl\\9\\1364":I
    move-object/from16 v22, v6

    .local v22, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 1366
    .local v23, "$i$a$-with-Updater$set$1\\10\\1365\\9":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_d

    move-object/from16 v24, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v24, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v25, v7

    .end local v7    # "$changed\\5":I
    .local v25, "$changed\\5":I
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v4, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_c

    goto :goto_7

    :cond_c
    move-object/from16 v7, v22

    goto :goto_8

    .end local v24    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v25    # "$changed\\5":I
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$changed\\5":I
    :cond_d
    move-object/from16 v24, v4

    move/from16 v25, v7

    .line 1367
    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v7    # "$changed\\5":I
    .restart local v24    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v25    # "$changed\\5":I
    :goto_7
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v7, v22

    .end local v22    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .local v7, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1368
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v6, v4, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1370
    :goto_8
    nop

    .line 1365
    .end local v7    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-with-Updater$set$1\\10\\1365\\9":I
    nop

    .line 1370
    nop

    .line 1371
    .end local v3    # "block\\9":Lkotlin/jvm/functions/Function2;
    .end local v20    # "$i$f$set-impl\\9\\1364":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v6, v5, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1372
    nop

    .line 1360
    .end local v6    # "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\1360\\6":I
    nop

    .line 1373
    shr-int/lit8 v3, v18, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\11":I
    move-object/from16 v4, v24

    .local v4, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 1374
    .local v6, "$i$a$-Layout-ColumnKt$Column$1\\11\\1373\\5":I
    const v7, -0x16ef5699

    move/from16 v17, v3

    .end local v3    # "$changed\\11":I
    .local v17, "$changed\\11":I
    const-string v3, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v4, v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v7, v25, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v0, v3, v4, v7}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1373
    .end local v4    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$a$-Layout-ColumnKt$Column$1\\11\\1373\\5":I
    .end local v17    # "$changed\\11":I
    nop

    .line 1375
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1352
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1376
    nop

    .line 1346
    .end local v16    # "$i$f$ReusableComposeNode\\7\\1350":I
    .end local v18    # "$changed\\7":I
    .end local v21    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1377
    nop

    .line 1339
    .end local v5    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .end local v12    # "$changed\\6":I
    .end local v13    # "$i$f$Layout\\6\\1345":I
    .end local v14    # "compositeKeyHash\\6":I
    .end local v15    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1378
    nop

    .end local v8    # "$i$f$Column\\5\\514":I
    .end local v9    # "verticalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v10    # "horizontalAlignment\\5":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v11    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v25    # "$changed\\5":I
    .end local p0    # "modifier\\5":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_e
    move-object/from16 v7, v19

    .end local v19    # "modifier":Landroidx/compose/ui/Modifier;
    .local v7, "modifier":Landroidx/compose/ui/Modifier;
    :goto_9
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v3

    if-eqz v3, :cond_f

    new-instance v4, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v4, v7, v0, v1, v2}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda8;-><init>(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;II)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 515
    :cond_f
    return-void
.end method

.method private static final StoreCard$lambda$96(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p4, v0, p3}, Lorg/lighttouch/android/StoreScreenKt;->StoreCard(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreDetails(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZLandroidx/compose/runtime/Composer;I)V
    .locals 110
    .param p0, "$this$StoreDetails"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "app"    # Lorg/json/JSONObject;
    .param p3, "running"    # Z
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    .line 437
    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p5

    const v0, 0x76613361

    move-object/from16 v1, p4

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(StoreDetails)P(1)438@26092L4914:StoreScreen.kt#o13vsk"

    invoke-static {v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p5

    .local v1, "$dirty":I
    and-int/lit8 v7, v5, 0x6

    const/4 v9, 0x2

    if-nez v7, :cond_1

    move-object/from16 v10, p0

    invoke-interface {v6, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_0

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    move v7, v9

    :goto_0
    or-int/2addr v1, v7

    goto :goto_1

    :cond_1
    move-object/from16 v10, p0

    :goto_1
    and-int/lit8 v7, v5, 0x30

    const/16 v11, 0x20

    if-nez v7, :cond_3

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    move v7, v11

    goto :goto_2

    :cond_2
    const/16 v7, 0x10

    :goto_2
    or-int/2addr v1, v7

    :cond_3
    and-int/lit16 v7, v5, 0x180

    if-nez v7, :cond_5

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v7, 0x100

    goto :goto_3

    :cond_4
    const/16 v7, 0x80

    :goto_3
    or-int/2addr v1, v7

    :cond_5
    and-int/lit16 v7, v5, 0xc00

    if-nez v7, :cond_7

    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v7

    if-eqz v7, :cond_6

    const/16 v7, 0x800

    goto :goto_4

    :cond_6
    const/16 v7, 0x400

    :goto_4
    or-int/2addr v1, v7

    :cond_7
    move v7, v1

    .end local v1    # "$dirty":I
    .local v7, "$dirty":I
    and-int/lit16 v1, v7, 0x493

    const/16 v12, 0x492

    if-ne v1, v12, :cond_9

    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_8

    goto :goto_5

    .line 1329
    :cond_8
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v27, v7

    goto/16 :goto_2b

    .line 437
    :cond_9
    :goto_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_a

    const/4 v1, -0x1

    const-string v12, "org.lighttouch.android.StoreDetails (StoreScreen.kt:436)"

    invoke-static {v0, v7, v1, v12}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 438
    :cond_a
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getInstalled()Ljava/util/Map;

    move-result-object v0

    const-string v1, "bundle_id"

    invoke-virtual {v3, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 439
    .local v0, "installedVersion":Ljava/lang/String;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v14, 0x2

    const/4 v15, 0x0

    const/high16 v12, 0x3f800000    # 1.0f

    const/4 v13, 0x0

    move/from16 v109, v11

    move-object v11, v1

    move/from16 v1, v109

    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/16 v10, 0x10

    .local v10, "$this$dp\\1":I
    const/4 v12, 0x0

    .line 1136
    .local v12, "$i$f$getDp\\1\\439":I
    int-to-float v13, v10

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 439
    .end local v10    # "$this$dp\\1":I
    .end local v12    # "$i$f$getDp\\1\\439":I
    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static {v11, v10, v12, v9, v13}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .local v10, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v11, 0x0

    .local v11, "$changed\\2":I
    const/4 v14, 0x0

    .line 1137
    .local v14, "$i$f$Column\\2\\439":I
    const v15, -0x1cd0f17e

    const-string v1, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v6, v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1138
    sget-object v16, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 1139
    .local v8, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 1142
    .local v9, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v11, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v18, v11, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v15, v16, v18

    invoke-static {v8, v9, v6, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v11, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 1143
    nop

    .local v16, "$changed\\3":I
    const/16 v18, 0x0

    .line 1144
    .local v18, "$i$f$Layout\\3\\1143":I
    const v12, -0x4ee9b9da

    const-string v13, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v6, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1145
    const/4 v12, 0x0

    invoke-static {v6, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v21

    .line 1146
    .local v21, "compositeKeyHash\\3":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 1147
    .local v12, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 1149
    .local v4, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    shl-int/lit8 v5, v16, 0x6

    and-int/lit16 v5, v5, 0x380

    move/from16 v24, v5

    const/4 v5, 0x6

    or-int/lit8 v24, v24, 0x6

    .line 1148
    move-object/from16 v25, v23

    .local v24, "$changed\\4":I
    .local v25, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 1150
    .local v23, "$i$f$ReusableComposeNode\\4\\1148":I
    move/from16 v26, v5

    const v5, -0x2942ffcf

    move/from16 v27, v7

    .end local v7    # "$dirty":I
    .local v27, "$dirty":I
    const-string v7, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v6, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1151
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1152
    :cond_b
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1153
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_c

    .line 1154
    move-object/from16 v5, v25

    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6

    .line 1156
    .end local v5    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c
    move-object/from16 v5, v25

    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1158
    :goto_6
    move-object/from16 v25, v5

    .end local v5    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 1159
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1158\\3":I
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v31, v8

    .end local v8    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v31, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v15, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1160
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v12, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1162
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v30, 0x0

    .line 1163
    .local v30, "$i$f$set-impl\\6\\1162":I
    move-object/from16 v32, v5

    .local v32, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 1164
    .local v33, "$i$a$-with-Updater$set$1\\7\\1163\\6":I
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v34

    if-nez v34, :cond_e

    move-object/from16 v34, v9

    .end local v9    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v34, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v35, v10

    .end local v10    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v35, "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_d

    goto :goto_7

    :cond_d
    move-object/from16 v10, v32

    goto :goto_8

    .end local v34    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .restart local v9    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v10    # "modifier\\2":Landroidx/compose/ui/Modifier;
    :cond_e
    move-object/from16 v34, v9

    move-object/from16 v35, v10

    .line 1165
    .end local v9    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .restart local v34    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    :goto_7
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v32

    .end local v32    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1166
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v5, v9, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1168
    :goto_8
    nop

    .line 1163
    .end local v10    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-with-Updater$set$1\\7\\1163\\6":I
    nop

    .line 1168
    nop

    .line 1169
    .end local v8    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v30    # "$i$f$set-impl\\6\\1162":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v4, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1170
    nop

    .line 1158
    .end local v5    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\1158\\3":I
    nop

    .line 1171
    shr-int/lit8 v5, v24, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\8":I
    move-object v8, v6

    .local v8, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 1172
    .local v9, "$i$a$-Layout-ColumnKt$Column$1\\8\\1171\\2":I
    const v10, -0x16ef5699

    move-object/from16 v29, v4

    .end local v4    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v29, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v4, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v8, v10, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v30, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v32, v11, 0x6

    and-int/lit8 v32, v32, 0x70

    or-int/lit8 v32, v32, 0x6

    .local v32, "$changed\\9":I
    move-object/from16 v10, v30

    check-cast v10, Landroidx/compose/foundation/layout/ColumnScope;

    .local v10, "$this$StoreDetails_u24lambda_u2485\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v57, v8

    .local v57, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 440
    .local v30, "$i$a$-Column-StoreScreenKt$StoreDetails$1\\9\\1172\\0":I
    move/from16 v61, v5

    .end local v5    # "$changed\\8":I
    .local v61, "$changed\\8":I
    const v5, 0x50c27d8e

    move-object/from16 v62, v8

    .end local v8    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v8, "C439@26158L1033,452@27326L10,452@27371L11,452@27263L211,455@27628L11,455@27515L1829,475@29353L30,488@30367L29,490@30484L61,491@30788L173,490@30467L494,494@30970L30:StoreScreen.kt#o13vsk"

    move/from16 v63, v9

    move-object/from16 v9, v57

    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v63, "$i$a$-Layout-ColumnKt$Column$1\\8\\1171\\2":I
    invoke-static {v9, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v8, 0x8

    .local v8, "$this$dp\\10":I
    const/16 v36, 0x0

    .line 1173
    .local v36, "$i$f$getDp\\10\\440":I
    move/from16 v64, v11

    .end local v11    # "$changed\\2":I
    .local v64, "$changed\\2":I
    int-to-float v11, v8

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 440
    .end local v8    # "$this$dp\\10":I
    .end local v36    # "$i$f$getDp\\10\\440":I
    const/4 v11, 0x1

    move-object/from16 v65, v12

    move/from16 v66, v14

    const/4 v12, 0x0

    const/4 v14, 0x0

    .end local v12    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "$i$f$Column\\2\\439":I
    .local v65, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v66, "$i$f$Column\\2\\439":I
    invoke-static {v5, v12, v8, v11, v14}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v8

    .local v8, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v12, 0x186

    .local v12, "$changed\\11":I
    const/4 v14, 0x0

    .line 1174
    .local v14, "$i$f$Row\\11\\440":I
    move/from16 v67, v11

    const v11, 0x2952b718

    move/from16 v36, v12

    .end local v12    # "$changed\\11":I
    .local v36, "$changed\\11":I
    const-string v12, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v9, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1175
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    .line 1179
    .local v11, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v12, v36, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v37, v36, 0x3

    and-int/lit8 v37, v37, 0x70

    or-int v12, v12, v37

    invoke-static {v11, v8, v9, v12}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v37, v36, 0x3

    and-int/lit8 v37, v37, 0x70

    .line 1180
    nop

    .local v37, "$changed\\12":I
    const/16 v38, 0x0

    .line 1181
    .local v38, "$i$f$Layout\\12\\1180":I
    move-object/from16 v39, v8

    const v8, -0x4ee9b9da

    .end local v8    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v39, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v9, v8, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1182
    const/4 v8, 0x0

    invoke-static {v9, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v40

    .line 1183
    .local v40, "compositeKeyHash\\12":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 1184
    .local v8, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v41, v11

    .end local v11    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v41, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v9, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 1186
    .local v11, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v42, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v42 .. v42}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v42

    move-object/from16 v43, v5

    .end local v5    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v37, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 1185
    nop

    .local v5, "$changed\\13":I
    move-object/from16 v44, v42

    .local v44, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v42, 0x0

    .line 1187
    .local v42, "$i$f$ReusableComposeNode\\13\\1185":I
    move/from16 v45, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\13":I
    .local v45, "$changed\\13":I
    invoke-static {v9, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1188
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1189
    :cond_f
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1190
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_10

    .line 1191
    move-object/from16 v5, v44

    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 1193
    .end local v5    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v5, v44

    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1195
    :goto_9
    move-object/from16 v44, v5

    .end local v5    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 1196
    .local v46, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1195\\12":I
    sget-object v47, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v48, v14

    .end local v14    # "$i$f$Row\\11\\440":I
    .local v48, "$i$f$Row\\11\\440":I
    invoke-virtual/range {v47 .. v47}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v5, v12, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1197
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    invoke-static {v5, v8, v14}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1199
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    .local v14, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v47, 0x0

    .line 1200
    .local v47, "$i$f$set-impl\\15\\1199":I
    move-object/from16 v49, v5

    .local v49, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v50, 0x0

    .line 1201
    .local v50, "$i$a$-with-Updater$set$1\\16\\1200\\15":I
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v51

    if-nez v51, :cond_12

    move-object/from16 v51, v8

    .end local v8    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v51, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v52, v12

    .end local v12    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v52, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-static {v8, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_11

    goto :goto_a

    :cond_11
    move-object/from16 v12, v49

    goto :goto_b

    .end local v51    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v52    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v8    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v12    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_12
    move-object/from16 v51, v8

    move-object/from16 v52, v12

    .line 1202
    .end local v8    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v51    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v52    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_a
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    move-object/from16 v12, v49

    .end local v49    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v12, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1203
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v5, v8, v14}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1205
    :goto_b
    nop

    .line 1200
    .end local v12    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-with-Updater$set$1\\16\\1200\\15":I
    nop

    .line 1205
    nop

    .line 1206
    .end local v14    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v47    # "$i$f$set-impl\\15\\1199":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v11, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1207
    nop

    .line 1195
    .end local v5    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v46    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\1195\\12":I
    nop

    .line 1208
    shr-int/lit8 v5, v45, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\17":I
    move-object v8, v9

    .local v8, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1209
    .local v12, "$i$a$-Layout-RowKt$Row$1\\17\\1208\\11":I
    const v14, -0x184f2606

    move/from16 v46, v5

    .end local v5    # "$changed\\17":I
    .local v46, "$changed\\17":I
    const-string v5, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v8, v14, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v14, v36, 0x6

    and-int/lit8 v14, v14, 0x70

    or-int/lit8 v14, v14, 0x6

    .local v14, "$changed\\18":I
    check-cast v5, Landroidx/compose/foundation/layout/RowScope;

    .local v5, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2465\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v56, v8

    .local v56, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 441
    .local v47, "$i$a$-Row-StoreScreenKt$StoreDetails$1$1\\18\\1209\\9":I
    move-object/from16 v49, v5

    .end local v5    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2465\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v49, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2465\\18":Landroidx/compose/foundation/layout/RowScope;
    const v5, -0x7247db3e

    move-object/from16 v50, v8

    .end local v8    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v8, "C440@26259L55,441@26327L29,442@26369L812:StoreScreen.kt#o13vsk"

    move-object/from16 v59, v11

    move-object/from16 v11, v56

    .end local v56    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v59, "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static {v11, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v5, "icon_url"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-nez v8, :cond_13

    move/from16 v8, v67

    goto :goto_c

    :cond_13
    const/4 v8, 0x0

    :goto_c
    if-eqz v8, :cond_14

    .line 587
    const/4 v5, 0x0

    .line 441
    .local v5, "$i$a$-ifEmpty-StoreScreenKt$StoreDetails$1$1$1\\19\\441\\18":I
    const/4 v5, 0x0

    .end local v5    # "$i$a$-ifEmpty-StoreScreenKt$StoreDetails$1$1$1\\19\\441\\18":I
    :cond_14
    move-object/from16 v53, v5

    check-cast v53, Ljava/lang/String;

    const/16 v57, 0x30

    const/16 v58, 0x4

    const/16 v54, 0x48

    const/16 v55, 0x0

    move-object/from16 v56, v11

    .end local v11    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v56    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v53 .. v58}, Lorg/lighttouch/android/StoreScreenKt;->AppIcon(Ljava/lang/String;ILjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 442
    .end local v56    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\18":Landroidx/compose/runtime/Composer;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v8, 0x10

    .local v8, "$this$dp\\20":I
    const/16 v53, 0x0

    .line 1210
    .local v53, "$i$f$getDp\\20\\442":I
    move/from16 v54, v12

    .end local v12    # "$i$a$-Layout-RowKt$Row$1\\17\\1208\\11":I
    .local v54, "$i$a$-Layout-RowKt$Row$1\\17\\1208\\11":I
    int-to-float v12, v8

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 442
    .end local v8    # "$this$dp\\20":I
    .end local v53    # "$i$f$getDp\\20\\442":I
    invoke-static {v5, v8}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    move/from16 v8, v26

    invoke-static {v5, v11, v8}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 443
    const/16 v22, 0x0

    move/from16 v5, v22

    .local v5, "$changed\\21":I
    const/4 v8, 0x0

    .line 1211
    .local v8, "$i$f$Column\\21\\443":I
    const v12, -0x1cd0f17e

    invoke-static {v11, v12, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1212
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    .line 1213
    .local v12, "modifier\\21":Landroidx/compose/ui/Modifier;
    sget-object v53, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move/from16 v55, v5

    .end local v5    # "$changed\\21":I
    .local v55, "$changed\\21":I
    invoke-virtual/range {v53 .. v53}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v5

    .line 1214
    .local v5, "verticalArrangement\\21":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v53, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v56, v8

    .end local v8    # "$i$f$Column\\21\\443":I
    .local v56, "$i$f$Column\\21\\443":I
    invoke-virtual/range {v53 .. v53}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 1217
    .local v8, "horizontalAlignment\\21":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v53, v55, 0x3

    and-int/lit8 v53, v53, 0xe

    shr-int/lit8 v57, v55, 0x3

    and-int/lit8 v57, v57, 0x70

    move/from16 v58, v14

    .end local v14    # "$changed\\18":I
    .local v58, "$changed\\18":I
    or-int v14, v53, v57

    invoke-static {v5, v8, v11, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v53, v55, 0x3

    and-int/lit8 v53, v53, 0x70

    .line 1218
    nop

    .local v53, "$changed\\22":I
    const/16 v57, 0x0

    .line 1219
    .local v57, "$i$f$Layout\\22\\1218":I
    move-object/from16 v60, v5

    const v5, -0x4ee9b9da

    .end local v5    # "verticalArrangement\\21":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v60, "verticalArrangement\\21":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v11, v5, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1220
    const/4 v5, 0x0

    invoke-static {v11, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v68

    .line 1221
    .local v68, "compositeKeyHash\\22":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 1222
    .local v5, "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v69, v8

    .end local v8    # "horizontalAlignment\\21":Landroidx/compose/ui/Alignment$Horizontal;
    .local v69, "horizontalAlignment\\21":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v11, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 1224
    .local v8, "materialized\\22":Landroidx/compose/ui/Modifier;
    sget-object v70, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v70 .. v70}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v70

    move-object/from16 v71, v12

    .end local v12    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v71, "modifier\\21":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v12, v53, 0x6

    and-int/lit16 v12, v12, 0x380

    const/16 v26, 0x6

    or-int/lit8 v12, v12, 0x6

    .line 1223
    nop

    .local v12, "$changed\\23":I
    move-object/from16 v72, v70

    .local v72, "factory\\23":Lkotlin/jvm/functions/Function0;
    const/16 v70, 0x0

    .line 1225
    .local v70, "$i$f$ReusableComposeNode\\23\\1223":I
    move/from16 v73, v12

    const v12, -0x2942ffcf

    .end local v12    # "$changed\\23":I
    .local v73, "$changed\\23":I
    invoke-static {v11, v12, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1226
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v12

    instance-of v12, v12, Landroidx/compose/runtime/Applier;

    if-nez v12, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1227
    :cond_15
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1228
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-eqz v12, :cond_16

    .line 1229
    move-object/from16 v12, v72

    .end local v72    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .local v12, "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11, v12}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 1231
    .end local v12    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .restart local v72    # "factory\\23":Lkotlin/jvm/functions/Function0;
    :cond_16
    move-object/from16 v12, v72

    .end local v72    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .restart local v12    # "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1233
    :goto_d
    move-object/from16 v72, v11

    .end local v11    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v72, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .local v11, "$this$Layout_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v74, 0x0

    .line 1234
    .local v74, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\24\\1233\\22":I
    sget-object v75, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v76, v12

    .end local v12    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .local v76, "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v75 .. v75}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    invoke-static {v11, v14, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1235
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    invoke-static {v11, v5, v12}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1237
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v12

    .local v12, "block\\25":Lkotlin/jvm/functions/Function2;
    const/16 v75, 0x0

    .line 1238
    .local v75, "$i$f$set-impl\\25\\1237":I
    move-object/from16 v77, v11

    .local v77, "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    const/16 v78, 0x0

    .line 1239
    .local v78, "$i$a$-with-Updater$set$1\\26\\1238\\25":I
    invoke-interface/range {v77 .. v77}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v79

    if-nez v79, :cond_18

    move-object/from16 v79, v5

    .end local v5    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .local v79, "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v77 .. v77}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v80, v14

    .end local v14    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v80, "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v68 .. v68}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v5, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_17

    goto :goto_e

    :cond_17
    move-object/from16 v14, v77

    goto :goto_f

    .end local v79    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v80    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v5    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v14    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_18
    move-object/from16 v79, v5

    move-object/from16 v80, v14

    .line 1240
    .end local v5    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v79    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v80    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_e
    invoke-static/range {v68 .. v68}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v14, v77

    .end local v77    # "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    .local v14, "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    invoke-interface {v14, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1241
    invoke-static/range {v68 .. v68}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v11, v5, v12}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1243
    :goto_f
    nop

    .line 1238
    .end local v14    # "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    .end local v78    # "$i$a$-with-Updater$set$1\\26\\1238\\25":I
    nop

    .line 1243
    nop

    .line 1244
    .end local v12    # "block\\25":Lkotlin/jvm/functions/Function2;
    .end local v75    # "$i$f$set-impl\\25\\1237":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v11, v8, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1245
    nop

    .line 1233
    .end local v11    # "$this$Layout_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v74    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\24\\1233\\22":I
    nop

    .line 1246
    shr-int/lit8 v5, v73, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\27":I
    move-object/from16 v11, v72

    .local v11, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 1247
    .local v12, "$i$a$-Layout-ColumnKt$Column$1\\27\\1246\\21":I
    const v14, -0x16ef5699

    invoke-static {v11, v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v14, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v74, v55, 0x6

    and-int/lit8 v74, v74, 0x70

    const/16 v26, 0x6

    or-int/lit8 v74, v74, 0x6

    .local v74, "$changed\\28":I
    check-cast v14, Landroidx/compose/foundation/layout/ColumnScope;

    .local v14, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2465_u24lambda_u2464\\28":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v102, v11

    .local v102, "$composer\\28":Landroidx/compose/runtime/Composer;
    const/16 v75, 0x0

    .line 444
    .local v75, "$i$a$-Column-StoreScreenKt$StoreDetails$1$1$2\\28\\1247\\18":I
    move/from16 v77, v5

    .end local v5    # "$changed\\27":I
    .local v77, "$changed\\27":I
    const v5, -0x6305e3d3

    move-object/from16 v78, v8

    .end local v8    # "materialized\\22":Landroidx/compose/ui/Modifier;
    .local v78, "materialized\\22":Landroidx/compose/ui/Modifier;
    const-string v8, "C443@26444L10,443@26394L120,444@26620L10,444@26665L11,444@26531L163:StoreScreen.kt#o13vsk"

    move-object/from16 v106, v11

    .end local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v106, "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static {v11, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v5, "name"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v8, "optString(...)"

    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v81, v5

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v11, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v101

    sget-object v5, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v96

    const/16 v104, 0xc30

    const v105, 0xd7fe

    const/16 v82, 0x0

    const-wide/16 v83, 0x0

    const-wide/16 v85, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x0

    const-wide/16 v90, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x2

    const/16 v99, 0x0

    const/16 v100, 0x0

    const/16 v103, 0x0

    .end local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static/range {v81 .. v105}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 445
    .end local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    const-string v5, "developer"

    invoke-static {v3, v5}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_1a

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getInfo()Lorg/json/JSONObject;

    move-result-object v5

    if-eqz v5, :cond_19

    const-string v8, "developer"

    invoke-static {v5, v8}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_10

    :cond_19
    const/4 v5, 0x0

    :goto_10
    if-nez v5, :cond_1a

    const-string v5, ""

    :cond_1a
    move-object/from16 v81, v5

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v11, v8}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v101

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v11, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v83

    const/16 v104, 0x0

    const v105, 0xfffa

    const/16 v82, 0x0

    const-wide/16 v85, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x0

    const-wide/16 v90, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const/16 v103, 0x0

    move-object/from16 v102, v11

    .end local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static/range {v81 .. v105}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 446
    .end local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getInfo()Lorg/json/JSONObject;

    move-result-object v5

    const v8, 0x369cddd4

    invoke-interface {v11, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v8, ""

    invoke-static {v11, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v5, :cond_1b

    goto/16 :goto_14

    .line 587
    .local v5, "info\\29":Lorg/json/JSONObject;
    :cond_1b
    const/4 v8, 0x0

    .line 446
    .local v8, "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$1\\29\\446\\28":I
    move/from16 v107, v8

    const/4 v3, 0x2

    .end local v8    # "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$1\\29\\446\\28":I
    .local v107, "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$1\\29\\446\\28":I
    new-array v8, v3, [Ljava/lang/String;

    const-string v3, "genre"

    invoke-static {v5, v3}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v22, 0x0

    aput-object v3, v8, v22

    const-string v3, "original_release_date"

    invoke-static {v5, v3}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1c

    move-object/from16 v108, v5

    const/4 v5, 0x4

    .end local v5    # "info\\29":Lorg/json/JSONObject;
    .local v108, "info\\29":Lorg/json/JSONObject;
    invoke-static {v3, v5}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    goto :goto_11

    .end local v108    # "info\\29":Lorg/json/JSONObject;
    .restart local v5    # "info\\29":Lorg/json/JSONObject;
    :cond_1c
    move-object/from16 v108, v5

    .end local v5    # "info\\29":Lorg/json/JSONObject;
    .restart local v108    # "info\\29":Lorg/json/JSONObject;
    const/4 v3, 0x0

    :goto_11
    aput-object v3, v8, v67

    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    move-object v5, v3

    .line 587
    .local v5, "it\\30":Ljava/util/List;
    const/4 v8, 0x0

    .line 446
    .local v8, "$i$a$-takeIf-StoreScreenKt$StoreDetails$1$1$2$1$1\\30\\446\\29":I
    move-object/from16 v17, v5

    check-cast v17, Ljava/util/Collection;

    invoke-interface/range {v17 .. v17}, Ljava/util/Collection;->isEmpty()Z

    move-result v17

    .end local v5    # "it\\30":Ljava/util/List;
    .end local v8    # "$i$a$-takeIf-StoreScreenKt$StoreDetails$1$1$2$1$1\\30\\446\\29":I
    if-nez v17, :cond_1d

    goto :goto_12

    :cond_1d
    const/4 v3, 0x0

    :goto_12
    const v5, 0x369cec79

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "*446@26921L10,446@26965L11,446@26870L124"

    invoke-static {v11, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v3, :cond_1e

    goto :goto_13

    .local v3, "it\\31":Ljava/util/List;
    :cond_1e
    const/4 v5, 0x0

    .line 447
    .local v5, "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$1$2\\31\\446\\29":I
    move-object/from16 v81, v3

    check-cast v81, Ljava/lang/Iterable;

    const-string v8, " \u00b7 "

    move-object/from16 v82, v8

    check-cast v82, Ljava/lang/CharSequence;

    const/16 v88, 0x3e

    const/16 v89, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    invoke-static/range {v81 .. v89}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v81

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v17, v3

    .end local v3    # "it\\31":Ljava/util/List;
    .local v17, "it\\31":Ljava/util/List;
    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v11, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v101

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v11, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v83

    const/16 v104, 0x0

    const v105, 0xfffa

    const/16 v82, 0x0

    const-wide/16 v85, 0x0

    const/16 v88, 0x0

    const-wide/16 v90, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const/16 v103, 0x0

    move-object/from16 v102, v11

    .end local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static/range {v81 .. v105}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 448
    .end local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    nop

    .end local v5    # "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$1$2\\31\\446\\29":I
    .end local v17    # "it\\31":Ljava/util/List;
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 446
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_13
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 448
    nop

    .line 446
    .end local v107    # "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$1\\29\\446\\28":I
    .end local v108    # "info\\29":Lorg/json/JSONObject;
    nop

    :goto_14
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v3, 0x369d05e7

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*448@27099L10,448@27145L11,448@27055L110"

    invoke-static {v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 449
    if-nez v0, :cond_1f

    goto :goto_15

    :cond_1f
    move-object v3, v0

    .line 587
    .local v3, "it\\32":Ljava/lang/String;
    const/4 v5, 0x0

    .line 449
    .local v5, "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$2\\32\\449\\28":I
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v17, v5

    .end local v5    # "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$2\\32\\449\\28":I
    .local v17, "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$2\\32\\449\\28":I
    const-string v5, "\u5df2\u5b89\u88c5 "

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v81

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v11, v8}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v101

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v11, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v83

    const/16 v104, 0x0

    const v105, 0xfffa

    const/16 v82, 0x0

    const-wide/16 v85, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x0

    const-wide/16 v90, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const/16 v103, 0x0

    move-object/from16 v102, v11

    .end local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static/range {v81 .. v105}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v3    # "it\\32":Ljava/lang/String;
    .end local v17    # "$i$a$-let-StoreScreenKt$StoreDetails$1$1$2$2\\32\\449\\28":I
    .end local v102    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_15
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 444
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 450
    nop

    .line 1247
    .end local v11    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v14    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2465_u24lambda_u2464\\28":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v74    # "$changed\\28":I
    .end local v75    # "$i$a$-Column-StoreScreenKt$StoreDetails$1$1$2\\28\\1247\\18":I
    invoke-static/range {v106 .. v106}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1246
    .end local v12    # "$i$a$-Layout-ColumnKt$Column$1\\27\\1246\\21":I
    .end local v77    # "$changed\\27":I
    .end local v106    # "$composer\\27":Landroidx/compose/runtime/Composer;
    nop

    .line 1248
    invoke-interface/range {v72 .. v72}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1225
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1249
    nop

    .line 1219
    .end local v70    # "$i$f$ReusableComposeNode\\23\\1223":I
    .end local v73    # "$changed\\23":I
    .end local v76    # "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1250
    nop

    .line 1211
    .end local v53    # "$changed\\22":I
    .end local v57    # "$i$f$Layout\\22\\1218":I
    .end local v68    # "compositeKeyHash\\22":I
    .end local v78    # "materialized\\22":Landroidx/compose/ui/Modifier;
    .end local v79    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1251
    nop

    .line 441
    .end local v55    # "$changed\\21":I
    .end local v56    # "$i$f$Column\\21\\443":I
    .end local v60    # "verticalArrangement\\21":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v69    # "horizontalAlignment\\21":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v71    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .end local v80    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v72 .. v72}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 451
    nop

    .line 1209
    .end local v47    # "$i$a$-Row-StoreScreenKt$StoreDetails$1$1\\18\\1209\\9":I
    .end local v49    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2465\\18":Landroidx/compose/foundation/layout/RowScope;
    .end local v58    # "$changed\\18":I
    .end local v72    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1208
    .end local v46    # "$changed\\17":I
    .end local v50    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-Layout-RowKt$Row$1\\17\\1208\\11":I
    nop

    .line 1252
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1187
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1253
    nop

    .line 1181
    .end local v42    # "$i$f$ReusableComposeNode\\13\\1185":I
    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .end local v45    # "$changed\\13":I
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1254
    nop

    .line 1174
    .end local v37    # "$changed\\12":I
    .end local v38    # "$i$f$Layout\\12\\1180":I
    .end local v40    # "compositeKeyHash\\12":I
    .end local v51    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v59    # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1255
    nop

    .end local v36    # "$changed\\11":I
    .end local v39    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v41    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v43    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v48    # "$i$f$Row\\11\\440":I
    .end local v52    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    const v3, -0x607d6b5f

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "451@27230L24"

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 452
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getShots()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_20

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getShots()Ljava/util/List;

    move-result-object v3

    const/4 v5, 0x0

    invoke-static {v3, v9, v5}, Lorg/lighttouch/android/StoreScreenKt;->Screenshots(Ljava/util/List;Landroidx/compose/runtime/Composer;I)V

    :cond_20
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 453
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v9, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v56

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v9, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v38

    .line 454
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v40, v3

    check-cast v40, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x4

    .local v3, "$this$dp\\33":I
    const/4 v5, 0x0

    .line 1256
    .local v5, "$i$f$getDp\\33\\454":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v41

    .line 454
    .end local v3    # "$this$dp\\33":I
    .end local v5    # "$i$f$getDp\\33\\454":I
    const/16 v3, 0xc

    .local v3, "$this$dp\\34":I
    const/4 v5, 0x0

    .line 1256
    .local v5, "$i$f$getDp\\34\\454":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v42

    .line 454
    .end local v3    # "$this$dp\\34":I
    .end local v5    # "$i$f$getDp\\34\\454":I
    const/16 v3, 0x8

    .local v3, "$this$dp\\35":I
    const/4 v5, 0x0

    .line 1256
    .local v5, "$i$f$getDp\\35\\454":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v44

    .line 454
    .end local v3    # "$this$dp\\35":I
    .end local v5    # "$i$f$getDp\\35\\454":I
    const/16 v45, 0x4

    const/16 v46, 0x0

    const/16 v43, 0x0

    invoke-static/range {v40 .. v46}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    .line 453
    nop

    .line 454
    nop

    .line 453
    const/16 v59, 0x0

    const v60, 0xfff8

    const-string v36, "\u53ef\u5728\u8be5\u8bbe\u5907\u8fd0\u884c\u7684\u7248\u672c"

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v58, 0x36

    move-object/from16 v57, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v57, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v60}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 455
    .end local v57    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getCopies()Ljava/util/List;

    move-result-object v3

    .line 456
    .local v3, "rows\\9":Ljava/util/List;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v11, 0x0

    invoke-interface {v10, v5, v8, v11}, Landroidx/compose/foundation/layout/ColumnScope;->weight(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;

    move-result-object v5

    move/from16 v8, v67

    const/4 v12, 0x0

    const/4 v14, 0x0

    invoke-static {v5, v12, v8, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/16 v8, 0x14

    .local v8, "$this$dp\\36":I
    const/4 v11, 0x0

    .line 1257
    .local v11, "$i$f$getDp\\36\\456":I
    int-to-float v12, v8

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 456
    .end local v8    # "$this$dp\\36":I
    .end local v11    # "$i$f$getDp\\36\\456":I
    invoke-static {v8}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v8

    check-cast v8, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v5, v8}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v36

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v9, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getSurfaceContainer-0d7_KjU()J

    move-result-wide v37

    const/16 v40, 0x2

    const/16 v41, 0x0

    const/16 v39, 0x0

    invoke-static/range {v36 .. v41}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\37":Landroidx/compose/ui/Modifier;
    const/4 v8, 0x0

    .local v8, "$changed\\37":I
    const/4 v11, 0x0

    .line 1258
    .local v11, "$i$f$Column\\37\\456":I
    const v12, -0x1cd0f17e

    invoke-static {v9, v12, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1259
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v1}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v1

    .line 1260
    .local v1, "verticalArrangement\\37":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v12

    .line 1263
    .local v12, "horizontalAlignment\\37":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v14, v8, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v17, v8, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v14, v14, v17

    invoke-static {v1, v12, v9, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\37":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v8, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 1264
    nop

    .local v17, "$changed\\38":I
    const/16 v19, 0x0

    .line 1265
    .local v19, "$i$f$Layout\\38\\1264":I
    move-object/from16 v36, v1

    const v1, -0x4ee9b9da

    .end local v1    # "verticalArrangement\\37":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v36, "verticalArrangement\\37":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v9, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1266
    const/4 v1, 0x0

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v13

    .line 1267
    .local v13, "compositeKeyHash\\38":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 1268
    .local v1, "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v20, v8

    .end local v8    # "$changed\\37":I
    .local v20, "$changed\\37":I
    invoke-static {v9, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 1270
    .local v8, "materialized\\38":Landroidx/compose/ui/Modifier;
    sget-object v37, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v37 .. v37}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v37

    move-object/from16 v38, v5

    .end local v5    # "modifier\\37":Landroidx/compose/ui/Modifier;
    .local v38, "modifier\\37":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v17, 0x6

    and-int/lit16 v5, v5, 0x380

    const/16 v26, 0x6

    or-int/lit8 v5, v5, 0x6

    .line 1269
    move-object/from16 v39, v37

    .local v5, "$changed\\39":I
    .local v39, "factory\\39":Lkotlin/jvm/functions/Function0;
    const/16 v37, 0x0

    .line 1271
    .local v37, "$i$f$ReusableComposeNode\\39\\1269":I
    move/from16 v40, v5

    const v5, -0x2942ffcf

    .end local v5    # "$changed\\39":I
    .local v40, "$changed\\39":I
    invoke-static {v9, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 1272
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_21

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 1273
    :cond_21
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 1274
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_22

    .line 1275
    move-object/from16 v5, v39

    .end local v39    # "factory\\39":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\39":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_16

    .line 1277
    .end local v5    # "factory\\39":Lkotlin/jvm/functions/Function0;
    .restart local v39    # "factory\\39":Lkotlin/jvm/functions/Function0;
    :cond_22
    move-object/from16 v5, v39

    .end local v39    # "factory\\39":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\39":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 1279
    :goto_16
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 1280
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\40\\1279\\38":I
    sget-object v39, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v41, v5

    .end local v5    # "factory\\39":Lkotlin/jvm/functions/Function0;
    .local v41, "factory\\39":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v7, v14, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1281
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v7, v1, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1283
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\41":Lkotlin/jvm/functions/Function2;
    const/16 v39, 0x0

    .line 1284
    .local v39, "$i$f$set-impl\\41\\1283":I
    move-object/from16 v42, v7

    .local v42, "$this$set_impl_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 1285
    .local v43, "$i$a$-with-Updater$set$1\\42\\1284\\41":I
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v44

    if-nez v44, :cond_24

    move-object/from16 v44, v1

    .end local v1    # "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    .local v44, "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v42 .. v42}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v45, v11

    .end local v11    # "$i$f$Column\\37\\456":I
    .local v45, "$i$f$Column\\37\\456":I
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v1, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_23

    goto :goto_17

    :cond_23
    move-object/from16 v11, v42

    goto :goto_18

    .end local v44    # "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v45    # "$i$f$Column\\37\\456":I
    .restart local v1    # "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v11    # "$i$f$Column\\37\\456":I
    :cond_24
    move-object/from16 v44, v1

    move/from16 v45, v11

    .line 1286
    .end local v1    # "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v11    # "$i$f$Column\\37\\456":I
    .restart local v44    # "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v45    # "$i$f$Column\\37\\456":I
    :goto_17
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v11, v42

    .end local v42    # "$this$set_impl_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    .local v11, "$this$set_impl_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1287
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v7, v1, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1289
    :goto_18
    nop

    .line 1284
    .end local v11    # "$this$set_impl_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-with-Updater$set$1\\42\\1284\\41":I
    nop

    .line 1289
    nop

    .line 1290
    .end local v5    # "block\\41":Lkotlin/jvm/functions/Function2;
    .end local v39    # "$i$f$set-impl\\41\\1283":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v7, v8, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1291
    nop

    .line 1279
    .end local v7    # "$this$Layout_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\40\\1279\\38":I
    nop

    .line 1292
    shr-int/lit8 v1, v40, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\43":I
    move-object v5, v9

    .local v5, "$composer\\43":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1293
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    const v11, -0x16ef5699

    invoke-static {v5, v11, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v11, v20, 0x6

    and-int/lit8 v11, v11, 0x70

    const/16 v26, 0x6

    or-int/lit8 v11, v11, 0x6

    .local v11, "$changed\\44":I
    check-cast v4, Landroidx/compose/foundation/layout/ColumnScope;

    .local v4, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478\\44":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v53, v5

    .local v53, "$composer\\44":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 457
    .local v28, "$i$a$-Column-StoreScreenKt$StoreDetails$1$2\\44\\1293\\9":I
    move/from16 v33, v1

    .end local v1    # "$changed\\43":I
    .local v33, "$changed\\43":I
    const v1, -0x6af09baf

    move-object/from16 v39, v4

    .end local v4    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478\\44":Landroidx/compose/foundation/layout/ColumnScope;
    .local v39, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478\\44":Landroidx/compose/foundation/layout/ColumnScope;
    const-string v4, "C459@28075L23,460@28132L110,460@28111L131,461@28372L962,461@28255L1079:StoreScreen.kt#o13vsk"

    move-object/from16 v42, v5

    .end local v53    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\44":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    if-nez v3, :cond_25

    const v1, 0x786bd5f4

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "456@27691L63"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    move-object/from16 v53, v5

    move/from16 v43, v7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v7, 0x0

    .end local v5    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    .local v43, "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    .restart local v53    # "$composer\\44":Landroidx/compose/runtime/Composer;
    invoke-static {v1, v4, v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v4, 0x10

    .local v4, "$this$dp\\45":I
    const/4 v5, 0x0

    .line 1294
    .local v5, "$i$f$getDp\\45\\457":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 457
    .end local v4    # "$this$dp\\45":I
    .end local v5    # "$i$f$getDp\\45\\457":I
    invoke-static {v1, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v46

    const/16 v54, 0x6

    const/16 v55, 0x1e

    const-wide/16 v47, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    invoke-static/range {v46 .. v55}, Landroidx/compose/material3/ProgressIndicatorKt;->LinearProgressIndicator-rIrjwxo(Landroidx/compose/ui/Modifier;JJIFLandroidx/compose/runtime/Composer;II)V

    move-object/from16 v5, v53

    .end local v53    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\44":Landroidx/compose/runtime/Composer;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_1a

    .line 458
    .end local v43    # "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    .restart local v7    # "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    :cond_25
    move/from16 v43, v7

    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    .restart local v43    # "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_26

    const v1, -0x6aef86a0

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "457@27859L10,457@27904L11,457@27792L141"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x10

    .local v4, "$this$dp\\46":I
    const/4 v7, 0x0

    .line 1295
    .local v7, "$i$f$getDp\\46\\458":I
    move/from16 v46, v7

    .end local v7    # "$i$f$getDp\\46\\458":I
    .local v46, "$i$f$getDp\\46\\458":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 458
    .end local v4    # "$this$dp\\46":I
    .end local v46    # "$i$f$getDp\\46\\458":I
    invoke-static {v1, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v69

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v88

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v70

    const/16 v91, 0x0

    const v92, 0xfff8

    const-string v68, "\u672a\u627e\u5230\u3002"

    const-wide/16 v72, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const-wide/16 v77, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const-wide/16 v81, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const/16 v90, 0x36

    move-object/from16 v89, v5

    .end local v5    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .local v89, "$composer\\44":Landroidx/compose/runtime/Composer;
    invoke-static/range {v68 .. v92}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v89    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\44":Landroidx/compose/runtime/Composer;
    goto :goto_19

    :cond_26
    const v1, -0x6aed7553

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_19
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_1a
    nop

    .line 460
    const/4 v1, 0x3

    const/4 v4, 0x0

    invoke-static {v4, v4, v5, v4, v1}, Landroidx/compose/foundation/lazy/LazyListStateKt;->rememberLazyListState(IILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/lazy/LazyListState;

    move-result-object v1

    .line 461
    .local v1, "versionList\\44":Landroidx/compose/foundation/lazy/LazyListState;
    const v4, -0x6815fd56

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v46

    or-int v7, v7, v46

    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v46

    or-int v7, v7, v46

    .local v7, "invalid\\47":Z
    move-object/from16 v46, v5

    .local v46, "$this$cache\\47":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 1296
    .local v47, "$i$f$cache\\47\\461":I
    move/from16 v48, v7

    .end local v7    # "invalid\\47":Z
    .local v48, "invalid\\47":Z
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\47":Ljava/lang/Object;
    const/16 v49, 0x0

    .line 1297
    .local v49, "$i$a$-let-ComposerKt$cache$1\\48\\1296\\47":I
    if-nez v48, :cond_28

    sget-object v50, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v58, v8

    .end local v8    # "materialized\\38":Landroidx/compose/ui/Modifier;
    .local v58, "materialized\\38":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v50 .. v50}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v7, v8, :cond_27

    goto :goto_1b

    .line 1301
    :cond_27
    move-object/from16 v50, v7

    move-object/from16 v8, v46

    goto :goto_1c

    .line 1297
    .end local v58    # "materialized\\38":Landroidx/compose/ui/Modifier;
    .restart local v8    # "materialized\\38":Landroidx/compose/ui/Modifier;
    :cond_28
    move-object/from16 v58, v8

    .line 1298
    .end local v8    # "materialized\\38":Landroidx/compose/ui/Modifier;
    .restart local v58    # "materialized\\38":Landroidx/compose/ui/Modifier;
    :goto_1b
    const/4 v8, 0x0

    .line 461
    .local v8, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$1\\49\\1298\\44":I
    move-object/from16 v50, v7

    .end local v7    # "it\\47":Ljava/lang/Object;
    .local v50, "it\\47":Ljava/lang/Object;
    new-instance v7, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$2$1$1;

    move/from16 v51, v8

    const/4 v8, 0x0

    .end local v8    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$1\\49\\1298\\44":I
    .local v51, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$1\\49\\1298\\44":I
    invoke-direct {v7, v3, v2, v1, v8}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$2$1$1;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListState;Lkotlin/coroutines/Continuation;)V

    check-cast v7, Lkotlin/jvm/functions/Function2;

    .line 1298
    .end local v51    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$1\\49\\1298\\44":I
    nop

    .line 1299
    .local v7, "value\\48":Ljava/lang/Object;
    move-object/from16 v8, v46

    .end local v46    # "$this$cache\\47":Landroidx/compose/runtime/Composer;
    .local v8, "$this$cache\\47":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1300
    nop

    .line 1297
    .end local v7    # "value\\48":Ljava/lang/Object;
    :goto_1c
    nop

    .line 1296
    .end local v49    # "$i$a$-let-ComposerKt$cache$1\\48\\1296\\47":I
    .end local v50    # "it\\47":Ljava/lang/Object;
    nop

    .line 461
    .end local v8    # "$this$cache\\47":Landroidx/compose/runtime/Composer;
    .end local v47    # "$i$f$cache\\47\\461":I
    .end local v48    # "invalid\\47":Z
    check-cast v7, Lkotlin/jvm/functions/Function2;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v8, 0x0

    invoke-static {v3, v7, v5, v8}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 462
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    const-string v8, "store_versions"

    invoke-static {v7, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v46

    const/4 v7, 0x6

    .local v7, "$this$dp\\50":I
    const/4 v8, 0x0

    .line 1302
    .local v8, "$i$f$getDp\\50\\462":I
    move-object/from16 v47, v1

    .end local v1    # "versionList\\44":Landroidx/compose/foundation/lazy/LazyListState;
    .local v47, "versionList\\44":Landroidx/compose/foundation/lazy/LazyListState;
    int-to-float v1, v7

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 462
    .end local v7    # "$this$dp\\50":I
    .end local v8    # "$i$f$getDp\\50\\462":I
    move/from16 v59, v11

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v11, 0x0

    .end local v11    # "$changed\\44":I
    .local v59, "$changed\\44":I
    invoke-static {v7, v1, v8, v11}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA$default(FFILjava/lang/Object;)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v48

    const v1, -0x615d173a

    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    or-int/2addr v1, v7

    .local v1, "invalid\\51":Z
    move-object v7, v5

    .local v7, "$this$cache\\51":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 1303
    .local v8, "$i$f$cache\\51\\462":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\51":Ljava/lang/Object;
    const/16 v49, 0x0

    .line 1304
    .local v49, "$i$a$-let-ComposerKt$cache$1\\52\\1303\\51":I
    if-nez v1, :cond_2a

    sget-object v50, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v51, v1

    .end local v1    # "invalid\\51":Z
    .local v51, "invalid\\51":Z
    invoke-virtual/range {v50 .. v50}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v11, v1, :cond_29

    goto :goto_1d

    .line 1308
    :cond_29
    move-object v1, v11

    goto :goto_1e

    .line 1304
    .end local v51    # "invalid\\51":Z
    .restart local v1    # "invalid\\51":Z
    :cond_2a
    move/from16 v51, v1

    .line 1305
    .end local v1    # "invalid\\51":Z
    .restart local v51    # "invalid\\51":Z
    :goto_1d
    const/4 v1, 0x0

    .line 462
    .local v1, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2\\53\\1305\\44":I
    move/from16 v50, v1

    .end local v1    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2\\53\\1305\\44":I
    .local v50, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2\\53\\1305\\44":I
    new-instance v1, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda27;

    invoke-direct {v1, v3, v2}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda27;-><init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    .line 1305
    .end local v50    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2\\53\\1305\\44":I
    nop

    .line 1306
    .local v1, "value\\52":Ljava/lang/Object;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1307
    nop

    .line 1304
    .end local v1    # "value\\52":Ljava/lang/Object;
    :goto_1e
    nop

    .line 1303
    .end local v11    # "it\\51":Ljava/lang/Object;
    .end local v49    # "$i$a$-let-ComposerKt$cache$1\\52\\1303\\51":I
    nop

    .line 462
    .end local v7    # "$this$cache\\51":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\51\\462":I
    .end local v51    # "invalid\\51":Z
    move-object/from16 v54, v1

    check-cast v54, Lkotlin/jvm/functions/Function1;

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v56, 0x186

    const/16 v57, 0xf8

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    move-object/from16 v55, v5

    .end local v5    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\44":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v57}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 457
    .end local v55    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\44":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 475
    .end local v47    # "versionList\\44":Landroidx/compose/foundation/lazy/LazyListState;
    nop

    .line 1293
    .end local v5    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-Column-StoreScreenKt$StoreDetails$1$2\\44\\1293\\9":I
    .end local v39    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478\\44":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v59    # "$changed\\44":I
    invoke-static/range {v42 .. v42}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1292
    .end local v33    # "$changed\\43":I
    .end local v42    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .end local v43    # "$i$a$-Layout-ColumnKt$Column$1\\43\\1292\\37":I
    nop

    .line 1309
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1271
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1310
    nop

    .line 1265
    .end local v37    # "$i$f$ReusableComposeNode\\39\\1269":I
    .end local v40    # "$changed\\39":I
    .end local v41    # "factory\\39":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1311
    nop

    .line 1258
    .end local v13    # "compositeKeyHash\\38":I
    .end local v17    # "$changed\\38":I
    .end local v19    # "$i$f$Layout\\38\\1264":I
    .end local v44    # "localMap\\38":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v58    # "materialized\\38":Landroidx/compose/ui/Modifier;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1312
    nop

    .line 476
    .end local v12    # "horizontalAlignment\\37":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v14    # "measurePolicy\\37":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20    # "$changed\\37":I
    .end local v36    # "verticalArrangement\\37":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v38    # "modifier\\37":Landroidx/compose/ui/Modifier;
    .end local v45    # "$i$f$Column\\37\\456":I
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v5, 0xc

    .local v5, "$this$dp\\54":I
    const/4 v7, 0x0

    .line 1313
    .local v7, "$i$f$getDp\\54\\476":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 476
    .end local v5    # "$this$dp\\54":I
    .end local v7    # "$i$f$getDp\\54\\476":I
    invoke-static {v1, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v8, 0x6

    invoke-static {v1, v9, v8}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    sget-object v1, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v1}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$-1489468270$app_debug()Lkotlin/jvm/functions/Function4;

    move-result-object v1

    .line 477
    nop

    .line 481
    .local v1, "note\\9":Lkotlin/jvm/functions/Function4;
    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getProblem()Ljava/lang/String;

    move-result-object v5

    const v7, -0x607c309f

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "*480@29725L14"

    invoke-static {v9, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-nez v5, :cond_2b

    goto :goto_1f

    .line 587
    .local v5, "it\\55":Ljava/lang/String;
    :cond_2b
    const/4 v7, 0x0

    .line 481
    .local v7, "$i$a$-let-StoreScreenKt$StoreDetails$1$3\\55\\481\\9":I
    const/16 v67, 0x1

    invoke-static/range {v67 .. v67}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    const/16 v11, 0x1b0

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-interface {v1, v5, v8, v9, v11}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .end local v5    # "it\\55":Ljava/lang/String;
    .end local v7    # "$i$a$-let-StoreScreenKt$StoreDetails$1$3\\55\\481\\9":I
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :goto_1f
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 482
    if-eqz v3, :cond_30

    move-object v5, v3

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$firstOrNull\\56":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 1314
    .local v7, "$i$f$firstOrNull\\56\\482":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_20
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_2f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\56":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Lorg/lighttouch/android/StoreCopy;

    .local v12, "it\\57":Lorg/lighttouch/android/StoreCopy;
    const/4 v13, 0x0

    .line 482
    .local v13, "$i$a$-firstOrNull-StoreScreenKt$StoreDetails$1$chosenVersion$1\\57\\1314\\9":I
    invoke-virtual {v12}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v14

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getSelected()Ljava/lang/Integer;

    move-result-object v17

    move-object/from16 v19, v3

    if-nez v17, :cond_2c

    goto :goto_21

    .end local v3    # "rows\\9":Ljava/util/List;
    .local v19, "rows\\9":Ljava/util/List;
    :cond_2c
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-ne v14, v3, :cond_2d

    const/4 v3, 0x1

    goto :goto_22

    :cond_2d
    :goto_21
    const/4 v3, 0x0

    .line 1314
    .end local v12    # "it\\57":Lorg/lighttouch/android/StoreCopy;
    .end local v13    # "$i$a$-firstOrNull-StoreScreenKt$StoreDetails$1$chosenVersion$1\\57\\1314\\9":I
    :goto_22
    if-eqz v3, :cond_2e

    goto :goto_23

    :cond_2e
    move-object/from16 v3, v19

    goto :goto_20

    .line 1315
    .end local v11    # "element\\56":Ljava/lang/Object;
    .end local v19    # "rows\\9":Ljava/util/List;
    .restart local v3    # "rows\\9":Ljava/util/List;
    :cond_2f
    move-object/from16 v19, v3

    .end local v3    # "rows\\9":Ljava/util/List;
    .restart local v19    # "rows\\9":Ljava/util/List;
    const/4 v11, 0x0

    .line 482
    .end local v5    # "$this$firstOrNull\\56":Ljava/lang/Iterable;
    .end local v7    # "$i$f$firstOrNull\\56\\482":I
    :goto_23
    check-cast v11, Lorg/lighttouch/android/StoreCopy;

    if-eqz v11, :cond_31

    invoke-virtual {v11}, Lorg/lighttouch/android/StoreCopy;->getVersion()Ljava/lang/String;

    move-result-object v3

    goto :goto_24

    .end local v19    # "rows\\9":Ljava/util/List;
    .restart local v3    # "rows\\9":Ljava/util/List;
    :cond_30
    move-object/from16 v19, v3

    .end local v3    # "rows\\9":Ljava/util/List;
    .restart local v19    # "rows\\9":Ljava/util/List;
    :cond_31
    const/4 v3, 0x0

    .local v3, "chosenVersion\\9":Ljava/lang/String;
    :goto_24
    const v5, -0x607c20b6

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "484@30083L94"

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 483
    if-eqz v0, :cond_32

    if-eqz v3, :cond_32

    .line 484
    sget-object v5, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    const/16 v7, 0x20

    const/4 v8, 0x2

    const/4 v14, 0x0

    invoke-static {v3, v7, v14, v8, v14}, Lkotlin/text/StringsKt;->substringBefore$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v5

    .local v5, "a\\9":Ljava/util/List;
    sget-object v7, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v7, v0}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v7

    .line 485
    .local v7, "b\\9":Ljava/util/List;
    if-eqz v5, :cond_32

    if-eqz v7, :cond_32

    sget-object v8, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v8, v7, v5}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v8

    if-eqz v8, :cond_32

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "\u7248\u672c "

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v11, " \u5df2\u5b89\u88c5\u3002\u65e7\u7248\u672c\u53ef\u80fd\u65e0\u6cd5\u8bfb\u53d6\u5176\u6570\u636e\u3002"

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v22, 0x0

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    const/16 v12, 0x1b0

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-interface {v1, v8, v11, v9, v12}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .end local v5    # "a\\9":Ljava/util/List;
    .end local v7    # "b\\9":Ljava/util/List;
    :cond_32
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 487
    if-nez p3, :cond_33

    const v5, -0x607bf32a

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "486@30210L43"

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/16 v22, 0x0

    invoke-static/range {v22 .. v22}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/16 v7, 0x1b6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v8, "\u542f\u52a8\u8bbe\u5907\u4ee5\u5b89\u88c5\u3002"

    invoke-interface {v1, v8, v5, v9, v7}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_26

    .line 488
    :cond_33
    const/16 v22, 0x0

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getServicesAvailable()Z

    move-result v5

    if-nez v5, :cond_34

    const v5, -0x607be838

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "487@30297L61"

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/16 v67, 0x1

    invoke-static/range {v67 .. v67}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/16 v7, 0x1b6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v8, "\u6b64\u7248\u672c\u4e0d\u5305\u542b\u5e94\u7528\u5b89\u88c5\u529f\u80fd\u3002"

    invoke-interface {v1, v8, v5, v9, v7}, Lkotlin/jvm/functions/Function4;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_25

    :cond_34
    const v5, 0x50ffc637

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_25
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 489
    :goto_26
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v7, 0x8

    .local v7, "$this$dp\\58":I
    const/4 v8, 0x0

    .line 1316
    .local v8, "$i$f$getDp\\58\\489":I
    int-to-float v11, v7

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 489
    .end local v7    # "$this$dp\\58":I
    .end local v8    # "$i$f$getDp\\58\\489":I
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/4 v8, 0x6

    invoke-static {v5, v9, v8}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 490
    invoke-virtual/range {p1 .. p2}, Lorg/lighttouch/android/StoreModel;->queued(Lorg/json/JSONObject;)Lorg/lighttouch/android/QueueItem;

    move-result-object v14

    if-eqz v14, :cond_35

    move-object v5, v14

    .line 587
    .local v5, "it\\59":Lorg/lighttouch/android/QueueItem;
    const/4 v7, 0x0

    .line 490
    .local v7, "$i$a$-takeIf-StoreScreenKt$StoreDetails$1$inQueue$1\\59\\490\\9":I
    invoke-virtual {v5}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v5

    .end local v5    # "it\\59":Lorg/lighttouch/android/QueueItem;
    .end local v7    # "$i$a$-takeIf-StoreScreenKt$StoreDetails$1$inQueue$1\\59\\490\\9":I
    if-eqz v5, :cond_35

    goto :goto_27

    :cond_35
    const/4 v14, 0x0

    .line 491
    .local v14, "inQueue\\9":Lorg/lighttouch/android/QueueItem;
    :goto_27
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    invoke-interface {v10, v5, v7}, Landroidx/compose/foundation/layout/ColumnScope;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment$Horizontal;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/16 v7, 0x34

    .local v7, "$this$dp\\60":I
    const/4 v8, 0x0

    .line 1317
    .local v8, "$i$f$getDp\\60\\491":I
    int-to-float v11, v7

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 491
    .end local v7    # "$this$dp\\60":I
    .end local v8    # "$i$f$getDp\\60\\491":I
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const-string v7, "store_install"

    invoke-static {v5, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    .line 492
    const/16 v5, 0x28

    .local v5, "$this$dp\\61":I
    const/4 v7, 0x0

    .line 1318
    .local v7, "$i$f$getDp\\61\\492":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 492
    .end local v5    # "$this$dp\\61":I
    .end local v7    # "$i$f$getDp\\61\\492":I
    const/4 v8, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v5, v12, v8, v11}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA$default(FFILjava/lang/Object;)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v43

    if-eqz p3, :cond_36

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getServicesAvailable()Z

    move-result v5

    if-eqz v5, :cond_36

    invoke-virtual {v2}, Lorg/lighttouch/android/StoreModel;->getCandidate()Lorg/json/JSONObject;

    move-result-object v5

    if-eqz v5, :cond_36

    if-nez v14, :cond_36

    const/16 v38, 0x1

    goto :goto_28

    :cond_36
    move/from16 v38, v22

    :goto_28
    const v5, 0x4c5de2

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    .line 491
    nop

    .local v4, "invalid\\62":Z
    move-object v5, v9

    .local v5, "$this$cache\\62":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 1319
    .local v7, "$i$f$cache\\62\\491":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\62":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 1320
    .local v11, "$i$a$-let-ComposerKt$cache$1\\63\\1319\\62":I
    if-nez v4, :cond_38

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v8, v12, :cond_37

    goto :goto_29

    .line 1324
    :cond_37
    move-object v13, v8

    goto :goto_2a

    .line 1321
    :cond_38
    :goto_29
    const/4 v12, 0x0

    .line 491
    .local v12, "$i$a$-cache-StoreScreenKt$StoreDetails$1$4\\64\\1321\\9":I
    new-instance v13, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda28;

    invoke-direct {v13, v2}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda28;-><init>(Lorg/lighttouch/android/StoreModel;)V

    .line 1321
    .end local v12    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$4\\64\\1321\\9":I
    nop

    .line 1322
    .local v13, "value\\63":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1323
    nop

    .line 1320
    .end local v13    # "value\\63":Ljava/lang/Object;
    :goto_2a
    nop

    .line 1319
    .end local v8    # "it\\62":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\63\\1319\\62":I
    nop

    .line 491
    .end local v4    # "invalid\\62":Z
    .end local v5    # "$this$cache\\62":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\62\\491":I
    move-object/from16 v36, v13

    check-cast v36, Lkotlin/jvm/functions/Function0;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 492
    new-instance v4, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$5;

    invoke-direct {v4, v14, v0}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$5;-><init>(Lorg/lighttouch/android/QueueItem;Ljava/lang/String;)V

    const/16 v5, 0x36

    const v7, -0x566bca45

    const/4 v8, 0x1

    invoke-static {v7, v8, v4, v9, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    move-object/from16 v45, v4

    check-cast v45, Lkotlin/jvm/functions/Function3;

    .line 491
    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v44, 0x0

    const/high16 v47, 0x30c00000

    const/16 v48, 0x178

    move-object/from16 v46, v9

    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v48}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 495
    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0xc

    .local v5, "$this$dp\\65":I
    const/4 v7, 0x0

    .line 1325
    .local v7, "$i$f$getDp\\65\\495":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 495
    .end local v5    # "$this$dp\\65":I
    .end local v7    # "$i$f$getDp\\65\\495":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/4 v8, 0x6

    invoke-static {v4, v9, v8}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 440
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 496
    .end local v1    # "note\\9":Lkotlin/jvm/functions/Function4;
    .end local v3    # "chosenVersion\\9":Ljava/lang/String;
    .end local v14    # "inQueue\\9":Lorg/lighttouch/android/QueueItem;
    .end local v19    # "rows\\9":Ljava/util/List;
    nop

    .line 1172
    .end local v9    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v10    # "$this$StoreDetails_u24lambda_u2485\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v30    # "$i$a$-Column-StoreScreenKt$StoreDetails$1\\9\\1172\\0":I
    .end local v32    # "$changed\\9":I
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1171
    .end local v61    # "$changed\\8":I
    .end local v62    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v63    # "$i$a$-Layout-ColumnKt$Column$1\\8\\1171\\2":I
    nop

    .line 1326
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 1150
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1327
    nop

    .line 1144
    .end local v23    # "$i$f$ReusableComposeNode\\4\\1148":I
    .end local v24    # "$changed\\4":I
    .end local v25    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1328
    nop

    .line 1137
    .end local v16    # "$changed\\3":I
    .end local v18    # "$i$f$Layout\\3\\1143":I
    .end local v21    # "compositeKeyHash\\3":I
    .end local v29    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v65    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 1329
    nop

    .end local v15    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v31    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v34    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v35    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v64    # "$changed\\2":I
    .end local v66    # "$i$f$Column\\2\\439":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_39

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "installedVersion":Ljava/lang/String;
    :cond_39
    :goto_2b
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_3a

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda29;

    move-object/from16 v1, p0

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda29;-><init>(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZI)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 497
    :cond_3a
    return-void
.end method

.method private static final StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76(Ljava/util/List;Lorg/lighttouch/android/StoreModel;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .locals 11
    .param p0, "$rows"    # Ljava/util/List;
    .param p1, "$model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 463
    if-nez p0, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, p0

    :goto_0
    new-instance v1, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda35;

    invoke-direct {v1}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda35;-><init>()V

    .local v0, "items\\1":Ljava/util/List;
    .local v1, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object v2, p2

    .line 1609
    .local v2, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 1612
    sget-object v3, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$1;->INSTANCE:Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$1;

    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1609
    .local v3, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v4, 0x0

    .line 1614
    .local v4, "$i$f$items\\1\\463":I
    nop

    .line 1615
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    .line 1616
    nop

    .line 1614
    new-instance v6, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$2;

    invoke-direct {v6, v1, v0}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v6, Lkotlin/jvm/functions/Function1;

    new-instance v7, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$3;

    invoke-direct {v7, v3, v0}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v7, Lkotlin/jvm/functions/Function1;

    .line 1618
    new-instance v8, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;

    invoke-direct {v8, v0, p0, p1}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;-><init>(Ljava/util/List;Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V

    const v9, -0x25b7f321

    const/4 v10, 0x1

    invoke-static {v9, v10, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    check-cast v8, Lkotlin/jvm/functions/Function4;

    .line 1614
    invoke-interface {v2, v5, v6, v7, v8}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 1620
    nop

    .line 474
    .end local v0    # "items\\1":Ljava/util/List;
    .end local v1    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v2    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v3    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v4    # "$i$f$items\\1\\463":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$lambda$67(Lorg/lighttouch/android/StoreCopy;)Ljava/lang/Object;
    .locals 1
    .param p0, "it"    # Lorg/lighttouch/android/StoreCopy;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 463
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0
.end method

.method private static final StoreDetails$lambda$85$lambda$84$lambda$83(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 2
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;

    .line 491
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->getCandidate()Lorg/json/JSONObject;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 587
    .local v0, "it\\1":Lorg/json/JSONObject;
    const/4 v1, 0x0

    .line 491
    .local v1, "$i$a$-let-StoreScreenKt$StoreDetails$1$4$1$1\\1\\491\\0":I
    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->install(Lorg/json/JSONObject;)V

    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->close()V

    .end local v0    # "it\\1":Lorg/json/JSONObject;
    .end local v1    # "$i$a$-let-StoreScreenKt$StoreDetails$1$4$1$1\\1\\491\\0":I
    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreDetails$lambda$86(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/StoreScreenKt;->StoreDetails(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZLandroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final StoreScreen(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 21
    .param p0, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "running"    # Z
    .param p2, "onPickLocal"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onClose"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/StoreModel;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v7, p5

    const-string v0, "model"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onPickLocal"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onClose"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 281
    const v0, -0x1af5b678

    move-object/from16 v2, p4

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(StoreScreen)P(!1,3,2)282@15049L78,285@15292L64,285@15263L93,287@15525L31,287@15580L11,287@15604L2049,287@15467L2186:StoreScreen.kt#o13vsk"

    invoke-static {v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p5

    .local v2, "$dirty":I
    and-int/lit8 v5, v7, 0x6

    if-nez v5, :cond_1

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    :goto_0
    or-int/2addr v2, v5

    :cond_1
    and-int/lit8 v5, v7, 0x30

    if-nez v5, :cond_3

    move/from16 v5, p1

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_2

    const/16 v6, 0x20

    goto :goto_1

    :cond_2
    const/16 v6, 0x10

    :goto_1
    or-int/2addr v2, v6

    goto :goto_2

    :cond_3
    move/from16 v5, p1

    :goto_2
    and-int/lit16 v6, v7, 0x180

    if-nez v6, :cond_5

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    const/16 v6, 0x100

    goto :goto_3

    :cond_4
    const/16 v6, 0x80

    :goto_3
    or-int/2addr v2, v6

    :cond_5
    and-int/lit16 v6, v7, 0xc00

    if-nez v6, :cond_7

    invoke-interface {v8, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6

    const/16 v6, 0x800

    goto :goto_4

    :cond_6
    const/16 v6, 0x400

    :goto_4
    or-int/2addr v2, v6

    :cond_7
    move v9, v2

    .end local v2    # "$dirty":I
    .local v9, "$dirty":I
    and-int/lit16 v2, v9, 0x493

    const/16 v6, 0x492

    if-ne v2, v6, :cond_9

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_8

    goto :goto_5

    .line 288
    :cond_8
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v18, v8

    move v6, v9

    goto/16 :goto_a

    .line 281
    :cond_9
    :goto_5
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_a

    const/4 v2, -0x1

    const-string v6, "org.lighttouch.android.StoreScreen (StoreScreen.kt:280)"

    invoke-static {v0, v9, v2, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 282
    :cond_a
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getInstalledList()Lorg/lighttouch/android/InstalledList;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/InstalledList;->getPlain()Lorg/lighttouch/android/InstalledApp;

    move-result-object v0

    .line 283
    .local v0, "plain":Lorg/lighttouch/android/InstalledApp;
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getChosen()Lorg/json/JSONObject;

    move-result-object v2

    const/4 v6, 0x0

    if-nez v2, :cond_b

    if-nez v0, :cond_b

    const/4 v2, 0x1

    goto :goto_6

    :cond_b
    move v2, v6

    :goto_6
    shr-int/lit8 v11, v9, 0x6

    and-int/lit8 v11, v11, 0x70

    invoke-static {v2, v4, v8, v11, v6}, Landroidx/activity/compose/BackHandlerKt;->BackHandler(ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 284
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getChosen()Lorg/json/JSONObject;

    move-result-object v4

    .line 286
    .local v4, "details":Lorg/json/JSONObject;
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v2

    const v11, 0x4c5de2

    invoke-interface {v8, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v8, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v12

    .local v12, "invalid\\1":Z
    move-object v13, v8

    .local v13, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 636
    .local v14, "$i$f$cache\\1\\286":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\1":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 637
    .local v16, "$i$a$-let-ComposerKt$cache$1\\2\\636\\1":I
    const/4 v10, 0x0

    if-nez v12, :cond_d

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v15, v6, :cond_c

    goto :goto_7

    .line 641
    :cond_c
    move-object/from16 v17, v0

    move-object v0, v15

    goto :goto_8

    .line 638
    :cond_d
    :goto_7
    const/4 v6, 0x0

    .line 286
    .local v6, "$i$a$-cache-StoreScreenKt$StoreScreen$1\\3\\638\\0":I
    move-object/from16 v17, v0

    .end local v0    # "plain":Lorg/lighttouch/android/InstalledApp;
    .local v17, "plain":Lorg/lighttouch/android/InstalledApp;
    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$1$1;

    invoke-direct {v0, v1, v10}, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$1$1;-><init>(Lorg/lighttouch/android/StoreModel;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    .line 638
    .end local v6    # "$i$a$-cache-StoreScreenKt$StoreScreen$1\\3\\638\\0":I
    nop

    .line 639
    .local v0, "value\\2":Ljava/lang/Object;
    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 640
    nop

    .line 637
    .end local v0    # "value\\2":Ljava/lang/Object;
    :goto_8
    nop

    .line 636
    .end local v15    # "it\\1":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\2\\636\\1":I
    nop

    .line 286
    .end local v12    # "invalid\\1":Z
    .end local v13    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\1\\286":I
    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v6, 0x0

    invoke-static {v2, v0, v8, v6}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 288
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v2, v6, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v2, "store"

    invoke-static {v0, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v2, 0x6e3c21fe

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v8, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\4":Z
    move-object v6, v8

    .local v6, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 642
    .local v11, "$i$f$cache\\4\\288":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\4":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 643
    .local v13, "$i$a$-let-ComposerKt$cache$1\\5\\642\\4":I
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v12, v14, :cond_e

    .line 644
    const/4 v14, 0x0

    .local v14, "$i$a$-cache-StoreScreenKt$StoreScreen$2\\6\\644\\0":I
    new-instance v15, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v15}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda2;-><init>()V

    .line 645
    .end local v14    # "$i$a$-cache-StoreScreenKt$StoreScreen$2\\6\\644\\0":I
    .local v15, "value\\5":Ljava/lang/Object;
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 646
    nop

    .end local v15    # "value\\5":Ljava/lang/Object;
    goto :goto_9

    .line 647
    :cond_e
    move-object v15, v12

    .line 643
    :goto_9
    nop

    .line 642
    .end local v12    # "it\\4":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\5\\642\\4":I
    nop

    .line 288
    .end local v2    # "invalid\\4":Z
    .end local v6    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\4\\288":I
    check-cast v15, Lkotlin/jvm/functions/Function1;

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v6, 0x0

    const/4 v11, 0x1

    invoke-static {v0, v6, v15, v11, v10}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v8, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v12

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3;

    move-object/from16 v6, p3

    move v2, v5

    move-object/from16 v5, v17

    .end local v17    # "plain":Lorg/lighttouch/android/InstalledApp;
    .local v5, "plain":Lorg/lighttouch/android/InstalledApp;
    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/StoreScreenKt$StoreScreen$3;-><init>(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lorg/json/JSONObject;Lorg/lighttouch/android/InstalledApp;Lkotlin/jvm/functions/Function0;)V

    const/16 v1, 0x36

    const v2, 0x20c079cd

    invoke-static {v2, v11, v0, v8, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lkotlin/jvm/functions/Function2;

    const/high16 v19, 0xc00000

    const/16 v20, 0x7a

    move v2, v9

    .end local v9    # "$dirty":I
    .local v2, "$dirty":I
    const/4 v9, 0x0

    move-object/from16 v18, v8

    move-object v8, v10

    move-wide v10, v12

    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .local v18, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v12, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    move v6, v2

    .end local v2    # "$dirty":I
    .local v6, "$dirty":I
    invoke-static/range {v8 .. v20}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v4    # "details":Lorg/json/JSONObject;
    .end local v5    # "plain":Lorg/lighttouch/android/InstalledApp;
    :cond_f
    :goto_a
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_10

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda3;

    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move v5, v7

    invoke-direct/range {v0 .. v5}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda3;-><init>(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 324
    :cond_10
    return-void
.end method

.method private static final StoreScreen$lambda$8$lambda$7(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 288
    const/4 v0, 0x1

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsProperties_androidKt;->setTestTagsAsResourceId(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreScreen$lambda$9(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 7

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/StoreScreenKt;->StoreScreen(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final StoreTopBar(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 83
    .param p0, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "running"    # Z
    .param p2, "onPickLocal"    # Lkotlin/jvm/functions/Function0;
    .param p3, "canSearch"    # Z
    .param p4, "onBack"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/StoreModel;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 344
    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v6, p6

    const v0, 0x47e7e292

    move-object/from16 v5, p5

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(StoreTopBar)P(1,4,3)344@19166L34,346@19255L1684:StoreScreen.kt#o13vsk"

    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p6

    .local v5, "$dirty":I
    and-int/lit8 v8, v6, 0x6

    if-nez v8, :cond_1

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_0

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    :goto_0
    or-int/2addr v5, v8

    :cond_1
    and-int/lit8 v8, v6, 0x30

    if-nez v8, :cond_3

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v8

    if-eqz v8, :cond_2

    const/16 v8, 0x20

    goto :goto_1

    :cond_2
    const/16 v8, 0x10

    :goto_1
    or-int/2addr v5, v8

    :cond_3
    and-int/lit16 v8, v6, 0x180

    if-nez v8, :cond_5

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_4

    const/16 v8, 0x100

    goto :goto_2

    :cond_4
    const/16 v8, 0x80

    :goto_2
    or-int/2addr v5, v8

    :cond_5
    and-int/lit16 v8, v6, 0xc00

    if-nez v8, :cond_7

    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v8

    if-eqz v8, :cond_6

    const/16 v8, 0x800

    goto :goto_3

    :cond_6
    const/16 v8, 0x400

    :goto_3
    or-int/2addr v5, v8

    :cond_7
    and-int/lit16 v8, v6, 0x6000

    if-nez v8, :cond_9

    move-object/from16 v10, p4

    invoke-interface {v7, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_8

    const/16 v8, 0x4000

    goto :goto_4

    :cond_8
    const/16 v8, 0x2000

    :goto_4
    or-int/2addr v5, v8

    goto :goto_5

    :cond_9
    move-object/from16 v10, p4

    :goto_5
    move v8, v5

    .end local v5    # "$dirty":I
    .local v8, "$dirty":I
    and-int/lit16 v5, v8, 0x2493

    const/16 v11, 0x2492

    if-ne v5, v11, :cond_b

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_a

    goto :goto_6

    .line 852
    :cond_a
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object/from16 v18, v7

    move/from16 v31, v8

    goto/16 :goto_18

    .line 344
    :cond_b
    :goto_6
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_c

    const/4 v5, -0x1

    const-string v11, "org.lighttouch.android.StoreTopBar (StoreScreen.kt:343)"

    invoke-static {v0, v8, v5, v11}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_c
    const v0, 0x6e3c21fe

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 345
    const/4 v5, 0x0

    move v11, v5

    .local v11, "invalid\\1":Z
    move-object v12, v7

    .local v12, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 707
    .local v13, "$i$f$cache\\1\\345":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\1":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 708
    .local v15, "$i$a$-let-ComposerKt$cache$1\\2\\707\\1":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p5, v5

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x0

    if-ne v14, v5, :cond_d

    .line 709
    const/4 v5, 0x0

    .line 345
    .local v5, "$i$a$-cache-StoreScreenKt$StoreTopBar$menu$2\\3\\709\\0":I
    invoke-static/range {p5 .. p5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    move/from16 v17, v5

    const/4 v5, 0x2

    .end local v5    # "$i$a$-cache-StoreScreenKt$StoreTopBar$menu$2\\3\\709\\0":I
    .local v17, "$i$a$-cache-StoreScreenKt$StoreTopBar$menu$2\\3\\709\\0":I
    invoke-static {v4, v9, v5, v9}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v4

    .line 709
    .end local v17    # "$i$a$-cache-StoreScreenKt$StoreTopBar$menu$2\\3\\709\\0":I
    nop

    .line 710
    .local v4, "value\\2":Ljava/lang/Object;
    invoke-interface {v12, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 711
    nop

    .end local v4    # "value\\2":Ljava/lang/Object;
    goto :goto_7

    .line 712
    :cond_d
    move-object v4, v14

    .line 708
    :goto_7
    nop

    .line 707
    .end local v14    # "it\\1":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\2\\707\\1":I
    nop

    .line 345
    .end local v11    # "invalid\\1":Z
    .end local v12    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$cache\\1\\345":I
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .local v4, "menu$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 346
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getSearchOpen()Z

    move-result v5

    const/4 v11, 0x1

    if-eqz v5, :cond_e

    if-eqz p3, :cond_e

    move v5, v11

    goto :goto_8

    :cond_e
    move/from16 v5, p5

    .line 347
    .local v5, "searching":Z
    :goto_8
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    const/4 v13, 0x0

    invoke-static {v12, v13, v11, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    const/16 v14, 0x40

    .local v14, "$this$dp\\4":I
    const/4 v15, 0x0

    .line 713
    .local v15, "$i$f$getDp\\4\\347":I
    int-to-float v11, v14

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 347
    .end local v14    # "$this$dp\\4":I
    .end local v15    # "$i$f$getDp\\4\\347":I
    invoke-static {v12, v11}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v11

    const/4 v12, 0x4

    .local v12, "$this$dp\\5":I
    const/4 v14, 0x0

    .line 713
    .local v14, "$i$f$getDp\\5\\347":I
    int-to-float v15, v12

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 347
    .end local v12    # "$this$dp\\5":I
    .end local v14    # "$i$f$getDp\\5\\347":I
    const/4 v14, 0x2

    invoke-static {v11, v12, v13, v14, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .local v9, "modifier\\6":Landroidx/compose/ui/Modifier;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v11

    .local v11, "verticalAlignment\\6":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v12, 0x186

    .local v12, "$changed\\6":I
    move/from16 v19, v12

    .end local v12    # "$changed\\6":I
    .local v19, "$changed\\6":I
    const/16 v20, 0x0

    .line 714
    .local v20, "$i$f$Row\\6\\347":I
    const v12, 0x2952b718

    const-string v13, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v7, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 715
    sget-object v12, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v12}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v12

    .line 719
    .local v12, "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v13, v19, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v19, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v12, v11, v7, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v19, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 720
    move/from16 v21, v14

    .local v21, "$changed\\7":I
    const/16 v22, 0x0

    .line 721
    .local v22, "$i$f$Layout\\7\\720":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v7, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 722
    move/from16 v14, p5

    invoke-static {v7, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v23

    .line 723
    .local v23, "compositeKeyHash\\7":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 724
    .local v14, "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v18, v12

    .end local v12    # "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v18, "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 726
    .local v12, "materialized\\7":Landroidx/compose/ui/Modifier;
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v24

    move/from16 v25, v5

    .end local v5    # "searching":Z
    .local v25, "searching":Z
    shl-int/lit8 v5, v21, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 725
    nop

    .local v5, "$changed\\8":I
    move-object/from16 v26, v24

    .local v26, "factory\\8":Lkotlin/jvm/functions/Function0;
    const/16 v24, 0x0

    .line 727
    .local v24, "$i$f$ReusableComposeNode\\8\\725":I
    move/from16 v27, v5

    .end local v5    # "$changed\\8":I
    .local v27, "$changed\\8":I
    const v5, -0x2942ffcf

    const-string v6, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v7, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 728
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 729
    :cond_f
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 730
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_10

    .line 731
    move-object/from16 v5, v26

    .end local v26    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_9

    .line 733
    .end local v5    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\8":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object/from16 v5, v26

    .end local v26    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 735
    :goto_9
    move-object/from16 v26, v5

    .end local v5    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .restart local v26    # "factory\\8":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 736
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\9\\735\\7":I
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v31, v8

    .end local v8    # "$dirty":I
    .local v31, "$dirty":I
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v13, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 737
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v14, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 739
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\10":Lkotlin/jvm/functions/Function2;
    const/16 v30, 0x0

    .line 740
    .local v30, "$i$f$set-impl\\10\\739":I
    move-object/from16 v32, v5

    .local v32, "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 741
    .local v33, "$i$a$-with-Updater$set$1\\11\\740\\10":I
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v34

    if-nez v34, :cond_12

    move-object/from16 v34, v9

    .end local v9    # "modifier\\6":Landroidx/compose/ui/Modifier;
    .local v34, "modifier\\6":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_11

    goto :goto_a

    :cond_11
    move-object/from16 v10, v32

    goto :goto_b

    .end local v34    # "modifier\\6":Landroidx/compose/ui/Modifier;
    .restart local v9    # "modifier\\6":Landroidx/compose/ui/Modifier;
    :cond_12
    move-object/from16 v34, v9

    .line 742
    .end local v9    # "modifier\\6":Landroidx/compose/ui/Modifier;
    .restart local v34    # "modifier\\6":Landroidx/compose/ui/Modifier;
    :goto_a
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    move-object/from16 v10, v32

    .end local v32    # "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    .local v10, "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 743
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-interface {v5, v9, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 745
    :goto_b
    nop

    .line 740
    .end local v10    # "$this$set_impl_u24lambda_u240\\10":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-with-Updater$set$1\\11\\740\\10":I
    nop

    .line 745
    nop

    .line 746
    .end local v8    # "block\\10":Lkotlin/jvm/functions/Function2;
    .end local v30    # "$i$f$set-impl\\10\\739":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v5, v12, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 747
    nop

    .line 735
    .end local v5    # "$this$Layout_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\9\\735\\7":I
    nop

    .line 748
    shr-int/lit8 v5, v27, 0x6

    and-int/lit8 v5, v5, 0xe

    .local v5, "$changed\\12":I
    move-object v8, v7

    .local v8, "$composer\\12":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 749
    .local v9, "$i$a$-Layout-RowKt$Row$1\\12\\748\\6":I
    const v10, -0x184f2606

    move/from16 v29, v5

    .end local v5    # "$changed\\12":I
    .local v29, "$changed\\12":I
    const-string v5, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v8, v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v19, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v30, v10, 0x6

    .local v30, "$changed\\13":I
    check-cast v5, Landroidx/compose/foundation/layout/RowScope;

    .local v5, "$this$StoreTopBar_u24lambda_u2431\\13":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v35, v5

    .end local v5    # "$this$StoreTopBar_u24lambda_u2431\\13":Landroidx/compose/foundation/layout/RowScope;
    .local v35, "$this$StoreTopBar_u24lambda_u2431\\13":Landroidx/compose/foundation/layout/RowScope;
    move-object v5, v8

    .local v5, "$composer\\13":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 348
    .local v32, "$i$a$-Row-StoreScreenKt$StoreTopBar$1\\13\\749\\0":I
    const v10, -0x479496f9

    move-object/from16 v33, v8

    .end local v8    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v33, "$composer\\12":Landroidx/compose/runtime/Composer;
    const-string v8, "C347@19383L126,357@20192L18,358@20219L714:StoreScreen.kt#o13vsk"

    invoke-static {v5, v10, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    const-string v10, "store_close"

    invoke-static {v8, v10}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    sget-object v10, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v10}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$1958551217$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v10

    shr-int/lit8 v36, v31, 0xc

    and-int/lit8 v36, v36, 0xe

    const v37, 0x30030

    or-int v36, v36, v37

    move-object/from16 v37, v18

    .end local v18    # "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v37, "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v18, 0x1c

    move-object/from16 v38, v12

    .end local v12    # "materialized\\7":Landroidx/compose/ui/Modifier;
    .local v38, "materialized\\7":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v39, v13

    .end local v13    # "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v39, "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v13, 0x0

    move-object/from16 v40, v14

    .end local v14    # "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    .local v40, "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v14, 0x0

    move-object/from16 v16, v5

    move-object/from16 v48, v11

    move-object v5, v15

    move/from16 v17, v36

    move-object/from16 v49, v37

    move-object/from16 v47, v38

    move-object/from16 v45, v39

    move-object/from16 v46, v40

    move-object v11, v8

    move-object v15, v10

    const v8, -0x4ee9b9da

    move-object/from16 v10, p4

    .end local v5    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local v11    # "verticalAlignment\\6":Landroidx/compose/ui/Alignment$Vertical;
    .end local v37    # "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v38    # "materialized\\7":Landroidx/compose/ui/Modifier;
    .end local v39    # "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v40    # "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    .local v16, "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v45, "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v46, "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    .local v47, "materialized\\7":Landroidx/compose/ui/Modifier;
    .local v48, "verticalAlignment\\6":Landroidx/compose/ui/Alignment$Vertical;
    .local v49, "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static/range {v10 .. v18}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 349
    move-object/from16 v10, v16

    .end local v16    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\13":Landroidx/compose/runtime/Composer;
    if-eqz v25, :cond_13

    const v12, 0x3fc17355

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "348@19533L39"

    invoke-static {v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v36, v12

    check-cast v36, Landroidx/compose/ui/Modifier;

    const/16 v39, 0x2

    const/16 v40, 0x0

    const/high16 v37, 0x3f800000    # 1.0f

    const/16 v38, 0x0

    invoke-static/range {v35 .. v40}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    and-int/lit8 v13, v31, 0xe

    invoke-static {v1, v12, v10, v13}, Lorg/lighttouch/android/StoreScreenKt;->SearchField(Lorg/lighttouch/android/StoreModel;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v51, v9

    goto/16 :goto_12

    .line 350
    :cond_13
    const v12, -0x4791f7c1

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "350@19600L411,355@20060L27,355@20039L134"

    invoke-static {v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 351
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v36, v12

    check-cast v36, Landroidx/compose/ui/Modifier;

    const/16 v39, 0x2

    const/16 v40, 0x0

    const/high16 v37, 0x3f800000    # 1.0f

    const/16 v38, 0x0

    invoke-static/range {v35 .. v40}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .local v12, "modifier\\14":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .local v13, "$changed\\14":I
    const/4 v14, 0x0

    .line 750
    .local v14, "$i$f$Column\\14\\351":I
    const v15, -0x1cd0f17e

    const-string v11, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v10, v15, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 751
    sget-object v11, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v11}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v11

    .line 752
    .local v11, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v15, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v15

    .line 755
    .local v15, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v17, v13, 0x3

    and-int/lit8 v17, v17, 0xe

    shr-int/lit8 v18, v13, 0x3

    and-int/lit8 v18, v18, 0x70

    or-int v8, v17, v18

    invoke-static {v11, v15, v10, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v13, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 756
    nop

    .local v17, "$changed\\15":I
    const/16 v18, 0x0

    .line 757
    .local v18, "$i$f$Layout\\15\\756":I
    move/from16 v51, v9

    const v9, -0x4ee9b9da

    .end local v9    # "$i$a$-Layout-RowKt$Row$1\\12\\748\\6":I
    .local v51, "$i$a$-Layout-RowKt$Row$1\\12\\748\\6":I
    invoke-static {v10, v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 758
    const/4 v9, 0x0

    invoke-static {v10, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v36

    .line 759
    .local v36, "compositeKeyHash\\15":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 760
    .local v9, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v37, v11

    .end local v11    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v37, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v10, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 762
    .local v11, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v38, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v38 .. v38}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v38

    move-object/from16 v39, v12

    .end local v12    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v39, "modifier\\14":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v12, v17, 0x6

    and-int/lit16 v12, v12, 0x380

    or-int/lit8 v12, v12, 0x6

    .line 761
    nop

    .local v12, "$changed\\16":I
    move-object/from16 v40, v38

    .local v40, "factory\\16":Lkotlin/jvm/functions/Function0;
    const/16 v38, 0x0

    .line 763
    .local v38, "$i$f$ReusableComposeNode\\16\\761":I
    move/from16 v41, v12

    const v12, -0x2942ffcf

    .end local v12    # "$changed\\16":I
    .local v41, "$changed\\16":I
    invoke-static {v10, v12, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 764
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v12

    instance-of v12, v12, Landroidx/compose/runtime/Applier;

    if-nez v12, :cond_14

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 765
    :cond_14
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 766
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v12

    if-eqz v12, :cond_15

    .line 767
    move-object/from16 v12, v40

    .end local v40    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v12, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c

    .line 769
    .end local v12    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v40    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :cond_15
    move-object/from16 v12, v40

    .end local v40    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v12    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 771
    :goto_c
    move-object/from16 v40, v12

    .end local v12    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v40    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .local v12, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v42, 0x0

    .line 772
    .local v42, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\771\\15":I
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v44, v13

    .end local v13    # "$changed\\14":I
    .local v44, "$changed\\14":I
    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v12, v8, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 773
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v12, v9, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 775
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v43, 0x0

    .line 776
    .local v43, "$i$f$set-impl\\18\\775":I
    move-object/from16 v52, v12

    .local v52, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 777
    .local v53, "$i$a$-with-Updater$set$1\\19\\776\\18":I
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v54

    if-nez v54, :cond_17

    move-object/from16 v54, v8

    .end local v8    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v54, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    move-object/from16 v55, v9

    .end local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .local v55, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_16

    goto :goto_d

    :cond_16
    move-object/from16 v9, v52

    goto :goto_e

    .end local v54    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v55    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_17
    move-object/from16 v54, v8

    move-object/from16 v55, v9

    .line 778
    .end local v8    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v9    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v54    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v55    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_d
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    move-object/from16 v9, v52

    .end local v52    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 779
    invoke-static/range {v36 .. v36}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v12, v8, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 781
    :goto_e
    nop

    .line 776
    .end local v9    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$a$-with-Updater$set$1\\19\\776\\18":I
    nop

    .line 781
    nop

    .line 782
    .end local v13    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v43    # "$i$f$set-impl\\18\\775":I
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v12, v11, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 783
    nop

    .line 771
    .end local v12    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v42    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\771\\15":I
    nop

    .line 784
    shr-int/lit8 v8, v41, 0x6

    and-int/lit8 v8, v8, 0xe

    .local v8, "$changed\\20":I
    move-object v9, v10

    .local v9, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 785
    .local v12, "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    const v13, -0x16ef5699

    move/from16 v42, v8

    .end local v8    # "$changed\\20":I
    .local v42, "$changed\\20":I
    const-string v8, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v9, v13, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v13, v44, 0x6

    and-int/lit8 v13, v13, 0x70

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\21":I
    check-cast v8, Landroidx/compose/foundation/layout/ColumnScope;

    .local v8, "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2423\\21":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v77, v9

    .local v77, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/16 v43, 0x0

    .line 352
    .local v43, "$i$a$-Column-StoreScreenKt$StoreTopBar$1$1\\21\\785\\13":I
    move-object/from16 v52, v8

    .end local v8    # "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2423\\21":Landroidx/compose/foundation/layout/ColumnScope;
    .local v52, "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2423\\21":Landroidx/compose/foundation/layout/ColumnScope;
    const v8, -0x5e77eb90

    move-object/from16 v53, v9

    .end local v9    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v53, "$composer\\20":Landroidx/compose/runtime/Composer;
    const-string v9, "C351@19689L10,351@19646L65,353@19876L10,353@19920L11,352@19728L269:StoreScreen.kt#o13vsk"

    move-object/from16 v81, v11

    move-object/from16 v11, v77

    .end local v77    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v11, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v81, "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v11, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v76

    const/16 v79, 0x0

    const v80, 0xfffe

    const-string v56, "\u65e7\u7248\u5546\u5e97"

    const/16 v57, 0x0

    const-wide/16 v58, 0x0

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const/16 v71, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/16 v78, 0x6

    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v77    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v80}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 353
    .end local v77    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getTarget()Lorg/lighttouch/android/StoreTarget;

    move-result-object v8

    if-eqz v8, :cond_18

    .line 587
    .local v8, "it\\22":Lorg/lighttouch/android/StoreTarget;
    const/4 v9, 0x0

    .line 353
    .local v9, "$i$a$-let-StoreScreenKt$StoreTopBar$1$1$1\\22\\353\\21":I
    invoke-virtual {v8}, Lorg/lighttouch/android/StoreTarget;->getProductType()Ljava/lang/String;

    move-result-object v56

    move-object/from16 v57, v8

    .end local v8    # "it\\22":Lorg/lighttouch/android/StoreTarget;
    .local v57, "it\\22":Lorg/lighttouch/android/StoreTarget;
    invoke-static/range {v56 .. v56}, Lorg/lighttouch/android/DevicesKt;->shortProductName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move/from16 v56, v9

    .end local v9    # "$i$a$-let-StoreScreenKt$StoreTopBar$1$1$1\\22\\353\\21":I
    .local v56, "$i$a$-let-StoreScreenKt$StoreTopBar$1$1$1\\22\\353\\21":I
    invoke-virtual/range {v57 .. v57}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v9

    move/from16 v82, v12

    .end local v12    # "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    .local v82, "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v12, " \u00b7 iOS "

    invoke-virtual {v8, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    .end local v56    # "$i$a$-let-StoreScreenKt$StoreTopBar$1$1$1\\22\\353\\21":I
    .end local v57    # "it\\22":Lorg/lighttouch/android/StoreTarget;
    if-nez v8, :cond_19

    goto :goto_f

    .end local v82    # "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    .restart local v12    # "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    :cond_18
    move/from16 v82, v12

    .end local v12    # "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    .restart local v82    # "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    :goto_f
    const-string v8, "\u672a\u9009\u62e9\u8bbe\u5907"

    :cond_19
    move-object/from16 v56, v8

    .line 354
    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v11, v9}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v76

    sget-object v8, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v9, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v8, v11, v9}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v8

    invoke-virtual {v8}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v58

    sget-object v8, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v71

    .line 353
    nop

    .line 354
    nop

    .line 353
    const/16 v57, 0x0

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x1

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/16 v78, 0x0

    const/16 v79, 0xc30

    const v80, 0xd7fa

    move-object/from16 v77, v11

    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v77    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v80}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 352
    .end local v77    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 355
    nop

    .line 785
    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v13    # "$changed\\21":I
    .end local v43    # "$i$a$-Column-StoreScreenKt$StoreTopBar$1$1\\21\\785\\13":I
    .end local v52    # "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2423\\21":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 784
    .end local v42    # "$changed\\20":I
    .end local v53    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v82    # "$i$a$-Layout-ColumnKt$Column$1\\20\\784\\14":I
    nop

    .line 786
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 763
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 787
    nop

    .line 757
    .end local v38    # "$i$f$ReusableComposeNode\\16\\761":I
    .end local v40    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v41    # "$changed\\16":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 788
    nop

    .line 750
    .end local v17    # "$changed\\15":I
    .end local v18    # "$i$f$Layout\\15\\756":I
    .end local v36    # "compositeKeyHash\\15":I
    .end local v55    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v81    # "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 789
    nop

    .line 356
    .end local v14    # "$i$f$Column\\14\\351":I
    .end local v15    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v37    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v39    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .end local v44    # "$changed\\14":I
    .end local v54    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    if-eqz p3, :cond_1c

    const v8, 0x4c5de2

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    .local v8, "invalid\\23":Z
    move-object v9, v10

    .local v9, "$this$cache\\23":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 790
    .local v11, "$i$f$cache\\23\\356":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\23":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 791
    .local v13, "$i$a$-let-ComposerKt$cache$1\\24\\790\\23":I
    if-nez v8, :cond_1b

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v12, v14, :cond_1a

    goto :goto_10

    .line 795
    :cond_1a
    move-object v15, v12

    goto :goto_11

    .line 792
    :cond_1b
    :goto_10
    const/4 v14, 0x0

    .line 356
    .local v14, "$i$a$-cache-StoreScreenKt$StoreTopBar$1$2\\25\\792\\13":I
    new-instance v15, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v15, v1}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda4;-><init>(Lorg/lighttouch/android/StoreModel;)V

    .line 792
    .end local v14    # "$i$a$-cache-StoreScreenKt$StoreTopBar$1$2\\25\\792\\13":I
    nop

    .line 793
    .local v15, "value\\24":Ljava/lang/Object;
    invoke-interface {v9, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 794
    nop

    .line 791
    .end local v15    # "value\\24":Ljava/lang/Object;
    :goto_11
    nop

    .line 790
    .end local v12    # "it\\23":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\24\\790\\23":I
    nop

    .line 356
    .end local v8    # "invalid\\23":Z
    .end local v9    # "$this$cache\\23":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\23\\356":I
    move-object/from16 v36, v15

    check-cast v36, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    const-string v9, "store_search"

    invoke-static {v8, v9}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    sget-object v8, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v8}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$1359384722$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v41

    const v43, 0x30030

    const/16 v44, 0x1c

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    move-object/from16 v42, v10

    .end local v10    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\13":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v44}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 350
    .end local v42    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\13":Landroidx/compose/runtime/Composer;
    :cond_1c
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 358
    :goto_12
    and-int/lit8 v8, v31, 0xe

    invoke-static {v1, v10, v8}, Lorg/lighttouch/android/StoreScreenKt;->QueueButton(Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    .line 359
    const/4 v9, 0x0

    move v8, v9

    .local v8, "$changed\\26":I
    const/4 v9, 0x0

    .line 796
    .local v9, "$i$f$Box\\26\\359":I
    const v11, 0x2bb5b5d7

    const-string v12, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v10, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 797
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    .line 798
    .local v11, "modifier\\26":Landroidx/compose/ui/Modifier;
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v12

    .line 799
    .local v12, "contentAlignment\\26":Landroidx/compose/ui/Alignment;
    const/4 v13, 0x0

    .line 802
    .local v13, "propagateMinConstraints\\26":Z
    invoke-static {v12, v13}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .local v14, "measurePolicy\\26":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v8, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 803
    nop

    .local v15, "$changed\\27":I
    const/16 v17, 0x0

    .line 804
    .local v17, "$i$f$Layout\\27\\803":I
    move-object/from16 v18, v7

    const v7, -0x4ee9b9da

    .end local v7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v18, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {v10, v7, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 805
    const/4 v5, 0x0

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v5

    .line 806
    .local v5, "compositeKeyHash\\27":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v7

    .line 807
    .local v7, "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p5, v5

    .end local v5    # "compositeKeyHash\\27":I
    .local p5, "compositeKeyHash\\27":I
    invoke-static {v10, v11}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 809
    .local v5, "materialized\\27":Landroidx/compose/ui/Modifier;
    sget-object v36, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v36 .. v36}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v36

    move/from16 v37, v8

    .end local v8    # "$changed\\26":I
    .local v37, "$changed\\26":I
    shl-int/lit8 v8, v15, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 808
    nop

    .local v8, "$changed\\28":I
    move-object/from16 v38, v36

    .local v38, "factory\\28":Lkotlin/jvm/functions/Function0;
    const/16 v36, 0x0

    .line 810
    .local v36, "$i$f$ReusableComposeNode\\28\\808":I
    move/from16 v39, v8

    const v8, -0x2942ffcf

    .end local v8    # "$changed\\28":I
    .local v39, "$changed\\28":I
    invoke-static {v10, v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 811
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_1d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 812
    :cond_1d
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 813
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_1e

    .line 814
    move-object/from16 v6, v38

    .end local v38    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .local v6, "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_13

    .line 816
    .end local v6    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .restart local v38    # "factory\\28":Lkotlin/jvm/functions/Function0;
    :cond_1e
    move-object/from16 v6, v38

    .end local v38    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 818
    :goto_13
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 819
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\29\\818\\27":I
    sget-object v38, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v40, v6

    .end local v6    # "factory\\28":Lkotlin/jvm/functions/Function0;
    .local v40, "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v38 .. v38}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v8, v14, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 820
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v8, v7, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 822
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\30":Lkotlin/jvm/functions/Function2;
    const/16 v38, 0x0

    .line 823
    .local v38, "$i$f$set-impl\\30\\822":I
    move-object/from16 v41, v8

    .local v41, "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    const/16 v42, 0x0

    .line 824
    .local v42, "$i$a$-with-Updater$set$1\\31\\823\\30":I
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v43

    if-nez v43, :cond_20

    move-object/from16 v43, v7

    .end local v7    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .local v43, "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v41 .. v41}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move/from16 v44, v9

    .end local v9    # "$i$f$Box\\26\\359":I
    .local v44, "$i$f$Box\\26\\359":I
    invoke-static/range {p5 .. p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1f

    goto :goto_14

    :cond_1f
    move-object/from16 v9, v41

    goto :goto_15

    .end local v43    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v44    # "$i$f$Box\\26\\359":I
    .restart local v7    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "$i$f$Box\\26\\359":I
    :cond_20
    move-object/from16 v43, v7

    move/from16 v44, v9

    .line 825
    .end local v7    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "$i$f$Box\\26\\359":I
    .restart local v43    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v44    # "$i$f$Box\\26\\359":I
    :goto_14
    invoke-static/range {p5 .. p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v9, v41

    .end local v41    # "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 826
    invoke-static/range {p5 .. p5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v8, v7, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 828
    :goto_15
    nop

    .line 823
    .end local v9    # "$this$set_impl_u24lambda_u240\\30":Landroidx/compose/runtime/Composer;
    .end local v42    # "$i$a$-with-Updater$set$1\\31\\823\\30":I
    nop

    .line 828
    nop

    .line 829
    .end local v6    # "block\\30":Lkotlin/jvm/functions/Function2;
    .end local v38    # "$i$f$set-impl\\30\\822":I
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v8, v5, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 830
    nop

    .line 818
    .end local v8    # "$this$Layout_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\29\\818\\27":I
    nop

    .line 831
    shr-int/lit8 v6, v39, 0x6

    and-int/lit8 v6, v6, 0xe

    .local v6, "$changed\\32":I
    move-object v7, v10

    .local v7, "$composer\\32":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 832
    .local v8, "$i$a$-Layout-BoxKt$Box$1\\32\\831\\26":I
    const v9, -0x7ff519f7    # -1.000876E-39f

    move-object/from16 v28, v5

    .end local v5    # "materialized\\27":Landroidx/compose/ui/Modifier;
    .local v28, "materialized\\27":Landroidx/compose/ui/Modifier;
    const-string v5, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v7, v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v9, v37, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\33":I
    check-cast v5, Landroidx/compose/foundation/layout/BoxScope;

    .local v5, "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2430\\33":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v58, v7

    .local v58, "$composer\\33":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 360
    .local v38, "$i$a$-Box-StoreScreenKt$StoreTopBar$1$3\\33\\832\\13":I
    move-object/from16 v41, v5

    .end local v5    # "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2430\\33":Landroidx/compose/foundation/layout/BoxScope;
    .local v41, "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2430\\33":Landroidx/compose/foundation/layout/BoxScope;
    const v5, -0x1c1b293

    move/from16 v42, v6

    .end local v6    # "$changed\\32":I
    .local v42, "$changed\\32":I
    const-string v6, "C359@20258L15,359@20237L120,360@20389L16,360@20407L516,360@20370L553:StoreScreen.kt#o13vsk"

    move-object/from16 v50, v7

    .end local v58    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static {v7, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v5, 0x4c5de2

    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v5, 0x0

    .local v5, "invalid\\34":Z
    move-object v6, v7

    .local v6, "$this$cache\\34":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 833
    .local v52, "$i$f$cache\\34\\360":I
    move/from16 v53, v5

    .end local v5    # "invalid\\34":Z
    .local v53, "invalid\\34":Z
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\34":Ljava/lang/Object;
    const/16 v54, 0x0

    .line 834
    .local v54, "$i$a$-let-ComposerKt$cache$1\\35\\833\\34":I
    sget-object v55, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    .end local v7    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .restart local v58    # "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v55 .. v55}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_21

    .line 835
    const/4 v7, 0x0

    .line 360
    .local v7, "$i$a$-cache-StoreScreenKt$StoreTopBar$1$3$1\\36\\835\\33":I
    move-object/from16 v55, v5

    .end local v5    # "it\\34":Ljava/lang/Object;
    .local v55, "it\\34":Ljava/lang/Object;
    new-instance v5, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v5, v4}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda5;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 835
    .end local v7    # "$i$a$-cache-StoreScreenKt$StoreTopBar$1$3$1\\36\\835\\33":I
    nop

    .line 836
    .local v5, "value\\35":Ljava/lang/Object;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 837
    nop

    .end local v5    # "value\\35":Ljava/lang/Object;
    goto :goto_16

    .line 838
    .end local v55    # "it\\34":Ljava/lang/Object;
    .local v5, "it\\34":Ljava/lang/Object;
    :cond_21
    move-object/from16 v55, v5

    .line 834
    .end local v5    # "it\\34":Ljava/lang/Object;
    .restart local v55    # "it\\34":Ljava/lang/Object;
    :goto_16
    nop

    .line 833
    .end local v54    # "$i$a$-let-ComposerKt$cache$1\\35\\833\\34":I
    .end local v55    # "it\\34":Ljava/lang/Object;
    nop

    .line 360
    .end local v6    # "$this$cache\\34":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$f$cache\\34\\360":I
    .end local v53    # "invalid\\34":Z
    move-object/from16 v52, v5

    check-cast v52, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const-string v6, "store_menu"

    invoke-static {v5, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v53

    sget-object v5, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v5}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$-1378242133$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v57

    const v59, 0x30036

    const/16 v60, 0x1c

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    invoke-static/range {v52 .. v60}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .line 361
    move-object/from16 v7, v58

    .end local v58    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-static {v4}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$20(Landroidx/compose/runtime/MutableState;)Z

    move-result v52

    const v5, 0x4c5de2

    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\37":Z
    move-object v5, v7

    .local v5, "$this$cache\\37":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 839
    .local v6, "$i$f$cache\\37\\361":I
    move/from16 v16, v0

    .end local v0    # "invalid\\37":Z
    .local v16, "invalid\\37":Z
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\37":Ljava/lang/Object;
    const/16 v53, 0x0

    .line 840
    .local v53, "$i$a$-let-ComposerKt$cache$1\\38\\839\\37":I
    sget-object v54, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v55, v6

    .end local v6    # "$i$f$cache\\37\\361":I
    .local v55, "$i$f$cache\\37\\361":I
    invoke-virtual/range {v54 .. v54}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v0, v6, :cond_22

    .line 841
    const/4 v6, 0x0

    .line 361
    .local v6, "$i$a$-cache-StoreScreenKt$StoreTopBar$1$3$2\\39\\841\\33":I
    move-object/from16 v54, v0

    .end local v0    # "it\\37":Ljava/lang/Object;
    .local v54, "it\\37":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v0, v4}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda6;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 841
    .end local v6    # "$i$a$-cache-StoreScreenKt$StoreTopBar$1$3$2\\39\\841\\33":I
    nop

    .line 842
    .local v0, "value\\38":Ljava/lang/Object;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 843
    nop

    .end local v0    # "value\\38":Ljava/lang/Object;
    goto :goto_17

    .line 844
    .end local v54    # "it\\37":Ljava/lang/Object;
    .local v0, "it\\37":Ljava/lang/Object;
    :cond_22
    move-object/from16 v54, v0

    .line 840
    .end local v0    # "it\\37":Ljava/lang/Object;
    .restart local v54    # "it\\37":Ljava/lang/Object;
    :goto_17
    nop

    .line 839
    .end local v53    # "$i$a$-let-ComposerKt$cache$1\\38\\839\\37":I
    .end local v54    # "it\\37":Ljava/lang/Object;
    nop

    .line 361
    .end local v5    # "$this$cache\\37":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\37":Z
    .end local v55    # "$i$f$cache\\37\\361":I
    move-object/from16 v53, v0

    check-cast v53, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$StoreTopBar$1$3$3;

    invoke-direct {v0, v2, v1, v3, v4}, Lorg/lighttouch/android/StoreScreenKt$StoreTopBar$1$3$3;-><init>(ZLorg/lighttouch/android/StoreModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    const/16 v5, 0x36

    const v6, -0x3f36071d

    const/4 v1, 0x1

    invoke-static {v6, v1, v0, v7, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v65, v0

    check-cast v65, Lkotlin/jvm/functions/Function3;

    const/16 v68, 0x30

    const/16 v69, 0x7fc

    const/16 v54, 0x0

    const-wide/16 v55, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v67, 0x30

    move-object/from16 v66, v7

    .end local v7    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-static/range {v52 .. v69}, Landroidx/compose/material3/AndroidMenu_androidKt;->DropdownMenu-IlH_yew(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/ScrollState;Landroidx/compose/ui/window/PopupProperties;Landroidx/compose/ui/graphics/Shape;JFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    .line 360
    move-object/from16 v58, v66

    .end local v66    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .restart local v58    # "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 367
    nop

    .line 832
    .end local v9    # "$changed\\33":I
    .end local v38    # "$i$a$-Box-StoreScreenKt$StoreTopBar$1$3\\33\\832\\13":I
    .end local v41    # "$this$StoreTopBar_u24lambda_u2431_u24lambda_u2430\\33":Landroidx/compose/foundation/layout/BoxScope;
    .end local v58    # "$composer\\33":Landroidx/compose/runtime/Composer;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 831
    .end local v8    # "$i$a$-Layout-BoxKt$Box$1\\32\\831\\26":I
    .end local v42    # "$changed\\32":I
    .end local v50    # "$composer\\32":Landroidx/compose/runtime/Composer;
    nop

    .line 845
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 810
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 846
    nop

    .line 804
    .end local v36    # "$i$f$ReusableComposeNode\\28\\808":I
    .end local v39    # "$changed\\28":I
    .end local v40    # "factory\\28":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 847
    nop

    .line 796
    .end local v15    # "$changed\\27":I
    .end local v17    # "$i$f$Layout\\27\\803":I
    .end local v28    # "materialized\\27":Landroidx/compose/ui/Modifier;
    .end local v43    # "localMap\\27":Landroidx/compose/runtime/CompositionLocalMap;
    .end local p5    # "compositeKeyHash\\27":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 848
    nop

    .line 348
    .end local v11    # "modifier\\26":Landroidx/compose/ui/Modifier;
    .end local v12    # "contentAlignment\\26":Landroidx/compose/ui/Alignment;
    .end local v13    # "propagateMinConstraints\\26":Z
    .end local v14    # "measurePolicy\\26":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v37    # "$changed\\26":I
    .end local v44    # "$i$f$Box\\26\\359":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 368
    nop

    .line 749
    .end local v10    # "$composer\\13":Landroidx/compose/runtime/Composer;
    .end local v30    # "$changed\\13":I
    .end local v32    # "$i$a$-Row-StoreScreenKt$StoreTopBar$1\\13\\749\\0":I
    .end local v35    # "$this$StoreTopBar_u24lambda_u2431\\13":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 748
    .end local v29    # "$changed\\12":I
    .end local v33    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-Layout-RowKt$Row$1\\12\\748\\6":I
    nop

    .line 849
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 727
    invoke-static/range {v18 .. v18}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 850
    nop

    .line 721
    .end local v24    # "$i$f$ReusableComposeNode\\8\\725":I
    .end local v26    # "factory\\8":Lkotlin/jvm/functions/Function0;
    .end local v27    # "$changed\\8":I
    invoke-static/range {v18 .. v18}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 851
    nop

    .line 714
    .end local v21    # "$changed\\7":I
    .end local v22    # "$i$f$Layout\\7\\720":I
    .end local v23    # "compositeKeyHash\\7":I
    .end local v46    # "localMap\\7":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v47    # "materialized\\7":Landroidx/compose/ui/Modifier;
    invoke-static/range {v18 .. v18}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 852
    nop

    .end local v19    # "$changed\\6":I
    .end local v20    # "$i$f$Row\\6\\347":I
    .end local v34    # "modifier\\6":Landroidx/compose/ui/Modifier;
    .end local v45    # "measurePolicy\\6":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v48    # "verticalAlignment\\6":Landroidx/compose/ui/Alignment$Vertical;
    .end local v49    # "horizontalArrangement\\6":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v4    # "menu$delegate":Landroidx/compose/runtime/MutableState;
    .end local v25    # "searching":Z
    :cond_23
    :goto_18
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_24

    new-instance v0, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda7;

    move-object/from16 v1, p0

    move/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/StoreScreenKt$$ExternalSyntheticLambda7;-><init>(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 369
    :cond_24
    return-void
.end method

.method private static final StoreTopBar$lambda$20(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 345
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 1606
    .local v3, "$i$f$getValue\\1\\345":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\345":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 345
    return v0
.end method

.method private static final StoreTopBar$lambda$21(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 345
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 1607
    .local v4, "$i$f$setValue\\1\\345":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 1608
    nop

    .line 345
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\345":I
    return-void
.end method

.method private static final StoreTopBar$lambda$31$lambda$25$lambda$24(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;

    .line 356
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/StoreModel;->setSearchOpen(Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreTopBar$lambda$31$lambda$30$lambda$27$lambda$26(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 360
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$21(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreTopBar$lambda$31$lambda$30$lambda$29$lambda$28(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 361
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$21(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StoreTopBar$lambda$32(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final synthetic access$DeviceTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "$receiver"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->DeviceTab(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$QueueRow(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "item"    # Lorg/lighttouch/android/QueueItem;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    .line 1
    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/StoreScreenKt;->QueueRow(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$Screenshots$lambda$94$lambda$93$lambda$92$lambda$89(Landroidx/compose/runtime/State;)Landroid/graphics/Bitmap;
    .locals 1
    .param p0, "$bitmap$delegate"    # Landroidx/compose/runtime/State;

    .line 1
    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt;->Screenshots$lambda$94$lambda$93$lambda$92$lambda$89(Landroidx/compose/runtime/State;)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$StoreCard(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V
    .locals 0
    .param p0, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p1, "content"    # Lkotlin/jvm/functions/Function3;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .param p4, "$default"    # I

    .line 1
    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/StoreScreenKt;->StoreCard(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    return-void
.end method

.method public static final synthetic access$StoreDetails(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZLandroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "$receiver"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p1, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p2, "app"    # Lorg/json/JSONObject;
    .param p3, "running"    # Z
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/StoreScreenKt;->StoreDetails(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZLandroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$StoreTopBar(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .locals 0
    .param p0, "model"    # Lorg/lighttouch/android/StoreModel;
    .param p1, "running"    # Z
    .param p2, "onPickLocal"    # Lkotlin/jvm/functions/Function0;
    .param p3, "canSearch"    # Z
    .param p4, "onBack"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    .line 1
    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    return-void
.end method

.method public static final synthetic access$StoreTopBar$lambda$21(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/StoreScreenKt;->StoreTopBar$lambda$21(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final byteSize(J)Ljava/lang/String;
    .locals 7
    .param p0, "bytes"    # J

    .line 64
    nop

    .line 65
    const-wide/32 v0, 0x40000000

    cmp-long v0, p0, v0

    const-string v1, "format(...)"

    const/4 v2, 0x1

    if-ltz v0, :cond_0

    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    long-to-double v3, p0

    const-wide/high16 v5, 0x41d0000000000000L    # 1.073741824E9

    div-double/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%.1f GB"

    invoke-static {v0, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_0

    .line 66
    :cond_0
    const-wide/32 v3, 0x100000

    cmp-long v0, p0, v3

    if-ltz v0, :cond_1

    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    long-to-double v3, p0

    const-wide/high16 v5, 0x4130000000000000L    # 1048576.0

    div-double/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%.1f MB"

    invoke-static {v0, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_0

    .line 67
    :cond_1
    sget-object v0, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/16 v3, 0x400

    int-to-long v3, v3

    div-long v3, p0, v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%d KB"

    invoke-static {v0, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    :goto_0
    return-object v0
.end method

.method public static final productName(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p0, "productType"    # Ljava/lang/String;

    const-string v0, "productType"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 58
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    sparse-switch v0, :sswitch_data_0

    :goto_0
    goto/16 :goto_1

    :sswitch_0
    const-string v0, "iPod4,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 60
    :cond_0
    const-string v0, "iPod touch (4th generation)"

    goto/16 :goto_2

    .line 58
    :sswitch_1
    const-string v0, "iPod3,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 59
    :cond_1
    const-string v0, "iPod touch (3rd generation)"

    goto :goto_2

    .line 58
    :sswitch_2
    const-string v0, "iPod2,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 59
    :cond_2
    const-string v0, "iPod touch (2nd generation)"

    goto :goto_2

    .line 58
    :sswitch_3
    const-string v0, "iPod1,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    .line 59
    :cond_3
    const-string v0, "iPod touch"

    goto :goto_2

    .line 58
    :sswitch_4
    const-string v0, "iPad1,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    .line 61
    :cond_4
    const-string v0, "iPad"

    goto :goto_2

    .line 58
    :sswitch_5
    const-string v0, "iPhone3,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_0

    .line 61
    :cond_5
    const-string v0, "iPhone 4"

    goto :goto_2

    .line 58
    :sswitch_6
    const-string v0, "iPhone2,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_0

    .line 60
    :cond_6
    const-string v0, "iPhone 3GS"

    goto :goto_2

    .line 58
    :sswitch_7
    const-string v0, "iPhone1,2"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_0

    .line 60
    :cond_7
    const-string v0, "iPhone 3G"

    goto :goto_2

    .line 58
    :sswitch_8
    const-string v0, "iPhone1,1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_0

    .line 60
    :cond_8
    const-string v0, "iPhone"

    goto :goto_2

    .line 61
    :goto_1
    move-object v0, p0

    .line 62
    :goto_2
    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x7861b32f -> :sswitch_8
        -0x7861b32e -> :sswitch_7
        -0x7861af6e -> :sswitch_6
        -0x7861abad -> :sswitch_5
        0x407719cc -> :sswitch_4
        0x413c62da -> :sswitch_3
        0x413c669b -> :sswitch_2
        0x413c6a5c -> :sswitch_1
        0x413c6e1d -> :sswitch_0
    .end sparse-switch
.end method

.method public static final queueFraction(Ljava/util/List;)F
    .locals 8
    .param p0, "items"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;)F"
        }
    .end annotation

    const-string v0, "items"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 522
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    .line 523
    :cond_0
    nop

    .line 528
    nop

    .line 523
    move-object v0, p0

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-wide/16 v2, 0x0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lorg/lighttouch/android/QueueItem;

    .local v4, "item\\1":Lorg/lighttouch/android/QueueItem;
    const/4 v5, 0x0

    .line 524
    .local v5, "$i$a$-sumOfDouble-StoreScreenKt$queueFraction$1\\1\\523\\0":I
    invoke-virtual {v4}, Lorg/lighttouch/android/QueueItem;->getState()Lorg/lighttouch/android/QueueState;

    move-result-object v6

    sget-object v7, Lorg/lighttouch/android/StoreScreenKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v6}, Lorg/lighttouch/android/QueueState;->ordinal()I

    move-result v6

    aget v6, v7, v6

    packed-switch v6, :pswitch_data_0

    .line 526
    invoke-virtual {v4}, Lorg/lighttouch/android/QueueItem;->getOverall()F

    move-result v6

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v6, v1, v7}, Lkotlin/ranges/RangesKt;->coerceIn(FFF)F

    move-result v6

    float-to-double v6, v6

    goto :goto_1

    .line 525
    :pswitch_0
    const-wide/high16 v6, 0x3ff0000000000000L    # 1.0

    .line 527
    :goto_1
    nop

    .line 523
    .end local v4    # "item\\1":Lorg/lighttouch/android/QueueItem;
    .end local v5    # "$i$a$-sumOfDouble-StoreScreenKt$queueFraction$1\\1\\523\\0":I
    add-double/2addr v2, v6

    goto :goto_0

    .line 528
    :cond_1
    double-to-float v0, v2

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    int-to-float v1, v1

    .line 523
    div-float/2addr v0, v1

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static final text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0, "$this$text"    # Lorg/json/JSONObject;
    .param p1, "key"    # Ljava/lang/String;

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "key"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 56
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-nez v2, :cond_1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    if-eqz v2, :cond_2

    .line 587
    const/4 v0, 0x0

    .line 56
    .local v0, "$i$a$-ifEmpty-StoreScreenKt$text$1\\1\\56\\0":I
    nop

    .end local v0    # "$i$a$-ifEmpty-StoreScreenKt$text$1\\1\\56\\0":I
    goto :goto_1

    :cond_2
    move-object v1, v0

    :goto_1
    check-cast v1, Ljava/lang/String;

    :goto_2
    return-object v1
.end method

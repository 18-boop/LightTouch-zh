.class public final Lorg/lighttouch/android/InstalledList;
.super Ljava/lang/Object;
.source "StoreInstalled.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreInstalled.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreInstalled.kt\norg/lighttouch/android/InstalledList\n+ 2 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,204:1\n81#2:205\n107#2,2:206\n81#2:208\n107#2,2:209\n81#2:211\n107#2,2:212\n81#2:214\n107#2,2:215\n81#2:217\n107#2,2:218\n81#2:220\n107#2,2:221\n1563#3:223\n1634#3,3:224\n774#3:227\n865#3,2:228\n1#4:230\n*S KotlinDebug\n*F\n+ 1 StoreInstalled.kt\norg/lighttouch/android/InstalledList\n*L\n37#1:205\n37#1:206,2\n38#1:208\n38#1:209,2\n39#1:211\n39#1:212,2\n40#1:214\n40#1:215,2\n41#1:217\n41#1:218,2\n43#1:220\n43#1:221,2\n80#1:223\n80#1:224,3\n80#1:227\n80#1:228,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0014\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0008\u0011\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0002\u0008\u000f\u0008\u0001\u0018\u00002\u00020\u0001BW\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000e\u0010\u0004\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005\u0012\u000e\u0010\u0007\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00080\u0005\u0012\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0005\u0012\u0018\u0010\u000b\u001a\u0014\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u000e0\r\u0012\u0004\u0012\u00020\u000f0\u000c\u00a2\u0006\u0004\u0008\u0010\u0010\u0011J\u001e\u0010?\u001a\u00020\u000f2\u0006\u0010@\u001a\u00020\u00062\u000c\u0010A\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u0005H\u0002J\u0016\u0010B\u001a\u00020\n2\u000c\u0010A\u001a\u0008\u0012\u0004\u0012\u00020\u000f0\u0005H\u0002J\u0010\u0010C\u001a\u00020\u000f2\u0008\u0008\u0002\u0010D\u001a\u00020\nJ\u0014\u0010E\u001a\u00020\u000f2\u000c\u0010F\u001a\u0008\u0012\u0004\u0012\u00020\u000e0\rJ\u0006\u0010G\u001a\u00020\u000fJ\u0010\u0010H\u001a\u0004\u0018\u00010\u00062\u0006\u0010I\u001a\u00020\u000eJ\u0006\u0010J\u001a\u00020\u000fJ\u0006\u0010K\u001a\u00020\u000fJ\u0006\u0010L\u001a\u00020\u000fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0004\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00080\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\u000b\u001a\u0014\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u000e0\r\u0012\u0004\u0012\u00020\u000f0\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R;\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r2\u000e\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\u001a\u0010\u001b\u001a\u0004\u0008\u0016\u0010\u0017\"\u0004\u0008\u0018\u0010\u0019R+\u0010\u001c\u001a\u00020\n2\u0006\u0010\u0014\u001a\u00020\n8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008!\u0010\u001b\u001a\u0004\u0008\u001d\u0010\u001e\"\u0004\u0008\u001f\u0010 R/\u0010\"\u001a\u0004\u0018\u00010\u00062\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u00068F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008\'\u0010\u001b\u001a\u0004\u0008#\u0010$\"\u0004\u0008%\u0010&RC\u0010*\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020)0(2\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020)0(8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u0008/\u0010\u001b\u001a\u0004\u0008+\u0010,\"\u0004\u0008-\u0010.R/\u00100\u001a\u0004\u0018\u00010\u00062\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u00068F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u00083\u0010\u001b\u001a\u0004\u00081\u0010$\"\u0004\u00082\u0010&R/\u00104\u001a\u0004\u0018\u00010\u000e2\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u000e8F@FX\u0086\u008e\u0002\u00a2\u0006\u0012\n\u0004\u00089\u0010\u001b\u001a\u0004\u00085\u00106\"\u0004\u00087\u00108R\u000e\u0010:\u001a\u00020;X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020;X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020>X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006M"
    }
    d2 = {
        "Lorg/lighttouch/android/InstalledList;",
        "",
        "apps",
        "Lorg/lighttouch/android/GuestApps;",
        "muxSocket",
        "Lkotlin/Function0;",
        "",
        "target",
        "Lorg/lighttouch/android/StoreTarget;",
        "confirmed",
        "",
        "changed",
        "Lkotlin/Function1;",
        "",
        "Lorg/lighttouch/android/InstalledApp;",
        "",
        "<init>",
        "(Lorg/lighttouch/android/GuestApps;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V",
        "handler",
        "Landroid/os/Handler;",
        "<set-?>",
        "list",
        "getList",
        "()Ljava/util/List;",
        "setList",
        "(Ljava/util/List;)V",
        "list$delegate",
        "Landroidx/compose/runtime/MutableState;",
        "loading",
        "getLoading",
        "()Z",
        "setLoading",
        "(Z)V",
        "loading$delegate",
        "error",
        "getError",
        "()Ljava/lang/String;",
        "setError",
        "(Ljava/lang/String;)V",
        "error$delegate",
        "",
        "Lorg/lighttouch/android/Lookup;",
        "lookups",
        "getLookups",
        "()Ljava/util/Map;",
        "setLookups",
        "(Ljava/util/Map;)V",
        "lookups$delegate",
        "lookupError",
        "getLookupError",
        "setLookupError",
        "lookupError$delegate",
        "plain",
        "getPlain",
        "()Lorg/lighttouch/android/InstalledApp;",
        "setPlain",
        "(Lorg/lighttouch/android/InstalledApp;)V",
        "plain$delegate",
        "lookupGeneration",
        "",
        "refreshGeneration",
        "lastRefresh",
        "",
        "background",
        "name",
        "work",
        "post",
        "refresh",
        "force",
        "set",
        "next",
        "lookUp",
        "update",
        "app",
        "forgetLookups",
        "guestChanged",
        "reset",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final apps:Lorg/lighttouch/android/GuestApps;

.field private final changed:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field

.field private final confirmed:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private final error$delegate:Landroidx/compose/runtime/MutableState;

.field private final handler:Landroid/os/Handler;

.field private lastRefresh:J

.field private final list$delegate:Landroidx/compose/runtime/MutableState;

.field private final loading$delegate:Landroidx/compose/runtime/MutableState;

.field private final lookupError$delegate:Landroidx/compose/runtime/MutableState;

.field private lookupGeneration:I

.field private final lookups$delegate:Landroidx/compose/runtime/MutableState;

.field private final muxSocket:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final plain$delegate:Landroidx/compose/runtime/MutableState;

.field private refreshGeneration:I

.field private final target:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Lorg/lighttouch/android/StoreTarget;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$3xt979I41sTDZ_9f3vsl18Wvq9k(Ljava/util/List;Lorg/lighttouch/android/InstalledList;ILorg/lighttouch/android/StoreTarget;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/InstalledList;->lookUp$lambda$14(Ljava/util/List;Lorg/lighttouch/android/InstalledList;ILorg/lighttouch/android/StoreTarget;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ir0NlbDoq810kZfgz6nJX3aJWm4(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/InstalledList;->refresh$lambda$6$lambda$5(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ffvkV-Ik8BXK_ls934mBa9Y39AY(Lorg/lighttouch/android/InstalledList;Ljava/lang/String;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/InstalledList;->refresh$lambda$6(Lorg/lighttouch/android/InstalledList;Ljava/lang/String;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$nmrEfoP_YIAwnKiqpbRLsLdqgSQ(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/InstalledList;->background$lambda$0(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$o2Hpt4C3QcLJYbOZOLdIvxqcTZ4(Lkotlin/jvm/functions/Function0;)V
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/InstalledList;->post$lambda$1(Lkotlin/jvm/functions/Function0;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qgNvuMoBCIY46DmNbOUhDFrLJx8(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/InstalledList;->lookUp$lambda$14$lambda$13(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/InstalledList;->$stable:I

    return-void
.end method

.method public constructor <init>(Lorg/lighttouch/android/GuestApps;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V
    .locals 3
    .param p1, "apps"    # Lorg/lighttouch/android/GuestApps;
    .param p2, "muxSocket"    # Lkotlin/jvm/functions/Function0;
    .param p3, "target"    # Lkotlin/jvm/functions/Function0;
    .param p4, "confirmed"    # Lkotlin/jvm/functions/Function0;
    .param p5, "changed"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestApps;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lorg/lighttouch/android/StoreTarget;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "apps"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "muxSocket"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "confirmed"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "changed"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/InstalledList;->apps:Lorg/lighttouch/android/GuestApps;

    iput-object p2, p0, Lorg/lighttouch/android/InstalledList;->muxSocket:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Lorg/lighttouch/android/InstalledList;->target:Lkotlin/jvm/functions/Function0;

    .line 35
    iput-object p4, p0, Lorg/lighttouch/android/InstalledList;->confirmed:Lkotlin/jvm/functions/Function0;

    iput-object p5, p0, Lorg/lighttouch/android/InstalledList;->changed:Lkotlin/jvm/functions/Function1;

    .line 36
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/lighttouch/android/InstalledList;->handler:Landroid/os/Handler;

    .line 37
    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/InstalledList;->list$delegate:Landroidx/compose/runtime/MutableState;

    .line 38
    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/InstalledList;->loading$delegate:Landroidx/compose/runtime/MutableState;

    .line 39
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/InstalledList;->error$delegate:Landroidx/compose/runtime/MutableState;

    .line 40
    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v2

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/InstalledList;->lookups$delegate:Landroidx/compose/runtime/MutableState;

    .line 41
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    iput-object v2, p0, Lorg/lighttouch/android/InstalledList;->lookupError$delegate:Landroidx/compose/runtime/MutableState;

    .line 43
    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/InstalledList;->plain$delegate:Landroidx/compose/runtime/MutableState;

    .line 34
    return-void
.end method

.method private final background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V
    .locals 2
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "work"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 48
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda3;

    invoke-direct {v1, p2}, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-direct {v0, v1, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static final background$lambda$0(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 48
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method private static final lookUp$lambda$14(Ljava/util/List;Lorg/lighttouch/android/InstalledList;ILorg/lighttouch/android/StoreTarget;)Lkotlin/Unit;
    .locals 5
    .param p0, "$pending"    # Ljava/util/List;
    .param p1, "this$0"    # Lorg/lighttouch/android/InstalledList;
    .param p2, "$generation"    # I
    .param p3, "$t"    # Lorg/lighttouch/android/StoreTarget;

    .line 85
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 86
    .local v1, "id":Ljava/lang/String;
    :try_start_0
    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v2, p1

    .line 230
    .local v2, "$this$lookUp_u24lambda_u2414_u24lambda_u249\\1":Lorg/lighttouch/android/InstalledList;
    const/4 v3, 0x0

    .line 86
    .local v3, "$i$a$-runCatching-InstalledList$lookUp$1$outcome$1\\1\\86\\0":I
    sget-object v4, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v4, v1, p3}, Lorg/lighttouch/android/LegacyStore;->lookup(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Lorg/lighttouch/android/LegacyStore$Known;

    move-result-object v4

    .end local v2    # "$this$lookUp_u24lambda_u2414_u24lambda_u249\\1":Lorg/lighttouch/android/InstalledList;
    .end local v3    # "$i$a$-runCatching-InstalledList$lookUp$1$outcome$1\\1\\86\\0":I
    invoke-static {v4}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v2}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 87
    .local v2, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v3, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda4;

    invoke-direct {v3, p2, p1, v2, v1}, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda4;-><init>(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p1, v3}, Lorg/lighttouch/android/InstalledList;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 92
    invoke-static {v2}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    iget v3, p1, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    if-eq p2, v3, :cond_0

    .line 94
    .end local v1    # "id":Ljava/lang/String;
    .end local v2    # "outcome":Ljava/lang/Object;
    :cond_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final lookUp$lambda$14$lambda$13(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)Lkotlin/Unit;
    .locals 6
    .param p0, "$generation"    # I
    .param p1, "this$0"    # Lorg/lighttouch/android/InstalledList;
    .param p2, "$outcome"    # Ljava/lang/Object;
    .param p3, "$id"    # Ljava/lang/String;

    .line 88
    iget v0, p1, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 89
    :cond_0
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move-object v0, p2

    check-cast v0, Lorg/lighttouch/android/LegacyStore$Known;

    .line 230
    .local v0, "found\\1":Lorg/lighttouch/android/LegacyStore$Known;
    const/4 v1, 0x0

    .line 89
    .local v1, "$i$a$-onSuccess-InstalledList$lookUp$1$1$1\\1\\89\\0":I
    invoke-virtual {p1}, Lorg/lighttouch/android/InstalledList;->getLookups()Ljava/util/Map;

    move-result-object v2

    if-eqz v0, :cond_1

    .line 230
    move-object v3, v0

    .local v3, "it\\2":Lorg/lighttouch/android/LegacyStore$Known;
    const/4 v4, 0x0

    .line 89
    .local v4, "$i$a$-let-InstalledList$lookUp$1$1$1$1\\2\\89\\1":I
    new-instance v5, Lorg/lighttouch/android/Lookup$Found;

    invoke-direct {v5, v3}, Lorg/lighttouch/android/Lookup$Found;-><init>(Lorg/lighttouch/android/LegacyStore$Known;)V

    .end local v3    # "it\\2":Lorg/lighttouch/android/LegacyStore$Known;
    .end local v4    # "$i$a$-let-InstalledList$lookUp$1$1$1$1\\2\\89\\1":I
    check-cast v5, Lorg/lighttouch/android/Lookup;

    goto :goto_0

    :cond_1
    sget-object v3, Lorg/lighttouch/android/Lookup$Missing;->INSTANCE:Lorg/lighttouch/android/Lookup$Missing;

    move-object v5, v3

    check-cast v5, Lorg/lighttouch/android/Lookup;

    :goto_0
    invoke-static {p3, v5}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/collections/MapsKt;->plus(Ljava/util/Map;Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/InstalledList;->setLookups(Ljava/util/Map;)V

    .line 90
    .end local v0    # "found\\1":Lorg/lighttouch/android/LegacyStore$Known;
    .end local v1    # "$i$a$-onSuccess-InstalledList$lookUp$1$1$1\\1\\89\\0":I
    :cond_2
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 230
    .local v0, "it\\4":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 90
    .local v1, "$i$a$-onFailure-InstalledList$lookUp$1$1$2\\4\\90\\0":I
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    const-string v2, "\u65e0\u6cd5\u8fde\u63a5\u65e7\u7248\u5546\u5e97"

    :cond_3
    invoke-virtual {p1, v2}, Lorg/lighttouch/android/InstalledList;->setLookupError(Ljava/lang/String;)V

    .line 91
    .end local v0    # "it\\4":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-InstalledList$lookUp$1$1$2\\4\\90\\0":I
    :cond_4
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private final post(Lkotlin/jvm/functions/Function0;)Z
    .locals 2
    .param p1, "work"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;)Z"
        }
    .end annotation

    .line 49
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->handler:Landroid/os/Handler;

    new-instance v1, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda0;

    invoke-direct {v1, p1}, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/functions/Function0;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v0

    return v0
.end method

.method private static final post$lambda$1(Lkotlin/jvm/functions/Function0;)V
    .locals 0
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function0;

    .line 49
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    return-void
.end method

.method public static synthetic refresh$default(Lorg/lighttouch/android/InstalledList;ZILjava/lang/Object;)V
    .locals 0

    .line 52
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_0

    const/4 p1, 0x0

    :cond_0
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/InstalledList;->refresh(Z)V

    return-void
.end method

.method private static final refresh$lambda$6(Lorg/lighttouch/android/InstalledList;Ljava/lang/String;I)Lkotlin/Unit;
    .locals 3
    .param p0, "this$0"    # Lorg/lighttouch/android/InstalledList;
    .param p1, "$socket"    # Ljava/lang/String;
    .param p2, "$generation"    # I

    .line 59
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, p0

    .line 230
    .local v0, "$this$refresh_u24lambda_u246_u24lambda_u242\\1":Lorg/lighttouch/android/InstalledList;
    const/4 v1, 0x0

    .line 59
    .local v1, "$i$a$-runCatching-InstalledList$refresh$1$outcome$1\\1\\59\\0":I
    iget-object v2, v0, Lorg/lighttouch/android/InstalledList;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v2, p1}, Lorg/lighttouch/android/GuestApps;->installedApps(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    .end local v0    # "$this$refresh_u24lambda_u246_u24lambda_u242\\1":Lorg/lighttouch/android/InstalledList;
    .end local v1    # "$i$a$-runCatching-InstalledList$refresh$1$outcome$1\\1\\59\\0":I
    invoke-static {v2}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 60
    .local v0, "outcome":Ljava/lang/Object;
    :goto_0
    new-instance v1, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda5;

    invoke-direct {v1, p2, p0, v0, p1}, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda5;-><init>(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v1}, Lorg/lighttouch/android/InstalledList;->post(Lkotlin/jvm/functions/Function0;)Z

    .line 66
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final refresh$lambda$6$lambda$5(ILorg/lighttouch/android/InstalledList;Ljava/lang/Object;Ljava/lang/String;)Lkotlin/Unit;
    .locals 5
    .param p0, "$generation"    # I
    .param p1, "this$0"    # Lorg/lighttouch/android/InstalledList;
    .param p2, "$outcome"    # Ljava/lang/Object;
    .param p3, "$socket"    # Ljava/lang/String;

    .line 61
    iget v0, p1, Lorg/lighttouch/android/InstalledList;->refreshGeneration:I

    if-eq p0, v0, :cond_0

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 62
    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/InstalledList;->setLoading(Z)V

    .line 63
    invoke-static {p2}, Lkotlin/Result;->isSuccess-impl(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    move-object v0, p2

    check-cast v0, Ljava/util/List;

    .line 230
    .local v0, "it\\1":Ljava/util/List;
    const/4 v1, 0x0

    .line 63
    .local v1, "$i$a$-onSuccess-InstalledList$refresh$1$1$1\\1\\63\\0":I
    iget-object v2, p1, Lorg/lighttouch/android/InstalledList;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p1, v0}, Lorg/lighttouch/android/InstalledList;->set(Ljava/util/List;)V

    .line 64
    .end local v0    # "it\\1":Ljava/util/List;
    .end local v1    # "$i$a$-onSuccess-InstalledList$refresh$1$1$1\\1\\63\\0":I
    :cond_1
    invoke-static {p2}, Lkotlin/Result;->exceptionOrNull-impl(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 230
    .local v0, "it\\3":Ljava/lang/Throwable;
    const/4 v1, 0x0

    .line 64
    .local v1, "$i$a$-onFailure-InstalledList$refresh$1$1$2\\3\\64\\0":I
    iget-object v2, p1, Lorg/lighttouch/android/InstalledList;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Couldn\'t read the apps on this device: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Lorg/lighttouch/android/InstalledList;->setError(Ljava/lang/String;)V

    .line 65
    .end local v0    # "it\\3":Ljava/lang/Throwable;
    .end local v1    # "$i$a$-onFailure-InstalledList$refresh$1$1$2\\3\\64\\0":I
    :cond_2
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public final forgetLookups()V
    .locals 1

    .line 101
    iget v0, p0, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setLookups(Ljava/util/Map;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setLookupError(Ljava/lang/String;)V

    return-void
.end method

.method public final getError()Ljava/lang/String;
    .locals 3

    .line 39
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->error$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 211
    .local v2, "$i$f$getValue\\1\\39":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\39":I
    check-cast v0, Ljava/lang/String;

    .line 39
    return-object v0
.end method

.method public final getList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;"
        }
    .end annotation

    .line 37
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->list$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 205
    .local v2, "$i$f$getValue\\1\\37":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\37":I
    check-cast v0, Ljava/util/List;

    .line 37
    return-object v0
.end method

.method public final getLoading()Z
    .locals 3

    .line 38
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->loading$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 208
    .local v2, "$i$f$getValue\\1\\38":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\38":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 38
    return v0
.end method

.method public final getLookupError()Ljava/lang/String;
    .locals 3

    .line 41
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->lookupError$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 217
    .local v2, "$i$f$getValue\\1\\41":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\41":I
    check-cast v0, Ljava/lang/String;

    .line 41
    return-object v0
.end method

.method public final getLookups()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/Lookup;",
            ">;"
        }
    .end annotation

    .line 40
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->lookups$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 214
    .local v2, "$i$f$getValue\\1\\40":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\40":I
    check-cast v0, Ljava/util/Map;

    .line 40
    return-object v0
.end method

.method public final getPlain()Lorg/lighttouch/android/InstalledApp;
    .locals 3

    .line 43
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->plain$delegate:Landroidx/compose/runtime/MutableState;

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 220
    .local v2, "$i$f$getValue\\1\\43":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$getValue\\1\\43":I
    check-cast v0, Lorg/lighttouch/android/InstalledApp;

    .line 43
    return-object v0
.end method

.method public final guestChanged()V
    .locals 1

    .line 104
    iget v0, p0, Lorg/lighttouch/android/InstalledList;->refreshGeneration:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lorg/lighttouch/android/InstalledList;->refreshGeneration:I

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setLoading(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setList(Ljava/util/List;)V

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setError(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setPlain(Lorg/lighttouch/android/InstalledApp;)V

    return-void
.end method

.method public final lookUp()V
    .locals 11

    .line 79
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->target:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/lighttouch/android/StoreTarget;

    if-nez v0, :cond_0

    return-void

    .line 80
    .local v0, "t":Lorg/lighttouch/android/StoreTarget;
    :cond_0
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->getList()Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_6

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 223
    .local v2, "$i$f$map\\1\\80":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 224
    .local v5, "$i$f$mapTo\\2\\223":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 225
    .local v7, "item\\2":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Lorg/lighttouch/android/InstalledApp;

    .local v8, "it\\3":Lorg/lighttouch/android/InstalledApp;
    const/4 v9, 0x0

    .line 80
    .local v9, "$i$a$-map-InstalledList$lookUp$pending$1\\3\\225\\0":I
    invoke-virtual {v8}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v8

    .line 225
    .end local v8    # "it\\3":Lorg/lighttouch/android/InstalledApp;
    .end local v9    # "$i$a$-map-InstalledList$lookUp$pending$1\\3\\225\\0":I
    invoke-interface {v3, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 226
    .end local v7    # "item\\2":Ljava/lang/Object;
    :cond_1
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo\\2\\223":I
    check-cast v3, Ljava/util/List;

    .line 223
    nop

    .line 80
    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map\\1\\80":I
    move-object v1, v3

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$filter\\4":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 227
    .local v2, "$i$f$filter\\4\\80":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\5":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$filterTo\\5":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 228
    .local v5, "$i$f$filterTo\\5\\227":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_2
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element\\5":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/lang/String;

    .local v8, "it\\6":Ljava/lang/String;
    const/4 v9, 0x0

    .line 80
    .local v9, "$i$a$-filter-InstalledList$lookUp$pending$2\\6\\228\\0":I
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->getLookups()Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    .line 228
    .end local v8    # "it\\6":Ljava/lang/String;
    .end local v9    # "$i$a$-filter-InstalledList$lookUp$pending$2\\6\\228\\0":I
    if-nez v10, :cond_2

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 229
    .end local v7    # "element\\5":Ljava/lang/Object;
    :cond_3
    nop

    .end local v3    # "destination\\5":Ljava/util/Collection;
    .end local v4    # "$this$filterTo\\5":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo\\5\\227":I
    check-cast v3, Ljava/util/List;

    .line 227
    nop

    .line 80
    .end local v1    # "$this$filter\\4":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter\\4\\80":I
    nop

    .line 81
    .local v3, "pending":Ljava/util/List;
    iget-object v1, p0, Lorg/lighttouch/android/InstalledList;->confirmed:Lkotlin/jvm/functions/Function0;

    invoke-interface {v1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_2

    .line 82
    :cond_4
    iget v1, p0, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    iget v1, p0, Lorg/lighttouch/android/InstalledList;->lookupGeneration:I

    .line 83
    .local v1, "generation":I
    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/InstalledList;->setLookupError(Ljava/lang/String;)V

    .line 84
    new-instance v2, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda2;

    invoke-direct {v2, v3, p0, v1, v0}, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda2;-><init>(Ljava/util/List;Lorg/lighttouch/android/InstalledList;ILorg/lighttouch/android/StoreTarget;)V

    const-string v4, "store-lookup"

    invoke-direct {p0, v4, v2}, Lorg/lighttouch/android/InstalledList;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 95
    return-void

    .line 81
    .end local v1    # "generation":I
    :cond_5
    :goto_2
    return-void

    .line 80
    .end local v3    # "pending":Ljava/util/List;
    :cond_6
    return-void
.end method

.method public final refresh(Z)V
    .locals 5
    .param p1, "force"    # Z

    .line 53
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->muxSocket:Lkotlin/jvm/functions/Function0;

    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    .line 54
    .local v0, "socket":Ljava/lang/String;
    :cond_0
    iget-object v1, p0, Lorg/lighttouch/android/InstalledList;->apps:Lorg/lighttouch/android/GuestApps;

    invoke-virtual {v1}, Lorg/lighttouch/android/GuestApps;->getAvailable()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->getLoading()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    .line 55
    :cond_1
    if-nez p1, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->getList()Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iget-wide v3, p0, Lorg/lighttouch/android/InstalledList;->lastRefresh:J

    sub-long/2addr v1, v3

    const-wide/16 v3, 0x2710

    cmp-long v1, v1, v3

    if-gez v1, :cond_2

    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->lookUp()V

    return-void

    .line 56
    :cond_2
    iget v1, p0, Lorg/lighttouch/android/InstalledList;->refreshGeneration:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, p0, Lorg/lighttouch/android/InstalledList;->refreshGeneration:I

    iget v1, p0, Lorg/lighttouch/android/InstalledList;->refreshGeneration:I

    .line 57
    .local v1, "generation":I
    invoke-virtual {p0, v2}, Lorg/lighttouch/android/InstalledList;->setLoading(Z)V

    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Lorg/lighttouch/android/InstalledList;->setError(Ljava/lang/String;)V

    .line 58
    new-instance v2, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, v0, v1}, Lorg/lighttouch/android/InstalledList$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/InstalledList;Ljava/lang/String;I)V

    const-string v3, "store-installed"

    invoke-direct {p0, v3, v2}, Lorg/lighttouch/android/InstalledList;->background(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 67
    return-void

    .line 54
    .end local v1    # "generation":I
    :cond_3
    :goto_0
    return-void
.end method

.method public final reset()V
    .locals 0

    .line 106
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->guestChanged()V

    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->forgetLookups()V

    return-void
.end method

.method public final set(Ljava/util/List;)V
    .locals 2
    .param p1, "next"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;)V"
        }
    .end annotation

    const-string v0, "next"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lorg/lighttouch/android/InstalledList;->lastRefresh:J

    .line 72
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/InstalledList;->setList(Ljava/util/List;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/InstalledList;->setError(Ljava/lang/String;)V

    .line 73
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->changed:Lkotlin/jvm/functions/Function1;

    invoke-interface {v0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->lookUp()V

    .line 75
    return-void
.end method

.method public final setError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 39
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->error$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 212
    .local v2, "$i$f$setValue\\1\\39":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 213
    nop

    .line 39
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\39":I
    return-void
.end method

.method public final setList(Ljava/util/List;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/InstalledApp;",
            ">;)V"
        }
    .end annotation

    .line 37
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->list$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 206
    .local v2, "$i$f$setValue\\1\\37":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 207
    nop

    .line 37
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\37":I
    return-void
.end method

.method public final setLoading(Z)V
    .locals 4
    .param p1, "<set-?>"    # Z

    .line 38
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->loading$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    const/4 v3, 0x0

    .line 209
    .local v3, "$i$f$setValue\\1\\38":I
    invoke-interface {v0, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 210
    nop

    .line 38
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$i$f$setValue\\1\\38":I
    return-void
.end method

.method public final setLookupError(Ljava/lang/String;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 41
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->lookupError$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 218
    .local v2, "$i$f$setValue\\1\\41":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 219
    nop

    .line 41
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\41":I
    return-void
.end method

.method public final setLookups(Ljava/util/Map;)V
    .locals 3
    .param p1, "<set-?>"    # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "+",
            "Lorg/lighttouch/android/Lookup;",
            ">;)V"
        }
    .end annotation

    const-string v0, "<set-?>"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->lookups$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 215
    .local v2, "$i$f$setValue\\1\\40":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 216
    nop

    .line 40
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\40":I
    return-void
.end method

.method public final setPlain(Lorg/lighttouch/android/InstalledApp;)V
    .locals 3
    .param p1, "<set-?>"    # Lorg/lighttouch/android/InstalledApp;

    .line 43
    iget-object v0, p0, Lorg/lighttouch/android/InstalledList;->plain$delegate:Landroidx/compose/runtime/MutableState;

    .local v0, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v2, 0x0

    .line 221
    .local v2, "$i$f$setValue\\1\\43":I
    invoke-interface {v0, p1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 222
    nop

    .line 43
    .end local v0    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "$i$f$setValue\\1\\43":I
    return-void
.end method

.method public final update(Lorg/lighttouch/android/InstalledApp;)Ljava/lang/String;
    .locals 5
    .param p1, "app"    # Lorg/lighttouch/android/InstalledApp;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    invoke-virtual {p0}, Lorg/lighttouch/android/InstalledList;->getLookups()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {p1}, Lorg/lighttouch/android/InstalledApp;->getBundleId()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Lorg/lighttouch/android/Lookup$Found;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    check-cast v0, Lorg/lighttouch/android/Lookup$Found;

    goto :goto_0

    :cond_0
    move-object v0, v2

    :goto_0
    if-eqz v0, :cond_1

    .line 230
    .local v0, "it\\1":Lorg/lighttouch/android/Lookup$Found;
    const/4 v1, 0x0

    .line 98
    .local v1, "$i$a$-let-InstalledList$update$1\\1\\98\\0":I
    sget-object v2, Lorg/lighttouch/android/StoreVersions;->INSTANCE:Lorg/lighttouch/android/StoreVersions;

    invoke-virtual {p1}, Lorg/lighttouch/android/InstalledApp;->getVersion()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lorg/lighttouch/android/Lookup$Found;->getKnown()Lorg/lighttouch/android/LegacyStore$Known;

    move-result-object v4

    invoke-virtual {v4}, Lorg/lighttouch/android/LegacyStore$Known;->getNewest()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lorg/lighttouch/android/StoreVersions;->updateTo(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .end local v0    # "it\\1":Lorg/lighttouch/android/Lookup$Found;
    .end local v1    # "$i$a$-let-InstalledList$update$1\\1\\98\\0":I
    :cond_1
    return-object v2
.end method

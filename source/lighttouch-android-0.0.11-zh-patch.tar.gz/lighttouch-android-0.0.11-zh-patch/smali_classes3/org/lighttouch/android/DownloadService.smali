.class public final Lorg/lighttouch/android/DownloadService;
.super Landroid/app/Service;
.source "DownloadService.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/DownloadService$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDownloadService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DownloadService.kt\norg/lighttouch/android/DownloadService\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,70:1\n1#2:71\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0008\u0007\u0018\u0000 \u00132\u00020\u0001:\u0001\u0013B\u0007\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\"\u0010\u0007\u001a\u00020\u00082\u0008\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\u00082\u0006\u0010\u000c\u001a\u00020\u0008H\u0016J\u0018\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000c\u001a\u00020\u00082\u0006\u0010\u000f\u001a\u00020\u0008H\u0016J\u0008\u0010\u0010\u001a\u00020\u000eH\u0016J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0006\u0010\t\u001a\u00020\nH\u0016R\u0014\u0010\u0004\u001a\u0008\u0018\u00010\u0005R\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"
    }
    d2 = {
        "Lorg/lighttouch/android/DownloadService;",
        "Landroid/app/Service;",
        "<init>",
        "()V",
        "awake",
        "Landroid/os/PowerManager$WakeLock;",
        "Landroid/os/PowerManager;",
        "onStartCommand",
        "",
        "intent",
        "Landroid/content/Intent;",
        "flags",
        "startId",
        "onTimeout",
        "",
        "fgsType",
        "onDestroy",
        "onBind",
        "Landroid/os/IBinder;",
        "Companion",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lorg/lighttouch/android/DownloadService$Companion;

.field private static holders:I


# instance fields
.field private awake:Landroid/os/PowerManager$WakeLock;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lorg/lighttouch/android/DownloadService$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lorg/lighttouch/android/DownloadService$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/DownloadService;->$stable:I

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static final synthetic access$getHolders$cp()I
    .locals 1

    .line 14
    sget v0, Lorg/lighttouch/android/DownloadService;->holders:I

    return v0
.end method

.method public static final synthetic access$setHolders$cp(I)V
    .locals 0
    .param p0, "<set-?>"    # I

    .line 14
    sput p0, Lorg/lighttouch/android/DownloadService;->holders:I

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    const-string v0, "intent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    const/4 v0, 0x0

    return-object v0
.end method

.method public onDestroy()V
    .locals 3

    .line 26
    iget-object v0, p0, Lorg/lighttouch/android/DownloadService;->awake:Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_0

    .line 71
    .local v0, "it\\1":Landroid/os/PowerManager$WakeLock;
    const/4 v1, 0x0

    .line 26
    .local v1, "$i$a$-let-DownloadService$onDestroy$1\\1\\26\\0":I
    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    .end local v0    # "it\\1":Landroid/os/PowerManager$WakeLock;
    .end local v1    # "$i$a$-let-DownloadService$onDestroy$1\\1\\26\\0":I
    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/lighttouch/android/DownloadService;->awake:Landroid/os/PowerManager$WakeLock;

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 5
    .param p1, "intent"    # Landroid/content/Intent;
    .param p2, "flags"    # I
    .param p3, "startId"    # I

    .line 18
    sget-object v0, Lorg/lighttouch/android/DownloadService;->Companion:Lorg/lighttouch/android/DownloadService$Companion;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    if-eqz p1, :cond_0

    const-string v2, "text"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    :cond_0
    const-string v2, "\u6b63\u5728\u4e0b\u8f7d iOS"

    :cond_1
    const/4 v3, 0x0

    invoke-static {v0, v1, v2, v3}, Lorg/lighttouch/android/DownloadService$Companion;->access$notification(Lorg/lighttouch/android/DownloadService$Companion;Landroid/content/Context;Ljava/lang/String;Ljava/lang/Float;)Landroid/app/Notification;

    move-result-object v0

    const/4 v1, 0x3

    invoke-virtual {p0, v1, v0}, Lorg/lighttouch/android/DownloadService;->startForeground(ILandroid/app/Notification;)V

    .line 20
    iget-object v0, p0, Lorg/lighttouch/android/DownloadService;->awake:Landroid/os/PowerManager$WakeLock;

    if-nez v0, :cond_2

    const-class v0, Landroid/os/PowerManager;

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/DownloadService;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    .line 21
    const/4 v1, 0x1

    const-string v2, "LightTouch:download"

    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v0

    .line 71
    move-object v1, v0

    .local v1, "$this$onStartCommand_u24lambda_u240\\1":Landroid/os/PowerManager$WakeLock;
    const/4 v2, 0x0

    .line 21
    .local v2, "$i$a$-apply-DownloadService$onStartCommand$1\\1\\21\\0":I
    const-wide/32 v3, 0xa4cb80

    invoke-virtual {v1, v3, v4}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    .line 20
    .end local v1    # "$this$onStartCommand_u24lambda_u240\\1":Landroid/os/PowerManager$WakeLock;
    .end local v2    # "$i$a$-apply-DownloadService$onStartCommand$1\\1\\21\\0":I
    iput-object v0, p0, Lorg/lighttouch/android/DownloadService;->awake:Landroid/os/PowerManager$WakeLock;

    .line 22
    :cond_2
    const/4 v0, 0x2

    return v0
.end method

.method public onTimeout(II)V
    .locals 0
    .param p1, "startId"    # I
    .param p2, "fgsType"    # I

    .line 25
    invoke-virtual {p0}, Lorg/lighttouch/android/DownloadService;->stopSelf()V

    return-void
.end method

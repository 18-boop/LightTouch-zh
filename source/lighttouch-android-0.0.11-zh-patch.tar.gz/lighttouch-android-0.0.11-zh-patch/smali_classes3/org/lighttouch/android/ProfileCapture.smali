.class public final Lorg/lighttouch/android/ProfileCapture;
.super Ljava/lang/Object;
.source "ProfileCapture.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nProfileCapture.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ProfileCapture.kt\norg/lighttouch/android/ProfileCapture\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 5 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n+ 6 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,196:1\n1#2:197\n3829#3:198\n4344#3,2:199\n3829#3:213\n4344#3,2:214\n1068#4:201\n1869#4,2:202\n1869#4,2:216\n490#5,7:204\n216#6,2:211\n*S KotlinDebug\n*F\n+ 1 ProfileCapture.kt\norg/lighttouch/android/ProfileCapture\n*L\n83#1:198\n83#1:199,2\n125#1:213\n125#1:214,2\n87#1:201\n87#1:202,2\n125#1:216,2\n118#1:204,7\n119#1:211,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0006\n\u0002\u0010\u0011\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0006\n\u0002\u0010\u0002\n\u0002\u0008\u0003\u0008\u0001\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0004\u0008\u0007\u0010\u0008J\u0010\u0010\u0015\u001a\u00020\u000e2\u0006\u0010\u0016\u001a\u00020\u0006H\u0002J\u000e\u0010\u0017\u001a\u00020\u00062\u0006\u0010\u0018\u001a\u00020\u0013J\u0013\u0010\u0019\u001a\u0008\u0012\u0004\u0012\u00020\u00130\u001aH\u0002\u00a2\u0006\u0002\u0010\u001bJ\u0014\u0010\u001c\u001a\u0010\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u001dJ\u0008\u0010\u001e\u001a\u0004\u0018\u00010\nJ\u000e\u0010#\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u0013J \u0010$\u001a\u00020\u00062\u0006\u0010%\u001a\u00020 2\u0006\u0010\u0018\u001a\u00020\u00132\u0008\u0008\u0002\u0010\u001f\u001a\u00020 J\u0018\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020\u00132\u0008\u0008\u0002\u0010)\u001a\u00020 R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\n \u000b*\u0004\u0018\u00010\n0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000c\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u001f\u001a\u00020 8F\u00a2\u0006\u0006\u001a\u0004\u0008!\u0010\"\u00a8\u0006*"
    }
    d2 = {
        "Lorg/lighttouch/android/ProfileCapture;",
        "",
        "context",
        "Landroid/content/Context;",
        "observations",
        "Lkotlin/Function0;",
        "Landroid/os/Bundle;",
        "<init>",
        "(Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V",
        "filesDir",
        "Ljava/io/File;",
        "kotlin.jvm.PlatformType",
        "directory",
        "metadata",
        "Lorg/json/JSONObject;",
        "engineLog",
        "logOffset",
        "",
        "notice",
        "",
        "lastError",
        "encode",
        "bundle",
        "snapshot",
        "guestState",
        "frontmostApp",
        "",
        "()[Ljava/lang/String;",
        "frontmostIdentity",
        "Lkotlin/Pair;",
        "currentEvents",
        "automatic",
        "",
        "getAutomatic",
        "()Z",
        "startAutomatic",
        "change",
        "recording",
        "finish",
        "",
        "reason",
        "keep",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final context:Landroid/content/Context;

.field private directory:Ljava/io/File;

.field private engineLog:Ljava/io/File;

.field private final filesDir:Ljava/io/File;

.field private lastError:Ljava/lang/String;

.field private logOffset:J

.field private metadata:Lorg/json/JSONObject;

.field private notice:Ljava/lang/String;

.field private final observations:Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function0<",
            "Landroid/os/Bundle;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/ProfileCapture;->$stable:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lkotlin/jvm/functions/Function0;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "observations"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lkotlin/jvm/functions/Function0<",
            "Landroid/os/Bundle;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "observations"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/lighttouch/android/ProfileCapture;->context:Landroid/content/Context;

    iput-object p2, p0, Lorg/lighttouch/android/ProfileCapture;->observations:Lkotlin/jvm/functions/Function0;

    .line 14
    iget-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    iput-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->filesDir:Ljava/io/File;

    .line 19
    const-string v0, ""

    iput-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->notice:Ljava/lang/String;

    .line 20
    iput-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    .line 13
    return-void
.end method

.method public static synthetic change$default(Lorg/lighttouch/android/ProfileCapture;ZLjava/lang/String;ZILjava/lang/Object;)Landroid/os/Bundle;
    .locals 0

    .line 91
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    const/4 p3, 0x0

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Lorg/lighttouch/android/ProfileCapture;->change(ZLjava/lang/String;Z)Landroid/os/Bundle;

    move-result-object p0

    return-object p0
.end method

.method private final encode(Landroid/os/Bundle;)Lorg/json/JSONObject;
    .locals 7
    .param p1, "bundle"    # Landroid/os/Bundle;

    .line 22
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    move-object v1, v0

    .local v1, "$this$encode_u24lambda_u240\\1":Lorg/json/JSONObject;
    const/4 v2, 0x0

    .line 23
    .local v2, "$i$a$-apply-ProfileCapture$encode$1\\1\\22\\0":I
    invoke-virtual {p1}, Landroid/os/Bundle;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 24
    .local v4, "key\\1":Ljava/lang/String;
    invoke-virtual {p1, v4}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    .line 25
    .local v5, "value\\1":Ljava/lang/Object;
    instance-of v6, v5, Landroid/os/Bundle;

    if-eqz v6, :cond_0

    move-object v6, v5

    check-cast v6, Landroid/os/Bundle;

    invoke-direct {p0, v6}, Lorg/lighttouch/android/ProfileCapture;->encode(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object v6

    goto :goto_1

    :cond_0
    invoke-static {v5}, Lorg/json/JSONObject;->wrap(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    :goto_1
    invoke-virtual {v1, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .end local v5    # "value\\1":Ljava/lang/Object;
    goto :goto_0

    .line 27
    .end local v4    # "key\\1":Ljava/lang/String;
    :cond_1
    nop

    .line 22
    .end local v1    # "$this$encode_u24lambda_u240\\1":Lorg/json/JSONObject;
    .end local v2    # "$i$a$-apply-ProfileCapture$encode$1\\1\\22\\0":I
    nop

    .line 27
    return-object v0
.end method

.method public static synthetic finish$default(Lorg/lighttouch/android/ProfileCapture;Ljava/lang/String;ZILjava/lang/Object;)V
    .locals 0

    .line 161
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x0

    :cond_0
    invoke-virtual {p0, p1, p2}, Lorg/lighttouch/android/ProfileCapture;->finish(Ljava/lang/String;Z)V

    return-void
.end method

.method private final frontmostApp()[Ljava/lang/String;
    .locals 12

    .line 44
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    const-string v1, ""

    const/16 v2, 0x7d0

    const/4 v3, 0x1

    invoke-virtual {v0, v3, v1, v2}, Lorg/lighttouch/android/Native;->guestRequest(ILjava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    .line 45
    .local v0, "request":[Ljava/lang/String;
    aget-object v1, v0, v3

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    move v1, v3

    goto :goto_0

    :cond_0
    move v1, v2

    :goto_0
    if-eqz v1, :cond_8

    .line 46
    aget-object v1, v0, v2

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    .line 47
    .local v4, "id":J
    const/4 v1, 0x0

    .line 48
    .local v1, "reply":Ljava/lang/Object;
    nop

    .line 49
    :try_start_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    const/16 v8, 0x9c4

    int-to-long v8, v8

    add-long/2addr v6, v8

    .line 51
    .local v6, "deadline":J
    :goto_1
    sget-object v8, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v8, v4, v5}, Lorg/lighttouch/android/Native;->guestPoll(J)[Ljava/lang/String;

    move-result-object v8

    move-object v1, v8

    .line 52
    const/4 v8, 0x3

    aget-object v9, v1, v8

    check-cast v9, Ljava/lang/CharSequence;

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-nez v9, :cond_1

    move v9, v3

    goto :goto_2

    :cond_1
    move v9, v2

    :goto_2
    if-eqz v9, :cond_7

    .line 53
    aget-object v8, v1, v2

    const-string v9, "1"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string v9, "Could not identify the current iOS app"

    if-eqz v8, :cond_4

    .line 54
    :try_start_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    cmp-long v8, v10, v6

    if-gez v8, :cond_2

    move v8, v3

    goto :goto_3

    :cond_2
    move v8, v2

    :goto_3
    if-eqz v8, :cond_3

    .line 55
    const-wide/16 v8, 0x19

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V

    .line 56
    goto :goto_1

    .line 197
    :cond_3
    const/4 v2, 0x0

    .line 54
    .local v2, "$i$a$-check-ProfileCapture$frontmostApp$3\\3\\54\\0":I
    nop

    .end local v2    # "$i$a$-check-ProfileCapture$frontmostApp$3\\3\\54\\0":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "request":[Ljava/lang/String;
    .end local v1    # "reply":Ljava/lang/Object;
    .end local v4    # "id":J
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    throw v2

    .line 57
    .restart local v0    # "request":[Ljava/lang/String;
    .restart local v1    # "reply":Ljava/lang/Object;
    .restart local v4    # "id":J
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_4
    aget-object v8, v1, v2

    const-string v10, "2"

    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_5

    aget-object v8, v1, v3

    const-string v10, "0"

    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v8, :cond_5

    goto :goto_4

    :cond_5
    move v3, v2

    :goto_4
    if-eqz v3, :cond_6

    .line 58
    .end local v6    # "deadline":J
    sget-object v2, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v2, v4, v5}, Lorg/lighttouch/android/Native;->guestCancel(J)V

    .line 59
    return-object v1

    .line 197
    .restart local v6    # "deadline":J
    :cond_6
    const/4 v2, 0x0

    .line 57
    .local v2, "$i$a$-check-ProfileCapture$frontmostApp$4\\4\\57\\0":I
    nop

    .end local v2    # "$i$a$-check-ProfileCapture$frontmostApp$4\\4\\57\\0":I
    :try_start_2
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "request":[Ljava/lang/String;
    .end local v1    # "reply":Ljava/lang/Object;
    .end local v4    # "id":J
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    throw v2

    .line 197
    .restart local v0    # "request":[Ljava/lang/String;
    .restart local v1    # "reply":Ljava/lang/Object;
    .restart local v4    # "id":J
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_7
    const/4 v2, 0x0

    .line 52
    .local v2, "$i$a$-check-ProfileCapture$frontmostApp$2\\2\\52\\0":I
    aget-object v3, v1, v8

    .end local v2    # "$i$a$-check-ProfileCapture$frontmostApp$2\\2\\52\\0":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v0    # "request":[Ljava/lang/String;
    .end local v1    # "reply":Ljava/lang/Object;
    .end local v4    # "id":J
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    throw v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 58
    .end local v6    # "deadline":J
    .restart local v0    # "request":[Ljava/lang/String;
    .restart local v1    # "reply":Ljava/lang/Object;
    .restart local v4    # "id":J
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :catchall_0
    move-exception v2

    sget-object v3, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v3, v4, v5}, Lorg/lighttouch/android/Native;->guestCancel(J)V

    throw v2

    .line 197
    .end local v1    # "reply":Ljava/lang/Object;
    .end local v4    # "id":J
    :cond_8
    const/4 v1, 0x0

    .line 45
    .local v1, "$i$a$-check-ProfileCapture$frontmostApp$1\\1\\45\\0":I
    aget-object v1, v0, v3

    .end local v1    # "$i$a$-check-ProfileCapture$frontmostApp$1\\1\\45\\0":I
    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
.end method


# virtual methods
.method public final declared-synchronized change(ZLjava/lang/String;Z)Landroid/os/Bundle;
    .locals 25
    .param p1, "recording"    # Z
    .param p2, "guestState"    # Ljava/lang/String;
    .param p3, "automatic"    # Z

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move/from16 v3, p3

    monitor-enter p0

    :try_start_0
    const-string v0, "guestState"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 92
    const-string v0, ""

    iput-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_e

    .line 93
    nop

    .line 94
    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v7, 0x0

    if-eqz p1, :cond_1e

    :try_start_1
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    if-nez v0, :cond_1e

    .line 95
    const-string v0, "running"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_e

    if-eqz v0, :cond_1d

    .line 97
    const/4 v0, 0x3

    if-eqz v3, :cond_0

    const/4 v8, 0x4

    :try_start_2
    new-array v8, v8, [Ljava/lang/String;

    const-string v9, "2"

    aput-object v9, v8, v7

    const-string v9, "0"

    aput-object v9, v8, v4

    const-string v9, ""

    aput-object v9, v8, v5

    const-string v9, ""

    aput-object v9, v8, v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_e

    goto :goto_0

    .line 152
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :catch_0
    move-exception v0

    move v3, v4

    move v15, v7

    goto/16 :goto_18

    .line 97
    :cond_0
    :try_start_3
    invoke-direct {v1}, Lorg/lighttouch/android/ProfileCapture;->frontmostApp()[Ljava/lang/String;

    move-result-object v8
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4
    .catchall {:try_start_3 .. :try_end_3} :catchall_e

    .line 98
    .local v8, "reply":[Ljava/lang/String;
    :goto_0
    if-eqz v3, :cond_1

    :try_start_4
    new-array v9, v5, [Ljava/lang/String;

    const-string v10, ""

    aput-object v10, v9, v7

    const-string v10, "Detailed timing"

    aput-object v10, v9, v4

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_e

    goto :goto_1

    :cond_1
    :try_start_5
    aget-object v9, v8, v5

    check-cast v9, Ljava/lang/CharSequence;

    invoke-static {v9}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    check-cast v9, Ljava/lang/CharSequence;

    invoke-static {v9}, Lkotlin/text/StringsKt;->lines(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v9

    .line 99
    .local v9, "identity":Ljava/util/List;
    :goto_1
    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v10
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4
    .catchall {:try_start_5 .. :try_end_5} :catchall_e

    if-lt v10, v5, :cond_3

    :try_start_6
    invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/CharSequence;

    invoke-static {v10}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v10

    if-nez v10, :cond_3

    if-nez v3, :cond_2

    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/CharSequence;

    invoke-static {v10}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v10
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_e

    if-nez v10, :cond_3

    :cond_2
    move v10, v4

    goto :goto_2

    :cond_3
    move v10, v7

    :goto_2
    if-eqz v10, :cond_1c

    .line 102
    :try_start_7
    new-instance v10, Ljava/io/File;

    iget-object v11, v1, Lorg/lighttouch/android/ProfileCapture;->filesDir:Ljava/io/File;

    const-string v12, "profiles"

    invoke-direct {v10, v11, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v11, v10

    .line 197
    .local v11, "$this$change_u24lambda_u2417\\3":Ljava/io/File;
    const/4 v12, 0x0

    .line 102
    .local v12, "$i$a$-apply-ProfileCapture$change$root$1\\3\\102\\0":I
    invoke-virtual {v11}, Ljava/io/File;->mkdirs()Z

    .line 103
    .end local v11    # "$this$change_u24lambda_u2417\\3":Ljava/io/File;
    .end local v12    # "$i$a$-apply-ProfileCapture$change$root$1\\3\\102\\0":I
    .local v10, "root":Ljava/io/File;
    new-instance v11, Ljava/io/File;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v14

    invoke-virtual {v14}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v14

    const-string v15, "toString(...)"

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v15, 0x8

    invoke-static {v14, v15}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v12, v13}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "-"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v10, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 104
    .local v11, "dir":Ljava/io/File;
    invoke-virtual {v11}, Ljava/io/File;->mkdir()Z

    move-result v12

    if-eqz v12, :cond_1b

    .line 105
    sget-object v12, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v12}, Lorg/lighttouch/android/Native;->status()[Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v0}, Lkotlin/collections/ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_4
    .catchall {:try_start_7 .. :try_end_7} :catchall_e

    if-eqz v0, :cond_5

    move-object v12, v0

    .line 197
    .local v12, "it\\5":Ljava/lang/String;
    const/4 v13, 0x0

    .line 105
    .local v13, "$i$a$-takeIf-ProfileCapture$change$log$1\\5\\105\\0":I
    :try_start_8
    move-object v14, v12

    check-cast v14, Ljava/lang/CharSequence;

    invoke-static {v14}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v14

    .end local v12    # "it\\5":Ljava/lang/String;
    .end local v13    # "$i$a$-takeIf-ProfileCapture$change$log$1\\5\\105\\0":I
    if-nez v14, :cond_4

    goto :goto_3

    :cond_4
    const/4 v0, 0x0

    :goto_3
    if-eqz v0, :cond_5

    .line 197
    .local v0, "it\\6":Ljava/lang/String;
    const/4 v12, 0x0

    .line 105
    .local v12, "$i$a$-let-ProfileCapture$change$log$2\\6\\105\\0":I
    new-instance v13, Ljava/io/File;

    invoke-direct {v13, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_e

    .end local v0    # "it\\6":Ljava/lang/String;
    .end local v12    # "$i$a$-let-ProfileCapture$change$log$2\\6\\105\\0":I
    goto :goto_4

    :cond_5
    const/4 v13, 0x0

    .line 106
    .local v13, "log":Ljava/io/File;
    :goto_4
    :try_start_9
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    move-object v12, v0

    .local v12, "$this$change_u24lambda_u2424\\7":Lorg/json/JSONObject;
    const/4 v14, 0x0

    .line 107
    .local v14, "$i$a$-apply-ProfileCapture$change$info$1\\7\\106\\0":I
    const-string v15, "format"

    invoke-virtual {v12, v15, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v15, "bundleId"

    move/from16 v16, v5

    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v12, v15, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "appName"

    invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    invoke-virtual {v12, v5, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 108
    const-string v5, "frontmostResponse"

    aget-object v15, v8, v16

    invoke-virtual {v12, v5, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "startedAtMs"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    invoke-virtual {v12, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 109
    const-string v5, "startedElapsedRealtimeNs"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    move-result-wide v6

    invoke-virtual {v12, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 110
    const-string v5, "startedMonotonicNs"

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v6

    invoke-virtual {v12, v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 111
    const-string v5, "manufacturer"

    sget-object v6, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "model"

    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 112
    const-string v5, "hardware"

    sget-object v6, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "androidBuild"

    sget-object v6, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 113
    const-string v5, "lightTouchVersionCode"

    const/16 v6, 0xb

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 114
    const-string v5, "lightTouchVersion"

    const-string v6, "0.0.11"

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v5, "workerPid"

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v6

    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 115
    const-string v5, "engineLog"

    if-eqz v13, :cond_6

    invoke-virtual {v13}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_7

    :cond_6
    const-string v6, ""

    :cond_7
    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 116
    const-string v5, "instructionAccounting"

    const-string v6, "IT_VCPU_ACCT"

    invoke-static {v6}, Ljava/lang/System;->getenv(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_8

    move v6, v4

    goto :goto_5

    :cond_8
    const/4 v6, 0x0

    :goto_5
    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 117
    const-string v5, "environment"

    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    move-object v7, v6

    .local v7, "$this$change_u24lambda_u2424_u24lambda_u2423\\8":Lorg/json/JSONObject;
    const/16 v17, 0x0

    .line 118
    .local v17, "$i$a$-apply-ProfileCapture$change$info$1$1\\8\\117\\7":I
    invoke-static {}, Ljava/lang/System;->getenv()Ljava/util/Map;

    move-result-object v15
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4
    .catchall {:try_start_9 .. :try_end_9} :catchall_e

    :try_start_a
    const-string v4, "getenv(...)"

    invoke-static {v15, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v4, v15

    .local v4, "$this$filterKeys\\9":Ljava/util/Map;
    const/16 v19, 0x0

    .line 204
    .local v19, "$i$f$filterKeys\\9\\118":I
    new-instance v15, Ljava/util/LinkedHashMap;

    invoke-direct {v15}, Ljava/util/LinkedHashMap;-><init>()V

    .line 205
    .local v15, "result\\9":Ljava/util/LinkedHashMap;
    invoke-interface {v4}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v20

    invoke-interface/range {v20 .. v20}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_6
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_d

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v21

    check-cast v21, Ljava/util/Map$Entry;

    .line 206
    .local v21, "entry\\9":Ljava/util/Map$Entry;
    invoke-interface/range {v21 .. v21}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v22

    check-cast v22, Ljava/lang/String;

    move-object/from16 v23, v22

    .local v23, "it\\10":Ljava/lang/String;
    const/16 v22, 0x0

    .line 118
    .local v22, "$i$a$-filterKeys-ProfileCapture$change$info$1$1$1\\10\\206\\8":I
    invoke-static/range {v23 .. v23}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const-string v2, "LT_"

    move-object/from16 v24, v4

    move-object/from16 v18, v8

    move/from16 v8, v16

    move-object/from16 v4, v23

    move-object/from16 v23, v10

    move-object/from16 v16, v15

    const/4 v10, 0x0

    const/4 v15, 0x0

    .end local v8    # "reply":[Ljava/lang/String;
    .end local v10    # "root":Ljava/io/File;
    .end local v15    # "result\\9":Ljava/util/LinkedHashMap;
    .local v4, "it\\10":Ljava/lang/String;
    .local v16, "result\\9":Ljava/util/LinkedHashMap;
    .local v18, "reply":[Ljava/lang/String;
    .local v23, "root":Ljava/io/File;
    .local v24, "$this$filterKeys\\9":Ljava/util/Map;
    invoke-static {v4, v2, v15, v8, v10}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_a

    const-string v2, "IT_GLES_"

    invoke-static {v4, v2, v15, v8, v10}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    move-object/from16 v8, v16

    .end local v16    # "result\\9":Ljava/util/LinkedHashMap;
    .local v8, "result\\9":Ljava/util/LinkedHashMap;
    if-nez v2, :cond_b

    const-string v2, "IT_VCPU_ACCT"

    invoke-static {v4, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9

    goto :goto_7

    :cond_9
    const/4 v2, 0x0

    goto :goto_8

    .end local v8    # "result\\9":Ljava/util/LinkedHashMap;
    .restart local v16    # "result\\9":Ljava/util/LinkedHashMap;
    :cond_a
    move-object/from16 v8, v16

    .end local v16    # "result\\9":Ljava/util/LinkedHashMap;
    .restart local v8    # "result\\9":Ljava/util/LinkedHashMap;
    :cond_b
    :goto_7
    const/4 v2, 0x1

    .line 206
    .end local v4    # "it\\10":Ljava/lang/String;
    .end local v22    # "$i$a$-filterKeys-ProfileCapture$change$info$1$1$1\\10\\206\\8":I
    :goto_8
    if-eqz v2, :cond_c

    .line 207
    invoke-interface/range {v21 .. v21}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-interface/range {v21 .. v21}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v8, v2, v4}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v2, p2

    move-object v15, v8

    move-object/from16 v8, v18

    move-object/from16 v10, v23

    move-object/from16 v4, v24

    const/16 v16, 0x2

    goto :goto_6

    .line 206
    :cond_c
    move-object/from16 v2, p2

    move-object v15, v8

    move-object/from16 v8, v18

    move-object/from16 v10, v23

    move-object/from16 v4, v24

    const/16 v16, 0x2

    goto :goto_6

    .line 210
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v21    # "entry\\9":Ljava/util/Map$Entry;
    .end local v23    # "root":Ljava/io/File;
    .end local v24    # "$this$filterKeys\\9":Ljava/util/Map;
    .local v4, "$this$filterKeys\\9":Ljava/util/Map;
    .local v8, "reply":[Ljava/lang/String;
    .restart local v10    # "root":Ljava/io/File;
    .restart local v15    # "result\\9":Ljava/util/LinkedHashMap;
    :cond_d
    move-object/from16 v24, v4

    move-object/from16 v18, v8

    move-object/from16 v23, v10

    move-object v8, v15

    .end local v4    # "$this$filterKeys\\9":Ljava/util/Map;
    .end local v10    # "root":Ljava/io/File;
    .end local v15    # "result\\9":Ljava/util/LinkedHashMap;
    .local v8, "result\\9":Ljava/util/LinkedHashMap;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v23    # "root":Ljava/io/File;
    .restart local v24    # "$this$filterKeys\\9":Ljava/util/Map;
    move-object v2, v8

    check-cast v2, Ljava/util/Map;

    .line 119
    .end local v8    # "result\\9":Ljava/util/LinkedHashMap;
    .end local v19    # "$i$f$filterKeys\\9\\118":I
    .end local v24    # "$this$filterKeys\\9":Ljava/util/Map;
    nop

    .local v2, "$this$forEach\\11":Ljava/util/Map;
    const/4 v4, 0x0

    .line 211
    .local v4, "$i$f$forEach\\11\\119":I
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_9
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_e

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    .local v10, "element\\11":Ljava/util/Map$Entry;
    const/16 v19, 0x0

    .local v19, "$i$a$-forEach-ProfileCapture$change$info$1$1$2\\12\\211\\8":I
    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/String;

    move-object/from16 v21, v20

    .local v21, "key\\12":Ljava/lang/String;
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/String;

    move-object/from16 v22, v20

    .line 119
    .local v22, "value\\12":Ljava/lang/String;
    move-object/from16 v15, v21

    move-object/from16 v21, v2

    move-object/from16 v2, v22

    .end local v22    # "value\\12":Ljava/lang/String;
    .local v2, "value\\12":Ljava/lang/String;
    .local v15, "key\\12":Ljava/lang/String;
    .local v21, "$this$forEach\\11":Ljava/util/Map;
    invoke-virtual {v7, v15, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 211
    nop

    .end local v2    # "value\\12":Ljava/lang/String;
    .end local v15    # "key\\12":Ljava/lang/String;
    .end local v19    # "$i$a$-forEach-ProfileCapture$change$info$1$1$2\\12\\211\\8":I
    move-object/from16 v2, v21

    .end local v10    # "element\\11":Ljava/util/Map$Entry;
    goto :goto_9

    .line 212
    .end local v21    # "$this$forEach\\11":Ljava/util/Map;
    .local v2, "$this$forEach\\11":Ljava/util/Map;
    :cond_e
    move-object/from16 v21, v2

    .line 120
    .end local v2    # "$this$forEach\\11":Ljava/util/Map;
    .end local v4    # "$i$f$forEach\\11\\119":I
    nop

    .end local v7    # "$this$change_u24lambda_u2424_u24lambda_u2423\\8":Lorg/json/JSONObject;
    .end local v17    # "$i$a$-apply-ProfileCapture$change$info$1$1\\8\\117\\7":I
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 117
    invoke-virtual {v12, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 121
    const-string v2, "state"

    const-string v4, "recording"

    invoke-virtual {v12, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "automatic"

    invoke-virtual {v12, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 122
    const-string v2, "observationsAtStart"

    iget-object v4, v1, Lorg/lighttouch/android/ProfileCapture;->observations:Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/Bundle;

    invoke-direct {v1, v4}, Lorg/lighttouch/android/ProfileCapture;->encode(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v12, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 123
    nop

    .line 106
    .end local v12    # "$this$change_u24lambda_u2424\\7":Lorg/json/JSONObject;
    .end local v14    # "$i$a$-apply-ProfileCapture$change$info$1\\7\\106\\0":I
    move-object v2, v0

    .line 125
    .local v2, "info":Lorg/json/JSONObject;
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v4, "licenses"

    invoke-virtual {v0, v4}, Landroid/content/res/AssetManager;->list(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_12

    .local v0, "$this$filter\\13":[Ljava/lang/Object;
    const/4 v4, 0x0

    .line 213
    .local v4, "$i$f$filter\\13\\125":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\14":Ljava/util/Collection;
    move-object v6, v0

    .local v6, "$this$filterTo\\14":[Ljava/lang/Object;
    const/4 v7, 0x0

    .line 214
    .local v7, "$i$f$filterTo\\14\\213":I
    array-length v8, v6

    const/4 v15, 0x0

    :goto_a
    if-ge v15, v8, :cond_10

    aget-object v10, v6, v15

    .local v10, "element\\14":Ljava/lang/Object;
    move-object v12, v10

    .local v12, "it\\15":Ljava/lang/String;
    const/4 v14, 0x0

    .line 125
    .local v14, "$i$a$-filter-ProfileCapture$change$4\\15\\214\\0":I
    const-string v3, "firmware"

    invoke-static {v12, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    .line 214
    .end local v12    # "it\\15":Ljava/lang/String;
    .end local v14    # "$i$a$-filter-ProfileCapture$change$4\\15\\214\\0":I
    if-nez v3, :cond_f

    invoke-interface {v5, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v10    # "element\\14":Ljava/lang/Object;
    :cond_f
    add-int/lit8 v15, v15, 0x1

    move/from16 v3, p3

    goto :goto_a

    .line 215
    :cond_10
    nop

    .end local v5    # "destination\\14":Ljava/util/Collection;
    .end local v6    # "$this$filterTo\\14":[Ljava/lang/Object;
    .end local v7    # "$i$f$filterTo\\14\\213":I
    move-object v3, v5

    check-cast v3, Ljava/util/List;

    .line 213
    nop

    .line 125
    .end local v0    # "$this$filter\\13":[Ljava/lang/Object;
    .end local v4    # "$i$f$filter\\13\\125":I
    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$forEach\\16":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 216
    .local v4, "$i$f$forEach\\16\\125":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_11

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    .local v6, "element\\16":Ljava/lang/Object;
    move-object v0, v6

    check-cast v0, Ljava/lang/String;
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_3
    .catchall {:try_start_a .. :try_end_a} :catchall_e

    move-object v7, v0

    .local v7, "group\\17":Ljava/lang/String;
    const/4 v8, 0x0

    .line 126
    .local v8, "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    :try_start_b
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "licenses/"

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v12, "/manifest.json"

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Ljava/io/Closeable;
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_2
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_3
    .catchall {:try_start_b .. :try_end_b} :catchall_e

    :try_start_c
    move-object v0, v10

    check-cast v0, Ljava/io/InputStream;

    move-object v12, v0

    .local v12, "input\\18":Ljava/io/InputStream;
    const/4 v14, 0x0

    .local v14, "$i$a$-use-ProfileCapture$change$5$1\\18\\126\\17":I
    new-instance v0, Ljava/io/FileOutputStream;

    .line 127
    new-instance v15, Ljava/io/File;
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_7

    move-object/from16 v17, v3

    .end local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .local v17, "$this$forEach\\16":Ljava/lang/Iterable;
    :try_start_d
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_6

    move/from16 v19, v4

    .end local v4    # "$i$f$forEach\\16\\125":I
    .local v19, "$i$f$forEach\\16\\125":I
    :try_start_e
    const-string v4, "engine-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "-manifest.json"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v15, v11, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v0, v15}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v3, v0

    check-cast v3, Ljava/io/Closeable;
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    :try_start_f
    move-object v0, v3

    check-cast v0, Ljava/io/FileOutputStream;

    .line 197
    .local v0, "it\\19":Ljava/io/FileOutputStream;
    const/4 v4, 0x0

    .line 127
    .local v4, "$i$a$-use-ProfileCapture$change$5$1$1\\19\\127\\18":I
    invoke-static {v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v15, v0

    check-cast v15, Ljava/io/OutputStream;
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_2

    move/from16 v21, v4

    move-object/from16 v20, v5

    move-object/from16 v22, v6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    .end local v4    # "$i$a$-use-ProfileCapture$change$5$1$1\\19\\127\\18":I
    .end local v6    # "element\\16":Ljava/lang/Object;
    .local v21, "$i$a$-use-ProfileCapture$change$5$1$1\\19\\127\\18":I
    .local v22, "element\\16":Ljava/lang/Object;
    :try_start_10
    invoke-static {v12, v15, v6, v4, v5}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_1

    .end local v0    # "it\\19":Ljava/io/FileOutputStream;
    .end local v21    # "$i$a$-use-ProfileCapture$change$5$1$1\\19\\127\\18":I
    :try_start_11
    invoke-static {v3, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_0

    .line 126
    .end local v12    # "input\\18":Ljava/io/InputStream;
    .end local v14    # "$i$a$-use-ProfileCapture$change$5$1\\18\\126\\17":I
    :try_start_12
    invoke-static {v10, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_12
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_12} :catch_1
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_3
    .catchall {:try_start_12 .. :try_end_12} :catchall_e

    goto :goto_e

    :catchall_0
    move-exception v0

    move-object v3, v0

    goto :goto_d

    .line 127
    .restart local v12    # "input\\18":Ljava/io/InputStream;
    .restart local v14    # "$i$a$-use-ProfileCapture$change$5$1\\18\\126\\17":I
    :catchall_1
    move-exception v0

    move-object v4, v0

    goto :goto_c

    .end local v22    # "element\\16":Ljava/lang/Object;
    .restart local v6    # "element\\16":Ljava/lang/Object;
    :catchall_2
    move-exception v0

    move-object/from16 v20, v5

    move-object/from16 v22, v6

    move-object v4, v0

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v6    # "element\\16":Ljava/lang/Object;
    .end local v7    # "group\\17":Ljava/lang/String;
    .end local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v12    # "input\\18":Ljava/io/InputStream;
    .end local v13    # "log":Ljava/io/File;
    .end local v14    # "$i$a$-use-ProfileCapture$change$5$1\\18\\126\\17":I
    .end local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v19    # "$i$f$forEach\\16\\125":I
    .end local v23    # "root":Ljava/io/File;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    :goto_c
    :try_start_13
    throw v4
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_3

    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v7    # "group\\17":Ljava/lang/String;
    .restart local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v12    # "input\\18":Ljava/io/InputStream;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v14    # "$i$a$-use-ProfileCapture$change$5$1\\18\\126\\17":I
    .restart local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v19    # "$i$f$forEach\\16\\125":I
    .restart local v22    # "element\\16":Ljava/lang/Object;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catchall_3
    move-exception v0

    :try_start_14
    invoke-static {v3, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v7    # "group\\17":Ljava/lang/String;
    .end local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v19    # "$i$f$forEach\\16\\125":I
    .end local v22    # "element\\16":Ljava/lang/Object;
    .end local v23    # "root":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_4

    .line 126
    .end local v12    # "input\\18":Ljava/io/InputStream;
    .end local v14    # "$i$a$-use-ProfileCapture$change$5$1\\18\\126\\17":I
    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v7    # "group\\17":Ljava/lang/String;
    .restart local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v19    # "$i$f$forEach\\16\\125":I
    .restart local v22    # "element\\16":Ljava/lang/Object;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catchall_4
    move-exception v0

    move-object v3, v0

    goto :goto_d

    .end local v22    # "element\\16":Ljava/lang/Object;
    .restart local v6    # "element\\16":Ljava/lang/Object;
    :catchall_5
    move-exception v0

    move-object/from16 v20, v5

    move-object/from16 v22, v6

    move-object v3, v0

    .end local v6    # "element\\16":Ljava/lang/Object;
    .restart local v22    # "element\\16":Ljava/lang/Object;
    goto :goto_d

    .end local v19    # "$i$f$forEach\\16\\125":I
    .end local v22    # "element\\16":Ljava/lang/Object;
    .local v4, "$i$f$forEach\\16\\125":I
    .restart local v6    # "element\\16":Ljava/lang/Object;
    :catchall_6
    move-exception v0

    move/from16 v19, v4

    move-object/from16 v20, v5

    move-object/from16 v22, v6

    move-object v3, v0

    .end local v4    # "$i$f$forEach\\16\\125":I
    .end local v6    # "element\\16":Ljava/lang/Object;
    .restart local v19    # "$i$f$forEach\\16\\125":I
    .restart local v22    # "element\\16":Ljava/lang/Object;
    goto :goto_d

    .end local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v19    # "$i$f$forEach\\16\\125":I
    .end local v22    # "element\\16":Ljava/lang/Object;
    .restart local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v4    # "$i$f$forEach\\16\\125":I
    .restart local v6    # "element\\16":Ljava/lang/Object;
    :catchall_7
    move-exception v0

    move-object/from16 v17, v3

    move/from16 v19, v4

    move-object/from16 v20, v5

    move-object/from16 v22, v6

    move-object v3, v0

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\16\\125":I
    .end local v6    # "element\\16":Ljava/lang/Object;
    .end local v7    # "group\\17":Ljava/lang/String;
    .end local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v23    # "root":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    :goto_d
    :try_start_15
    throw v3
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_8

    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v7    # "group\\17":Ljava/lang/String;
    .restart local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v19    # "$i$f$forEach\\16\\125":I
    .restart local v22    # "element\\16":Ljava/lang/Object;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catchall_8
    move-exception v0

    :try_start_16
    invoke-static {v10, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v7    # "group\\17":Ljava/lang/String;
    .end local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v19    # "$i$f$forEach\\16\\125":I
    .end local v22    # "element\\16":Ljava/lang/Object;
    .end local v23    # "root":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0
    :try_end_16
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_16} :catch_1
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_3
    .catchall {:try_start_16 .. :try_end_16} :catchall_e

    .line 128
    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v7    # "group\\17":Ljava/lang/String;
    .restart local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v19    # "$i$f$forEach\\16\\125":I
    .restart local v22    # "element\\16":Ljava/lang/Object;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catch_1
    move-exception v0

    goto :goto_e

    .end local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v19    # "$i$f$forEach\\16\\125":I
    .end local v22    # "element\\16":Ljava/lang/Object;
    .restart local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v4    # "$i$f$forEach\\16\\125":I
    .restart local v6    # "element\\16":Ljava/lang/Object;
    :catch_2
    move-exception v0

    move-object/from16 v17, v3

    move/from16 v19, v4

    move-object/from16 v20, v5

    move-object/from16 v22, v6

    .line 129
    .end local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\16\\125":I
    .end local v6    # "element\\16":Ljava/lang/Object;
    .restart local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v19    # "$i$f$forEach\\16\\125":I
    .restart local v22    # "element\\16":Ljava/lang/Object;
    :goto_e
    nop

    .line 216
    .end local v7    # "group\\17":Ljava/lang/String;
    .end local v8    # "$i$a$-forEach-ProfileCapture$change$5\\17\\216\\0":I
    move-object/from16 v3, v17

    move/from16 v4, v19

    move-object/from16 v5, v20

    .end local v22    # "element\\16":Ljava/lang/Object;
    goto/16 :goto_b

    .line 217
    .end local v17    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v19    # "$i$f$forEach\\16\\125":I
    .restart local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .restart local v4    # "$i$f$forEach\\16\\125":I
    :cond_11
    move-object/from16 v17, v3

    move/from16 v19, v4

    .line 130
    .end local v3    # "$this$forEach\\16":Ljava/lang/Iterable;
    .end local v4    # "$i$f$forEach\\16\\125":I
    :cond_12
    if-eqz v13, :cond_15

    move-object v0, v13

    .line 197
    .local v0, "it\\20":Ljava/io/File;
    const/4 v3, 0x0

    .line 130
    .local v3, "$i$a$-takeIf-ProfileCapture$change$6\\20\\130\\0":I
    :try_start_17
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v4

    .end local v0    # "it\\20":Ljava/io/File;
    .end local v3    # "$i$a$-takeIf-ProfileCapture$change$6\\20\\130\\0":I
    if-eqz v4, :cond_13

    move-object v0, v13

    goto :goto_f

    :cond_13
    const/4 v0, 0x0

    :goto_f
    if-eqz v0, :cond_15

    new-instance v3, Ljava/io/FileInputStream;

    invoke-direct {v3, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v3, Ljava/io/Closeable;
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_17} :catch_3
    .catchall {:try_start_17 .. :try_end_17} :catchall_e

    :try_start_18
    move-object v0, v3

    check-cast v0, Ljava/io/FileInputStream;

    move-object v4, v0

    .local v4, "input\\21":Ljava/io/FileInputStream;
    const/4 v5, 0x0

    .local v5, "$i$a$-use-ProfileCapture$change$7\\21\\130\\0":I
    new-instance v0, Ljava/io/FileOutputStream;

    .line 131
    new-instance v6, Ljava/io/File;

    const-string v7, "engine-start.log"

    invoke-direct {v6, v11, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v0, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v6, v0

    check-cast v6, Ljava/io/Closeable;
    :try_end_18
    .catchall {:try_start_18 .. :try_end_18} :catchall_c

    :try_start_19
    move-object v0, v6

    check-cast v0, Ljava/io/FileOutputStream;

    .local v0, "output\\22":Ljava/io/FileOutputStream;
    const/4 v7, 0x0

    .line 132
    .local v7, "$i$a$-use-ProfileCapture$change$7$1\\22\\131\\21":I
    const/16 v8, 0x2000

    new-array v8, v8, [B

    .line 133
    .local v8, "buffer\\22":[B
    const/high16 v10, 0x10000

    .line 134
    .local v10, "remaining\\22":I
    :goto_10
    if-lez v10, :cond_14

    .line 135
    array-length v12, v8

    invoke-static {v12, v10}, Ljava/lang/Math;->min(II)I

    move-result v12

    const/4 v15, 0x0

    invoke-virtual {v4, v8, v15, v12}, Ljava/io/FileInputStream;->read([BII)I

    move-result v12

    .line 136
    .local v12, "n\\22":I
    if-lez v12, :cond_14

    .line 137
    invoke-virtual {v0, v8, v15, v12}, Ljava/io/FileOutputStream;->write([BII)V

    sub-int/2addr v10, v12

    .end local v12    # "n\\22":I
    goto :goto_10

    .line 139
    :cond_14
    nop

    .end local v0    # "output\\22":Ljava/io/FileOutputStream;
    .end local v7    # "$i$a$-use-ProfileCapture$change$7$1\\22\\131\\21":I
    .end local v8    # "buffer\\22":[B
    .end local v10    # "remaining\\22":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_a

    .line 131
    const/4 v10, 0x0

    :try_start_1a
    invoke-static {v6, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 140
    nop

    .end local v4    # "input\\21":Ljava/io/FileInputStream;
    .end local v5    # "$i$a$-use-ProfileCapture$change$7\\21\\130\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1a
    .catchall {:try_start_1a .. :try_end_1a} :catchall_9

    .line 130
    :try_start_1b
    invoke-static {v3, v10}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_1b
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1b} :catch_3
    .catchall {:try_start_1b .. :try_end_1b} :catchall_e

    goto :goto_12

    :catchall_9
    move-exception v0

    move-object v4, v0

    goto :goto_11

    .line 131
    .restart local v4    # "input\\21":Ljava/io/FileInputStream;
    .restart local v5    # "$i$a$-use-ProfileCapture$change$7\\21\\130\\0":I
    :catchall_a
    move-exception v0

    move-object v7, v0

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v4    # "input\\21":Ljava/io/FileInputStream;
    .end local v5    # "$i$a$-use-ProfileCapture$change$7\\21\\130\\0":I
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v23    # "root":Ljava/io/File;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    :try_start_1c
    throw v7
    :try_end_1c
    .catchall {:try_start_1c .. :try_end_1c} :catchall_b

    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v4    # "input\\21":Ljava/io/FileInputStream;
    .restart local v5    # "$i$a$-use-ProfileCapture$change$7\\21\\130\\0":I
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catchall_b
    move-exception v0

    :try_start_1d
    invoke-static {v6, v7}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v23    # "root":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_c

    .line 130
    .end local v4    # "input\\21":Ljava/io/FileInputStream;
    .end local v5    # "$i$a$-use-ProfileCapture$change$7\\21\\130\\0":I
    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catchall_c
    move-exception v0

    move-object v4, v0

    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v23    # "root":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    :goto_11
    :try_start_1e
    throw v4
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_d

    .restart local v2    # "info":Lorg/json/JSONObject;
    .restart local v9    # "identity":Ljava/util/List;
    .restart local v11    # "dir":Ljava/io/File;
    .restart local v13    # "log":Ljava/io/File;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v23    # "root":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catchall_d
    move-exception v0

    :try_start_1f
    invoke-static {v3, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0

    .line 141
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :cond_15
    :goto_12
    new-instance v0, Ljava/io/File;

    const-string v3, "metadata.json"

    invoke-direct {v0, v11, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x2

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v3

    const-string v5, "toString(...)"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v10, 0x0

    invoke-static {v0, v3, v10, v4, v10}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V

    .line 142
    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    new-instance v3, Ljava/io/File;

    const-string v4, "events.tsv"

    invoke-direct {v3, v11, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const-string v4, "getAbsolutePath(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Lorg/lighttouch/android/Native;->profile(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 143
    .local v0, "result":Ljava/lang/String;
    move-object v3, v0

    check-cast v3, Ljava/lang/CharSequence;

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_16

    const/4 v3, 0x1

    goto :goto_13

    :cond_16
    const/4 v3, 0x0

    :goto_13
    if-eqz v3, :cond_18

    .line 144
    const-string v3, "state"

    const-string v4, "start-failed"

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "error"

    invoke-virtual {v3, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 146
    if-eqz p3, :cond_17

    invoke-static {v11}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    goto :goto_14

    :cond_17
    new-instance v3, Ljava/io/File;

    const-string v4, "metadata.json"

    invoke-direct {v3, v11, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x2

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v5

    const-string v6, "toString(...)"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v10, 0x0

    invoke-static {v3, v5, v10, v4, v10}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V

    .line 147
    :goto_14
    new-instance v3, Ljava/lang/IllegalStateException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v3

    .line 149
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :cond_18
    iput-object v11, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    iput-object v2, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    iput-object v13, v1, Lorg/lighttouch/android/ProfileCapture;->engineLog:Ljava/io/File;

    if-eqz v13, :cond_19

    invoke-virtual {v13}, Ljava/io/File;->length()J

    move-result-wide v3

    goto :goto_15

    :cond_19
    const-wide/16 v3, 0x0

    :goto_15
    iput-wide v3, v1, Lorg/lighttouch/android/ProfileCapture;->logOffset:J

    .line 150
    if-eqz p3, :cond_1a

    const-string v3, ""
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_1f} :catch_3
    .catchall {:try_start_1f .. :try_end_1f} :catchall_e

    move-object v4, v3

    const/4 v3, 0x1

    goto :goto_16

    :cond_1a
    const/4 v3, 0x1

    :try_start_20
    invoke-interface {v9, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Profiling "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_16
    iput-object v4, v1, Lorg/lighttouch/android/ProfileCapture;->notice:Ljava/lang/String;

    const/4 v15, 0x0

    .end local v0    # "result":Ljava/lang/String;
    .end local v2    # "info":Lorg/json/JSONObject;
    .end local v9    # "identity":Ljava/util/List;
    .end local v11    # "dir":Ljava/io/File;
    .end local v13    # "log":Ljava/io/File;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v23    # "root":Ljava/io/File;
    goto :goto_19

    .line 152
    :catch_3
    move-exception v0

    const/4 v3, 0x1

    goto :goto_17

    .line 197
    .local v8, "reply":[Ljava/lang/String;
    .restart local v9    # "identity":Ljava/util/List;
    .local v10, "root":Ljava/io/File;
    .restart local v11    # "dir":Ljava/io/File;
    :cond_1b
    move v3, v4

    move-object/from16 v18, v8

    move-object/from16 v23, v10

    .end local v8    # "reply":[Ljava/lang/String;
    .end local v10    # "root":Ljava/io/File;
    .restart local v18    # "reply":[Ljava/lang/String;
    .restart local v23    # "root":Ljava/io/File;
    const/4 v0, 0x0

    .line 104
    .local v0, "$i$a$-check-ProfileCapture$change$3\\4\\104\\0":I
    const-string v2, "Could not create profile directory"

    .end local v0    # "$i$a$-check-ProfileCapture$change$3\\4\\104\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0

    .line 99
    .end local v11    # "dir":Ljava/io/File;
    .end local v18    # "reply":[Ljava/lang/String;
    .end local v23    # "root":Ljava/io/File;
    .restart local v8    # "reply":[Ljava/lang/String;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :cond_1c
    move v3, v4

    move-object/from16 v18, v8

    .end local v8    # "reply":[Ljava/lang/String;
    .restart local v18    # "reply":[Ljava/lang/String;
    const/4 v0, 0x0

    .line 100
    .local v0, "$i$a$-check-ProfileCapture$change$2\\2\\99\\0":I
    const-string v2, "The guest returned an incomplete app identity"

    .line 99
    .end local v0    # "$i$a$-check-ProfileCapture$change$2\\2\\99\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0

    .line 197
    .end local v9    # "identity":Ljava/util/List;
    .end local v18    # "reply":[Ljava/lang/String;
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :cond_1d
    move v3, v4

    const/4 v0, 0x0

    .line 95
    .local v0, "$i$a$-check-ProfileCapture$change$1\\1\\95\\0":I
    const-string v2, "Start profiling while the guest is running"

    .end local v0    # "$i$a$-check-ProfileCapture$change$1\\1\\95\\0":I
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    throw v0

    .line 152
    .restart local p1    # "recording":Z
    .restart local p2    # "guestState":Ljava/lang/String;
    .restart local p3    # "automatic":Z
    :catch_4
    move-exception v0

    move v3, v4

    :goto_17
    const/4 v15, 0x0

    goto :goto_18

    .line 94
    :cond_1e
    move v3, v4

    .line 151
    if-nez p1, :cond_20

    const-string v0, "user"
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_20} :catch_6
    .catchall {:try_start_20 .. :try_end_20} :catchall_e

    const/4 v4, 0x2

    const/4 v10, 0x0

    const/4 v15, 0x0

    :try_start_21
    invoke-static {v1, v0, v15, v4, v10}, Lorg/lighttouch/android/ProfileCapture;->finish$default(Lorg/lighttouch/android/ProfileCapture;Ljava/lang/String;ZILjava/lang/Object;)V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_21} :catch_5
    .catchall {:try_start_21 .. :try_end_21} :catchall_e

    goto :goto_19

    .line 152
    :catch_5
    move-exception v0

    goto :goto_18

    :catch_6
    move-exception v0

    goto :goto_17

    .line 153
    .local v0, "e":Ljava/lang/Exception;
    :goto_18
    :try_start_22
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1f

    const-string v2, "\u6027\u80fd\u8bb0\u5f55\u5931\u8d25"

    :cond_1f
    iput-object v2, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    goto :goto_19

    .line 151
    .end local v0    # "e":Ljava/lang/Exception;
    :cond_20
    const/4 v15, 0x0

    .line 155
    :goto_19
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v2, v0

    .local v2, "$this$change_u24lambda_u2432\\23":Landroid/os/Bundle;
    const/4 v4, 0x0

    .line 156
    .local v4, "$i$a$-apply-ProfileCapture$change$8\\23\\155\\0":I
    const-string v5, "profileRecording"

    iget-object v6, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    if-eqz v6, :cond_21

    move v15, v3

    :cond_21
    invoke-virtual {v2, v5, v15}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 157
    const-string v3, "profileNotice"

    iget-object v5, v1, Lorg/lighttouch/android/ProfileCapture;->notice:Ljava/lang/String;

    invoke-virtual {v2, v3, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v3, "profileError"

    iget-object v5, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    invoke-virtual {v2, v3, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_e

    .line 158
    nop

    .line 155
    .end local v2    # "$this$change_u24lambda_u2432\\23":Landroid/os/Bundle;
    .end local v4    # "$i$a$-apply-ProfileCapture$change$8\\23\\155\\0":I
    monitor-exit p0

    return-object v0

    .line 91
    .end local p1    # "recording":Z
    .end local p2    # "guestState":Ljava/lang/String;
    .end local p3    # "automatic":Z
    :catchall_e
    move-exception v0

    :try_start_23
    monitor-exit p0
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_e

    throw v0
.end method

.method public final declared-synchronized currentEvents()Ljava/io/File;
    .locals 4

    monitor-enter p0

    .line 68
    :try_start_0
    iget-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    if-eqz v0, :cond_0

    .line 197
    .local v0, "it\\1":Ljava/io/File;
    const/4 v1, 0x0

    .line 68
    .local v1, "$i$a$-let-ProfileCapture$currentEvents$1\\1\\68\\0":I
    new-instance v2, Ljava/io/File;

    const-string v3, "events.tsv"

    invoke-direct {v2, v0, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v0    # "it\\1":Ljava/io/File;
    .end local v1    # "$i$a$-let-ProfileCapture$currentEvents$1\\1\\68\\0":I
    goto :goto_0

    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_0
    const/4 v2, 0x0

    :goto_0
    monitor-exit p0

    return-object v2

    .line 67
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final declared-synchronized finish(Ljava/lang/String;Z)V
    .locals 20
    .param p1, "reason"    # Ljava/lang/String;
    .param p2, "keep"    # Z

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    monitor-enter p0

    :try_start_0
    const-string v0, "reason"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 162
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_a

    if-nez v0, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    move-object v3, v0

    .line 163
    .local v3, "dir":Ljava/io/File;
    const/4 v0, 0x1

    if-eqz p2, :cond_1

    :try_start_1
    iget-object v4, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    if-eqz v4, :cond_1

    const-string v5, "keep"

    invoke-virtual {v4, v5, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_a

    .line 164
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_1
    nop

    .line 165
    :try_start_2
    sget-object v5, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    const-string v6, ""

    invoke-virtual {v5, v6}, Lorg/lighttouch/android/Native;->profile(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 166
    .local v5, "result":Ljava/lang/String;
    move-object v6, v5

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    const/4 v7, 0x0

    if-lez v6, :cond_2

    move v6, v0

    goto :goto_0

    :cond_2
    move v6, v7

    :goto_0
    if-eqz v6, :cond_3

    iput-object v5, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    .line 167
    :cond_3
    iget-object v6, v1, Lorg/lighttouch/android/ProfileCapture;->engineLog:Ljava/io/File;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_9

    if-eqz v6, :cond_7

    move-object v8, v6

    .line 197
    .local v8, "it\\1":Ljava/io/File;
    const/4 v9, 0x0

    .line 167
    .local v9, "$i$a$-takeIf-ProfileCapture$finish$1\\1\\167\\0":I
    :try_start_3
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v10

    .end local v8    # "it\\1":Ljava/io/File;
    .end local v9    # "$i$a$-takeIf-ProfileCapture$finish$1\\1\\167\\0":I
    if-eqz v10, :cond_4

    goto :goto_1

    :cond_4
    const/4 v6, 0x0

    :goto_1
    if-eqz v6, :cond_7

    .local v6, "source\\2":Ljava/io/File;
    const/4 v8, 0x0

    .line 168
    .local v8, "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    new-instance v9, Ljava/io/RandomAccessFile;

    const-string v10, "r"

    invoke-direct {v9, v6, v10}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    check-cast v9, Ljava/io/Closeable;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_7

    :try_start_4
    move-object v10, v9

    check-cast v10, Ljava/io/RandomAccessFile;

    .local v10, "input\\3":Ljava/io/RandomAccessFile;
    const/4 v11, 0x0

    .line 169
    .local v11, "$i$a$-use-ProfileCapture$finish$2$1\\3\\168\\2":I
    iget-wide v12, v1, Lorg/lighttouch/android/ProfileCapture;->logOffset:J

    invoke-virtual {v10}, Ljava/io/RandomAccessFile;->length()J

    move-result-wide v14

    invoke-static {v12, v13, v14, v15}, Lkotlin/ranges/RangesKt;->coerceAtMost(JJ)J

    move-result-wide v12

    invoke-virtual {v10, v12, v13}, Ljava/io/RandomAccessFile;->seek(J)V

    new-instance v12, Ljava/io/FileOutputStream;

    .line 170
    new-instance v13, Ljava/io/File;

    const-string v14, "engine.log"

    invoke-direct {v13, v3, v14}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v12, v13}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    check-cast v12, Ljava/io/Closeable;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    :try_start_5
    move-object v13, v12

    check-cast v13, Ljava/io/FileOutputStream;

    .local v13, "output\\4":Ljava/io/FileOutputStream;
    const/4 v14, 0x0

    .line 171
    .local v14, "$i$a$-use-ProfileCapture$finish$2$1$1\\4\\170\\3":I
    const v15, 0x8000

    new-array v15, v15, [B

    .line 172
    .local v15, "buffer\\4":[B
    invoke-virtual {v10}, Ljava/io/RandomAccessFile;->length()J

    move-result-wide v16

    invoke-virtual {v10}, Ljava/io/RandomAccessFile;->getFilePointer()J

    move-result-wide v18
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    sub-long v0, v16, v18

    move-object/from16 v17, v5

    .end local v5    # "result":Ljava/lang/String;
    .local v17, "result":Ljava/lang/String;
    const-wide/32 v4, 0x800000

    :try_start_6
    invoke-static {v0, v1, v4, v5}, Lkotlin/ranges/RangesKt;->coerceAtMost(JJ)J

    move-result-wide v0

    .line 173
    .local v0, "remaining\\4":J
    :goto_2
    const-wide/16 v4, 0x0

    cmp-long v4, v0, v4

    if-lez v4, :cond_6

    .line 174
    array-length v4, v15

    int-to-long v4, v4

    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    long-to-int v4, v4

    invoke-virtual {v10, v15, v7, v4}, Ljava/io/RandomAccessFile;->read([BII)I

    move-result v4

    .line 175
    .local v4, "n\\4":I
    if-lez v4, :cond_5

    .line 176
    invoke-virtual {v13, v15, v7, v4}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    move/from16 v18, v8

    .end local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .local v18, "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    int-to-long v7, v4

    sub-long/2addr v0, v7

    move/from16 v8, v18

    const/4 v7, 0x0

    .end local v4    # "n\\4":I
    goto :goto_2

    .line 175
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v4    # "n\\4":I
    .restart local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :cond_5
    move/from16 v18, v8

    .end local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    goto :goto_3

    .line 173
    .end local v4    # "n\\4":I
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :cond_6
    move/from16 v18, v8

    .line 178
    .end local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :goto_3
    nop

    .end local v0    # "remaining\\4":J
    .end local v13    # "output\\4":Ljava/io/FileOutputStream;
    .end local v14    # "$i$a$-use-ProfileCapture$finish$2$1$1\\4\\170\\3":I
    .end local v15    # "buffer\\4":[B
    :try_start_7
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 170
    const/4 v1, 0x0

    :try_start_8
    invoke-static {v12, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 179
    nop

    .end local v10    # "input\\3":Ljava/io/RandomAccessFile;
    .end local v11    # "$i$a$-use-ProfileCapture$finish$2$1\\3\\168\\2":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    .line 168
    :try_start_9
    invoke-static {v9, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_7

    .line 180
    nop

    .end local v6    # "source\\2":Ljava/io/File;
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    goto :goto_6

    .line 170
    .restart local v6    # "source\\2":Ljava/io/File;
    .restart local v10    # "input\\3":Ljava/io/RandomAccessFile;
    .restart local v11    # "$i$a$-use-ProfileCapture$finish$2$1\\3\\168\\2":I
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :catchall_0
    move-exception v0

    move-object v1, v0

    goto :goto_4

    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :catchall_1
    move-exception v0

    move/from16 v18, v8

    move-object v1, v0

    .end local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    goto :goto_4

    .end local v17    # "result":Ljava/lang/String;
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v5    # "result":Ljava/lang/String;
    .restart local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :catchall_2
    move-exception v0

    move-object/from16 v17, v5

    move/from16 v18, v8

    move-object v1, v0

    .end local v3    # "dir":Ljava/io/File;
    .end local v5    # "result":Ljava/lang/String;
    .end local v6    # "source\\2":Ljava/io/File;
    .end local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .end local v10    # "input\\3":Ljava/io/RandomAccessFile;
    .end local v11    # "$i$a$-use-ProfileCapture$finish$2$1\\3\\168\\2":I
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "reason":Ljava/lang/String;
    .end local p2    # "keep":Z
    :goto_4
    :try_start_a
    throw v1
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .restart local v3    # "dir":Ljava/io/File;
    .restart local v6    # "source\\2":Ljava/io/File;
    .restart local v10    # "input\\3":Ljava/io/RandomAccessFile;
    .restart local v11    # "$i$a$-use-ProfileCapture$finish$2$1\\3\\168\\2":I
    .restart local v17    # "result":Ljava/lang/String;
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "reason":Ljava/lang/String;
    .restart local p2    # "keep":Z
    :catchall_3
    move-exception v0

    :try_start_b
    invoke-static {v12, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v3    # "dir":Ljava/io/File;
    .end local v6    # "source\\2":Ljava/io/File;
    .end local v17    # "result":Ljava/lang/String;
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "reason":Ljava/lang/String;
    .end local p2    # "keep":Z
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 168
    .end local v10    # "input\\3":Ljava/io/RandomAccessFile;
    .end local v11    # "$i$a$-use-ProfileCapture$finish$2$1\\3\\168\\2":I
    .restart local v3    # "dir":Ljava/io/File;
    .restart local v6    # "source\\2":Ljava/io/File;
    .restart local v17    # "result":Ljava/lang/String;
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "reason":Ljava/lang/String;
    .restart local p2    # "keep":Z
    :catchall_4
    move-exception v0

    move-object v1, v0

    goto :goto_5

    .end local v17    # "result":Ljava/lang/String;
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v5    # "result":Ljava/lang/String;
    .restart local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    :catchall_5
    move-exception v0

    move-object/from16 v17, v5

    move/from16 v18, v8

    move-object v1, v0

    .end local v3    # "dir":Ljava/io/File;
    .end local v5    # "result":Ljava/lang/String;
    .end local v6    # "source\\2":Ljava/io/File;
    .end local v8    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "reason":Ljava/lang/String;
    .end local p2    # "keep":Z
    :goto_5
    :try_start_c
    throw v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .restart local v3    # "dir":Ljava/io/File;
    .restart local v6    # "source\\2":Ljava/io/File;
    .restart local v17    # "result":Ljava/lang/String;
    .restart local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "reason":Ljava/lang/String;
    .restart local p2    # "keep":Z
    :catchall_6
    move-exception v0

    :try_start_d
    invoke-static {v9, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v3    # "dir":Ljava/io/File;
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .end local p1    # "reason":Ljava/lang/String;
    .end local p2    # "keep":Z
    throw v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_0
    .catchall {:try_start_d .. :try_end_d} :catchall_7

    .line 193
    .end local v6    # "source\\2":Ljava/io/File;
    .end local v17    # "result":Ljava/lang/String;
    .end local v18    # "$i$a$-let-ProfileCapture$finish$2\\2\\167\\0":I
    .restart local v3    # "dir":Ljava/io/File;
    .restart local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    .restart local p1    # "reason":Ljava/lang/String;
    .restart local p2    # "keep":Z
    :catchall_7
    move-exception v0

    move-object/from16 v1, p0

    goto/16 :goto_d

    .line 190
    :catch_0
    move-exception v0

    move-object/from16 v1, p0

    goto/16 :goto_b

    .line 167
    .restart local v5    # "result":Ljava/lang/String;
    :cond_7
    move-object/from16 v17, v5

    .end local v5    # "result":Ljava/lang/String;
    .restart local v17    # "result":Ljava/lang/String;
    :goto_6
    nop

    .line 181
    move-object/from16 v1, p0

    :try_start_e
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_2
    .catchall {:try_start_e .. :try_end_e} :catchall_9

    if-eqz v0, :cond_a

    .local v0, "$this$finish_u24lambda_u2437\\5":Lorg/json/JSONObject;
    const/4 v4, 0x0

    .line 182
    .local v4, "$i$a$-apply-ProfileCapture$finish$3\\5\\181\\0":I
    :try_start_f
    const-string v6, "state"

    iget-object v7, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    check-cast v7, Ljava/lang/CharSequence;

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-nez v7, :cond_8

    const/4 v7, 0x1

    goto :goto_7

    :cond_8
    const/4 v7, 0x0

    :goto_7
    if-eqz v7, :cond_9

    const-string v7, "saved"

    goto :goto_8

    :cond_9
    const-string v7, "partial"

    :goto_8
    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 183
    const-string v6, "stopReason"

    invoke-virtual {v0, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v6, "endedAtMs"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    invoke-virtual {v0, v6, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 184
    const-string v6, "endedElapsedRealtimeNs"

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    move-result-wide v7

    invoke-virtual {v0, v6, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 185
    const-string v6, "endedMonotonicNs"

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v7

    invoke-virtual {v0, v6, v7, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const-string v6, "error"

    iget-object v7, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 186
    const-string v6, "observationsAtEnd"

    iget-object v7, v1, Lorg/lighttouch/android/ProfileCapture;->observations:Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/os/Bundle;

    invoke-direct {v1, v7}, Lorg/lighttouch/android/ProfileCapture;->encode(Landroid/os/Bundle;)Lorg/json/JSONObject;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 187
    new-instance v6, Ljava/io/File;

    const-string v7, "metadata.json"

    invoke-direct {v6, v3, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v7, 0x2

    invoke-virtual {v0, v7}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v8

    const-string v9, "toString(...)"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v9, 0x0

    invoke-static {v6, v8, v9, v7, v9}, Lkotlin/io/FilesKt;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_1
    .catchall {:try_start_f .. :try_end_f} :catchall_8

    .line 188
    nop

    .end local v0    # "$this$finish_u24lambda_u2437\\5":Lorg/json/JSONObject;
    .end local v4    # "$i$a$-apply-ProfileCapture$finish$3\\5\\181\\0":I
    goto :goto_9

    .line 193
    .end local v17    # "result":Ljava/lang/String;
    :catchall_8
    move-exception v0

    goto :goto_d

    .line 190
    :catch_1
    move-exception v0

    goto :goto_b

    .line 181
    .restart local v17    # "result":Ljava/lang/String;
    :cond_a
    :goto_9
    nop

    .line 189
    :try_start_10
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_2
    .catchall {:try_start_10 .. :try_end_10} :catchall_9

    if-eqz v0, :cond_b

    :try_start_11
    const-string v4, "automatic"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x1

    if-ne v0, v4, :cond_b

    move v0, v4

    goto :goto_a

    :cond_b
    const/4 v0, 0x0

    :goto_a
    if-nez v0, :cond_e

    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    if-eqz v0, :cond_c

    const-string v4, "appName"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_d

    :cond_c
    const-string v0, "iOS app"

    :cond_d
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Saved profile: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->notice:Ljava/lang/String;
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_1
    .catchall {:try_start_11 .. :try_end_11} :catchall_8

    .line 193
    .end local v17    # "result":Ljava/lang/String;
    :cond_e
    const/4 v9, 0x0

    :try_start_12
    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->engineLog:Ljava/io/File;
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_a

    goto :goto_c

    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :catchall_9
    move-exception v0

    goto :goto_d

    .line 190
    :catch_2
    move-exception v0

    .line 191
    .local v0, "e":Ljava/lang/Exception;
    :goto_b
    :try_start_13
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_f

    const-string v4, "Could not finish profile capture"

    :cond_f
    iput-object v4, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    .line 192
    const-string v4, "Profile retained with incomplete metadata"

    iput-object v4, v1, Lorg/lighttouch/android/ProfileCapture;->notice:Ljava/lang/String;
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_9

    .line 193
    .end local v0    # "e":Ljava/lang/Exception;
    const/4 v9, 0x0

    :try_start_14
    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->engineLog:Ljava/io/File;
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_a

    .line 194
    :goto_c
    monitor-exit p0

    return-void

    .line 193
    :goto_d
    const/4 v9, 0x0

    :try_start_15
    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    iput-object v9, v1, Lorg/lighttouch/android/ProfileCapture;->engineLog:Ljava/io/File;

    throw v0

    .line 161
    .end local v3    # "dir":Ljava/io/File;
    .end local p1    # "reason":Ljava/lang/String;
    .end local p2    # "keep":Z
    :catchall_a
    move-exception v0

    monitor-exit p0
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_a

    throw v0
.end method

.method public final frontmostIdentity()Lkotlin/Pair;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 63
    nop

    .line 64
    const/4 v0, 0x0

    :try_start_0
    invoke-direct {p0}, Lorg/lighttouch/android/ProfileCapture;->frontmostApp()[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    aget-object v1, v1, v2

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->lines(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v1

    move-object v3, v1

    .line 197
    .local v3, "it\\1":Ljava/util/List;
    const/4 v4, 0x0

    .line 64
    .local v4, "$i$a$-takeIf-ProfileCapture$frontmostIdentity$1\\1\\64\\0":I
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-lt v5, v2, :cond_0

    invoke-interface {v3, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    move v2, v7

    goto :goto_0

    :cond_0
    move v2, v6

    .end local v3    # "it\\1":Ljava/util/List;
    .end local v4    # "$i$a$-takeIf-ProfileCapture$frontmostIdentity$1\\1\\64\\0":I
    :goto_0
    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    move-object v1, v0

    :goto_1
    if-eqz v1, :cond_2

    .line 197
    .local v1, "it\\2":Ljava/util/List;
    const/4 v2, 0x0

    .line 64
    .local v2, "$i$a$-let-ProfileCapture$frontmostIdentity$2\\2\\64\\0":I
    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .end local v1    # "it\\2":Ljava/util/List;
    .end local v2    # "$i$a$-let-ProfileCapture$frontmostIdentity$2\\2\\64\\0":I
    goto :goto_2

    .line 65
    :catch_0
    move-exception v1

    :cond_2
    :goto_2
    return-object v0
.end method

.method public final declared-synchronized getAutomatic()Z
    .locals 3

    monitor-enter p0

    .line 69
    :try_start_0
    iget-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const-string v2, "automatic"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    move v1, v2

    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_0
    monitor-exit p0

    return v1

    .line 69
    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final declared-synchronized snapshot(Ljava/lang/String;)Landroid/os/Bundle;
    .locals 8
    .param p1, "guestState"    # Ljava/lang/String;

    monitor-enter p0

    :try_start_0
    const-string v0, "guestState"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    iget-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    move-result-wide v4

    iget-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    if-eqz v0, :cond_0

    const-string v6, "startedElapsedRealtimeNs"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v6

    goto :goto_0

    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_0
    const-wide/16 v6, 0x0

    :goto_0
    sub-long/2addr v4, v6

    const-wide v6, 0xd18c2e2800L

    cmp-long v0, v4, v6

    if-ltz v0, :cond_1

    const-string v0, "duration-limit"

    invoke-static {p0, v0, v3, v2, v1}, Lorg/lighttouch/android/ProfileCapture;->finish$default(Lorg/lighttouch/android/ProfileCapture;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 31
    :cond_1
    iget-object v0, p0, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    const/4 v4, 0x1

    if-eqz v0, :cond_4

    new-array v0, v2, [Ljava/lang/String;

    const-string v5, "running"

    aput-object v5, v0, v3

    const-string v5, "paused"

    aput-object v5, v0, v4

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Lorg/lighttouch/android/Native;->INSTANCE:Lorg/lighttouch/android/Native;

    invoke-virtual {v0}, Lorg/lighttouch/android/Native;->profileStatus()I

    move-result v0

    if-eq v0, v4, :cond_4

    .line 32
    :cond_2
    new-array v0, v2, [Ljava/lang/String;

    const-string v5, "running"

    aput-object v5, v0, v3

    const-string v5, "paused"

    aput-object v5, v0, v4

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, "capture-limit-or-error"

    goto :goto_1

    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "guest-"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-static {p0, v0, v3, v2, v1}, Lorg/lighttouch/android/ProfileCapture;->finish$default(Lorg/lighttouch/android/ProfileCapture;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 33
    :cond_4
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    move-object v1, v0

    .local v1, "$this$snapshot_u24lambda_u241\\1":Landroid/os/Bundle;
    const/4 v2, 0x0

    .line 34
    .local v2, "$i$a$-apply-ProfileCapture$snapshot$1\\1\\33\\0":I
    const-string v5, "profileRecording"

    iget-object v6, p0, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    if-eqz v6, :cond_5

    move v6, v4

    goto :goto_2

    :cond_5
    move v6, v3

    :goto_2
    invoke-virtual {v1, v5, v6}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 35
    const-string v5, "profileAutomatic"

    iget-object v6, p0, Lorg/lighttouch/android/ProfileCapture;->metadata:Lorg/json/JSONObject;

    if-eqz v6, :cond_6

    const-string v7, "automatic"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v6

    if-ne v6, v4, :cond_6

    move v3, v4

    :cond_6
    invoke-virtual {v1, v5, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 36
    const-string v3, "profileNotice"

    iget-object v4, p0, Lorg/lighttouch/android/ProfileCapture;->notice:Ljava/lang/String;

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    const-string v3, "profileError"

    iget-object v4, p0, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    invoke-virtual {v1, v3, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    nop

    .line 33
    .end local v1    # "$this$snapshot_u24lambda_u241\\1":Landroid/os/Bundle;
    .end local v2    # "$i$a$-apply-ProfileCapture$snapshot$1\\1\\33\\0":I
    monitor-exit p0

    return-object v0

    .line 29
    .end local p1    # "guestState":Ljava/lang/String;
    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized startAutomatic(Ljava/lang/String;)Ljava/lang/String;
    .locals 16
    .param p1, "guestState"    # Ljava/lang/String;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    monitor-enter p0

    :try_start_0
    const-string v0, "guestState"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 78
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    if-nez v0, :cond_b

    const-string v0, "running"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_7

    .line 79
    :cond_0
    const/4 v3, 0x1

    invoke-virtual {v1, v3, v2, v3}, Lorg/lighttouch/android/ProfileCapture;->change(ZLjava/lang/String;Z)Landroid/os/Bundle;

    .line 81
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    if-nez v0, :cond_3

    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-nez v5, :cond_1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    if-eqz v3, :cond_2

    .line 197
    const/4 v0, 0x0

    .line 81
    .local v0, "$i$a$-ifEmpty-ProfileCapture$startAutomatic$1\\1\\81\\0":I
    const-string v3, "Detailed timing could not start"

    move-object v0, v3

    .end local v0    # "$i$a$-ifEmpty-ProfileCapture$startAutomatic$1\\1\\81\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/ProfileCapture;
    :cond_2
    move-object v3, v0

    check-cast v3, Ljava/lang/String;

    .line 197
    .local v3, "it\\2":Ljava/lang/String;
    const/4 v4, 0x0

    .line 81
    .local v4, "$i$a$-also-ProfileCapture$startAutomatic$2\\2\\81\\0":I
    const-string v5, ""

    iput-object v5, v1, Lorg/lighttouch/android/ProfileCapture;->lastError:Ljava/lang/String;

    .end local v3    # "it\\2":Ljava/lang/String;
    .end local v4    # "$i$a$-also-ProfileCapture$startAutomatic$2\\2\\81\\0":I
    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    .line 82
    :cond_3
    :try_start_1
    new-instance v0, Ljava/io/File;

    iget-object v5, v1, Lorg/lighttouch/android/ProfileCapture;->filesDir:Ljava/io/File;

    const-string v6, "profiles"

    invoke-direct {v0, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v5, v0

    .line 83
    .local v5, "root":Ljava/io/File;
    nop

    .line 87
    nop

    .line 83
    invoke-virtual {v5}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_a

    move-object v6, v0

    .local v6, "$this$filter\\3":[Ljava/lang/Object;
    const/4 v7, 0x0

    .line 198
    .local v7, "$i$f$filter\\3\\83":I
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    check-cast v0, Ljava/util/Collection;

    move-object v8, v0

    .local v8, "destination\\4":Ljava/util/Collection;
    move-object v9, v6

    .local v9, "$this$filterTo\\4":[Ljava/lang/Object;
    const/4 v10, 0x0

    .line 199
    .local v10, "$i$f$filterTo\\4\\198":I
    array-length v11, v9

    const/4 v12, 0x0

    :goto_1
    if-ge v12, v11, :cond_8

    aget-object v0, v9, v12

    move-object v13, v0

    .local v13, "element\\4":Ljava/lang/Object;
    move-object v14, v13

    .local v14, "dir\\5":Ljava/io/File;
    const/4 v15, 0x0

    .line 84
    .local v15, "$i$a$-filter-ProfileCapture$startAutomatic$3\\5\\199\\0":I
    iget-object v0, v1, Lorg/lighttouch/android/ProfileCapture;->directory:Ljava/io/File;

    invoke-static {v14, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v0, :cond_5

    .line 85
    :try_start_2
    new-instance v0, Lorg/json/JSONObject;

    new-instance v4, Ljava/io/File;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const-string v3, "metadata.json"

    invoke-direct {v4, v14, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    :try_start_4
    invoke-static {v4, v3, v2, v3}, Lkotlin/io/FilesKt;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 197
    .local v0, "it\\6":Lorg/json/JSONObject;
    const/4 v3, 0x0

    .line 85
    .local v3, "$i$a$-let-ProfileCapture$startAutomatic$3$1\\6\\85\\5":I
    const-string v4, "automatic"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_4

    const-string v4, "keep"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v4
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-nez v4, :cond_4

    move v0, v2

    goto :goto_3

    :cond_4
    const/4 v0, 0x0

    goto :goto_3

    .line 86
    .end local v0    # "it\\6":Lorg/json/JSONObject;
    .end local v3    # "$i$a$-let-ProfileCapture$startAutomatic$3$1\\6\\85\\5":I
    :catch_0
    move-exception v0

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v2, 0x1

    goto :goto_2

    :catch_2
    move-exception v0

    move v2, v3

    :goto_2
    const/4 v0, 0x0

    .line 84
    :goto_3
    if-eqz v0, :cond_6

    move v0, v2

    goto :goto_4

    :cond_5
    move v2, v3

    :cond_6
    const/4 v0, 0x0

    .line 86
    :goto_4
    nop

    .line 199
    .end local v14    # "dir\\5":Ljava/io/File;
    .end local v15    # "$i$a$-filter-ProfileCapture$startAutomatic$3\\5\\199\\0":I
    if-eqz v0, :cond_7

    :try_start_5
    invoke-interface {v8, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v13    # "element\\4":Ljava/lang/Object;
    :cond_7
    add-int/lit8 v12, v12, 0x1

    move v3, v2

    move-object/from16 v2, p1

    goto :goto_1

    .line 200
    :cond_8
    nop

    .end local v8    # "destination\\4":Ljava/util/Collection;
    .end local v9    # "$this$filterTo\\4":[Ljava/lang/Object;
    .end local v10    # "$i$f$filterTo\\4\\198":I
    move-object v0, v8

    check-cast v0, Ljava/util/List;

    .line 198
    nop

    .line 83
    .end local v6    # "$this$filter\\3":[Ljava/lang/Object;
    .end local v7    # "$i$f$filter\\3\\83":I
    nop

    .line 87
    nop

    .line 83
    check-cast v0, Ljava/lang/Iterable;

    .line 87
    nop

    .local v0, "$this$sortedByDescending\\7":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 201
    .local v2, "$i$f$sortedByDescending\\7\\87":I
    new-instance v3, Lorg/lighttouch/android/ProfileCapture$startAutomatic$$inlined$sortedByDescending$1;

    invoke-direct {v3}, Lorg/lighttouch/android/ProfileCapture$startAutomatic$$inlined$sortedByDescending$1;-><init>()V

    check-cast v3, Ljava/util/Comparator;

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v3

    .line 87
    .end local v0    # "$this$sortedByDescending\\7":Ljava/lang/Iterable;
    .end local v2    # "$i$f$sortedByDescending\\7\\87":I
    if-eqz v3, :cond_a

    .line 83
    check-cast v3, Ljava/lang/Iterable;

    .line 87
    const/4 v0, 0x2

    invoke-static {v3, v0}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_a

    .line 83
    check-cast v0, Ljava/lang/Iterable;

    .line 87
    nop

    .local v0, "$this$forEach\\8":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 202
    .local v2, "$i$f$forEach\\8\\87":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\8":Ljava/lang/Object;
    move-object v6, v4

    check-cast v6, Ljava/io/File;

    .local v6, "it\\9":Ljava/io/File;
    const/4 v7, 0x0

    .line 87
    .local v7, "$i$a$-forEach-ProfileCapture$startAutomatic$5\\9\\202\\0":I
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v6}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 202
    nop

    .end local v4    # "element\\8":Ljava/lang/Object;
    .end local v6    # "it\\9":Ljava/io/File;
    .end local v7    # "$i$a$-forEach-ProfileCapture$startAutomatic$5\\9\\202\\0":I
    goto :goto_5

    .line 203
    :cond_9
    nop

    .end local v0    # "$this$forEach\\8":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\8\\87":I
    goto :goto_6

    .line 83
    :cond_a
    nop

    .line 88
    :goto_6
    const-string v0, ""
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    monitor-exit p0

    return-object v0

    .line 78
    .end local v5    # "root":Ljava/io/File;
    :cond_b
    :goto_7
    :try_start_6
    const-string v0, ""
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    monitor-exit p0

    return-object v0

    .line 77
    .end local p1    # "guestState":Ljava/lang/String;
    :catchall_0
    move-exception v0

    :try_start_7
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    throw v0
.end method

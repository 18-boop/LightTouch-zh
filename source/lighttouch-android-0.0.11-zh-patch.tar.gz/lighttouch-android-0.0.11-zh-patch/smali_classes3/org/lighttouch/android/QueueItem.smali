.class public final Lorg/lighttouch/android/QueueItem;
.super Ljava/lang/Object;
.source "InstallQueue.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0007\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008%\n\u0002\u0010\u0008\n\u0002\u0008\u0002\u0008\u0087\u0008\u0018\u00002\u00020\u0001B_\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0008\u0012\u0008\u0008\u0002\u0010\t\u001a\u00020\u0005\u0012\n\u0008\u0002\u0010\n\u001a\u0004\u0018\u00010\u000b\u0012\n\u0008\u0002\u0010\u000c\u001a\u0004\u0018\u00010\u0005\u0012\u0008\u0008\u0002\u0010\r\u001a\u00020\u000e\u0012\u0008\u0008\u0002\u0010\u000f\u001a\u00020\u000b\u00a2\u0006\u0004\u0008\u0010\u0010\u0011J\t\u0010&\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\'\u001a\u00020\u0005H\u00c6\u0003J\t\u0010(\u001a\u00020\u0005H\u00c6\u0003J\t\u0010)\u001a\u00020\u0008H\u00c6\u0003J\t\u0010*\u001a\u00020\u0005H\u00c6\u0003J\u0010\u0010+\u001a\u0004\u0018\u00010\u000bH\u00c6\u0003\u00a2\u0006\u0002\u0010\u001bJ\u000b\u0010,\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\t\u0010-\u001a\u00020\u000eH\u00c6\u0003J\t\u0010.\u001a\u00020\u000bH\u00c6\u0003Jl\u0010/\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00082\u0008\u0008\u0002\u0010\t\u001a\u00020\u00052\n\u0008\u0002\u0010\n\u001a\u0004\u0018\u00010\u000b2\n\u0008\u0002\u0010\u000c\u001a\u0004\u0018\u00010\u00052\u0008\u0008\u0002\u0010\r\u001a\u00020\u000e2\u0008\u0008\u0002\u0010\u000f\u001a\u00020\u000bH\u00c6\u0001\u00a2\u0006\u0002\u00100J\u0013\u00101\u001a\u00020\u000e2\u0008\u00102\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u00103\u001a\u000204H\u00d6\u0001J\t\u00105\u001a\u00020\u0005H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0014\u0010\u0015R\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0015R\u0011\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0017\u0010\u0018R\u0011\u0010\t\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0019\u0010\u0015R\u0015\u0010\n\u001a\u0004\u0018\u00010\u000b\u00a2\u0006\n\n\u0002\u0010\u001c\u001a\u0004\u0008\u001a\u0010\u001bR\u0013\u0010\u000c\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001d\u0010\u0015R\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u001e\u0010\u001fR\u0011\u0010\u000f\u001a\u00020\u000b\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008 \u0010!R\u0011\u0010\"\u001a\u00020\u000e8F\u00a2\u0006\u0006\u001a\u0004\u0008#\u0010\u001fR\u0011\u0010$\u001a\u00020\u000e8F\u00a2\u0006\u0006\u001a\u0004\u0008%\u0010\u001f\u00a8\u00066"
    }
    d2 = {
        "Lorg/lighttouch/android/QueueItem;",
        "",
        "id",
        "",
        "key",
        "",
        "name",
        "state",
        "Lorg/lighttouch/android/QueueState;",
        "phase",
        "progress",
        "",
        "error",
        "committed",
        "",
        "overall",
        "<init>",
        "(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)V",
        "getId",
        "()J",
        "getKey",
        "()Ljava/lang/String;",
        "getName",
        "getState",
        "()Lorg/lighttouch/android/QueueState;",
        "getPhase",
        "getProgress",
        "()Ljava/lang/Float;",
        "Ljava/lang/Float;",
        "getError",
        "getCommitted",
        "()Z",
        "getOverall",
        "()F",
        "active",
        "getActive",
        "cancellable",
        "getCancellable",
        "component1",
        "component2",
        "component3",
        "component4",
        "component5",
        "component6",
        "component7",
        "component8",
        "component9",
        "copy",
        "(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)Lorg/lighttouch/android/QueueItem;",
        "equals",
        "other",
        "hashCode",
        "",
        "toString",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private final committed:Z

.field private final error:Ljava/lang/String;

.field private final id:J

.field private final key:Ljava/lang/String;

.field private final name:Ljava/lang/String;

.field private final overall:F

.field private final phase:Ljava/lang/String;

.field private final progress:Ljava/lang/Float;

.field private final state:Lorg/lighttouch/android/QueueState;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)V
    .locals 1
    .param p1, "id"    # J
    .param p3, "key"    # Ljava/lang/String;
    .param p4, "name"    # Ljava/lang/String;
    .param p5, "state"    # Lorg/lighttouch/android/QueueState;
    .param p6, "phase"    # Ljava/lang/String;
    .param p7, "progress"    # Ljava/lang/Float;
    .param p8, "error"    # Ljava/lang/String;
    .param p9, "committed"    # Z
    .param p10, "overall"    # F

    const-string v0, "key"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "state"

    invoke-static {p5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "phase"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lorg/lighttouch/android/QueueItem;->id:J

    iput-object p3, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    iput-object p4, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    iput-object p5, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    .line 9
    iput-object p6, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    iput-object p7, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    iput-object p8, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    .line 10
    iput-boolean p9, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    iput p10, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    .line 8
    return-void
.end method

.method public synthetic constructor <init>(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 13

    .line 8
    move/from16 v0, p11

    and-int/lit8 v1, v0, 0x8

    if-eqz v1, :cond_0

    sget-object v1, Lorg/lighttouch/android/QueueState;->PENDING:Lorg/lighttouch/android/QueueState;

    move-object v7, v1

    goto :goto_0

    :cond_0
    move-object/from16 v7, p5

    :goto_0
    and-int/lit8 v1, v0, 0x10

    if-eqz v1, :cond_1

    .line 9
    const-string v1, "\u7b49\u5f85\u4e2d"

    move-object v8, v1

    goto :goto_1

    .line 8
    :cond_1
    move-object/from16 v8, p6

    :goto_1
    and-int/lit8 v1, v0, 0x20

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    .line 9
    move-object v9, v2

    goto :goto_2

    .line 8
    :cond_2
    move-object/from16 v9, p7

    :goto_2
    and-int/lit8 v1, v0, 0x40

    if-eqz v1, :cond_3

    .line 9
    move-object v10, v2

    goto :goto_3

    .line 8
    :cond_3
    move-object/from16 v10, p8

    :goto_3
    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_4

    .line 10
    const/4 v1, 0x0

    move v11, v1

    goto :goto_4

    .line 8
    :cond_4
    move/from16 v11, p9

    :goto_4
    and-int/lit16 v0, v0, 0x100

    if-eqz v0, :cond_5

    .line 10
    const/4 v0, 0x0

    move v12, v0

    goto :goto_5

    .line 8
    :cond_5
    move/from16 v12, p10

    :goto_5
    move-object v2, p0

    move-wide v3, p1

    move-object/from16 v5, p3

    move-object/from16 v6, p4

    invoke-direct/range {v2 .. v12}, Lorg/lighttouch/android/QueueItem;-><init>(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)V

    .line 10
    return-void
.end method

.method public static synthetic copy$default(Lorg/lighttouch/android/QueueItem;JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZFILjava/lang/Object;)Lorg/lighttouch/android/QueueItem;
    .locals 11

    move/from16 v0, p11

    and-int/lit8 v1, v0, 0x1

    if-eqz v1, :cond_0

    iget-wide p1, p0, Lorg/lighttouch/android/QueueItem;->id:J

    :cond_0
    move-wide v1, p1

    and-int/lit8 p1, v0, 0x2

    if-eqz p1, :cond_1

    iget-object p3, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    :cond_1
    move-object v3, p3

    and-int/lit8 p1, v0, 0x4

    if-eqz p1, :cond_2

    iget-object p4, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    :cond_2
    move-object v4, p4

    and-int/lit8 p1, v0, 0x8

    if-eqz p1, :cond_3

    iget-object p1, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    move-object v5, p1

    goto :goto_0

    :cond_3
    move-object/from16 v5, p5

    :goto_0
    and-int/lit8 p1, v0, 0x10

    if-eqz p1, :cond_4

    iget-object p1, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    move-object v6, p1

    goto :goto_1

    :cond_4
    move-object/from16 v6, p6

    :goto_1
    and-int/lit8 p1, v0, 0x20

    if-eqz p1, :cond_5

    iget-object p1, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    move-object v7, p1

    goto :goto_2

    :cond_5
    move-object/from16 v7, p7

    :goto_2
    and-int/lit8 p1, v0, 0x40

    if-eqz p1, :cond_6

    iget-object p1, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    move-object v8, p1

    goto :goto_3

    :cond_6
    move-object/from16 v8, p8

    :goto_3
    and-int/lit16 p1, v0, 0x80

    if-eqz p1, :cond_7

    iget-boolean p1, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    move v9, p1

    goto :goto_4

    :cond_7
    move/from16 v9, p9

    :goto_4
    and-int/lit16 p1, v0, 0x100

    if-eqz p1, :cond_8

    iget p1, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    move v10, p1

    goto :goto_5

    :cond_8
    move/from16 v10, p10

    :goto_5
    move-object v0, p0

    invoke-virtual/range {v0 .. v10}, Lorg/lighttouch/android/QueueItem;->copy(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)Lorg/lighttouch/android/QueueItem;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()J
    .locals 2

    iget-wide v0, p0, Lorg/lighttouch/android/QueueItem;->id:J

    return-wide v0
.end method

.method public final component2()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    return-object v0
.end method

.method public final component3()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final component4()Lorg/lighttouch/android/QueueState;
    .locals 1

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    return-object v0
.end method

.method public final component5()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    return-object v0
.end method

.method public final component6()Ljava/lang/Float;
    .locals 1

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    return-object v0
.end method

.method public final component7()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    return-object v0
.end method

.method public final component8()Z
    .locals 1

    iget-boolean v0, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    return v0
.end method

.method public final component9()F
    .locals 1

    iget v0, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    return v0
.end method

.method public final copy(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)Lorg/lighttouch/android/QueueItem;
    .locals 12

    const-string v0, "key"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "name"

    move-object/from16 v5, p4

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "state"

    move-object/from16 v6, p5

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "phase"

    move-object/from16 v7, p6

    invoke-static {v7, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Lorg/lighttouch/android/QueueItem;

    move-wide v2, p1

    move-object v4, p3

    move-object/from16 v8, p7

    move-object/from16 v9, p8

    move/from16 v10, p9

    move/from16 v11, p10

    invoke-direct/range {v1 .. v11}, Lorg/lighttouch/android/QueueItem;-><init>(JLjava/lang/String;Ljava/lang/String;Lorg/lighttouch/android/QueueState;Ljava/lang/String;Ljava/lang/Float;Ljava/lang/String;ZF)V

    return-object v1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lorg/lighttouch/android/QueueItem;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    move-object v1, p1

    check-cast v1, Lorg/lighttouch/android/QueueItem;

    iget-wide v3, p0, Lorg/lighttouch/android/QueueItem;->id:J

    iget-wide v5, v1, Lorg/lighttouch/android/QueueItem;->id:J

    cmp-long v3, v3, v5

    if-eqz v3, :cond_2

    return v2

    :cond_2
    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    iget-object v4, v1, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3

    return v2

    :cond_3
    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    iget-object v4, v1, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    return v2

    :cond_4
    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    iget-object v4, v1, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    if-eq v3, v4, :cond_5

    return v2

    :cond_5
    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    iget-object v4, v1, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_6

    return v2

    :cond_6
    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    iget-object v4, v1, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7

    return v2

    :cond_7
    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    iget-object v4, v1, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_8

    return v2

    :cond_8
    iget-boolean v3, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    iget-boolean v4, v1, Lorg/lighttouch/android/QueueItem;->committed:Z

    if-eq v3, v4, :cond_9

    return v2

    :cond_9
    iget v3, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    iget v1, v1, Lorg/lighttouch/android/QueueItem;->overall:F

    invoke-static {v3, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_a

    return v2

    :cond_a
    return v0
.end method

.method public final getActive()Z
    .locals 2

    .line 12
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    sget-object v1, Lorg/lighttouch/android/QueueState;->DONE:Lorg/lighttouch/android/QueueState;

    if-eq v0, v1, :cond_0

    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    sget-object v1, Lorg/lighttouch/android/QueueState;->FAILED:Lorg/lighttouch/android/QueueState;

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final getCancellable()Z
    .locals 1

    .line 14
    invoke-virtual {p0}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final getCommitted()Z
    .locals 1

    .line 10
    iget-boolean v0, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    return v0
.end method

.method public final getError()Ljava/lang/String;
    .locals 1

    .line 9
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    return-object v0
.end method

.method public final getId()J
    .locals 2

    .line 8
    iget-wide v0, p0, Lorg/lighttouch/android/QueueItem;->id:J

    return-wide v0
.end method

.method public final getKey()Ljava/lang/String;
    .locals 1

    .line 8
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    return-object v0
.end method

.method public final getName()Ljava/lang/String;
    .locals 1

    .line 8
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final getOverall()F
    .locals 1

    .line 10
    iget v0, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    return v0
.end method

.method public final getPhase()Ljava/lang/String;
    .locals 1

    .line 9
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    return-object v0
.end method

.method public final getProgress()Ljava/lang/Float;
    .locals 1

    .line 9
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    return-object v0
.end method

.method public final getState()Lorg/lighttouch/android/QueueState;
    .locals 1

    .line 8
    iget-object v0, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    return-object v0
.end method

.method public hashCode()I
    .locals 4

    iget-wide v0, p0, Lorg/lighttouch/android/QueueItem;->id:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    invoke-virtual {v2}, Lorg/lighttouch/android/QueueState;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v0, v2

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    const/4 v3, 0x0

    if-nez v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_0
    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v3

    :goto_1
    add-int/2addr v0, v3

    mul-int/lit8 v1, v0, 0x1f

    iget-boolean v2, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    invoke-static {v2}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v0, v1, 0x1f

    iget v2, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v0, v2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 12

    iget-wide v0, p0, Lorg/lighttouch/android/QueueItem;->id:J

    iget-object v2, p0, Lorg/lighttouch/android/QueueItem;->key:Ljava/lang/String;

    iget-object v3, p0, Lorg/lighttouch/android/QueueItem;->name:Ljava/lang/String;

    iget-object v4, p0, Lorg/lighttouch/android/QueueItem;->state:Lorg/lighttouch/android/QueueState;

    iget-object v5, p0, Lorg/lighttouch/android/QueueItem;->phase:Ljava/lang/String;

    iget-object v6, p0, Lorg/lighttouch/android/QueueItem;->progress:Ljava/lang/Float;

    iget-object v7, p0, Lorg/lighttouch/android/QueueItem;->error:Ljava/lang/String;

    iget-boolean v8, p0, Lorg/lighttouch/android/QueueItem;->committed:Z

    iget v9, p0, Lorg/lighttouch/android/QueueItem;->overall:F

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "QueueItem(id="

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", key="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", name="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", state="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", phase="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", progress="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", error="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", committed="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", overall="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ")"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.class public final Lorg/lighttouch/android/MainActivity$poll$1;
.super Ljava/lang/Object;
.source "MainActivity.kt"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/MainActivity;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMainActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MainActivity.kt\norg/lighttouch/android/MainActivity$poll$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1266:1\n1#2:1267\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004"
    }
    d2 = {
        "org/lighttouch/android/MainActivity$poll$1",
        "Ljava/lang/Runnable;",
        "run",
        "",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lorg/lighttouch/android/MainActivity;


# direct methods
.method public static synthetic $r8$lambda$2k88DhhP8SjZN4p_XqN5-SZMTes(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/IFirmware;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/MainActivity$poll$1;)V
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/MainActivity$poll$1;->run$lambda$8$lambda$7(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/IFirmware;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/MainActivity$poll$1;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zQCsDfROks1xbvuUhK9QnoBphVk(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$poll$1;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/MainActivity$poll$1;->run$lambda$8(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$poll$1;)V

    return-void
.end method

.method constructor <init>(Lorg/lighttouch/android/MainActivity;)V
    .locals 0
    .param p1, "$receiver"    # Lorg/lighttouch/android/MainActivity;

    iput-object p1, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    .line 212
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final run$lambda$8(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$poll$1;)V
    .locals 10
    .param p0, "$observedEngine"    # Lorg/lighttouch/android/IEngine;
    .param p1, "$observedFirmware"    # Lorg/lighttouch/android/IFirmware;
    .param p2, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p3, "this$1"    # Lorg/lighttouch/android/MainActivity$poll$1;

    .line 219
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    move-object v4, v0

    .line 220
    .local v4, "engineState":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v7, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v7}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 221
    .local v7, "firmwareState":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v5, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v5}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 222
    .local v5, "engineFailure":Lkotlin/jvm/internal/Ref$ObjectRef;
    new-instance v8, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v8}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 223
    .local v8, "firmwareFailure":Lkotlin/jvm/internal/Ref$ObjectRef;
    const/4 v1, 0x0

    if-eqz p0, :cond_0

    :try_start_0
    invoke-interface {p0}, Lorg/lighttouch/android/IEngine;->status()Landroid/os/Bundle;

    move-result-object v0

    goto :goto_0

    :catch_0
    move-exception v0

    goto :goto_1

    :cond_0
    move-object v0, v1

    :goto_0
    iput-object v0, v4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    .local v0, "e":Landroid/os/RemoteException;
    :goto_1
    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    const-string v2, "\u5de5\u4f5c\u8fdb\u7a0b\u5df2\u9000\u51fa"

    :cond_1
    iput-object v2, v5, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 224
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_2
    if-eqz p1, :cond_2

    :try_start_1
    invoke-interface {p1}, Lorg/lighttouch/android/IFirmware;->status()Landroid/os/Bundle;

    move-result-object v1

    goto :goto_3

    :catch_1
    move-exception v0

    goto :goto_4

    :cond_2
    :goto_3
    iput-object v1, v7, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_5

    .restart local v0    # "e":Landroid/os/RemoteException;
    :goto_4
    invoke-virtual {v0}, Landroid/os/RemoteException;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_3

    const-string v1, "\u56fa\u4ef6\u5de5\u4f5c\u8fdb\u7a0b\u5df2\u9000\u51fa"

    :cond_3
    iput-object v1, v8, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 225
    .end local v0    # "e":Landroid/os/RemoteException;
    :goto_5
    invoke-static {p2}, Lorg/lighttouch/android/MainActivity;->access$getHandler$p(Lorg/lighttouch/android/MainActivity;)Landroid/os/Handler;

    move-result-object v0

    new-instance v1, Lorg/lighttouch/android/MainActivity$poll$1$$ExternalSyntheticLambda1;

    move-object v3, p0

    move-object v6, p1

    move-object v2, p2

    move-object v9, p3

    .end local p0    # "$observedEngine":Lorg/lighttouch/android/IEngine;
    .end local p1    # "$observedFirmware":Lorg/lighttouch/android/IFirmware;
    .end local p2    # "this$0":Lorg/lighttouch/android/MainActivity;
    .end local p3    # "this$1":Lorg/lighttouch/android/MainActivity$poll$1;
    .local v2, "this$0":Lorg/lighttouch/android/MainActivity;
    .local v3, "$observedEngine":Lorg/lighttouch/android/IEngine;
    .local v6, "$observedFirmware":Lorg/lighttouch/android/IFirmware;
    .local v9, "this$1":Lorg/lighttouch/android/MainActivity$poll$1;
    invoke-direct/range {v1 .. v9}, Lorg/lighttouch/android/MainActivity$poll$1$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/IFirmware;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/MainActivity$poll$1;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 260
    return-void
.end method

.method private static final run$lambda$8$lambda$7(Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/IEngine;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/IFirmware;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lorg/lighttouch/android/MainActivity$poll$1;)V
    .locals 14
    .param p0, "this$0"    # Lorg/lighttouch/android/MainActivity;
    .param p1, "$observedEngine"    # Lorg/lighttouch/android/IEngine;
    .param p2, "$engineState"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p3, "$engineFailure"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p4, "$observedFirmware"    # Lorg/lighttouch/android/IFirmware;
    .param p5, "$firmwareState"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p6, "$firmwareFailure"    # Lkotlin/jvm/internal/Ref$ObjectRef;
    .param p7, "this$1"    # Lorg/lighttouch/android/MainActivity$poll$1;

    .line 226
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setPollInFlight$p(Lorg/lighttouch/android/MainActivity;Z)V

    .line 227
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getActive$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    .line 228
    :cond_0
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    invoke-interface {v1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v1

    goto :goto_0

    :cond_1
    move-object v1, v2

    :goto_0
    if-eqz p1, :cond_2

    invoke-interface {p1}, Lorg/lighttouch/android/IEngine;->asBinder()Landroid/os/IBinder;

    move-result-object v3

    goto :goto_1

    :cond_2
    move-object v3, v2

    :goto_1
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const-string v3, "state"

    if-eqz v1, :cond_19

    .line 229
    move-object/from16 v1, p2

    iget-object v4, v1, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v4, Landroid/os/Bundle;

    if-eqz v4, :cond_18

    .local v4, "b\\1":Landroid/os/Bundle;
    const/4 v5, 0x0

    .line 230
    .local v5, "$i$a$-let-MainActivity$poll$1$run$1$1$1\\1\\229\\0":I
    invoke-virtual {v4, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_3

    const-string v6, "\u672a\u77e5"

    :cond_3
    invoke-static {p0, v6}, Lorg/lighttouch/android/MainActivity;->access$setStatus(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 231
    const-string v6, "detail"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, ""

    if-nez v6, :cond_4

    move-object v6, v7

    :cond_4
    invoke-static {p0, v6}, Lorg/lighttouch/android/MainActivity;->access$setDetail(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 232
    const-string v6, "observations"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v6

    const/4 v8, 0x1

    if-eqz v6, :cond_6

    .local v6, "it\\2":Landroid/os/Bundle;
    const/4 v9, 0x0

    .line 233
    .local v9, "$i$a$-let-MainActivity$poll$1$run$1$1$1$1\\2\\232\\1":I
    const-string v10, "runtimeDiagnosticsAvailable"

    invoke-virtual {v6, v10}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_5

    const-string v10, "engineReady"

    invoke-virtual {v6, v10}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v10

    const-wide/16 v12, 0x0

    cmp-long v10, v10, v12

    if-eqz v10, :cond_5

    const-string v10, "displaySleeping"

    invoke-virtual {v6, v10}, Landroid/os/Bundle;->getLong(Ljava/lang/String;)J

    move-result-wide v10

    cmp-long v10, v10, v12

    if-eqz v10, :cond_5

    move v6, v8

    goto :goto_2

    :cond_5
    move v6, v0

    .end local v6    # "it\\2":Landroid/os/Bundle;
    .end local v9    # "$i$a$-let-MainActivity$poll$1$run$1$1$1$1\\2\\232\\1":I
    :goto_2
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    .line 232
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    goto :goto_3

    .line 234
    :cond_6
    move v6, v0

    .line 232
    :goto_3
    invoke-static {p0, v6}, Lorg/lighttouch/android/MainActivity;->access$setDisplayAsleep(Lorg/lighttouch/android/MainActivity;Z)V

    .line 235
    const-string v6, "profileError"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_9

    move-object v9, v6

    .line 1267
    .local v9, "it\\3":Ljava/lang/String;
    const/4 v10, 0x0

    .line 235
    .local v10, "$i$a$-takeIf-MainActivity$poll$1$run$1$1$1$reportedError$1\\3\\235\\1":I
    move-object v11, v9

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-lez v11, :cond_7

    move v11, v8

    goto :goto_4

    :cond_7
    move v11, v0

    .end local v9    # "it\\3":Ljava/lang/String;
    .end local v10    # "$i$a$-takeIf-MainActivity$poll$1$run$1$1$1$reportedError$1\\3\\235\\1":I
    :goto_4
    if-eqz v11, :cond_8

    goto :goto_5

    :cond_8
    move-object v6, v2

    :goto_5
    if-nez v6, :cond_a

    :cond_9
    const-string v6, "error"

    invoke-virtual {v4, v6}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_a

    move-object v6, v7

    .line 236
    .local v6, "reportedError\\1":Ljava/lang/String;
    :cond_a
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getDismissedError$p(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v6, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_b

    invoke-static {p0, v7}, Lorg/lighttouch/android/MainActivity;->access$setDismissedError$p(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 237
    :cond_b
    move-object v9, v6

    check-cast v9, Ljava/lang/CharSequence;

    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v9

    if-lez v9, :cond_c

    move v9, v8

    goto :goto_6

    :cond_c
    move v9, v0

    :goto_6
    const-string v10, "running"

    if-nez v9, :cond_d

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_f

    :cond_d
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getDismissedError$p(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v6, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_e

    move-object v9, v7

    goto :goto_7

    :cond_e
    move-object v9, v6

    :goto_7
    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 238
    :cond_f
    const-string v9, "pid"

    invoke-virtual {v4, v9}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v9

    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setWorkerPid(Lorg/lighttouch/android/MainActivity;I)V

    .line 239
    const-string v9, "profileRecording"

    invoke-virtual {v4, v9}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v9

    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setProfileRecording(Lorg/lighttouch/android/MainActivity;Z)V

    const-string v9, "profileAutomatic"

    invoke-virtual {v4, v9}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v9

    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setProfileAutomatic(Lorg/lighttouch/android/MainActivity;Z)V

    .line 240
    const-string v9, "profileNotice"

    invoke-virtual {v4, v9}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_10

    move-object v9, v7

    :cond_10
    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setProfileNotice(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 241
    const-string v9, "sessionStarted"

    invoke-virtual {v4, v9}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z

    move-result v9

    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setSessionOwned(Lorg/lighttouch/android/MainActivity;Z)V

    .line 242
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_11

    const-string v9, "usbMuxSocket"

    invoke-virtual {v4, v9}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-nez v9, :cond_12

    :cond_11
    move-object v9, v7

    .line 243
    .local v9, "socket\\1":Ljava/lang/String;
    :cond_12
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getMuxSocket(Lorg/lighttouch/android/MainActivity;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v9, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_14

    invoke-static {p0, v9}, Lorg/lighttouch/android/MainActivity;->access$setMuxSocket(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getStore(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreModel;

    move-result-object v11

    invoke-virtual {v11}, Lorg/lighttouch/android/StoreModel;->guestChanged()V

    move-object v11, v9

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-lez v11, :cond_13

    move v11, v8

    goto :goto_8

    :cond_13
    move v11, v0

    :goto_8
    if-eqz v11, :cond_14

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getOverlay(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/Screen;

    move-result-object v11

    sget-object v12, Lorg/lighttouch/android/Screen;->STORE:Lorg/lighttouch/android/Screen;

    if-ne v11, v12, :cond_14

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getStore(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/StoreModel;

    move-result-object v11

    invoke-virtual {v11}, Lorg/lighttouch/android/StoreModel;->refreshGuest()V

    .line 244
    :cond_14
    const-string v11, "appServicesError"

    invoke-virtual {v4, v11}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_15

    goto :goto_9

    :cond_15
    move-object v7, v11

    :goto_9
    invoke-static {p0, v7}, Lorg/lighttouch/android/MainActivity;->access$setAppServicesError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .line 245
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getDisplayView$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/GuestDisplay;

    move-result-object v7

    if-eqz v7, :cond_16

    const/4 v11, 0x3

    new-array v11, v11, [Ljava/lang/String;

    const-string v12, "starting"

    aput-object v12, v11, v0

    aput-object v10, v11, v8

    const/4 v8, 0x2

    const-string v12, "stopping"

    aput-object v12, v11, v8

    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v8, v11}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v8

    invoke-virtual {v7, v8}, Lorg/lighttouch/android/GuestDisplay;->setKeepScreenOn(Z)V

    .line 246
    :cond_16
    invoke-virtual {p0}, Lorg/lighttouch/android/MainActivity;->getStatus()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_17

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$startSensors(Lorg/lighttouch/android/MainActivity;)V

    goto :goto_a

    :cond_17
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$stopSensors(Lorg/lighttouch/android/MainActivity;)V

    .line 247
    :goto_a
    nop

    .line 229
    .end local v4    # "b\\1":Landroid/os/Bundle;
    .end local v5    # "$i$a$-let-MainActivity$poll$1$run$1$1$1\\1\\229\\0":I
    .end local v6    # "reportedError\\1":Ljava/lang/String;
    .end local v9    # "socket\\1":Ljava/lang/String;
    nop

    .line 248
    :cond_18
    move-object/from16 v4, p3

    iget-object v5, v4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    if-eqz v5, :cond_1a

    .line 1267
    .local v5, "it\\4":Ljava/lang/String;
    const/4 v6, 0x0

    .line 248
    .local v6, "$i$a$-let-MainActivity$poll$1$run$1$1$2\\4\\248\\0":I
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$workerExited(Lorg/lighttouch/android/MainActivity;)V

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getEngineExpectedExit$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v7

    if-nez v7, :cond_1a

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "Guest worker unavailable: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ". Writable state retained; Start creates a fresh worker."

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {p0, v7}, Lorg/lighttouch/android/MainActivity;->access$setError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    goto :goto_b

    .line 228
    .end local v5    # "it\\4":Ljava/lang/String;
    .end local v6    # "$i$a$-let-MainActivity$poll$1$run$1$1$2\\4\\248\\0":I
    :cond_19
    move-object/from16 v1, p2

    move-object/from16 v4, p3

    .line 251
    :cond_1a
    :goto_b
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getAddRetainedWhenReady$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v5

    if-eqz v5, :cond_1c

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object v5

    if-eqz v5, :cond_1c

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getPrep$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/PrepareState;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/PrepareState;->getCatalog()Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1c

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getPreparedImportInFlight$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v5

    if-nez v5, :cond_1c

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getPrep$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/PrepareState;

    move-result-object v5

    invoke-virtual {v5}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v5

    if-eqz v5, :cond_1b

    invoke-virtual {v5, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_c

    :cond_1b
    move-object v3, v2

    :goto_c
    const-string v5, "complete"

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1c

    .line 252
    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$setAddRetainedWhenReady$p(Lorg/lighttouch/android/MainActivity;Z)V

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getPrep$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/PrepareState;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/PrepareState;->getPreparation()Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_1c

    .line 1267
    .local v0, "it\\5":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 252
    .local v3, "$i$a$-let-MainActivity$poll$1$run$1$1$3\\5\\252\\0":I
    invoke-static {p0, v0}, Lorg/lighttouch/android/MainActivity;->access$importPreparedOutput(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V

    .line 254
    .end local v0    # "it\\5":Landroid/os/Bundle;
    .end local v3    # "$i$a$-let-MainActivity$poll$1$run$1$1$3\\5\\252\\0":I
    :cond_1c
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getFirmware$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IFirmware;

    move-result-object v0

    if-eqz v0, :cond_1d

    invoke-interface {v0}, Lorg/lighttouch/android/IFirmware;->asBinder()Landroid/os/IBinder;

    move-result-object v0

    goto :goto_d

    :cond_1d
    move-object v0, v2

    :goto_d
    if-eqz p4, :cond_1e

    invoke-interface/range {p4 .. p4}, Lorg/lighttouch/android/IFirmware;->asBinder()Landroid/os/IBinder;

    move-result-object v2

    :cond_1e
    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getFirmwareRestarting(Lorg/lighttouch/android/MainActivity;)Z

    move-result v0

    if-nez v0, :cond_20

    .line 255
    move-object/from16 v0, p5

    iget-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Landroid/os/Bundle;

    if-eqz v2, :cond_1f

    .line 1267
    .local v2, "it\\6":Landroid/os/Bundle;
    const/4 v3, 0x0

    .line 255
    .local v3, "$i$a$-let-MainActivity$poll$1$run$1$1$4\\6\\255\\0":I
    invoke-static {p0, v2}, Lorg/lighttouch/android/MainActivity;->access$pollPreparation(Lorg/lighttouch/android/MainActivity;Landroid/os/Bundle;)V

    .line 256
    .end local v2    # "it\\6":Landroid/os/Bundle;
    .end local v3    # "$i$a$-let-MainActivity$poll$1$run$1$1$4\\6\\255\\0":I
    :cond_1f
    move-object/from16 v2, p6

    iget-object v3, v2, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    if-eqz v3, :cond_21

    .line 1267
    .local v3, "it\\7":Ljava/lang/String;
    const/4 v5, 0x0

    .line 256
    .local v5, "$i$a$-let-MainActivity$poll$1$run$1$1$5\\7\\256\\0":I
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Firmware worker unavailable: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {p0, v6}, Lorg/lighttouch/android/MainActivity;->access$setError(Lorg/lighttouch/android/MainActivity;Ljava/lang/String;)V

    .end local v3    # "it\\7":Ljava/lang/String;
    .end local v5    # "$i$a$-let-MainActivity$poll$1$run$1$1$5\\7\\256\\0":I
    goto :goto_e

    .line 254
    :cond_20
    move-object/from16 v0, p5

    move-object/from16 v2, p6

    .line 258
    :cond_21
    :goto_e
    invoke-static {p0}, Lorg/lighttouch/android/MainActivity;->access$getHandler$p(Lorg/lighttouch/android/MainActivity;)Landroid/os/Handler;

    move-result-object v3

    move-object/from16 v5, p7

    check-cast v5, Ljava/lang/Runnable;

    const-wide/16 v6, 0x1f4

    invoke-virtual {v3, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 259
    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 214
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getActive$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getPollInFlight$p(Lorg/lighttouch/android/MainActivity;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 215
    :cond_0
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lorg/lighttouch/android/MainActivity;->access$setPollInFlight$p(Lorg/lighttouch/android/MainActivity;Z)V

    .line 216
    iget-object v0, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v0}, Lorg/lighttouch/android/MainActivity;->access$getEngine(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IEngine;

    move-result-object v0

    .line 217
    .local v0, "observedEngine":Lorg/lighttouch/android/IEngine;
    iget-object v1, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v1}, Lorg/lighttouch/android/MainActivity;->access$getPreparationOpen(Lorg/lighttouch/android/MainActivity;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v1}, Lorg/lighttouch/android/MainActivity;->access$getFirmwareRestarting(Lorg/lighttouch/android/MainActivity;)Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    invoke-static {v1}, Lorg/lighttouch/android/MainActivity;->access$getFirmware$p(Lorg/lighttouch/android/MainActivity;)Lorg/lighttouch/android/IFirmware;

    move-result-object v1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    .line 218
    .local v1, "observedFirmware":Lorg/lighttouch/android/IFirmware;
    :goto_0
    new-instance v2, Ljava/lang/Thread;

    .line 260
    iget-object v3, p0, Lorg/lighttouch/android/MainActivity$poll$1;->this$0:Lorg/lighttouch/android/MainActivity;

    new-instance v4, Lorg/lighttouch/android/MainActivity$poll$1$$ExternalSyntheticLambda0;

    invoke-direct {v4, v0, v1, v3, p0}, Lorg/lighttouch/android/MainActivity$poll$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/IEngine;Lorg/lighttouch/android/IFirmware;Lorg/lighttouch/android/MainActivity;Lorg/lighttouch/android/MainActivity$poll$1;)V

    .line 218
    const-string v3, "worker-status"

    invoke-direct {v2, v4, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 260
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 261
    return-void

    .line 214
    .end local v0    # "observedEngine":Lorg/lighttouch/android/IEngine;
    .end local v1    # "observedFirmware":Lorg/lighttouch/android/IFirmware;
    :cond_2
    :goto_1
    return-void
.end method

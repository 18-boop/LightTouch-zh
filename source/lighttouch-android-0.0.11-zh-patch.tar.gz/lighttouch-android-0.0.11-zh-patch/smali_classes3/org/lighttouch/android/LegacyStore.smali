.class public final Lorg/lighttouch/android/LegacyStore;
.super Ljava/lang/Object;
.source "LegacyStore.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/lighttouch/android/LegacyStore$Known;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLegacyStore.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LegacyStore.kt\norg/lighttouch/android/LegacyStore\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,387:1\n1#2:388\n1#2:424\n1#2:445\n1#2:465\n1#2:485\n1#2:502\n1#2:517\n1563#3:389\n1634#3,3:390\n1563#3:393\n1634#3,3:394\n1761#3,3:397\n1563#3:400\n1634#3,3:401\n2746#3,3:404\n774#3:407\n865#3,2:408\n1563#3:410\n1634#3,3:411\n1617#3,9:414\n1869#3:423\n1870#3:425\n1626#3:426\n1563#3:427\n1634#3,3:428\n774#3:431\n865#3,2:432\n1056#3:434\n1617#3,9:435\n1869#3:444\n1870#3:446\n1626#3:447\n1563#3:448\n1634#3,3:449\n774#3:452\n865#3,2:453\n1617#3,9:455\n1869#3:464\n1870#3:466\n1626#3:467\n1869#3,2:468\n1626#3:470\n1563#3:471\n1634#3,3:472\n1617#3,9:475\n1869#3:484\n1870#3:486\n1626#3:487\n1563#3:488\n1634#3,3:489\n1617#3,9:492\n1869#3:501\n1870#3:503\n1626#3:504\n295#3,2:505\n1617#3,9:507\n1869#3:516\n1870#3:518\n1626#3:519\n774#3:520\n865#3,2:521\n1563#3:523\n1634#3,3:524\n*S KotlinDebug\n*F\n+ 1 LegacyStore.kt\norg/lighttouch/android/LegacyStore\n*L\n298#1:424\n316#1:445\n325#1:465\n344#1:485\n359#1:502\n360#1:517\n141#1:389\n141#1:390,3\n167#1:393\n167#1:394,3\n168#1:397,3\n222#1:400\n222#1:401,3\n235#1:404,3\n238#1:407\n238#1:408,2\n288#1:410\n288#1:411,3\n298#1:414,9\n298#1:423\n298#1:425\n298#1:426\n299#1:427\n299#1:428,3\n300#1:431\n300#1:432,2\n300#1:434\n316#1:435,9\n316#1:444\n316#1:446\n316#1:447\n317#1:448\n317#1:449,3\n318#1:452\n318#1:453,2\n325#1:455,9\n325#1:464\n325#1:466\n325#1:467\n325#1:468,2\n325#1:470\n342#1:471\n342#1:472,3\n344#1:475,9\n344#1:484\n344#1:486\n344#1:487\n344#1:488\n344#1:489,3\n359#1:492,9\n359#1:501\n359#1:503\n359#1:504\n359#1:505,2\n360#1:507,9\n360#1:516\n360#1:518\n360#1:519\n361#1:520\n361#1:521,2\n361#1:523\n361#1:524,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00bc\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010$\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\n\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\u0008\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001_B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u000e\u0010\r\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u0008J\u0018\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0008\u0018\u00010\u00102\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0005J\"\u0010\u0012\u001a\u00020\u00132\u000c\u0010\u0014\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u00102\u000c\u0010\u0015\u001a\u0008\u0012\u0004\u0012\u00020\u00080\u0010J\u001a\u0010\u0016\u001a\u00020\u00132\u0008\u0010\u0017\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u001b\u001a\u00020\u001cJ\u0010\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u0005H\u0002J$\u0010\u001f\u001a\u00020\u00052\u0006\u0010 \u001a\u00020\u00052\u0012\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u000cH\u0002J0\u0010&\u001a\u00020\u001c2\u0006\u0010 \u001a\u00020\u00052\u0014\u0008\u0002\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u000c2\u0008\u0008\u0002\u0010\'\u001a\u00020\u0013H\u0002J\u0018\u0010(\u001a\u00020\u001c2\u0006\u0010\u001f\u001a\u00020\u00052\u0006\u0010\'\u001a\u00020\u0013H\u0002J*\u0010)\u001a\u0008\u0012\u0004\u0012\u00020\u001c0\u00102\u0012\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u000c2\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u001c\u0010*\u001a\u0008\u0012\u0004\u0012\u00020\u001c0\u00102\u0006\u0010!\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u0019J\u0016\u0010+\u001a\u00020\u001c2\u0006\u0010\u000e\u001a\u00020\u00082\u0006\u0010\u0018\u001a\u00020\u0019J\u000e\u0010,\u001a\u00020\u001c2\u0006\u0010\u000e\u001a\u00020\u0008J\u001a\u0010-\u001a\u00020\u00132\u0008\u0010.\u001a\u0004\u0018\u00010/2\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u0010\u00100\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u001b\u001a\u00020\u001cJ\u001c\u00101\u001a\u0008\u0012\u0004\u0012\u0002020\u00102\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0018\u001a\u00020\u0019J&\u00103\u001a\u0008\u0012\u0004\u0012\u0002020\u00102\u0006\u00104\u001a\u00020/2\u0006\u00105\u001a\u00020\u00082\u0006\u0010\u0018\u001a\u00020\u0019H\u0002J\u0018\u00106\u001a\u0004\u0018\u0001072\u0006\u00108\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u0019J\u001e\u00109\u001a\u00020:2\u0006\u0010;\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0018\u001a\u00020\u0019JH\u0010<\u001a\u00020=2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010>\u001a\u00020=2\u001a\u0010?\u001a\u0016\u0012\u0004\u0012\u00020\n\u0012\u0006\u0012\u0004\u0018\u00010\n\u0012\u0004\u0012\u00020:0@2\u000c\u0010A\u001a\u0008\u0012\u0004\u0012\u00020\u00130BJ \u0010C\u001a\u0008\u0012\u0004\u0012\u00020\u001c0\u00102\u0008\u0010D\u001a\u0004\u0018\u00010/2\u0006\u0010E\u001a\u00020\u0005H\u0002J\u000c\u0010F\u001a\u0008\u0012\u0004\u0012\u00020G0\u0010J\u0016\u0010H\u001a\u00020I2\u0006\u0010J\u001a\u00020\u00052\u0006\u0010K\u001a\u00020\u0005J\u000e\u0010L\u001a\u00020I2\u0006\u0010M\u001a\u00020\u0005J\u000c\u0010N\u001a\u0008\u0012\u0004\u0012\u00020O0\u0010J\u000e\u0010P\u001a\u00020I2\u0006\u0010Q\u001a\u00020\u0005J*\u0010R\u001a\u00020S2\u0006\u0010T\u001a\u00020\u00052\u0006\u0010U\u001a\u00020\u00052\u0008\u0010J\u001a\u0004\u0018\u00010\u00052\u0008\u0010V\u001a\u0004\u0018\u00010\u0005J\u000e\u0010W\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001cJ\u0014\u0010X\u001a\u0008\u0012\u0004\u0012\u00020Y0\u00102\u0006\u0010\u001b\u001a\u00020\u001cJ\u0010\u0010\\\u001a\u0004\u0018\u00010[2\u0006\u0010\u001f\u001a\u00020\u0005J\u0010\u0010^\u001a\u0004\u0018\u00010[2\u0006\u0010\u001f\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\u00080\u000cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R&\u0010\"\u001a\u001a\u0012\u0004\u0012\u00020\u0005\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u001c0$0#X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\nX\u0082T\u00a2\u0006\u0002\n\u0000R\u001a\u0010Z\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020[0#X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010]\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020[0#X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006`"
    }
    d2 = {
        "Lorg/lighttouch/android/LegacyStore;",
        "",
        "<init>",
        "()V",
        "BASE",
        "",
        "USER_AGENT",
        "JSON_LIMIT",
        "",
        "DOWNLOAD_LIMIT",
        "",
        "BROKEN",
        "",
        "preferred",
        "ipaId",
        "version",
        "",
        "value",
        "newer",
        "",
        "a",
        "b",
        "requires",
        "minimum",
        "target",
        "Lorg/lighttouch/android/StoreTarget;",
        "incompatibility",
        "app",
        "Lorg/json/JSONObject;",
        "open",
        "Ljava/net/HttpURLConnection;",
        "url",
        "path",
        "query",
        "responses",
        "Landroid/util/LruCache;",
        "Lkotlin/Pair;",
        "CACHE_MS",
        "json",
        "cached",
        "fetch",
        "apps",
        "search",
        "compatibleCopy",
        "copyDetails",
        "runs",
        "architectures",
        "Lorg/json/JSONArray;",
        "appKey",
        "versions",
        "Lorg/lighttouch/android/StoreCopy;",
        "runnableCopies",
        "data",
        "chosen",
        "lookup",
        "Lorg/lighttouch/android/LegacyStore$Known;",
        "bundleId",
        "checkCopy",
        "",
        "copy",
        "download",
        "Ljava/io/File;",
        "scratch",
        "progress",
        "Lkotlin/Function2;",
        "cancelled",
        "Lkotlin/Function0;",
        "rows",
        "list",
        "what",
        "genres",
        "Lorg/lighttouch/android/StoreGenre;",
        "genreApps",
        "Lorg/lighttouch/android/StorePage;",
        "genreId",
        "sort",
        "page",
        "address",
        "collections",
        "Lorg/lighttouch/android/StoreCollection;",
        "collection",
        "slug",
        "chart",
        "Lorg/lighttouch/android/StoreChart;",
        "type",
        "device",
        "date",
        "appInfo",
        "screenshots",
        "Lorg/lighttouch/android/StoreShot;",
        "screens",
        "Landroid/graphics/Bitmap;",
        "screenshot",
        "icons",
        "icon",
        "Known",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field private static final BASE:Ljava/lang/String; = "https://legacystore.app"

.field private static final BROKEN:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final CACHE_MS:J = 0x927c0L

.field private static final DOWNLOAD_LIMIT:J = 0x80000000L

.field public static final INSTANCE:Lorg/lighttouch/android/LegacyStore;

.field private static final JSON_LIMIT:I = 0x800000

.field private static final USER_AGENT:Ljava/lang/String; = "LightTouchAndroid/0.1 (+https://github.com/blake-lucas/LightTouch)"

.field private static final icons:Landroid/util/LruCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/LruCache<",
            "Ljava/lang/String;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field private static final responses:Landroid/util/LruCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/LruCache<",
            "Ljava/lang/String;",
            "Lkotlin/Pair<",
            "Ljava/lang/Long;",
            "Lorg/json/JSONObject;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final screens:Landroid/util/LruCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/LruCache<",
            "Ljava/lang/String;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $r8$lambda$DZj5_jTJXS5qqlAFJVvZNRlq-1I(B)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/LegacyStore;->download$lambda$26(B)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$LnjDW1RCwL-Kjig7qVRSjSDhLHE(Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    invoke-static {p0, p1, p2}, Lorg/lighttouch/android/LegacyStore;->runnableCopies$lambda$15(Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$jHfEGDFub8xOZF0ubTvZC5S0reE(Ljava/lang/String;Ljava/lang/String;)I
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/LegacyStore;->runnableCopies$lambda$14(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$owLcq8YZ3f7QoOcKwxXmnidWBIA(Ljava/util/Map$Entry;)Ljava/lang/CharSequence;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/LegacyStore;->url$lambda$1(Ljava/util/Map$Entry;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lorg/lighttouch/android/LegacyStore;

    invoke-direct {v0}, Lorg/lighttouch/android/LegacyStore;-><init>()V

    sput-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    .line 60
    const v0, 0xe9cd

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const v1, 0x2bd85

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf(Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Lorg/lighttouch/android/LegacyStore;->BROKEN:Ljava/util/Map;

    .line 121
    new-instance v0, Landroid/util/LruCache;

    const/16 v1, 0x40

    invoke-direct {v0, v1}, Landroid/util/LruCache;-><init>(I)V

    sput-object v0, Lorg/lighttouch/android/LegacyStore;->responses:Landroid/util/LruCache;

    .line 364
    new-instance v0, Landroid/util/LruCache;

    const/16 v1, 0x18

    invoke-direct {v0, v1}, Landroid/util/LruCache;-><init>(I)V

    sput-object v0, Lorg/lighttouch/android/LegacyStore;->screens:Landroid/util/LruCache;

    .line 377
    new-instance v0, Landroid/util/LruCache;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Landroid/util/LruCache;-><init>(I)V

    sput-object v0, Lorg/lighttouch/android/LegacyStore;->icons:Landroid/util/LruCache;

    const/16 v0, 0x8

    sput v0, Lorg/lighttouch/android/LegacyStore;->$stable:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final apps(Ljava/util/Map;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;
    .locals 16
    .param p1, "query"    # Ljava/util/Map;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lorg/lighttouch/android/StoreTarget;",
            ")",
            "Ljava/util/List<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation

    .line 138
    const/4 v0, 0x2

    new-array v1, v0, [Lkotlin/Pair;

    const-string v2, "device"

    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/StoreTarget;->getProductType()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "os"

    invoke-virtual/range {p2 .. p2}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v4, 0x1

    aput-object v2, v1, v4

    invoke-static {v1}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v1

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/collections/MapsKt;->plus(Ljava/util/Map;Ljava/util/Map;)Ljava/util/Map;

    move-result-object v7

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string v6, "/api/emulator/apps"

    const/4 v8, 0x0

    move-object/from16 v5, p0

    invoke-static/range {v5 .. v10}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v5, "apps"

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    const-string v5, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u5e94\u7528\u5217\u8868\u3002"

    const/4 v6, 0x0

    if-eqz v1, :cond_5

    .line 140
    .local v1, "list":Lorg/json/JSONArray;
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v7

    const/16 v8, 0x1f4

    if-gt v7, v8, :cond_4

    .line 141
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v5

    invoke-static {v3, v5}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 389
    .local v7, "$i$f$map\\1\\141":I
    new-instance v8, Ljava/util/ArrayList;

    const/16 v9, 0xa

    invoke-static {v5, v9}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v8, Ljava/util/Collection;

    .local v8, "destination\\2":Ljava/util/Collection;
    move-object v9, v5

    .local v9, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 390
    .local v10, "$i$f$mapTo\\2\\389":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_3

    move-object v12, v11

    check-cast v12, Lkotlin/collections/IntIterator;

    invoke-virtual {v12}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v12

    .line 391
    .local v12, "item\\2":I
    move v13, v12

    .local v13, "index\\3":I
    const/4 v14, 0x0

    .line 142
    .local v14, "$i$a$-map-LegacyStore$apps$1\\3\\391\\0":I
    invoke-virtual {v1, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v15

    .line 143
    .local v15, "app\\3":Lorg/json/JSONObject;
    if-eqz v15, :cond_2

    const-string v4, "ipa_id"

    invoke-virtual {v15, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    if-lez v4, :cond_2

    const-string v4, "name"

    invoke-virtual {v15, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v0, "optString(...)"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_0

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    move v4, v3

    :goto_1
    if-nez v4, :cond_2

    const-string v4, "download_url"

    invoke-virtual {v15, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_1

    const/4 v0, 0x1

    goto :goto_2

    :cond_1
    move v0, v3

    :goto_2
    if-nez v0, :cond_2

    .line 145
    nop

    .line 391
    .end local v13    # "index\\3":I
    .end local v14    # "$i$a$-map-LegacyStore$apps$1\\3\\391\\0":I
    .end local v15    # "app\\3":Lorg/json/JSONObject;
    invoke-interface {v8, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x2

    const/4 v4, 0x1

    goto :goto_0

    .line 144
    .restart local v13    # "index\\3":I
    .restart local v14    # "$i$a$-map-LegacyStore$apps$1\\3\\391\\0":I
    .restart local v15    # "app\\3":Lorg/json/JSONObject;
    :cond_2
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v4, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u5e94\u7528\u6761\u76ee\u3002"

    const/4 v11, 0x2

    invoke-direct {v0, v4, v3, v11, v6}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0

    .line 392
    .end local v12    # "item\\2":I
    .end local v13    # "index\\3":I
    .end local v14    # "$i$a$-map-LegacyStore$apps$1\\3\\391\\0":I
    .end local v15    # "app\\3":Lorg/json/JSONObject;
    :cond_3
    nop

    .end local v8    # "destination\\2":Ljava/util/Collection;
    .end local v9    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v10    # "$i$f$mapTo\\2\\389":I
    move-object v0, v8

    check-cast v0, Ljava/util/List;

    .line 389
    nop

    .line 141
    .end local v5    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v7    # "$i$f$map\\1\\141":I
    return-object v0

    .line 140
    :cond_4
    move v11, v0

    new-instance v0, Lorg/lighttouch/android/StoreError;

    invoke-direct {v0, v5, v3, v11, v6}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0

    .line 139
    .end local v1    # "list":Lorg/json/JSONArray;
    :cond_5
    move v11, v0

    new-instance v0, Lorg/lighttouch/android/StoreError;

    invoke-direct {v0, v5, v3, v11, v6}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method private static final download$lambda$26(B)Ljava/lang/CharSequence;
    .locals 2
    .param p0, "it"    # B

    .line 276
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%02x"

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method

.method private final fetch(Ljava/lang/String;Z)Lorg/json/JSONObject;
    .locals 8
    .param p1, "url"    # Ljava/lang/String;
    .param p2, "cached"    # Z

    .line 128
    if-eqz p2, :cond_0

    sget-object v0, Lorg/lighttouch/android/LegacyStore;->responses:Landroid/util/LruCache;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lkotlin/Pair;

    if-eqz v0, :cond_0

    .line 388
    const/4 v1, 0x0

    .local v1, "$i$a$-let-LegacyStore$fetch$1\\1\\128\\0":I
    invoke-virtual {v0}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    .local v2, "time\\1":J
    invoke-virtual {v0}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/json/JSONObject;

    .line 128
    .local v0, "value\\1":Lorg/json/JSONObject;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v4, v2

    const-wide/32 v6, 0x927c0

    cmp-long v4, v4, v6

    if-gez v4, :cond_0

    return-object v0

    .line 129
    .end local v0    # "value\\1":Lorg/json/JSONObject;
    .end local v1    # "$i$a$-let-LegacyStore$fetch$1\\1\\128\\0":I
    .end local v2    # "time\\1":J
    :cond_0
    invoke-direct {p0, p1}, Lorg/lighttouch/android/LegacyStore;->open(Ljava/lang/String;)Ljava/net/HttpURLConnection;

    move-result-object v0

    .line 130
    .local v0, "connection":Ljava/net/HttpURLConnection;
    :try_start_0
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    check-cast v1, Ljava/io/Closeable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    move-object v2, v1

    check-cast v2, Ljava/io/InputStream;

    .line 388
    .local v2, "it\\2":Ljava/io/InputStream;
    const/4 v3, 0x0

    .line 130
    .local v3, "$i$a$-use-LegacyStore$fetch$body$1\\2\\130\\0":I
    const v4, 0x800001

    invoke-virtual {v2, v4}, Ljava/io/InputStream;->readNBytes(I)[B

    move-result-object v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v2    # "it\\2":Ljava/io/InputStream;
    .end local v3    # "$i$a$-use-LegacyStore$fetch$body$1\\2\\130\\0":I
    const/4 v2, 0x0

    :try_start_2
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 131
    .local v4, "body":[B
    array-length v1, v4

    const/high16 v3, 0x800000

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-gt v1, v3, :cond_2

    .line 132
    :try_start_3
    new-instance v1, Lorg/json/JSONObject;

    invoke-static {v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v4}, Lkotlin/text/StringsKt;->decodeToString([B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0

    .line 133
    .local v1, "value":Lorg/json/JSONObject;
    if-eqz p2, :cond_1

    sget-object v2, Lorg/lighttouch/android/LegacyStore;->responses:Landroid/util/LruCache;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v3, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    invoke-virtual {v2, p1, v3}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    :cond_1
    return-object v1

    .line 132
    .end local v1    # "value":Lorg/json/JSONObject;
    :catch_0
    move-exception v1

    .local v1, "<unused var>":Lorg/json/JSONException;
    new-instance v3, Lorg/lighttouch/android/StoreError;

    const-string v7, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u54cd\u5e94\u3002"

    invoke-direct {v3, v7, v6, v5, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v3

    .line 131
    .end local v1    # "<unused var>":Lorg/json/JSONException;
    :cond_2
    new-instance v1, Lorg/lighttouch/android/StoreError;

    const-string v3, "\u76ee\u5f55\u54cd\u5e94\u8d85\u51fa\u5927\u5c0f\u9650\u5236\u3002"

    invoke-direct {v1, v3, v6, v5, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v1

    .line 130
    .end local v4    # "body":[B
    :catchall_0
    move-exception v2

    .end local v0    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    .end local p2    # "cached":Z
    :try_start_4
    throw v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .restart local v0    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    .restart local p2    # "cached":Z
    :catchall_1
    move-exception v3

    :try_start_5
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "connection":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    .end local p2    # "cached":Z
    throw v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .restart local v0    # "connection":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    .restart local p2    # "cached":Z
    :catchall_2
    move-exception v1

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    throw v1
.end method

.method private final json(Ljava/lang/String;Ljava/util/Map;Z)Lorg/json/JSONObject;
    .locals 1
    .param p1, "path"    # Ljava/lang/String;
    .param p2, "query"    # Ljava/util/Map;
    .param p3, "cached"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z)",
            "Lorg/json/JSONObject;"
        }
    .end annotation

    .line 125
    invoke-direct {p0, p1, p2}, Lorg/lighttouch/android/LegacyStore;->url(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0, p3}, Lorg/lighttouch/android/LegacyStore;->fetch(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    return-object v0
.end method

.method static synthetic json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;
    .locals 0

    .line 125
    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_0

    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object p2

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    const/4 p3, 0x0

    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lorg/lighttouch/android/LegacyStore;->json(Ljava/lang/String;Ljava/util/Map;Z)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0
.end method

.method private final open(Ljava/lang/String;)Ljava/net/HttpURLConnection;
    .locals 10
    .param p1, "url"    # Ljava/lang/String;

    .line 90
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 91
    .local v0, "parsed":Ljava/net/URL;
    invoke-virtual {v0}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v1

    const-string v2, "https"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_9

    invoke-virtual {v0}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    if-eqz v1, :cond_1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x1

    :goto_1
    if-nez v1, :cond_9

    invoke-virtual {v0}, Ljava/net/URL;->getUserInfo()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_9

    .line 92
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    const-string v6, "null cannot be cast to non-null type javax.net.ssl.HttpsURLConnection"

    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljavax/net/ssl/HttpsURLConnection;

    .line 93
    .local v1, "connection":Ljavax/net/ssl/HttpsURLConnection;
    const/16 v6, 0x7530

    invoke-virtual {v1, v6}, Ljavax/net/ssl/HttpsURLConnection;->setConnectTimeout(I)V

    invoke-virtual {v1, v6}, Ljavax/net/ssl/HttpsURLConnection;->setReadTimeout(I)V

    .line 94
    const-string v6, "User-Agent"

    const-string v7, "LightTouchAndroid/0.1 (+https://github.com/blake-lucas/LightTouch)"

    invoke-virtual {v1, v6, v7}, Ljavax/net/ssl/HttpsURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    :try_start_0
    invoke-virtual {v1}, Ljavax/net/ssl/HttpsURLConnection;->getResponseCode()I

    move-result v6
    :try_end_0
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 103
    .local v6, "code":I
    invoke-virtual {v1}, Ljavax/net/ssl/HttpsURLConnection;->getURL()Ljava/net/URL;

    move-result-object v7

    invoke-virtual {v7}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    .line 104
    const/16 v2, 0xc8

    if-eq v6, v2, :cond_7

    .line 105
    invoke-virtual {v1}, Ljavax/net/ssl/HttpsURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v2

    if-eqz v2, :cond_2

    check-cast v2, Ljava/io/Closeable;

    :try_start_1
    move-object v7, v2

    check-cast v7, Ljava/io/InputStream;

    .line 388
    .local v7, "it\\1":Ljava/io/InputStream;
    const/4 v8, 0x0

    .line 105
    .local v8, "$i$a$-use-LegacyStore$open$body$1\\1\\105\\0":I
    const/16 v9, 0x1000

    invoke-virtual {v7, v9}, Ljava/io/InputStream;->readNBytes(I)[B

    move-result-object v9
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .end local v7    # "it\\1":Ljava/io/InputStream;
    .end local v8    # "$i$a$-use-LegacyStore$open$body$1\\1\\105\\0":I
    invoke-static {v2, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    if-eqz v9, :cond_2

    invoke-static {v9}, Lkotlin/text/StringsKt;->decodeToString([B)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    goto :goto_2

    :catchall_0
    move-exception v3

    .end local v0    # "parsed":Ljava/net/URL;
    .end local v1    # "connection":Ljavax/net/ssl/HttpsURLConnection;
    .end local v6    # "code":I
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    :try_start_2
    throw v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .restart local v0    # "parsed":Ljava/net/URL;
    .restart local v1    # "connection":Ljavax/net/ssl/HttpsURLConnection;
    .restart local v6    # "code":I
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_1
    move-exception v4

    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v4

    :cond_2
    :goto_2
    const-string v2, ""

    .line 106
    .local v2, "body":Ljava/lang/String;
    :cond_3
    invoke-virtual {v1}, Ljavax/net/ssl/HttpsURLConnection;->disconnect()V

    .line 107
    new-instance v7, Lorg/lighttouch/android/StoreError;

    .line 108
    const/16 v8, 0x190

    if-ne v6, v8, :cond_5

    move-object v8, v2

    check-cast v8, Ljava/lang/CharSequence;

    const-string v9, "device must be one of"

    check-cast v9, Ljava/lang/CharSequence;

    invoke-static {v8, v9, v5, v3, v4}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_3

    :cond_4
    const-string v3, "\u65e7\u7248\u5546\u5e97\u5c1a\u4e0d\u652f\u6301\u6b64\u8bbe\u5907\u3002"

    goto :goto_4

    .line 109
    :cond_5
    :goto_3
    const/16 v3, 0x1f7

    if-ne v6, v3, :cond_6

    const-string v3, "Internet Archive \u7e41\u5fd9\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\u3002"

    goto :goto_4

    .line 110
    :cond_6
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Legacy Store could not answer the request (HTTP "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ")."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 111
    :goto_4
    nop

    .line 107
    invoke-direct {v7, v3, v6}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;I)V

    throw v7

    .line 113
    .end local v2    # "body":Ljava/lang/String;
    :cond_7
    move-object v2, v1

    check-cast v2, Ljava/net/HttpURLConnection;

    return-object v2

    .line 103
    :cond_8
    invoke-virtual {v1}, Ljavax/net/ssl/HttpsURLConnection;->disconnect()V

    new-instance v2, Lorg/lighttouch/android/StoreError;

    const-string v7, "\u76ee\u5f55\u91cd\u5b9a\u5411\u5230\u4e86\u4e0d\u5b89\u5168\u7684\u5730\u5740\u3002"

    invoke-direct {v2, v7, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v2

    .line 100
    .end local v6    # "code":I
    :catch_0
    move-exception v2

    .line 101
    .local v2, "e":Ljava/io/IOException;
    new-instance v6, Lorg/lighttouch/android/StoreError;

    invoke-virtual {v2}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Could not connect to Legacy Store: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v6

    .line 97
    .end local v2    # "e":Ljava/io/IOException;
    :catch_1
    move-exception v2

    .line 99
    .local v2, "e":Ljava/net/UnknownHostException;
    new-instance v6, Lorg/lighttouch/android/StoreError;

    const-string v7, "\u65e0\u6cd5\u8fde\u63a5\u65e7\u7248\u5546\u5e97\u3002\u8bf7\u68c0\u67e5\u7f51\u7edc\uff0c\u5e76\u786e\u8ba4\u5df2\u5728 Android \u5e94\u7528\u8bbe\u7f6e\u4e2d\u5141\u8bb8 LightTouch \u8054\u7f51\u3002"

    invoke-direct {v6, v7, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v6

    .line 91
    .end local v1    # "connection":Ljavax/net/ssl/HttpsURLConnection;
    .end local v2    # "e":Ljava/net/UnknownHostException;
    :cond_9
    new-instance v1, Lorg/lighttouch/android/StoreError;

    const-string v2, "\u76ee\u5f55\u63d0\u4f9b\u4e86\u65e0\u6548\u7684 HTTPS \u5730\u5740\u3002"

    invoke-direct {v1, v2, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v1
.end method

.method private final requires(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Z
    .locals 6
    .param p1, "minimum"    # Ljava/lang/String;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;

    .line 67
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 68
    :cond_0
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    .line 69
    .local v1, "need":Ljava/util/List;
    invoke-virtual {p2}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0, v4}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_1

    invoke-virtual {p0, v1, v4}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v0

    return v0

    :cond_1
    new-instance v4, Lorg/lighttouch/android/StoreError;

    const-string v5, "\u5ba2\u6237\u673a iOS \u7248\u672c\u65e0\u6548\u3002"

    invoke-direct {v4, v5, v0, v3, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4

    .line 68
    .end local v1    # "need":Ljava/util/List;
    :cond_2
    new-instance v1, Lorg/lighttouch/android/StoreError;

    const-string v4, "\u65e0\u6cd5\u786e\u8ba4\u6700\u4f4e iOS \u7248\u672c\u8981\u6c42\u3002"

    invoke-direct {v1, v4, v0, v3, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v1
.end method

.method private final rows(Lorg/json/JSONArray;Ljava/lang/String;)Ljava/util/List;
    .locals 16
    .param p1, "list"    # Lorg/json/JSONArray;
    .param p2, "what"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation

    .line 287
    move-object/from16 v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    const/16 v5, 0x1f4

    if-gt v4, v5, :cond_3

    .line 288
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v4

    invoke-static {v3, v4}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v4

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 410
    .local v5, "$i$f$map\\1\\288":I
    new-instance v6, Ljava/util/ArrayList;

    const/16 v7, 0xa

    invoke-static {v4, v7}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\2":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 411
    .local v8, "$i$f$mapTo\\2\\410":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2

    move-object v10, v9

    check-cast v10, Lkotlin/collections/IntIterator;

    invoke-virtual {v10}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v10

    .line 412
    .local v10, "item\\2":I
    move v11, v10

    .local v11, "index\\3":I
    const/4 v12, 0x0

    .line 289
    .local v12, "$i$a$-map-LegacyStore$rows$1\\3\\412\\0":I
    invoke-virtual {v0, v11}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    .line 290
    .local v13, "app\\3":Lorg/json/JSONObject;
    if-eqz v13, :cond_1

    const-string v14, "name"

    invoke-virtual {v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "optString(...)"

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v14, Ljava/lang/CharSequence;

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-nez v14, :cond_0

    const/4 v14, 0x1

    goto :goto_1

    :cond_0
    move v14, v3

    :goto_1
    if-nez v14, :cond_1

    .line 291
    nop

    .line 412
    .end local v11    # "index\\3":I
    .end local v12    # "$i$a$-map-LegacyStore$rows$1\\3\\412\\0":I
    .end local v13    # "app\\3":Lorg/json/JSONObject;
    invoke-interface {v6, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 290
    .restart local v11    # "index\\3":I
    .restart local v12    # "$i$a$-map-LegacyStore$rows$1\\3\\412\\0":I
    .restart local v13    # "app\\3":Lorg/json/JSONObject;
    :cond_1
    new-instance v9, Lorg/lighttouch/android/StoreError;

    const-string v14, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u5e94\u7528\u6761\u76ee\u3002"

    invoke-direct {v9, v14, v3, v2, v1}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v9

    .line 413
    .end local v10    # "item\\2":I
    .end local v11    # "index\\3":I
    .end local v12    # "$i$a$-map-LegacyStore$rows$1\\3\\412\\0":I
    .end local v13    # "app\\3":Lorg/json/JSONObject;
    :cond_2
    nop

    .end local v6    # "destination\\2":Ljava/util/Collection;
    .end local v7    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapTo\\2\\410":I
    move-object v1, v6

    check-cast v1, Ljava/util/List;

    .line 410
    nop

    .line 288
    .end local v4    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v5    # "$i$f$map\\1\\288":I
    return-object v1

    .line 287
    :cond_3
    new-instance v4, Lorg/lighttouch/android/StoreError;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "Legacy Store sent an unreadable "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    move-object/from16 v6, p2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "."

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5, v3, v2, v1}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4
.end method

.method private final runnableCopies(Lorg/json/JSONArray;ILorg/lighttouch/android/StoreTarget;)Ljava/util/List;
    .locals 24
    .param p1, "data"    # Lorg/json/JSONArray;
    .param p2, "chosen"    # I
    .param p3, "target"    # Lorg/lighttouch/android/StoreTarget;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            "I",
            "Lorg/lighttouch/android/StoreTarget;",
            ")",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCopy;",
            ">;"
        }
    .end annotation

    .line 188
    move-object/from16 v1, p0

    move-object/from16 v2, p3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object v3, v0

    check-cast v3, Ljava/util/List;

    .line 189
    .local v3, "rows":Ljava/util/List;
    const/4 v0, 0x0

    .local v0, "v":I
    invoke-virtual/range {p1 .. p1}, Lorg/json/JSONArray;->length()I

    move-result v4

    move v5, v0

    .end local v0    # "v":I
    .local v5, "v":I
    :goto_0
    if-ge v5, v4, :cond_12

    .line 190
    move-object/from16 v6, p1

    invoke-virtual {v6, v5}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    if-nez v0, :cond_0

    move-object/from16 v17, v3

    move/from16 v20, v4

    goto/16 :goto_c

    :cond_0
    move-object v7, v0

    .line 191
    .local v7, "entry":Lorg/json/JSONObject;
    const-string v0, "minimum_os_version"

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-nez v8, :cond_1

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    :goto_1
    if-eqz v8, :cond_2

    .line 388
    const/4 v0, 0x0

    .line 191
    .local v0, "$i$a$-ifEmpty-LegacyStore$runnableCopies$minimum$1\\1\\191\\0":I
    const/4 v0, 0x0

    .end local v0    # "$i$a$-ifEmpty-LegacyStore$runnableCopies$minimum$1\\1\\191\\0":I
    :cond_2
    move-object v8, v0

    check-cast v8, Ljava/lang/String;

    .line 192
    .local v8, "minimum":Ljava/lang/String;
    const-string v0, "copies"

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    if-nez v0, :cond_3

    move-object/from16 v17, v3

    move/from16 v20, v4

    goto/16 :goto_c

    :cond_3
    move-object v12, v0

    .line 193
    .local v12, "copies":Lorg/json/JSONArray;
    const/4 v0, 0x0

    .local v0, "c":I
    invoke-virtual {v12}, Lorg/json/JSONArray;->length()I

    move-result v13

    move v14, v0

    .end local v0    # "c":I
    .local v14, "c":I
    :goto_2
    if-ge v14, v13, :cond_11

    .line 194
    invoke-virtual {v12, v14}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    if-nez v0, :cond_4

    move-object/from16 v17, v3

    move/from16 v20, v4

    const/16 v16, 0x0

    const/16 v19, 0x1

    goto/16 :goto_b

    :cond_4
    move-object v15, v0

    .line 195
    .local v15, "copy":Lorg/json/JSONObject;
    const-string v0, "ipa_id"

    invoke-virtual {v15, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/16 v16, 0x0

    const-string v9, "optString(...)"

    invoke-static {v0, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_10

    move-object/from16 v17, v0

    check-cast v17, Ljava/lang/Number;

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    move-result v17

    .line 388
    .local v17, "it\\2":I
    const/16 v18, 0x0

    .line 195
    .local v18, "$i$a$-takeIf-LegacyStore$runnableCopies$id$1\\2\\195\\0":I
    const/16 v19, 0x1

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    sget-object v11, Lorg/lighttouch/android/LegacyStore;->BROKEN:Ljava/util/Map;

    invoke-interface {v11, v10}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    .end local v17    # "it\\2":I
    .end local v18    # "$i$a$-takeIf-LegacyStore$runnableCopies$id$1\\2\\195\\0":I
    if-nez v10, :cond_5

    goto :goto_3

    :cond_5
    const/4 v0, 0x0

    :goto_3
    if-eqz v0, :cond_f

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    move v10, v0

    .line 196
    .local v10, "id":I
    const-string v0, "macho_min_os"

    invoke-virtual {v15, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-nez v11, :cond_6

    move/from16 v11, v19

    goto :goto_4

    :cond_6
    move/from16 v11, v16

    :goto_4
    if-eqz v11, :cond_7

    .line 388
    const/4 v0, 0x0

    .line 196
    .local v0, "$i$a$-ifEmpty-LegacyStore$runnableCopies$machoMinimum$1\\3\\196\\0":I
    const/4 v0, 0x0

    .end local v0    # "$i$a$-ifEmpty-LegacyStore$runnableCopies$machoMinimum$1\\3\\196\\0":I
    :cond_7
    move-object v11, v0

    check-cast v11, Ljava/lang/String;

    .line 197
    .local v11, "machoMinimum":Ljava/lang/String;
    const-string v0, "install_status"

    invoke-virtual {v15, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v17, v3

    .end local v3    # "rows":Ljava/util/List;
    .local v17, "rows":Ljava/util/List;
    const-string v3, "installable"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    const-string v0, "architectures"

    invoke-virtual {v15, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    invoke-direct {v1, v0, v2}, Lorg/lighttouch/android/LegacyStore;->runs(Lorg/json/JSONArray;Lorg/lighttouch/android/StoreTarget;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 198
    :try_start_0
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, v1

    check-cast v0, Lorg/lighttouch/android/LegacyStore;

    .line 388
    .local v0, "$this$runnableCopies_u24lambda_u2412\\4":Lorg/lighttouch/android/LegacyStore;
    const/4 v3, 0x0

    .line 198
    .local v3, "$i$a$-runCatching-LegacyStore$runnableCopies$fits$1\\4\\198\\0":I
    invoke-direct {v0, v8, v2}, Lorg/lighttouch/android/LegacyStore;->requires(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Z

    move-result v18

    if-nez v18, :cond_8

    invoke-direct {v0, v11, v2}, Lorg/lighttouch/android/LegacyStore;->requires(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Z

    move-result v18

    if-nez v18, :cond_8

    move/from16 v0, v19

    goto :goto_5

    :cond_8
    move/from16 v0, v16

    .end local v0    # "$this$runnableCopies_u24lambda_u2412\\4":Lorg/lighttouch/android/LegacyStore;
    .end local v3    # "$i$a$-runCatching-LegacyStore$runnableCopies$fits$1\\4\\198\\0":I
    :goto_5
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_6

    :catchall_0
    move-exception v0

    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_6
    invoke-static/range {v16 .. v16}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    invoke-static {v0}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_9

    move-object v0, v3

    :cond_9
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_a

    move/from16 v0, v19

    goto :goto_7

    :cond_a
    move/from16 v0, v16

    .line 197
    :goto_7
    nop

    .line 199
    .local v0, "fits":Z
    if-nez v0, :cond_c

    move/from16 v3, p2

    if-ne v10, v3, :cond_b

    goto :goto_8

    :cond_b
    move/from16 v20, v4

    goto :goto_b

    :cond_c
    move/from16 v3, p2

    :goto_8
    move/from16 v18, v0

    .end local v0    # "fits":Z
    .local v18, "fits":Z
    move-object/from16 v0, v17

    check-cast v0, Ljava/util/Collection;

    const-string v1, "version"

    const-string v2, "\u672a\u77e5"

    invoke-virtual {v7, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 200
    const-string v2, "size"

    invoke-virtual {v15, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v20

    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->longValue()J

    move-result-wide v20

    .line 388
    nop

    .local v20, "it\\5":J
    const/4 v9, 0x0

    .line 200
    .local v9, "$i$a$-takeIf-LegacyStore$runnableCopies$1\\5\\200\\0":I
    const-wide/16 v22, 0x0

    cmp-long v22, v20, v22

    if-lez v22, :cond_d

    move/from16 v9, v19

    goto :goto_9

    :cond_d
    move/from16 v9, v16

    .end local v9    # "$i$a$-takeIf-LegacyStore$runnableCopies$1\\5\\200\\0":I
    .end local v20    # "it\\5":J
    :goto_9
    if-eqz v9, :cond_e

    goto :goto_a

    :cond_e
    const/4 v2, 0x0

    :goto_a
    const/4 v9, 0x2

    new-array v9, v9, [Ljava/lang/String;

    aput-object v8, v9, v16

    aput-object v11, v9, v19

    invoke-static {v9}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    check-cast v9, Ljava/lang/Iterable;

    new-instance v3, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda1;

    invoke-direct {v3}, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda1;-><init>()V

    move/from16 v20, v4

    new-instance v4, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda2;

    invoke-direct {v4, v3}, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/functions/Function2;)V

    invoke-static {v9, v4}, Lkotlin/collections/CollectionsKt;->maxWithOrNull(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 199
    new-instance v4, Lorg/lighttouch/android/StoreCopy;

    invoke-direct {v4, v10, v1, v2, v3}, Lorg/lighttouch/android/StoreCopy;-><init>(ILjava/lang/String;Ljava/lang/Long;Ljava/lang/String;)V

    invoke-interface {v0, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_b

    .line 195
    .end local v10    # "id":I
    .end local v11    # "machoMinimum":Ljava/lang/String;
    .end local v17    # "rows":Ljava/util/List;
    .end local v18    # "fits":Z
    .local v3, "rows":Ljava/util/List;
    :cond_f
    move-object/from16 v17, v3

    move/from16 v20, v4

    goto :goto_b

    :cond_10
    move-object/from16 v17, v3

    move/from16 v20, v4

    const/16 v19, 0x1

    .line 193
    .end local v3    # "rows":Ljava/util/List;
    .end local v15    # "copy":Lorg/json/JSONObject;
    .restart local v17    # "rows":Ljava/util/List;
    :goto_b
    add-int/lit8 v14, v14, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p3

    move-object/from16 v3, v17

    move/from16 v4, v20

    goto/16 :goto_2

    .end local v17    # "rows":Ljava/util/List;
    .restart local v3    # "rows":Ljava/util/List;
    :cond_11
    move-object/from16 v17, v3

    move/from16 v20, v4

    .line 189
    .end local v3    # "rows":Ljava/util/List;
    .end local v7    # "entry":Lorg/json/JSONObject;
    .end local v8    # "minimum":Ljava/lang/String;
    .end local v12    # "copies":Lorg/json/JSONArray;
    .end local v14    # "c":I
    .restart local v17    # "rows":Ljava/util/List;
    :goto_c
    add-int/lit8 v5, v5, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p3

    move-object/from16 v3, v17

    move/from16 v4, v20

    goto/16 :goto_0

    .end local v17    # "rows":Ljava/util/List;
    .restart local v3    # "rows":Ljava/util/List;
    :cond_12
    move-object/from16 v17, v3

    .line 205
    .end local v3    # "rows":Ljava/util/List;
    .end local v5    # "v":I
    .restart local v17    # "rows":Ljava/util/List;
    return-object v17
.end method

.method private static final runnableCopies$lambda$14(Ljava/lang/String;Ljava/lang/String;)I
    .locals 7
    .param p0, "a"    # Ljava/lang/String;
    .param p1, "b"    # Ljava/lang/String;

    .line 201
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v0, p0}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    if-nez v0, :cond_0

    new-array v0, v2, [Ljava/lang/Integer;

    aput-object v5, v0, v4

    aput-object v5, v0, v3

    aput-object v5, v0, v1

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .local v0, "x":Ljava/util/List;
    :cond_0
    sget-object v6, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v6, p1}, Lorg/lighttouch/android/LegacyStore;->version(Ljava/lang/String;)Ljava/util/List;

    move-result-object v6

    if-nez v6, :cond_1

    new-array v2, v2, [Ljava/lang/Integer;

    aput-object v5, v2, v4

    aput-object v5, v2, v3

    aput-object v5, v2, v1

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 202
    .local v6, "y":Ljava/util/List;
    :cond_1
    sget-object v1, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v1, v0, v6}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_0

    :cond_2
    sget-object v1, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-virtual {v1, v6, v0}, Lorg/lighttouch/android/LegacyStore;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v1

    if-eqz v1, :cond_3

    const/4 v3, -0x1

    goto :goto_0

    :cond_3
    move v3, v4

    :goto_0
    return v3
.end method

.method private static final runnableCopies$lambda$15(Lkotlin/jvm/functions/Function2;Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 1
    .param p0, "$tmp0"    # Lkotlin/jvm/functions/Function2;
    .param p1, "p0"    # Ljava/lang/Object;
    .param p2, "p1"    # Ljava/lang/Object;

    .line 200
    invoke-interface {p0, p1, p2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    return v0
.end method

.method private final runs(Lorg/json/JSONArray;Lorg/lighttouch/android/StoreTarget;)Z
    .locals 10
    .param p1, "architectures"    # Lorg/json/JSONArray;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;

    .line 167
    const/4 v0, 0x0

    if-eqz p1, :cond_6

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 393
    .local v2, "$i$f$map\\1\\167":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v4, v1

    .local v4, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 394
    .local v5, "$i$f$mapTo\\2\\393":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_0

    move-object v7, v6

    check-cast v7, Lkotlin/collections/IntIterator;

    invoke-virtual {v7}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v7

    .line 395
    .local v7, "item\\2":I
    move v8, v7

    .local v8, "it\\3":I
    const/4 v9, 0x0

    .line 167
    .local v9, "$i$a$-map-LegacyStore$runs$1\\3\\395\\0":I
    invoke-virtual {p1, v8}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v8

    .line 395
    .end local v8    # "it\\3":I
    .end local v9    # "$i$a$-map-LegacyStore$runs$1\\3\\395\\0":I
    invoke-interface {v3, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 396
    .end local v7    # "item\\2":I
    :cond_0
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v4    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo\\2\\393":I
    check-cast v3, Ljava/util/List;

    .line 393
    nop

    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map\\1\\167":I
    check-cast v3, Ljava/lang/Iterable;

    .line 168
    nop

    .local v3, "$this$any\\4":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 397
    .local v1, "$i$f$any\\4\\168":I
    instance-of v2, v3, Ljava/util/Collection;

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    move-object v2, v3

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    move v1, v0

    goto :goto_3

    .line 398
    :cond_1
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\4":Ljava/lang/Object;
    move-object v6, v5

    check-cast v6, Ljava/lang/String;

    .local v6, "it\\5":Ljava/lang/String;
    const/4 v7, 0x0

    .line 168
    .local v7, "$i$a$-any-LegacyStore$runs$2\\5\\398\\0":I
    invoke-virtual {p2}, Lorg/lighttouch/android/StoreTarget;->getArch()Ljava/lang/String;

    move-result-object v8

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_4

    invoke-virtual {p2}, Lorg/lighttouch/android/StoreTarget;->getArch()Ljava/lang/String;

    move-result-object v8

    const-string v9, "armv7"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_3

    const-string v8, "armv6"

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_3

    goto :goto_1

    :cond_3
    move v6, v0

    goto :goto_2

    :cond_4
    :goto_1
    move v6, v4

    .line 398
    .end local v6    # "it\\5":Ljava/lang/String;
    .end local v7    # "$i$a$-any-LegacyStore$runs$2\\5\\398\\0":I
    :goto_2
    if-eqz v6, :cond_2

    move v1, v4

    goto :goto_3

    .line 399
    .end local v5    # "element\\4":Ljava/lang/Object;
    :cond_5
    move v1, v0

    .line 168
    .end local v1    # "$i$f$any\\4\\168":I
    .end local v3    # "$this$any\\4":Ljava/lang/Iterable;
    :goto_3
    if-eqz v1, :cond_6

    move v0, v4

    goto :goto_4

    :cond_6
    nop

    :goto_4
    return v0
.end method

.method private final url(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
    .locals 10
    .param p1, "path"    # Ljava/lang/String;
    .param p2, "query"    # Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 116
    invoke-interface {p2}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    const-string v0, "&"

    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v7, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda0;

    invoke-direct {v7}, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda0;-><init>()V

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v1 .. v9}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "?"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "https://legacystore.app"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 118
    return-object v0
.end method

.method private static final url$lambda$1(Ljava/util/Map$Entry;)Ljava/lang/CharSequence;
    .locals 3
    .param p0, "it"    # Ljava/util/Map$Entry;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 117
    invoke-interface {p0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v1, "UTF-8"

    invoke-static {v0, v1}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v2, v1}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    return-object v0
.end method


# virtual methods
.method public final appInfo(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 8
    .param p1, "app"    # Lorg/json/JSONObject;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 351
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/LegacyStore;->appKey(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 352
    .local v0, "key":Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "/api/v1/apps/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object v2, p0

    invoke-static/range {v2 .. v7}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    return-object v1

    .line 351
    .end local v0    # "key":Ljava/lang/String;
    :cond_0
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v3, "\u6b64\u5e94\u7528\u6ca1\u6709\u76ee\u5f55\u6807\u8bc6\u7b26\u3002"

    const/4 v4, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final appKey(Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 9
    .param p1, "app"    # Lorg/json/JSONObject;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    nop

    .line 172
    const-string v0, "app_store_id"

    invoke-static {p1, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_1

    const-string v0, "bundle_id"

    invoke-static {p1, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    const-string v0, "app_url"

    invoke-static {p1, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    new-array v2, v2, [C

    const/4 v3, 0x0

    const/16 v4, 0x2f

    aput-char v4, v2, v3

    invoke-static {v0, v2}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-static {v0, v4, v1, v2, v1}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    move-object v0, v1

    .line 173
    :cond_1
    :goto_0
    if-eqz v0, :cond_2

    .line 172
    nop

    .line 173
    nop

    .line 388
    .local v0, "it\\1":Ljava/lang/String;
    const/4 v1, 0x0

    .line 173
    .local v1, "$i$a$-let-LegacyStore$appKey$1\\1\\173\\0":I
    const-string v2, "UTF-8"

    invoke-static {v0, v2}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v2, "encode(...)"

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v4, "+"

    const-string v5, "%20"

    const/4 v6, 0x0

    invoke-static/range {v3 .. v8}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .end local v0    # "it\\1":Ljava/lang/String;
    .end local v1    # "$i$a$-let-LegacyStore$appKey$1\\1\\173\\0":I
    :cond_2
    return-object v1
.end method

.method public final chart(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/lighttouch/android/StoreChart;
    .locals 26
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "device"    # Ljava/lang/String;
    .param p3, "genreId"    # Ljava/lang/String;
    .param p4, "date"    # Ljava/lang/String;

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-string v0, "type"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "device"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 335
    const/4 v4, 0x2

    new-array v5, v4, [Lkotlin/Pair;

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/4 v6, 0x0

    aput-object v0, v5, v6

    invoke-static {v3, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/4 v3, 0x1

    aput-object v0, v5, v3

    invoke-static {v5}, Lkotlin/collections/MapsKt;->mutableMapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v5

    .line 336
    .local v5, "query":Ljava/util/Map;
    if-eqz p3, :cond_0

    move-object/from16 v0, p3

    .line 388
    .local v0, "it\\1":Ljava/lang/String;
    const/4 v7, 0x0

    .line 336
    .local v7, "$i$a$-let-LegacyStore$chart$1\\1\\336\\0":I
    const-string v8, "genre"

    invoke-interface {v5, v8, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .end local v0    # "it\\1":Ljava/lang/String;
    .end local v7    # "$i$a$-let-LegacyStore$chart$1\\1\\336\\0":I
    :cond_0
    if-eqz p4, :cond_1

    move-object/from16 v0, p4

    .line 388
    .local v0, "it\\2":Ljava/lang/String;
    const/4 v7, 0x0

    .line 336
    .local v7, "$i$a$-let-LegacyStore$chart$2\\2\\336\\0":I
    const-string v8, "date"

    invoke-interface {v5, v8, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 337
    .end local v0    # "it\\2":Ljava/lang/String;
    .end local v7    # "$i$a$-let-LegacyStore$chart$2\\2\\336\\0":I
    :cond_1
    :try_start_0
    const-string v0, "/api/v1/charts"
    :try_end_0
    .catch Lorg/lighttouch/android/StoreError; {:try_start_0 .. :try_end_0} :catch_1

    move-object/from16 v7, p0

    :try_start_1
    invoke-direct {v7, v0, v5, v3}, Lorg/lighttouch/android/LegacyStore;->json(Ljava/lang/String;Ljava/util/Map;Z)Lorg/json/JSONObject;

    move-result-object v0
    :try_end_1
    .catch Lorg/lighttouch/android/StoreError; {:try_start_1 .. :try_end_1} :catch_0

    .line 341
    .local v0, "body":Lorg/json/JSONObject;
    const-string v3, "positions"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    if-eqz v3, :cond_9

    .line 342
    .local v3, "positions":Lorg/json/JSONArray;
    const-string v4, "available_dates"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    const/16 v8, 0xa

    if-eqz v4, :cond_3

    .line 388
    .local v4, "list\\3":Lorg/json/JSONArray;
    const/4 v9, 0x0

    .line 342
    .local v9, "$i$a$-let-LegacyStore$chart$dates$1\\3\\342\\0":I
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v10

    invoke-static {v6, v10}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v10

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$map\\4":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 471
    .local v11, "$i$f$map\\4\\342":I
    new-instance v12, Ljava/util/ArrayList;

    invoke-static {v10, v8}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v12, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\5":Ljava/util/Collection;
    move-object v13, v10

    .local v13, "$this$mapTo\\5":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 472
    .local v14, "$i$f$mapTo\\5\\471":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_0
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_2

    move-object/from16 v16, v15

    check-cast v16, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v16 .. v16}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v16

    .line 473
    .local v16, "item\\5":I
    move/from16 v17, v16

    .local v17, "it\\6":I
    const/16 v18, 0x0

    .line 342
    .local v18, "$i$a$-map-LegacyStore$chart$dates$1$1\\6\\473\\3":I
    move/from16 v8, v17

    .end local v17    # "it\\6":I
    .local v8, "it\\6":I
    invoke-virtual {v4, v8}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v8

    .line 473
    .end local v8    # "it\\6":I
    .end local v18    # "$i$a$-map-LegacyStore$chart$dates$1$1\\6\\473\\3":I
    invoke-interface {v12, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/16 v8, 0xa

    goto :goto_0

    .line 474
    .end local v16    # "item\\5":I
    :cond_2
    nop

    .end local v12    # "destination\\5":Ljava/util/Collection;
    .end local v13    # "$this$mapTo\\5":Ljava/lang/Iterable;
    .end local v14    # "$i$f$mapTo\\5\\471":I
    move-object v8, v12

    check-cast v8, Ljava/util/List;

    .line 471
    nop

    .line 342
    .end local v10    # "$this$map\\4":Ljava/lang/Iterable;
    .end local v11    # "$i$f$map\\4\\342":I
    nop

    .end local v4    # "list\\3":Lorg/json/JSONArray;
    .end local v9    # "$i$a$-let-LegacyStore$chart$dates$1\\3\\342\\0":I
    goto :goto_1

    :cond_3
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v8

    .line 343
    .local v8, "dates":Ljava/util/List;
    :goto_1
    const-string v4, "chart_type"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v9, "name"

    if-eqz v4, :cond_4

    invoke-virtual {v4, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_5

    :cond_4
    move-object v4, v1

    :cond_5
    const-string v10, "snapshot_date"

    invoke-virtual {v0, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "optString(...)"

    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 344
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v12

    invoke-static {v6, v12}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$mapNotNull\\7":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 475
    .local v12, "$i$f$mapNotNull\\7\\344":I
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    check-cast v13, Ljava/util/Collection;

    .local v13, "destination\\8":Ljava/util/Collection;
    move-object v14, v6

    .local v14, "$this$mapNotNullTo\\8":Ljava/lang/Iterable;
    const/4 v15, 0x0

    .line 483
    .local v15, "$i$f$mapNotNullTo\\8\\475":I
    move-object/from16 v16, v14

    .local v16, "$this$forEach\\9":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 484
    .local v17, "$i$f$forEach\\9\\483":I
    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_2
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_7

    move-object/from16 v20, v18

    check-cast v20, Lkotlin/collections/IntIterator;

    invoke-virtual/range {v20 .. v20}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v20

    .local v20, "element\\9":I
    move/from16 v21, v20

    .local v21, "element\\10":I
    const/16 v22, 0x0

    .line 483
    .local v22, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\10\\484\\8":I
    move/from16 v23, v21

    .local v23, "it\\12":I
    const/16 v24, 0x0

    .line 344
    .local v24, "$i$a$-mapNotNull-LegacyStore$chart$3\\12\\483\\0":I
    move-object/from16 v25, v0

    move/from16 v0, v23

    .end local v23    # "it\\12":I
    .local v0, "it\\12":I
    .local v25, "body":Lorg/json/JSONObject;
    invoke-virtual {v3, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    .line 483
    .end local v0    # "it\\12":I
    .end local v24    # "$i$a$-mapNotNull-LegacyStore$chart$3\\12\\483\\0":I
    if-eqz v0, :cond_6

    .line 485
    .local v0, "it\\10":Ljava/lang/Object;
    const/16 v23, 0x0

    .line 483
    .local v23, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\11\\485\\10":I
    invoke-interface {v13, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 484
    .end local v0    # "it\\10":Ljava/lang/Object;
    .end local v21    # "element\\10":I
    .end local v22    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\10\\484\\8":I
    .end local v23    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\11\\485\\10":I
    :cond_6
    move-object/from16 v0, v25

    .end local v20    # "element\\9":I
    goto :goto_2

    .line 486
    .end local v25    # "body":Lorg/json/JSONObject;
    .local v0, "body":Lorg/json/JSONObject;
    :cond_7
    move-object/from16 v25, v0

    .line 487
    .end local v0    # "body":Lorg/json/JSONObject;
    .end local v16    # "$this$forEach\\9":Ljava/lang/Iterable;
    .end local v17    # "$i$f$forEach\\9\\483":I
    .restart local v25    # "body":Lorg/json/JSONObject;
    nop

    .end local v13    # "destination\\8":Ljava/util/Collection;
    .end local v14    # "$this$mapNotNullTo\\8":Ljava/lang/Iterable;
    .end local v15    # "$i$f$mapNotNullTo\\8\\475":I
    move-object v0, v13

    check-cast v0, Ljava/util/List;

    .line 475
    nop

    .end local v6    # "$this$mapNotNull\\7":Ljava/lang/Iterable;
    .end local v12    # "$i$f$mapNotNull\\7\\344":I
    check-cast v0, Ljava/lang/Iterable;

    .line 344
    nop

    .local v0, "$this$map\\13":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 488
    .local v6, "$i$f$map\\13\\344":I
    new-instance v12, Ljava/util/ArrayList;

    const/16 v13, 0xa

    invoke-static {v0, v13}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v13

    invoke-direct {v12, v13}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\14":Ljava/util/Collection;
    move-object v13, v0

    .local v13, "$this$mapTo\\14":Ljava/lang/Iterable;
    const/4 v14, 0x0

    .line 489
    .local v14, "$i$f$mapTo\\14\\488":I
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_3
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_8

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .line 490
    .local v16, "item\\14":Ljava/lang/Object;
    move-object/from16 v17, v0

    .end local v0    # "$this$map\\13":Ljava/lang/Iterable;
    .local v17, "$this$map\\13":Ljava/lang/Iterable;
    move-object/from16 v0, v16

    check-cast v0, Lorg/json/JSONObject;

    .local v0, "it\\15":Lorg/json/JSONObject;
    const/16 v18, 0x0

    .line 345
    .local v18, "$i$a$-map-LegacyStore$chart$4\\15\\490\\0":I
    new-instance v1, Lorg/lighttouch/android/ChartRow;

    const-string v2, "position"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    move-object/from16 v19, v3

    .end local v3    # "positions":Lorg/json/JSONArray;
    .local v19, "positions":Lorg/json/JSONArray;
    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object/from16 v20, v5

    .end local v5    # "query":Ljava/util/Map;
    .local v20, "query":Ljava/util/Map;
    const-string v5, "developer"

    invoke-static {v0, v5}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move/from16 v21, v6

    .end local v6    # "$i$f$map\\13\\344":I
    .local v21, "$i$f$map\\13\\344":I
    const-string v6, "app"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    invoke-direct {v1, v2, v3, v5, v6}, Lorg/lighttouch/android/ChartRow;-><init>(ILjava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 490
    .end local v0    # "it\\15":Lorg/json/JSONObject;
    .end local v18    # "$i$a$-map-LegacyStore$chart$4\\15\\490\\0":I
    invoke-interface {v12, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v0, v17

    move-object/from16 v3, v19

    move-object/from16 v5, v20

    move/from16 v6, v21

    goto :goto_3

    .line 491
    .end local v16    # "item\\14":Ljava/lang/Object;
    .end local v17    # "$this$map\\13":Ljava/lang/Iterable;
    .end local v19    # "positions":Lorg/json/JSONArray;
    .end local v20    # "query":Ljava/util/Map;
    .end local v21    # "$i$f$map\\13\\344":I
    .local v0, "$this$map\\13":Ljava/lang/Iterable;
    .restart local v3    # "positions":Lorg/json/JSONArray;
    .restart local v5    # "query":Ljava/util/Map;
    .restart local v6    # "$i$f$map\\13\\344":I
    :cond_8
    move-object/from16 v17, v0

    .end local v0    # "$this$map\\13":Ljava/lang/Iterable;
    .end local v12    # "destination\\14":Ljava/util/Collection;
    .end local v13    # "$this$mapTo\\14":Ljava/lang/Iterable;
    .end local v14    # "$i$f$mapTo\\14\\488":I
    .restart local v17    # "$this$map\\13":Ljava/lang/Iterable;
    move-object v0, v12

    check-cast v0, Ljava/util/List;

    .line 488
    nop

    .line 343
    .end local v6    # "$i$f$map\\13\\344":I
    .end local v17    # "$this$map\\13":Ljava/lang/Iterable;
    new-instance v1, Lorg/lighttouch/android/StoreChart;

    invoke-direct {v1, v4, v10, v8, v0}, Lorg/lighttouch/android/StoreChart;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    return-object v1

    .line 341
    .end local v3    # "positions":Lorg/json/JSONArray;
    .end local v8    # "dates":Ljava/util/List;
    .end local v25    # "body":Lorg/json/JSONObject;
    .local v0, "body":Lorg/json/JSONObject;
    :cond_9
    move-object/from16 v25, v0

    .end local v0    # "body":Lorg/json/JSONObject;
    .restart local v25    # "body":Lorg/json/JSONObject;
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u6392\u884c\u699c\u3002"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v6, v4, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0

    .line 337
    .end local v25    # "body":Lorg/json/JSONObject;
    :catch_0
    move-exception v0

    goto :goto_4

    :catch_1
    move-exception v0

    move-object/from16 v7, p0

    :goto_4
    move-object/from16 v20, v5

    .line 339
    .end local v5    # "query":Ljava/util/Map;
    .local v0, "e":Lorg/lighttouch/android/StoreError;
    .restart local v20    # "query":Ljava/util/Map;
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreError;->getStatus()I

    move-result v1

    const/16 v2, 0x194

    if-ne v1, v2, :cond_a

    new-instance v1, Lorg/lighttouch/android/StoreError;

    const-string v3, "\u6b64\u9009\u62e9\u6ca1\u6709\u5b58\u6863\u7684\u6392\u884c\u699c\u3002"

    invoke-direct {v1, v3, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;I)V

    check-cast v1, Ljava/lang/Throwable;

    goto :goto_5

    :cond_a
    move-object v1, v0

    check-cast v1, Ljava/lang/Throwable;

    :goto_5
    throw v1
.end method

.method public final checkCopy(Lorg/json/JSONObject;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;)V
    .locals 18
    .param p1, "copy"    # Lorg/json/JSONObject;
    .param p2, "app"    # Lorg/json/JSONObject;
    .param p3, "target"    # Lorg/lighttouch/android/StoreTarget;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    const-string v4, "copy"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "app"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "target"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    const-string v4, "ipa_id"

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v4, :cond_12

    const-string v4, "bundle_id"

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v8, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_12

    .line 229
    const-string v4, "available"

    invoke-virtual {v1, v4, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_11

    .line 230
    const-string v4, "binary"

    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    if-eqz v4, :cond_10

    .line 231
    .local v4, "binary":Lorg/json/JSONObject;
    const-string v8, "install_status"

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "installable"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_f

    .line 232
    const-string v8, "architectures"

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    invoke-direct {v0, v8, v3}, Lorg/lighttouch/android/LegacyStore;->runs(Lorg/json/JSONArray;Lorg/lighttouch/android/StoreTarget;)Z

    move-result v8

    if-eqz v8, :cond_e

    invoke-virtual {v3}, Lorg/lighttouch/android/StoreTarget;->getArch()Ljava/lang/String;

    move-result-object v8

    const-string v9, "armv6"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    const-string v8, "armv7_code"

    invoke-virtual {v4, v8, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v8

    if-nez v8, :cond_0

    goto :goto_0

    :cond_0
    move v9, v6

    const/4 v11, 0x0

    goto/16 :goto_8

    .line 234
    :cond_1
    :goto_0
    const-string v8, "device_family_macho"

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    if-eqz v8, :cond_7

    .local v8, "families\\1":Lorg/json/JSONArray;
    const/4 v10, 0x0

    .line 235
    .local v10, "$i$a$-let-LegacyStore$checkCopy$1\\1\\234\\0":I
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v11

    if-lez v11, :cond_6

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v11

    invoke-static {v7, v11}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v11

    check-cast v11, Ljava/lang/Iterable;

    .local v11, "$this$none\\2":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 404
    .local v12, "$i$f$none\\2\\235":I
    instance-of v13, v11, Ljava/util/Collection;

    if-eqz v13, :cond_2

    move-object v13, v11

    check-cast v13, Ljava/util/Collection;

    invoke-interface {v13}, Ljava/util/Collection;->isEmpty()Z

    move-result v13

    if-eqz v13, :cond_2

    const/4 v9, 0x1

    const/16 v17, 0x1

    goto :goto_1

    .line 405
    :cond_2
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_3
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_4

    move-object v14, v13

    check-cast v14, Lkotlin/collections/IntIterator;

    invoke-virtual {v14}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v14

    .local v14, "element\\2":I
    move v15, v14

    .local v15, "it\\3":I
    const/16 v16, 0x0

    .line 235
    .local v16, "$i$a$-none-LegacyStore$checkCopy$1$1\\3\\405\\1":I
    const/16 v17, 0x1

    invoke-virtual {v8, v15}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3}, Lorg/lighttouch/android/StoreTarget;->getFamily()Ljava/lang/String;

    move-result-object v5

    invoke-static {v9, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    .line 405
    .end local v15    # "it\\3":I
    .end local v16    # "$i$a$-none-LegacyStore$checkCopy$1$1\\3\\405\\1":I
    if-eqz v5, :cond_3

    move v9, v7

    goto :goto_1

    .line 406
    .end local v14    # "element\\2":I
    :cond_4
    const/16 v17, 0x1

    move/from16 v9, v17

    .line 235
    .end local v11    # "$this$none\\2":Ljava/lang/Iterable;
    .end local v12    # "$i$f$none\\2\\235":I
    :goto_1
    if-nez v9, :cond_5

    goto :goto_2

    .line 236
    :cond_5
    new-instance v5, Lorg/lighttouch/android/StoreError;

    const-string v9, "\u6b64\u526f\u672c\u5e76\u975e\u4e3a\u8be5\u8bbe\u5907\u5236\u4f5c\u3002"

    const/4 v11, 0x0

    invoke-direct {v5, v9, v7, v6, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v5

    .line 235
    :cond_6
    const/16 v17, 0x1

    .line 237
    :goto_2
    nop

    .end local v8    # "families\\1":Lorg/json/JSONArray;
    .end local v10    # "$i$a$-let-LegacyStore$checkCopy$1\\1\\234\\0":I
    goto :goto_3

    .line 234
    :cond_7
    const/16 v17, 0x1

    :goto_3
    nop

    .line 238
    new-array v5, v6, [Ljava/lang/String;

    const-string v8, "min_os"

    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v5, v7

    const-string v8, "macho_min_os"

    invoke-virtual {v4, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v5, v17

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/lang/Iterable;

    .local v5, "$this$filter\\4":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 407
    .local v8, "$i$f$filter\\4\\238":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination\\5":Ljava/util/Collection;
    move-object v10, v5

    .local v10, "$this$filterTo\\5":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 408
    .local v11, "$i$f$filterTo\\5\\407":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_4
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_b

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "element\\5":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Ljava/lang/String;

    .local v14, "it\\6":Ljava/lang/String;
    const/4 v15, 0x0

    .line 238
    .local v15, "$i$a$-filter-LegacyStore$checkCopy$2\\6\\408\\0":I
    invoke-static {v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object/from16 v16, v14

    check-cast v16, Ljava/lang/CharSequence;

    invoke-interface/range {v16 .. v16}, Ljava/lang/CharSequence;->length()I

    move-result v16

    if-lez v16, :cond_8

    move/from16 v16, v17

    goto :goto_5

    :cond_8
    move/from16 v16, v7

    :goto_5
    if-eqz v16, :cond_9

    const-string v6, "null"

    invoke-static {v14, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_9

    move/from16 v6, v17

    goto :goto_6

    :cond_9
    move v6, v7

    .line 408
    .end local v14    # "it\\6":Ljava/lang/String;
    .end local v15    # "$i$a$-filter-LegacyStore$checkCopy$2\\6\\408\\0":I
    :goto_6
    if-eqz v6, :cond_a

    invoke-interface {v9, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_a
    const/4 v6, 0x2

    goto :goto_4

    .line 409
    .end local v13    # "element\\5":Ljava/lang/Object;
    :cond_b
    nop

    .end local v9    # "destination\\5":Ljava/util/Collection;
    .end local v10    # "$this$filterTo\\5":Ljava/lang/Iterable;
    .end local v11    # "$i$f$filterTo\\5\\407":I
    move-object v6, v9

    check-cast v6, Ljava/util/List;

    .line 407
    nop

    .line 238
    .end local v5    # "$this$filter\\4":Ljava/lang/Iterable;
    .end local v8    # "$i$f$filter\\4\\238":I
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_7
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_d

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 239
    .local v6, "minimum":Ljava/lang/String;
    invoke-direct {v0, v6, v3}, Lorg/lighttouch/android/LegacyStore;->requires(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Z

    move-result v8

    if-nez v8, :cond_c

    goto :goto_7

    :cond_c
    new-instance v5, Lorg/lighttouch/android/StoreError;

    invoke-virtual {v3}, Lorg/lighttouch/android/StoreTarget;->getIos()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "\u9700\u8981 iOS "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "; this device runs iOS "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "."

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x2

    const/4 v11, 0x0

    invoke-direct {v5, v8, v7, v9, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v5

    .line 240
    .end local v6    # "minimum":Ljava/lang/String;
    :cond_d
    return-void

    .line 232
    :cond_e
    move v9, v6

    const/4 v11, 0x0

    .line 233
    :goto_8
    new-instance v5, Lorg/lighttouch/android/StoreError;

    const-string v6, "\u6b64\u526f\u672c\u9700\u8981\u6bd4\u8be5\u8bbe\u5907\u66f4\u65b0\u7684\u5904\u7406\u5668\u3002"

    invoke-direct {v5, v6, v7, v9, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v5

    .line 231
    :cond_f
    move v9, v6

    const/4 v11, 0x0

    new-instance v5, Lorg/lighttouch/android/StoreError;

    const-string v6, "\u6b64\u526f\u672c\u5df2\u52a0\u5bc6\uff0c\u6216\u5c1a\u672a\u88ab\u5224\u5b9a\u4e3a\u53ef\u5b89\u88c5\u3002"

    invoke-direct {v5, v6, v7, v9, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v5

    .line 230
    .end local v4    # "binary":Lorg/json/JSONObject;
    :cond_10
    move v9, v6

    const/4 v11, 0x0

    new-instance v4, Lorg/lighttouch/android/StoreError;

    const-string v5, "\u6b64\u526f\u672c\u5c1a\u672a\u505a\u517c\u5bb9\u6027\u5206\u6790\u3002"

    invoke-direct {v4, v5, v7, v9, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4

    .line 229
    :cond_11
    move v9, v6

    const/4 v11, 0x0

    new-instance v4, Lorg/lighttouch/android/StoreError;

    const-string v5, "\u6b64\u5b58\u6863\u4e0b\u8f7d\u5df2\u4e0d\u53ef\u7528\u3002"

    invoke-direct {v4, v5, v7, v9, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4

    .line 227
    :cond_12
    move v9, v6

    const/4 v11, 0x0

    .line 228
    new-instance v4, Lorg/lighttouch/android/StoreError;

    const-string v5, "\u5b58\u6863\u526f\u672c\u5df2\u4e0e\u6b64\u5e94\u7528\u4e0d\u5339\u914d\u3002"

    invoke-direct {v4, v5, v7, v9, v11}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4
.end method

.method public final collection(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 21
    .param p1, "slug"    # Ljava/lang/String;

    move-object/from16 v0, p1

    const-string v1, "slug"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 323
    const-string v1, "UTF-8"

    invoke-static {v0, v1}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/api/v1/collections/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object/from16 v2, p0

    invoke-static/range {v2 .. v7}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "members"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_8

    .line 325
    .local v1, "members":Lorg/json/JSONArray;
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v4

    invoke-static {v2, v4}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 455
    .local v4, "$i$f$mapNotNull\\1\\325":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\2":Ljava/util/Collection;
    move-object v6, v2

    .local v6, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 463
    .local v7, "$i$f$mapNotNullTo\\2\\455":I
    move-object v8, v6

    .local v8, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 464
    .local v9, "$i$f$forEach\\3\\463":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_1

    move-object v11, v10

    check-cast v11, Lkotlin/collections/IntIterator;

    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v11

    .local v11, "element\\3":I
    move v12, v11

    .local v12, "element\\4":I
    const/4 v13, 0x0

    .line 463
    .local v13, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\464\\2":I
    move v14, v12

    .local v14, "it\\6":I
    const/4 v15, 0x0

    .line 325
    .local v15, "$i$a$-mapNotNull-LegacyStore$collection$apps$1\\6\\463\\0":I
    invoke-virtual {v1, v14}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v14

    .line 463
    .end local v14    # "it\\6":I
    .end local v15    # "$i$a$-mapNotNull-LegacyStore$collection$apps$1\\6\\463\\0":I
    if-eqz v14, :cond_0

    .line 465
    .local v14, "it\\4":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 463
    .local v15, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\465\\4":I
    invoke-interface {v5, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 464
    .end local v12    # "element\\4":I
    .end local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\464\\2":I
    .end local v14    # "it\\4":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\465\\4":I
    :cond_0
    nop

    .end local v11    # "element\\3":I
    goto :goto_0

    .line 466
    :cond_1
    nop

    .line 467
    .end local v8    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v9    # "$i$f$forEach\\3\\463":I
    nop

    .end local v5    # "destination\\2":Ljava/util/Collection;
    .end local v6    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v7    # "$i$f$mapNotNullTo\\2\\455":I
    check-cast v5, Ljava/util/List;

    .line 455
    nop

    .end local v2    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapNotNull\\1\\325":I
    check-cast v5, Ljava/lang/Iterable;

    .line 325
    nop

    .local v5, "$this$mapNotNull\\7":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 455
    .local v2, "$i$f$mapNotNull\\7\\325":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\8":Ljava/util/Collection;
    move-object v6, v5

    .local v6, "$this$mapNotNullTo\\8":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 463
    .local v7, "$i$f$mapNotNullTo\\8\\455":I
    move-object v8, v6

    .local v8, "$this$forEach\\9":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 468
    .local v9, "$i$f$forEach\\9\\463":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_7

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element\\9":Ljava/lang/Object;
    move-object v12, v11

    .local v12, "element\\10":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 463
    .local v13, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\10\\468\\8":I
    move-object v14, v12

    check-cast v14, Lorg/json/JSONObject;

    .local v14, "member\\12":Lorg/json/JSONObject;
    const/4 v15, 0x0

    .line 327
    .local v15, "$i$a$-mapNotNull-LegacyStore$collection$apps$2\\12\\463\\0":I
    const-string v3, "app"

    invoke-virtual {v14, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v0, "label"

    if-eqz v3, :cond_3

    move-object/from16 v16, v3

    .line 388
    .local v16, "app\\13":Lorg/json/JSONObject;
    const/16 v17, 0x0

    .line 327
    .local v17, "$i$a$-also-LegacyStore$collection$apps$2$1\\13\\327\\12":I
    invoke-static {v14, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    if-eqz v18, :cond_2

    move-object/from16 v19, v18

    .line 388
    .local v19, "it\\14":Ljava/lang/String;
    const/16 v18, 0x0

    .line 327
    .local v18, "$i$a$-let-LegacyStore$collection$apps$2$1$1\\14\\327\\13":I
    move-object/from16 v20, v1

    move-object/from16 v1, v16

    move/from16 v16, v2

    move-object/from16 v2, v19

    .end local v19    # "it\\14":Ljava/lang/String;
    .local v1, "app\\13":Lorg/json/JSONObject;
    .local v2, "it\\14":Ljava/lang/String;
    .local v16, "$i$f$mapNotNull\\7\\325":I
    .local v20, "members":Lorg/json/JSONArray;
    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .end local v2    # "it\\14":Ljava/lang/String;
    .end local v18    # "$i$a$-let-LegacyStore$collection$apps$2$1$1\\14\\327\\13":I
    goto :goto_2

    .end local v20    # "members":Lorg/json/JSONArray;
    .local v1, "members":Lorg/json/JSONArray;
    .local v2, "$i$f$mapNotNull\\7\\325":I
    .local v16, "app\\13":Lorg/json/JSONObject;
    :cond_2
    move-object/from16 v20, v1

    move-object/from16 v1, v16

    move/from16 v16, v2

    .end local v1    # "members":Lorg/json/JSONArray;
    .end local v2    # "$i$f$mapNotNull\\7\\325":I
    .end local v17    # "$i$a$-also-LegacyStore$collection$apps$2$1\\13\\327\\12":I
    .local v16, "$i$f$mapNotNull\\7\\325":I
    .restart local v20    # "members":Lorg/json/JSONArray;
    :goto_2
    if-nez v3, :cond_5

    goto :goto_3

    .end local v16    # "$i$f$mapNotNull\\7\\325":I
    .end local v20    # "members":Lorg/json/JSONArray;
    .restart local v1    # "members":Lorg/json/JSONArray;
    .restart local v2    # "$i$f$mapNotNull\\7\\325":I
    :cond_3
    move-object/from16 v20, v1

    move/from16 v16, v2

    .line 328
    .end local v1    # "members":Lorg/json/JSONArray;
    .end local v2    # "$i$f$mapNotNull\\7\\325":I
    .restart local v16    # "$i$f$mapNotNull\\7\\325":I
    .restart local v20    # "members":Lorg/json/JSONArray;
    :goto_3
    invoke-static {v14, v0}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 388
    .local v0, "it\\15":Ljava/lang/String;
    const/4 v1, 0x0

    .line 328
    .local v1, "$i$a$-let-LegacyStore$collection$apps$2$2\\15\\328\\12":I
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "name"

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "ghost"

    move-object/from16 v17, v0

    .end local v0    # "it\\15":Ljava/lang/String;
    .local v17, "it\\15":Ljava/lang/String;
    const/4 v0, 0x1

    invoke-virtual {v2, v3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v3

    .end local v1    # "$i$a$-let-LegacyStore$collection$apps$2$2\\15\\328\\12":I
    .end local v17    # "it\\15":Ljava/lang/String;
    goto :goto_4

    :cond_4
    const/4 v3, 0x0

    .line 463
    .end local v14    # "member\\12":Lorg/json/JSONObject;
    .end local v15    # "$i$a$-mapNotNull-LegacyStore$collection$apps$2\\12\\463\\0":I
    :cond_5
    :goto_4
    if-eqz v3, :cond_6

    .line 465
    .local v3, "it\\10":Ljava/lang/Object;
    const/4 v0, 0x0

    .line 463
    .local v0, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\11\\465\\10":I
    invoke-interface {v4, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 468
    .end local v0    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\11\\465\\10":I
    .end local v3    # "it\\10":Ljava/lang/Object;
    .end local v12    # "element\\10":Ljava/lang/Object;
    .end local v13    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\10\\468\\8":I
    :cond_6
    move-object/from16 v0, p1

    move/from16 v2, v16

    move-object/from16 v1, v20

    .end local v11    # "element\\9":Ljava/lang/Object;
    goto :goto_1

    .line 469
    .end local v16    # "$i$f$mapNotNull\\7\\325":I
    .end local v20    # "members":Lorg/json/JSONArray;
    .local v1, "members":Lorg/json/JSONArray;
    .restart local v2    # "$i$f$mapNotNull\\7\\325":I
    :cond_7
    move-object/from16 v20, v1

    move/from16 v16, v2

    .line 470
    .end local v1    # "members":Lorg/json/JSONArray;
    .end local v2    # "$i$f$mapNotNull\\7\\325":I
    .end local v8    # "$this$forEach\\9":Ljava/lang/Iterable;
    .end local v9    # "$i$f$forEach\\9\\463":I
    .restart local v16    # "$i$f$mapNotNull\\7\\325":I
    .restart local v20    # "members":Lorg/json/JSONArray;
    nop

    .end local v4    # "destination\\8":Ljava/util/Collection;
    .end local v6    # "$this$mapNotNullTo\\8":Ljava/lang/Iterable;
    .end local v7    # "$i$f$mapNotNullTo\\8\\455":I
    move-object v0, v4

    check-cast v0, Ljava/util/List;

    .line 455
    nop

    .line 325
    .end local v5    # "$this$mapNotNull\\7":Ljava/lang/Iterable;
    .end local v16    # "$i$f$mapNotNull\\7\\325":I
    nop

    .line 330
    .local v0, "apps":Ljava/util/List;
    new-instance v1, Lorg/lighttouch/android/StorePage;

    new-instance v2, Lorg/json/JSONArray;

    move-object v3, v0

    check-cast v3, Ljava/util/Collection;

    invoke-direct {v2, v3}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    const-string v3, "collection"

    move-object/from16 v4, p0

    invoke-direct {v4, v2, v3}, Lorg/lighttouch/android/LegacyStore;->rows(Lorg/json/JSONArray;Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v5, 0x0

    invoke-direct {v1, v2, v3, v5}, Lorg/lighttouch/android/StorePage;-><init>(Ljava/util/List;ILjava/lang/String;)V

    return-object v1

    .line 324
    .end local v0    # "apps":Ljava/util/List;
    .end local v20    # "members":Lorg/json/JSONArray;
    :cond_8
    const/4 v5, 0x0

    move-object/from16 v4, p0

    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u5408\u96c6\u3002"

    const/4 v3, 0x2

    invoke-direct {v0, v1, v2, v3, v5}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final collections()Ljava/util/List;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCollection;",
            ">;"
        }
    .end annotation

    .line 315
    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "/api/v1/collections"

    const/4 v2, 0x0

    const/4 v3, 0x1

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v5}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v0, "data"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_9

    .line 316
    .local v0, "data":Lorg/json/JSONArray;
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 435
    .local v3, "$i$f$mapNotNull\\1\\316":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 443
    .local v6, "$i$f$mapNotNullTo\\2\\435":I
    move-object v7, v5

    .local v7, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 444
    .local v8, "$i$f$forEach\\3\\443":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_1

    move-object v10, v9

    check-cast v10, Lkotlin/collections/IntIterator;

    invoke-virtual {v10}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v10

    .local v10, "element\\3":I
    move v11, v10

    .local v11, "element\\4":I
    const/4 v12, 0x0

    .line 443
    .local v12, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\444\\2":I
    move v13, v11

    .local v13, "it\\6":I
    const/4 v14, 0x0

    .line 316
    .local v14, "$i$a$-mapNotNull-LegacyStore$collections$1\\6\\443\\0":I
    invoke-virtual {v0, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    .line 443
    .end local v13    # "it\\6":I
    .end local v14    # "$i$a$-mapNotNull-LegacyStore$collections$1\\6\\443\\0":I
    if-eqz v13, :cond_0

    .line 445
    .local v13, "it\\4":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 443
    .local v14, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\445\\4":I
    invoke-interface {v4, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 444
    .end local v11    # "element\\4":I
    .end local v12    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\444\\2":I
    .end local v13    # "it\\4":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\445\\4":I
    :cond_0
    nop

    .end local v10    # "element\\3":I
    goto :goto_0

    .line 446
    :cond_1
    nop

    .line 447
    .end local v7    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\3\\443":I
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapNotNullTo\\2\\435":I
    check-cast v4, Ljava/util/List;

    .line 435
    nop

    .end local v2    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\1\\316":I
    check-cast v4, Ljava/lang/Iterable;

    .line 317
    nop

    .local v4, "$this$map\\7":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 448
    .local v2, "$i$f$map\\7\\317":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v4, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\8":Ljava/util/Collection;
    move-object v5, v4

    .local v5, "$this$mapTo\\8":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 449
    .local v6, "$i$f$mapTo\\8\\448":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 450
    .local v8, "item\\8":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/json/JSONObject;

    .local v9, "it\\9":Lorg/json/JSONObject;
    const/4 v10, 0x0

    .line 317
    .local v10, "$i$a$-map-LegacyStore$collections$2\\9\\450\\0":I
    new-instance v11, Lorg/lighttouch/android/StoreCollection;

    const-string v12, "slug"

    invoke-virtual {v9, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "optString(...)"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "title"

    invoke-virtual {v9, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v13, "subtitle"

    invoke-static {v9, v13}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_2

    const-string v13, "series"

    invoke-static {v9, v13}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    :cond_2
    const-string v15, "app_count"

    invoke-virtual {v9, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v15

    invoke-direct {v11, v12, v14, v13, v15}, Lorg/lighttouch/android/StoreCollection;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    .line 450
    .end local v9    # "it\\9":Lorg/json/JSONObject;
    .end local v10    # "$i$a$-map-LegacyStore$collections$2\\9\\450\\0":I
    invoke-interface {v3, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 451
    .end local v8    # "item\\8":Ljava/lang/Object;
    :cond_3
    nop

    .end local v3    # "destination\\8":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\8":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\8\\448":I
    check-cast v3, Ljava/util/List;

    .line 448
    nop

    .end local v2    # "$i$f$map\\7\\317":I
    .end local v4    # "$this$map\\7":Ljava/lang/Iterable;
    check-cast v3, Ljava/lang/Iterable;

    .line 318
    nop

    .local v3, "$this$filter\\10":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 452
    .local v2, "$i$f$filter\\10\\318":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\11":Ljava/util/Collection;
    move-object v5, v3

    .local v5, "$this$filterTo\\11":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 453
    .local v6, "$i$f$filterTo\\11\\452":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_4
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_8

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\11":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/StoreCollection;

    .local v9, "it\\12":Lorg/lighttouch/android/StoreCollection;
    const/4 v10, 0x0

    .line 318
    .local v10, "$i$a$-filter-LegacyStore$collections$3\\12\\453\\0":I
    invoke-virtual {v9}, Lorg/lighttouch/android/StoreCollection;->getSlug()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    const/4 v12, 0x1

    if-lez v11, :cond_5

    move v11, v12

    goto :goto_3

    :cond_5
    move v11, v1

    :goto_3
    if-eqz v11, :cond_7

    invoke-virtual {v9}, Lorg/lighttouch/android/StoreCollection;->getTitle()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-lez v11, :cond_6

    move v11, v12

    goto :goto_4

    :cond_6
    move v11, v1

    :goto_4
    if-eqz v11, :cond_7

    goto :goto_5

    :cond_7
    move v12, v1

    .line 453
    .end local v9    # "it\\12":Lorg/lighttouch/android/StoreCollection;
    .end local v10    # "$i$a$-filter-LegacyStore$collections$3\\12\\453\\0":I
    :goto_5
    if-eqz v12, :cond_4

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 454
    .end local v8    # "element\\11":Ljava/lang/Object;
    :cond_8
    nop

    .end local v4    # "destination\\11":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\11":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo\\11\\452":I
    move-object v1, v4

    check-cast v1, Ljava/util/List;

    .line 452
    nop

    .line 316
    .end local v2    # "$i$f$filter\\10\\318":I
    .end local v3    # "$this$filter\\10":Ljava/lang/Iterable;
    return-object v1

    .line 315
    .end local v0    # "data":Lorg/json/JSONArray;
    :cond_9
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v4, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u5408\u96c6\u5217\u8868\u3002"

    invoke-direct {v0, v4, v1, v2, v3}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final compatibleCopy(ILorg/lighttouch/android/StoreTarget;)Lorg/json/JSONObject;
    .locals 7
    .param p1, "ipaId"    # I
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;

    const-string v0, "target"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 154
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "ipa_id"

    invoke-static {v1, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf(Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    invoke-direct {p0, v0, p2}, Lorg/lighttouch/android/LegacyStore;->apps(Ljava/util/Map;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;

    move-result-object v0

    .line 155
    .local v0, "found":Ljava/util/List;
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ne v2, v3, :cond_1

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/json/JSONObject;

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    if-ne v1, p1, :cond_1

    .line 156
    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONObject;

    invoke-virtual {p0, v1}, Lorg/lighttouch/android/LegacyStore;->incompatibility(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    .line 157
    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONObject;

    return-object v1

    .line 388
    .local v1, "it\\1":Ljava/lang/String;
    :cond_0
    const/4 v2, 0x0

    .line 156
    .local v2, "$i$a$-let-LegacyStore$compatibleCopy$1\\1\\156\\0":I
    new-instance v3, Lorg/lighttouch/android/StoreError;

    invoke-direct {v3, v1, v6, v5, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v3

    .line 155
    .end local v1    # "it\\1":Ljava/lang/String;
    .end local v2    # "$i$a$-let-LegacyStore$compatibleCopy$1\\1\\156\\0":I
    :cond_1
    new-instance v1, Lorg/lighttouch/android/StoreError;

    const-string v2, "\u6b64\u526f\u672c\u5df2\u4e0d\u53ef\u7528\u3002"

    invoke-direct {v1, v2, v6, v5, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v1
.end method

.method public final copyDetails(I)Lorg/json/JSONObject;
    .locals 7
    .param p1, "ipaId"    # I

    .line 161
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "/api/v1/copies/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v1, p0

    invoke-static/range {v1 .. v6}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    .line 162
    .local v0, "copy":Lorg/json/JSONObject;
    const-string v1, "ipa_id"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 163
    return-object v0

    .line 162
    :cond_0
    new-instance v1, Lorg/lighttouch/android/StoreError;

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v4, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u4e0d\u540c\u7684\u5b58\u6863\u526f\u672c\u3002"

    const/4 v5, 0x0

    invoke-direct {v1, v4, v5, v2, v3}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v1
.end method

.method public final download(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;Ljava/io/File;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;)Ljava/io/File;
    .locals 34
    .param p1, "app"    # Lorg/json/JSONObject;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;
    .param p3, "scratch"    # Ljava/io/File;
    .param p4, "progress"    # Lkotlin/jvm/functions/Function2;
    .param p5, "cancelled"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            "Lorg/lighttouch/android/StoreTarget;",
            "Ljava/io/File;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Ljava/lang/Long;",
            "-",
            "Ljava/lang/Long;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/io/File;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    const-string v0, "app"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "scratch"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "progress"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "cancelled"

    move-object/from16 v6, p5

    invoke-static {v6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 244
    const-string v0, "ipa_id"

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v1, v7, v3}, Lorg/lighttouch/android/LegacyStore;->compatibleCopy(ILorg/lighttouch/android/StoreTarget;)Lorg/json/JSONObject;

    move-result-object v7

    .line 245
    .local v7, "current":Lorg/json/JSONObject;
    const-string v8, "bundle_id"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v9, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v8, :cond_13

    .line 246
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v1, v8}, Lorg/lighttouch/android/LegacyStore;->copyDetails(I)Lorg/json/JSONObject;

    move-result-object v8

    .line 247
    .local v8, "details":Lorg/json/JSONObject;
    invoke-virtual {v1, v8, v7, v3}, Lorg/lighttouch/android/LegacyStore;->checkCopy(Lorg/json/JSONObject;Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;)V

    .line 248
    const-string v12, "md5"

    invoke-virtual {v8, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object v13, v12

    .line 388
    .local v13, "it\\1":Ljava/lang/String;
    const/4 v14, 0x0

    .line 248
    .local v14, "$i$a$-takeIf-LegacyStore$download$checksum$1\\1\\248\\0":I
    invoke-static {v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v15, v13

    check-cast v15, Ljava/lang/CharSequence;

    invoke-interface {v15}, Ljava/lang/CharSequence;->length()I

    move-result v15

    const/16 v16, 0x1

    if-lez v15, :cond_0

    move/from16 v15, v16

    goto :goto_0

    :cond_0
    move v15, v11

    :goto_0
    if-eqz v15, :cond_1

    const-string v15, "null"

    invoke-static {v13, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_1

    move/from16 v13, v16

    goto :goto_1

    :cond_1
    move v13, v11

    .end local v13    # "it\\1":Ljava/lang/String;
    .end local v14    # "$i$a$-takeIf-LegacyStore$download$checksum$1\\1\\248\\0":I
    :goto_1
    if-eqz v13, :cond_2

    goto :goto_2

    :cond_2
    move-object v12, v10

    .line 249
    .local v12, "checksum":Ljava/lang/String;
    :goto_2
    if-eqz v12, :cond_4

    new-instance v13, Lkotlin/text/Regex;

    const-string v14, "[0-9a-fA-F]{32}"

    invoke-direct {v13, v14}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    move-object v14, v12

    check-cast v14, Ljava/lang/CharSequence;

    invoke-virtual {v13, v14}, Lkotlin/text/Regex;->matches(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_3

    goto :goto_3

    :cond_3
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v13, "\u5b58\u6863\u63d0\u4f9b\u7684\u6587\u4ef6\u6821\u9a8c\u548c\u65e0\u6548\u3002"

    invoke-direct {v0, v13, v11, v9, v10}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0

    .line 250
    :cond_4
    :goto_3
    const-string v13, "size"

    invoke-virtual {v8, v13}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_5

    move-object v13, v10

    goto :goto_5

    :cond_5
    invoke-virtual {v8, v13}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v13

    move-object v14, v13

    check-cast v14, Ljava/lang/Number;

    invoke-virtual {v14}, Ljava/lang/Number;->longValue()J

    move-result-wide v14

    .local v14, "it\\2":J
    const/16 v17, 0x0

    .line 251
    .local v17, "$i$a$-also-LegacyStore$download$size$1\\2\\250\\0":I
    const-wide/16 v18, 0x1

    cmp-long v18, v18, v14

    if-gtz v18, :cond_6

    const-wide v18, 0x80000001L

    cmp-long v18, v14, v18

    if-gez v18, :cond_6

    goto :goto_4

    :cond_6
    move/from16 v16, v11

    :goto_4
    if-eqz v16, :cond_12

    .line 252
    nop

    .line 250
    .end local v14    # "it\\2":J
    .end local v17    # "$i$a$-also-LegacyStore$download$size$1\\2\\250\\0":I
    nop

    .line 253
    .local v13, "size":Ljava/lang/Long;
    :goto_5
    new-instance v14, Ljava/io/File;

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v9

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "catalog-"

    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v11, "-"

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v14, v4, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 254
    .local v14, "directory":Ljava/io/File;
    invoke-virtual {v14}, Ljava/io/File;->mkdirs()Z

    move-result v0

    if-eqz v0, :cond_11

    .line 255
    new-instance v0, Ljava/io/File;

    const-string v9, "download.partial"

    invoke-direct {v0, v14, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v9, v0

    .local v9, "partial":Ljava/io/File;
    new-instance v0, Ljava/io/File;

    const-string v10, "App.ipa"

    invoke-direct {v0, v14, v10}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v10, v0

    .line 256
    .local v10, "final":Ljava/io/File;
    nop

    .line 257
    :try_start_0
    const-string v0, "download_url"

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v11, "optString(...)"

    invoke-static {v0, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v1, v0}, Lorg/lighttouch/android/LegacyStore;->open(Ljava/lang/String;)Ljava/net/HttpURLConnection;

    move-result-object v0

    move-object v11, v0

    .line 258
    .local v11, "connection":Ljava/net/HttpURLConnection;
    const-string v0, "MD5"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-object v15, v0

    .line 259
    .local v15, "digest":Ljava/security/MessageDigest;
    const-wide/16 v20, 0x0

    .line 260
    .local v20, "count":J
    nop

    .line 261
    :try_start_1
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_8

    :try_start_2
    move-object v0, v1

    check-cast v0, Ljava/io/InputStream;

    move-object/from16 v17, v0

    .line 388
    .local v17, "input\\3":Ljava/io/InputStream;
    const/16 v22, 0x0

    .local v22, "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    new-instance v0, Ljava/io/FileOutputStream;

    .line 261
    invoke-direct {v0, v9}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    :try_start_3
    move-object v0, v2

    check-cast v0, Ljava/io/FileOutputStream;

    .local v0, "output\\4":Ljava/io/FileOutputStream;
    const/16 v23, 0x0

    .line 262
    .local v23, "$i$a$-use-LegacyStore$download$1$1\\4\\261\\3":I
    const/high16 v3, 0x10000

    new-array v3, v3, [B

    .line 263
    .local v3, "buffer\\4":[B
    :goto_6
    nop

    .line 264
    invoke-interface {v6}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v24

    check-cast v24, Ljava/lang/Boolean;

    invoke-virtual/range {v24 .. v24}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v24
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-nez v24, :cond_f

    .line 265
    move-object/from16 v4, v17

    .end local v17    # "input\\3":Ljava/io/InputStream;
    .local v4, "input\\3":Ljava/io/InputStream;
    :try_start_4
    invoke-virtual {v4, v3}, Ljava/io/InputStream;->read([B)I

    move-result v17
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    move/from16 v24, v17

    .line 266
    .local v24, "read\\4":I
    if-ltz v24, :cond_9

    .line 267
    move-object/from16 v17, v4

    move/from16 v4, v24

    move-object/from16 v24, v7

    .end local v7    # "current":Lorg/json/JSONObject;
    .local v4, "read\\4":I
    .restart local v17    # "input\\3":Ljava/io/InputStream;
    .local v24, "current":Lorg/json/JSONObject;
    int-to-long v6, v4

    add-long v20, v20, v6

    .line 268
    const-wide v6, 0x80000000L

    cmp-long v6, v20, v6

    if-gtz v6, :cond_8

    if-eqz v13, :cond_7

    :try_start_5
    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    cmp-long v6, v20, v6

    if-gtz v6, :cond_8

    .line 269
    :cond_7
    const/4 v6, 0x0

    invoke-virtual {v0, v3, v6, v4}, Ljava/io/FileOutputStream;->write([BII)V

    invoke-virtual {v15, v3, v6, v4}, Ljava/security/MessageDigest;->update([BII)V

    .line 270
    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v5, v6, v13}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v4, p3

    move-object/from16 v6, p5

    move-object/from16 v7, v24

    goto :goto_6

    .line 268
    :cond_8
    new-instance v6, Lorg/lighttouch/android/StoreError;

    const-string v7, "\u4e0b\u8f7d\u5185\u5bb9\u8d85\u51fa\u9884\u671f\u5927\u5c0f\u3002"

    move-object/from16 v25, v3

    move/from16 v26, v4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    .end local v3    # "buffer\\4":[B
    .end local v4    # "read\\4":I
    .local v25, "buffer\\4":[B
    .local v26, "read\\4":I
    invoke-direct {v6, v7, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v17    # "input\\3":Ljava/io/InputStream;
    .end local v20    # "count":J
    .end local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v6

    .line 266
    .end local v25    # "buffer\\4":[B
    .end local v26    # "read\\4":I
    .restart local v3    # "buffer\\4":[B
    .local v4, "input\\3":Ljava/io/InputStream;
    .restart local v7    # "current":Lorg/json/JSONObject;
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v15    # "digest":Ljava/security/MessageDigest;
    .restart local v20    # "count":J
    .restart local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .local v24, "read\\4":I
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :cond_9
    move-object/from16 v25, v3

    move-object/from16 v17, v4

    move/from16 v26, v24

    move-object/from16 v24, v7

    .line 272
    .end local v3    # "buffer\\4":[B
    .end local v4    # "input\\3":Ljava/io/InputStream;
    .end local v7    # "current":Lorg/json/JSONObject;
    .restart local v17    # "input\\3":Ljava/io/InputStream;
    .local v24, "current":Lorg/json/JSONObject;
    .restart local v25    # "buffer\\4":[B
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/FileDescriptor;->sync()V

    .line 273
    nop

    .end local v0    # "output\\4":Ljava/io/FileOutputStream;
    .end local v23    # "$i$a$-use-LegacyStore$download$1$1\\4\\261\\3":I
    .end local v25    # "buffer\\4":[B
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 261
    const/4 v4, 0x0

    :try_start_6
    invoke-static {v2, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 273
    nop

    .end local v17    # "input\\3":Ljava/io/InputStream;
    .end local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 261
    :try_start_7
    invoke-static {v1, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_7

    .line 274
    :try_start_8
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 275
    const-wide/16 v0, 0x0

    cmp-long v0, v20, v0

    if-eqz v0, :cond_e

    if-eqz v13, :cond_a

    invoke-virtual {v13}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    cmp-long v0, v20, v0

    if-nez v0, :cond_e

    .line 276
    :cond_a
    if-eqz v12, :cond_c

    invoke-virtual {v15}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v0

    const-string v1, "digest(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, ""

    move-object/from16 v26, v1

    check-cast v26, Ljava/lang/CharSequence;

    new-instance v31, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda3;

    invoke-direct/range {v31 .. v31}, Lorg/lighttouch/android/LegacyStore$$ExternalSyntheticLambda3;-><init>()V

    const/16 v32, 0x1e

    const/16 v33, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    move-object/from16 v25, v0

    invoke-static/range {v25 .. v33}, Lkotlin/collections/ArraysKt;->joinToString$default([BLjava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v12, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "toLowerCase(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    goto :goto_7

    .line 277
    :cond_b
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u4e0b\u8f7d\u7684 IPA \u672a\u901a\u8fc7\u6821\u9a8c\u548c\u68c0\u67e5\u3002"

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0, v1, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0

    .line 278
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :cond_c
    :goto_7
    invoke-virtual {v9, v10}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v0

    if-eqz v0, :cond_d

    .line 279
    return-object v10

    .line 278
    :cond_d
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u65e0\u6cd5\u53d1\u5e03\u4e0b\u8f7d\u5185\u5bb9\u3002"

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0, v1, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0

    .line 275
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :cond_e
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u4e0b\u8f7d\u4e0d\u5b8c\u6574\uff0c\u6216\u4e0e\u5b58\u6863\u5927\u5c0f\u4e0d\u4e00\u81f4\u3002"

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0, v1, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 261
    .restart local v4    # "input\\3":Ljava/io/InputStream;
    .restart local v7    # "current":Lorg/json/JSONObject;
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_0
    move-exception v0

    move-object/from16 v17, v4

    move-object/from16 v24, v7

    move-object v3, v0

    .end local v4    # "input\\3":Ljava/io/InputStream;
    .end local v7    # "current":Lorg/json/JSONObject;
    .restart local v17    # "input\\3":Ljava/io/InputStream;
    .restart local v24    # "current":Lorg/json/JSONObject;
    goto :goto_8

    .line 264
    .end local v24    # "current":Lorg/json/JSONObject;
    .restart local v0    # "output\\4":Ljava/io/FileOutputStream;
    .restart local v3    # "buffer\\4":[B
    .restart local v7    # "current":Lorg/json/JSONObject;
    .restart local v23    # "$i$a$-use-LegacyStore$download$1$1\\4\\261\\3":I
    :cond_f
    move-object/from16 v25, v3

    move-object/from16 v24, v7

    .end local v3    # "buffer\\4":[B
    .end local v7    # "current":Lorg/json/JSONObject;
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local v25    # "buffer\\4":[B
    :try_start_9
    new-instance v3, Lorg/lighttouch/android/StoreError;

    const-string v4, "\u4e0b\u8f7d\u5df2\u53d6\u6d88\u3002"

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v3, v4, v7, v5, v6}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v17    # "input\\3":Ljava/io/InputStream;
    .end local v20    # "count":J
    .end local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v3
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 261
    .end local v0    # "output\\4":Ljava/io/FileOutputStream;
    .end local v23    # "$i$a$-use-LegacyStore$download$1$1\\4\\261\\3":I
    .end local v25    # "buffer\\4":[B
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v15    # "digest":Ljava/security/MessageDigest;
    .restart local v17    # "input\\3":Ljava/io/InputStream;
    .restart local v20    # "count":J
    .restart local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_1
    move-exception v0

    move-object v3, v0

    goto :goto_8

    .end local v24    # "current":Lorg/json/JSONObject;
    .restart local v7    # "current":Lorg/json/JSONObject;
    :catchall_2
    move-exception v0

    move-object/from16 v24, v7

    move-object v3, v0

    .end local v7    # "current":Lorg/json/JSONObject;
    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v17    # "input\\3":Ljava/io/InputStream;
    .end local v20    # "count":J
    .end local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :goto_8
    :try_start_a
    throw v3
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v15    # "digest":Ljava/security/MessageDigest;
    .restart local v17    # "input\\3":Ljava/io/InputStream;
    .restart local v20    # "count":J
    .restart local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_3
    move-exception v0

    :try_start_b
    invoke-static {v2, v3}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v20    # "count":J
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .end local v17    # "input\\3":Ljava/io/InputStream;
    .end local v22    # "$i$a$-use-LegacyStore$download$1\\3\\261\\0":I
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v15    # "digest":Ljava/security/MessageDigest;
    .restart local v20    # "count":J
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_4
    move-exception v0

    move-object v2, v0

    goto :goto_9

    .end local v24    # "current":Lorg/json/JSONObject;
    .restart local v7    # "current":Lorg/json/JSONObject;
    :catchall_5
    move-exception v0

    move-object/from16 v24, v7

    move-object v2, v0

    .end local v7    # "current":Lorg/json/JSONObject;
    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v20    # "count":J
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :goto_9
    :try_start_c
    throw v2
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v15    # "digest":Ljava/security/MessageDigest;
    .restart local v20    # "count":J
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_6
    move-exception v0

    :try_start_d
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v20    # "count":J
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_7

    .line 274
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v11    # "connection":Ljava/net/HttpURLConnection;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v15    # "digest":Ljava/security/MessageDigest;
    .restart local v20    # "count":J
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catchall_7
    move-exception v0

    goto :goto_a

    .end local v24    # "current":Lorg/json/JSONObject;
    .restart local v7    # "current":Lorg/json/JSONObject;
    :catchall_8
    move-exception v0

    move-object/from16 v24, v7

    .end local v7    # "current":Lorg/json/JSONObject;
    .restart local v24    # "current":Lorg/json/JSONObject;
    :goto_a
    :try_start_e
    invoke-virtual {v11}, Ljava/net/HttpURLConnection;->disconnect()V

    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v13    # "size":Ljava/lang/Long;
    .end local v14    # "directory":Ljava/io/File;
    .end local v24    # "current":Lorg/json/JSONObject;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "app":Lorg/json/JSONObject;
    .end local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .end local p3    # "scratch":Ljava/io/File;
    .end local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .end local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    throw v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_0

    .line 280
    .end local v11    # "connection":Ljava/net/HttpURLConnection;
    .end local v15    # "digest":Ljava/security/MessageDigest;
    .end local v20    # "count":J
    .restart local v8    # "details":Lorg/json/JSONObject;
    .restart local v9    # "partial":Ljava/io/File;
    .restart local v10    # "final":Ljava/io/File;
    .restart local v12    # "checksum":Ljava/lang/String;
    .restart local v13    # "size":Ljava/lang/Long;
    .restart local v14    # "directory":Ljava/io/File;
    .restart local v24    # "current":Lorg/json/JSONObject;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "app":Lorg/json/JSONObject;
    .restart local p2    # "target":Lorg/lighttouch/android/StoreTarget;
    .restart local p3    # "scratch":Ljava/io/File;
    .restart local p4    # "progress":Lkotlin/jvm/functions/Function2;
    .restart local p5    # "cancelled":Lkotlin/jvm/functions/Function0;
    :catch_0
    move-exception v0

    goto :goto_b

    .end local v24    # "current":Lorg/json/JSONObject;
    .restart local v7    # "current":Lorg/json/JSONObject;
    :catch_1
    move-exception v0

    move-object/from16 v24, v7

    .line 281
    .end local v7    # "current":Lorg/json/JSONObject;
    .local v0, "e":Ljava/lang/Exception;
    .restart local v24    # "current":Lorg/json/JSONObject;
    :goto_b
    invoke-static {v14}, Lkotlin/io/FilesKt;->deleteRecursively(Ljava/io/File;)Z

    .line 282
    instance-of v1, v0, Lorg/lighttouch/android/StoreError;

    if-eqz v1, :cond_10

    move-object v1, v0

    check-cast v1, Ljava/lang/Throwable;

    goto :goto_c

    :cond_10
    new-instance v1, Lorg/lighttouch/android/StoreError;

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Download failed: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v1, v2, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    check-cast v1, Ljava/lang/Throwable;

    :goto_c
    throw v1

    .line 254
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v9    # "partial":Ljava/io/File;
    .end local v10    # "final":Ljava/io/File;
    .end local v24    # "current":Lorg/json/JSONObject;
    .restart local v7    # "current":Lorg/json/JSONObject;
    :cond_11
    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u65e0\u6cd5\u521b\u5efa\u4e0b\u8f7d\u76ee\u5f55\u3002"

    invoke-direct {v0, v1, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0

    .line 251
    .end local v13    # "size":Ljava/lang/Long;
    .local v14, "it\\2":J
    .local v17, "$i$a$-also-LegacyStore$download$size$1\\2\\250\\0":I
    :cond_12
    move v3, v9

    move-object v4, v10

    move v5, v11

    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u5b58\u6863\u63d0\u4f9b\u7684\u6587\u4ef6\u5927\u5c0f\u65e0\u6548\u3002"

    invoke-direct {v0, v1, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0

    .line 245
    .end local v8    # "details":Lorg/json/JSONObject;
    .end local v12    # "checksum":Ljava/lang/String;
    .end local v14    # "it\\2":J
    .end local v17    # "$i$a$-also-LegacyStore$download$size$1\\2\\250\\0":I
    :cond_13
    move v3, v9

    move-object v4, v10

    move v5, v11

    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v1, "\u5b58\u6863\u526f\u672c\u5df2\u4e0e\u6b64\u5e94\u7528\u4e0d\u5339\u914d\u3002"

    invoke-direct {v0, v1, v5, v3, v4}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final genreApps(Ljava/lang/String;Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 4
    .param p1, "genreId"    # Ljava/lang/String;
    .param p2, "sort"    # Ljava/lang/String;

    const-string v0, "genreId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "sort"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 305
    const/4 v1, 0x3

    new-array v1, v1, [Lkotlin/Pair;

    const-string v2, "genre"

    invoke-static {v2, p1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    invoke-static {v0, p2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    aput-object v0, v1, v2

    const-string v0, "limit"

    const-string v2, "50"

    invoke-static {v0, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/4 v2, 0x2

    aput-object v0, v1, v2

    invoke-static {v1}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    const-string v1, "/api/v1/apps"

    invoke-direct {p0, v1, v0}, Lorg/lighttouch/android/LegacyStore;->url(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/lighttouch/android/LegacyStore;->page(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;

    move-result-object v0

    return-object v0
.end method

.method public final genres()Ljava/util/List;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreGenre;",
            ">;"
        }
    .end annotation

    .line 297
    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "/api/v1/genres"

    const/4 v2, 0x0

    const/4 v3, 0x1

    move-object v0, p0

    invoke-static/range {v0 .. v5}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v0, "data"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    .line 298
    .local v0, "data":Lorg/json/JSONArray;
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    invoke-static {v1, v2}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 414
    .local v3, "$i$f$mapNotNull\\1\\298":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\2":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 422
    .local v6, "$i$f$mapNotNullTo\\2\\414":I
    move-object v7, v5

    .local v7, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 423
    .local v8, "$i$f$forEach\\3\\422":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_1

    move-object v10, v9

    check-cast v10, Lkotlin/collections/IntIterator;

    invoke-virtual {v10}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v10

    .local v10, "element\\3":I
    move v11, v10

    .local v11, "element\\4":I
    const/4 v12, 0x0

    .line 422
    .local v12, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\423\\2":I
    move v13, v11

    .local v13, "it\\6":I
    const/4 v14, 0x0

    .line 298
    .local v14, "$i$a$-mapNotNull-LegacyStore$genres$1\\6\\422\\0":I
    invoke-virtual {v0, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    .line 422
    .end local v13    # "it\\6":I
    .end local v14    # "$i$a$-mapNotNull-LegacyStore$genres$1\\6\\422\\0":I
    if-eqz v13, :cond_0

    .line 424
    .local v13, "it\\4":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 422
    .local v14, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\424\\4":I
    invoke-interface {v4, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 423
    .end local v11    # "element\\4":I
    .end local v12    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\423\\2":I
    .end local v13    # "it\\4":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\424\\4":I
    :cond_0
    nop

    .end local v10    # "element\\3":I
    goto :goto_0

    .line 425
    :cond_1
    nop

    .line 426
    .end local v7    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$forEach\\3\\422":I
    nop

    .end local v4    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapNotNullTo\\2\\414":I
    check-cast v4, Ljava/util/List;

    .line 414
    nop

    .end local v2    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapNotNull\\1\\298":I
    check-cast v4, Ljava/lang/Iterable;

    .line 299
    nop

    .local v4, "$this$map\\7":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 427
    .local v2, "$i$f$map\\7\\299":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v4, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\8":Ljava/util/Collection;
    move-object v5, v4

    .local v5, "$this$mapTo\\8":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 428
    .local v6, "$i$f$mapTo\\8\\427":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 429
    .local v8, "item\\8":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/json/JSONObject;

    .local v9, "it\\9":Lorg/json/JSONObject;
    const/4 v10, 0x0

    .line 299
    .local v10, "$i$a$-map-LegacyStore$genres$2\\9\\429\\0":I
    new-instance v11, Lorg/lighttouch/android/StoreGenre;

    const-string v12, "genre_id"

    invoke-virtual {v9, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "optString(...)"

    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v14, "name"

    invoke-virtual {v9, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v13, "app_count"

    invoke-virtual {v9, v13}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v13

    invoke-direct {v11, v12, v14, v13}, Lorg/lighttouch/android/StoreGenre;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 429
    .end local v9    # "it\\9":Lorg/json/JSONObject;
    .end local v10    # "$i$a$-map-LegacyStore$genres$2\\9\\429\\0":I
    invoke-interface {v3, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 430
    .end local v8    # "item\\8":Ljava/lang/Object;
    :cond_2
    nop

    .end local v3    # "destination\\8":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\8":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\8\\427":I
    check-cast v3, Ljava/util/List;

    .line 427
    nop

    .end local v2    # "$i$f$map\\7\\299":I
    .end local v4    # "$this$map\\7":Ljava/lang/Iterable;
    check-cast v3, Ljava/lang/Iterable;

    .line 300
    nop

    .local v3, "$this$filter\\10":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 431
    .local v2, "$i$f$filter\\10\\300":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\11":Ljava/util/Collection;
    move-object v5, v3

    .local v5, "$this$filterTo\\11":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 432
    .local v6, "$i$f$filterTo\\11\\431":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_3
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element\\11":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/lighttouch/android/StoreGenre;

    .local v9, "it\\12":Lorg/lighttouch/android/StoreGenre;
    const/4 v10, 0x0

    .line 300
    .local v10, "$i$a$-filter-LegacyStore$genres$3\\12\\432\\0":I
    invoke-virtual {v9}, Lorg/lighttouch/android/StoreGenre;->getId()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    const/4 v12, 0x1

    if-lez v11, :cond_4

    move v11, v12

    goto :goto_3

    :cond_4
    move v11, v1

    :goto_3
    if-eqz v11, :cond_6

    invoke-virtual {v9}, Lorg/lighttouch/android/StoreGenre;->getName()Ljava/lang/String;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-lez v11, :cond_5

    move v11, v12

    goto :goto_4

    :cond_5
    move v11, v1

    :goto_4
    if-eqz v11, :cond_6

    invoke-virtual {v9}, Lorg/lighttouch/android/StoreGenre;->getCount()I

    move-result v11

    if-lez v11, :cond_6

    goto :goto_5

    :cond_6
    move v12, v1

    .line 432
    .end local v9    # "it\\12":Lorg/lighttouch/android/StoreGenre;
    .end local v10    # "$i$a$-filter-LegacyStore$genres$3\\12\\432\\0":I
    :goto_5
    if-eqz v12, :cond_3

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 433
    .end local v8    # "element\\11":Ljava/lang/Object;
    :cond_7
    nop

    .end local v4    # "destination\\11":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\11":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo\\11\\431":I
    move-object v1, v4

    check-cast v1, Ljava/util/List;

    .line 431
    nop

    .end local v2    # "$i$f$filter\\10\\300":I
    .end local v3    # "$this$filter\\10":Ljava/lang/Iterable;
    check-cast v1, Ljava/lang/Iterable;

    .line 300
    nop

    .local v1, "$this$sortedBy\\13":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 434
    .local v2, "$i$f$sortedBy\\13\\300":I
    new-instance v3, Lorg/lighttouch/android/LegacyStore$genres$$inlined$sortedBy$1;

    invoke-direct {v3}, Lorg/lighttouch/android/LegacyStore$genres$$inlined$sortedBy$1;-><init>()V

    check-cast v3, Ljava/util/Comparator;

    invoke-static {v1, v3}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v1

    .line 298
    .end local v1    # "$this$sortedBy\\13":Ljava/lang/Iterable;
    .end local v2    # "$i$f$sortedBy\\13\\300":I
    return-object v1

    .line 297
    .end local v0    # "data":Lorg/json/JSONArray;
    :cond_8
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v4, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u5206\u7c7b\u5217\u8868\u3002"

    invoke-direct {v0, v4, v1, v2, v3}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final icon(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 8
    .param p1, "url"    # Ljava/lang/String;

    const-string v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 380
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->icons:Landroid/util/LruCache;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 388
    .local v0, "it\\1":Landroid/graphics/Bitmap;
    const/4 v1, 0x0

    .line 380
    .local v1, "$i$a$-let-LegacyStore$icon$1\\1\\380\\0":I
    return-object v0

    .line 384
    .end local v0    # "it\\1":Landroid/graphics/Bitmap;
    .end local v1    # "$i$a$-let-LegacyStore$icon$1\\1\\380\\0":I
    :cond_0
    nop

    .line 381
    const/4 v0, 0x0

    :try_start_0
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Lorg/lighttouch/android/LegacyStore;

    .local v1, "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    const/4 v2, 0x0

    .line 382
    .local v2, "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    invoke-direct {v1, p1}, Lorg/lighttouch/android/LegacyStore;->open(Ljava/lang/String;)Ljava/net/HttpURLConnection;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 383
    .local v3, "connection\\2":Ljava/net/HttpURLConnection;
    :try_start_1
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    check-cast v4, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v5, v4

    check-cast v5, Ljava/io/InputStream;

    .line 388
    .local v5, "it\\3":Ljava/io/InputStream;
    const/4 v6, 0x0

    .line 383
    .local v6, "$i$a$-use-LegacyStore$icon$2$1\\3\\383\\2":I
    invoke-static {v5}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v5    # "it\\3":Ljava/io/InputStream;
    .end local v6    # "$i$a$-use-LegacyStore$icon$2$1\\3\\383\\2":I
    :try_start_3
    invoke-static {v4, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 381
    .end local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    invoke-static {v7}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    goto :goto_0

    .line 383
    .restart local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .restart local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .restart local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    :catchall_0
    move-exception v5

    .end local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    :try_start_5
    throw v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .restart local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .restart local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_1
    move-exception v6

    :try_start_6
    invoke-static {v4, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    throw v6
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .restart local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .restart local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .restart local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_2
    move-exception v4

    :try_start_7
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    throw v4
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 381
    .end local v1    # "$this$icon_u24lambda_u2460\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$icon$2\\2\\381\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_3
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 384
    :goto_0
    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    move-object v1, v0

    :cond_1
    check-cast v1, Landroid/graphics/Bitmap;

    if-eqz v1, :cond_2

    .line 381
    nop

    .line 384
    move-object v0, v1

    .line 388
    .local v0, "it\\4":Landroid/graphics/Bitmap;
    const/4 v2, 0x0

    .line 384
    .local v2, "$i$a$-also-LegacyStore$icon$3\\4\\384\\0":I
    sget-object v3, Lorg/lighttouch/android/LegacyStore;->icons:Landroid/util/LruCache;

    invoke-virtual {v3, p1, v0}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 381
    .end local v0    # "it\\4":Landroid/graphics/Bitmap;
    .end local v2    # "$i$a$-also-LegacyStore$icon$3\\4\\384\\0":I
    :cond_2
    return-object v0
.end method

.method public final incompatibility(Lorg/json/JSONObject;)Ljava/lang/String;
    .locals 7
    .param p1, "app"    # Lorg/json/JSONObject;

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    const-string v0, "compat"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    .line 75
    .local v0, "compat":Lorg/json/JSONObject;
    :cond_0
    const-string v2, "compatible"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_1

    return-object v1

    .line 76
    :cond_1
    const-string v2, "reasons"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    invoke-virtual {v2, v3}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_3

    :cond_2
    const-string v2, ""

    .line 77
    .local v2, "reason":Ljava/lang/String;
    :cond_3
    nop

    .line 78
    const-string v4, "armv6_slice_contains_armv7_code"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_c

    const-string v4, "no_"

    const/4 v5, 0x2

    invoke-static {v2, v4, v3, v5, v1}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    const-string v4, "_slice"

    invoke-static {v2, v4, v3, v5, v1}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    goto/16 :goto_1

    .line 79
    :cond_4
    const-string v4, "requires_ios_"

    invoke-static {v2, v4, v3, v5, v1}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v2, v4}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u9700\u8981 iOS "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    .line 80
    :cond_5
    const-string v4, "capability:!"

    invoke-static {v2, v4, v3, v5, v1}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_b

    const-string v4, "device_family"

    invoke-static {v2, v4, v3, v5, v1}, Lkotlin/text/StringsKt;->endsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_b

    const-string v4, "family_not_requested"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6

    goto :goto_0

    .line 81
    :cond_6
    const-string v4, "capability:"

    invoke-static {v2, v4, v3, v5, v1}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    const-string v1, "\u9700\u8981\u6b64\u8bbe\u5907\u4e0d\u5177\u5907\u7684\u786c\u4ef6"

    goto :goto_2

    .line 82
    :cond_7
    const-string v1, "encrypted"

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    const-string v1, "\u5df2\u52a0\u5bc6 \u2014 \u65e0\u6cd5\u5728 LightTouch \u4e2d\u6253\u5f00"

    goto :goto_2

    .line 83
    :cond_8
    const-string v1, "unavailable"

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    const-string v1, "\u4e0b\u8f7d\u5df2\u4e0d\u53ef\u7528"

    goto :goto_2

    .line 84
    :cond_9
    const-string v1, "not_analyzed"

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    const-string v1, "\u5c1a\u672a\u68c0\u67e5\u517c\u5bb9\u6027"

    goto :goto_2

    .line 85
    :cond_a
    const-string v1, "\u4e0e\u6b64\u8bbe\u5907\u4e0d\u517c\u5bb9"

    goto :goto_2

    .line 80
    :cond_b
    :goto_0
    const-string v1, "\u4e0d\u9002\u7528\u4e8e\u6b64\u8bbe\u5907"

    goto :goto_2

    .line 78
    :cond_c
    :goto_1
    const-string v1, "\u9700\u8981\u66f4\u65b0\u7684\u5904\u7406\u5668"

    .line 77
    :goto_2
    return-object v1
.end method

.method public final lookup(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Lorg/lighttouch/android/LegacyStore$Known;
    .locals 13
    .param p1, "bundleId"    # Ljava/lang/String;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;

    const-string v0, "bundleId"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 216
    const/4 v1, 0x0

    :try_start_0
    const-string v0, "UTF-8"

    invoke-static {p1, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v0, "encode(...)"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "+"

    const-string v4, "%20"

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-static/range {v2 .. v7}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/api/v1/apps/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object v2, p0

    invoke-static/range {v2 .. v7}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0
    :try_end_0
    .catch Lorg/lighttouch/android/StoreError; {:try_start_0 .. :try_end_0} :catch_0

    .line 218
    .local v0, "body":Lorg/json/JSONObject;
    const-string v2, "bundle_id"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-static {v3, p1, v4}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_0

    return-object v1

    .line 219
    :cond_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "name"

    invoke-static {v0, v2}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_1

    const-string v3, "display_name"

    invoke-static {v0, v3}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_1

    move-object v3, p1

    :cond_1
    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    .line 220
    .local v1, "app":Lorg/json/JSONObject;
    const/4 v2, 0x3

    new-array v2, v2, [Ljava/lang/String;

    const-string v3, "app_store_id"

    const/4 v5, 0x0

    aput-object v3, v2, v5

    const-string v3, "developer"

    aput-object v3, v2, v4

    const/4 v3, 0x2

    const-string v4, "icon_url"

    aput-object v4, v2, v3

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .local v3, "key":Ljava/lang/String;
    invoke-static {v0, v3}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_2

    .line 388
    .local v4, "it\\1":Ljava/lang/String;
    const/4 v6, 0x0

    .line 220
    .local v6, "$i$a$-let-LegacyStore$lookup$1\\1\\220\\0":I
    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .end local v4    # "it\\1":Ljava/lang/String;
    .end local v6    # "$i$a$-let-LegacyStore$lookup$1\\1\\220\\0":I
    goto :goto_0

    .end local v3    # "key":Ljava/lang/String;
    :cond_2
    goto :goto_0

    .line 221
    :cond_3
    const-string v2, "versions"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    if-eqz v2, :cond_4

    .line 388
    .local v2, "it\\2":Lorg/json/JSONArray;
    const/4 v3, 0x0

    .line 221
    .local v3, "$i$a$-let-LegacyStore$lookup$versions$1\\2\\221\\0":I
    sget-object v4, Lorg/lighttouch/android/LegacyStore;->INSTANCE:Lorg/lighttouch/android/LegacyStore;

    invoke-direct {v4, v2, v5, p2}, Lorg/lighttouch/android/LegacyStore;->runnableCopies(Lorg/json/JSONArray;ILorg/lighttouch/android/StoreTarget;)Ljava/util/List;

    move-result-object v2

    .end local v2    # "it\\2":Lorg/json/JSONArray;
    .end local v3    # "$i$a$-let-LegacyStore$lookup$versions$1\\2\\221\\0":I
    if-nez v2, :cond_5

    :cond_4
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    .line 222
    .local v2, "versions":Ljava/util/List;
    :cond_5
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    sget-object v3, Lorg/lighttouch/android/StoreVersions;->INSTANCE:Lorg/lighttouch/android/StoreVersions;

    move-object v4, v2

    check-cast v4, Ljava/lang/Iterable;

    .local v4, "$this$map\\3":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 400
    .local v5, "$i$f$map\\3\\222":I
    new-instance v6, Ljava/util/ArrayList;

    const/16 v7, 0xa

    invoke-static {v4, v7}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\4":Ljava/util/Collection;
    move-object v7, v4

    .local v7, "$this$mapTo\\4":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 401
    .local v8, "$i$f$mapTo\\4\\400":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_6

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 402
    .local v10, "item\\4":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Lorg/lighttouch/android/StoreCopy;

    .local v11, "it\\5":Lorg/lighttouch/android/StoreCopy;
    const/4 v12, 0x0

    .line 222
    .local v12, "$i$a$-map-LegacyStore$lookup$2\\5\\402\\0":I
    invoke-virtual {v11}, Lorg/lighttouch/android/StoreCopy;->getVersion()Ljava/lang/String;

    move-result-object v11

    .line 402
    .end local v11    # "it\\5":Lorg/lighttouch/android/StoreCopy;
    .end local v12    # "$i$a$-map-LegacyStore$lookup$2\\5\\402\\0":I
    invoke-interface {v6, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 403
    .end local v10    # "item\\4":Ljava/lang/Object;
    :cond_6
    nop

    .end local v6    # "destination\\4":Ljava/util/Collection;
    .end local v7    # "$this$mapTo\\4":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapTo\\4\\400":I
    check-cast v6, Ljava/util/List;

    .line 400
    nop

    .line 222
    .end local v4    # "$this$map\\3":Ljava/lang/Iterable;
    .end local v5    # "$i$f$map\\3\\222":I
    invoke-virtual {v3, v6}, Lorg/lighttouch/android/StoreVersions;->newest(Ljava/util/List;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lorg/lighttouch/android/LegacyStore$Known;

    invoke-direct {v4, v1, v3}, Lorg/lighttouch/android/LegacyStore$Known;-><init>(Lorg/json/JSONObject;Ljava/lang/String;)V

    return-object v4

    .line 217
    .end local v0    # "body":Lorg/json/JSONObject;
    .end local v1    # "app":Lorg/json/JSONObject;
    .end local v2    # "versions":Ljava/util/List;
    :catch_0
    move-exception v0

    .local v0, "e":Lorg/lighttouch/android/StoreError;
    invoke-virtual {v0}, Lorg/lighttouch/android/StoreError;->getStatus()I

    move-result v2

    const/16 v3, 0x194

    if-ne v2, v3, :cond_7

    return-object v1

    :cond_7
    throw v0
.end method

.method public final newer(Ljava/util/List;Ljava/util/List;)Z
    .locals 1
    .param p1, "a"    # Ljava/util/List;
    .param p2, "b"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)Z"
        }
    .end annotation

    const-string v0, "a"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 65
    sget-object v0, Lorg/lighttouch/android/StoreVersions;->INSTANCE:Lorg/lighttouch/android/StoreVersions;

    invoke-virtual {v0, p1, p2}, Lorg/lighttouch/android/StoreVersions;->newer(Ljava/util/List;Ljava/util/List;)Z

    move-result v0

    return v0
.end method

.method public final page(Ljava/lang/String;)Lorg/lighttouch/android/StorePage;
    .locals 5
    .param p1, "address"    # Ljava/lang/String;

    const-string v0, "address"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 309
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/net/URL;

    const-string v2, "https://legacystore.app"

    invoke-direct {v1, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 310
    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, Lorg/lighttouch/android/LegacyStore;->fetch(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    .line 311
    .local v0, "body":Lorg/json/JSONObject;
    new-instance v1, Lorg/lighttouch/android/StorePage;

    const-string v2, "data"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    const-string v3, "app list"

    invoke-direct {p0, v2, v3}, Lorg/lighttouch/android/LegacyStore;->rows(Lorg/json/JSONArray;Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    const-string v3, "total"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v3

    const-string v4, "next_url"

    invoke-static {v0, v4}, Lorg/lighttouch/android/StoreScreenKt;->text(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v2, v3, v4}, Lorg/lighttouch/android/StorePage;-><init>(Ljava/util/List;ILjava/lang/String;)V

    return-object v1

    .line 309
    .end local v0    # "body":Lorg/json/JSONObject;
    :cond_0
    new-instance v0, Lorg/lighttouch/android/StoreError;

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v3, "\u76ee\u5f55\u63d0\u4f9b\u4e86\u9884\u671f\u4e4b\u5916\u7684\u5730\u5740\u3002"

    const/4 v4, 0x0

    invoke-direct {v0, v3, v4, v1, v2}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

.method public final preferred(I)I
    .locals 2
    .param p1, "ipaId"    # I

    .line 62
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->BROKEN:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_0

    :cond_0
    move v0, p1

    :goto_0
    return v0
.end method

.method public final screenshot(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 12
    .param p1, "url"    # Ljava/lang/String;

    const-string v0, "url"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 367
    sget-object v0, Lorg/lighttouch/android/LegacyStore;->screens:Landroid/util/LruCache;

    invoke-virtual {v0, p1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 388
    .local v0, "it\\1":Landroid/graphics/Bitmap;
    const/4 v1, 0x0

    .line 367
    .local v1, "$i$a$-let-LegacyStore$screenshot$1\\1\\367\\0":I
    return-object v0

    .line 374
    .end local v0    # "it\\1":Landroid/graphics/Bitmap;
    .end local v1    # "$i$a$-let-LegacyStore$screenshot$1\\1\\367\\0":I
    :cond_0
    nop

    .line 368
    const/4 v0, 0x0

    :try_start_0
    sget-object v1, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v1, p0

    check-cast v1, Lorg/lighttouch/android/LegacyStore;

    .local v1, "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    const/4 v2, 0x0

    .line 369
    .local v2, "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    invoke-direct {v1, p1}, Lorg/lighttouch/android/LegacyStore;->open(Ljava/lang/String;)Ljava/net/HttpURLConnection;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    .line 370
    .local v3, "connection\\2":Ljava/net/HttpURLConnection;
    :try_start_1
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    check-cast v4, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    move-object v5, v4

    check-cast v5, Ljava/io/InputStream;

    .line 388
    .local v5, "it\\3":Ljava/io/InputStream;
    const/4 v6, 0x0

    .line 370
    .local v6, "$i$a$-use-LegacyStore$screenshot$2$bytes$1\\3\\370\\2":I
    const/high16 v7, 0x800000

    invoke-virtual {v5, v7}, Ljava/io/InputStream;->readNBytes(I)[B

    move-result-object v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .end local v5    # "it\\3":Ljava/io/InputStream;
    .end local v6    # "$i$a$-use-LegacyStore$screenshot$2$bytes$1\\3\\370\\2":I
    :try_start_3
    invoke-static {v4, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 371
    .local v7, "bytes\\2":[B
    new-instance v4, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v4}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    move-object v5, v4

    .line 388
    .local v5, "$this$screenshot_u24lambda_u2456_u24lambda_u2453\\4":Landroid/graphics/BitmapFactory$Options;
    const/4 v6, 0x0

    .line 371
    .local v6, "$i$a$-apply-LegacyStore$screenshot$2$bounds$1\\4\\371\\2":I
    const/4 v8, 0x1

    iput-boolean v8, v5, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .end local v5    # "$this$screenshot_u24lambda_u2456_u24lambda_u2453\\4":Landroid/graphics/BitmapFactory$Options;
    .end local v6    # "$i$a$-apply-LegacyStore$screenshot$2$bounds$1\\4\\371\\2":I
    move-object v5, v4

    .line 388
    .local v5, "it\\5":Landroid/graphics/BitmapFactory$Options;
    const/4 v6, 0x0

    .line 371
    .local v6, "$i$a$-also-LegacyStore$screenshot$2$bounds$2\\5\\371\\2":I
    array-length v9, v7

    const/4 v10, 0x0

    invoke-static {v7, v10, v9, v5}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 372
    .end local v5    # "it\\5":Landroid/graphics/BitmapFactory$Options;
    .end local v6    # "$i$a$-also-LegacyStore$screenshot$2$bounds$2\\5\\371\\2":I
    .local v4, "bounds\\2":Landroid/graphics/BitmapFactory$Options;
    new-instance v5, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v5}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    move-object v6, v5

    .line 388
    .local v6, "$this$screenshot_u24lambda_u2456_u24lambda_u2455\\6":Landroid/graphics/BitmapFactory$Options;
    const/4 v9, 0x0

    .line 372
    .local v9, "$i$a$-apply-LegacyStore$screenshot$2$options$1\\6\\372\\2":I
    iget v11, v4, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    div-int/lit16 v11, v11, 0x190

    invoke-static {v11, v8}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v8

    iput v8, v6, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 373
    .end local v6    # "$this$screenshot_u24lambda_u2456_u24lambda_u2455\\6":Landroid/graphics/BitmapFactory$Options;
    .end local v9    # "$i$a$-apply-LegacyStore$screenshot$2$options$1\\6\\372\\2":I
    .local v5, "options\\2":Landroid/graphics/BitmapFactory$Options;
    array-length v6, v7

    invoke-static {v7, v10, v6, v5}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v6

    .line 368
    .end local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .end local v4    # "bounds\\2":Landroid/graphics/BitmapFactory$Options;
    .end local v5    # "options\\2":Landroid/graphics/BitmapFactory$Options;
    .end local v7    # "bytes\\2":[B
    invoke-static {v6}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    goto :goto_0

    .line 370
    .restart local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .restart local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .restart local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    :catchall_0
    move-exception v5

    .end local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    :try_start_5
    throw v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .restart local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .restart local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .restart local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_1
    move-exception v6

    :try_start_6
    invoke-static {v4, v5}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    throw v6
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .restart local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .restart local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .restart local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_2
    move-exception v4

    :try_start_7
    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V

    .end local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .end local p1    # "url":Ljava/lang/String;
    throw v4
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 368
    .end local v1    # "$this$screenshot_u24lambda_u2456\\2":Lorg/lighttouch/android/LegacyStore;
    .end local v2    # "$i$a$-runCatching-LegacyStore$screenshot$2\\2\\368\\0":I
    .end local v3    # "connection\\2":Ljava/net/HttpURLConnection;
    .restart local p0    # "this":Lorg/lighttouch/android/LegacyStore;
    .restart local p1    # "url":Ljava/lang/String;
    :catchall_3
    move-exception v1

    sget-object v2, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v1}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 374
    :goto_0
    invoke-static {v1}, Lkotlin/Result;->isFailure-impl(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    move-object v1, v0

    :cond_1
    check-cast v1, Landroid/graphics/Bitmap;

    if-eqz v1, :cond_2

    .line 368
    nop

    .line 374
    move-object v0, v1

    .line 388
    .local v0, "it\\7":Landroid/graphics/Bitmap;
    const/4 v2, 0x0

    .line 374
    .local v2, "$i$a$-also-LegacyStore$screenshot$3\\7\\374\\0":I
    sget-object v3, Lorg/lighttouch/android/LegacyStore;->screens:Landroid/util/LruCache;

    invoke-virtual {v3, p1, v0}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 368
    .end local v0    # "it\\7":Landroid/graphics/Bitmap;
    .end local v2    # "$i$a$-also-LegacyStore$screenshot$3\\7\\374\\0":I
    :cond_2
    return-object v0
.end method

.method public final screenshots(Lorg/json/JSONObject;)Ljava/util/List;
    .locals 19
    .param p1, "app"    # Lorg/json/JSONObject;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            ")",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreShot;",
            ">;"
        }
    .end annotation

    const-string v0, "app"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 357
    invoke-virtual/range {p0 .. p1}, Lorg/lighttouch/android/LegacyStore;->appKey(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 358
    .local v0, "key":Ljava/lang/String;
    :cond_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "/api/v1/apps/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/screenshots"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    move-object/from16 v3, p0

    invoke-static/range {v3 .. v8}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "data"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    if-nez v2, :cond_1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v2

    return-object v2

    .line 359
    .local v2, "sets":Lorg/json/JSONArray;
    :cond_1
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v4, 0x0

    invoke-static {v4, v3}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$mapNotNull\\1":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 492
    .local v5, "$i$f$mapNotNull\\1\\359":I
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    check-cast v6, Ljava/util/Collection;

    .local v6, "destination\\2":Ljava/util/Collection;
    move-object v7, v3

    .local v7, "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 500
    .local v8, "$i$f$mapNotNullTo\\2\\492":I
    move-object v9, v7

    .local v9, "$this$forEach\\3":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 501
    .local v10, "$i$f$forEach\\3\\500":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_0
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_4

    move-object v12, v11

    check-cast v12, Lkotlin/collections/IntIterator;

    invoke-virtual {v12}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v12

    .local v12, "element\\3":I
    move v14, v12

    .local v14, "element\\4":I
    const/4 v15, 0x0

    .line 500
    .local v15, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\501\\2":I
    move/from16 v16, v14

    .local v16, "it\\6":I
    const/16 v17, 0x0

    .line 359
    .local v17, "$i$a$-mapNotNull-LegacyStore$screenshots$shots$1\\6\\500\\0":I
    move/from16 v13, v16

    .end local v16    # "it\\6":I
    .local v13, "it\\6":I
    invoke-virtual {v2, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    if-eqz v4, :cond_2

    move-object/from16 v18, v0

    .end local v0    # "key":Ljava/lang/String;
    .local v18, "key":Ljava/lang/String;
    const-string v0, "shots"

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    move-object v13, v0

    goto :goto_1

    .end local v18    # "key":Ljava/lang/String;
    .restart local v0    # "key":Ljava/lang/String;
    :cond_2
    move-object/from16 v18, v0

    .end local v0    # "key":Ljava/lang/String;
    .restart local v18    # "key":Ljava/lang/String;
    const/4 v13, 0x0

    .line 500
    .end local v13    # "it\\6":I
    .end local v17    # "$i$a$-mapNotNull-LegacyStore$screenshots$shots$1\\6\\500\\0":I
    :goto_1
    if-eqz v13, :cond_3

    .line 502
    .local v13, "it\\4":Ljava/lang/Object;
    const/4 v0, 0x0

    .line 500
    .local v0, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\502\\4":I
    invoke-interface {v6, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 501
    .end local v0    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\5\\502\\4":I
    .end local v13    # "it\\4":Ljava/lang/Object;
    .end local v14    # "element\\4":I
    .end local v15    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\4\\501\\2":I
    :cond_3
    move-object/from16 v0, v18

    const/4 v4, 0x0

    .end local v12    # "element\\3":I
    goto :goto_0

    .line 503
    .end local v18    # "key":Ljava/lang/String;
    .local v0, "key":Ljava/lang/String;
    :cond_4
    move-object/from16 v18, v0

    .line 504
    .end local v0    # "key":Ljava/lang/String;
    .end local v9    # "$this$forEach\\3":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\3\\500":I
    .restart local v18    # "key":Ljava/lang/String;
    nop

    .end local v6    # "destination\\2":Ljava/util/Collection;
    .end local v7    # "$this$mapNotNullTo\\2":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapNotNullTo\\2\\492":I
    move-object v0, v6

    check-cast v0, Ljava/util/List;

    .line 492
    nop

    .line 359
    .end local v3    # "$this$mapNotNull\\1":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapNotNull\\1\\359":I
    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\7":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 505
    .local v3, "$i$f$firstOrNull\\7\\359":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_5
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v6, 0x1

    if-eqz v5, :cond_7

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\7":Ljava/lang/Object;
    move-object v7, v5

    check-cast v7, Lorg/json/JSONArray;

    .local v7, "it\\8":Lorg/json/JSONArray;
    const/4 v8, 0x0

    .line 359
    .local v8, "$i$a$-firstOrNull-LegacyStore$screenshots$shots$2\\8\\505\\0":I
    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-lez v9, :cond_6

    move v7, v6

    goto :goto_2

    :cond_6
    const/4 v7, 0x0

    .line 505
    .end local v7    # "it\\8":Lorg/json/JSONArray;
    .end local v8    # "$i$a$-firstOrNull-LegacyStore$screenshots$shots$2\\8\\505\\0":I
    :goto_2
    if-eqz v7, :cond_5

    move-object v13, v5

    goto :goto_3

    .line 506
    .end local v5    # "element\\7":Ljava/lang/Object;
    :cond_7
    const/4 v13, 0x0

    .line 359
    .end local v0    # "$this$firstOrNull\\7":Ljava/lang/Iterable;
    .end local v3    # "$i$f$firstOrNull\\7\\359":I
    :goto_3
    check-cast v13, Lorg/json/JSONArray;

    if-nez v13, :cond_8

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    .line 360
    .local v13, "shots":Lorg/json/JSONArray;
    :cond_8
    invoke-virtual {v13}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v3, 0x0

    invoke-static {v3, v0}, Lkotlin/ranges/RangesKt;->until(II)Lkotlin/ranges/IntRange;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$mapNotNull\\9":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 507
    .local v4, "$i$f$mapNotNull\\9\\360":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination\\10":Ljava/util/Collection;
    move-object v7, v0

    .local v7, "$this$mapNotNullTo\\10":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 515
    .local v8, "$i$f$mapNotNullTo\\10\\507":I
    move-object v9, v7

    .local v9, "$this$forEach\\11":Ljava/lang/Iterable;
    const/4 v10, 0x0

    .line 516
    .local v10, "$i$f$forEach\\11\\515":I
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_4
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_a

    move-object v12, v11

    check-cast v12, Lkotlin/collections/IntIterator;

    invoke-virtual {v12}, Lkotlin/collections/IntIterator;->nextInt()I

    move-result v12

    .local v12, "element\\11":I
    move v14, v12

    .local v14, "element\\12":I
    const/4 v15, 0x0

    .line 515
    .local v15, "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\12\\516\\10":I
    move/from16 v16, v14

    .local v16, "it\\14":I
    const/16 v17, 0x0

    .line 360
    .local v17, "$i$a$-mapNotNull-LegacyStore$screenshots$1\\14\\515\\0":I
    move/from16 v3, v16

    .end local v16    # "it\\14":I
    .local v3, "it\\14":I
    invoke-virtual {v13, v3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    .line 515
    .end local v3    # "it\\14":I
    .end local v17    # "$i$a$-mapNotNull-LegacyStore$screenshots$1\\14\\515\\0":I
    if-eqz v3, :cond_9

    .line 517
    .local v3, "it\\12":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 515
    .local v16, "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\13\\517\\12":I
    invoke-interface {v5, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 516
    .end local v3    # "it\\12":Ljava/lang/Object;
    .end local v14    # "element\\12":I
    .end local v15    # "$i$a$-forEach-CollectionsKt___CollectionsKt$mapNotNullTo$1\\12\\516\\10":I
    .end local v16    # "$i$a$-let-CollectionsKt___CollectionsKt$mapNotNullTo$1$1\\13\\517\\12":I
    :cond_9
    const/4 v3, 0x0

    .end local v12    # "element\\11":I
    goto :goto_4

    .line 518
    :cond_a
    nop

    .line 519
    .end local v9    # "$this$forEach\\11":Ljava/lang/Iterable;
    .end local v10    # "$i$f$forEach\\11\\515":I
    nop

    .end local v5    # "destination\\10":Ljava/util/Collection;
    .end local v7    # "$this$mapNotNullTo\\10":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapNotNullTo\\10\\507":I
    move-object v3, v5

    check-cast v3, Ljava/util/List;

    .line 507
    nop

    .end local v0    # "$this$mapNotNull\\9":Ljava/lang/Iterable;
    .end local v4    # "$i$f$mapNotNull\\9\\360":I
    check-cast v3, Ljava/lang/Iterable;

    .line 361
    nop

    .local v3, "$this$filter\\15":Ljava/lang/Iterable;
    const/4 v0, 0x0

    .line 520
    .local v0, "$i$f$filter\\15\\361":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\16":Ljava/util/Collection;
    move-object v5, v3

    .local v5, "$this$filterTo\\16":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 521
    .local v7, "$i$f$filterTo\\16\\520":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_b
    :goto_5
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const-string v10, "optString(...)"

    const-string v11, "url"

    if-eqz v9, :cond_d

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element\\16":Ljava/lang/Object;
    move-object v12, v9

    check-cast v12, Lorg/json/JSONObject;

    .local v12, "it\\17":Lorg/json/JSONObject;
    const/4 v14, 0x0

    .line 361
    .local v14, "$i$a$-filter-LegacyStore$screenshots$2\\17\\521\\0":I
    invoke-virtual {v12, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v10

    if-lez v10, :cond_c

    move v10, v6

    goto :goto_6

    :cond_c
    const/4 v10, 0x0

    .line 521
    .end local v12    # "it\\17":Lorg/json/JSONObject;
    .end local v14    # "$i$a$-filter-LegacyStore$screenshots$2\\17\\521\\0":I
    :goto_6
    if-eqz v10, :cond_b

    invoke-interface {v4, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_5

    .line 522
    .end local v9    # "element\\16":Ljava/lang/Object;
    :cond_d
    nop

    .end local v4    # "destination\\16":Ljava/util/Collection;
    .end local v5    # "$this$filterTo\\16":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filterTo\\16\\520":I
    check-cast v4, Ljava/util/List;

    .line 520
    nop

    .end local v0    # "$i$f$filter\\15\\361":I
    .end local v3    # "$this$filter\\15":Ljava/lang/Iterable;
    check-cast v4, Ljava/lang/Iterable;

    .line 361
    nop

    .local v4, "$this$map\\18":Ljava/lang/Iterable;
    const/4 v0, 0x0

    .line 523
    .local v0, "$i$f$map\\18\\361":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v4, v5}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\19":Ljava/util/Collection;
    move-object v5, v4

    .local v5, "$this$mapTo\\19":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 524
    .local v6, "$i$f$mapTo\\19\\523":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_7
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_e

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 525
    .local v8, "item\\19":Ljava/lang/Object;
    move-object v9, v8

    check-cast v9, Lorg/json/JSONObject;

    .local v9, "it\\20":Lorg/json/JSONObject;
    const/4 v12, 0x0

    .line 361
    .local v12, "$i$a$-map-LegacyStore$screenshots$3\\20\\525\\0":I
    new-instance v14, Lorg/lighttouch/android/StoreShot;

    invoke-virtual {v9, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move/from16 v16, v0

    .end local v0    # "$i$f$map\\18\\361":I
    .local v16, "$i$f$map\\18\\361":I
    const-string v0, "width"

    invoke-virtual {v9, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const-string v1, "height"

    invoke-virtual {v9, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    invoke-direct {v14, v15, v0, v1}, Lorg/lighttouch/android/StoreShot;-><init>(Ljava/lang/String;II)V

    .line 525
    .end local v9    # "it\\20":Lorg/json/JSONObject;
    .end local v12    # "$i$a$-map-LegacyStore$screenshots$3\\20\\525\\0":I
    invoke-interface {v3, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p1

    move/from16 v0, v16

    goto :goto_7

    .line 526
    .end local v8    # "item\\19":Ljava/lang/Object;
    .end local v16    # "$i$f$map\\18\\361":I
    .restart local v0    # "$i$f$map\\18\\361":I
    :cond_e
    move/from16 v16, v0

    .end local v0    # "$i$f$map\\18\\361":I
    .end local v3    # "destination\\19":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\19":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\19\\523":I
    .restart local v16    # "$i$f$map\\18\\361":I
    move-object v0, v3

    check-cast v0, Ljava/util/List;

    .line 523
    nop

    .line 360
    .end local v4    # "$this$map\\18":Ljava/lang/Iterable;
    .end local v16    # "$i$f$map\\18\\361":I
    return-object v0
.end method

.method public final search(Ljava/lang/String;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;
    .locals 4
    .param p1, "query"    # Ljava/lang/String;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lorg/lighttouch/android/StoreTarget;",
            ")",
            "Ljava/util/List<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation

    const-string v0, "query"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 151
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    const-string v1, "50"

    const-string v2, "limit"

    if-eqz v0, :cond_0

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf(Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x3

    new-array v0, v0, [Lkotlin/Pair;

    const/4 v3, 0x0

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    aput-object v1, v0, v3

    move-object v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "q"

    invoke-static {v2, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x1

    aput-object v1, v0, v2

    const-string v1, "incompatible"

    const-string v2, "include"

    invoke-static {v1, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/4 v2, 0x2

    aput-object v1, v0, v2

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v0

    :goto_0
    invoke-direct {p0, v0, p2}, Lorg/lighttouch/android/LegacyStore;->apps(Ljava/util/Map;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final version(Ljava/lang/String;)Ljava/util/List;
    .locals 1
    .param p1, "value"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 64
    sget-object v0, Lorg/lighttouch/android/StoreVersions;->INSTANCE:Lorg/lighttouch/android/StoreVersions;

    invoke-virtual {v0, p1}, Lorg/lighttouch/android/StoreVersions;->parse(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final versions(Lorg/json/JSONObject;Lorg/lighttouch/android/StoreTarget;)Ljava/util/List;
    .locals 11
    .param p1, "app"    # Lorg/json/JSONObject;
    .param p2, "target"    # Lorg/lighttouch/android/StoreTarget;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONObject;",
            "Lorg/lighttouch/android/StoreTarget;",
            ")",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/StoreCopy;",
            ">;"
        }
    .end annotation

    const-string v0, "app"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "target"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 180
    invoke-virtual {p0, p1}, Lorg/lighttouch/android/LegacyStore;->appKey(Lorg/json/JSONObject;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    .line 181
    .local v0, "key":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "/api/v1/apps/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "/versions"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    move-object v5, p0

    invoke-static/range {v5 .. v10}, Lorg/lighttouch/android/LegacyStore;->json$default(Lorg/lighttouch/android/LegacyStore;Ljava/lang/String;Ljava/util/Map;ZILjava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v6, "data"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 183
    .local v4, "data":Lorg/json/JSONArray;
    const-string v1, "ipa_id"

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    invoke-direct {p0, v4, v1, p2}, Lorg/lighttouch/android/LegacyStore;->runnableCopies(Lorg/json/JSONArray;ILorg/lighttouch/android/StoreTarget;)Ljava/util/List;

    move-result-object v1

    return-object v1

    .line 182
    .end local v4    # "data":Lorg/json/JSONArray;
    :cond_0
    new-instance v4, Lorg/lighttouch/android/StoreError;

    const-string v6, "\u65e7\u7248\u5546\u5e97\u8fd4\u56de\u4e86\u65e0\u6cd5\u89e3\u6790\u7684\u7248\u672c\u4fe1\u606f\u3002"

    invoke-direct {v4, v6, v3, v2, v1}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v4

    .line 180
    .end local v0    # "key":Ljava/lang/String;
    :cond_1
    move-object v5, p0

    new-instance v0, Lorg/lighttouch/android/StoreError;

    const-string v4, "\u6b64\u5e94\u7528\u6ca1\u6709\u76ee\u5f55\u6807\u8bc6\u7b26\u3002"

    invoke-direct {v0, v4, v3, v2, v1}, Lorg/lighttouch/android/StoreError;-><init>(Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    throw v0
.end method

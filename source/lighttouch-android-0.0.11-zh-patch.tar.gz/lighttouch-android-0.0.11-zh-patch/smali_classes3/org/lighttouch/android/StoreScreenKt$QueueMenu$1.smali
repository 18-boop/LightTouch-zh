.class final Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;
.super Ljava/lang/Object;
.source "StoreScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/StoreScreenKt;->QueueMenu(Lorg/lighttouch/android/StoreModel;ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStoreScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt$QueueMenu$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 8 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 9 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n*L\n1#1,586:1\n149#2:587\n149#2:640\n149#2:681\n99#3:588\n96#3,6:589\n102#3:623\n106#3:639\n79#4,6:595\n86#4,4:610\n90#4,2:620\n94#4:638\n79#4,6:648\n86#4,4:663\n90#4,2:673\n94#4:679\n368#5,9:601\n377#5:622\n378#5,2:636\n368#5,9:654\n377#5:675\n378#5,2:677\n4034#6,6:614\n4034#6,6:667\n1761#7,3:624\n1761#7,3:627\n1225#8,6:630\n86#9:641\n83#9,6:642\n89#9:676\n93#9:680\n*S KotlinDebug\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt$QueueMenu$1\n*L\n554#1:587\n558#1:640\n561#1:681\n554#1:588\n554#1:589,6\n554#1:623\n554#1:639\n554#1:595,6\n554#1:610,4\n554#1:620,2\n554#1:638\n558#1:648,6\n558#1:663,4\n558#1:673,2\n558#1:679\n554#1:601,9\n554#1:622\n554#1:636,2\n558#1:654,9\n558#1:675\n558#1:677,2\n554#1:614,6\n558#1:667,6\n555#1:624,3\n556#1:627,3\n556#1:630,6\n558#1:641\n558#1:642,6\n558#1:676\n558#1:680\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $items:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $model:Lorg/lighttouch/android/StoreModel;


# direct methods
.method public static synthetic $r8$lambda$XtKKX3KvLLeKAQW6Wct3zMImHXY(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->invoke$lambda$4$lambda$3$lambda$2(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lorg/lighttouch/android/QueueItem;",
            ">;",
            "Lorg/lighttouch/android/StoreModel;",
            ")V"
        }
    .end annotation

    iput-object p1, p0, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->$items:Ljava/util/List;

    iput-object p2, p0, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->$model:Lorg/lighttouch/android/StoreModel;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static final invoke$lambda$4$lambda$3$lambda$2(Lorg/lighttouch/android/StoreModel;)Lkotlin/Unit;
    .locals 1
    .param p0, "$model"    # Lorg/lighttouch/android/StoreModel;

    .line 556
    invoke-virtual {p0}, Lorg/lighttouch/android/StoreModel;->clearFinished()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 553
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 57
    .param p1, "$this$DropdownMenu"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$DropdownMenu"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C553@34114L376,557@34553L21,557@34499L171,560@34679L29:StoreScreen.kt#o13vsk"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-ne v3, v5, :cond_1

    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    .line 561
    :cond_0
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_e

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2

    const/4 v3, -0x1

    const-string v5, "org.lighttouch.android.QueueMenu.<anonymous> (StoreScreen.kt:553)"

    const v6, -0x76e1514c

    invoke-static {v6, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 554
    :cond_2
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object v5, v3

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x10

    .local v3, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 587
    .local v6, "$i$f$getDp\\1\\554":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 554
    .end local v3    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\554":I
    const/16 v3, 0x8

    .local v3, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 587
    .local v7, "$i$f$getDp\\2\\554":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 554
    .end local v3    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\554":I
    const/16 v10, 0xa

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    invoke-static/range {v5 .. v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    iget-object v6, v0, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->$items:Ljava/util/List;

    iget-object v7, v0, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->$model:Lorg/lighttouch/android/StoreModel;

    const/16 v8, 0x186

    .local v8, "$changed\\3":I
    const/4 v9, 0x0

    .line 588
    .local v9, "$i$f$Row\\3\\554":I
    const v10, 0x2952b718

    const-string v11, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v1, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 589
    sget-object v10, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v10}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v10

    .line 593
    .local v10, "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v11, v8, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v8, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v10, v5, v1, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .local v11, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v8, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 594
    nop

    .local v12, "$changed\\4":I
    const/4 v13, 0x0

    .line 595
    .local v13, "$i$f$Layout\\4\\594":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v1, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 596
    const/4 v14, 0x0

    invoke-static {v1, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v17

    .line 597
    .local v17, "compositeKeyHash\\4":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 598
    .local v14, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 600
    .local v2, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v19, v3

    .end local v3    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\3":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v12, 0x6

    and-int/lit16 v3, v3, 0x380

    move/from16 v20, v3

    const/4 v3, 0x6

    or-int/lit8 v20, v20, 0x6

    .line 599
    move-object/from16 v21, v18

    .local v20, "$changed\\5":I
    .local v21, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 601
    .local v18, "$i$f$ReusableComposeNode\\5\\599":I
    move/from16 v22, v3

    const v3, -0x2942ffcf

    const-string v4, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v1, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 602
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 603
    :cond_3
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 604
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_4

    .line 605
    move-object/from16 v3, v21

    .end local v21    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 607
    .end local v3    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v21    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_4
    move-object/from16 v3, v21

    .end local v21    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 609
    :goto_1
    move-object/from16 v21, v3

    .end local v3    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v21    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 610
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\609\\4":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v26, v5

    .end local v5    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .local v26, "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v11, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 611
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v14, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 613
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 614
    .local v25, "$i$f$set-impl\\7\\613":I
    move-object/from16 v27, v3

    .local v27, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 615
    .local v28, "$i$a$-with-Updater$set$1\\8\\614\\7":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v29

    if-nez v29, :cond_6

    move-object/from16 v29, v6

    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    move/from16 v30, v8

    .end local v8    # "$changed\\3":I
    .local v30, "$changed\\3":I
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v6, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v8, v27

    goto :goto_3

    .end local v30    # "$changed\\3":I
    .restart local v8    # "$changed\\3":I
    :cond_6
    move-object/from16 v29, v6

    move/from16 v30, v8

    .line 616
    .end local v8    # "$changed\\3":I
    .restart local v30    # "$changed\\3":I
    :goto_2
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    move-object/from16 v8, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 617
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v3, v6, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 619
    :goto_3
    nop

    .line 614
    .end local v8    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-with-Updater$set$1\\8\\614\\7":I
    nop

    .line 619
    nop

    .line 620
    .end local v5    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v25    # "$i$f$set-impl\\7\\613":I
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v2, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 621
    nop

    .line 609
    .end local v3    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\609\\4":I
    nop

    .line 622
    shr-int/lit8 v3, v20, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\9":I
    move-object/from16 v5, p2

    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 623
    .local v6, "$i$a$-Layout-RowKt$Row$1\\9\\622\\3":I
    const v8, -0x184f2606

    move-object/from16 v24, v2

    .end local v2    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v24, "materialized\\4":Landroidx/compose/ui/Modifier;
    const-string v2, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v5, v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v8, v30, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\10":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$invoke_u24lambda_u244\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v31, v2

    .end local v2    # "$this$invoke_u24lambda_u244\\10":Landroidx/compose/foundation/layout/RowScope;
    .local v31, "$this$invoke_u24lambda_u244\\10":Landroidx/compose/foundation/layout/RowScope;
    move-object v2, v5

    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 555
    .local v25, "$i$a$-Row-StoreScreenKt$QueueMenu$1$1\\10\\623\\0":I
    move/from16 v27, v3

    .end local v3    # "$changed\\9":I
    .local v27, "$changed\\9":I
    const v3, 0x2ecc470c

    move-object/from16 v28, v5

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v28, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v5, "C554@34341L10,554@34225L138:StoreScreen.kt#o13vsk"

    invoke-static {v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v3, v29

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$any\\11":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 624
    .local v5, "$i$f$any\\11\\555":I
    move/from16 v32, v5

    .end local v5    # "$i$f$any\\11\\555":I
    .local v32, "$i$f$any\\11\\555":I
    instance-of v5, v3, Ljava/util/Collection;

    move-object/from16 v33, v3

    .end local v3    # "$this$any\\11":Ljava/lang/Iterable;
    .local v33, "$this$any\\11":Ljava/lang/Iterable;
    if-eqz v5, :cond_7

    move-object/from16 v5, v33

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_7

    const/4 v5, 0x0

    goto :goto_4

    .line 625
    :cond_7
    invoke-interface/range {v33 .. v33}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v34

    if-eqz v34, :cond_9

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v34

    .local v34, "element\\11":Ljava/lang/Object;
    move-object/from16 v35, v34

    check-cast v35, Lorg/lighttouch/android/QueueItem;

    .local v35, "it\\12":Lorg/lighttouch/android/QueueItem;
    const/16 v36, 0x0

    .line 555
    .local v36, "$i$a$-any-StoreScreenKt$QueueMenu$1$1$1\\12\\625\\10":I
    invoke-virtual/range {v35 .. v35}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v35

    .line 625
    .end local v35    # "it\\12":Lorg/lighttouch/android/QueueItem;
    .end local v36    # "$i$a$-any-StoreScreenKt$QueueMenu$1$1$1\\12\\625\\10":I
    if-eqz v35, :cond_8

    const/4 v5, 0x1

    goto :goto_4

    .line 626
    .end local v34    # "element\\11":Ljava/lang/Object;
    :cond_9
    const/4 v5, 0x0

    .line 555
    .end local v32    # "$i$f$any\\11\\555":I
    .end local v33    # "$this$any\\11":Ljava/lang/Iterable;
    :goto_4
    if-eqz v5, :cond_a

    const-string v5, "\u5b89\u88c5\u4e2d"

    goto :goto_5

    :cond_a
    const-string v5, "\u5df2\u5b8c\u6210\u5b89\u88c5"

    :goto_5
    sget-object v32, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v32, Landroidx/compose/ui/Modifier;

    const/16 v35, 0x2

    const/16 v36, 0x0

    const/high16 v33, 0x3f800000    # 1.0f

    const/16 v34, 0x0

    invoke-static/range {v31 .. v36}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v33

    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v32, v5

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v2, v5}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/Typography;->getTitleSmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v52

    const/16 v55, 0x0

    const v56, 0xfffc

    const-wide/16 v34, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const-wide/16 v41, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    const/16 v51, 0x0

    const/16 v54, 0x0

    move-object/from16 v53, v2

    .end local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v53, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v56}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v5, v53

    .end local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\10":Landroidx/compose/runtime/Composer;
    const v2, -0x1f85b9e0

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "555@34427L25,555@34406L74"

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 556
    move-object/from16 v2, v29

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$any\\13":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 627
    .local v3, "$i$f$any\\13\\556":I
    move/from16 v29, v3

    .end local v3    # "$i$f$any\\13\\556":I
    .local v29, "$i$f$any\\13\\556":I
    instance-of v3, v2, Ljava/util/Collection;

    if-eqz v3, :cond_b

    move-object v3, v2

    check-cast v3, Ljava/util/Collection;

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_b

    const/4 v2, 0x0

    goto :goto_6

    .line 628
    :cond_b
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v32

    if-eqz v32, :cond_d

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v32

    .local v32, "element\\13":Ljava/lang/Object;
    move-object/from16 v33, v32

    check-cast v33, Lorg/lighttouch/android/QueueItem;

    .local v33, "it\\14":Lorg/lighttouch/android/QueueItem;
    const/16 v34, 0x0

    .line 556
    .local v34, "$i$a$-any-StoreScreenKt$QueueMenu$1$1$2\\14\\628\\10":I
    invoke-virtual/range {v33 .. v33}, Lorg/lighttouch/android/QueueItem;->getActive()Z

    move-result v35

    .line 628
    .end local v33    # "it\\14":Lorg/lighttouch/android/QueueItem;
    .end local v34    # "$i$a$-any-StoreScreenKt$QueueMenu$1$1$2\\14\\628\\10":I
    if-nez v35, :cond_c

    const/4 v2, 0x1

    goto :goto_6

    .line 629
    .end local v32    # "element\\13":Ljava/lang/Object;
    :cond_d
    const/4 v2, 0x0

    .line 556
    .end local v2    # "$this$any\\13":Ljava/lang/Iterable;
    .end local v29    # "$i$f$any\\13\\556":I
    :goto_6
    if-eqz v2, :cond_10

    const v2, 0x4c5de2

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v5, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\15":Z
    move-object v3, v5

    .local v3, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 630
    .local v29, "$i$f$cache\\15\\556":I
    move/from16 v32, v2

    .end local v2    # "invalid\\15":Z
    .local v32, "invalid\\15":Z
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\15":Ljava/lang/Object;
    const/16 v33, 0x0

    .line 631
    .local v33, "$i$a$-let-ComposerKt$cache$1\\16\\630\\15":I
    if-nez v32, :cond_f

    sget-object v34, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v53, v5

    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v34 .. v34}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v2, v5, :cond_e

    goto :goto_7

    .line 635
    :cond_e
    move-object/from16 v34, v2

    goto :goto_8

    .line 631
    .end local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_f
    move-object/from16 v53, v5

    .line 632
    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :goto_7
    const/4 v5, 0x0

    .line 556
    .local v5, "$i$a$-cache-StoreScreenKt$QueueMenu$1$1$3\\17\\632\\10":I
    move-object/from16 v34, v2

    .end local v2    # "it\\15":Ljava/lang/Object;
    .local v34, "it\\15":Ljava/lang/Object;
    new-instance v2, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1$$ExternalSyntheticLambda0;

    invoke-direct {v2, v7}, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/StoreModel;)V

    .line 632
    .end local v5    # "$i$a$-cache-StoreScreenKt$QueueMenu$1$1$3\\17\\632\\10":I
    nop

    .line 633
    .local v2, "value\\16":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 634
    nop

    .line 631
    .end local v2    # "value\\16":Ljava/lang/Object;
    :goto_8
    nop

    .line 630
    .end local v33    # "$i$a$-let-ComposerKt$cache$1\\16\\630\\15":I
    .end local v34    # "it\\15":Ljava/lang/Object;
    nop

    .line 556
    .end local v3    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$f$cache\\15\\556":I
    .end local v32    # "invalid\\15":Z
    move-object/from16 v32, v2

    check-cast v32, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v2, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;

    invoke-virtual {v2}, Lorg/lighttouch/android/ComposableSingletons$StoreScreenKt;->getLambda$699384432$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v41

    const/high16 v43, 0x30000000

    const/16 v44, 0x1fe

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    move-object/from16 v42, v53

    .end local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v44}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v42    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    goto :goto_9

    .end local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\10":Landroidx/compose/runtime/Composer;
    :cond_10
    move-object/from16 v53, v5

    .end local v5    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    :goto_9
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 555
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 557
    nop

    .line 623
    .end local v8    # "$changed\\10":I
    .end local v25    # "$i$a$-Row-StoreScreenKt$QueueMenu$1$1\\10\\623\\0":I
    .end local v31    # "$this$invoke_u24lambda_u244\\10":Landroidx/compose/foundation/layout/RowScope;
    .end local v53    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 622
    .end local v6    # "$i$a$-Layout-RowKt$Row$1\\9\\622\\3":I
    .end local v27    # "$changed\\9":I
    .end local v28    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 636
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 601
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 637
    nop

    .line 595
    .end local v18    # "$i$f$ReusableComposeNode\\5\\599":I
    .end local v20    # "$changed\\5":I
    .end local v21    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 638
    nop

    .line 588
    .end local v12    # "$changed\\4":I
    .end local v13    # "$i$f$Layout\\4\\594":I
    .end local v14    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "compositeKeyHash\\4":I
    .end local v24    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 639
    nop

    .line 558
    .end local v9    # "$i$f$Row\\3\\554":I
    .end local v10    # "horizontalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v11    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v26    # "verticalAlignment\\3":Landroidx/compose/ui/Alignment$Vertical;
    .end local v30    # "$changed\\3":I
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x140

    .local v3, "$this$dp\\18":I
    const/4 v5, 0x0

    .line 640
    .local v5, "$i$f$getDp\\18\\558":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 558
    .end local v3    # "$this$dp\\18":I
    .end local v5    # "$i$f$getDp\\18\\558":I
    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v2, v5, v3, v7, v6}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/4 v2, 0x0

    invoke-static {v2, v1, v2, v7}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v9

    const/16 v13, 0xe

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v3, 0x10

    .local v3, "$this$dp\\19":I
    const/4 v7, 0x0

    .line 640
    .local v7, "$i$f$getDp\\19\\558":I
    int-to-float v8, v3

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 558
    .end local v3    # "$this$dp\\19":I
    .end local v7    # "$i$f$getDp\\19\\558":I
    const/4 v7, 0x2

    invoke-static {v2, v3, v5, v7, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\20":Landroidx/compose/ui/Modifier;
    iget-object v3, v0, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->$items:Ljava/util/List;

    iget-object v5, v0, Lorg/lighttouch/android/StoreScreenKt$QueueMenu$1;->$model:Lorg/lighttouch/android/StoreModel;

    const/4 v6, 0x0

    .local v6, "$changed\\20":I
    const/4 v7, 0x0

    .line 641
    .local v7, "$i$f$Column\\20\\558":I
    const v8, -0x1cd0f17e

    const-string v9, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v1, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 642
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 643
    .local v8, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 646
    .local v9, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v8, v9, v1, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 647
    nop

    .local v11, "$changed\\21":I
    const/4 v12, 0x0

    .line 648
    .local v12, "$i$f$Layout\\21\\647":I
    const v13, -0x4ee9b9da

    invoke-static {v1, v13, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 649
    const/4 v13, 0x0

    invoke-static {v1, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v14

    .line 650
    .local v14, "compositeKeyHash\\21":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 651
    .local v13, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v1, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 653
    .local v15, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v0, v11, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 652
    move-object/from16 v17, v16

    .local v0, "$changed\\22":I
    .local v17, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 654
    .local v16, "$i$f$ReusableComposeNode\\22\\652":I
    move/from16 v18, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\22":I
    .local v18, "$changed\\22":I
    invoke-static {v1, v0, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 655
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 656
    :cond_11
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 657
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_12

    .line 658
    move-object/from16 v0, v17

    .end local v17    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a

    .line 660
    .end local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v17    # "factory\\22":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v0, v17

    .end local v17    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 662
    :goto_a
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 663
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\662\\21":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v20, v0

    .end local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v20, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 664
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 666
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 667
    .local v19, "$i$f$set-impl\\24\\666":I
    move-object/from16 v21, v4

    .local v21, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 668
    .local v23, "$i$a$-with-Updater$set$1\\25\\667\\24":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_14

    move-object/from16 v24, v2

    .end local v2    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\20":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v25, v3

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_13

    goto :goto_b

    :cond_13
    move-object/from16 v3, v21

    goto :goto_c

    .end local v24    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .restart local v2    # "modifier\\20":Landroidx/compose/ui/Modifier;
    :cond_14
    move-object/from16 v24, v2

    move-object/from16 v25, v3

    .line 669
    .end local v2    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .restart local v24    # "modifier\\20":Landroidx/compose/ui/Modifier;
    :goto_b
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 670
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v4, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 672
    :goto_c
    nop

    .line 667
    .end local v3    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-with-Updater$set$1\\25\\667\\24":I
    nop

    .line 672
    nop

    .line 673
    .end local v0    # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\24\\666":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 674
    nop

    .line 662
    .end local v4    # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\662\\21":I
    nop

    .line 675
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\26":I
    move-object/from16 v2, p2

    .local v2, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 676
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\26\\675\\20":I
    const v4, -0x16ef5699

    move/from16 v17, v0

    .end local v0    # "$changed\\26":I
    .local v17, "$changed\\26":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v4, v6, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\27":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$invoke_u24lambda_u245\\27":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v19, v2

    .local v19, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 559
    .local v21, "$i$a$-Column-StoreScreenKt$QueueMenu$1$2\\27\\676\\0":I
    move-object/from16 v23, v0

    .end local v0    # "$this$invoke_u24lambda_u245\\27":Landroidx/compose/foundation/layout/ColumnScope;
    .local v23, "$this$invoke_u24lambda_u245\\27":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x5e40cad0

    move-object/from16 v26, v2

    .end local v2    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v26, "$composer\\26":Landroidx/compose/runtime/Composer;
    const-string v2, "C:StoreScreen.kt#o13vsk"

    move/from16 v27, v3

    move-object/from16 v3, v19

    .end local v19    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v27, "$i$a$-Layout-ColumnKt$Column$1\\26\\675\\20":I
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, -0x15bbd86d

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "*558@34639L21"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface/range {v25 .. v25}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/lighttouch/android/QueueItem;

    move-object/from16 v19, v0

    const/4 v0, 0x0

    .local v2, "item\\27":Lorg/lighttouch/android/QueueItem;
    invoke-static {v2, v5, v3, v0}, Lorg/lighttouch/android/StoreScreenKt;->access$QueueRow(Lorg/lighttouch/android/QueueItem;Lorg/lighttouch/android/StoreModel;Landroidx/compose/runtime/Composer;I)V

    move-object/from16 v0, v19

    .end local v2    # "item\\27":Lorg/lighttouch/android/QueueItem;
    goto :goto_d

    :cond_15
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 560
    nop

    .line 676
    .end local v3    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .end local v4    # "$changed\\27":I
    .end local v21    # "$i$a$-Column-StoreScreenKt$QueueMenu$1$2\\27\\676\\0":I
    .end local v23    # "$this$invoke_u24lambda_u245\\27":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 675
    .end local v17    # "$changed\\26":I
    .end local v26    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-Layout-ColumnKt$Column$1\\26\\675\\20":I
    nop

    .line 677
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 654
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 678
    nop

    .line 648
    .end local v16    # "$i$f$ReusableComposeNode\\22\\652":I
    .end local v18    # "$changed\\22":I
    .end local v20    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 679
    nop

    .line 641
    .end local v11    # "$changed\\21":I
    .end local v12    # "$i$f$Layout\\21\\647":I
    .end local v13    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "compositeKeyHash\\21":I
    .end local v15    # "materialized\\21":Landroidx/compose/ui/Modifier;
    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 680
    nop

    .line 561
    .end local v6    # "$changed\\20":I
    .end local v7    # "$i$f$Column\\20\\558":I
    .end local v8    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "modifier\\20":Landroidx/compose/ui/Modifier;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\28":I
    const/4 v3, 0x0

    .line 681
    .local v3, "$i$f$getDp\\28\\561":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 561
    .end local v2    # "$this$dp\\28":I
    .end local v3    # "$i$f$getDp\\28\\561":I
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v2, v22

    invoke-static {v0, v1, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 562
    :cond_16
    :goto_e
    return-void
.end method

.class public final Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;
.super Lkotlin/jvm/internal/Lambda;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/lighttouch/android/StoreScreenKt;->StoreDetails(Landroidx/compose/foundation/layout/ColumnScope;Lorg/lighttouch/android/StoreModel;Lorg/json/JSONObject;ZLandroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/Lambda;",
        "Lkotlin/jvm/functions/Function4<",
        "Landroidx/compose/foundation/lazy/LazyItemScope;",
        "Ljava/lang/Integer;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$4\n+ 2 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 6 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 7 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 8 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 9 Composer.kt\nandroidx/compose/runtime/Updater\n+ 10 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 11 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,433:1\n464#2:434\n465#2:439\n466#2:483\n467#2:490\n468#2,2:528\n470#2,2:531\n472#2:537\n473#2:542\n1788#3,4:435\n1225#4,6:440\n1225#4,6:484\n149#5:446\n99#6:447\n96#6,6:448\n102#6:482\n106#6:541\n79#7,6:454\n86#7,4:469\n90#7,2:479\n79#7,6:499\n86#7,4:514\n90#7,2:524\n94#7:535\n94#7:540\n368#8,9:460\n377#8:481\n368#8,9:505\n377#8:526\n378#8,2:533\n378#8,2:538\n4034#9,6:473\n4034#9,6:518\n86#10:491\n82#10,7:492\n89#10:527\n93#10:536\n1#11:530\n*S KotlinDebug\n*F\n+ 1 StoreScreen.kt\norg/lighttouch/android/StoreScreenKt\n*L\n464#1:435,4\n465#1:440,6\n466#1:484,6\n465#1:446\n465#1:447\n465#1:448,6\n465#1:482\n465#1:541\n465#1:454,6\n465#1:469,4\n465#1:479,2\n467#1:499,6\n467#1:514,4\n467#1:524,2\n467#1:535\n465#1:540\n465#1:460,9\n465#1:481\n467#1:505,9\n467#1:526\n467#1:533,2\n465#1:538,2\n465#1:473,6\n467#1:518,6\n467#1:491\n467#1:492,7\n467#1:527\n467#1:536\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0003\u0010\u0000\u001a\u00020\u0001\"\u0004\u0008\u0000\u0010\u0002*\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u000b\u00a2\u0006\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0008"
    }
    d2 = {
        "<anonymous>",
        "",
        "T",
        "Landroidx/compose/foundation/lazy/LazyItemScope;",
        "it",
        "",
        "invoke",
        "(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V",
        "androidx/compose/foundation/lazy/LazyDslKt$items$4"
    }
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $items:Ljava/util/List;

.field final synthetic $model$inlined:Lorg/lighttouch/android/StoreModel;

.field final synthetic $rows$inlined:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/util/List;Lorg/lighttouch/android/StoreModel;)V
    .locals 0

    iput-object p1, p0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$items:Ljava/util/List;

    iput-object p2, p0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$rows$inlined:Ljava/util/List;

    iput-object p3, p0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$model$inlined:Lorg/lighttouch/android/StoreModel;

    const/4 p2, 0x4

    invoke-direct {p0, p2}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;
    .param p4, "p4"    # Ljava/lang/Object;

    .line 152
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/lazy/LazyItemScope;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    move-object v2, p3

    check-cast v2, Landroidx/compose/runtime/Composer;

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V
    .locals 82
    .param p1, "$this$items"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "it"    # I
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move/from16 v1, p2

    move-object/from16 v2, p3

    const-string v3, "C152@7074L22:LazyDsl.kt#428nma"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p4

    .local v3, "$dirty":I
    and-int/lit8 v4, p4, 0x6

    if-nez v4, :cond_1

    move-object/from16 v4, p1

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v3, v6

    goto :goto_1

    :cond_1
    move-object/from16 v4, p1

    :goto_1
    and-int/lit8 v6, p4, 0x30

    const/16 v7, 0x20

    if-nez v6, :cond_3

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_2

    move v6, v7

    goto :goto_2

    :cond_2
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v3, v6

    .line 153
    :cond_3
    and-int/lit16 v6, v3, 0x93

    const/16 v8, 0x92

    if-ne v6, v8, :cond_5

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_4

    goto :goto_3

    :cond_4
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v24, v3

    goto/16 :goto_19

    :cond_5
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, -0x1

    const-string v8, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:152)"

    const v9, -0x25b7f321

    invoke-static {v9, v3, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_6
    iget-object v6, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$items:Ljava/util/List;

    invoke-interface {v6, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    and-int/lit8 v8, v3, 0xe

    .local v8, "$changed\\1":I
    check-cast v6, Lorg/lighttouch/android/StoreCopy;

    .local v6, "copy\\1":Lorg/lighttouch/android/StoreCopy;
    move-object/from16 v9, p1

    .local v9, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475\\1":Landroidx/compose/foundation/lazy/LazyItemScope;
    move-object/from16 v10, p3

    .local v10, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 434
    .local v11, "$i$a$-items$default-StoreScreenKt$StoreDetails$1$2$2$1$2\\1\\153\\0":I
    const v12, 0x3fb45cef

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v12, "C*464@28599L28,464@28561L741:StoreScreen.kt#o13vsk"

    invoke-static {v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v12, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$rows$inlined:Ljava/util/List;

    if-eqz v12, :cond_7

    iget-object v12, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$rows$inlined:Ljava/util/List;

    goto :goto_4

    :cond_7
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v12

    :goto_4
    check-cast v12, Ljava/lang/Iterable;

    .local v12, "$this$count\\2":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 435
    .local v13, "$i$f$count\\2\\434":I
    instance-of v14, v12, Ljava/util/Collection;

    if-eqz v14, :cond_8

    move-object v14, v12

    check-cast v14, Ljava/util/Collection;

    invoke-interface {v14}, Ljava/util/Collection;->isEmpty()Z

    move-result v14

    if-eqz v14, :cond_8

    const/4 v14, 0x0

    goto :goto_6

    .line 436
    :cond_8
    const/4 v14, 0x0

    .line 437
    .local v14, "count\\2":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :cond_9
    :goto_5
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_a

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    .local v17, "element\\2":Ljava/lang/Object;
    move-object/from16 v18, v17

    check-cast v18, Lorg/lighttouch/android/StoreCopy;

    .local v18, "it\\3":Lorg/lighttouch/android/StoreCopy;
    const/16 v19, 0x0

    .line 434
    .local v19, "$i$a$-count-StoreScreenKt$StoreDetails$1$2$2$1$2$twin$1\\3\\437\\1":I
    invoke-virtual/range {v18 .. v18}, Lorg/lighttouch/android/StoreCopy;->getVersion()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreCopy;->getVersion()Ljava/lang/String;

    move-result-object v15

    invoke-static {v5, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    .line 437
    .end local v18    # "it\\3":Lorg/lighttouch/android/StoreCopy;
    .end local v19    # "$i$a$-count-StoreScreenKt$StoreDetails$1$2$2$1$2$twin$1\\3\\437\\1":I
    if-eqz v5, :cond_9

    add-int/lit8 v14, v14, 0x1

    if-gez v14, :cond_9

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwCountOverflow()V

    .end local v17    # "element\\2":Ljava/lang/Object;
    goto :goto_5

    .line 438
    :cond_a
    nop

    .line 434
    .end local v12    # "$this$count\\2":Ljava/lang/Iterable;
    .end local v13    # "$i$f$count\\2\\434":I
    .end local v14    # "count\\2":I
    :goto_6
    const/4 v5, 0x1

    if-le v14, v5, :cond_b

    move v12, v5

    goto :goto_7

    :cond_b
    const/4 v12, 0x0

    .line 439
    .local v12, "twin\\1":Z
    :goto_7
    sget-object v13, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v13, Landroidx/compose/ui/Modifier;

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-static {v13, v14, v5, v15}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v22

    const v13, -0x615d173a

    invoke-interface {v10, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v14, "CC(remember):StoreScreen.kt#9igjgp"

    invoke-static {v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v16, v5

    iget-object v5, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$model$inlined:Lorg/lighttouch/android/StoreModel;

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    and-int/lit8 v17, v8, 0x70

    xor-int/lit8 v15, v17, 0x30

    if-le v15, v7, :cond_c

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_d

    :cond_c
    and-int/lit8 v15, v8, 0x30

    if-ne v15, v7, :cond_e

    :cond_d
    move/from16 v15, v16

    goto :goto_8

    :cond_e
    const/4 v15, 0x0

    :goto_8
    or-int/2addr v5, v15

    .local v5, "invalid\\4":Z
    move-object v15, v10

    .local v15, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 440
    .local v17, "$i$f$cache\\4\\439":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\4":Ljava/lang/Object;
    const/16 v23, 0x0

    .line 441
    .local v23, "$i$a$-let-ComposerKt$cache$1\\5\\440\\4":I
    if-nez v5, :cond_10

    sget-object v24, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v24 .. v24}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v7, v13, :cond_f

    goto :goto_9

    .line 445
    :cond_f
    move-object v1, v7

    goto :goto_a

    .line 442
    :cond_10
    :goto_9
    const/4 v13, 0x0

    .line 439
    .local v13, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2$1$2$1\\6\\442\\1":I
    new-instance v1, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$2$2$1$2$1$1;

    iget-object v2, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$model$inlined:Lorg/lighttouch/android/StoreModel;

    invoke-direct {v1, v2, v6}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$2$2$1$2$1$1;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/StoreCopy;)V

    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 442
    .end local v13    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2$1$2$1\\6\\442\\1":I
    nop

    .line 443
    .local v1, "value\\5":Ljava/lang/Object;
    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 444
    nop

    .line 441
    .end local v1    # "value\\5":Ljava/lang/Object;
    :goto_a
    nop

    .line 440
    .end local v7    # "it\\4":Ljava/lang/Object;
    .end local v23    # "$i$a$-let-ComposerKt$cache$1\\5\\440\\4":I
    nop

    .line 439
    .end local v5    # "invalid\\4":Z
    .end local v15    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$f$cache\\4\\439":I
    move-object/from16 v26, v1

    check-cast v26, Lkotlin/jvm/functions/Function0;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v27, 0x7

    const/16 v28, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    invoke-static/range {v22 .. v28}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v2, 0x8

    .local v2, "$this$dp\\7":I
    const/4 v5, 0x0

    .line 446
    .local v5, "$i$f$getDp\\7\\439":I
    int-to-float v7, v2

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 439
    .end local v2    # "$this$dp\\7":I
    .end local v5    # "$i$f$getDp\\7\\439":I
    const/4 v5, 0x2

    .local v5, "$this$dp\\8":I
    const/4 v7, 0x0

    .line 446
    .local v7, "$i$f$getDp\\8\\439":I
    int-to-float v13, v5

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 439
    .end local v5    # "$this$dp\\8":I
    .end local v7    # "$i$f$getDp\\8\\439":I
    invoke-static {v1, v2, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\9":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v2

    .local v2, "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v5, 0x180

    .local v5, "$changed\\9":I
    const/4 v7, 0x0

    .line 447
    .local v7, "$i$f$Row\\9\\439":I
    const v13, 0x2952b718

    const-string v15, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v10, v13, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 448
    sget-object v13, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v13}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v13

    .line 452
    .local v13, "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v15, v5, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v17, v5, 0x3

    and-int/lit8 v17, v17, 0x70

    or-int v15, v15, v17

    invoke-static {v13, v2, v10, v15}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .local v15, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v5, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 453
    nop

    .local v17, "$changed\\10":I
    const/16 v22, 0x0

    .line 454
    .local v22, "$i$f$Layout\\10\\453":I
    move-object/from16 v23, v2

    .end local v2    # "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .local v23, "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    const v2, -0x4ee9b9da

    move/from16 v24, v3

    .end local v3    # "$dirty":I
    .local v24, "$dirty":I
    const-string v3, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 455
    const/4 v2, 0x0

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v26

    .line 456
    .local v26, "compositeKeyHash\\10":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 457
    .local v2, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 459
    .local v4, "materialized\\10":Landroidx/compose/ui/Modifier;
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v27

    move-object/from16 v28, v1

    .end local v1    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .local v28, "modifier\\9":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v17, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 458
    nop

    .local v1, "$changed\\11":I
    move-object/from16 v30, v27

    .local v30, "factory\\11":Lkotlin/jvm/functions/Function0;
    const/16 v27, 0x0

    .line 460
    .local v27, "$i$f$ReusableComposeNode\\11\\458":I
    move/from16 v31, v1

    .end local v1    # "$changed\\11":I
    .local v31, "$changed\\11":I
    const v1, -0x2942ffcf

    move/from16 v32, v5

    .end local v5    # "$changed\\9":I
    .local v32, "$changed\\9":I
    const-string v5, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v1, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 461
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_11

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 462
    :cond_11
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 463
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_12

    .line 464
    move-object/from16 v1, v30

    .end local v30    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b

    .line 466
    .end local v1    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :cond_12
    move-object/from16 v1, v30

    .end local v30    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 468
    :goto_b
    move-object/from16 v30, v1

    .end local v1    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 469
    .local v34, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\468\\10":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v36, v7

    .end local v7    # "$i$f$Row\\9\\439":I
    .local v36, "$i$f$Row\\9\\439":I
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v1, v15, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 470
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v1, v2, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 472
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\13":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 473
    .local v35, "$i$f$set-impl\\13\\472":I
    move-object/from16 v37, v1

    .local v37, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 474
    .local v38, "$i$a$-with-Updater$set$1\\14\\473\\13":I
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v39

    if-nez v39, :cond_14

    move-object/from16 v39, v2

    .end local v2    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v39, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v40, v8

    .end local v8    # "$changed\\1":I
    .local v40, "$changed\\1":I
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v2, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_13

    goto :goto_c

    :cond_13
    move-object/from16 v8, v37

    goto :goto_d

    .end local v39    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v40    # "$changed\\1":I
    .restart local v2    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v8    # "$changed\\1":I
    :cond_14
    move-object/from16 v39, v2

    move/from16 v40, v8

    .line 475
    .end local v2    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v8    # "$changed\\1":I
    .restart local v39    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v40    # "$changed\\1":I
    :goto_c
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v8, v37

    .end local v37    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 476
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 478
    :goto_d
    nop

    .line 473
    .end local v8    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v38    # "$i$a$-with-Updater$set$1\\14\\473\\13":I
    nop

    .line 478
    nop

    .line 479
    .end local v7    # "block\\13":Lkotlin/jvm/functions/Function2;
    .end local v35    # "$i$f$set-impl\\13\\472":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v4, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 480
    nop

    .line 468
    .end local v1    # "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\468\\10":I
    nop

    .line 481
    shr-int/lit8 v1, v31, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\15":I
    move-object v2, v10

    .local v2, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 482
    .local v7, "$i$a$-Layout-RowKt$Row$1\\15\\481\\9":I
    const v8, -0x184f2606

    move/from16 v34, v1

    .end local v1    # "$changed\\15":I
    .local v34, "$changed\\15":I
    const-string v1, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v2, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v8, v32, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\16":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474\\16":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v47, v2

    .local v47, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 483
    .local v35, "$i$a$-Row-StoreScreenKt$StoreDetails$1$2$2$1$2$2\\16\\482\\1":I
    move-object/from16 v37, v1

    .end local v1    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474\\16":Landroidx/compose/foundation/layout/RowScope;
    .local v37, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474\\16":Landroidx/compose/foundation/layout/RowScope;
    const v1, -0x5895aabf

    move-object/from16 v38, v2

    .end local v2    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\15":Landroidx/compose/runtime/Composer;
    const-string v2, "C465@28789L28,465@28747L71,466@28843L437:StoreScreen.kt#o13vsk"

    move-object/from16 v50, v4

    move-object/from16 v4, v47

    .end local v47    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v50, "materialized\\10":Landroidx/compose/ui/Modifier;
    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$model$inlined:Lorg/lighttouch/android/StoreModel;

    invoke-virtual {v1}, Lorg/lighttouch/android/StoreModel;->getSelected()Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v2

    if-nez v1, :cond_15

    goto :goto_e

    :cond_15
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, v2, :cond_16

    move/from16 v41, v16

    goto :goto_f

    :cond_16
    :goto_e
    const/16 v41, 0x0

    :goto_f
    const v1, -0x615d173a

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v4, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v1, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$model$inlined:Lorg/lighttouch/android/StoreModel;

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    and-int/lit8 v2, v40, 0x70

    xor-int/lit8 v2, v2, 0x30

    const/16 v14, 0x20

    if-le v2, v14, :cond_17

    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_18

    :cond_17
    and-int/lit8 v2, v40, 0x30

    const/16 v14, 0x20

    if-ne v2, v14, :cond_19

    :cond_18
    move/from16 v2, v16

    goto :goto_10

    :cond_19
    const/4 v2, 0x0

    :goto_10
    or-int/2addr v1, v2

    .local v1, "invalid\\17":Z
    move-object v2, v4

    .local v2, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 484
    .local v14, "$i$f$cache\\17\\483":I
    move/from16 v19, v1

    .end local v1    # "invalid\\17":Z
    .local v19, "invalid\\17":Z
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\17":Ljava/lang/Object;
    const/16 v29, 0x0

    .line 485
    .local v29, "$i$a$-let-ComposerKt$cache$1\\18\\484\\17":I
    if-nez v19, :cond_1b

    sget-object v42, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v47, v4

    .end local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v42 .. v42}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v1, v4, :cond_1a

    goto :goto_11

    .line 489
    :cond_1a
    move-object/from16 v42, v1

    goto :goto_12

    .line 485
    .end local v47    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :cond_1b
    move-object/from16 v47, v4

    .line 486
    .end local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :goto_11
    const/4 v4, 0x0

    .line 483
    .local v4, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2$1$2$2$1\\19\\486\\16":I
    move-object/from16 v42, v1

    .end local v1    # "it\\17":Ljava/lang/Object;
    .local v42, "it\\17":Ljava/lang/Object;
    new-instance v1, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$2$2$1$2$2$1$1;

    move/from16 v43, v4

    .end local v4    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2$1$2$2$1\\19\\486\\16":I
    .local v43, "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2$1$2$2$1\\19\\486\\16":I
    iget-object v4, v0, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$lambda$85$lambda$78$lambda$77$lambda$76$$inlined$items$default$4;->$model$inlined:Lorg/lighttouch/android/StoreModel;

    invoke-direct {v1, v4, v6}, Lorg/lighttouch/android/StoreScreenKt$StoreDetails$1$2$2$1$2$2$1$1;-><init>(Lorg/lighttouch/android/StoreModel;Lorg/lighttouch/android/StoreCopy;)V

    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 486
    .end local v43    # "$i$a$-cache-StoreScreenKt$StoreDetails$1$2$2$1$2$2$1\\19\\486\\16":I
    nop

    .line 487
    .local v1, "value\\18":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 488
    nop

    .line 485
    .end local v1    # "value\\18":Ljava/lang/Object;
    :goto_12
    nop

    .line 484
    .end local v29    # "$i$a$-let-ComposerKt$cache$1\\18\\484\\17":I
    .end local v42    # "it\\17":Ljava/lang/Object;
    nop

    .line 483
    .end local v2    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\17\\483":I
    .end local v19    # "invalid\\17":Z
    move-object/from16 v42, v1

    check-cast v42, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v47 .. v47}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/16 v48, 0x0

    const/16 v49, 0x3c

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    invoke-static/range {v41 .. v49}, Landroidx/compose/material3/RadioButtonKt;->RadioButton(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/RadioButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;II)V

    .line 490
    move-object/from16 v4, v47

    .end local v47    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    move/from16 v1, v21

    .local v1, "$changed\\20":I
    const/4 v2, 0x0

    .line 491
    .local v2, "$i$f$Column\\20\\490":I
    const v14, -0x1cd0f17e

    const-string v0, "CC(Column)P(2,3,1)86@4330L61,87@4396L133:Column.kt#2w3rfo"

    invoke-static {v4, v14, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 492
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 493
    .local v0, "modifier\\20":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v14}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v14

    .line 494
    .local v14, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v19, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move/from16 v29, v1

    .end local v1    # "$changed\\20":I
    .local v29, "$changed\\20":I
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v1

    .line 497
    .local v1, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v19, v29, 0x3

    and-int/lit8 v19, v19, 0xe

    shr-int/lit8 v41, v29, 0x3

    and-int/lit8 v41, v41, 0x70

    move/from16 v42, v2

    .end local v2    # "$i$f$Column\\20\\490":I
    .local v42, "$i$f$Column\\20\\490":I
    or-int v2, v19, v41

    invoke-static {v14, v1, v4, v2}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v2

    .local v2, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v19, v29, 0x3

    and-int/lit8 v19, v19, 0x70

    .line 498
    nop

    .local v19, "$changed\\21":I
    const/16 v41, 0x0

    .line 499
    .local v41, "$i$f$Layout\\21\\498":I
    move-object/from16 v43, v1

    const v1, -0x4ee9b9da

    .end local v1    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .local v43, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 500
    const/4 v1, 0x0

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v3

    .line 501
    .local v3, "compositeKeyHash\\21":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 502
    .local v1, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v25, v3

    .end local v3    # "compositeKeyHash\\21":I
    .local v25, "compositeKeyHash\\21":I
    invoke-static {v4, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 504
    .local v3, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v44, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v44 .. v44}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v44

    move-object/from16 v45, v0

    .end local v0    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v45, "modifier\\20":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v19, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 503
    nop

    .local v0, "$changed\\22":I
    move-object/from16 v46, v44

    .local v46, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v44, 0x0

    .line 505
    .local v44, "$i$f$ReusableComposeNode\\22\\503":I
    move/from16 v47, v0

    const v0, -0x2942ffcf

    .end local v0    # "$changed\\22":I
    .local v47, "$changed\\22":I
    invoke-static {v4, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 506
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 507
    :cond_1c
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 508
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 509
    move-object/from16 v0, v46

    .end local v46    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_13

    .line 511
    .end local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v46    # "factory\\22":Lkotlin/jvm/functions/Function0;
    :cond_1d
    move-object/from16 v0, v46

    .end local v46    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 513
    :goto_13
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 514
    .local v33, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\513\\21":I
    sget-object v46, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v48, v0

    .end local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v48, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v46 .. v46}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 515
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 517
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v46, 0x0

    .line 518
    .local v46, "$i$f$set-impl\\24\\517":I
    move-object/from16 v49, v5

    .local v49, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 519
    .local v51, "$i$a$-with-Updater$set$1\\25\\518\\24":I
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v52

    if-nez v52, :cond_1f

    move-object/from16 v52, v1

    .end local v1    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v52, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v53, v2

    .end local v2    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v53, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    goto :goto_14

    :cond_1e
    move-object/from16 v2, v49

    goto :goto_15

    .end local v52    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v53    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v1    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v2    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_1f
    move-object/from16 v52, v1

    move-object/from16 v53, v2

    .line 520
    .end local v1    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v2    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v52    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v53    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_14
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v49

    .end local v49    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 521
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v5, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 523
    :goto_15
    nop

    .line 518
    .end local v2    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-with-Updater$set$1\\25\\518\\24":I
    nop

    .line 523
    nop

    .line 524
    .end local v0    # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v46    # "$i$f$set-impl\\24\\517":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 525
    nop

    .line 513
    .end local v5    # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\513\\21":I
    nop

    .line 526
    shr-int/lit8 v0, v47, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\26":I
    move-object v1, v4

    .local v1, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 527
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\26\\526\\20":I
    const v5, -0x16ef5699

    move/from16 v33, v0

    .end local v0    # "$changed\\26":I
    .local v33, "$changed\\26":I
    const-string v0, "C88@4444L9:Column.kt#2w3rfo"

    invoke-static {v1, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v29, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\27":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474_u24lambda_u2473\\27":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v75, v1

    .local v75, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 528
    .local v46, "$i$a$-Column-StoreScreenKt$StoreDetails$1$2$2$1$2$2$2\\27\\527\\16":I
    move-object/from16 v49, v0

    .end local v0    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474_u24lambda_u2473\\27":Landroidx/compose/foundation/layout/ColumnScope;
    .local v49, "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474_u24lambda_u2473\\27":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x50505276

    move-object/from16 v51, v1

    .end local v1    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\26":Landroidx/compose/runtime/Composer;
    const-string v1, "C467@28965L10,467@28880L106,469@29181L10,469@29225L11,468@29015L239:StoreScreen.kt#o13vsk"

    move/from16 v79, v2

    move-object/from16 v2, v75

    .end local v75    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v79, "$i$a$-Layout-ColumnKt$Column$1\\26\\526\\20":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreCopy;->getVersion()Ljava/lang/String;

    move-result-object v0

    if-eqz v12, :cond_20

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreCopy;->getIpaId()I

    move-result v1

    move-object/from16 v80, v3

    .end local v3    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v80, "materialized\\21":Landroidx/compose/ui/Modifier;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v81, v4

    .end local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v81, "$composer\\16":Landroidx/compose/runtime/Composer;
    const-string v4, " \u00b7 \u590d\u5236 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_16

    .end local v80    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v81    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v3    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .restart local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :cond_20
    move-object/from16 v80, v3

    move-object/from16 v81, v4

    .end local v3    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v4    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v80    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .restart local v81    # "$composer\\16":Landroidx/compose/runtime/Composer;
    const-string v1, ""

    :goto_16
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v54

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v74

    const/16 v77, 0x0

    const v78, 0xfffe

    const/16 v55, 0x0

    const-wide/16 v56, 0x0

    const-wide/16 v58, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const-wide/16 v63, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v76, 0x0

    move-object/from16 v75, v2

    .end local v2    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .restart local v75    # "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static/range {v54 .. v78}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 529
    .end local v75    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\27":Landroidx/compose/runtime/Composer;
    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreCopy;->getSize()Ljava/lang/Long;

    move-result-object v1

    if-eqz v1, :cond_21

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    .line 530
    nop

    .local v3, "p0\\28":J
    const/4 v1, 0x0

    .line 529
    .local v1, "$i$a$-let-StoreScreenKt$StoreDetails$1$2$2$1$2$2$2$1\\28\\529\\27":I
    invoke-static {v3, v4}, Lorg/lighttouch/android/StoreScreenKt;->byteSize(J)Ljava/lang/String;

    move-result-object v1

    .end local v1    # "$i$a$-let-StoreScreenKt$StoreDetails$1$2$2$1$2$2$2$1\\28\\529\\27":I
    .end local v3    # "p0\\28":J
    goto :goto_17

    :cond_21
    const/4 v1, 0x0

    :goto_17
    const/16 v21, 0x0

    aput-object v1, v0, v21

    invoke-virtual {v6}, Lorg/lighttouch/android/StoreCopy;->getMinimumOS()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_22

    .line 530
    nop

    .local v1, "it\\29":Ljava/lang/String;
    const/4 v3, 0x0

    .line 529
    .local v3, "$i$a$-let-StoreScreenKt$StoreDetails$1$2$2$1$2$2$2$2\\29\\529\\27":I
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v20, v0

    const-string v0, "iOS "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, " \u6216\u66f4\u9ad8\u7248\u672c"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v1    # "it\\29":Ljava/lang/String;
    .end local v3    # "$i$a$-let-StoreScreenKt$StoreDetails$1$2$2$1$2$2$2$2\\29\\529\\27":I
    goto :goto_18

    :cond_22
    move-object/from16 v20, v0

    const/4 v0, 0x0

    :goto_18
    aput-object v0, v20, v16

    invoke-static/range {v20 .. v20}, Lkotlin/collections/CollectionsKt;->listOfNotNull([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    move-object/from16 v54, v0

    check-cast v54, Ljava/lang/Iterable;

    const-string v0, " \u00b7 "

    move-object/from16 v55, v0

    check-cast v55, Ljava/lang/CharSequence;

    const/16 v61, 0x3e

    const/16 v62, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    invoke-static/range {v54 .. v62}, Lkotlin/collections/CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v54

    .line 531
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v74

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v56

    .line 529
    nop

    .line 531
    nop

    .line 529
    const/16 v55, 0x0

    const-wide/16 v58, 0x0

    const/16 v61, 0x0

    const-wide/16 v63, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const v78, 0xfffa

    move-object/from16 v75, v2

    .end local v2    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .restart local v75    # "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static/range {v54 .. v78}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 528
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 532
    nop

    .line 527
    .end local v5    # "$changed\\27":I
    .end local v46    # "$i$a$-Column-StoreScreenKt$StoreDetails$1$2$2$1$2$2$2\\27\\527\\16":I
    .end local v49    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474_u24lambda_u2473\\27":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v75    # "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 526
    .end local v33    # "$changed\\26":I
    .end local v51    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v79    # "$i$a$-Layout-ColumnKt$Column$1\\26\\526\\20":I
    nop

    .line 533
    invoke-interface/range {v81 .. v81}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 505
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 534
    nop

    .line 499
    .end local v44    # "$i$f$ReusableComposeNode\\22\\503":I
    .end local v47    # "$changed\\22":I
    .end local v48    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 535
    nop

    .line 491
    .end local v19    # "$changed\\21":I
    .end local v25    # "compositeKeyHash\\21":I
    .end local v41    # "$i$f$Layout\\21\\498":I
    .end local v52    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v80    # "materialized\\21":Landroidx/compose/ui/Modifier;
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 536
    nop

    .line 483
    .end local v14    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v29    # "$changed\\20":I
    .end local v42    # "$i$f$Column\\20\\490":I
    .end local v43    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v45    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .end local v53    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v81 .. v81}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 537
    nop

    .line 482
    .end local v8    # "$changed\\16":I
    .end local v35    # "$i$a$-Row-StoreScreenKt$StoreDetails$1$2$2$1$2$2\\16\\482\\1":I
    .end local v37    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475_u24lambda_u2474\\16":Landroidx/compose/foundation/layout/RowScope;
    .end local v81    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 481
    .end local v7    # "$i$a$-Layout-RowKt$Row$1\\15\\481\\9":I
    .end local v34    # "$changed\\15":I
    .end local v38    # "$composer\\15":Landroidx/compose/runtime/Composer;
    nop

    .line 538
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 460
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 539
    nop

    .line 454
    .end local v27    # "$i$f$ReusableComposeNode\\11\\458":I
    .end local v30    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .end local v31    # "$changed\\11":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 540
    nop

    .line 447
    .end local v17    # "$changed\\10":I
    .end local v22    # "$i$f$Layout\\10\\453":I
    .end local v26    # "compositeKeyHash\\10":I
    .end local v39    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "materialized\\10":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 541
    nop

    .end local v13    # "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v15    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .end local v28    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .end local v32    # "$changed\\9":I
    .end local v36    # "$i$f$Row\\9\\439":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 542
    .end local v12    # "twin\\1":Z
    nop

    .line 153
    .end local v6    # "copy\\1":Lorg/lighttouch/android/StoreCopy;
    .end local v9    # "$this$StoreDetails_u24lambda_u2485_u24lambda_u2478_u24lambda_u2477_u24lambda_u2476_u24lambda_u2475\\1":Landroidx/compose/foundation/lazy/LazyItemScope;
    .end local v10    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$a$-items$default-StoreScreenKt$StoreDetails$1$2$2$1$2\\1\\153\\0":I
    .end local v40    # "$changed\\1":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 154
    :cond_23
    :goto_19
    return-void
.end method

.class public final Lorg/lighttouch/android/HitchDataKt;
.super Ljava/lang/Object;
.source "HitchData.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHitchData.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HitchData.kt\norg/lighttouch/android/HitchDataKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 ReadWrite.kt\nkotlin/io/TextStreamsKt\n+ 5 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n*L\n1#1,198:1\n1#2:199\n1#2:207\n1878#3,3:200\n1068#3:203\n1869#3,2:204\n57#4:206\n1321#5,2:208\n*S KotlinDebug\n*F\n+ 1 HitchData.kt\norg/lighttouch/android/HitchDataKt\n*L\n173#1:207\n157#1:200,3\n160#1:203\n161#1:204,2\n173#1:206\n173#1:208,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\u001a(\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\u0008\u001a\u00020\u0007H\u0000\u00a8\u0006\t"
    }
    d2 = {
        "saveHitchReport",
        "Landroid/net/Uri;",
        "context",
        "Landroid/content/Context;",
        "data",
        "Lorg/lighttouch/android/HitchData;",
        "from",
        "",
        "to",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$ES0CnW4xfWXS94aA7ljz9Ulq_GY(JJLorg/lighttouch/android/RangeStats;Lorg/lighttouch/android/HitchData;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$lambda$22(JJLorg/lighttouch/android/RangeStats;Lorg/lighttouch/android/HitchData;Ljava/io/OutputStream;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Iols4JUrr7b4dc8XPKBa0CAx__A(Lorg/lighttouch/android/HitchData;JJLorg/lighttouch/android/RangeStats;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$lambda$6(Lorg/lighttouch/android/HitchData;JJLorg/lighttouch/android/RangeStats;Ljava/io/OutputStream;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$aTg4X8Zv_81v780bITzIs58c2Lk(Lorg/lighttouch/android/HitchData;JJLjava/io/OutputStream;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$lambda$8(Lorg/lighttouch/android/HitchData;JJLjava/io/OutputStream;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g_pkRWo1AJtpPRWiK2l2ffj_bK4(Ljava/io/File;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$lambda$17$lambda$16(Ljava/io/File;Ljava/io/OutputStream;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$usDlLNGx62yxRSOeo7wsy6EfG_A(Ljava/io/File;JJLjava/io/OutputStream;)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p5}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$lambda$13$lambda$12(Ljava/io/File;JJLjava/io/OutputStream;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$xKyxkur_2_38wELGC3Zq4R4A5FA(Ljava/io/File;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$lambda$21$lambda$20(Ljava/io/File;Ljava/io/OutputStream;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final saveHitchReport(Landroid/content/Context;Lorg/lighttouch/android/HitchData;JJ)Landroid/net/Uri;
    .locals 26
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "data"    # Lorg/lighttouch/android/HitchData;
    .param p2, "from"    # J
    .param p4, "to"    # J

    const-string v0, "engine.log"

    const-string v1, "events.tsv"

    const-string v2, "context"

    move-object/from16 v3, p0

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "data"

    move-object/from16 v5, p1

    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 133
    sget-object v2, Lorg/lighttouch/android/RangeStats;->Companion:Lorg/lighttouch/android/RangeStats$Companion;

    invoke-virtual/range {p1 .. p5}, Lorg/lighttouch/android/HitchData;->framesIn(JJ)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/lighttouch/android/RangeStats$Companion;->of(Ljava/util/List;)Lorg/lighttouch/android/RangeStats;

    move-result-object v10

    .line 134
    .local v10, "stats":Lorg/lighttouch/android/RangeStats;
    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v4, "yyyyMMdd-HHmmss"

    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-direct {v2, v4, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v4, Ljava/util/Date;

    invoke-direct {v4}, Ljava/util/Date;-><init>()V

    invoke-virtual {v2, v4}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    .line 136
    .local v2, "stamp":Ljava/lang/String;
    invoke-virtual {v5}, Lorg/lighttouch/android/HitchData;->getAppName()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v6

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-nez v6, :cond_0

    move v6, v11

    goto :goto_0

    :cond_0
    move v6, v12

    :goto_0
    const/4 v13, 0x2

    const/4 v14, 0x0

    if-eqz v6, :cond_1

    .line 199
    const/4 v4, 0x0

    .line 136
    .local v4, "$i$a$-ifEmpty-HitchDataKt$saveHitchReport$app$1\\1\\136\\0":I
    invoke-virtual {v5}, Lorg/lighttouch/android/HitchData;->getBundleId()Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x2e

    invoke-static {v6, v7, v14, v13, v14}, Lkotlin/text/StringsKt;->substringAfterLast$default(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    .end local v4    # "$i$a$-ifEmpty-HitchDataKt$saveHitchReport$app$1\\1\\136\\0":I
    :cond_1
    check-cast v4, Ljava/lang/CharSequence;

    .line 137
    new-instance v6, Lkotlin/text/Regex;

    const-string v7, "[^A-Za-z0-9]+"

    invoke-direct {v6, v7}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const-string v7, "-"

    invoke-virtual {v6, v4, v7}, Lkotlin/text/Regex;->replace(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v6, v11, [C

    const/16 v8, 0x2d

    aput-char v8, v6, v12

    invoke-static {v4, v6}, Lkotlin/text/StringsKt;->trim(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0x28

    invoke-static {v4, v6}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    .line 136
    move-object v15, v4

    .line 138
    .local v15, "app":Ljava/lang/String;
    move-object v4, v15

    check-cast v4, Ljava/lang/CharSequence;

    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-nez v4, :cond_2

    move v4, v11

    goto :goto_1

    :cond_2
    move v4, v12

    :goto_1
    if-eqz v4, :cond_3

    const-string v4, ""

    goto :goto_2

    :cond_3
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_2
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "lighttouch-hitch-"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, ".zip"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 139
    .local v4, "name":Ljava/lang/String;
    new-instance v6, Landroid/content/ContentValues;

    invoke-direct {v6}, Landroid/content/ContentValues;-><init>()V

    move-object v7, v6

    .local v7, "$this$saveHitchReport_u24lambda_u241\\2":Landroid/content/ContentValues;
    const/4 v8, 0x0

    .line 140
    .local v8, "$i$a$-apply-HitchDataKt$saveHitchReport$values$1\\2\\139\\0":I
    const-string v9, "_display_name"

    invoke-virtual {v7, v9, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v9, "mime_type"

    move/from16 v16, v11

    const-string v11, "application/zip"

    invoke-virtual {v7, v9, v11}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 141
    const-string v9, "relative_path"

    const-string v11, "Download/LightTouch"

    invoke-virtual {v7, v9, v11}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    const-string v11, "is_pending"

    invoke-virtual {v7, v11, v9}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 142
    nop

    .line 139
    .end local v7    # "$this$saveHitchReport_u24lambda_u241\\2":Landroid/content/ContentValues;
    .end local v8    # "$i$a$-apply-HitchDataKt$saveHitchReport$values$1\\2\\139\\0":I
    nop

    .line 143
    .local v6, "values":Landroid/content/ContentValues;
    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v7

    .line 144
    .local v7, "resolver":Landroid/content/ContentResolver;
    sget-object v8, Landroid/provider/MediaStore$Downloads;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-virtual {v7, v8, v6}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v8

    if-eqz v8, :cond_e

    .line 145
    .local v8, "uri":Landroid/net/Uri;
    nop

    .line 146
    :try_start_0
    invoke-virtual {v7, v8}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v9

    if-eqz v9, :cond_d

    check-cast v9, Ljava/io/Closeable;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    move-object/from16 v17, v9

    check-cast v17, Ljava/io/OutputStream;

    move-object/from16 v18, v17

    .line 199
    .local v18, "raw\\3":Ljava/io/OutputStream;
    const/16 v17, 0x0

    .line 146
    .local v17, "$i$a$-use-HitchDataKt$saveHitchReport$1\\3\\146\\0":I
    move/from16 v19, v12

    new-instance v12, Ljava/util/zip/ZipOutputStream;

    move/from16 v20, v13

    move-object/from16 v13, v18

    .end local v18    # "raw\\3":Ljava/io/OutputStream;
    .local v13, "raw\\3":Ljava/io/OutputStream;
    invoke-direct {v12, v13}, Ljava/util/zip/ZipOutputStream;-><init>(Ljava/io/OutputStream;)V

    check-cast v12, Ljava/io/Closeable;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_9

    :try_start_2
    move-object/from16 v18, v12

    check-cast v18, Ljava/util/zip/ZipOutputStream;

    move-object/from16 v21, v18

    .local v21, "zip\\4":Ljava/util/zip/ZipOutputStream;
    const/16 v18, 0x0

    .line 148
    .local v18, "$i$a$-use-HitchDataKt$saveHitchReport$1$1\\4\\146\\3":I
    const-string v14, "summary.txt"
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_6

    move-object/from16 v22, v4

    .end local v4    # "name":Ljava/lang/String;
    .local v22, "name":Ljava/lang/String;
    :try_start_3
    new-instance v4, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda0;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_5

    move-object/from16 v24, v2

    move-object/from16 v23, v6

    move-object v2, v7

    move-object v3, v8

    move-object/from16 v25, v13

    move-wide/from16 v6, p2

    move-object v13, v9

    move-wide/from16 v8, p4

    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v7    # "resolver":Landroid/content/ContentResolver;
    .end local v8    # "uri":Landroid/net/Uri;
    .end local v13    # "raw\\3":Ljava/io/OutputStream;
    .local v2, "resolver":Landroid/content/ContentResolver;
    .local v3, "uri":Landroid/net/Uri;
    .local v23, "values":Landroid/content/ContentValues;
    .local v24, "stamp":Ljava/lang/String;
    .local v25, "raw\\3":Ljava/io/OutputStream;
    :try_start_4
    invoke-direct/range {v4 .. v10}, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda0;-><init>(Lorg/lighttouch/android/HitchData;JJLorg/lighttouch/android/RangeStats;)V

    move-object/from16 v5, v21

    .end local v21    # "zip\\4":Ljava/util/zip/ZipOutputStream;
    .local v5, "zip\\4":Ljava/util/zip/ZipOutputStream;
    invoke-static {v5, v14, v4}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 163
    const-string v14, "selection.tsv"

    new-instance v4, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda1;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    move-wide/from16 v6, p2

    move-wide/from16 v8, p4

    move-object/from16 v21, v15

    move-object v15, v5

    move-object/from16 v5, p1

    .end local v5    # "zip\\4":Ljava/util/zip/ZipOutputStream;
    .local v15, "zip\\4":Ljava/util/zip/ZipOutputStream;
    .local v21, "app":Ljava/lang/String;
    :try_start_5
    invoke-direct/range {v4 .. v9}, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda1;-><init>(Lorg/lighttouch/android/HitchData;JJ)V

    invoke-static {v15, v14, v4}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 172
    new-instance v4, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/HitchData;->getDirectory()Ljava/io/File;

    move-result-object v5

    invoke-direct {v4, v5, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v5, v4

    .line 199
    .local v5, "it\\5":Ljava/io/File;
    const/4 v6, 0x0

    .line 172
    .local v6, "$i$a$-takeIf-HitchDataKt$saveHitchReport$1$1$3\\5\\172\\4":I
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    move-result v7
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .end local v5    # "it\\5":Ljava/io/File;
    .end local v6    # "$i$a$-takeIf-HitchDataKt$saveHitchReport$1$1$3\\5\\172\\4":I
    if-eqz v7, :cond_4

    move-object v5, v4

    goto :goto_3

    :cond_4
    const/4 v5, 0x0

    :goto_3
    if-eqz v5, :cond_5

    .local v5, "events\\6":Ljava/io/File;
    const/4 v14, 0x0

    .line 173
    .local v14, "$i$a$-let-HitchDataKt$saveHitchReport$1$1$4\\6\\172\\4":I
    :try_start_6
    new-instance v4, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda2;

    move-wide/from16 v6, p2

    move-wide/from16 v8, p4

    invoke-direct/range {v4 .. v9}, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda2;-><init>(Ljava/io/File;JJ)V

    invoke-static {v15, v1, v4}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 177
    nop

    .end local v5    # "events\\6":Ljava/io/File;
    .end local v14    # "$i$a$-let-HitchDataKt$saveHitchReport$1$1$4\\6\\172\\4":I
    goto :goto_4

    .line 146
    .end local v15    # "zip\\4":Ljava/util/zip/ZipOutputStream;
    .end local v18    # "$i$a$-use-HitchDataKt$saveHitchReport$1$1\\4\\146\\3":I
    :catchall_0
    move-exception v0

    move-object v1, v0

    move-object/from16 v6, v23

    goto/16 :goto_a

    .line 172
    .restart local v15    # "zip\\4":Ljava/util/zip/ZipOutputStream;
    .restart local v18    # "$i$a$-use-HitchDataKt$saveHitchReport$1$1\\4\\146\\3":I
    :cond_5
    :goto_4
    nop

    .line 178
    const/4 v1, 0x4

    :try_start_7
    new-array v1, v1, [Ljava/lang/String;

    const-string v4, "metadata.json"

    aput-object v4, v1, v19

    const-string v4, "frames.tsv"

    aput-object v4, v1, v16

    aput-object v0, v1, v20

    const-string v4, "engine-start.log"

    const/4 v5, 0x3

    aput-object v4, v1, v5

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    if-eqz v4, :cond_8

    :try_start_8
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "extra\\4":Ljava/lang/String;
    new-instance v5, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/HitchData;->getDirectory()Ljava/io/File;

    move-result-object v6

    invoke-direct {v5, v6, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v6, v5

    .line 199
    .local v6, "it\\7":Ljava/io/File;
    const/4 v7, 0x0

    .line 178
    .local v7, "$i$a$-takeIf-HitchDataKt$saveHitchReport$1$1$5\\7\\178\\4":I
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v8

    .end local v6    # "it\\7":Ljava/io/File;
    .end local v7    # "$i$a$-takeIf-HitchDataKt$saveHitchReport$1$1$5\\7\\178\\4":I
    if-eqz v8, :cond_6

    goto :goto_6

    :cond_6
    const/4 v5, 0x0

    :goto_6
    if-eqz v5, :cond_7

    .local v5, "f\\8":Ljava/io/File;
    const/4 v6, 0x0

    .line 179
    .local v6, "$i$a$-let-HitchDataKt$saveHitchReport$1$1$6\\8\\178\\4":I
    new-instance v7, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda3;

    invoke-direct {v7, v5}, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda3;-><init>(Ljava/io/File;)V

    invoke-static {v15, v4, v7}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 180
    nop

    .line 178
    .end local v5    # "f\\8":Ljava/io/File;
    .end local v6    # "$i$a$-let-HitchDataKt$saveHitchReport$1$1$6\\8\\178\\4":I
    goto :goto_5

    .end local v4    # "extra\\4":Ljava/lang/String;
    :cond_7
    goto :goto_5

    .line 182
    :cond_8
    :try_start_9
    new-instance v1, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/HitchData;->getDirectory()Ljava/io/File;

    move-result-object v4

    invoke-direct {v1, v4, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    if-nez v0, :cond_c

    :try_start_a
    new-instance v0, Ljava/io/File;

    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/HitchData;->getEngineLog()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .line 199
    .local v1, "it\\9":Ljava/io/File;
    const/4 v4, 0x0

    .line 182
    .local v4, "$i$a$-takeIf-HitchDataKt$saveHitchReport$1$1$7\\9\\182\\4":I
    invoke-virtual/range {p1 .. p1}, Lorg/lighttouch/android/HitchData;->getEngineLog()Ljava/lang/String;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_9

    move/from16 v5, v16

    goto :goto_7

    :cond_9
    move/from16 v5, v19

    :goto_7
    if-eqz v5, :cond_a

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v5

    if-eqz v5, :cond_a

    goto :goto_8

    :cond_a
    move/from16 v16, v19

    .end local v1    # "it\\9":Ljava/io/File;
    .end local v4    # "$i$a$-takeIf-HitchDataKt$saveHitchReport$1$1$7\\9\\182\\4":I
    :goto_8
    if-eqz v16, :cond_b

    goto :goto_9

    :cond_b
    const/4 v0, 0x0

    :goto_9
    if-eqz v0, :cond_c

    .local v0, "log\\10":Ljava/io/File;
    const/4 v1, 0x0

    .line 183
    .local v1, "$i$a$-let-HitchDataKt$saveHitchReport$1$1$8\\10\\182\\4":I
    const-string v4, "engine-tail.log"

    new-instance v5, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda4;

    invoke-direct {v5, v0}, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda4;-><init>(Ljava/io/File;)V

    invoke-static {v15, v4, v5}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 188
    nop

    .line 182
    .end local v0    # "log\\10":Ljava/io/File;
    .end local v1    # "$i$a$-let-HitchDataKt$saveHitchReport$1$1$8\\10\\182\\4":I
    :cond_c
    nop

    .line 189
    :try_start_b
    const-string v0, "report.json"

    new-instance v4, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda5;
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    move-wide/from16 v5, p2

    move-wide/from16 v7, p4

    move-object v9, v10

    move-object/from16 v10, p1

    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .local v9, "stats":Lorg/lighttouch/android/RangeStats;
    :try_start_c
    invoke-direct/range {v4 .. v10}, Lorg/lighttouch/android/HitchDataKt$$ExternalSyntheticLambda5;-><init>(JJLorg/lighttouch/android/RangeStats;Lorg/lighttouch/android/HitchData;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_2

    move-object v10, v9

    .end local v9    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    :try_start_d
    invoke-static {v15, v0, v4}, Lorg/lighttouch/android/HitchDataKt;->saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V

    .line 192
    nop

    .end local v15    # "zip\\4":Ljava/util/zip/ZipOutputStream;
    .end local v18    # "$i$a$-use-HitchDataKt$saveHitchReport$1$1\\4\\146\\3":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    .line 146
    const/4 v1, 0x0

    :try_start_e
    invoke-static {v12, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 192
    nop

    .end local v17    # "$i$a$-use-HitchDataKt$saveHitchReport$1\\3\\146\\0":I
    .end local v25    # "raw\\3":Ljava/io/OutputStream;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_1

    .line 146
    :try_start_f
    invoke-static {v13, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 193
    invoke-virtual/range {v23 .. v23}, Landroid/content/ContentValues;->clear()V

    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_0

    move-object/from16 v6, v23

    .end local v23    # "values":Landroid/content/ContentValues;
    .local v6, "values":Landroid/content/ContentValues;
    :try_start_10
    invoke-virtual {v6, v11, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 194
    const/4 v1, 0x0

    invoke-virtual {v2, v3, v6, v1, v1}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_1

    .line 196
    return-object v3

    .line 195
    .end local v6    # "values":Landroid/content/ContentValues;
    .restart local v23    # "values":Landroid/content/ContentValues;
    :catch_0
    move-exception v0

    move-object/from16 v6, v23

    .end local v23    # "values":Landroid/content/ContentValues;
    .restart local v6    # "values":Landroid/content/ContentValues;
    goto/16 :goto_c

    .line 146
    .end local v6    # "values":Landroid/content/ContentValues;
    .restart local v23    # "values":Landroid/content/ContentValues;
    :catchall_1
    move-exception v0

    move-object/from16 v6, v23

    move-object v1, v0

    .end local v23    # "values":Landroid/content/ContentValues;
    .restart local v6    # "values":Landroid/content/ContentValues;
    goto :goto_b

    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v9    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v17    # "$i$a$-use-HitchDataKt$saveHitchReport$1\\3\\146\\0":I
    .restart local v23    # "values":Landroid/content/ContentValues;
    .restart local v25    # "raw\\3":Ljava/io/OutputStream;
    :catchall_2
    move-exception v0

    move-object v10, v9

    move-object/from16 v6, v23

    move-object v1, v0

    .end local v9    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v23    # "values":Landroid/content/ContentValues;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    goto :goto_a

    .end local v6    # "values":Landroid/content/ContentValues;
    .restart local v23    # "values":Landroid/content/ContentValues;
    :catchall_3
    move-exception v0

    move-object/from16 v6, v23

    move-object v1, v0

    .end local v23    # "values":Landroid/content/ContentValues;
    .restart local v6    # "values":Landroid/content/ContentValues;
    goto :goto_a

    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v21    # "app":Ljava/lang/String;
    .local v15, "app":Ljava/lang/String;
    .restart local v23    # "values":Landroid/content/ContentValues;
    :catchall_4
    move-exception v0

    move-object/from16 v21, v15

    move-object/from16 v6, v23

    move-object v1, v0

    .end local v15    # "app":Ljava/lang/String;
    .end local v23    # "values":Landroid/content/ContentValues;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v21    # "app":Ljava/lang/String;
    goto :goto_a

    .end local v3    # "uri":Landroid/net/Uri;
    .end local v21    # "app":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .end local v25    # "raw\\3":Ljava/io/OutputStream;
    .local v2, "stamp":Ljava/lang/String;
    .local v7, "resolver":Landroid/content/ContentResolver;
    .restart local v8    # "uri":Landroid/net/Uri;
    .restart local v13    # "raw\\3":Ljava/io/OutputStream;
    .restart local v15    # "app":Ljava/lang/String;
    :catchall_5
    move-exception v0

    move-object/from16 v24, v2

    move-object v2, v7

    move-object v3, v8

    move-object/from16 v25, v13

    move-object/from16 v21, v15

    move-object v13, v9

    move-object v1, v0

    .end local v7    # "resolver":Landroid/content/ContentResolver;
    .end local v8    # "uri":Landroid/net/Uri;
    .end local v13    # "raw\\3":Ljava/io/OutputStream;
    .end local v15    # "app":Ljava/lang/String;
    .local v2, "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    .restart local v25    # "raw\\3":Ljava/io/OutputStream;
    goto :goto_a

    .end local v3    # "uri":Landroid/net/Uri;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .end local v25    # "raw\\3":Ljava/io/OutputStream;
    .local v2, "stamp":Ljava/lang/String;
    .local v4, "name":Ljava/lang/String;
    .restart local v7    # "resolver":Landroid/content/ContentResolver;
    .restart local v8    # "uri":Landroid/net/Uri;
    .restart local v13    # "raw\\3":Ljava/io/OutputStream;
    .restart local v15    # "app":Ljava/lang/String;
    :catchall_6
    move-exception v0

    move-object/from16 v24, v2

    move-object/from16 v22, v4

    move-object v2, v7

    move-object v3, v8

    move-object/from16 v25, v13

    move-object/from16 v21, v15

    move-object v13, v9

    move-object v1, v0

    .end local v2    # "stamp":Ljava/lang/String;
    .end local v4    # "name":Ljava/lang/String;
    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v7    # "resolver":Landroid/content/ContentResolver;
    .end local v8    # "uri":Landroid/net/Uri;
    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v13    # "raw\\3":Ljava/io/OutputStream;
    .end local v15    # "app":Ljava/lang/String;
    .end local v17    # "$i$a$-use-HitchDataKt$saveHitchReport$1\\3\\146\\0":I
    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "data":Lorg/lighttouch/android/HitchData;
    .end local p2    # "from":J
    .end local p4    # "to":J
    :goto_a
    :try_start_11
    throw v1
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_7

    .local v2, "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v17    # "$i$a$-use-HitchDataKt$saveHitchReport$1\\3\\146\\0":I
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v22    # "name":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    .restart local v25    # "raw\\3":Ljava/io/OutputStream;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "data":Lorg/lighttouch/android/HitchData;
    .restart local p2    # "from":J
    .restart local p4    # "to":J
    :catchall_7
    move-exception v0

    :try_start_12
    invoke-static {v12, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v2    # "resolver":Landroid/content/ContentResolver;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "data":Lorg/lighttouch/android/HitchData;
    .end local p2    # "from":J
    .end local p4    # "to":J
    throw v0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_8

    .end local v17    # "$i$a$-use-HitchDataKt$saveHitchReport$1\\3\\146\\0":I
    .end local v25    # "raw\\3":Ljava/io/OutputStream;
    .restart local v2    # "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v22    # "name":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "data":Lorg/lighttouch/android/HitchData;
    .restart local p2    # "from":J
    .restart local p4    # "to":J
    :catchall_8
    move-exception v0

    move-object v1, v0

    goto :goto_b

    .end local v3    # "uri":Landroid/net/Uri;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .local v2, "stamp":Ljava/lang/String;
    .restart local v4    # "name":Ljava/lang/String;
    .restart local v7    # "resolver":Landroid/content/ContentResolver;
    .restart local v8    # "uri":Landroid/net/Uri;
    .restart local v15    # "app":Ljava/lang/String;
    :catchall_9
    move-exception v0

    move-object/from16 v24, v2

    move-object/from16 v22, v4

    move-object v2, v7

    move-object v3, v8

    move-object v13, v9

    move-object/from16 v21, v15

    move-object v1, v0

    .end local v2    # "stamp":Ljava/lang/String;
    .end local v4    # "name":Ljava/lang/String;
    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v7    # "resolver":Landroid/content/ContentResolver;
    .end local v8    # "uri":Landroid/net/Uri;
    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v15    # "app":Ljava/lang/String;
    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "data":Lorg/lighttouch/android/HitchData;
    .end local p2    # "from":J
    .end local p4    # "to":J
    :goto_b
    :try_start_13
    throw v1
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_a

    .local v2, "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v22    # "name":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "data":Lorg/lighttouch/android/HitchData;
    .restart local p2    # "from":J
    .restart local p4    # "to":J
    :catchall_a
    move-exception v0

    :try_start_14
    invoke-static {v13, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v2    # "resolver":Landroid/content/ContentResolver;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "data":Lorg/lighttouch/android/HitchData;
    .end local p2    # "from":J
    .end local p4    # "to":J
    throw v0

    .local v2, "stamp":Ljava/lang/String;
    .restart local v4    # "name":Ljava/lang/String;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v7    # "resolver":Landroid/content/ContentResolver;
    .restart local v8    # "uri":Landroid/net/Uri;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v15    # "app":Ljava/lang/String;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "data":Lorg/lighttouch/android/HitchData;
    .restart local p2    # "from":J
    .restart local p4    # "to":J
    :cond_d
    move-object/from16 v24, v2

    move-object/from16 v22, v4

    move-object v2, v7

    move-object v3, v8

    move-object/from16 v21, v15

    .end local v4    # "name":Ljava/lang/String;
    .end local v7    # "resolver":Landroid/content/ContentResolver;
    .end local v8    # "uri":Landroid/net/Uri;
    .end local v15    # "app":Ljava/lang/String;
    .local v2, "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v22    # "name":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 192
    const-string v1, "\u65e0\u6cd5\u5199\u5165\u62a5\u544a"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .end local v2    # "resolver":Landroid/content/ContentResolver;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local v6    # "values":Landroid/content/ContentValues;
    .end local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "data":Lorg/lighttouch/android/HitchData;
    .end local p2    # "from":J
    .end local p4    # "to":J
    throw v0
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_1

    .line 195
    .restart local v2    # "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v6    # "values":Landroid/content/ContentValues;
    .restart local v10    # "stats":Lorg/lighttouch/android/RangeStats;
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v22    # "name":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "data":Lorg/lighttouch/android/HitchData;
    .restart local p2    # "from":J
    .restart local p4    # "to":J
    :catch_1
    move-exception v0

    goto :goto_c

    .end local v3    # "uri":Landroid/net/Uri;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .local v2, "stamp":Ljava/lang/String;
    .restart local v4    # "name":Ljava/lang/String;
    .restart local v7    # "resolver":Landroid/content/ContentResolver;
    .restart local v8    # "uri":Landroid/net/Uri;
    .restart local v15    # "app":Ljava/lang/String;
    :catch_2
    move-exception v0

    move-object/from16 v24, v2

    move-object/from16 v22, v4

    move-object v2, v7

    move-object v3, v8

    move-object/from16 v21, v15

    .end local v4    # "name":Ljava/lang/String;
    .end local v7    # "resolver":Landroid/content/ContentResolver;
    .end local v8    # "uri":Landroid/net/Uri;
    .end local v15    # "app":Ljava/lang/String;
    .local v2, "resolver":Landroid/content/ContentResolver;
    .restart local v3    # "uri":Landroid/net/Uri;
    .restart local v21    # "app":Ljava/lang/String;
    .restart local v22    # "name":Ljava/lang/String;
    .restart local v24    # "stamp":Ljava/lang/String;
    :goto_c
    const/4 v1, 0x0

    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v2, v3, v1, v1}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I

    throw v0

    .line 144
    .end local v0    # "e":Ljava/lang/Exception;
    .end local v3    # "uri":Landroid/net/Uri;
    .end local v21    # "app":Ljava/lang/String;
    .end local v22    # "name":Ljava/lang/String;
    .end local v24    # "stamp":Ljava/lang/String;
    .local v2, "stamp":Ljava/lang/String;
    .restart local v4    # "name":Ljava/lang/String;
    .restart local v7    # "resolver":Landroid/content/ContentResolver;
    .restart local v15    # "app":Ljava/lang/String;
    :cond_e
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "\u65e0\u6cd5\u5728 Downloads \u4e2d\u521b\u5efa\u62a5\u544a"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$entry(Ljava/util/zip/ZipOutputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .locals 1
    .param p0, "$zip"    # Ljava/util/zip/ZipOutputStream;
    .param p1, "path"    # Ljava/lang/String;
    .param p2, "write"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/zip/ZipOutputStream;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/io/OutputStream;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 147
    new-instance v0, Ljava/util/zip/ZipEntry;

    invoke-direct {v0, p1}, Ljava/util/zip/ZipEntry;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/util/zip/ZipOutputStream;->putNextEntry(Ljava/util/zip/ZipEntry;)V

    invoke-interface {p2, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/util/zip/ZipOutputStream;->closeEntry()V

    return-void
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$lambda$13$lambda$12(Ljava/io/File;JJLjava/io/OutputStream;)Lkotlin/Unit;
    .locals 23
    .param p0, "$events"    # Ljava/io/File;
    .param p1, "$from"    # J
    .param p3, "$to"    # J
    .param p5, "out"    # Ljava/io/OutputStream;

    move-object/from16 v1, p5

    const-string v0, "out"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    sget-object v0, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    new-instance v2, Ljava/io/InputStreamReader;

    new-instance v3, Ljava/io/FileInputStream;

    move-object/from16 v4, p0

    invoke-direct {v3, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v3, Ljava/io/InputStream;

    invoke-direct {v2, v3, v0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v2, Ljava/io/Reader;

    instance-of v0, v2, Ljava/io/BufferedReader;

    const/16 v3, 0x2000

    if-eqz v0, :cond_0

    check-cast v2, Ljava/io/BufferedReader;

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/io/BufferedReader;

    invoke-direct {v0, v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    move-object v2, v0

    :goto_0
    check-cast v2, Ljava/io/Reader;

    .local v2, "$this$useLines\\1":Ljava/io/Reader;
    const/4 v5, 0x0

    .line 206
    .local v5, "$i$f$useLines\\1\\173":I
    instance-of v0, v2, Ljava/io/BufferedReader;

    if-eqz v0, :cond_1

    move-object v0, v2

    check-cast v0, Ljava/io/BufferedReader;

    goto :goto_1

    :cond_1
    new-instance v0, Ljava/io/BufferedReader;

    invoke-direct {v0, v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    :goto_1
    move-object v3, v0

    check-cast v3, Ljava/io/Closeable;

    :try_start_0
    move-object v0, v3

    check-cast v0, Ljava/io/BufferedReader;

    .line 207
    .local v0, "it\\1":Ljava/io/BufferedReader;
    const/4 v6, 0x0

    .line 206
    .local v6, "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    invoke-static {v0}, Lkotlin/io/TextStreamsKt;->lineSequence(Ljava/io/BufferedReader;)Lkotlin/sequences/Sequence;

    move-result-object v7

    .local v7, "lines\\3":Lkotlin/sequences/Sequence;
    const/4 v8, 0x0

    .line 173
    .local v8, "$i$a$-useLines-HitchDataKt$saveHitchReport$1$1$4$1$1\\3\\206\\0":I
    move-object v9, v7

    .local v9, "$this$forEach\\4":Lkotlin/sequences/Sequence;
    const/4 v10, 0x0

    .line 208
    .local v10, "$i$f$forEach\\4\\173":I
    invoke-interface {v9}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_2
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_6

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    .local v12, "element\\4":Ljava/lang/Object;
    move-object v14, v12

    check-cast v14, Ljava/lang/String;

    .local v14, "line\\5":Ljava/lang/String;
    const/4 v15, 0x0

    .line 174
    .local v15, "$i$a$-forEach-HitchDataKt$saveHitchReport$1$1$4$1$1$1\\5\\208\\3":I
    move-object/from16 v16, v14

    check-cast v16, Ljava/lang/CharSequence;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    const/4 v13, 0x1

    move-object/from16 v22, v0

    .end local v0    # "it\\1":Ljava/io/BufferedReader;
    .local v22, "it\\1":Ljava/io/BufferedReader;
    :try_start_1
    new-array v0, v13, [C

    const/4 v13, 0x0

    const/16 v17, 0x20

    aput-char v17, v0, v13
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/16 v20, 0x6

    const/16 v21, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v17, v0

    :try_start_2
    invoke-static/range {v16 .. v21}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v13, 0x1

    invoke-static {v0, v13}, Lkotlin/collections/CollectionsKt;->getOrNull(Ljava/util/List;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    if-eqz v0, :cond_2

    :try_start_3
    invoke-static {v0}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_3

    .line 206
    .end local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .end local v8    # "$i$a$-useLines-HitchDataKt$saveHitchReport$1$1$4$1$1\\3\\206\\0":I
    .end local v9    # "$this$forEach\\4":Lkotlin/sequences/Sequence;
    .end local v10    # "$i$f$forEach\\4\\173":I
    .end local v12    # "element\\4":Ljava/lang/Object;
    .end local v14    # "line\\5":Ljava/lang/String;
    .end local v15    # "$i$a$-forEach-HitchDataKt$saveHitchReport$1$1$4$1$1$1\\5\\208\\3":I
    .end local v22    # "it\\1":Ljava/io/BufferedReader;
    :catchall_0
    move-exception v0

    move-object v4, v0

    move-object/from16 v18, v2

    move v2, v5

    goto/16 :goto_7

    .line 174
    .restart local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v8    # "$i$a$-useLines-HitchDataKt$saveHitchReport$1$1$4$1$1\\3\\206\\0":I
    .restart local v9    # "$this$forEach\\4":Lkotlin/sequences/Sequence;
    .restart local v10    # "$i$f$forEach\\4\\173":I
    .restart local v12    # "element\\4":Ljava/lang/Object;
    .restart local v14    # "line\\5":Ljava/lang/String;
    .restart local v15    # "$i$a$-forEach-HitchDataKt$saveHitchReport$1$1$4$1$1$1\\5\\208\\3":I
    .restart local v22    # "it\\1":Ljava/io/BufferedReader;
    :cond_2
    const/4 v0, 0x0

    .line 175
    .local v0, "t\\5":Ljava/lang/Long;
    :goto_3
    :try_start_4
    const-string v13, "#"
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    move-object/from16 v17, v0

    .end local v0    # "t\\5":Ljava/lang/Long;
    .local v17, "t\\5":Ljava/lang/Long;
    const/4 v0, 0x2

    move-object/from16 v18, v2

    const/4 v2, 0x0

    const/4 v4, 0x0

    .end local v2    # "$this$useLines\\1":Ljava/io/Reader;
    .local v18, "$this$useLines\\1":Ljava/io/Reader;
    :try_start_5
    invoke-static {v14, v13, v2, v0, v4}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    if-eqz v17, :cond_3

    new-instance v0, Lkotlin/ranges/LongRange;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const-wide/32 v19, 0x3b9aca00

    move v2, v5

    .end local v5    # "$i$f$useLines\\1\\173":I
    .local v2, "$i$f$useLines\\1\\173":I
    sub-long v4, p1, v19

    move v13, v6

    move-object/from16 v16, v7

    .end local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .local v13, "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .local v16, "lines\\3":Lkotlin/sequences/Sequence;
    add-long v6, p3, v19

    :try_start_6
    invoke-direct {v0, v4, v5, v6, v7}, Lkotlin/ranges/LongRange;-><init>(JJ)V

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v0, v4, v5}, Lkotlin/ranges/LongRange;->contains(J)Z

    move-result v0

    if-eqz v0, :cond_5

    goto :goto_4

    .end local v2    # "$i$f$useLines\\1\\173":I
    .end local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v5    # "$i$f$useLines\\1\\173":I
    .restart local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    :cond_3
    move v2, v5

    move v13, v6

    move-object/from16 v16, v7

    .end local v5    # "$i$f$useLines\\1\\173":I
    .end local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v2    # "$i$f$useLines\\1\\173":I
    .restart local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    goto :goto_5

    .end local v2    # "$i$f$useLines\\1\\173":I
    .end local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v5    # "$i$f$useLines\\1\\173":I
    .restart local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    :cond_4
    move v2, v5

    move v13, v6

    move-object/from16 v16, v7

    .end local v5    # "$i$f$useLines\\1\\173":I
    .end local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v2    # "$i$f$useLines\\1\\173":I
    .restart local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    :goto_4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v4, "\n"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v4, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v4, "getBytes(...)"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 176
    :cond_5
    :goto_5
    nop

    .line 208
    .end local v14    # "line\\5":Ljava/lang/String;
    .end local v15    # "$i$a$-forEach-HitchDataKt$saveHitchReport$1$1$4$1$1$1\\5\\208\\3":I
    .end local v17    # "t\\5":Ljava/lang/Long;
    move-object/from16 v4, p0

    move v5, v2

    move v6, v13

    move-object/from16 v7, v16

    move-object/from16 v2, v18

    move-object/from16 v0, v22

    .end local v12    # "element\\4":Ljava/lang/Object;
    goto/16 :goto_2

    .line 206
    .end local v2    # "$i$f$useLines\\1\\173":I
    .end local v8    # "$i$a$-useLines-HitchDataKt$saveHitchReport$1$1$4$1$1\\3\\206\\0":I
    .end local v9    # "$this$forEach\\4":Lkotlin/sequences/Sequence;
    .end local v10    # "$i$f$forEach\\4\\173":I
    .end local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    .end local v22    # "it\\1":Ljava/io/BufferedReader;
    .restart local v5    # "$i$f$useLines\\1\\173":I
    :catchall_1
    move-exception v0

    move v2, v5

    move-object v4, v0

    .end local v5    # "$i$f$useLines\\1\\173":I
    .restart local v2    # "$i$f$useLines\\1\\173":I
    goto :goto_7

    .end local v18    # "$this$useLines\\1":Ljava/io/Reader;
    .local v2, "$this$useLines\\1":Ljava/io/Reader;
    .restart local v5    # "$i$f$useLines\\1\\173":I
    :catchall_2
    move-exception v0

    move-object/from16 v18, v2

    move v2, v5

    .end local v5    # "$i$f$useLines\\1\\173":I
    .local v2, "$i$f$useLines\\1\\173":I
    .restart local v18    # "$this$useLines\\1":Ljava/io/Reader;
    goto :goto_6

    .line 209
    .end local v18    # "$this$useLines\\1":Ljava/io/Reader;
    .local v0, "it\\1":Ljava/io/BufferedReader;
    .local v2, "$this$useLines\\1":Ljava/io/Reader;
    .restart local v5    # "$i$f$useLines\\1\\173":I
    .restart local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v8    # "$i$a$-useLines-HitchDataKt$saveHitchReport$1$1$4$1$1\\3\\206\\0":I
    .restart local v9    # "$this$forEach\\4":Lkotlin/sequences/Sequence;
    .restart local v10    # "$i$f$forEach\\4\\173":I
    :cond_6
    move-object/from16 v22, v0

    move-object/from16 v18, v2

    move v2, v5

    move v13, v6

    move-object/from16 v16, v7

    .line 176
    .end local v0    # "it\\1":Ljava/io/BufferedReader;
    .end local v5    # "$i$f$useLines\\1\\173":I
    .end local v6    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v7    # "lines\\3":Lkotlin/sequences/Sequence;
    .end local v9    # "$this$forEach\\4":Lkotlin/sequences/Sequence;
    .end local v10    # "$i$f$forEach\\4\\173":I
    .local v2, "$i$f$useLines\\1\\173":I
    .restart local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .restart local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    .restart local v18    # "$this$useLines\\1":Ljava/io/Reader;
    .restart local v22    # "it\\1":Ljava/io/BufferedReader;
    nop

    .end local v8    # "$i$a$-useLines-HitchDataKt$saveHitchReport$1$1$4$1$1\\3\\206\\0":I
    .end local v16    # "lines\\3":Lkotlin/sequences/Sequence;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 206
    .end local v13    # "$i$a$-use-TextStreamsKt$useLines$1\\2\\207\\1":I
    .end local v22    # "it\\1":Ljava/io/BufferedReader;
    const/4 v4, 0x0

    invoke-static {v3, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 176
    .end local v2    # "$i$f$useLines\\1\\173":I
    .end local v18    # "$this$useLines\\1":Ljava/io/Reader;
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 206
    .restart local v2    # "$i$f$useLines\\1\\173":I
    .restart local v18    # "$this$useLines\\1":Ljava/io/Reader;
    :catchall_3
    move-exception v0

    :goto_6
    move-object v4, v0

    goto :goto_7

    .end local v18    # "$this$useLines\\1":Ljava/io/Reader;
    .local v2, "$this$useLines\\1":Ljava/io/Reader;
    .restart local v5    # "$i$f$useLines\\1\\173":I
    :catchall_4
    move-exception v0

    move-object/from16 v18, v2

    move v2, v5

    move-object v4, v0

    .end local v2    # "$this$useLines\\1":Ljava/io/Reader;
    .end local v5    # "$i$f$useLines\\1\\173":I
    .end local p0    # "$events":Ljava/io/File;
    .end local p1    # "$from":J
    .end local p3    # "$to":J
    .end local p5    # "out":Ljava/io/OutputStream;
    :goto_7
    :try_start_7
    throw v4
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .local v2, "$i$f$useLines\\1\\173":I
    .restart local v18    # "$this$useLines\\1":Ljava/io/Reader;
    .restart local p0    # "$events":Ljava/io/File;
    .restart local p1    # "$from":J
    .restart local p3    # "$to":J
    .restart local p5    # "out":Ljava/io/OutputStream;
    :catchall_5
    move-exception v0

    invoke-static {v3, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$lambda$17$lambda$16(Ljava/io/File;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 7
    .param p0, "$f"    # Ljava/io/File;
    .param p1, "out"    # Ljava/io/OutputStream;

    const-string v0, "out"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ljava/io/FileInputStream;

    .line 179
    invoke-direct {v0, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    check-cast v0, Ljava/io/Closeable;

    :try_start_0
    move-object v1, v0

    check-cast v1, Ljava/io/FileInputStream;

    .line 199
    .local v1, "it\\1":Ljava/io/FileInputStream;
    const/4 v2, 0x0

    .line 179
    .local v2, "$i$a$-use-HitchDataKt$saveHitchReport$1$1$6$1$1\\1\\179\\0":I
    move-object v3, v1

    check-cast v3, Ljava/io/InputStream;

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v3, p1, v4, v5, v6}, Lkotlin/io/ByteStreamsKt;->copyTo$default(Ljava/io/InputStream;Ljava/io/OutputStream;IILjava/lang/Object;)J

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .end local v1    # "it\\1":Ljava/io/FileInputStream;
    .end local v2    # "$i$a$-use-HitchDataKt$saveHitchReport$1$1$6$1$1\\1\\179\\0":I
    invoke-static {v0, v6}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    :catchall_0
    move-exception v1

    .end local p0    # "$f":Ljava/io/File;
    .end local p1    # "out":Ljava/io/OutputStream;
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local p0    # "$f":Ljava/io/File;
    .restart local p1    # "out":Ljava/io/OutputStream;
    :catchall_1
    move-exception v2

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$lambda$21$lambda$20(Ljava/io/File;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 8
    .param p0, "$log"    # Ljava/io/File;
    .param p1, "out"    # Ljava/io/OutputStream;

    const-string v0, "out"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 183
    new-instance v0, Ljava/io/RandomAccessFile;

    const-string v1, "r"

    invoke-direct {v0, p0, v1}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    check-cast v0, Ljava/io/Closeable;

    :try_start_0
    move-object v1, v0

    check-cast v1, Ljava/io/RandomAccessFile;

    .local v1, "input\\1":Ljava/io/RandomAccessFile;
    const/4 v2, 0x0

    .line 184
    .local v2, "$i$a$-use-HitchDataKt$saveHitchReport$1$1$8$1$1\\1\\183\\0":I
    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->length()J

    move-result-wide v3

    const-wide/32 v5, 0x200000

    sub-long/2addr v3, v5

    const-wide/16 v5, 0x0

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    .local v3, "start\\1":J
    invoke-virtual {v1, v3, v4}, Ljava/io/RandomAccessFile;->seek(J)V

    .line 185
    const/high16 v5, 0x10000

    new-array v5, v5, [B

    .line 186
    .local v5, "buffer\\1":[B
    :goto_0
    invoke-virtual {v1, v5}, Ljava/io/RandomAccessFile;->read([B)I

    move-result v6

    .local v6, "n\\1":I
    if-lez v6, :cond_0

    const/4 v7, 0x0

    invoke-virtual {p1, v5, v7, v6}, Ljava/io/OutputStream;->write([BII)V

    .end local v6    # "n\\1":I
    goto :goto_0

    .line 187
    :cond_0
    nop

    .end local v1    # "input\\1":Ljava/io/RandomAccessFile;
    .end local v2    # "$i$a$-use-HitchDataKt$saveHitchReport$1$1$8$1$1\\1\\183\\0":I
    .end local v3    # "start\\1":J
    .end local v5    # "buffer\\1":[B
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 183
    const/4 v1, 0x0

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 187
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 183
    :catchall_0
    move-exception v1

    .end local p0    # "$log":Ljava/io/File;
    .end local p1    # "out":Ljava/io/OutputStream;
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .restart local p0    # "$log":Ljava/io/File;
    .restart local p1    # "out":Ljava/io/OutputStream;
    :catchall_1
    move-exception v2

    invoke-static {v0, v1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$lambda$22(JJLorg/lighttouch/android/RangeStats;Lorg/lighttouch/android/HitchData;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 4
    .param p0, "$from"    # J
    .param p2, "$to"    # J
    .param p4, "$stats"    # Lorg/lighttouch/android/RangeStats;
    .param p5, "$data"    # Lorg/lighttouch/android/HitchData;
    .param p6, "out"    # Ljava/io/OutputStream;

    const-string v0, "out"

    invoke-static {p6, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 189
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "from"

    invoke-virtual {v0, v1, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "to"

    invoke-virtual {v0, v1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "frames"

    invoke-virtual {p4}, Lorg/lighttouch/android/RangeStats;->getFrames()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    .line 190
    invoke-virtual {p4}, Lorg/lighttouch/android/RangeStats;->getAvgFps()F

    move-result v1

    float-to-double v1, v1

    const-string v3, "averageFps"

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {p4}, Lorg/lighttouch/android/RangeStats;->getLowFps()F

    move-result v1

    float-to-double v1, v1

    const-string v3, "lowFps"

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {p4}, Lorg/lighttouch/android/RangeStats;->getWorstMs()F

    move-result v1

    float-to-double v1, v1

    const-string v3, "worstMs"

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object v0

    .line 191
    const-string v1, "hitches"

    invoke-virtual {p4}, Lorg/lighttouch/android/RangeStats;->getHitches()I

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "detailed"

    invoke-virtual {p5}, Lorg/lighttouch/android/HitchData;->getDetailed()Z

    move-result v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->toString(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "toString(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v1, "getBytes(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 189
    invoke-virtual {p6, v0}, Ljava/io/OutputStream;->write([B)V

    .line 191
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$lambda$6(Lorg/lighttouch/android/HitchData;JJLorg/lighttouch/android/RangeStats;Ljava/io/OutputStream;)Lkotlin/Unit;
    .locals 28
    .param p0, "$data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "$from"    # J
    .param p3, "$to"    # J
    .param p5, "$stats"    # Lorg/lighttouch/android/RangeStats;
    .param p6, "out"    # Ljava/io/OutputStream;

    move-wide/from16 v0, p1

    move-wide/from16 v2, p3

    move-object/from16 v4, p6

    const-string v5, "out"

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object v6, v5

    .local v6, "$this$saveHitchReport_u24lambda_u2424_u24lambda_u2423_u24lambda_u246_u24lambda_u245\\1":Ljava/lang/StringBuilder;
    const/4 v7, 0x0

    .line 149
    .local v7, "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$1$1\\1\\148\\0":I
    new-instance v8, Ljava/util/Date;

    invoke-direct {v8}, Ljava/util/Date;-><init>()V

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "LightTouch \u5361\u987f\u62a5\u544a  "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 150
    sget-object v8, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    sget-object v10, Landroid/os/Build;->MODEL:Ljava/lang/String;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "Android "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v11, " "

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, ", LightTouch 0.0.11"

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 151
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getAppName()Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v8

    const/4 v12, 0x1

    if-nez v8, :cond_0

    move v8, v12

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    :goto_0
    const-string v13, ")"

    if-eqz v8, :cond_2

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getBundleId()Ljava/lang/String;

    move-result-object v8

    check-cast v8, Ljava/lang/CharSequence;

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v8

    if-nez v8, :cond_1

    move v8, v12

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    :goto_1
    if-eqz v8, :cond_2

    const-string v8, "\u672a\u77e5\uff08\u5ba2\u6237\u673a\u5de5\u5177\u65e0\u54cd\u5e94\uff09"

    goto :goto_2

    .line 152
    :cond_2
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getAppName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getBundleId()Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v15, " ("

    invoke-virtual {v8, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    :goto_2
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "\u524d\u53f0\u5e94\u7528\uff1a"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    invoke-virtual {v14, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 153
    sget-object v8, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getStartNs()J

    move-result-wide v14

    sub-long v14, v0, v14

    long-to-double v14, v14

    const-wide v16, 0x41cdcd6500000000L    # 1.0E9

    div-double v14, v14, v16

    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v14

    filled-new-array {v14}, [Ljava/lang/Object;

    move-result-object v14

    invoke-static {v14, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v14

    const-string v15, "%.3f"

    invoke-static {v8, v15, v14}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    const-string v14, "format(...)"

    invoke-static {v8, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v18, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getStartNs()J

    move-result-wide v19

    move-object/from16 v21, v10

    sub-long v9, v2, v19

    long-to-double v9, v9

    div-double v9, v9, v16

    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    filled-new-array {v9}, [Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v10, v21

    invoke-static {v10, v15, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "\u9009\u62e9\uff1a"

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v10, " s to "

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " \u79d2\u7684\u65f6\u95f4\u7ebf (CLOCK_MONOTONIC "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, ".."

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 154
    sget-object v8, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 155
    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getFrames()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v21

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getSeconds()F

    move-result v9

    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v22

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getAvgFps()F

    move-result v9

    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v23

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getAvgMs()F

    move-result v9

    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v24

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getLowFps()F

    move-result v9

    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v25

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getWorstMs()F

    move-result v9

    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v26

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getHitches()I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v27

    filled-new-array/range {v21 .. v27}, [Ljava/lang/Object;

    move-result-object v9

    .line 154
    const/4 v10, 0x7

    invoke-static {v9, v10}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v9

    const-string v10, "\u5171 %d \u5e27 / %.2f \u79d2\uff1a\u5e73\u5747 %.1f fps (%.2f \u6beb\u79d2)\uff0c1%% \u4f4e\u5e27 %.1f fps\uff0c\u6700\u5dee %.1f \u6beb\u79d2\uff0c%d \u5e27\u8d85\u8fc7 50 \u6beb\u79d2"

    invoke-static {v8, v10, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 156
    const-string v8, "\u5e27\u65f6\u95f4\uff1a"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 157
    sget-object v8, Lorg/lighttouch/android/RangeStats;->Companion:Lorg/lighttouch/android/RangeStats$Companion;

    invoke-virtual {v8}, Lorg/lighttouch/android/RangeStats$Companion;->getBucketLabels()Ljava/util/List;

    move-result-object v8

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 200
    .local v9, "$i$f$forEachIndexed\\2\\157":I
    const/4 v10, 0x0

    .line 201
    .local v10, "index\\2":I
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_4

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .local v13, "item\\2":Ljava/lang/Object;
    add-int/lit8 v15, v10, 0x1

    .end local v10    # "index\\2":I
    .local v15, "index\\2":I
    if-gez v10, :cond_3

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_3
    move-object v0, v13

    check-cast v0, Ljava/lang/String;

    .local v0, "label\\3":Ljava/lang/String;
    .local v10, "i\\3":I
    const/4 v1, 0x0

    .line 157
    .local v1, "$i$a$-forEachIndexed-HitchDataKt$saveHitchReport$1$1$1$1$1\\3\\201\\1":I
    move/from16 v16, v1

    .end local v1    # "$i$a$-forEachIndexed-HitchDataKt$saveHitchReport$1$1$1$1$1\\3\\201\\1":I
    .local v16, "$i$a$-forEachIndexed-HitchDataKt$saveHitchReport$1$1$1$1$1\\3\\201\\1":I
    const/4 v1, 0x2

    const/4 v2, 0x0

    const/16 v3, 0x9

    move-object/from16 v17, v5

    const/4 v5, 0x0

    invoke-static {v0, v3, v5, v1, v2}, Lkotlin/text/StringsKt;->padEnd$default(Ljava/lang/String;ICILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p5 .. p5}, Lorg/lighttouch/android/RangeStats;->getBuckets()[I

    move-result-object v2

    aget v2, v2, v10

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "  "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/16 v2, 0xa

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 201
    .end local v0    # "label\\3":Ljava/lang/String;
    .end local v10    # "i\\3":I
    .end local v16    # "$i$a$-forEachIndexed-HitchDataKt$saveHitchReport$1$1$1$1$1\\3\\201\\1":I
    move-wide/from16 v0, p1

    move-wide/from16 v2, p3

    move v10, v15

    move-object/from16 v5, v17

    .end local v13    # "item\\2":Ljava/lang/Object;
    goto :goto_3

    .line 202
    .end local v15    # "index\\2":I
    .local v10, "index\\2":I
    :cond_4
    move-object/from16 v17, v5

    .line 158
    .end local v8    # "$this$forEachIndexed\\2":Ljava/lang/Iterable;
    .end local v9    # "$i$f$forEachIndexed\\2\\157":I
    .end local v10    # "index\\2":I
    invoke-virtual/range {p0 .. p0}, Lorg/lighttouch/android/HitchData;->getDetailed()Z

    move-result v0

    if-eqz v0, :cond_5

    const-string v0, "\u8be6\u7ec6\u8ba1\u65f6\uff1a\u5f00\u542f\uff08selection.tsv \u4e3a\u9010\u5e27\u660e\u7ec6\uff0cevents.tsv \u4e3a\u539f\u59cb\u8bb0\u5f55\uff09"

    goto :goto_4

    .line 159
    :cond_5
    const-string v0, "\u8be6\u7ec6\u8ba1\u65f6\uff1a\u5173\u95ed\uff08\u53ef\u5728\u300c\u8bbe\u7f6e > \u8bca\u65ad\u300d\u4e2d\u5f00\u542f\uff0c\u4ee5\u83b7\u53d6\u9010\u5e27 GL\u3001CPU \u4e0e\u9501\u8ba1\u65f6\uff09"

    :goto_4
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v9, 0xa

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 160
    invoke-virtual/range {p0 .. p4}, Lorg/lighttouch/android/HitchData;->eventsIn(JJ)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$sortedByDescending\\4":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 203
    .local v1, "$i$f$sortedByDescending\\4\\160":I
    new-instance v2, Lorg/lighttouch/android/HitchDataKt$saveHitchReport$lambda$24$lambda$23$lambda$6$lambda$5$$inlined$sortedByDescending$1;

    invoke-direct {v2}, Lorg/lighttouch/android/HitchDataKt$saveHitchReport$lambda$24$lambda$23$lambda$6$lambda$5$$inlined$sortedByDescending$1;-><init>()V

    check-cast v2, Ljava/util/Comparator;

    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v0

    .end local v0    # "$this$sortedByDescending\\4":Ljava/lang/Iterable;
    .end local v1    # "$i$f$sortedByDescending\\4\\160":I
    check-cast v0, Ljava/lang/Iterable;

    .line 160
    const/16 v1, 0x14

    invoke-static {v0, v1}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v0

    .line 161
    .local v0, "slow\\1":Ljava/util/List;
    move-object v1, v0

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\u6700\u6162\u4e8b\u4ef6\uff1a"

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/16 v9, 0xa

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-object v1, v0

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach\\5":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 204
    .local v2, "$i$f$forEach\\5\\161":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    .local v5, "element\\5":Ljava/lang/Object;
    move-object v8, v5

    check-cast v8, Lorg/lighttouch/android/SlowEvent;

    .local v8, "it\\6":Lorg/lighttouch/android/SlowEvent;
    const/4 v9, 0x0

    .line 161
    .local v9, "$i$a$-forEach-HitchDataKt$saveHitchReport$1$1$1$1$2\\6\\204\\1":I
    sget-object v10, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8}, Lorg/lighttouch/android/SlowEvent;->getMs()F

    move-result v11

    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    invoke-virtual {v8}, Lorg/lighttouch/android/SlowEvent;->getKind()Lorg/lighttouch/android/EventKind;

    move-result-object v12

    invoke-virtual {v12}, Lorg/lighttouch/android/EventKind;->getLabel()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8}, Lorg/lighttouch/android/SlowEvent;->getLabel()Ljava/lang/String;

    move-result-object v13

    filled-new-array {v11, v12, v13}, [Ljava/lang/Object;

    move-result-object v11

    const/4 v12, 0x3

    invoke-static {v11, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v11

    const-string v12, "  %7.2f ms  %-9s %s"

    invoke-static {v10, v12, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const/16 v11, 0xa

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 204
    .end local v8    # "it\\6":Lorg/lighttouch/android/SlowEvent;
    .end local v9    # "$i$a$-forEach-HitchDataKt$saveHitchReport$1$1$1$1$2\\6\\204\\1":I
    nop

    .end local v5    # "element\\5":Ljava/lang/Object;
    goto :goto_5

    .line 205
    :cond_6
    nop

    .line 162
    .end local v1    # "$this$forEach\\5":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\5\\161":I
    :cond_7
    nop

    .line 148
    .end local v0    # "slow\\1":Ljava/util/List;
    .end local v6    # "$this$saveHitchReport_u24lambda_u2424_u24lambda_u2423_u24lambda_u246_u24lambda_u245\\1":Ljava/lang/StringBuilder;
    .end local v7    # "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$1$1\\1\\148\\0":I
    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 162
    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    const-string v1, "getBytes(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    invoke-virtual {v4, v0}, Ljava/io/OutputStream;->write([B)V

    .line 162
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final saveHitchReport$lambda$24$lambda$23$lambda$8(Lorg/lighttouch/android/HitchData;JJLjava/io/OutputStream;)Lkotlin/Unit;
    .locals 20
    .param p0, "$data"    # Lorg/lighttouch/android/HitchData;
    .param p1, "$from"    # J
    .param p3, "$to"    # J
    .param p5, "out"    # Ljava/io/OutputStream;

    move-object/from16 v0, p5

    const-string v1, "out"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v1

    .local v2, "$this$saveHitchReport_u24lambda_u2424_u24lambda_u2423_u24lambda_u248_u24lambda_u247\\1":Ljava/lang/StringBuilder;
    const/4 v3, 0x0

    .line 164
    .local v3, "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$2$1\\1\\163\\0":I
    const-string v4, "# sequence published-ns presented-ns interval-ms presenter-ms run-ms outside-ms bql-ms vcpu-cpu-ms gl-ms gl-present-ms main-cpu-ms"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const/16 v5, 0xa

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 165
    invoke-virtual/range {p0 .. p4}, Lorg/lighttouch/android/HitchData;->framesIn(JJ)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lorg/lighttouch/android/HitchFrame;

    .line 166
    .local v6, "f\\1":Lorg/lighttouch/android/HitchFrame;
    move-object/from16 v7, p0

    invoke-virtual {v7, v6}, Lorg/lighttouch/android/HitchData;->breakdownFor(Lorg/lighttouch/android/HitchFrame;)Lorg/lighttouch/android/FrameBreakdown;

    move-result-object v8

    .line 167
    .local v8, "b\\1":Lorg/lighttouch/android/FrameBreakdown;
    invoke-virtual {v6}, Lorg/lighttouch/android/HitchFrame;->getSequence()J

    move-result-wide v9

    invoke-virtual {v6}, Lorg/lighttouch/android/HitchFrame;->getPublishedNs()J

    move-result-wide v11

    invoke-virtual {v6}, Lorg/lighttouch/android/HitchFrame;->getPresentedNs()J

    move-result-wide v13

    sget-object v15, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v15, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v6}, Lorg/lighttouch/android/HitchFrame;->getIntervalMs()F

    move-result v16

    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    move/from16 v16, v3

    move-object/from16 v17, v4

    .end local v3    # "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$2$1\\1\\163\\0":I
    .local v16, "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$2$1\\1\\163\\0":I
    invoke-virtual {v6}, Lorg/lighttouch/android/HitchFrame;->getWorkNs()J

    move-result-wide v3

    long-to-double v3, v3

    const-wide v18, 0x412e848000000000L    # 1000000.0

    div-double v3, v3, v18

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    filled-new-array {v5, v3}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x2

    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%.3f %.3f"

    invoke-static {v15, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "format(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v9, " "

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 168
    if-eqz v8, :cond_0

    sget-object v3, Lkotlin/jvm/internal/StringCompanionObject;->INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getRunMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v9

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getOutsideMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v10

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getBqlMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getVcpuCpuMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v12

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getGlMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v13

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getGlPresentMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v14

    invoke-virtual {v8}, Lorg/lighttouch/android/FrameBreakdown;->getMainCpuMs()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v15

    filled-new-array/range {v9 .. v15}, [Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    invoke-static {v5, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v5

    const-string v9, " %.3f %.3f %.3f %.3f %.3f %.3f %.3f"

    invoke-static {v3, v9, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    :cond_0
    const/16 v3, 0xa

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move v5, v3

    move/from16 v3, v16

    move-object/from16 v4, v17

    .end local v8    # "b\\1":Lorg/lighttouch/android/FrameBreakdown;
    goto/16 :goto_0

    .line 171
    .end local v6    # "f\\1":Lorg/lighttouch/android/HitchFrame;
    .end local v16    # "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$2$1\\1\\163\\0":I
    .restart local v3    # "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$2$1\\1\\163\\0":I
    :cond_1
    nop

    .line 163
    .end local v2    # "$this$saveHitchReport_u24lambda_u2424_u24lambda_u2423_u24lambda_u248_u24lambda_u247\\1":Ljava/lang/StringBuilder;
    .end local v3    # "$i$a$-buildString-HitchDataKt$saveHitchReport$1$1$2$1\\1\\163\\0":I
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 171
    sget-object v2, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v1, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    const-string v2, "getBytes(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    .line 171
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

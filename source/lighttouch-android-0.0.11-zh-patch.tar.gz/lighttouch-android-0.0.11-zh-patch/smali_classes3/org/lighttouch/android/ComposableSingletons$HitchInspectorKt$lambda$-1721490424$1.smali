.class final Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;
.super Ljava/lang/Object;
.source "HitchInspector.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHitchInspector.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,342:1\n149#2:343\n149#2:380\n149#2:381\n99#3:344\n96#3,6:345\n102#3:379\n106#3:385\n79#4,6:351\n86#4,4:366\n90#4,2:376\n94#4:384\n368#5,9:357\n377#5:378\n378#5,2:382\n4034#6,6:370\n*S KotlinDebug\n*F\n+ 1 HitchInspector.kt\norg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1\n*L\n126#1:343\n127#1:380\n128#1:381\n126#1:344\n126#1:345,6\n126#1:379\n126#1:385\n126#1:351,6\n126#1:366,4\n126#1:376,2\n126#1:384\n126#1:357,9\n126#1:378\n126#1:382,2\n126#1:370,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;

    invoke-direct {v0}, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;-><init>()V

    sput-object v0, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;->INSTANCE:Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;

    return-void
.end method

.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 125
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lorg/lighttouch/android/ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .locals 50
    .param p1, "$this$Card"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Card"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C125@7758L468:HitchInspector.kt#o13vsk"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    if-ne v2, v4, :cond_1

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    .line 385
    :cond_0
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_4

    .line 0
    :cond_1
    :goto_0
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, -0x1

    const-string v4, "org.lighttouch.android.ComposableSingletons$HitchInspectorKt.lambda$-1721490424.<anonymous> (HitchInspector.kt:125)"

    const v5, -0x669bdbf8

    invoke-static {v5, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 126
    :cond_2
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v4, 0xe

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 343
    .local v5, "$i$f$getDp\\1\\126":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 126
    .end local v4    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\126":I
    invoke-static {v2, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x6

    .local v4, "$changed\\2":I
    const/4 v5, 0x0

    .line 344
    .local v5, "$i$f$Row\\2\\126":I
    const v6, 0x2952b718

    const-string v7, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v0, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 345
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v6

    .line 346
    .local v6, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 349
    .local v7, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v8, v4, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v9, v4, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v8, v9

    invoke-static {v6, v7, v0, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v4, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 350
    nop

    .local v9, "$changed\\3":I
    const/4 v10, 0x0

    .line 351
    .local v10, "$i$f$Layout\\3\\350":I
    const v11, -0x4ee9b9da

    const-string v12, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v0, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 352
    const/4 v11, 0x0

    invoke-static {v0, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v11

    .line 353
    .local v11, "compositeKeyHash\\3":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 354
    .local v12, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v0, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 356
    .local v13, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v14

    shl-int/lit8 v15, v9, 0x6

    and-int/lit16 v15, v15, 0x380

    const/4 v1, 0x6

    or-int/2addr v15, v1

    .line 355
    nop

    .local v14, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v15, "$changed\\4":I
    const/16 v16, 0x0

    .line 357
    .local v16, "$i$f$ReusableComposeNode\\4\\355":I
    move/from16 v17, v1

    const v1, -0x2942ffcf

    move-object/from16 v18, v2

    .end local v2    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\2":Landroidx/compose/ui/Modifier;
    const-string v2, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 358
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 359
    :cond_3
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 360
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_4

    .line 361
    invoke-interface {v0, v14}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1

    .line 363
    :cond_4
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 365
    :goto_1
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 366
    .local v2, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 367
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 369
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 370
    .local v19, "$i$f$set-impl\\6\\369":I
    move-object/from16 v20, v1

    .local v20, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 371
    .local v21, "$i$a$-with-Updater$set$1\\7\\370\\6":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_6

    move/from16 v22, v2

    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_5

    goto :goto_2

    :cond_5
    move-object/from16 v3, v20

    goto :goto_3

    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    .restart local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    :cond_6
    move/from16 v22, v2

    .line 372
    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    .restart local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    :goto_2
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 373
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 375
    :goto_3
    nop

    .line 370
    .end local v3    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\7\\370\\6":I
    nop

    .line 375
    nop

    .line 376
    .end local v0    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\6\\369":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 377
    nop

    .line 365
    .end local v1    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\365\\3":I
    nop

    .line 378
    shr-int/lit8 v0, v15, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object/from16 v1, p2

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 379
    .local v2, "$i$a$-Layout-RowKt$Row$1\\8\\378\\2":I
    const v3, -0x184f2606

    move/from16 v19, v0

    .end local v0    # "$changed\\8":I
    .local v19, "$changed\\8":I
    const-string v0, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v3, v4, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v25, v1

    .local v25, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v45, 0x0

    .line 127
    .local v45, "$i$a$-Row-ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1$1\\9\\379\\0":I
    move-object/from16 v46, v0

    .end local v0    # "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v46, "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const v0, 0x257f67a8

    move-object/from16 v47, v1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v47, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C126@7877L11,126@7809L88,127@7918L29,129@8187L10,128@7968L240:HitchInspector.kt#o13vsk"

    move/from16 v48, v2

    move-object/from16 v2, v25

    .end local v25    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v48, "$i$a$-Layout-RowKt$Row$1\\8\\378\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getInfo()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v20

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x14

    .local v1, "$this$dp\\10":I
    const/16 v21, 0x0

    .line 380
    .local v21, "$i$f$getDp\\10\\127":I
    move/from16 v49, v3

    .end local v3    # "$changed\\9":I
    .local v49, "$changed\\9":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 127
    .end local v1    # "$this$dp\\10":I
    .end local v21    # "$i$f$getDp\\10\\127":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v22

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v23

    const/16 v26, 0x1b0

    const/16 v27, 0x0

    const/16 v21, 0x0

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v25    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v27}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .line 128
    .end local v25    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0xc

    .local v1, "$this$dp\\11":I
    const/4 v3, 0x0

    .line 381
    .local v3, "$i$f$getDp\\11\\128":I
    move/from16 v20, v3

    .end local v3    # "$i$f$getDp\\11\\128":I
    .local v20, "$i$f$getDp\\11\\128":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 128
    .end local v1    # "$this$dp\\11":I
    .end local v20    # "$i$f$getDp\\11\\128":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v17

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 129
    nop

    .line 130
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v40

    .line 129
    const-string v20, "\u5728\u300c\u8bbe\u7f6e \u203a \u8bca\u65ad\u300d\u4e2d\u5f00\u542f\u300c\u8be6\u7ec6\u5e27\u8ba1\u65f6\u300d\uff0c\u5373\u53ef\u770b\u5230\u6bcf\u5e27\u7684\u65f6\u95f4\u53bb\u5411\uff1a\u5ba2\u6237\u673a CPU\u3001GL \u4e0e\u9501\u7b49\u5f85\u3002\u5f00\u542f\u65f6\u4f1a\u635f\u5931\u51e0\u4e2a\u767e\u5206\u70b9\u7684\u901f\u5ea6\u3002"

    const-wide/16 v22, 0x0

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v42, 0x6

    const/16 v43, 0x0

    const v44, 0xfffe

    move-object/from16 v41, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v44}, Landroidx/compose/material3/TextKt;->Text--4IGK_g(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 127
    .end local v41    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 131
    nop

    .line 379
    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v45    # "$i$a$-Row-ComposableSingletons$HitchInspectorKt$lambda$-1721490424$1$1\\9\\379\\0":I
    .end local v46    # "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v49    # "$changed\\9":I
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 378
    .end local v19    # "$changed\\8":I
    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v48    # "$i$a$-Layout-RowKt$Row$1\\8\\378\\2":I
    nop

    .line 382
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 357
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 383
    nop

    .line 351
    .end local v14    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v15    # "$changed\\4":I
    .end local v16    # "$i$f$ReusableComposeNode\\4\\355":I
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 384
    nop

    .line 344
    .end local v9    # "$changed\\3":I
    .end local v10    # "$i$f$Layout\\3\\350":I
    .end local v11    # "compositeKeyHash\\3":I
    .end local v12    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v13    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {p2 .. p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 385
    nop

    .end local v4    # "$changed\\2":I
    .end local v5    # "$i$f$Row\\2\\126":I
    .end local v6    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v7    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v8    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v18    # "modifier\\2":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 132
    :cond_7
    :goto_4
    return-void
.end method

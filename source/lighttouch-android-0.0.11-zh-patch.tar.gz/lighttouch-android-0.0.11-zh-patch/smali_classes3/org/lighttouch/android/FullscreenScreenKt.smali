.class public final Lorg/lighttouch/android/FullscreenScreenKt;
.super Ljava/lang/Object;
.source "FullscreenScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nFullscreenScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FullscreenScreen.kt\norg/lighttouch/android/FullscreenScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 9 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 10 Dp.kt\nandroidx/compose/ui/unit/Dp\n+ 11 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,156:1\n1225#2,6:157\n1225#2,6:163\n1225#2,6:279\n1225#2,6:324\n1225#2,6:330\n1225#2,6:350\n1225#2,6:356\n1225#2,6:403\n1225#2,6:452\n1225#2,6:458\n149#3:169\n149#3:242\n149#3:285\n149#3:286\n149#3:349\n149#3:397\n149#3:402\n149#3:444\n149#3:449\n159#3:451\n159#3:500\n99#4:170\n96#4,6:171\n102#4:205\n99#4:206\n96#4,6:207\n102#4:241\n106#4:246\n99#4,3:247\n102#4:278\n106#4:343\n106#4:347\n79#5,6:177\n86#5,4:192\n90#5,2:202\n79#5,6:213\n86#5,4:228\n90#5,2:238\n94#5:245\n79#5,6:250\n86#5,4:265\n90#5,2:275\n79#5,6:295\n86#5,4:310\n90#5,2:320\n94#5:338\n94#5:342\n94#5:346\n79#5,6:368\n86#5,4:383\n90#5,2:393\n94#5:400\n79#5,6:415\n86#5,4:430\n90#5,2:440\n94#5:447\n79#5,6:470\n86#5,4:485\n90#5,2:495\n94#5:503\n368#6,9:183\n377#6:204\n368#6,9:219\n377#6:240\n378#6,2:243\n368#6,9:256\n377#6:277\n368#6,9:301\n377#6:322\n378#6,2:336\n378#6,2:340\n378#6,2:344\n368#6,9:374\n377#6:395\n378#6,2:398\n368#6,9:421\n377#6:442\n378#6,2:445\n368#6,9:476\n377#6:497\n378#6,2:501\n4034#7,6:196\n4034#7,6:232\n4034#7,6:269\n4034#7,6:314\n4034#7,6:387\n4034#7,6:434\n4034#7,6:489\n71#8:287\n67#8,7:288\n74#8:323\n78#8:339\n71#8:362\n69#8,5:363\n74#8:396\n78#8:401\n71#8:409\n69#8,5:410\n74#8:443\n78#8:448\n71#8:464\n69#8,5:465\n74#8:498\n78#8:504\n77#9:348\n77#9:450\n84#10:499\n81#11:505\n107#11,2:506\n*S KotlinDebug\n*F\n+ 1 FullscreenScreen.kt\norg/lighttouch/android/FullscreenScreenKt\n*L\n83#1:157,6\n84#1:163,6\n96#1:279,6\n102#1:324,6\n103#1:330,6\n130#1:350,6\n131#1:356,6\n140#1:403,6\n150#1:452,6\n151#1:458,6\n86#1:169\n90#1:242\n97#1:285\n100#1:286\n129#1:349\n133#1:397\n139#1:402\n141#1:444\n147#1:449\n149#1:451\n153#1:500\n86#1:170\n86#1:171,6\n86#1:205\n88#1:206\n88#1:207,6\n88#1:241\n88#1:246\n94#1:247,3\n94#1:278\n94#1:343\n86#1:347\n86#1:177,6\n86#1:192,4\n86#1:202,2\n88#1:213,6\n88#1:228,4\n88#1:238,2\n88#1:245\n94#1:250,6\n94#1:265,4\n94#1:275,2\n101#1:295,6\n101#1:310,4\n101#1:320,2\n101#1:338\n94#1:342\n86#1:346\n129#1:368,6\n129#1:383,4\n129#1:393,2\n129#1:400\n139#1:415,6\n139#1:430,4\n139#1:440,2\n139#1:447\n149#1:470,6\n149#1:485,4\n149#1:495,2\n149#1:503\n86#1:183,9\n86#1:204\n88#1:219,9\n88#1:240\n88#1:243,2\n94#1:256,9\n94#1:277\n101#1:301,9\n101#1:322\n101#1:336,2\n94#1:340,2\n86#1:344,2\n129#1:374,9\n129#1:395\n129#1:398,2\n139#1:421,9\n139#1:442\n139#1:445,2\n149#1:476,9\n149#1:497\n149#1:501,2\n86#1:196,6\n88#1:232,6\n94#1:269,6\n101#1:314,6\n129#1:387,6\n139#1:434,6\n149#1:489,6\n101#1:287\n101#1:288,7\n101#1:323\n101#1:339\n129#1:362\n129#1:363,5\n129#1:396\n129#1:401\n139#1:409\n139#1:410,5\n139#1:443\n139#1:448\n149#1:464\n149#1:465,5\n149#1:498\n149#1:504\n128#1:348\n148#1:450\n153#1:499\n84#1:505\n84#1:506,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008\u0007\u001a.\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0017\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00010\u0005\u00a2\u0006\u0002\u0008\u0007H\u0001\u00a2\u0006\u0002\u0010\u0008\u001a;\u0010\t\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u00062\u000e\u0008\u0002\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000c2\u000c\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000cH\u0003\u00a2\u0006\u0002\u0010\u000e\u001aK\u0010\u000f\u001a\u00020\u00012\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0016\u001a\u00020\u00172\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000c2\u0006\u0010\u0018\u001a\u00020\u0013H\u0003\u00a2\u0006\u0002\u0010\u0019\u001a;\u0010\u001a\u001a\u00020\u00012\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u000c\u0010\u001b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000c2\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0013H\u0003\u00a2\u0006\u0002\u0010\u001c\u001a7\u0010\u001d\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0016\u001a\u00020\u00172\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000c2\u0008\u0008\u0002\u0010\u001e\u001a\u00020\u001fH\u0003\u00a2\u0006\u0004\u0008 \u0010!\u00a8\u0006\"\u00b2\u0006\n\u0010#\u001a\u00020\u0017X\u008a\u008e\u0002\u00b2\u0006\n\u0010$\u001a\u00020\u0017X\u008a\u008e\u0002\u00b2\u0006\n\u0010%\u001a\u00020\u0015X\u008a\u008e\u0002\u00b2\u0006\n\u0010&\u001a\u00020\u0017X\u008a\u008e\u0002"
    }
    d2 = {
        "FullscreenScreen",
        "",
        "host",
        "Lorg/lighttouch/android/GuestHost;",
        "guestSurface",
        "Lkotlin/Function1;",
        "Landroidx/compose/ui/Modifier;",
        "Landroidx/compose/runtime/Composable;",
        "(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V",
        "ButtonBar",
        "modifier",
        "onInteract",
        "Lkotlin/Function0;",
        "onStop",
        "(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "HardwareKey",
        "icon",
        "Landroidx/compose/ui/graphics/vector/ImageVector;",
        "label",
        "",
        "id",
        "",
        "enabled",
        "",
        "tag",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "SmallKey",
        "onClick",
        "(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "HomeKey",
        "size",
        "Landroidx/compose/ui/unit/Dp;",
        "HomeKey--jt2gSs",
        "(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FLandroidx/compose/runtime/Composer;II)V",
        "app_debug",
        "confirmStop",
        "visible",
        "touched",
        "menu"
    }
    k = 0x2
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$8g6Pg1WcPgek9bCuwO8VuB8t1z0(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$15$lambda$14$lambda$8$lambda$7(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9puAXEORwSB7DyqOR8OuoUlpFqE(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;IZ)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey$lambda$20$lambda$19(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;IZ)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$AqpWN-JUOLLtFGtN8AM4TZE5tOw()Lkotlin/Unit;
    .locals 1

    invoke-static {}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$2$lambda$1()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$CmAZDvo1hP9ATnGdg_SH33B78Js(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->SmallKey$lambda$26$lambda$25(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$L1x7aI-oKbnK14zd0gjT7wH0trQ(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lorg/lighttouch/android/FullscreenScreenKt;->FullscreenScreen$lambda$0(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NQGKthAdTsgpHAAPc4gq87361kY(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$15$lambda$14$lambda$13$lambda$12$lambda$11(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$VHoawud4ZnsvmMXh3tqJJgUMebQ(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p9}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey$lambda$24(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZJ6i9eFNuyAoEvrKMBAfIRwpoKE(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->HomeKey__jt2gSs$lambda$34$lambda$33(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_p3uHAVumQeWsTAe7kwDzXc1nRE(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey$lambda$22$lambda$21(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fCE-AYG1T96r1dRd-GEx2NnpUh4(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey$lambda$18$lambda$17(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fMxhWR6qgrB7Me6ie7K8TOm14uQ(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/FullscreenScreenKt;->SmallKey$lambda$28(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g3yr_Od4lTbYBP8e9-teIz5KFXY(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$16(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mLy21Ds6MIYZp7cCvEnUHrdfdG8(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 0

    invoke-static/range {p0 .. p7}, Lorg/lighttouch/android/FullscreenScreenKt;->HomeKey__jt2gSs$lambda$36(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vs8GT2EMCzulz0PxgDbvUd7UQok(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0}, Lorg/lighttouch/android/FullscreenScreenKt;->HomeKey__jt2gSs$lambda$30$lambda$29(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$z-ZDll3gBoPRbYGRnviesR3sIQs(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;IZ)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lorg/lighttouch/android/FullscreenScreenKt;->HomeKey__jt2gSs$lambda$32$lambda$31(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;IZ)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$zDZ7n43wP9zDvtVyaPk4YdM04h4(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 0

    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$15$lambda$14$lambda$13$lambda$10$lambda$9(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method private static final ButtonBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .locals 92
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p2, "onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onStop"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Landroidx/compose/ui/Modifier;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    .line 83
    move-object/from16 v3, p0

    move-object/from16 v9, p1

    move-object/from16 v10, p3

    move/from16 v11, p5

    const v0, 0x16a8c787

    move-object/from16 v1, p4

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const-string v0, "C(ButtonBar)82@4913L2,83@4955L34,85@5025L3277:FullscreenScreen.kt#o13vsk"

    invoke-static {v12, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v0, p5

    .local v0, "$dirty":I
    and-int/lit8 v1, p6, 0x1

    const/4 v14, 0x2

    if-eqz v1, :cond_0

    or-int/lit8 v0, v0, 0x6

    goto :goto_2

    :cond_0
    and-int/lit8 v1, v11, 0x6

    if-nez v1, :cond_3

    and-int/lit8 v1, v11, 0x8

    if-nez v1, :cond_1

    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    goto :goto_0

    :cond_1
    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    :goto_0
    if-eqz v1, :cond_2

    const/4 v1, 0x4

    goto :goto_1

    :cond_2
    move v1, v14

    :goto_1
    or-int/2addr v0, v1

    :cond_3
    :goto_2
    and-int/lit8 v1, p6, 0x2

    if-eqz v1, :cond_4

    or-int/lit8 v0, v0, 0x30

    goto :goto_4

    :cond_4
    and-int/lit8 v1, v11, 0x30

    if-nez v1, :cond_6

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    const/16 v1, 0x20

    goto :goto_3

    :cond_5
    const/16 v1, 0x10

    :goto_3
    or-int/2addr v0, v1

    :cond_6
    :goto_4
    and-int/lit8 v1, p6, 0x4

    if-eqz v1, :cond_7

    or-int/lit16 v0, v0, 0x180

    move-object/from16 v2, p2

    goto :goto_6

    :cond_7
    and-int/lit16 v2, v11, 0x180

    if-nez v2, :cond_9

    move-object/from16 v2, p2

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    const/16 v4, 0x100

    goto :goto_5

    :cond_8
    const/16 v4, 0x80

    :goto_5
    or-int/2addr v0, v4

    goto :goto_6

    :cond_9
    move-object/from16 v2, p2

    :goto_6
    and-int/lit8 v4, p6, 0x8

    if-eqz v4, :cond_a

    or-int/lit16 v0, v0, 0xc00

    goto :goto_8

    :cond_a
    and-int/lit16 v4, v11, 0xc00

    if-nez v4, :cond_c

    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_b

    const/16 v4, 0x800

    goto :goto_7

    :cond_b
    const/16 v4, 0x400

    :goto_7
    or-int/2addr v0, v4

    :cond_c
    :goto_8
    and-int/lit16 v4, v0, 0x493

    const/16 v5, 0x492

    if-ne v4, v5, :cond_e

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_d

    goto :goto_9

    .line 347
    :cond_d
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v9, v0

    move-object v3, v2

    move-object v4, v10

    move-object/from16 v57, v12

    goto/16 :goto_23

    .line 83
    :cond_e
    :goto_9
    const-string v4, "CC(remember):FullscreenScreen.kt#9igjgp"

    if-eqz v1, :cond_10

    const v1, 0x6e3c21fe

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v12, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v1, 0x0

    .local v1, "invalid\\1":Z
    move-object v5, v12

    .local v5, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 157
    .local v6, "$i$f$cache\\1\\83":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\1":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 158
    .local v8, "$i$a$-let-ComposerKt$cache$1\\2\\157\\1":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v7, v13, :cond_f

    .line 159
    const/4 v13, 0x0

    .local v13, "$i$a$-cache-FullscreenScreenKt$ButtonBar$1\\3\\159\\0":I
    new-instance v16, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda13;

    invoke-direct/range {v16 .. v16}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda13;-><init>()V

    .end local v13    # "$i$a$-cache-FullscreenScreenKt$ButtonBar$1\\3\\159\\0":I
    move-object/from16 v13, v16

    .line 160
    .local v13, "value\\2":Ljava/lang/Object;
    invoke-interface {v5, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 161
    nop

    .end local v13    # "value\\2":Ljava/lang/Object;
    goto :goto_a

    .line 162
    :cond_f
    move-object v13, v7

    .line 158
    :goto_a
    nop

    .line 157
    .end local v7    # "it\\1":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\2\\157\\1":I
    nop

    .line 83
    .end local v1    # "invalid\\1":Z
    .end local v5    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\1\\83":I
    move-object v1, v13

    check-cast v1, Lkotlin/jvm/functions/Function0;

    .end local p2    # "onInteract":Lkotlin/jvm/functions/Function0;
    .local v1, "onInteract":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object v5, v1

    goto :goto_b

    .end local v1    # "onInteract":Lkotlin/jvm/functions/Function0;
    .restart local p2    # "onInteract":Lkotlin/jvm/functions/Function0;
    :cond_10
    move-object v5, v2

    .end local p2    # "onInteract":Lkotlin/jvm/functions/Function0;
    .local v5, "onInteract":Lkotlin/jvm/functions/Function0;
    :goto_b
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_11

    const/4 v1, -0x1

    const-string v2, "org.lighttouch.android.ButtonBar (FullscreenScreen.kt:82)"

    const v6, 0x16a8c787

    invoke-static {v6, v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_11
    const v1, 0x6e3c21fe

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v12, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 84
    const/4 v13, 0x0

    move v1, v13

    .local v1, "invalid\\4":Z
    move-object v2, v12

    .local v2, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 163
    .local v6, "$i$f$cache\\4\\84":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\4":Ljava/lang/Object;
    const/4 v8, 0x0

    .line 164
    .local v8, "$i$a$-let-ComposerKt$cache$1\\5\\163\\4":I
    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    move/from16 p2, v13

    const/4 v13, 0x0

    if-ne v7, v15, :cond_12

    .line 165
    const/4 v15, 0x0

    .line 84
    .local v15, "$i$a$-cache-FullscreenScreenKt$ButtonBar$menu$2\\6\\165\\0":I
    move/from16 v16, v0

    .end local v0    # "$dirty":I
    .local v16, "$dirty":I
    invoke-static/range {p2 .. p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0, v13, v14, v13}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 165
    .end local v15    # "$i$a$-cache-FullscreenScreenKt$ButtonBar$menu$2\\6\\165\\0":I
    nop

    .line 166
    .local v0, "value\\5":Ljava/lang/Object;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 167
    nop

    .end local v0    # "value\\5":Ljava/lang/Object;
    goto :goto_c

    .line 168
    .end local v16    # "$dirty":I
    .local v0, "$dirty":I
    :cond_12
    move/from16 v16, v0

    .end local v0    # "$dirty":I
    .restart local v16    # "$dirty":I
    move-object v0, v7

    .line 164
    :goto_c
    nop

    .line 163
    .end local v7    # "it\\4":Ljava/lang/Object;
    .end local v8    # "$i$a$-let-ComposerKt$cache$1\\5\\163\\4":I
    nop

    .line 84
    .end local v1    # "invalid\\4":Z
    .end local v2    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\4\\84":I
    move-object v15, v0

    check-cast v15, Landroidx/compose/runtime/MutableState;

    .local v15, "menu$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 85
    invoke-static {v3}, Lorg/lighttouch/android/ShellKt;->getRunning(Lorg/lighttouch/android/GuestHost;)Z

    move-result v1

    .line 86
    .local v1, "enabled":Z
    const/16 v0, 0x14

    .local v0, "$this$dp\\7":I
    const/4 v2, 0x0

    .line 169
    .local v2, "$i$f$getDp\\7\\86":I
    int-to-float v6, v0

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 86
    .end local v0    # "$this$dp\\7":I
    .end local v2    # "$i$f$getDp\\7\\86":I
    const/4 v2, 0x0

    invoke-static {v9, v0, v2, v14, v13}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .local v13, "modifier\\8":Landroidx/compose/ui/Modifier;
    sget-object v0, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v0

    .local v0, "verticalAlignment\\8":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v2, 0x180

    .local v2, "$changed\\8":I
    move/from16 v18, v2

    .end local v2    # "$changed\\8":I
    .local v18, "$changed\\8":I
    const/16 v19, 0x0

    .line 170
    .local v19, "$i$f$Row\\8\\86":I
    const v2, 0x2952b718

    const-string v6, "CC(Row)P(2,1,3)99@5018L58,100@5081L130:Row.kt#2w3rfo"

    invoke-static {v12, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 171
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v7

    .line 175
    .local v7, "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v8, v18, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v20, v18, 0x3

    and-int/lit8 v20, v20, 0x70

    or-int v8, v8, v20

    invoke-static {v7, v0, v12, v8}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .local v8, "measurePolicy\\8":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v20, v18, 0x3

    and-int/lit8 v20, v20, 0x70

    .line 176
    nop

    .local v20, "$changed\\9":I
    const/16 v21, 0x0

    .line 177
    .local v21, "$i$f$Layout\\9\\176":I
    const v14, -0x4ee9b9da

    const-string v2, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v12, v14, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 178
    move/from16 v14, p2

    invoke-static {v12, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v25

    .line 179
    .local v25, "compositeKeyHash\\9":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 180
    .local v14, "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v12, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 182
    .local v9, "materialized\\9":Landroidx/compose/ui/Modifier;
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v26

    move-object/from16 v27, v0

    .end local v0    # "verticalAlignment\\8":Landroidx/compose/ui/Alignment$Vertical;
    .local v27, "verticalAlignment\\8":Landroidx/compose/ui/Alignment$Vertical;
    shl-int/lit8 v0, v20, 0x6

    and-int/lit16 v0, v0, 0x380

    const/4 v11, 0x6

    or-int/2addr v0, v11

    .line 181
    move/from16 v28, v0

    .local v28, "$changed\\10":I
    move-object/from16 v0, v26

    .local v0, "factory\\10":Lkotlin/jvm/functions/Function0;
    const/16 v26, 0x0

    .line 183
    .local v26, "$i$f$ReusableComposeNode\\10\\181":I
    move/from16 v29, v11

    const v11, -0x2942ffcf

    move-object/from16 v30, v13

    .end local v13    # "modifier\\8":Landroidx/compose/ui/Modifier;
    .local v30, "modifier\\8":Landroidx/compose/ui/Modifier;
    const-string v13, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v12, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 184
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v11

    instance-of v11, v11, Landroidx/compose/runtime/Applier;

    if-nez v11, :cond_13

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 185
    :cond_13
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 186
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v11

    if-eqz v11, :cond_14

    .line 187
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d

    .line 189
    :cond_14
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 191
    :goto_d
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .local v11, "$this$Layout_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 192
    .local v32, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\11\\191\\9":I
    sget-object v33, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v34, v0

    .end local v0    # "factory\\10":Lkotlin/jvm/functions/Function0;
    .local v34, "factory\\10":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v33 .. v33}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v11, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 193
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v11, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 195
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\12":Lkotlin/jvm/functions/Function2;
    const/16 v33, 0x0

    .line 196
    .local v33, "$i$f$set-impl\\12\\195":I
    move-object/from16 v35, v11

    .local v35, "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 197
    .local v36, "$i$a$-with-Updater$set$1\\13\\196\\12":I
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v37

    if-nez v37, :cond_16

    move/from16 v37, v1

    .end local v1    # "enabled":Z
    .local v37, "enabled":Z
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_15

    goto :goto_e

    :cond_15
    move-object/from16 v3, v35

    goto :goto_f

    .end local v37    # "enabled":Z
    .restart local v1    # "enabled":Z
    :cond_16
    move/from16 v37, v1

    .line 198
    .end local v1    # "enabled":Z
    .restart local v37    # "enabled":Z
    :goto_e
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v3, v35

    .end local v35    # "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 199
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v11, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 201
    :goto_f
    nop

    .line 196
    .end local v3    # "$this$set_impl_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-with-Updater$set$1\\13\\196\\12":I
    nop

    .line 201
    nop

    .line 202
    .end local v0    # "block\\12":Lkotlin/jvm/functions/Function2;
    .end local v33    # "$i$f$set-impl\\12\\195":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v11, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 203
    nop

    .line 191
    .end local v11    # "$this$Layout_u24lambda_u240\\11":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\11\\191\\9":I
    nop

    .line 204
    shr-int/lit8 v0, v28, 0x6

    and-int/lit8 v11, v0, 0xe

    .local v11, "$changed\\14":I
    move-object v0, v12

    .local v0, "$composer\\14":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 205
    .local v32, "$i$a$-Layout-RowKt$Row$1\\14\\204\\8":I
    const v1, -0x184f2606

    const-string v3, "C101@5126L9:Row.kt#2w3rfo"

    invoke-static {v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v33, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v35, v18, 0x6

    and-int/lit8 v35, v35, 0x70

    or-int/lit8 v35, v35, 0x6

    .local v35, "$changed\\15":I
    check-cast v33, Landroidx/compose/foundation/layout/RowScope;

    .local v33, "$this$ButtonBar_u24lambda_u2415\\15":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v38, v33

    .end local v33    # "$this$ButtonBar_u24lambda_u2415\\15":Landroidx/compose/foundation/layout/RowScope;
    .local v38, "$this$ButtonBar_u24lambda_u2415\\15":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v33, v0

    .local v33, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 88
    .local v36, "$i$a$-Row-FullscreenScreenKt$ButtonBar$2\\15\\205\\0":I
    const v1, 0x3b868631

    move-object/from16 v45, v0

    .end local v0    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\14":Landroidx/compose/runtime/Composer;
    const-string v0, "C87@5185L387,92@5581L34,93@5624L2672:FullscreenScreen.kt#o13vsk"

    move-object/from16 v46, v9

    move-object/from16 v9, v33

    .end local v33    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v46, "materialized\\9":Landroidx/compose/ui/Modifier;
    invoke-static {v9, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v39, v0

    check-cast v39, Landroidx/compose/ui/Modifier;

    const/16 v42, 0x2

    const/16 v43, 0x0

    const/high16 v40, 0x3f800000    # 1.0f

    const/16 v41, 0x0

    invoke-static/range {v38 .. v43}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\16":Landroidx/compose/ui/Modifier;
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v1

    .local v1, "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v33, 0x180

    .local v33, "$changed\\16":I
    const/16 v39, 0x0

    .line 206
    .local v39, "$i$f$Row\\16\\88":I
    move-object/from16 v40, v4

    const v4, 0x2952b718

    invoke-static {v9, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 207
    sget-object v23, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move/from16 v47, v11

    .end local v11    # "$changed\\14":I
    .local v47, "$changed\\14":I
    invoke-virtual/range {v23 .. v23}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v11

    .line 211
    .local v11, "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v23, v33, 0x3

    and-int/lit8 v23, v23, 0xe

    shr-int/lit8 v41, v33, 0x3

    and-int/lit8 v41, v41, 0x70

    or-int v4, v23, v41

    invoke-static {v11, v1, v9, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .local v4, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v23, v33, 0x3

    and-int/lit8 v23, v23, 0x70

    .line 212
    nop

    .local v23, "$changed\\17":I
    const/16 v41, 0x0

    .line 213
    .local v41, "$i$f$Layout\\17\\212":I
    move-object/from16 v43, v1

    const v1, -0x4ee9b9da

    .end local v1    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .local v43, "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v9, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 214
    const/4 v1, 0x0

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v48

    .line 215
    .local v48, "compositeKeyHash\\17":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 216
    .local v1, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v49, v2

    invoke-static {v9, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 218
    .local v2, "materialized\\17":Landroidx/compose/ui/Modifier;
    sget-object v50, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v50 .. v50}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v50

    move-object/from16 v51, v0

    .end local v0    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .local v51, "modifier\\16":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v23, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 217
    move/from16 v52, v0

    .local v52, "$changed\\18":I
    move-object/from16 v0, v50

    .local v0, "factory\\18":Lkotlin/jvm/functions/Function0;
    const/16 v50, 0x0

    .line 219
    .local v50, "$i$f$ReusableComposeNode\\18\\217":I
    move-object/from16 v53, v5

    const v5, -0x2942ffcf

    .end local v5    # "onInteract":Lkotlin/jvm/functions/Function0;
    .local v53, "onInteract":Lkotlin/jvm/functions/Function0;
    invoke-static {v9, v5, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 220
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_17

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 221
    :cond_17
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 222
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_18

    .line 223
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_10

    .line 225
    :cond_18
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 227
    :goto_10
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    const/16 v54, 0x0

    .line 228
    .local v54, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\227\\17":I
    sget-object v55, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v56, v0

    .end local v0    # "factory\\18":Lkotlin/jvm/functions/Function0;
    .local v56, "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v55 .. v55}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 229
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 231
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\20":Lkotlin/jvm/functions/Function2;
    const/16 v55, 0x0

    .line 232
    .local v55, "$i$f$set-impl\\20\\231":I
    move-object/from16 v57, v5

    .local v57, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 233
    .local v58, "$i$a$-with-Updater$set$1\\21\\232\\20":I
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v59

    if-nez v59, :cond_1a

    move-object/from16 v59, v1

    .end local v1    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .local v59, "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v60, v4

    .end local v4    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v60, "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v48 .. v48}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19

    goto :goto_11

    :cond_19
    move-object/from16 v4, v57

    goto :goto_12

    .end local v59    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v60    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v1    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_1a
    move-object/from16 v59, v1

    move-object/from16 v60, v4

    .line 234
    .end local v1    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v59    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v60    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_11
    invoke-static/range {v48 .. v48}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v4, v57

    .end local v57    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 235
    invoke-static/range {v48 .. v48}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v5, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 237
    :goto_12
    nop

    .line 232
    .end local v4    # "$this$set_impl_u24lambda_u240\\20":Landroidx/compose/runtime/Composer;
    .end local v58    # "$i$a$-with-Updater$set$1\\21\\232\\20":I
    nop

    .line 237
    nop

    .line 238
    .end local v0    # "block\\20":Lkotlin/jvm/functions/Function2;
    .end local v55    # "$i$f$set-impl\\20\\231":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 239
    nop

    .line 227
    .end local v5    # "$this$Layout_u24lambda_u240\\19":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\19\\227\\17":I
    nop

    .line 240
    shr-int/lit8 v0, v52, 0x6

    and-int/lit8 v54, v0, 0xe

    .local v54, "$changed\\22":I
    move-object v0, v9

    .local v0, "$composer\\22":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 241
    .local v55, "$i$a$-Layout-RowKt$Row$1\\22\\240\\16":I
    const v1, -0x184f2606

    invoke-static {v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v33, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v44, v5, 0x6

    .local v44, "$changed\\23":I
    check-cast v4, Landroidx/compose/foundation/layout/RowScope;

    move-object v5, v7

    .end local v7    # "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v4, "$this$ButtonBar_u24lambda_u2415_u24lambda_u246\\23":Landroidx/compose/foundation/layout/RowScope;
    .local v5, "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    move-object v7, v0

    .local v7, "$composer\\23":Landroidx/compose/runtime/Composer;
    move-object/from16 v57, v4

    .end local v4    # "$this$ButtonBar_u24lambda_u2415_u24lambda_u246\\23":Landroidx/compose/foundation/layout/RowScope;
    .local v57, "$this$ButtonBar_u24lambda_u2415_u24lambda_u246\\23":Landroidx/compose/foundation/layout/RowScope;
    const/16 v58, 0x0

    .line 89
    .local v58, "$i$a$-Row-FullscreenScreenKt$ButtonBar$2$1\\23\\241\\15":I
    const v4, 0x4f150db2    # 2.5007027E9f

    const-string v1, "C88@5272L122,89@5407L28,90@5448L114:FullscreenScreen.kt#o13vsk"

    invoke-static {v7, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getVolumeDown()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    shl-int/lit8 v4, v16, 0x9

    and-int/lit16 v4, v4, 0x1c00

    const v62, 0x1801b0

    or-int v4, v4, v62

    shl-int/lit8 v62, v16, 0x9

    const/high16 v63, 0x70000

    and-int v62, v62, v63

    or-int v4, v4, v62

    move-object/from16 v62, v0

    move-object v0, v1

    .end local v0    # "$composer\\22":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\22":Landroidx/compose/runtime/Composer;
    const-string v1, "\u97f3\u91cf \u2212"

    move-object/from16 v63, v2

    .end local v2    # "materialized\\17":Landroidx/compose/ui/Modifier;
    .local v63, "materialized\\17":Landroidx/compose/ui/Modifier;
    const/4 v2, 0x3

    move-object/from16 v64, v6

    const-string v6, "fs_volume_down"

    move-object v10, v8

    move v8, v4

    move/from16 v4, v37

    move-object/from16 v37, v34

    move-object/from16 v34, v10

    move-object/from16 v65, v9

    move/from16 v9, v16

    move-object/from16 v67, v40

    move-object/from16 v66, v49

    const v10, 0x2952b718

    move-object/from16 v16, v5

    move-object/from16 v40, v11

    move-object/from16 v49, v14

    move-object/from16 v5, v53

    move-object/from16 v14, v64

    move-object v11, v3

    move-object/from16 v3, p0

    .end local v8    # "measurePolicy\\8":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v11    # "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v14    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v53    # "onInteract":Lkotlin/jvm/functions/Function0;
    .local v4, "enabled":Z
    .local v5, "onInteract":Lkotlin/jvm/functions/Function0;
    .local v9, "$dirty":I
    .local v16, "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v34, "measurePolicy\\8":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v37, "factory\\10":Lkotlin/jvm/functions/Function0;
    .local v40, "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v49, "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    .local v65, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 90
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x8

    .local v1, "$this$dp\\24":I
    const/4 v2, 0x0

    .line 242
    .local v2, "$i$f$getDp\\24\\90":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 90
    .end local v1    # "$this$dp\\24":I
    .end local v2    # "$i$f$getDp\\24\\90":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v1, v29

    invoke-static {v0, v7, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 91
    sget-object v0, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v0}, Lorg/lighttouch/android/LtIcons;->getVolumeUp()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v0

    shl-int/lit8 v1, v9, 0x9

    and-int/lit16 v1, v1, 0x1c00

    const v2, 0x1801b0

    or-int/2addr v1, v2

    shl-int/lit8 v2, v9, 0x9

    const/high16 v3, 0x70000

    and-int/2addr v2, v3

    or-int v8, v1, v2

    const-string v1, "\u97f3\u91cf +"

    const/4 v2, 0x2

    const-string v6, "fs_volume_up"

    move-object/from16 v3, p0

    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 89
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 92
    nop

    .line 241
    .end local v7    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v44    # "$changed\\23":I
    .end local v57    # "$this$ButtonBar_u24lambda_u2415_u24lambda_u246\\23":Landroidx/compose/foundation/layout/RowScope;
    .end local v58    # "$i$a$-Row-FullscreenScreenKt$ButtonBar$2$1\\23\\241\\15":I
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 240
    .end local v54    # "$changed\\22":I
    .end local v55    # "$i$a$-Layout-RowKt$Row$1\\22\\240\\16":I
    .end local v62    # "$composer\\22":Landroidx/compose/runtime/Composer;
    nop

    .line 243
    invoke-interface/range {v65 .. v65}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 219
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 244
    nop

    .line 213
    .end local v50    # "$i$f$ReusableComposeNode\\18\\217":I
    .end local v52    # "$changed\\18":I
    .end local v56    # "factory\\18":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 245
    nop

    .line 206
    .end local v23    # "$changed\\17":I
    .end local v41    # "$i$f$Layout\\17\\212":I
    .end local v48    # "compositeKeyHash\\17":I
    .end local v59    # "localMap\\17":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v63    # "materialized\\17":Landroidx/compose/ui/Modifier;
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 246
    nop

    .line 93
    .end local v33    # "$changed\\16":I
    .end local v39    # "$i$f$Row\\16\\88":I
    .end local v40    # "horizontalArrangement\\16":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v43    # "verticalAlignment\\16":Landroidx/compose/ui/Alignment$Vertical;
    .end local v51    # "modifier\\16":Landroidx/compose/ui/Modifier;
    .end local v60    # "measurePolicy\\16":Landroidx/compose/ui/layout/MeasurePolicy;
    and-int/lit8 v0, v9, 0xe

    and-int/lit16 v1, v9, 0x380

    or-int/2addr v0, v1

    const/16 v6, 0x8

    const/4 v3, 0x0

    move v1, v4

    move-object v2, v5

    move-object/from16 v4, v65

    move v5, v0

    move-object/from16 v0, p0

    .end local v5    # "onInteract":Lkotlin/jvm/functions/Function0;
    .end local v65    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v1, "enabled":Z
    .local v2, "onInteract":Lkotlin/jvm/functions/Function0;
    .local v4, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v6}, Lorg/lighttouch/android/FullscreenScreenKt;->HomeKey--jt2gSs(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FLandroidx/compose/runtime/Composer;II)V

    .line 94
    move-object v3, v0

    move-object v5, v2

    move-object v0, v4

    move v4, v1

    .end local v1    # "enabled":Z
    .end local v2    # "onInteract":Lkotlin/jvm/functions/Function0;
    .local v0, "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v4, "enabled":Z
    .restart local v5    # "onInteract":Lkotlin/jvm/functions/Function0;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v39, v1

    check-cast v39, Landroidx/compose/ui/Modifier;

    const/16 v42, 0x2

    const/16 v43, 0x0

    const/high16 v40, 0x3f800000    # 1.0f

    const/16 v41, 0x0

    invoke-static/range {v38 .. v43}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\25":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v2}, Landroidx/compose/foundation/layout/Arrangement;->getEnd()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v2

    .local v2, "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    .local v6, "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v7, 0x1b0

    .local v7, "$changed\\25":I
    move/from16 v23, v7

    .end local v7    # "$changed\\25":I
    .local v23, "$changed\\25":I
    const/16 v33, 0x0

    .line 247
    .local v33, "$i$f$Row\\25\\94":I
    invoke-static {v0, v10, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 248
    shr-int/lit8 v7, v23, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v8, v23, 0x3

    and-int/lit8 v8, v8, 0x70

    or-int/2addr v7, v8

    invoke-static {v2, v6, v0, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .local v10, "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v7, v23, 0x3

    and-int/lit8 v7, v7, 0x70

    .line 249
    move v14, v7

    .local v14, "$changed\\26":I
    const/16 v39, 0x0

    .line 250
    .local v39, "$i$f$Layout\\26\\249":I
    move-object/from16 v7, v66

    const v8, -0x4ee9b9da

    invoke-static {v0, v8, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 251
    const/4 v8, 0x0

    invoke-static {v0, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v40

    .line 252
    .local v40, "compositeKeyHash\\26":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 253
    .local v8, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v41, v2

    .end local v2    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v41, "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v0, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 255
    .local v2, "materialized\\26":Landroidx/compose/ui/Modifier;
    sget-object v42, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v42 .. v42}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v42

    move-object/from16 v43, v1

    .end local v1    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\25":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v14, 0x6

    and-int/lit16 v1, v1, 0x380

    const/16 v29, 0x6

    or-int/lit8 v1, v1, 0x6

    .line 254
    move/from16 v44, v1

    .local v44, "$changed\\27":I
    move-object/from16 v1, v42

    .local v1, "factory\\27":Lkotlin/jvm/functions/Function0;
    const/16 v42, 0x0

    .line 256
    .local v42, "$i$f$ReusableComposeNode\\27\\254":I
    move/from16 v48, v4

    const v4, -0x2942ffcf

    .end local v4    # "enabled":Z
    .local v48, "enabled":Z
    invoke-static {v0, v4, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 257
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_1b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 258
    :cond_1b
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 259
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_1c

    .line 260
    invoke-interface {v0, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_13

    .line 262
    :cond_1c
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 264
    :goto_13
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    const/16 v50, 0x0

    .line 265
    .local v50, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\264\\26":I
    sget-object v51, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v65, v0

    .end local v0    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .restart local v65    # "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v51 .. v51}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 266
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 268
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\29":Lkotlin/jvm/functions/Function2;
    const/16 v51, 0x0

    .line 269
    .local v51, "$i$f$set-impl\\29\\268":I
    move-object/from16 v52, v4

    .local v52, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 270
    .local v53, "$i$a$-with-Updater$set$1\\30\\269\\29":I
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v54

    if-nez v54, :cond_1e

    move-object/from16 v54, v1

    .end local v1    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .local v54, "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v55, v6

    .end local v6    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .local v55, "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d

    goto :goto_14

    :cond_1d
    move-object/from16 v6, v52

    goto :goto_15

    .end local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .end local v55    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v1    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    :cond_1e
    move-object/from16 v54, v1

    move-object/from16 v55, v6

    .line 271
    .end local v1    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .end local v6    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v55    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    :goto_14
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v6, v52

    .end local v52    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 272
    invoke-static/range {v40 .. v40}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v4, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 274
    :goto_15
    nop

    .line 269
    .end local v6    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$a$-with-Updater$set$1\\30\\269\\29":I
    nop

    .line 274
    nop

    .line 275
    .end local v0    # "block\\29":Lkotlin/jvm/functions/Function2;
    .end local v51    # "$i$f$set-impl\\29\\268":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 276
    nop

    .line 264
    .end local v4    # "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\264\\26":I
    nop

    .line 277
    shr-int/lit8 v0, v44, 0x6

    and-int/lit8 v50, v0, 0xe

    .local v50, "$changed\\31":I
    move-object/from16 v0, v65

    .local v0, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 278
    .local v51, "$i$a$-Layout-RowKt$Row$1\\31\\277\\25":I
    const v1, -0x184f2606

    invoke-static {v0, v1, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v23, 0x6

    and-int/lit8 v4, v4, 0x70

    const/16 v29, 0x6

    or-int/lit8 v11, v4, 0x6

    .local v11, "$changed\\32":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414\\32":Landroidx/compose/foundation/layout/RowScope;
    move-object v4, v0

    .local v4, "$composer\\32":Landroidx/compose/runtime/Composer;
    move-object/from16 v52, v1

    .end local v1    # "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414\\32":Landroidx/compose/foundation/layout/RowScope;
    .local v52, "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414\\32":Landroidx/compose/foundation/layout/RowScope;
    const/16 v53, 0x0

    .line 95
    .local v53, "$i$a$-Row-FullscreenScreenKt$ButtonBar$2$2\\32\\278\\15":I
    const v1, 0x24fb8817

    const-string v6, "C98@6019L108,99@6140L28,100@6181L2105:FullscreenScreen.kt#o13vsk"

    invoke-static {v4, v1, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v1, -0x1fd6e37c

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "95@5846L34,95@5801L146,96@5964L28"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v3}, Lorg/lighttouch/android/GuestHost;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v1

    invoke-virtual {v1}, Lorg/lighttouch/android/AppSettings;->getHitchButton()Z

    move-result v1

    if-eqz v1, :cond_24

    .line 96
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getTimeline()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v56

    const v1, -0x615d173a

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    move-object/from16 v1, v67

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/16 v63, 0x1

    and-int/lit16 v6, v9, 0x380

    move-object/from16 v64, v0

    const/16 v0, 0x100

    .end local v0    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\31":Landroidx/compose/runtime/Composer;
    if-ne v6, v0, :cond_1f

    move/from16 v0, v63

    goto :goto_16

    :cond_1f
    const/4 v0, 0x0

    :goto_16
    and-int/lit8 v6, v9, 0xe

    move/from16 v57, v0

    const/4 v0, 0x4

    if-eq v6, v0, :cond_21

    and-int/lit8 v0, v9, 0x8

    if-eqz v0, :cond_20

    invoke-interface {v12, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    goto :goto_17

    :cond_20
    const/4 v0, 0x0

    goto :goto_18

    :cond_21
    :goto_17
    move/from16 v0, v63

    :goto_18
    or-int v0, v57, v0

    .local v0, "invalid\\33":Z
    move-object v6, v4

    .local v6, "$this$cache\\33":Landroidx/compose/runtime/Composer;
    const/16 v57, 0x0

    .line 279
    .local v57, "$i$f$cache\\33\\96":I
    move/from16 p4, v0

    .end local v0    # "invalid\\33":Z
    .local p4, "invalid\\33":Z
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\33":Ljava/lang/Object;
    const/16 v58, 0x0

    .line 280
    .local v58, "$i$a$-let-ComposerKt$cache$1\\34\\279\\33":I
    if-nez p4, :cond_23

    sget-object v59, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v67, v1

    invoke-virtual/range {v59 .. v59}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_22

    goto :goto_19

    .line 284
    :cond_22
    move-object/from16 v59, v0

    goto :goto_1a

    .line 280
    :cond_23
    move-object/from16 v67, v1

    .line 281
    :goto_19
    const/4 v1, 0x0

    .line 96
    .local v1, "$i$a$-cache-FullscreenScreenKt$ButtonBar$2$2$1\\35\\281\\32":I
    move-object/from16 v59, v0

    .end local v0    # "it\\33":Ljava/lang/Object;
    .local v59, "it\\33":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v0, v5, v3}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda14;-><init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)V

    .line 281
    .end local v1    # "$i$a$-cache-FullscreenScreenKt$ButtonBar$2$2$1\\35\\281\\32":I
    nop

    .line 282
    .local v0, "value\\34":Ljava/lang/Object;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 283
    nop

    .line 280
    .end local v0    # "value\\34":Ljava/lang/Object;
    :goto_1a
    nop

    .line 279
    .end local v58    # "$i$a$-let-ComposerKt$cache$1\\34\\279\\33":I
    .end local v59    # "it\\33":Ljava/lang/Object;
    nop

    .line 96
    .end local v6    # "$this$cache\\33":Landroidx/compose/runtime/Composer;
    .end local v57    # "$i$f$cache\\33\\96":I
    .end local p4    # "invalid\\33":Z
    move-object/from16 v58, v0

    check-cast v58, Lkotlin/jvm/functions/Function0;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v0, 0x2

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "running"

    const/4 v6, 0x0

    aput-object v1, v0, v6

    const-string v1, "paused"

    aput-object v1, v0, v63

    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v3}, Lorg/lighttouch/android/GuestHost;->getStatus()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v59

    const-string v60, "hitch_button"

    const/16 v62, 0x6030

    const-string v57, "\u68c0\u67e5\u5e27"

    move-object/from16 v61, v4

    .end local v4    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v61, "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v62}, Lorg/lighttouch/android/FullscreenScreenKt;->SmallKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 97
    move-object/from16 v0, v61

    .end local v61    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\32":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x8

    .local v4, "$this$dp\\36":I
    const/4 v6, 0x0

    .line 285
    .local v6, "$i$f$getDp\\36\\97":I
    move-object/from16 p4, v2

    .end local v2    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .local p4, "materialized\\26":Landroidx/compose/ui/Modifier;
    int-to-float v2, v4

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 97
    .end local v4    # "$this$dp\\36":I
    .end local v6    # "$i$f$getDp\\36\\97":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v0, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    goto :goto_1b

    .line 95
    .end local v64    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local p4    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .local v0, "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local v2    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .local v4, "$composer\\32":Landroidx/compose/runtime/Composer;
    :cond_24
    move-object/from16 v64, v0

    move-object/from16 p4, v2

    move-object v0, v4

    const/16 v63, 0x1

    .line 97
    .end local v2    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .end local v4    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v64    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local p4    # "materialized\\26":Landroidx/compose/ui/Modifier;
    :goto_1b
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 99
    sget-object v1, Lorg/lighttouch/android/LtIcons;->INSTANCE:Lorg/lighttouch/android/LtIcons;

    invoke-virtual {v1}, Lorg/lighttouch/android/LtIcons;->getPower()Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v1

    shl-int/lit8 v2, v9, 0x9

    and-int/lit16 v2, v2, 0x1c00

    const v4, 0x1801b0

    or-int/2addr v2, v4

    const/high16 v4, 0x70000

    shl-int/lit8 v6, v9, 0x9

    and-int/2addr v4, v6

    or-int/2addr v2, v4

    move-object/from16 v61, v0

    move-object v0, v1

    .end local v0    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v61    # "$composer\\32":Landroidx/compose/runtime/Composer;
    const-string v1, "\u7761\u7720/\u5524\u9192"

    move-object v4, v8

    move v8, v2

    .end local v8    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .local v4, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v2, 0x1

    const-string v6, "power_button"

    move-object/from16 v22, v4

    move/from16 v56, v11

    move-object/from16 v57, v12

    move/from16 v4, v48

    move/from16 v12, v63

    move-object/from16 v62, v65

    move-object/from16 v11, v67

    move-object/from16 v48, p4

    move-object/from16 p4, v10

    move-object v10, v7

    move-object/from16 v7, v61

    move-object/from16 v61, v64

    .end local v10    # "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v11    # "$changed\\32":I
    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v64    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local v65    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v4, "enabled":Z
    .local v7, "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v22, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .local v48, "materialized\\26":Landroidx/compose/ui/Modifier;
    .local v56, "$changed\\32":I
    .local v57, "$composer":Landroidx/compose/runtime/Composer;
    .local v61, "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\15":Landroidx/compose/runtime/Composer;
    .local p4, "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v0 .. v8}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 100
    move-object v0, v7

    .end local v7    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v0    # "$composer\\32":Landroidx/compose/runtime/Composer;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x8

    .local v2, "$this$dp\\37":I
    const/4 v6, 0x0

    .line 286
    .local v6, "$i$f$getDp\\37\\100":I
    int-to-float v7, v2

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 100
    .end local v2    # "$this$dp\\37":I
    .end local v6    # "$i$f$getDp\\37\\100":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x6

    invoke-static {v1, v0, v2}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 101
    const/4 v1, 0x0

    move v2, v1

    .local v2, "$changed\\38":I
    const/4 v1, 0x0

    .line 287
    .local v1, "$i$f$Box\\38\\101":I
    const v6, 0x2bb5b5d7

    const-string v7, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v0, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 288
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 289
    .local v6, "modifier\\38":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v7

    .line 290
    .local v7, "contentAlignment\\38":Landroidx/compose/ui/Alignment;
    const/4 v8, 0x0

    .line 293
    .local v8, "propagateMinConstraints\\38":Z
    invoke-static {v7, v8}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v58, v2, 0x3

    and-int/lit8 v58, v58, 0x70

    .line 294
    nop

    .local v58, "$changed\\39":I
    const/16 v59, 0x0

    .line 295
    .local v59, "$i$f$Layout\\39\\294":I
    move/from16 v60, v1

    const v1, -0x4ee9b9da

    .end local v1    # "$i$f$Box\\38\\101":I
    .local v60, "$i$f$Box\\38\\101":I
    invoke-static {v0, v1, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 296
    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v10

    .line 297
    .local v10, "compositeKeyHash\\39":I
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 298
    .local v1, "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v24, v2

    .end local v2    # "$changed\\38":I
    .local v24, "$changed\\38":I
    invoke-static {v0, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 300
    .local v2, "materialized\\39":Landroidx/compose/ui/Modifier;
    sget-object v64, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v64 .. v64}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v64

    move/from16 v65, v4

    .end local v4    # "enabled":Z
    .local v65, "enabled":Z
    shl-int/lit8 v4, v58, 0x6

    and-int/lit16 v4, v4, 0x380

    const/16 v29, 0x6

    or-int/lit8 v4, v4, 0x6

    .line 299
    move-object/from16 v66, v64

    .local v4, "$changed\\40":I
    .local v66, "factory\\40":Lkotlin/jvm/functions/Function0;
    const/16 v64, 0x0

    .line 301
    .local v64, "$i$f$ReusableComposeNode\\40\\299":I
    move/from16 v67, v4

    const v4, -0x2942ffcf

    .end local v4    # "$changed\\40":I
    .local v67, "$changed\\40":I
    invoke-static {v0, v4, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 302
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_25

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 303
    :cond_25
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 304
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_26

    .line 305
    move-object/from16 v4, v66

    .end local v66    # "factory\\40":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-interface {v0, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1c

    .line 307
    .end local v4    # "factory\\40":Lkotlin/jvm/functions/Function0;
    .restart local v66    # "factory\\40":Lkotlin/jvm/functions/Function0;
    :cond_26
    move-object/from16 v4, v66

    .end local v66    # "factory\\40":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 309
    :goto_1c
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .local v13, "$this$Layout_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    const/16 v31, 0x0

    .line 310
    .local v31, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\41\\309\\39":I
    sget-object v66, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v68, v0

    .end local v0    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v68, "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v66 .. v66}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 311
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 313
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\42":Lkotlin/jvm/functions/Function2;
    const/16 v66, 0x0

    .line 314
    .local v66, "$i$f$set-impl\\42\\313":I
    move-object/from16 v69, v13

    .local v69, "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    const/16 v70, 0x0

    .line 315
    .local v70, "$i$a$-with-Updater$set$1\\43\\314\\42":I
    invoke-interface/range {v69 .. v69}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v71

    if-nez v71, :cond_28

    move-object/from16 v71, v1

    .end local v1    # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .local v71, "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v69 .. v69}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v72, v4

    .end local v4    # "factory\\40":Lkotlin/jvm/functions/Function0;
    .local v72, "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_27

    goto :goto_1d

    :cond_27
    move-object/from16 v4, v69

    goto :goto_1e

    .end local v71    # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v72    # "factory\\40":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "factory\\40":Lkotlin/jvm/functions/Function0;
    :cond_28
    move-object/from16 v71, v1

    move-object/from16 v72, v4

    .line 316
    .end local v1    # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "factory\\40":Lkotlin/jvm/functions/Function0;
    .restart local v71    # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v72    # "factory\\40":Lkotlin/jvm/functions/Function0;
    :goto_1d
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v4, v69

    .end local v69    # "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 317
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v13, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 319
    :goto_1e
    nop

    .line 314
    .end local v4    # "$this$set_impl_u24lambda_u240\\42":Landroidx/compose/runtime/Composer;
    .end local v70    # "$i$a$-with-Updater$set$1\\43\\314\\42":I
    nop

    .line 319
    nop

    .line 320
    .end local v0    # "block\\42":Lkotlin/jvm/functions/Function2;
    .end local v66    # "$i$f$set-impl\\42\\313":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 321
    nop

    .line 309
    .end local v13    # "$this$Layout_u24lambda_u240\\41":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\41\\309\\39":I
    nop

    .line 322
    shr-int/lit8 v0, v67, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\44":I
    move-object/from16 v1, v68

    .local v1, "$composer\\44":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 323
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\44\\322\\38":I
    const v13, -0x7ff519f7    # -1.000876E-39f

    move/from16 v31, v0

    .end local v0    # "$changed\\44":I
    .local v31, "$changed\\44":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v13, v24, 0x6

    and-int/lit8 v13, v13, 0x70

    const/16 v29, 0x6

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\45":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414_u24lambda_u2413\\45":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v78, v1

    .local v78, "$composer\\45":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 102
    .local v29, "$i$a$-Box-FullscreenScreenKt$ButtonBar$2$2$2\\45\\323\\32":I
    move-object/from16 v66, v0

    .end local v0    # "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414_u24lambda_u2413\\45":Landroidx/compose/foundation/layout/BoxScope;
    .local v66, "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414_u24lambda_u2413\\45":Landroidx/compose/foundation/layout/BoxScope;
    const v0, -0x9dcd5fe

    move-object/from16 v69, v1

    .end local v1    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .local v69, "$composer\\44":Landroidx/compose/runtime/Composer;
    const-string v1, "C101@6243L29,101@6203L101,102@6340L16,102@6358L1914,102@6321L1951:FullscreenScreen.kt#o13vsk"

    move-object/from16 v70, v2

    move-object/from16 v2, v78

    .end local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v70, "materialized\\39":Landroidx/compose/ui/Modifier;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material/icons/Icons$Filled;->INSTANCE:Landroidx/compose/material/icons/Icons$Filled;

    invoke-static {v0}, Landroidx/compose/material/icons/filled/MoreVertKt;->getMoreVert(Landroidx/compose/material/icons/Icons$Filled;)Landroidx/compose/ui/graphics/vector/ImageVector;

    move-result-object v73

    const v0, -0x615d173a

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v0, v9, 0x380

    const/16 v1, 0x100

    if-ne v0, v1, :cond_29

    const/4 v0, 0x1

    goto :goto_1f

    :cond_29
    const/4 v0, 0x0

    .local v0, "invalid\\46":Z
    :goto_1f
    move-object v1, v2

    .local v1, "$this$cache\\46":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 324
    .local v17, "$i$f$cache\\46\\102":I
    move/from16 p2, v0

    .end local v0    # "invalid\\46":Z
    .local p2, "invalid\\46":Z
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\46":Ljava/lang/Object;
    const/16 v74, 0x0

    .line 325
    .local v74, "$i$a$-let-ComposerKt$cache$1\\47\\324\\46":I
    if-nez p2, :cond_2b

    sget-object v75, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v78, v2

    .end local v2    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v75 .. v75}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_2a

    goto :goto_20

    .line 329
    :cond_2a
    move-object/from16 v75, v0

    goto :goto_21

    .line 325
    .end local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\45":Landroidx/compose/runtime/Composer;
    :cond_2b
    move-object/from16 v78, v2

    .line 326
    .end local v2    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    :goto_20
    const/4 v2, 0x0

    .line 102
    .local v2, "$i$a$-cache-FullscreenScreenKt$ButtonBar$2$2$2$1\\48\\326\\45":I
    move-object/from16 v75, v0

    .end local v0    # "it\\46":Ljava/lang/Object;
    .local v75, "it\\46":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda15;

    invoke-direct {v0, v5, v15}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda15;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 326
    .end local v2    # "$i$a$-cache-FullscreenScreenKt$ButtonBar$2$2$2$1\\48\\326\\45":I
    nop

    .line 327
    .local v0, "value\\47":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 328
    nop

    .line 325
    .end local v0    # "value\\47":Ljava/lang/Object;
    :goto_21
    nop

    .line 324
    .end local v74    # "$i$a$-let-ComposerKt$cache$1\\47\\324\\46":I
    .end local v75    # "it\\46":Ljava/lang/Object;
    nop

    .line 102
    .end local v1    # "$this$cache\\46":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$f$cache\\46\\102":I
    .end local p2    # "invalid\\46":Z
    move-object/from16 v75, v0

    check-cast v75, Lkotlin/jvm/functions/Function0;

    invoke-interface/range {v78 .. v78}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const-string v77, "fullscreen_menu"

    const/16 v79, 0x6c30

    const-string v74, "\u66f4\u591a"

    const/16 v76, 0x1

    invoke-static/range {v73 .. v79}, Lorg/lighttouch/android/FullscreenScreenKt;->SmallKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 103
    move-object/from16 v2, v78

    .end local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static {v15}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v73

    const v0, 0x4c5de2

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v2, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\49":Z
    move-object v1, v2

    .local v1, "$this$cache\\49":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 330
    .local v11, "$i$f$cache\\49\\103":I
    move/from16 p2, v0

    .end local v0    # "invalid\\49":Z
    .local p2, "invalid\\49":Z
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\49":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 331
    .local v17, "$i$a$-let-ComposerKt$cache$1\\50\\330\\49":I
    sget-object v74, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v91, v4

    .end local v4    # "$i$a$-Layout-BoxKt$Box$1\\44\\322\\38":I
    .local v91, "$i$a$-Layout-BoxKt$Box$1\\44\\322\\38":I
    invoke-virtual/range {v74 .. v74}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v0, v4, :cond_2c

    .line 332
    const/4 v4, 0x0

    .line 103
    .local v4, "$i$a$-cache-FullscreenScreenKt$ButtonBar$2$2$2$2\\51\\332\\45":I
    move-object/from16 v74, v0

    .end local v0    # "it\\49":Ljava/lang/Object;
    .local v74, "it\\49":Ljava/lang/Object;
    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v0, v15}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 332
    .end local v4    # "$i$a$-cache-FullscreenScreenKt$ButtonBar$2$2$2$2\\51\\332\\45":I
    nop

    .line 333
    .local v0, "value\\50":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 334
    nop

    .end local v0    # "value\\50":Ljava/lang/Object;
    goto :goto_22

    .line 335
    .end local v74    # "it\\49":Ljava/lang/Object;
    .local v0, "it\\49":Ljava/lang/Object;
    :cond_2c
    move-object/from16 v74, v0

    .line 331
    .end local v0    # "it\\49":Ljava/lang/Object;
    .restart local v74    # "it\\49":Ljava/lang/Object;
    :goto_22
    nop

    .line 330
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\50\\330\\49":I
    .end local v74    # "it\\49":Ljava/lang/Object;
    nop

    .line 103
    .end local v1    # "$this$cache\\49":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\49\\103":I
    .end local p2    # "invalid\\49":Z
    move-object/from16 v74, v0

    check-cast v74, Lkotlin/jvm/functions/Function0;

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$ButtonBar$2$2$2$3;

    move-object/from16 v4, p3

    invoke-direct {v0, v3, v4, v15}, Lorg/lighttouch/android/FullscreenScreenKt$ButtonBar$2$2$2$3;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    const/16 v1, 0x36

    const v11, 0x2a183df1

    const/4 v3, 0x1

    invoke-static {v11, v3, v0, v2, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v86, v0

    check-cast v86, Lkotlin/jvm/functions/Function3;

    const/16 v89, 0x30

    const/16 v90, 0x7fc

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const-wide/16 v81, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v88, 0x30

    move-object/from16 v87, v2

    .end local v2    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .local v87, "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static/range {v73 .. v90}, Landroidx/compose/material3/AndroidMenu_androidKt;->DropdownMenu-IlH_yew(ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/ScrollState;Landroidx/compose/ui/window/PopupProperties;Landroidx/compose/ui/graphics/Shape;JFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;III)V

    .line 102
    move-object/from16 v78, v87

    .end local v87    # "$composer\\45":Landroidx/compose/runtime/Composer;
    .restart local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static/range {v78 .. v78}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 120
    nop

    .line 323
    .end local v13    # "$changed\\45":I
    .end local v29    # "$i$a$-Box-FullscreenScreenKt$ButtonBar$2$2$2\\45\\323\\32":I
    .end local v66    # "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414_u24lambda_u2413\\45":Landroidx/compose/foundation/layout/BoxScope;
    .end local v78    # "$composer\\45":Landroidx/compose/runtime/Composer;
    invoke-static/range {v69 .. v69}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 322
    .end local v31    # "$changed\\44":I
    .end local v69    # "$composer\\44":Landroidx/compose/runtime/Composer;
    .end local v91    # "$i$a$-Layout-BoxKt$Box$1\\44\\322\\38":I
    nop

    .line 336
    invoke-interface/range {v68 .. v68}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 301
    invoke-static/range {v68 .. v68}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 337
    nop

    .line 295
    .end local v64    # "$i$f$ReusableComposeNode\\40\\299":I
    .end local v67    # "$changed\\40":I
    .end local v72    # "factory\\40":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v68 .. v68}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 338
    nop

    .line 287
    .end local v10    # "compositeKeyHash\\39":I
    .end local v58    # "$changed\\39":I
    .end local v59    # "$i$f$Layout\\39\\294":I
    .end local v70    # "materialized\\39":Landroidx/compose/ui/Modifier;
    .end local v71    # "localMap\\39":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v68 .. v68}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 339
    nop

    .line 95
    .end local v6    # "modifier\\38":Landroidx/compose/ui/Modifier;
    .end local v7    # "contentAlignment\\38":Landroidx/compose/ui/Alignment;
    .end local v8    # "propagateMinConstraints\\38":Z
    .end local v12    # "measurePolicy\\38":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "$changed\\38":I
    .end local v60    # "$i$f$Box\\38\\101":I
    invoke-static/range {v68 .. v68}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 121
    nop

    .line 278
    .end local v52    # "$this$ButtonBar_u24lambda_u2415_u24lambda_u2414\\32":Landroidx/compose/foundation/layout/RowScope;
    .end local v53    # "$i$a$-Row-FullscreenScreenKt$ButtonBar$2$2\\32\\278\\15":I
    .end local v56    # "$changed\\32":I
    .end local v68    # "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static/range {v61 .. v61}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 277
    .end local v50    # "$changed\\31":I
    .end local v51    # "$i$a$-Layout-RowKt$Row$1\\31\\277\\25":I
    .end local v61    # "$composer\\31":Landroidx/compose/runtime/Composer;
    nop

    .line 340
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 256
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 341
    nop

    .line 250
    .end local v42    # "$i$f$ReusableComposeNode\\27\\254":I
    .end local v44    # "$changed\\27":I
    .end local v54    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 342
    nop

    .line 247
    .end local v14    # "$changed\\26":I
    .end local v22    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v39    # "$i$f$Layout\\26\\249":I
    .end local v40    # "compositeKeyHash\\26":I
    .end local v48    # "materialized\\26":Landroidx/compose/ui/Modifier;
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 343
    nop

    .line 88
    .end local v23    # "$changed\\25":I
    .end local v33    # "$i$f$Row\\25\\94":I
    .end local v41    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v43    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .end local v55    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .end local p4    # "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 122
    nop

    .line 205
    .end local v35    # "$changed\\15":I
    .end local v36    # "$i$a$-Row-FullscreenScreenKt$ButtonBar$2\\15\\205\\0":I
    .end local v38    # "$this$ButtonBar_u24lambda_u2415\\15":Landroidx/compose/foundation/layout/RowScope;
    .end local v62    # "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 204
    .end local v32    # "$i$a$-Layout-RowKt$Row$1\\14\\204\\8":I
    .end local v45    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local v47    # "$changed\\14":I
    nop

    .line 344
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 183
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 345
    nop

    .line 177
    .end local v26    # "$i$f$ReusableComposeNode\\10\\181":I
    .end local v28    # "$changed\\10":I
    .end local v37    # "factory\\10":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 346
    nop

    .line 170
    .end local v20    # "$changed\\9":I
    .end local v21    # "$i$f$Layout\\9\\176":I
    .end local v25    # "compositeKeyHash\\9":I
    .end local v46    # "materialized\\9":Landroidx/compose/ui/Modifier;
    .end local v49    # "localMap\\9":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 347
    nop

    .end local v16    # "horizontalArrangement\\8":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v18    # "$changed\\8":I
    .end local v19    # "$i$f$Row\\8\\86":I
    .end local v27    # "verticalAlignment\\8":Landroidx/compose/ui/Alignment$Vertical;
    .end local v30    # "modifier\\8":Landroidx/compose/ui/Modifier;
    .end local v34    # "measurePolicy\\8":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v15    # "menu$delegate":Landroidx/compose/runtime/MutableState;
    .end local v65    # "enabled":Z
    :cond_2d
    move-object v3, v5

    .end local v5    # "onInteract":Lkotlin/jvm/functions/Function0;
    .local v3, "onInteract":Lkotlin/jvm/functions/Function0;
    :goto_23
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_2e

    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda2;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v5, p5

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda2;-><init>(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;II)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 123
    :cond_2e
    return-void
.end method

.method private static final ButtonBar$lambda$15$lambda$14$lambda$13$lambda$10$lambda$9(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 102
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ButtonBar$lambda$15$lambda$14$lambda$13$lambda$12$lambda$11(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .locals 1
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 103
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ButtonBar$lambda$15$lambda$14$lambda$8$lambda$7(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)Lkotlin/Unit;
    .locals 1
    .param p0, "$onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;

    .line 96
    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    invoke-interface {p1}, Lorg/lighttouch/android/GuestHost;->openHitch()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ButtonBar$lambda$16(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v7, p5

    move-object v5, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final ButtonBar$lambda$2$lambda$1()Lkotlin/Unit;
    .locals 1

    .line 83
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ButtonBar$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .locals 4
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 84
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 505
    .local v3, "$i$f$getValue\\1\\84":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\84":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 84
    return v0
.end method

.method private static final ButtonBar$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 5
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 84
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 506
    .local v4, "$i$f$setValue\\1\\84":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 507
    nop

    .line 84
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\84":I
    return-void
.end method

.method public static final FullscreenScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V
    .locals 5
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "guestSurface"    # Lkotlin/jvm/functions/Function3;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/ui/Modifier;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    const-string v0, "host"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "guestSurface"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    const v0, -0x504b7ab6

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object p2

    const-string v1, "C(FullscreenScreen)P(1)42@1957L2858,42@1947L2868:FullscreenScreen.kt#o13vsk"

    invoke-static {p2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move v1, p3

    .local v1, "$dirty":I
    and-int/lit8 v2, p3, 0x6

    if-nez v2, :cond_2

    and-int/lit8 v2, p3, 0x8

    if-nez v2, :cond_0

    invoke-interface {p2, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    goto :goto_0

    :cond_0
    invoke-interface {p2, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    :goto_0
    if-eqz v2, :cond_1

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    const/4 v2, 0x2

    :goto_1
    or-int/2addr v1, v2

    :cond_2
    and-int/lit8 v2, p3, 0x30

    if-nez v2, :cond_4

    invoke-interface {p2, p1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    const/16 v2, 0x20

    goto :goto_2

    :cond_3
    const/16 v2, 0x10

    :goto_2
    or-int/2addr v1, v2

    :cond_4
    and-int/lit8 v2, v1, 0x13

    const/16 v3, 0x12

    if-ne v2, v3, :cond_6

    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v2

    if-nez v2, :cond_5

    goto :goto_3

    :cond_5
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto :goto_4

    :cond_6
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_7

    const/4 v2, -0x1

    const-string v3, "org.lighttouch.android.FullscreenScreen (FullscreenScreen.kt:42)"

    invoke-static {v0, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_7
    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1;

    invoke-direct {v0, p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt$FullscreenScreen$1;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;)V

    const/16 v2, 0x36

    const v3, 0x57e1bd12

    const/4 v4, 0x1

    invoke-static {v3, v4, v0, p2, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function2;

    const/4 v2, 0x6

    invoke-static {v0, p2, v2}, Lorg/lighttouch/android/ThemeKt;->DarkTheme(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_8
    :goto_4
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_9

    new-instance v2, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda12;

    invoke-direct {v2, p0, p1, p3}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda12;-><init>(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;I)V

    invoke-interface {v0, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 80
    :cond_9
    return-void
.end method

.method private static final FullscreenScreen$lambda$0(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 1

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p3, v0}, Lorg/lighttouch/android/FullscreenScreenKt;->FullscreenScreen(Lorg/lighttouch/android/GuestHost;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HardwareKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 42
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "id"    # I
    .param p3, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p4, "enabled"    # Z
    .param p5, "onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p6, "tag"    # Ljava/lang/String;
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "I",
            "Lorg/lighttouch/android/GuestHost;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 127
    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move/from16 v8, p8

    const v0, 0xb150577

    move-object/from16 v1, p7

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(HardwareKey)P(2,4,3,1)127@8593L7,129@8711L50,130@8802L69,130@8873L89,128@8605L521:FullscreenScreen.kt#o13vsk"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p8

    .local v1, "$dirty":I
    and-int/lit8 v10, v8, 0x6

    if-nez v10, :cond_1

    move-object/from16 v11, p0

    invoke-interface {v9, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_0

    const/4 v10, 0x4

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    :goto_0
    or-int/2addr v1, v10

    goto :goto_1

    :cond_1
    move-object/from16 v11, p0

    :goto_1
    and-int/lit8 v10, v8, 0x30

    const/16 v12, 0x20

    if-nez v10, :cond_3

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2

    move v10, v12

    goto :goto_2

    :cond_2
    const/16 v10, 0x10

    :goto_2
    or-int/2addr v1, v10

    :cond_3
    and-int/lit16 v10, v8, 0x180

    if-nez v10, :cond_5

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v10

    if-eqz v10, :cond_4

    const/16 v10, 0x100

    goto :goto_3

    :cond_4
    const/16 v10, 0x80

    :goto_3
    or-int/2addr v1, v10

    :cond_5
    and-int/lit16 v10, v8, 0xc00

    if-nez v10, :cond_8

    and-int/lit16 v10, v8, 0x1000

    if-nez v10, :cond_6

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    goto :goto_4

    :cond_6
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    :goto_4
    if-eqz v10, :cond_7

    const/16 v10, 0x800

    goto :goto_5

    :cond_7
    const/16 v10, 0x400

    :goto_5
    or-int/2addr v1, v10

    :cond_8
    and-int/lit16 v10, v8, 0x6000

    if-nez v10, :cond_a

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v10

    if-eqz v10, :cond_9

    const/16 v10, 0x4000

    goto :goto_6

    :cond_9
    const/16 v10, 0x2000

    :goto_6
    or-int/2addr v1, v10

    :cond_a
    const/high16 v10, 0x30000

    and-int/2addr v10, v8

    if-nez v10, :cond_c

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b

    const/high16 v10, 0x20000

    goto :goto_7

    :cond_b
    const/high16 v10, 0x10000

    :goto_7
    or-int/2addr v1, v10

    :cond_c
    const/high16 v10, 0x180000

    and-int/2addr v10, v8

    if-nez v10, :cond_e

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_d

    const/high16 v10, 0x100000

    goto :goto_8

    :cond_d
    const/high16 v10, 0x80000

    :goto_8
    or-int/2addr v1, v10

    :cond_e
    move v10, v1

    .end local v1    # "$dirty":I
    .local v10, "$dirty":I
    const v1, 0x92493

    and-int/2addr v1, v10

    const v15, 0x92492

    if-ne v1, v15, :cond_10

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v1

    if-nez v1, :cond_f

    goto :goto_9

    .line 401
    :cond_f
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    goto/16 :goto_1a

    .line 127
    :cond_10
    :goto_9
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_11

    const/4 v1, -0x1

    const-string v15, "org.lighttouch.android.HardwareKey (FullscreenScreen.kt:126)"

    invoke-static {v0, v10, v1, v15}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 128
    :cond_11
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalHapticFeedback()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/CompositionLocal;

    .local v0, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v1, 0x0

    .local v1, "$changed\\1":I
    const/4 v15, 0x0

    .line 348
    .local v15, "$i$f$getCurrent\\1\\128":I
    const v13, 0x789c5f52

    const-string v14, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v9, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v13

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 128
    .end local v0    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v1    # "$changed\\1":I
    .end local v15    # "$i$f$getCurrent\\1\\128":I
    move-object v0, v13

    check-cast v0, Landroidx/compose/ui/hapticfeedback/HapticFeedback;

    .line 129
    .local v0, "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v13, 0x30

    .local v13, "$this$dp\\2":I
    const/4 v14, 0x0

    .line 349
    .local v14, "$i$f$getDp\\2\\129":I
    int-to-float v15, v13

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v13

    .line 129
    .end local v13    # "$this$dp\\2":I
    .end local v14    # "$i$f$getDp\\2\\129":I
    invoke-static {v1, v13}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v13

    check-cast v13, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v13}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v17

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v18

    const/16 v24, 0xe

    const/16 v25, 0x0

    const v20, 0x3da3d70a    # 0.08f

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-static/range {v18 .. v25}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v18

    const/16 v21, 0x2

    const/16 v22, 0x0

    const/16 v20, 0x0

    invoke-static/range {v17 .. v22}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 130
    const v13, 0x4c5de2

    invoke-interface {v9, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v13, "CC(remember):FullscreenScreen.kt#9igjgp"

    invoke-static {v9, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v14, v10, 0x70

    if-ne v14, v12, :cond_12

    const/4 v12, 0x1

    goto :goto_a

    :cond_12
    const/4 v12, 0x0

    .local v12, "invalid\\3":Z
    :goto_a
    move-object v14, v9

    .local v14, "$this$cache\\3":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 350
    .local v18, "$i$f$cache\\3\\130":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\3":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 351
    .local v20, "$i$a$-let-ComposerKt$cache$1\\4\\350\\3":I
    if-nez v12, :cond_14

    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v15, v8, :cond_13

    goto :goto_b

    .line 355
    :cond_13
    move-object v8, v15

    goto :goto_c

    .line 352
    :cond_14
    :goto_b
    const/4 v8, 0x0

    .line 130
    .local v8, "$i$a$-cache-FullscreenScreenKt$HardwareKey$1\\5\\352\\0":I
    move/from16 v21, v8

    .end local v8    # "$i$a$-cache-FullscreenScreenKt$HardwareKey$1\\5\\352\\0":I
    .local v21, "$i$a$-cache-FullscreenScreenKt$HardwareKey$1\\5\\352\\0":I
    new-instance v8, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda0;

    invoke-direct {v8, v2}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V

    .line 352
    .end local v21    # "$i$a$-cache-FullscreenScreenKt$HardwareKey$1\\5\\352\\0":I
    nop

    .line 353
    .local v8, "value\\4":Ljava/lang/Object;
    invoke-interface {v14, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 354
    nop

    .line 351
    .end local v8    # "value\\4":Ljava/lang/Object;
    :goto_c
    nop

    .line 350
    .end local v15    # "it\\3":Ljava/lang/Object;
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\4\\350\\3":I
    nop

    .line 130
    .end local v12    # "invalid\\3":Z
    .end local v14    # "$this$cache\\3":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$f$cache\\3\\130":I
    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v12, 0x0

    const/4 v14, 0x1

    const/4 v15, 0x0

    invoke-static {v1, v15, v8, v14, v12}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 131
    const v8, -0x615d173a

    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/high16 v12, 0x70000

    and-int/2addr v12, v10

    const/high16 v15, 0x20000

    if-ne v12, v15, :cond_15

    move v15, v14

    goto :goto_d

    :cond_15
    const/4 v15, 0x0

    :goto_d
    and-int/lit16 v12, v10, 0x1c00

    const/16 v14, 0x800

    if-eq v12, v14, :cond_17

    and-int/lit16 v12, v10, 0x1000

    if-eqz v12, :cond_16

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_16

    goto :goto_e

    :cond_16
    const/4 v12, 0x0

    goto :goto_f

    :cond_17
    :goto_e
    const/4 v12, 0x1

    :goto_f
    or-int/2addr v12, v15

    .local v12, "invalid\\6":Z
    move-object v14, v9

    .local v14, "$this$cache\\6":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 356
    .local v15, "$i$f$cache\\6\\131":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v8

    .local v8, "it\\6":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 357
    .local v18, "$i$a$-let-ComposerKt$cache$1\\7\\356\\6":I
    if-nez v12, :cond_19

    sget-object v20, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v8, v2, :cond_18

    goto :goto_10

    .line 361
    :cond_18
    move-object v2, v8

    goto :goto_11

    .line 358
    :cond_19
    :goto_10
    const/4 v2, 0x0

    .line 131
    .local v2, "$i$a$-cache-FullscreenScreenKt$HardwareKey$2\\8\\358\\0":I
    move/from16 v20, v2

    .end local v2    # "$i$a$-cache-FullscreenScreenKt$HardwareKey$2\\8\\358\\0":I
    .local v20, "$i$a$-cache-FullscreenScreenKt$HardwareKey$2\\8\\358\\0":I
    new-instance v2, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v2, v6, v4}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda7;-><init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)V

    .line 358
    .end local v20    # "$i$a$-cache-FullscreenScreenKt$HardwareKey$2\\8\\358\\0":I
    nop

    .line 359
    .local v2, "value\\7":Ljava/lang/Object;
    invoke-interface {v14, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 360
    nop

    .line 357
    .end local v2    # "value\\7":Ljava/lang/Object;
    :goto_11
    nop

    .line 356
    .end local v8    # "it\\6":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\7\\356\\6":I
    nop

    .line 131
    .end local v12    # "invalid\\6":Z
    .end local v14    # "$this$cache\\6":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\6\\131":I
    check-cast v2, Lkotlin/jvm/functions/Function2;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v8, -0x615d173a

    invoke-interface {v9, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v9, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v8, v10, 0x1c00

    const/16 v14, 0x800

    if-eq v8, v14, :cond_1b

    and-int/lit16 v8, v10, 0x1000

    if-eqz v8, :cond_1a

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1a

    goto :goto_12

    :cond_1a
    const/4 v15, 0x0

    goto :goto_13

    :cond_1b
    :goto_12
    const/4 v15, 0x1

    :goto_13
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    or-int/2addr v8, v15

    .local v8, "invalid\\9":Z
    move-object v12, v9

    .local v12, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 356
    .local v13, "$i$f$cache\\9\\131":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\9":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 357
    .local v15, "$i$a$-let-ComposerKt$cache$1\\10\\356\\9":I
    if-nez v8, :cond_1d

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v14, v6, :cond_1c

    goto :goto_14

    .line 361
    :cond_1c
    move-object v6, v14

    goto :goto_15

    .line 358
    :cond_1d
    :goto_14
    const/4 v6, 0x0

    .line 131
    .local v6, "$i$a$-cache-FullscreenScreenKt$HardwareKey$3\\11\\358\\0":I
    move/from16 p7, v6

    .end local v6    # "$i$a$-cache-FullscreenScreenKt$HardwareKey$3\\11\\358\\0":I
    .local p7, "$i$a$-cache-FullscreenScreenKt$HardwareKey$3\\11\\358\\0":I
    new-instance v6, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v6, v4, v0}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda8;-><init>(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)V

    .line 358
    .end local p7    # "$i$a$-cache-FullscreenScreenKt$HardwareKey$3\\11\\358\\0":I
    nop

    .line 359
    .local v6, "value\\10":Ljava/lang/Object;
    invoke-interface {v12, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 360
    nop

    .line 357
    .end local v6    # "value\\10":Ljava/lang/Object;
    :goto_15
    nop

    .line 356
    .end local v14    # "it\\9":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\10\\356\\9":I
    nop

    .line 131
    .end local v8    # "invalid\\9":Z
    .end local v12    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$cache\\9\\131":I
    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v1, v5, v3, v2, v6}, Lorg/lighttouch/android/DeviceFrameKt;->held(Landroidx/compose/ui/Modifier;ZILkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 132
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v2

    .line 129
    const/16 v6, 0x30

    .local v1, "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v2, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .local v6, "$changed\\12":I
    const/4 v8, 0x0

    .line 362
    .local v8, "$i$f$Box\\12\\129":I
    const v12, 0x2bb5b5d7

    const-string v13, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v9, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 363
    const/4 v12, 0x0

    .line 366
    .local v12, "propagateMinConstraints\\12":Z
    invoke-static {v2, v12}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .local v13, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v6, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 367
    move/from16 v20, v14

    .local v20, "$changed\\13":I
    const/16 v21, 0x0

    .line 368
    .local v21, "$i$f$Layout\\13\\367":I
    const v14, -0x4ee9b9da

    const-string v15, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v9, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 369
    const/4 v15, 0x0

    invoke-static {v9, v15}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v19

    .line 370
    .local v19, "compositeKeyHash\\13":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 371
    .local v14, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9, v1}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 373
    .local v15, "materialized\\13":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 p7, v0

    .end local v0    # "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    .local p7, "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    shl-int/lit8 v0, v20, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 372
    nop

    .local v0, "$changed\\14":I
    move-object/from16 v22, v16

    .local v22, "factory\\14":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 374
    .local v23, "$i$f$ReusableComposeNode\\14\\372":I
    move/from16 v24, v0

    .end local v0    # "$changed\\14":I
    .local v24, "$changed\\14":I
    const v0, -0x2942ffcf

    move-object/from16 v25, v1

    .end local v1    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v25, "modifier\\12":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v9, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 375
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_1e

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 376
    :cond_1e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 377
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_1f

    .line 378
    move-object/from16 v0, v22

    .end local v22    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_16

    .line 380
    .end local v0    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\14":Lkotlin/jvm/functions/Function0;
    :cond_1f
    move-object/from16 v0, v22

    .end local v22    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 382
    :goto_16
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 383
    .local v16, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\382\\13":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v0

    .end local v0    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\14":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 384
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 386
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\16":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 387
    .local v17, "$i$f$set-impl\\16\\386":I
    move-object/from16 v18, v1

    .local v18, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 388
    .local v26, "$i$a$-with-Updater$set$1\\17\\387\\16":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_21

    move-object/from16 v27, v2

    .end local v2    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .local v27, "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_20

    goto :goto_17

    :cond_20
    move-object/from16 v3, v18

    goto :goto_18

    .end local v27    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .restart local v2    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    :cond_21
    move-object/from16 v27, v2

    .line 389
    .end local v2    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .restart local v27    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    :goto_17
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 390
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 392
    :goto_18
    nop

    .line 387
    .end local v3    # "$this$set_impl_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\17\\387\\16":I
    nop

    .line 392
    nop

    .line 393
    .end local v0    # "block\\16":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\16\\386":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 394
    nop

    .line 382
    .end local v1    # "$this$Layout_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\15\\382\\13":I
    nop

    .line 395
    shr-int/lit8 v0, v24, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\18":I
    move-object v1, v9

    .local v1, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 396
    .local v2, "$i$a$-Layout-BoxKt$Box$1\\18\\395\\12":I
    const v3, -0x7ff519f7    # -1.000876E-39f

    move/from16 v26, v0

    .end local v0    # "$changed\\18":I
    .local v26, "$changed\\18":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v3, v6, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\19":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$HardwareKey_u24lambda_u2423\\19":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v16, v1

    .local v16, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 133
    .local v28, "$i$a$-Box-FullscreenScreenKt$HardwareKey$4\\19\\396\\0":I
    move-object/from16 v29, v0

    .end local v0    # "$this$HardwareKey_u24lambda_u2423\\19":Landroidx/compose/foundation/layout/BoxScope;
    .local v29, "$this$HardwareKey_u24lambda_u2423\\19":Landroidx/compose/foundation/layout/BoxScope;
    const v0, -0x9d4dd3

    move-object/from16 v30, v1

    .end local v1    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\18":Landroidx/compose/runtime/Composer;
    const-string v1, "C132@9019L101:FullscreenScreen.kt#o13vsk"

    move/from16 v31, v2

    move-object/from16 v2, v16

    .end local v16    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v31, "$i$a$-Layout-BoxKt$Box$1\\18\\395\\12":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x16

    .local v1, "$this$dp\\20":I
    const/16 v16, 0x0

    .line 397
    .local v16, "$i$f$getDp\\20\\133":I
    move-object/from16 v17, v2

    .end local v2    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v17, "$composer\\19":Landroidx/compose/runtime/Composer;
    int-to-float v2, v1

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 133
    .end local v1    # "$this$dp\\20":I
    .end local v16    # "$i$f$getDp\\20\\133":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v32

    if-eqz v5, :cond_22

    const v1, 0x3f59999a    # 0.85f

    goto :goto_19

    :cond_22
    const v1, 0x3e99999a    # 0.3f

    :goto_19
    move/from16 v34, v1

    const/16 v38, 0xe

    const/16 v39, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    invoke-static/range {v32 .. v39}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v1

    move-object/from16 v16, v0

    and-int/lit8 v0, v10, 0xe

    or-int/lit16 v0, v0, 0x1b0

    const/16 v18, 0x0

    move/from16 v32, v12

    .end local v12    # "propagateMinConstraints\\12":Z
    .local v32, "propagateMinConstraints\\12":Z
    const/4 v12, 0x0

    move-object/from16 v40, v17

    move/from16 v17, v0

    move-object v0, v13

    move-object/from16 v13, v16

    move-object/from16 v16, v40

    move-wide/from16 v40, v1

    move-object v1, v14

    move-object v2, v15

    move-wide/from16 v14, v40

    .end local v13    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v14    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .end local v17    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v0, "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v1, "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .local v2, "materialized\\13":Landroidx/compose/ui/Modifier;
    .local v16, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static/range {v11 .. v18}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 134
    nop

    .line 396
    .end local v3    # "$changed\\19":I
    .end local v16    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-Box-FullscreenScreenKt$HardwareKey$4\\19\\396\\0":I
    .end local v29    # "$this$HardwareKey_u24lambda_u2423\\19":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 395
    .end local v26    # "$changed\\18":I
    .end local v30    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v31    # "$i$a$-Layout-BoxKt$Box$1\\18\\395\\12":I
    nop

    .line 398
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 374
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 399
    nop

    .line 368
    .end local v22    # "factory\\14":Lkotlin/jvm/functions/Function0;
    .end local v23    # "$i$f$ReusableComposeNode\\14\\372":I
    .end local v24    # "$changed\\14":I
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 400
    nop

    .line 362
    .end local v1    # "localMap\\13":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v2    # "materialized\\13":Landroidx/compose/ui/Modifier;
    .end local v19    # "compositeKeyHash\\13":I
    .end local v20    # "$changed\\13":I
    .end local v21    # "$i$f$Layout\\13\\367":I
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 401
    nop

    .end local v0    # "measurePolicy\\12":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v6    # "$changed\\12":I
    .end local v8    # "$i$f$Box\\12\\129":I
    .end local v25    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v27    # "contentAlignment\\12":Landroidx/compose/ui/Alignment;
    .end local v32    # "propagateMinConstraints\\12":Z
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local p7    # "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    :cond_23
    :goto_1a
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_24

    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda9;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v6, p5

    move/from16 v8, p8

    invoke-direct/range {v0 .. v8}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda9;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;I)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 135
    :cond_24
    return-void
.end method

.method private static final HardwareKey$lambda$18$lambda$17(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 130
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/semantics/Role$Companion;->getButton-o7Vup1c()I

    move-result v0

    invoke-static {p1, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setRole-kuIjeqM(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HardwareKey$lambda$20$lambda$19(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;IZ)Lkotlin/Unit;
    .locals 1
    .param p0, "$onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p2, "button"    # I
    .param p3, "down"    # Z

    .line 131
    if-eqz p3, :cond_0

    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    :cond_0
    invoke-interface {p1, p2, p3}, Lorg/lighttouch/android/GuestHost;->button(IZ)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HardwareKey$lambda$22$lambda$21(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "$haptic"    # Landroidx/compose/ui/hapticfeedback/HapticFeedback;

    .line 131
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/AppSettings;->getHaptics()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Landroidx/compose/ui/hapticfeedback/HapticFeedbackType;->Companion:Landroidx/compose/ui/hapticfeedback/HapticFeedbackType$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/hapticfeedback/HapticFeedbackType$Companion;->getLongPress-5zf0vsI()I

    move-result v0

    invoke-interface {p1, v0}, Landroidx/compose/ui/hapticfeedback/HapticFeedback;->performHapticFeedback-CdsT49E(I)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HardwareKey$lambda$24(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 10

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move v5, p4

    move-object v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p8

    invoke-static/range {v1 .. v9}, Lorg/lighttouch/android/FullscreenScreenKt;->HardwareKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;ILorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HomeKey--jt2gSs(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FLandroidx/compose/runtime/Composer;II)V
    .locals 38
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "enabled"    # Z
    .param p2, "onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p3, "size"    # F
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/lighttouch/android/GuestHost;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;F",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    .line 147
    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v5, p5

    const v0, 0x1ba985f1

    move-object/from16 v4, p4

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(HomeKey)P(1!,3:c#ui.unit.Dp)147@9795L7,149@9997L51,150@10113L69,150@10184L89,148@9807L664:FullscreenScreen.kt#o13vsk"

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p5

    .local v4, "$dirty":I
    and-int/lit8 v6, p6, 0x1

    if-eqz v6, :cond_0

    or-int/lit8 v4, v4, 0x6

    goto :goto_2

    :cond_0
    and-int/lit8 v6, v5, 0x6

    if-nez v6, :cond_3

    and-int/lit8 v6, v5, 0x8

    if-nez v6, :cond_1

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    goto :goto_0

    :cond_1
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    :goto_0
    if-eqz v6, :cond_2

    const/4 v6, 0x4

    goto :goto_1

    :cond_2
    const/4 v6, 0x2

    :goto_1
    or-int/2addr v4, v6

    :cond_3
    :goto_2
    and-int/lit8 v6, p6, 0x2

    if-eqz v6, :cond_4

    or-int/lit8 v4, v4, 0x30

    goto :goto_4

    :cond_4
    and-int/lit8 v6, v5, 0x30

    if-nez v6, :cond_6

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_5

    const/16 v6, 0x20

    goto :goto_3

    :cond_5
    const/16 v6, 0x10

    :goto_3
    or-int/2addr v4, v6

    :cond_6
    :goto_4
    and-int/lit8 v6, p6, 0x4

    const/16 v9, 0x100

    if-eqz v6, :cond_7

    or-int/lit16 v4, v4, 0x180

    goto :goto_6

    :cond_7
    and-int/lit16 v6, v5, 0x180

    if-nez v6, :cond_9

    invoke-interface {v7, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_8

    move v6, v9

    goto :goto_5

    :cond_8
    const/16 v6, 0x80

    :goto_5
    or-int/2addr v4, v6

    :cond_9
    :goto_6
    and-int/lit8 v6, p6, 0x8

    if-eqz v6, :cond_a

    or-int/lit16 v4, v4, 0xc00

    move/from16 v10, p3

    goto :goto_8

    :cond_a
    and-int/lit16 v10, v5, 0xc00

    if-nez v10, :cond_c

    move/from16 v10, p3

    invoke-interface {v7, v10}, Landroidx/compose/runtime/Composer;->changed(F)Z

    move-result v11

    if-eqz v11, :cond_b

    const/16 v11, 0x800

    goto :goto_7

    :cond_b
    const/16 v11, 0x400

    :goto_7
    or-int/2addr v4, v11

    goto :goto_8

    :cond_c
    move/from16 v10, p3

    :goto_8
    move v11, v4

    .end local v4    # "$dirty":I
    .local v11, "$dirty":I
    and-int/lit16 v4, v11, 0x493

    const/16 v12, 0x492

    if-ne v4, v12, :cond_e

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v4

    if-nez v4, :cond_d

    goto :goto_9

    .line 504
    :cond_d
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v4, v10

    goto/16 :goto_19

    .line 147
    :cond_e
    :goto_9
    if-eqz v6, :cond_f

    const/16 v4, 0x40

    .local v4, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 449
    .local v6, "$i$f$getDp\\1\\147":I
    int-to-float v12, v4

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    move v10, v4

    .end local v4    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\147":I
    .end local p3    # "size":F
    .local v10, "size":F
    :cond_f
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_10

    const/4 v4, -0x1

    const-string v6, "org.lighttouch.android.HomeKey (FullscreenScreen.kt:146)"

    invoke-static {v0, v11, v4, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 148
    :cond_10
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalHapticFeedback()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/CompositionLocal;

    .local v0, "this_\\2":Landroidx/compose/runtime/CompositionLocal;
    const/4 v4, 0x0

    .local v4, "$changed\\2":I
    const/4 v6, 0x0

    .line 450
    .local v6, "$i$f$getCurrent\\2\\148":I
    const v12, 0x789c5f52

    const-string v13, "CC:CompositionLocal.kt#9igjgp"

    invoke-static {v7, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v12

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 148
    .end local v0    # "this_\\2":Landroidx/compose/runtime/CompositionLocal;
    .end local v4    # "$changed\\2":I
    .end local v6    # "$i$f$getCurrent\\2\\148":I
    move-object v0, v12

    check-cast v0, Landroidx/compose/ui/hapticfeedback/HapticFeedback;

    .line 149
    .local v0, "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    invoke-static {v4, v10}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v6

    check-cast v6, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v4, v6}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    sget-object v4, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v13

    const/16 v19, 0xe

    const/16 v20, 0x0

    const v15, 0x3d75c28f    # 0.06f

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-static/range {v13 .. v20}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v13

    const/16 v16, 0x2

    const/16 v17, 0x0

    const/4 v15, 0x0

    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const-wide/high16 v12, 0x3ff8000000000000L    # 1.5

    .local v12, "$this$dp\\3":D
    const/4 v6, 0x0

    .line 451
    .local v6, "$i$f$getDp\\3\\149":I
    double-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 149
    .end local v6    # "$i$f$getDp\\3\\149":I
    .end local v12    # "$this$dp\\3":D
    sget-object v12, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v13

    if-eqz v2, :cond_11

    const v12, 0x3eb33333    # 0.35f

    goto :goto_a

    :cond_11
    const v12, 0x3e19999a    # 0.15f

    :goto_a
    move v15, v12

    const/16 v19, 0xe

    const/16 v20, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-static/range {v13 .. v20}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v12

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v14

    check-cast v14, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v4, v6, v12, v13, v14}, Landroidx/compose/foundation/BorderKt;->border-xT4_qwU(Landroidx/compose/ui/Modifier;FJLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 150
    const v6, 0x6e3c21fe

    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "CC(remember):FullscreenScreen.kt#9igjgp"

    invoke-static {v7, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v12, 0x0

    .local v12, "invalid\\4":Z
    move-object v13, v7

    .local v13, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 452
    .local v14, "$i$f$cache\\4\\150":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\4":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 453
    .local v16, "$i$a$-let-ComposerKt$cache$1\\5\\452\\4":I
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v15, v8, :cond_12

    .line 454
    const/4 v8, 0x0

    .local v8, "$i$a$-cache-FullscreenScreenKt$HomeKey$1\\6\\454\\0":I
    new-instance v17, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda3;

    invoke-direct/range {v17 .. v17}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda3;-><init>()V

    .end local v8    # "$i$a$-cache-FullscreenScreenKt$HomeKey$1\\6\\454\\0":I
    move-object/from16 v8, v17

    .line 455
    .local v8, "value\\5":Ljava/lang/Object;
    invoke-interface {v13, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 456
    nop

    .end local v8    # "value\\5":Ljava/lang/Object;
    goto :goto_b

    .line 457
    :cond_12
    move-object v8, v15

    .line 453
    :goto_b
    nop

    .line 452
    .end local v15    # "it\\4":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\5\\452\\4":I
    nop

    .line 150
    .end local v12    # "invalid\\4":Z
    .end local v13    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\4\\150":I
    check-cast v8, Lkotlin/jvm/functions/Function1;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-static {v4, v13, v8, v14, v12}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const-string v8, "home_button"

    invoke-static {v4, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 151
    const v8, -0x615d173a

    invoke-interface {v7, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit16 v12, v11, 0x380

    if-ne v12, v9, :cond_13

    move v9, v14

    goto :goto_c

    :cond_13
    move v9, v13

    :goto_c
    and-int/lit8 v12, v11, 0xe

    const/4 v15, 0x4

    if-eq v12, v15, :cond_15

    and-int/lit8 v12, v11, 0x8

    if-eqz v12, :cond_14

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_14

    goto :goto_d

    :cond_14
    move v12, v13

    goto :goto_e

    :cond_15
    :goto_d
    move v12, v14

    :goto_e
    or-int/2addr v9, v12

    .local v9, "invalid\\7":Z
    move-object v12, v7

    .local v12, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 458
    .local v15, "$i$f$cache\\7\\151":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\7":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 459
    .local v16, "$i$a$-let-ComposerKt$cache$1\\8\\458\\7":I
    if-nez v9, :cond_17

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v14, v13, :cond_16

    goto :goto_f

    .line 463
    :cond_16
    move-object v8, v14

    goto :goto_10

    .line 460
    :cond_17
    :goto_f
    const/4 v13, 0x0

    .line 151
    .local v13, "$i$a$-cache-FullscreenScreenKt$HomeKey$2\\9\\460\\0":I
    new-instance v8, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v8, v3, v1}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda4;-><init>(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;)V

    .line 460
    .end local v13    # "$i$a$-cache-FullscreenScreenKt$HomeKey$2\\9\\460\\0":I
    nop

    .line 461
    .local v8, "value\\8":Ljava/lang/Object;
    invoke-interface {v12, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 462
    nop

    .line 459
    .end local v8    # "value\\8":Ljava/lang/Object;
    :goto_10
    nop

    .line 458
    .end local v14    # "it\\7":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\8\\458\\7":I
    nop

    .line 151
    .end local v9    # "invalid\\7":Z
    .end local v12    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\7\\151":I
    check-cast v8, Lkotlin/jvm/functions/Function2;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const v9, -0x615d173a

    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-static {v7, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v6, v11, 0xe

    const/4 v15, 0x4

    if-eq v6, v15, :cond_19

    and-int/lit8 v6, v11, 0x8

    if-eqz v6, :cond_18

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_18

    goto :goto_11

    :cond_18
    const/4 v14, 0x0

    goto :goto_12

    :cond_19
    :goto_11
    const/4 v14, 0x1

    :goto_12
    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v6, v14

    .local v6, "invalid\\10":Z
    move-object v9, v7

    .local v9, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 458
    .local v12, "$i$f$cache\\10\\151":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\10":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 459
    .local v14, "$i$a$-let-ComposerKt$cache$1\\11\\458\\10":I
    if-nez v6, :cond_1b

    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v13, v15, :cond_1a

    goto :goto_13

    .line 463
    :cond_1a
    move-object v3, v13

    goto :goto_14

    .line 460
    :cond_1b
    :goto_13
    const/4 v15, 0x0

    .line 151
    .local v15, "$i$a$-cache-FullscreenScreenKt$HomeKey$3\\12\\460\\0":I
    new-instance v3, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v3, v1, v0}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda5;-><init>(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)V

    .line 460
    .end local v15    # "$i$a$-cache-FullscreenScreenKt$HomeKey$3\\12\\460\\0":I
    nop

    .line 461
    .local v3, "value\\11":Ljava/lang/Object;
    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 462
    nop

    .line 459
    .end local v3    # "value\\11":Ljava/lang/Object;
    :goto_14
    nop

    .line 458
    .end local v13    # "it\\10":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\11\\458\\10":I
    nop

    .line 151
    .end local v6    # "invalid\\10":Z
    .end local v9    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\10\\151":I
    check-cast v3, Lkotlin/jvm/functions/Function0;

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v6, 0x0

    invoke-static {v4, v2, v6, v8, v3}, Lorg/lighttouch/android/DeviceFrameKt;->held(Landroidx/compose/ui/Modifier;ZILkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 152
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 149
    const/16 v6, 0x30

    .local v3, "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v4, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .local v6, "$changed\\13":I
    const/4 v8, 0x0

    .line 464
    .local v8, "$i$f$Box\\13\\149":I
    const v9, 0x2bb5b5d7

    const-string v12, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v7, v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 465
    const/4 v9, 0x0

    .line 468
    .local v9, "propagateMinConstraints\\13":Z
    invoke-static {v4, v9}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .local v12, "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v6, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 469
    nop

    .local v13, "$changed\\14":I
    const/4 v14, 0x0

    .line 470
    .local v14, "$i$f$Layout\\14\\469":I
    const v15, -0x4ee9b9da

    move-object/from16 p3, v0

    .end local v0    # "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    .local p3, "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    const-string v0, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v7, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 471
    const/4 v0, 0x0

    invoke-static {v7, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v15

    .line 472
    .local v15, "compositeKeyHash\\14":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 473
    .local v0, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 475
    .local v1, "materialized\\14":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v2, v13, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 474
    nop

    .local v2, "$changed\\15":I
    move-object/from16 p4, v16

    .local p4, "factory\\15":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 476
    .local v16, "$i$f$ReusableComposeNode\\15\\474":I
    move/from16 v17, v2

    .end local v2    # "$changed\\15":I
    .local v17, "$changed\\15":I
    const v2, -0x2942ffcf

    move-object/from16 v19, v3

    .end local v3    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\13":Landroidx/compose/ui/Modifier;
    const-string v3, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v7, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 477
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_1c

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 478
    :cond_1c
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 479
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_1d

    .line 480
    move-object/from16 v2, p4

    .end local p4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_15

    .line 482
    .end local v2    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local p4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    :cond_1d
    move-object/from16 v2, p4

    .end local p4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 484
    :goto_15
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 485
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\484\\14":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 p4, v2

    .end local v2    # "factory\\15":Lkotlin/jvm/functions/Function0;
    .restart local p4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v12, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 486
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 488
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\17":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 489
    .local v21, "$i$f$set-impl\\17\\488":I
    move-object/from16 v22, v3

    .local v22, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 490
    .local v23, "$i$a$-with-Updater$set$1\\18\\489\\17":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_1f

    move-object/from16 v24, v0

    .end local v0    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .local v24, "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v25, v4

    .end local v4    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .local v25, "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1e

    goto :goto_16

    :cond_1e
    move-object/from16 v4, v22

    goto :goto_17

    .end local v24    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v25    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .restart local v0    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    :cond_1f
    move-object/from16 v24, v0

    move-object/from16 v25, v4

    .line 491
    .end local v0    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    .restart local v24    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v25    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    :goto_16
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v4, v22

    .end local v22    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 492
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v3, v0, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 494
    :goto_17
    nop

    .line 489
    .end local v4    # "$this$set_impl_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-with-Updater$set$1\\18\\489\\17":I
    nop

    .line 494
    nop

    .line 495
    .end local v2    # "block\\17":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\17\\488":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v3, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 496
    nop

    .line 484
    .end local v3    # "$this$Layout_u24lambda_u240\\16":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\16\\484\\14":I
    nop

    .line 497
    shr-int/lit8 v0, v17, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\19":I
    move-object v2, v7

    .local v2, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 498
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\19\\497\\13":I
    const v4, -0x7ff519f7    # -1.000876E-39f

    move/from16 v20, v0

    .end local v0    # "$changed\\19":I
    .local v20, "$changed\\19":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v4, v6, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\20":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$HomeKey__jt2gSs_u24lambda_u2435\\20":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v21, v2

    .local v21, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 153
    .local v22, "$i$a$-Box-FullscreenScreenKt$HomeKey$4\\20\\498\\0":I
    move-object/from16 v23, v0

    .end local v0    # "$this$HomeKey__jt2gSs_u24lambda_u2435\\20":Landroidx/compose/foundation/layout/BoxScope;
    .local v23, "$this$HomeKey__jt2gSs_u24lambda_u2435\\20":Landroidx/compose/foundation/layout/BoxScope;
    const v0, 0x21a17c45

    move-object/from16 v26, v1

    .end local v1    # "materialized\\14":Landroidx/compose/ui/Modifier;
    .local v26, "materialized\\14":Landroidx/compose/ui/Modifier;
    const-string v1, "C152@10330L135:FullscreenScreen.kt#o13vsk"

    move-object/from16 v27, v2

    .end local v21    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const v1, 0x3e99999a    # 0.3f

    .local v1, "other\\21":F
    const/16 v21, 0x0

    .line 499
    .local v21, "$i$f$times-u2uoSUM\\21\\153":I
    mul-float v28, v10, v1

    invoke-static/range {v28 .. v28}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 153
    .end local v1    # "other\\21":F
    .end local v21    # "$i$f$times-u2uoSUM\\21\\153":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move v1, v3

    move/from16 v21, v4

    .end local v3    # "$i$a$-Layout-BoxKt$Box$1\\19\\497\\13":I
    .end local v4    # "$changed\\20":I
    .local v1, "$i$a$-Layout-BoxKt$Box$1\\19\\497\\13":I
    .local v21, "$changed\\20":I
    const-wide/high16 v3, 0x3ff8000000000000L    # 1.5

    .local v3, "$this$dp\\22":D
    const/16 v28, 0x0

    .line 500
    .local v28, "$i$f$getDp\\22\\153":I
    move/from16 v29, v1

    .end local v1    # "$i$a$-Layout-BoxKt$Box$1\\19\\497\\13":I
    .local v29, "$i$a$-Layout-BoxKt$Box$1\\19\\497\\13":I
    double-to-float v1, v3

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 153
    .end local v3    # "$this$dp\\22":D
    .end local v28    # "$i$f$getDp\\22\\153":I
    sget-object v3, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v30

    if-eqz p1, :cond_20

    const v3, 0x3f19999a    # 0.6f

    goto :goto_18

    :cond_20
    const v3, 0x3e4ccccd    # 0.2f

    :goto_18
    move/from16 v32, v3

    const/16 v36, 0xe

    const/16 v37, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    invoke-static/range {v30 .. v37}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v3

    const v28, 0x3d8f5c29    # 0.07f

    .local v28, "other\\23":F
    const/16 v30, 0x0

    .line 499
    .local v30, "$i$f$times-u2uoSUM\\23\\153":I
    mul-float v31, v10, v28

    invoke-static/range {v31 .. v31}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v28

    .line 153
    .end local v28    # "other\\23":F
    .end local v30    # "$i$f$times-u2uoSUM\\23\\153":I
    invoke-static/range {v28 .. v28}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v28

    move-object/from16 v5, v28

    check-cast v5, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v1, v3, v4, v5}, Landroidx/compose/foundation/BorderKt;->border-xT4_qwU(Landroidx/compose/ui/Modifier;FJLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v2, v1}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 154
    nop

    .line 498
    .end local v2    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v21    # "$changed\\20":I
    .end local v22    # "$i$a$-Box-FullscreenScreenKt$HomeKey$4\\20\\498\\0":I
    .end local v23    # "$this$HomeKey__jt2gSs_u24lambda_u2435\\20":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 497
    .end local v20    # "$changed\\19":I
    .end local v27    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-Layout-BoxKt$Box$1\\19\\497\\13":I
    nop

    .line 501
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 476
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 502
    nop

    .line 470
    .end local v16    # "$i$f$ReusableComposeNode\\15\\474":I
    .end local v17    # "$changed\\15":I
    .end local p4    # "factory\\15":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 503
    nop

    .line 464
    .end local v13    # "$changed\\14":I
    .end local v14    # "$i$f$Layout\\14\\469":I
    .end local v15    # "compositeKeyHash\\14":I
    .end local v24    # "localMap\\14":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v26    # "materialized\\14":Landroidx/compose/ui/Modifier;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 504
    nop

    .end local v6    # "$changed\\13":I
    .end local v8    # "$i$f$Box\\13\\149":I
    .end local v9    # "propagateMinConstraints\\13":Z
    .end local v12    # "measurePolicy\\13":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "modifier\\13":Landroidx/compose/ui/Modifier;
    .end local v25    # "contentAlignment\\13":Landroidx/compose/ui/Alignment;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_21

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local p3    # "haptic":Landroidx/compose/ui/hapticfeedback/HapticFeedback;
    :cond_21
    move v4, v10

    .end local v10    # "size":F
    .local v4, "size":F
    :goto_19
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_22

    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda6;

    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v5, p5

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda6;-><init>(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FII)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 155
    :cond_22
    return-void
.end method

.method private static final HomeKey__jt2gSs$lambda$30$lambda$29(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 150
    const-string v0, "\u4e3b\u5c4f\u5e55"

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/semantics/Role;->Companion:Landroidx/compose/ui/semantics/Role$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/semantics/Role$Companion;->getButton-o7Vup1c()I

    move-result v0

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setRole-kuIjeqM(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HomeKey__jt2gSs$lambda$32$lambda$31(Lkotlin/jvm/functions/Function0;Lorg/lighttouch/android/GuestHost;IZ)Lkotlin/Unit;
    .locals 1
    .param p0, "$onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p2, "button"    # I
    .param p3, "down"    # Z

    .line 151
    if-eqz p3, :cond_0

    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    :cond_0
    invoke-interface {p1, p2, p3}, Lorg/lighttouch/android/GuestHost;->button(IZ)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HomeKey__jt2gSs$lambda$34$lambda$33(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/hapticfeedback/HapticFeedback;)Lkotlin/Unit;
    .locals 1
    .param p0, "$host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "$haptic"    # Landroidx/compose/ui/hapticfeedback/HapticFeedback;

    .line 151
    invoke-interface {p0}, Lorg/lighttouch/android/GuestHost;->getSettings()Lorg/lighttouch/android/AppSettings;

    move-result-object v0

    invoke-virtual {v0}, Lorg/lighttouch/android/AppSettings;->getHaptics()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Landroidx/compose/ui/hapticfeedback/HapticFeedbackType;->Companion:Landroidx/compose/ui/hapticfeedback/HapticFeedbackType$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/hapticfeedback/HapticFeedbackType$Companion;->getLongPress-5zf0vsI()I

    move-result v0

    invoke-interface {p1, v0}, Landroidx/compose/ui/hapticfeedback/HapticFeedback;->performHapticFeedback-CdsT49E(I)V

    :cond_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final HomeKey__jt2gSs$lambda$36(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move v4, p3

    move v7, p5

    move-object v5, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/FullscreenScreenKt;->HomeKey--jt2gSs(Lorg/lighttouch/android/GuestHost;ZLkotlin/jvm/functions/Function0;FLandroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final SmallKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .locals 38
    .param p0, "icon"    # Landroidx/compose/ui/graphics/vector/ImageVector;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "onClick"    # Lkotlin/jvm/functions/Function0;
    .param p3, "enabled"    # Z
    .param p4, "tag"    # Ljava/lang/String;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/graphics/vector/ImageVector;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;Z",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 138
    move-object/from16 v2, p1

    move/from16 v4, p3

    move-object/from16 v0, p4

    move/from16 v1, p6

    const v3, 0x22b1f903

    move-object/from16 v5, p5

    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(SmallKey)P(1,2,3)139@9365L30,138@9255L309:FullscreenScreen.kt#o13vsk"

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p6

    .local v5, "$dirty":I
    and-int/lit8 v6, v1, 0x6

    if-nez v6, :cond_1

    move-object/from16 v11, p0

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v5, v6

    goto :goto_1

    :cond_1
    move-object/from16 v11, p0

    :goto_1
    and-int/lit8 v6, v1, 0x30

    const/16 v12, 0x20

    if-nez v6, :cond_3

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    move v6, v12

    goto :goto_2

    :cond_2
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v5, v6

    :cond_3
    and-int/lit16 v6, v1, 0x180

    if-nez v6, :cond_5

    move-object/from16 v7, p2

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    const/16 v6, 0x100

    goto :goto_3

    :cond_4
    const/16 v6, 0x80

    :goto_3
    or-int/2addr v5, v6

    goto :goto_4

    :cond_5
    move-object/from16 v7, p2

    :goto_4
    and-int/lit16 v6, v1, 0xc00

    if-nez v6, :cond_7

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_6

    const/16 v6, 0x800

    goto :goto_5

    :cond_6
    const/16 v6, 0x400

    :goto_5
    or-int/2addr v5, v6

    :cond_7
    and-int/lit16 v6, v1, 0x6000

    if-nez v6, :cond_9

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_8

    const/16 v6, 0x4000

    goto :goto_6

    :cond_8
    const/16 v6, 0x2000

    :goto_6
    or-int/2addr v5, v6

    :cond_9
    move v13, v5

    .end local v5    # "$dirty":I
    .local v13, "$dirty":I
    and-int/lit16 v5, v13, 0x2493

    const/16 v6, 0x2492

    if-ne v5, v6, :cond_b

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v5

    if-nez v5, :cond_a

    goto :goto_7

    .line 448
    :cond_a
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v28, v13

    goto/16 :goto_f

    .line 138
    :cond_b
    :goto_7
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_c

    const/4 v5, -0x1

    const-string v6, "org.lighttouch.android.SmallKey (FullscreenScreen.kt:137)"

    invoke-static {v3, v13, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 139
    :cond_c
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x2c

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 402
    .local v6, "$i$f$getDp\\1\\139":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 139
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\139":I
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-static {}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->getCircleShape()Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v5

    check-cast v5, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v3, v5}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static/range {v3 .. v9}, Landroidx/compose/foundation/ClickableKt;->clickable-XHw0xAI$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 140
    const v4, 0x4c5de2

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "CC(remember):FullscreenScreen.kt#9igjgp"

    invoke-static {v10, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v4, v13, 0x70

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-ne v4, v12, :cond_d

    move v4, v5

    goto :goto_8

    :cond_d
    move v4, v6

    .local v4, "invalid\\2":Z
    :goto_8
    move-object v7, v10

    .local v7, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 403
    .local v8, "$i$f$cache\\2\\140":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\2":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 404
    .local v12, "$i$a$-let-ComposerKt$cache$1\\3\\403\\2":I
    if-nez v4, :cond_f

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v9, v14, :cond_e

    goto :goto_9

    .line 408
    :cond_e
    move-object v15, v9

    goto :goto_a

    .line 405
    :cond_f
    :goto_9
    const/4 v14, 0x0

    .line 140
    .local v14, "$i$a$-cache-FullscreenScreenKt$SmallKey$1\\4\\405\\0":I
    new-instance v15, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v15, v2}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda10;-><init>(Ljava/lang/String;)V

    .line 405
    .end local v14    # "$i$a$-cache-FullscreenScreenKt$SmallKey$1\\4\\405\\0":I
    nop

    .line 406
    .local v15, "value\\3":Ljava/lang/Object;
    invoke-interface {v7, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 407
    nop

    .line 404
    .end local v15    # "value\\3":Ljava/lang/Object;
    :goto_a
    nop

    .line 403
    .end local v9    # "it\\2":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\3\\403\\2":I
    nop

    .line 140
    .end local v4    # "invalid\\2":Z
    .end local v7    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\2\\140":I
    check-cast v15, Lkotlin/jvm/functions/Function1;

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    const/4 v4, 0x0

    invoke-static {v3, v6, v15, v5, v4}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-static {v3, v0}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 139
    nop

    .local v3, "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v4, "contentAlignment\\5":Landroidx/compose/ui/Alignment;
    const/16 v5, 0x30

    .local v5, "$changed\\5":I
    const/4 v7, 0x0

    .line 409
    .local v7, "$i$f$Box\\5\\139":I
    const v8, 0x2bb5b5d7

    const-string v9, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo"

    invoke-static {v10, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 410
    const/4 v8, 0x0

    .line 413
    .local v8, "propagateMinConstraints\\5":Z
    invoke-static {v4, v8}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .local v9, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v5, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 414
    move/from16 v19, v12

    .local v19, "$changed\\6":I
    const/16 v20, 0x0

    .line 415
    .local v20, "$i$f$Layout\\6\\414":I
    const v12, -0x4ee9b9da

    const-string v14, "CC(Layout)P(!1,2)79@3208L23,82@3359L411:Layout.kt#80mrfh"

    invoke-static {v10, v12, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 416
    invoke-static {v10, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/Composer;I)I

    move-result v6

    .line 417
    .local v6, "compositeKeyHash\\6":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 418
    .local v12, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 420
    .local v14, "materialized\\6":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v0, v19, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 419
    nop

    .local v0, "$changed\\7":I
    .local v15, "factory\\7":Lkotlin/jvm/functions/Function0;
    const/16 v21, 0x0

    .line 421
    .local v21, "$i$f$ReusableComposeNode\\7\\419":I
    move/from16 p5, v0

    .end local v0    # "$changed\\7":I
    .local p5, "$changed\\7":I
    const v0, -0x2942ffcf

    const-string v1, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 422
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_10

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 423
    :cond_10
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 424
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_11

    .line 425
    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b

    .line 427
    :cond_11
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 429
    :goto_b
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 430
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\429\\6":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v17, v1

    .end local v1    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\429\\6":I
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\429\\6":I
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v9, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 431
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 433
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\9":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 434
    .local v16, "$i$f$set-impl\\9\\433":I
    move-object/from16 v18, v0

    .local v18, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 435
    .local v22, "$i$a$-with-Updater$set$1\\10\\434\\9":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_13

    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v23, v3

    .end local v3    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v23, "modifier\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_12

    goto :goto_c

    :cond_12
    move-object/from16 v3, v18

    goto :goto_d

    .end local v23    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .restart local v3    # "modifier\\5":Landroidx/compose/ui/Modifier;
    :cond_13
    move-object/from16 v23, v3

    .line 436
    .end local v3    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .restart local v23    # "modifier\\5":Landroidx/compose/ui/Modifier;
    :goto_c
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 437
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 439
    :goto_d
    nop

    .line 434
    .end local v3    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\10\\434\\9":I
    nop

    .line 439
    nop

    .line 440
    .end local v1    # "block\\9":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\9\\433":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 441
    nop

    .line 429
    .end local v0    # "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\429\\6":I
    nop

    .line 442
    shr-int/lit8 v0, p5, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\11":I
    move-object v1, v10

    .local v1, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 443
    .local v2, "$i$a$-Layout-BoxKt$Box$1\\11\\442\\5":I
    const v3, -0x7ff519f7    # -1.000876E-39f

    move/from16 v22, v0

    .end local v0    # "$changed\\11":I
    .local v22, "$changed\\11":I
    const-string v0, "C73@3429L9:Box.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v3, v5, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\12":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$SmallKey_u24lambda_u2427\\12":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v16, v1

    .local v16, "$composer\\12":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 141
    .local v24, "$i$a$-Box-FullscreenScreenKt$SmallKey$2\\12\\443\\0":I
    move-object/from16 v25, v0

    .end local v0    # "$this$SmallKey_u24lambda_u2427\\12":Landroidx/compose/foundation/layout/BoxScope;
    .local v25, "$this$SmallKey_u24lambda_u2427\\12":Landroidx/compose/foundation/layout/BoxScope;
    const v0, -0x22bd79ab

    move-object/from16 v26, v1

    .end local v1    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v26, "$composer\\11":Landroidx/compose/runtime/Composer;
    const-string v1, "C140@9457L101:FullscreenScreen.kt#o13vsk"

    move/from16 v27, v2

    move-object/from16 v2, v16

    .end local v16    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v27, "$i$a$-Layout-BoxKt$Box$1\\11\\442\\5":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x16

    .local v1, "$this$dp\\13":I
    const/16 v16, 0x0

    .line 444
    .local v16, "$i$f$getDp\\13\\141":I
    move-object/from16 v17, v2

    .end local v2    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v17, "$composer\\12":Landroidx/compose/runtime/Composer;
    int-to-float v2, v1

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 141
    .end local v1    # "$this$dp\\13":I
    .end local v16    # "$i$f$getDp\\13\\141":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    sget-object v1, Landroidx/compose/ui/graphics/Color;->Companion:Landroidx/compose/ui/graphics/Color$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/graphics/Color$Companion;->getWhite-0d7_KjU()J

    move-result-wide v28

    if-eqz p3, :cond_14

    const/high16 v1, 0x3f400000    # 0.75f

    goto :goto_e

    :cond_14
    const v1, 0x3e99999a    # 0.3f

    :goto_e
    move/from16 v30, v1

    const/16 v34, 0xe

    const/16 v35, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v28 .. v35}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v1

    move-object/from16 v16, v0

    and-int/lit8 v0, v13, 0xe

    or-int/lit16 v0, v0, 0x1b0

    const/16 v18, 0x0

    move-object/from16 v28, v12

    .end local v12    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .local v28, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v12, 0x0

    move-object/from16 v36, v17

    move/from16 v17, v0

    move-object/from16 v0, v28

    move/from16 v28, v13

    move-object/from16 v13, v16

    move-object/from16 v16, v36

    move-wide/from16 v36, v1

    move-object v1, v14

    move-object v2, v15

    move-wide/from16 v14, v36

    .end local v13    # "$dirty":I
    .end local v14    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .end local v15    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .end local v17    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v0, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .local v1, "materialized\\6":Landroidx/compose/ui/Modifier;
    .local v2, "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v16, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v28, "$dirty":I
    invoke-static/range {v11 .. v18}, Landroidx/compose/material3/IconKt;->Icon-ww6aTOc(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 142
    nop

    .line 443
    .end local v3    # "$changed\\12":I
    .end local v16    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Box-FullscreenScreenKt$SmallKey$2\\12\\443\\0":I
    .end local v25    # "$this$SmallKey_u24lambda_u2427\\12":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 442
    .end local v22    # "$changed\\11":I
    .end local v26    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-Layout-BoxKt$Box$1\\11\\442\\5":I
    nop

    .line 445
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 421
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 446
    nop

    .line 415
    .end local v2    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .end local v21    # "$i$f$ReusableComposeNode\\7\\419":I
    .end local p5    # "$changed\\7":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 447
    nop

    .line 409
    .end local v0    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v1    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .end local v6    # "compositeKeyHash\\6":I
    .end local v19    # "$changed\\6":I
    .end local v20    # "$i$f$Layout\\6\\414":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 448
    nop

    .end local v4    # "contentAlignment\\5":Landroidx/compose/ui/Alignment;
    .end local v5    # "$changed\\5":I
    .end local v7    # "$i$f$Box\\5\\139":I
    .end local v8    # "propagateMinConstraints\\5":Z
    .end local v9    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "modifier\\5":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    :cond_15
    :goto_f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_16

    new-instance v0, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda11;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lorg/lighttouch/android/FullscreenScreenKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 143
    :cond_16
    return-void
.end method

.method private static final SmallKey$lambda$26$lambda$25(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .locals 1
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 140
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SmallKey$lambda$28(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .locals 8

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lorg/lighttouch/android/FullscreenScreenKt;->SmallKey(Landroidx/compose/ui/graphics/vector/ImageVector;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLjava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final synthetic access$ButtonBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .locals 0
    .param p0, "host"    # Lorg/lighttouch/android/GuestHost;
    .param p1, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p2, "onInteract"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onStop"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .param p6, "$default"    # I

    .line 1
    invoke-static/range {p0 .. p6}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar(Lorg/lighttouch/android/GuestHost;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    return-void
.end method

.method public static final synthetic access$ButtonBar$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .locals 0
    .param p0, "$menu$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lorg/lighttouch/android/FullscreenScreenKt;->ButtonBar$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

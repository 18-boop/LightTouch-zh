# Android 汉化改动的复现步骤

本目录是 `LightTouch-0.0.11-android-arm64-zh.apk` 的全部改动，相对于上游 `LightTouch-3e0484d-arm64-debug.apk`（commit `3e0484d`）。

## 内容

- `smali_classes2/`、`smali_classes3/`：**仅包含被改动的 179 个 smali 文件**（其余文件与上游一致）
- `trans.json`：602 条「英文 → 简体中文」译文表
- `tools/apply.py`：按译文表回填 `const-string` 字面量（中文写成 `\uXXXX` 转义）
- `tools/verify.py`：校验 dex 是否可解析、译文是否写入、原文是否已消失
- `tools/count.py`：统计中文 `const-string` 数量
- `tools/diff_apk.py`：逐条目比对两个 APK（确认原生库与 assets 未变）
- `tools/extract_app_strings.py`、`tools/extract_ui_only.py`：抽取候选文案（用于制作译文表）

## 从原始 APK 复现

```bash
# 1) 反编译（保留原始 dex 便于比对）
java -jar apktool_2.11.1.jar d -f -o dec LightTouch-3e0484d-arm64-debug.apk

# 2) 用本目录覆盖改动过的 smali（或用 tools/apply.py 从 trans.json 回填）
cp -r smali_classes2 smali_classes3 dec/

# 3) 重新打包
java -Xmx4g -jar apktool_2.11.1.jar b dec -o LightTouch-zh-unsigned.apk

# 4) 对齐并签名（v1/v2/v3）
java -jar uber-apk-signer-1.3.0.jar --apks LightTouch-zh-unsigned.apk --out out
```

产物即 `LightTouch-0.0.11-android-arm64-zh.apk`。

## 也可以用译文表回填

```bash
python tools/apply.py      # 修改 dec/ 下的 smali
python tools/verify.py     # 校验结果
```

## 说明

- 中文以 `\uXXXX` 转义写入 smali，避免打包时的编码问题。
- 未翻译：硬件/产品名、格式串（`%.1f GB` 等）、`SharedPreferences` 键、枚举 `.name`、日志、协议字段、`testTag`。
- 原生库与 assets 逐字节未变，可用 `tools/diff_apk.py` 复核。
